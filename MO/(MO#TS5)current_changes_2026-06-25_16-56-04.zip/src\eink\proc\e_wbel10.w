&ANALYZE-SUSPEND _VERSION-NUMBER UIB_v8r12 GUI ADM1
&ANALYZE-RESUME
/* Connected Databases
          basis            PROGRESS
*/
&Scoped-define WINDOW-NAME CURRENT-WINDOW

&ANALYZE-SUSPEND _UIB-CODE-BLOCK _CUSTOM _DECLARATIONS V-table-Win 

/* _UIB-CODE-BLOCK-END */
&ANALYZE-RESUME


&ANALYZE-SUSPEND _UIB-CODE-BLOCK _XFTR "Update Information" V-table-Win _INLINE
/* Actions: ? ? ? ? adm/support/proc/ds_pa_01.w */

/* _UIB-CODE-BLOCK-END */
&ANALYZE-RESUME

&ANALYZE-SUSPEND _UIB-CODE-BLOCK _CUSTOM _DEFINITIONS V-table-Win 
/*****************************************************************************/
/* @COPYRIGHT@                                                               */
/*                                                                           */
/*  Projekt....: Proalpha                                                    */
/*                                                                           */
/*  Name.......: e_wbel10.w                                                  */
/*  Bereich....: EINK/KERN                                                   */
/*                                                                           */
/*  erstellt am: 31.07.1997                                                  */
/*  Autor......: Ingrid Gr�nder                                              */
/*                                                                           */
/*  Version....: @PAVERSION@ vom @PADATE@/@PALASTAUTHOR@                     */
/*                                                                           */
/*---------------------------------------------------------------------------*/
/*  AUFGABE                                                                  */
/*---------------------------------------------------------------------------*/
/*                                                                           */
/*  Grundviewer zur Anlage von Bestellpositionen                             */
/*                                                                           */
/*---------------------------------------------------------------------------*/
/*  ARGUMENTE/PARAMETER                                                      */
/*---------------------------------------------------------------------------*/
/*                                                                           */
/*  Name                Art Funktion/Inhalt                                  */
/*  ------------------- --- ------------------------------------------------ */
/*---------------------------------------------------------------------------*/
/*  �NDERUNGSPROTOKOLL                                                       */
/*---------------------------------------------------------------------------*/
/* @FILEHISTORY@                                                             */
/*****************************************************************************/

/*----------------------------------------------------------------------     */
/*          This .W file was created with the Progress UIB.                  */
/*----------------------------------------------------------------------     */

/* Create an unnamed pool to store all the widgets created
     by this procedure. This is a good default which assures
     that this procedure's triggers and internal procedures
     will execute in this procedure's storage, and that proper
     cleanup will occur on deletion of the procedure. */

CREATE WIDGET-POOL.

/*---------------------------------------------------------------------------*/
/* Definitionen                                                              */
/*---------------------------------------------------------------------------*/

/* KONSTANTEN ---------------------------------------------------------------*/
/* Systemkonstanten **********************************************************/

&GLOBAL-DEFINE pa-Autor             Ingrid Gr�nder
&GLOBAL-DEFINE pa-Version           @PAVERSION@
&GLOBAL-DEFINE pa-Datum             @PADATE@
&GLOBAL-DEFINE pa-Letzter           @PALASTAUTHOR@

&GLOBAL-DEFINE pa-GenVersion       UIB
&GLOBAL-DEFINE pa-ProgrammTyp      SmartViewer
&GLOBAL-DEFINE pa-Template         adm/template/proc/dt_viw00.w
&GLOBAL-DEFINE pa-TemplateVersion  1.07

&GLOBAL-DEFINE pa-XBasisName       e_wbel10_w


/* lokale Konstanten *********************************************************/

&Scoped-define pa-ENABLE-check FelderEnablen()

/* EXTERNE DEFINITIONEN -----------------------------------------------------*/

{adm/template/incl/dt_viw00.df}


/* LOKALE OBJEKTE -----------------------------------------------------------*/
/* Variable ******************************************************************/
/*   Name               Funktion                                             */
/*   ------------------ ---------------------------------------------------- */
/*   gcSatzart          Hilfsvariable zum Handhaben von Satzart bei Neuanlage*/
/*   glWertposition     Hilfsvariable zum Handhaben von Wertpos bei Neuanlage*/
/*   giLieferant        Hilfsvariable zum Erkennen im loc-display-fields, ob */
/*                      sich der Lieferant ver�ndert hat (f�r Kreditlimit)   */
/*   gdMindestbestellwert Mindestbestellwert beim Lieferanten                */
/*   gcHerk_Belegart    Belegart des Rahmenauftrages                         */
/*   giHerk_ReferenzNr  ReferenzNr des Rahmenauftrages                       */
/*   gdHerk_PositionsNr PositionsNr der Rahmenauftragsposition               */
/*   gcBelegart         Belegart, per initialize aus Attribut                */
/*   gcMRPAreaObj       object ID of mrp area                                */
/*****************************************************************************/

define variable gcSatzart             as character init 'A':U           no-undo.
define variable glWertposition        as logical   init no              no-undo.

define variable giLieferant           as integer                        no-undo.
define variable gdMindestbestellwert  as decimal decimals 3             no-undo.

define variable gcHerk_Belegart       as character init ?               no-undo.
define variable giHerk_ReferenzNr     as integer   init ?               no-undo.
define variable gdHerk_PositionsNr    as decimal decimals 1 init ?      no-undo.

define variable gcBelegart            as character                      no-undo.
define variable gcBereich             as character                      no-undo.

define variable giWaehrungNK          as integer                        no-undo.

define variable ghE_ArtLief           as handle                         no-undo.

define variable glEnableNachAdd       as logical   init yes             no-undo.
define variable glSatzKopiert         as logical   init no              no-undo.
define variable glArchivieren         as logical   init no              no-undo.
define variable glDestroy             as logical   init no              no-undo.
define variable glSlaveMode           as logical   init no              no-undo.
define variable gcMRPAreaObj     like ML_Lagergruppe.ML_Lagergruppe_Obj no-undo.
define variable ghContainer           as handle                         no-undo.
define variable gcSArtKundeObj   like S_ArtKunde.S_ArtKunde_Obj         no-undo.

&IF LOOKUP("U_CI":U,"{&PA-OPTIONEN}":U) > 0 &THEN
&IF LOOKUP("U_WMS":U,"{&PA-OPTIONEN}":U) > 0 &THEN
define variable gluLVSArchivieren     as logical       no-undo.
&ENDIF

&ENDIF
&IF LOOKUP("Q_DEL":U,"{&PA-OPTIONEN}":U) > 0 &THEN
  define variable glUpdateMetals         as logical        no-undo.
&ENDIF

define variable ghContainerSource as handle        no-undo.
define variable ghFocus           as handle        no-undo.

/* Buffer ********************************************************************/

define buffer gbS_Artikel for S_Artikel.
&IF LOOKUP("U_CE":U,"{&PA-OPTIONEN}":U) > 0 &THEN
define buffer gbuUSM_SupplierPONumbers  for USM_SupplierPONumbers.
define buffer gbuE_ArtLief              for E_ArtLief.
&ENDIF /* U_CE */

/* Work-/Temp-Tables *********************************************************/

{eink/incl/e__pfi00.tdf
  &ippNoReferenceOnlySwitch = "yes"
}

/* Dataset *******************************************************************/

&IF lookup("MS":U,"{&PA-MODULE}":U) > 0 &THEN

  {mawi/serie/incl/ms_ser00.pds &ippNoReferenceOnlySwitch = "yes"}

&ENDIF

{info/mawi/incl/im_dlk00.pds &ippNoReferenceOnlySwitch = "YES"}

/* _UIB-CODE-BLOCK-END */
&ANALYZE-RESUME


&ANALYZE-SUSPEND _UIB-PREPROCESSOR-BLOCK

/* ********************  Preprocessor Definitions  ******************** */

&Scoped-define PROCEDURE-TYPE SmartViewer
&Scoped-define DB-AWARE no

&Scoped-define ADM-SUPPORTED-LINKS Record-Source,Record-Target,TableIO-Target

/* Name of designated FRAME-NAME and/or first browse and/or first query */
&Scoped-define FRAME-NAME F-Main

/* External Tables                                                      */
&Scoped-define EXTERNAL-TABLES E_BelegPos E_BelegKopf
&Scoped-define FIRST-EXTERNAL-TABLE E_BelegPos


/* Need to scope the external tables to this procedure                  */
DEFINE QUERY external_tables FOR E_BelegPos, E_BelegKopf.
/* Standard List Definitions                                            */
&Scoped-Define ENABLED-FIELDS E_BelegPos.PositionsNr
&Scoped-define ENABLED-TABLES E_BelegPos
&Scoped-define FIRST-ENABLED-TABLE E_BelegPos
&Scoped-Define DISPLAYED-FIELDS E_BelegPos.PositionsNr ~
E_BelegPos.WertPosition E_BelegPos.Artikel E_BelegPos.TextSchluessel ~
E_BelegPos.ArtVar
&Scoped-define DISPLAYED-TABLES E_BelegPos
&Scoped-define FIRST-DISPLAYED-TABLE E_BelegPos
&Scoped-Define DISPLAYED-OBJECTS gcInfo-1 gdKreditlimit gcWBez-1 ~
BestellNr_var gdSaldo gcWBez-2 gcArtVar gdWarenwert gcWBez-3

/* Custom List Definitions                                              */
/* PA-CREATE-FIELDS,ADM-ASSIGN-FIELDS,List-3,List-4,PA-PROMPT-FIELDS,PA-SEARCH-FIELDS */
&Scoped-define PA-CREATE-FIELDS E_BelegPos.Artikel ~
E_BelegPos.TextSchluessel BestellNr_var E_BelegPos.ArtVar
&Scoped-define ADM-ASSIGN-FIELDS E_BelegPos.PositionsNr ~
E_BelegPos.WertPosition E_BelegPos.Satzart
&Scoped-define PA-SEARCH-FIELDS E_BelegPos.PositionsNr

/* _UIB-PREPROCESSOR-BLOCK-END */
&ANALYZE-RESUME


&ANALYZE-SUSPEND _UIB-CODE-BLOCK _XFTR "Konfiguration" V-table-Win _INLINE
/* Actions: ? adm/support/proc/ds_viw06.w ? ? ? */


&GLOB EXCLUDE-ADM-PRINT yes
/* _UIB-CODE-BLOCK-END */
&ANALYZE-RESUME

&ANALYZE-SUSPEND _UIB-CODE-BLOCK _XFTR "InfoFields" V-table-Win _INLINE
/* Actions: ? adm/support/proc/ds_sma00.w ? ? adm/support/proc/ds_inf01.p */
/* STRUCTURED-DATA
<Build-Information>
1.02
</Build-Information>
<Constants></Constants>
<InfoFields></InfoFields> */

/* _UIB-CODE-BLOCK-END */
&ANALYZE-RESUME

&ANALYZE-SUSPEND _UIB-CODE-BLOCK _XFTR "Dynamic InfoFields" V-table-Win _INLINE
/* Actions: ? ? ? ? adm/support/proc/ds_viw09.p */
/* _UIB-CODE-BLOCK-END */
&ANALYZE-RESUME

&ANALYZE-SUSPEND _UIB-CODE-BLOCK _XFTR "Update Support" V-table-Win _INLINE
/* Actions: ? adm/support/proc/ds_sma00.w ? ? adm/support/proc/ds_viw00.p */
/* STRUCTURED-DATA
<ADDITIONAL-INFORMATION EDITABLE>
E_BelegPos.Herk_PositionsNr = gdHerk_PositionsNr
E_BelegPos.Herk_ReferenzNr = giHerk_ReferenzNr
E_BelegPos.Herk_BelegArt = gcHerk_Belegart
E_BelegPos.Kopierposition = glSatzkopiert
</ADDITIONAL-INFORMATION EDITABLE>

<CONSTANTS>
*****/
&SCOP ENABLED-TABLES E_BelegPos
&SCOP FIRST-ENABLED-TABLE E_BelegPos
&SCOP PA-FIRST-INITIAL-VALUES~
  E_BelegPos.Firma = ~{firma/ebelkop.fir pa-Firma}~
  E_BelegPos.BelegArt = E_BelegKopf.BelegArt~
  E_BelegPos.ReferenzNr = E_BelegKopf.ReferenzNr~
  E_BelegPos.PositionsNr = input frame ~{&Frame-Name} E_BelegPos.PositionsNr~
  E_BelegPos.TextSchluessel = input frame ~{&FRAME-NAME} E_BelegPos.TextSchluessel~
  E_BelegPos.Artikel = input frame ~{&FRAME-NAME} E_BelegPos.Artikel~
  E_BelegPos.ArtVar = input frame ~{&FRAME-NAME} E_BelegPos.ArtVar~
  E_BelegPos.WertPosition = input frame ~{&FRAME-NAME} E_BelegPos.WertPosition~
  E_BelegPos.Satzart = input frame ~{&FRAME-NAME} E_BelegPos.Satzart~
  E_BelegPos.Herk_PositionsNr = gdHerk_PositionsNr~
  E_BelegPos.Herk_ReferenzNr = giHerk_ReferenzNr~
  E_BelegPos.Herk_BelegArt = gcHerk_Belegart~
  E_BelegPos.Kopierposition = glSatzkopiert
&SCOP PA-FIRST-CHECK~
  E_BelegPos.PositionsNr = input frame ~{&Frame-Name} E_BelegPos.PositionsNr
&SCOP PA-FIRST-COMPARE~
  E_BelegPos.Firma = ~{firma/ebelkop.fir pa-Firma}~
  and E_BelegPos.BelegArt = E_BelegKopf.BelegArt~
  and E_BelegPos.ReferenzNr = E_BelegKopf.ReferenzNr~
  and E_BelegPos.PositionsNr = input frame ~{&Frame-Name} E_BelegPos.PositionsNr
&SCOP PA-FIRST-EXCEPT-FIELDS {&PA-FIRST-EXCEPT-FIELDS} Firma BelegArt ReferenzNr PositionsNr TextSchluessel Artikel ArtVar WertPosition Satzart AnlageBenutzer AnlageDatum AnlageZeit AenderungBenutzer AenderungDatum AenderungZeit E_BelegPos_Obj
&SCOP PA-PRIMARY-FIELD E_BelegPos.PositionsNr
/*****
</CONSTANTS> */
/* _UIB-CODE-BLOCK-END */
&ANALYZE-RESUME

&ANALYZE-SUSPEND _UIB-CODE-BLOCK _XFTR "Search Support" V-table-Win _INLINE
/* Actions: ? adm/support/proc/ds_sma00.w ? ? adm/support/proc/ds_viw03.p */
/* STRUCTURED-DATA
<BUILD-INFORMATION>
1.09
basis.E_BelegPos.TextSchluessel,basis.E_BelegPos.Artikel,BestellNr_var,basis.E_BelegPos.ArtVar
basis.E_BelegPos.PositionsNr
</BUILD-INFORMATION>
<STATEMENTS>
*****/
&SCOP PA-SEARCH-ENABLE-STATEMENT~
  enable unless-hidden~
    E_BelegPos.PositionsNr~
      when can-do(pa-supported-sortby,'PositionsNr':U)~
    with frame {&FRAME-NAME}.
&SCOP PA-SEARCH-DISABLE-STATEMENT~
  disable unless-hidden~
    E_BelegPos.PositionsNr~
    with frame {&FRAME-NAME}.
/*****
</STATEMENTS> */
/* _UIB-CODE-BLOCK-END */
&ANALYZE-RESUME

&ANALYZE-SUSPEND _UIB-CODE-BLOCK _XFTR "Foreign Keys" V-table-Win _INLINE
/* Actions: ? adm/support/proc/keyedit.w ? ? ? */
/* STRUCTURED-DATA
<KEY-OBJECT>
THIS-PROCEDURE
</KEY-OBJECT>
<FOREIGN-KEYS>
BelegArt||y|MaWi.E_BelegPos.BelegArt||||||
Lieferant||y|MaWi.E_BelegKopf.Lieferant||||||
Doc_Obj||y|basis.E_BelegPos.E_BelegPos_Obj||||||
Artikel||y|basis.E_BelegPos.Artikel||||||
S_Artikel_Obj||y|basis.gbS_Artikel.S_Artikel_Obj||||||
Herk_Belegart||y|MaWi.E_BelegPos.Herk_Belegart||||||
Herk_ReferenzNr||y|MaWi.E_BelegPos.Herk_ReferenzNr||||||
Herk_PositionsNr||y|MaWi.E_BelegPos.Herk_PositionsNr||||||
Firma||y|MaWi.E_BelegPos.Firma||||||
ReferenzNr||y|MaWi.E_BelegPos.ReferenzNr||||||
PositionsNr||y|MaWi.E_BelegPos.PositionsNr||||||
BelegNummer||y|mawi.E_BelegKopf.BelegNummer||||||
ArtVar||y|MaWi.E_BelegPos.ArtVar||||||
gueltig_ab||y|mawi.E_BelegKopf.Preisgueltigkeit||||||
Waehrung||y|mawi.E_BelegKopf.Waehrung||||||
$KEY||y|MaWi.E_BelegPos|eink/incl/e_belpo.sl|||||
E_BelegPos_Obj||y|MaWi.E_BelegPos.E_BelegPos_Obj||||||
Source_Obj||y|MaWi.E_BelegPos.E_BelegPos_Obj||||||
E_BelegKopf_Obj||y|MaWi.E_BelegKopf.E_BelegKopf_Obj||||||
PosObj||y|basis.E_BelegPos.E_BelegPos_Obj||||||
Coverage_Obj||y|MaWi.E_BelegPos.Coverage_Obj||||||
Origin_Obj||y|basis.E_BelegPos.E_BelegPos_Obj||||||
ML_Lagergruppe_Obj||y|gcMRPAreaObj||||||
S_ArtKunde_Obj||y|gcSArtKundeObj||||||
MMM_CusRefOrder_Obj||y|MaWi.E_BelegPos.MMM_CusRefOrder_Obj||||||
Driver_Obj||y|MaWi.E_BelegPos.Driver_Obj||||||
S_Kostenstelle_Obj||y|MaWi.E_BelegPos.S_Kostenstelle_Obj||||||
Driver_Obj||y|MaWi.E_BelegKopf.Driver_Obj||||||
S_Kostenstelle_Obj||y|MaWi.E_BelegKopf.S_Kostenstelle_Obj||||||
SBM_ProfitCenter_Obj||y|MaWi.E_BelegKopf.SBM_ProfitCenter_Obj||||||
SBM_TaxCase_Obj||y|MaWi.E_BelegKopf.SBM_TaxCase_Obj||||||
SBM_FiscalText_Obj||y|MaWi.E_BelegKopf.SBM_FiscalText_Obj||||||
uCI_Coverage_Obj||y|MaWi.E_BelegPos.uCI_Coverage_Obj||||||
</FOREIGN-KEYS>
<EXECUTING-CODE>
**************************
* Set attributes related to FOREIGN KEYS
*/
run set-attribute-list (
    'Keys-Accepted = ,
     Keys-External = ,
     Keys-Supplied = "BelegArt,Lieferant,Doc_Obj,Artikel,S_Artikel_Obj,Herk_Belegart,Herk_ReferenzNr,Herk_PositionsNr,Firma,ReferenzNr,PositionsNr,BelegNummer,ArtVar,gueltig_ab,Waehrung,$KEY,E_BelegPos_Obj,Source_Obj,E_BelegKopf_Obj,PosObj,Coverage_Obj,Origin_Obj,ML_Lagergruppe_Obj,S_ArtKunde_Obj,MMM_CusRefOrder_Obj,Driver_Obj,S_Kostenstelle_Obj,Driver_Obj,S_Kostenstelle_Obj,SBM_ProfitCenter_Obj,SBM_TaxCase_Obj,SBM_FiscalText_Obj,uCI_Coverage_Obj"':U).
/**************************
</EXECUTING-CODE> */
/* _UIB-CODE-BLOCK-END */
&ANALYZE-RESUME

&ANALYZE-SUSPEND _UIB-CODE-BLOCK _XFTR "InfoTables" V-table-Win _INLINE
/* Actions: ? adm/support/proc/ds_sma00.w ? ? adm/support/proc/ds_tbl01.p */
/* STRUCTURED-DATA
<CONSTANTS></CONSTANTS>
<BUILD-INFORMATION>
1.01
</BUILD-INFORMATION>
<TABLES></TABLES>
<ADDITIONAL-INFORMATION EDITABLE></ADDITIONAL-INFORMATION EDITABLE> */
/* _UIB-CODE-BLOCK-END */
&ANALYZE-RESUME

&ANALYZE-SUSPEND _UIB-CODE-BLOCK _XFTR "Window Title" V-table-Win _INLINE
/* Actions: ? adm/support/proc/ds_sma00.w ? ? adm/support/proc/ds_ttl00.p */
/* STRUCTURED-DATA
<TITLE-CODE EDITABLE>
</TITLE-CODE EDITABLE>
<CONSTANTS></CONSTANTS>  */
/* _UIB-CODE-BLOCK-END */
&ANALYZE-RESUME

&ANALYZE-SUSPEND _UIB-CODE-BLOCK _XFTR "Skin Client Support" V-table-Win _INLINE
/* Actions: ? ? ? ? adm/support/proc/ds_skc00.p */
/* _UIB-CODE-BLOCK-END */
&ANALYZE-RESUME

/* ************************  Function Prototypes ********************** */

&ANALYZE-SUSPEND _UIB-CODE-BLOCK _FUNCTION-FORWARD FelderEnablen V-table-Win
FUNCTION FelderEnablen RETURNS LOGICAL
  ( /* parameter-definitions */ )  FORWARD.

/* _UIB-CODE-BLOCK-END */
&ANALYZE-RESUME

&ANALYZE-SUSPEND _UIB-CODE-BLOCK _FUNCTION-FORWARD lMenuProjekt V-table-Win
FUNCTION lMenuProjekt RETURNS LOGICAL
  ( /* parameter-definitions */ )  FORWARD.

/* _UIB-CODE-BLOCK-END */
&ANALYZE-RESUME


/* ***********************  Control Definitions  ********************** */


/* Definitions of the field level widgets                               */
DEFINE VARIABLE BestellNr_var AS CHARACTER FORMAT "X(30)":U 
     VIEW-AS FILL-IN 
     SIZE 24 BY 1 NO-UNDO.

DEFINE VARIABLE gcArtVar AS CHARACTER FORMAT "X(6)":U 
     VIEW-AS FILL-IN 
     SIZE 12 BY 1 NO-UNDO.

DEFINE VARIABLE gcInfo-1 AS CHARACTER FORMAT "X(256)":U 
     VIEW-AS FILL-IN 
     SIZE 16 BY 1 NO-UNDO.

DEFINE VARIABLE gcWBez-1 AS CHARACTER FORMAT "X(256)":U 
     VIEW-AS FILL-IN 
     SIZE 8 BY 1 NO-UNDO.

DEFINE VARIABLE gcWBez-2 AS CHARACTER FORMAT "X(256)":U 
     VIEW-AS FILL-IN 
     SIZE 8 BY 1 NO-UNDO.

DEFINE VARIABLE gcWBez-3 AS CHARACTER FORMAT "X(256)":U 
     VIEW-AS FILL-IN 
     SIZE 8 BY 1 NO-UNDO.

DEFINE VARIABLE gdKreditlimit AS DECIMAL FORMAT "zz,zzz,zz9.99":U INITIAL 0 
     LABEL "Kreditlimit":R18 
     VIEW-AS FILL-IN 
     SIZE 20 BY 1 NO-UNDO.

DEFINE VARIABLE gdSaldo AS DECIMAL FORMAT "zzz,zzz,zz9.99-":U INITIAL 0 
     LABEL "OP-Saldo":R18 
     VIEW-AS FILL-IN 
     SIZE 20 BY 1 NO-UNDO.

DEFINE VARIABLE gdWarenwert AS DECIMAL FORMAT "zzz,zzz,zz9.99-":U INITIAL 0 
     LABEL "Warenwert":R18 
     VIEW-AS FILL-IN 
     SIZE 20 BY 1 NO-UNDO.

DEFINE IMAGE sDocInfo TRANSPARENT
     SIZE 4 BY 1.

DEFINE IMAGE sTextInfo TRANSPARENT
     SIZE 4 BY 1.


/* ************************  Frame Definitions  *********************** */

DEFINE FRAME F-Main
     E_BelegPos.PositionsNr AT ROW 1 COL 21 COLON-ALIGNED
          VIEW-AS FILL-IN 
          SIZE 8 BY 1
     E_BelegPos.WertPosition AT ROW 1 COL 29 COLON-ALIGNED NO-LABEL
          VIEW-AS FILL-IN 
          SIZE 16 BY 1
     gcInfo-1 AT ROW 1 COL 45 COLON-ALIGNED NO-LABEL
     gdKreditlimit AT ROW 1 COL 88 COLON-ALIGNED
     gcWBez-1 AT ROW 1 COL 108 COLON-ALIGNED NO-LABEL
     E_BelegPos.Artikel AT ROW 2 COL 21 COLON-ALIGNED
          VIEW-AS FILL-IN 
          SIZE 24 BY 1
     E_BelegPos.TextSchluessel AT ROW 2 COL 21 COLON-ALIGNED
          VIEW-AS FILL-IN 
          SIZE 24 BY 1
     BestellNr_var AT ROW 2 COL 45 COLON-ALIGNED NO-LABEL
     gdSaldo AT ROW 2 COL 88 COLON-ALIGNED
     gcWBez-2 AT ROW 2 COL 108 COLON-ALIGNED NO-LABEL
     E_BelegPos.ArtVar AT ROW 3 COL 21 COLON-ALIGNED
          VIEW-AS FILL-IN 
          SIZE 12 BY 1
     gcArtVar AT ROW 3 COL 33 COLON-ALIGNED NO-LABEL
     E_BelegPos.Satzart AT ROW 3 COL 45 COLON-ALIGNED NO-LABEL
          VIEW-AS FILL-IN 
          SIZE 4 BY 1
     gdWarenwert AT ROW 3 COL 88 COLON-ALIGNED DEBLANK
     gcWBez-3 AT ROW 3 COL 108 COLON-ALIGNED NO-LABEL
     sTextInfo AT ROW 1 COL 63
     sDocInfo AT ROW 1 COL 67
    WITH 1 DOWN NO-BOX KEEP-TAB-ORDER OVERLAY
         SIDE-LABELS NO-UNDERLINE THREE-D
         AT COL 1 ROW 1 SCROLLABLE .


/* *********************** Procedure Settings ************************ */

&ANALYZE-SUSPEND _PROCEDURE-SETTINGS
/* Settings for THIS-PROCEDURE
   Type: SmartViewer
   External Tables: MaWi.E_BelegPos,MaWi.E_BelegKopf
   Allow: Basic,DB-Fields
   Frames: 1
   Add Fields to: EXTERNAL-TABLES
   Other Settings: PERSISTENT-ONLY
 */

/* This procedure should always be RUN PERSISTENT.  Report the error,  */
/* then cleanup and return.                                            */
IF NOT THIS-PROCEDURE:PERSISTENT THEN DO:
  MESSAGE "{&FILE-NAME} should only be RUN PERSISTENT.":U
          VIEW-AS ALERT-BOX ERROR BUTTONS OK.
  RETURN.
END.

&ANALYZE-RESUME _END-PROCEDURE-SETTINGS

/* *************************  Create Window  ************************** */

&ANALYZE-SUSPEND _CREATE-WINDOW
/* DESIGN Window definition (used by the UIB)
  CREATE WINDOW V-table-Win ASSIGN
         HEIGHT             = 4.25
         WIDTH              = 119.33.
/* END WINDOW DEFINITION */
                                                                        */
&ANALYZE-RESUME

&ANALYZE-SUSPEND _UIB-CODE-BLOCK _CUSTOM _INCLUDED-LIB V-table-Win 
/* ************************* Included-Libraries *********************** */

{adm/method/incl/dm_viw01.lib}
{eink/incl/e__bel03.lib}
{eink/incl/e__bel06.lib}
{eink/incl/e__buc00.lib}
{basis/text/incl/bt_txt00.lib}

/* _UIB-CODE-BLOCK-END */
&ANALYZE-RESUME




/* ***********  Runtime Attributes and AppBuilder Settings  *********** */

&ANALYZE-SUSPEND _RUN-TIME-ATTRIBUTES
/* SETTINGS FOR WINDOW V-table-Win
  VISIBLE,,RUN-PERSISTENT                                               */
/* SETTINGS FOR FRAME F-Main
   NOT-VISIBLE FRAME-NAME Size-to-Fit                                   */
ASSIGN
       FRAME F-Main:SCROLLABLE       = FALSE
       FRAME F-Main:HIDDEN           = TRUE.

/* SETTINGS FOR FILL-IN E_BelegPos.Artikel IN FRAME F-Main
   NO-ENABLE 1                                                          */
/* SETTINGS FOR FILL-IN E_BelegPos.ArtVar IN FRAME F-Main
   NO-ENABLE 1                                                          */
/* SETTINGS FOR FILL-IN BestellNr_var IN FRAME F-Main
   NO-ENABLE 1                                                          */
/* SETTINGS FOR FILL-IN gcArtVar IN FRAME F-Main
   NO-ENABLE                                                            */
/* SETTINGS FOR FILL-IN gcInfo-1 IN FRAME F-Main
   NO-ENABLE                                                            */
/* SETTINGS FOR FILL-IN gcWBez-1 IN FRAME F-Main
   NO-ENABLE                                                            */
/* SETTINGS FOR FILL-IN gcWBez-2 IN FRAME F-Main
   NO-ENABLE                                                            */
/* SETTINGS FOR FILL-IN gcWBez-3 IN FRAME F-Main
   NO-ENABLE                                                            */
/* SETTINGS FOR FILL-IN gdKreditlimit IN FRAME F-Main
   NO-ENABLE                                                            */
/* SETTINGS FOR FILL-IN gdSaldo IN FRAME F-Main
   NO-ENABLE                                                            */
/* SETTINGS FOR FILL-IN gdWarenwert IN FRAME F-Main
   NO-ENABLE                                                            */
/* SETTINGS FOR FILL-IN E_BelegPos.PositionsNr IN FRAME F-Main
   2 6                                                                  */
/* SETTINGS FOR FILL-IN E_BelegPos.Satzart IN FRAME F-Main
   NO-DISPLAY NO-ENABLE 2                                               */
ASSIGN
       E_BelegPos.Satzart:HIDDEN IN FRAME F-Main           = TRUE.

/* SETTINGS FOR IMAGE sDocInfo IN FRAME F-Main
   NO-ENABLE                                                            */
/* SETTINGS FOR IMAGE sTextInfo IN FRAME F-Main
   NO-ENABLE                                                            */
/* SETTINGS FOR FILL-IN E_BelegPos.TextSchluessel IN FRAME F-Main
   NO-ENABLE 1                                                          */
ASSIGN
       E_BelegPos.TextSchluessel:HIDDEN IN FRAME F-Main           = TRUE.

/* SETTINGS FOR FILL-IN E_BelegPos.WertPosition IN FRAME F-Main
   NO-ENABLE 2                                                          */
/* _RUN-TIME-ATTRIBUTES-END */
&ANALYZE-RESUME


/* Setting information for Queries and Browse Widgets fields            */

&ANALYZE-SUSPEND _QUERY-BLOCK FRAME F-Main
/* Query rebuild information for FRAME F-Main
     _Options          = "NO-LOCK"
     _Query            is NOT OPENED
*/  /* FRAME F-Main */
&ANALYZE-RESUME





/* ************************  Control Triggers  ************************ */

&Scoped-define SELF-NAME E_BelegPos.Artikel
&ANALYZE-SUSPEND _UIB-CODE-BLOCK _CONTROL E_BelegPos.Artikel V-table-Win
ON PAGE-DOWN OF E_BelegPos.Artikel IN FRAME F-Main /* Teil */
DO:

  {adm/template/incl/dt_uit00.if
     &UserExitName = "ON_PAGE-DOWN_OF_E_BelegPos_Artikel"}

  &IF LOOKUP("U_CE":U,"{&PA-OPTIONEN}":U) > 0 &THEN

  {adm/template/incl/dt_viw05.if
    &Richtung   = "next"
    &Tabelle    = "USM_SupplierPONumbers"
    &Feld       = "Part"
    &Index-Name = "Supplier"
    &Selekt     = "where USM_SupplierPONumbers.Company          = ~{firma/e_artli.fir pa-firma~}
                     and USM_SupplierPONumbers.Supplier         = E_BelegKopf.Lieferant
                     and USM_SupplierPONumbers.archived         = no
                     and USM_SupplierPONumbers.StandardPONumber = yes"
    &Var1       = "USM_SupplierPONumbers.PONumber"
    &At1        = "BestellNr_var"
  }

  &ELSE

  {adm/template/incl/dt_viw05.if
    &Richtung   = "next"
    &Tabelle    = "E_ArtLief"
    &Feld       = "Artikel"
    &Index-Name = "Lieferant"
    &Selekt     = "where E_ArtLief.Firma = ~{firma/e_artli.fir pa-firma~}
                     and E_ArtLief.Lieferant = E_BelegKopf.Lieferant"
  }

  &ENDIF /* U_CE */

  run Anzeige-BestellNr/Variante.

  run set-link-attribute in adm-broker-hdl
    (THIS-PROCEDURE,
     'record-target':U,
     'Artikel=':U + quoter(input frame {&frame-name} E_BelegPos.Artikel)).

  run new-state ('neues-Teil,record-target':U).

  {adm/template/incl/dt_uit01.if
     &UserExitName = "ON_PAGE-DOWN_OF_E_BelegPos_Artikel"}
END.

/* _UIB-CODE-BLOCK-END */
&ANALYZE-RESUME


&ANALYZE-SUSPEND _UIB-CODE-BLOCK _CONTROL E_BelegPos.Artikel V-table-Win
ON PAGE-UP OF E_BelegPos.Artikel IN FRAME F-Main /* Teil */
DO:

  {adm/template/incl/dt_uit00.if
     &UserExitName = "ON_PAGE-UP_OF_E_BelegPos_Artikel"}

  &IF LOOKUP("U_CE":U,"{&PA-OPTIONEN}":U) > 0 &THEN

  {adm/template/incl/dt_viw05.if
    &Richtung   = "prev"
    &Tabelle    = "USM_SupplierPONumbers"
    &Feld       = "Part"
    &Index-Name = "Supplier"
    &Selekt     = "where USM_SupplierPONumbers.Company          = ~{firma/e_artli.fir pa-firma~}
                     and USM_SupplierPONumbers.Supplier         = E_BelegKopf.Lieferant
                     and USM_SupplierPONumbers.archived         = no
                     and USM_SupplierPONumbers.StandardPONumber = yes"
    &Var1       = "USM_SupplierPONumbers.PONumber"
    &At1        = "BestellNr_var"
  }

  &ELSE

  {adm/template/incl/dt_viw05.if
    &Richtung   = "prev"
    &Tabelle    = "E_ArtLief"
    &Feld       = "Artikel"
    &Index-Name = "Lieferant"
    &Selekt     = "where E_ArtLief.Firma = ~{firma/e_artli.fir pa-firma~}
                     and E_ArtLief.Lieferant = E_BelegKopf.Lieferant"
  }

  &ENDIF /* U_CE */

  run Anzeige-BestellNr/Variante.

  run set-link-attribute in adm-broker-hdl
    (THIS-PROCEDURE,
     'record-target':U,
     'Artikel=':U + quoter(input frame {&frame-name} E_BelegPos.Artikel)).

  run new-state ('neues-Teil,record-target':U).

  {adm/template/incl/dt_uit01.if
     &UserExitName = "ON_PAGE-UP_OF_E_BelegPos_Artikel"}
END.

/* _UIB-CODE-BLOCK-END */
&ANALYZE-RESUME


&ANALYZE-SUSPEND _UIB-CODE-BLOCK _CONTROL E_BelegPos.Artikel V-table-Win
ON VALUE-CHANGED OF E_BelegPos.Artikel IN FRAME F-Main /* Teil */
DO:
  {adm/template/incl/dt_uit00.if
     &UserExitName = "ON_VALUE-CHANGED_OF_E_BelegPos_Artikel"}

  run Anzeige-BestellNr/Variante.

  {adm/template/incl/dt_uit01.if
     &UserExitName = "ON_VALUE-CHANGED_OF_E_BelegPos_Artikel"}
END.

/* _UIB-CODE-BLOCK-END */
&ANALYZE-RESUME


&Scoped-define SELF-NAME BestellNr_var
&ANALYZE-SUSPEND _UIB-CODE-BLOCK _CONTROL BestellNr_var V-table-Win
ON LEAVE OF BestellNr_var IN FRAME F-Main
DO:

  define buffer E_ArtLief for E_ArtLief.

  {adm/template/incl/dt_uit00.if
     &UserExitName = "ON_LEAVE_OF_BestellNr_var"}

  &IF LOOKUP("U_CE":U,"{&PA-OPTIONEN}":U) > 0 &THEN

  define buffer buUSM_SupplierPONumbers for USM_SupplierPONumbers.

  /* If the PO number has been left via Return, then the corresponding part   */
  /* is entered automatically and the new entry goes on.                      */

  if  ( input frame {&frame-name} BestellNr_var  > '':U
    and gcSatzart                                = 'A':U )
    and not can-find(      USM_SupplierPONumbers
                     where USM_SupplierPONumbers.Company  = {firma/e_artli.fir pACConnectionSvc:prpcCompany}
                       and USM_SupplierPONumbers.Supplier = giLieferant
                       and USM_SupplierPONumbers.Part     = input frame {&FRAME-NAME} E_BelegPos.Artikel
                       and USM_SupplierPONumbers.PONumber = input frame {&FRAME-NAME} BestellNr_var) then
  do:

    find first buUSM_SupplierPONumbers
      where buUSM_SupplierPONumbers.Company           = {firma/e_artli.fir pACConnectionSvc:prpcCompany}
        and buUSM_SupplierPONumbers.Supplier          = giLieferant
        and buUSM_SupplierPONumbers.Part              = input frame {&FRAME-NAME} E_BelegPos.Artikel
        and buUSM_SupplierPONumbers.StandardPONumber  = yes
      no-lock no-error.

    if  (not available buUSM_SupplierPONumbers
      or buUSM_SupplierPONumbers.PONumber <> input frame {&frame-name} BestellNr_var ) then
    uCE_FindUSM_SupplierPONumbers:
    do:

      find first buUSM_SupplierPONumbers
        where buUSM_SupplierPONumbers.Company  = {firma/e_artli.fir pACConnectionSvc:prpcCompany}
          and buUSM_SupplierPONumbers.Supplier = giLieferant
          and buUSM_SupplierPONumbers.PONumber begins input frame {&frame-name} BestellNr_var
          and buUSM_SupplierPONumbers.archived = no
        no-lock no-error.

      if available buUSM_SupplierPONumbers then

        {setwidgetattr
           "E_BelegPos.Artikel"
           "screen-value"
           "buUSM_SupplierPONumbers.Part"
           "in frame {&frame-name}"}.

    end. /* uCE_FindUSM_SupplierPONumbers */

  end. /* BestellNr_var  > '':U ... */

  &ELSE

  /* If the PO number has been left via Return, then the corresponding part   */
  /* is entered automatically and the new entry goes on.                      */

  if    input frame {&frame-name} BestellNr_var  > '':U
    and input frame {&frame-name} BestellNr_var <> BestellNr_var
    and gcSatzart                                = 'A':U then
  do:

    if    E_BelegPos.Artikel:screen-value in frame {&frame-name}  > '':U
      and E_BelegPos.Artikel:screen-value in frame {&frame-name} <> ? then

      find E_ArtLief
        where E_ArtLief.Firma     = {firma/e_artli.fir pa-Firma}
          and E_ArtLief.Lieferant = giLieferant
          and E_ArtLief.Artikel   = E_BelegPos.Artikel:screen-value in frame {&frame-name}
        no-lock no-error.

    if   not available E_ArtLief
      or E_ArtLief.BestellNr <> input frame {&frame-name} BestellNr_var then
    do:

      find first E_ArtLief
        where E_ArtLief.Firma      = {firma/e_artli.fir pa-Firma}
          and E_ArtLief.Lieferant  = giLieferant
          and E_ArtLief.BestellNr  begins input frame {&frame-name} BestellNr_var
          and E_ArtLief.archiviert = no
        use-index Best
        no-lock no-error.

      if not available E_ArtLief then

        find first E_ArtLief
          where E_ArtLief.Firma      = {firma/e_artli.fir pa-Firma}
            and E_ArtLief.Lieferant  = giLieferant
            and E_ArtLief.BestellNr  begins input frame {&frame-name} BestellNr_var
            and E_ArtLief.archiviert = yes
          use-index Best
          no-lock no-error.

      if available E_ArtLief then

        {setwidgetattr
           "E_BelegPos.Artikel"
           "screen-value"
           "E_ArtLief.Artikel"
           "in frame {&frame-name}"}.

    end. /* if not available S_Artikel */

  end. /* if input frame {&frame-name} BestellNr_var */

  &ENDIF /* U_CE */

  {adm/template/incl/dt_uit01.if
     &UserExitName = "ON_LEAVE_OF_BestellNr_var"}
END.

/* _UIB-CODE-BLOCK-END */
&ANALYZE-RESUME


&ANALYZE-SUSPEND _UIB-CODE-BLOCK _CONTROL BestellNr_var V-table-Win
ON PAGE-DOWN OF BestellNr_var IN FRAME F-Main
DO:

  {adm/template/incl/dt_uit00.if
     &UserExitName = "ON_PAGE-DOWN_OF_BestellNr_var"}

  &IF LOOKUP("U_CE":U,"{&PA-OPTIONEN}":U) > 0 &THEN

  {adm/template/incl/dt_viw05.if
    &Richtung   = "next"
    &Tabelle    = "USM_SupplierPONumbers"
    &Feld       = "PONumber"
    &Index-Name = "PONumber"
    &Selekt     = "where USM_SupplierPONumbers.Company  = ~{firma/e_artli.fir pa-firma~}
                     and USM_SupplierPONumbers.Supplier = E_BelegKopf.Lieferant
                     and USM_SupplierPONumbers.archived = no"
    &Var1       = "USM_SupplierPONumbers.Part"
    &At1        = "E_BelegPos.Artikel"    
  }

  &ELSE

  {adm/template/incl/dt_viw05.if
    &Richtung      = "next"
    &Tabelle       = "E_ArtLief"
    &Feld          = "BestellNr"
    &Index-Name    = "Best"
    &Selekt        = "where E_ArtLief.Firma      = ~{firma/e_artli.fir pa-firma~}
                        and E_ArtLief.Lieferant  = E_BelegKopf.Lieferant
                        and E_ArtLief.archiviert = no"
    &Var1          = "E_ArtLief.Artikel"
    &At1           = "E_BelegPos.Artikel"    
  }

  &ENDIF /* U_CE */

  run Anzeige-BestellNr/Variante.

  run set-link-attribute in adm-broker-hdl
    (THIS-PROCEDURE,
     'record-target':U,
     'Artikel=':U + quoter(input frame {&frame-name} E_BelegPos.Artikel)).

  run new-state ('neues-Teil,record-target':U).

  {adm/template/incl/dt_uit01.if
     &UserExitName = "ON_PAGE-DOWN_OF_BestellNr_var"}
END.

/* _UIB-CODE-BLOCK-END */
&ANALYZE-RESUME


&ANALYZE-SUSPEND _UIB-CODE-BLOCK _CONTROL BestellNr_var V-table-Win
ON PAGE-UP OF BestellNr_var IN FRAME F-Main
DO:

  {adm/template/incl/dt_uit00.if
     &UserExitName = "ON_PAGE-UP_OF_BestellNr_var"}

  &IF LOOKUP("U_CE":U,"{&PA-OPTIONEN}":U) > 0 &THEN

  {adm/template/incl/dt_viw05.if
    &Richtung   = "prev"
    &Tabelle    = "USM_SupplierPONumbers"
    &Feld       = "PONumber"
    &Index-Name = "PONumber"
    &Selekt     = "where USM_SupplierPONumbers.Company  = ~{firma/e_artli.fir pa-firma~}
                     and USM_SupplierPONumbers.Supplier = E_BelegKopf.Lieferant
                     and USM_SupplierPONumbers.archived = no"
    &Var1       = "USM_SupplierPONumbers.Part"
    &At1        = "E_BelegPos.Artikel"      
  }

  &ELSE

  {adm/template/incl/dt_viw05.if
    &Richtung      = "prev"
    &Tabelle       = "E_ArtLief"
    &Feld          = "BestellNr"
    &Index-Name    = "Best"
    &Selekt        = "where E_ArtLief.Firma      = ~{firma/e_artli.fir pa-firma~}
                        and E_ArtLief.Lieferant  = E_BelegKopf.Lieferant
                        and E_ArtLief.archiviert = no"
    &Var1          = "E_ArtLief.Artikel"
    &At1           = "E_BelegPos.Artikel"    
  }

  &ENDIF /* U_CE */

  run Anzeige-BestellNr/Variante.

  run set-link-attribute in adm-broker-hdl
    (THIS-PROCEDURE,
     'record-target':U,
     'Artikel=':U + quoter(input frame {&frame-name} E_BelegPos.Artikel)).

  run new-state ('neues-Teil,record-target':U).

  {adm/template/incl/dt_uit01.if
     &UserExitName = "ON_PAGE-UP_OF_BestellNr_var"}
END.

/* _UIB-CODE-BLOCK-END */
&ANALYZE-RESUME


&Scoped-define SELF-NAME E_BelegPos.PositionsNr
&ANALYZE-SUSPEND _UIB-CODE-BLOCK _CONTROL E_BelegPos.PositionsNr V-table-Win
ON RETURN OF E_BelegPos.PositionsNr IN FRAME F-Main /* Position */
DO:

  /* If an existing position was entered, change to update mode. If a new     */
  /* position was entered, create a new value position.                       */

  {adm/template/incl/dt_uit00.if
     &UserExitName = "ON_RETURN_OF_E_BelegPos_PositionsNr"}

  if can-find(first {&ADM-FIRST-ENABLED-TABLE}
                where {&PA-FIRST-COMPARE}) then
    run new-state('TOOLBAR-Update,TableIO-source':U).
  else
    if gcBelegart = 'EBA':U then
      run new-state('TOOLBAR-Value,TableIO-source':U).
    else
      run new-state('TOOLBAR-ADD,TableIO-source':U).

  {adm/template/incl/dt_uit01.if
     &UserExitName = "ON_RETURN_OF_E_BelegPos_PositionsNr"}
END.

/* _UIB-CODE-BLOCK-END */
&ANALYZE-RESUME


&UNDEFINE SELF-NAME

&ANALYZE-SUSPEND _UIB-CODE-BLOCK _CUSTOM _MAIN-BLOCK V-table-Win 


/* ***************************  Main Block  *************************** */

  &IF DEFINED(UIB_IS_RUNNING) <> 0 &THEN
    RUN dispatch IN THIS-PROCEDURE ('initialize':U).
  &ENDIF

  /************************ INTERNAL PROCEDURES ********************/

/* _UIB-CODE-BLOCK-END */
&ANALYZE-RESUME


/* **********************  Internal Procedures  *********************** */

&ANALYZE-SUSPEND _UIB-CODE-BLOCK _PROCEDURE _check-record V-table-Win 
PROCEDURE _check-record :
/*------------------------------------------------------------------------------
  Purpose:     F�hrt die notwendigen Zustandspr�fungen durch
  Parameters:  input pcFunction  auszuf�hrende Funktion (delete,create,update)
  Notes:
------------------------------------------------------------------------------*/

define input parameter pcFunction as char no-undo.

define buffer bS_Artikel for S_Artikel.

/* If the line refers to a Blanket Purchase Order, then the status of the     */
/* part with respect to the category EB was checked yet in the overview       */
/* "Selection Blanket Purchase Order".                                        */

if    pcFunction                       = 'update':U
  and available E_BelegPos
  and E_BelegPos.Satzart               = 'A':U
  and (      E_BelegPos.Herk_BelegArt <> 'ERA':U
       or    E_BelegPos.Herk_BelegArt  = 'ERA':U
         and adm-new-record            = no) then
do:

  find bS_Artikel
    where bS_Artikel.Firma   = {firma/sartikel.fir pa-Firma}
      and bS_Artikel.Artikel = input frame {&frame-name} E_BelegPos.Artikel
    no-lock no-error.

  /* Zustandpr�fungen Teil */

  if available bS_Artikel then
    basis.buro.cls.BBCWorkflowSvc:prpoInstance:showLockStatus
      (bS_Artikel.S_Artikel_Obj,
       gcBereich).

  &IF lookup("Q_DEL":U,"{&PA-OPTIONEN}":U) > 0 &THEN

    stamm.base.cls.SBCMetalSvc:prpoInstance:showMetalLockStatus(E_BelegPos.E_BelegPos_Obj).

  &ENDIF    

end. /* if pcFunction = 'update':U ... */

return.

end procedure.

/* _UIB-CODE-BLOCK-END */
&ANALYZE-RESUME

&ANALYZE-SUSPEND _UIB-CODE-BLOCK _PROCEDURE adm-row-available V-table-Win  adm/support/proc/ds_rec00.p
PROCEDURE adm-row-available :
/* Description ---------------------------------------------------------------*/
/*                                                                            */
/* Dispatched to this procedure when the Record-Source has a new row          */
/* available.  This procedure tries to get the new row (or foreign keys)      */
/* from the  Record-Source and process it.                                    */
/*                                                                            */
/* Parameters ----------------------------------------------------------------*/
/*                                                                            */
/* <none>                                                                     */
/*                                                                            */
/*----------------------------------------------------------------------------*/

/*----------------------------------------------------------------------------*/
/* Processing                                                                 */
/*----------------------------------------------------------------------------*/

/* Define variables needed by this internal procedure.                        */

{adm/template/incl/row-head.i}

/* Create a list of all the tables that we need to get.                       */

{adm/template/incl/row-list.i "E_BelegPos"}
{adm/template/incl/row-list.i "E_BelegKopf"}

/* Get the record ROWID's from the RECORD-SOURCE.                             */

{adm/template/incl/row-get.i}

/* FIND each record specified by the RECORD-SOURCE.                           */

{adm/template/incl/row-find.i "E_BelegPos"}
{adm/template/incl/row-find.i "E_BelegKopf"}

/* Process the newly available records (i.e. display fields, open queries,    */
/* and/or pass records on to any RECORD-TARGETS).                             */

{adm/template/incl/row-end.i}

end procedure. /* adm-row-available */

/* _UIB-CODE-BLOCK-END */
&ANALYZE-RESUME

&ANALYZE-SUSPEND _UIB-CODE-BLOCK _PROCEDURE Anzeige-BestellNr/Variante V-table-Win 
PROCEDURE Anzeige-BestellNr/Variante :
/*------------------------------------------------------------------------------
  Purpose:     Anzeige der BestellNr des Teile-Lieferanten-Beziehung und bei
               Artikeln mit Varianten deren Variante
  Parameters:  <none>
  Notes:
------------------------------------------------------------------------------*/

  if gcSatzart = 'A':U then
  do:

    BestellNr_var = eink.base.cls.EBCSupplierPartSvc:prpoInstance:cGetStdSuppPartNo
                      ((if available E_BelegPos then
                          E_BelegPos.E_BelegPos_Obj
                        else
                          '':U),
                       giLieferant,
                       input frame {&FRAME-NAME} E_BelegPos.Artikel,
                       input frame {&FRAME-NAME} BestellNr_var,
                       pa-add-on-enable).

    {setwidgetattr
       "BestellNr_var"
       "screen-value"
       "BestellNr_var"
       "in frame {&frame-name}"}.

    {fnarg
      pa_cUISvcUpdatePartVariantUI
      "(if    input frame {&frame-name} E_BelegPos.Artikel > '':U then
          stamm.base.cls.SBCPartSvc:prpoInstance:iGetArtVarType(input frame {&frame-name} E_BelegPos.Artikel)
        else
          0),
       input frame {&frame-name} E_BelegPos.ArtVar,
       E_BelegPos.ArtVar:handle in frame {&FRAME-NAME},
       gcArtVar:handle in frame {&FRAME-NAME},
       no,
       pa-add-on-enable"}.

    /* Buffer for part is only as foreign key "S_Artikel_Obj" used            */

    find gbS_Artikel /* code checked by herrmann 21.03.2024 */
      where gbS_Artikel.Firma   = {firma/sartikel.fir pACConnectionSvc:prpcCompany}
        and gbS_Artikel.Artikel = input frame {&FRAME-NAME} E_BelegPos.Artikel
      no-lock no-error.

  end. /* gcSatzart <> 'A':U */
  else
  do:

    {setwidgetattr
       "BestellNr_var"
       "screen-value"
       "'':U"
       "in frame {&frame-name}"}.

    release gbS_Artikel.

  end. /* if gcSatzart = 'A':U then (else) */

end procedure.

/* _UIB-CODE-BLOCK-END */
&ANALYZE-RESUME

&ANALYZE-SUSPEND _UIB-CODE-BLOCK _PROCEDURE checkHedgeContractAsgForReturn V-table-Win 
PROCEDURE checkHedgeContractAsgForReturn :
/* Description ---------------------------------------------------------------*/
/*                                                                            */
/* Check in the case of foreign currency that creating a new part line from   */
/* the stock is not allowed if the return is assigned to a hedge contract     */
/*                                                                            */
/* Notes ---------------------------------------------------------------------*/
/*                                                                            */
/*                                                                            */
/*                                                                            */
/* Parameters ----------------------------------------------------------------*/
/*                                                                            */
/* <none>                                                                     */
/*                                                                            */
/* Examples ------------------------------------------------------------------*/
/*                                                                            */
/*                                                                            */
/*                                                                            */
/*----------------------------------------------------------------------------*/

/* Variables -----------------------------------------------------------------*/
/*----------------------------------------------------------------------------*/

/* Buffers -------------------------------------------------------------------*/

/*----------------------------------------------------------------------------*/
/* Processing                                                                 */
/*----------------------------------------------------------------------------*/

if    E_BelegKopf.Waehrung     > 0
  and E_BelegPos.Belegart      = 'ERL':U
  and E_BelegPos.Satzart       = 'A':U
  and E_BelegPos.Herk_BelegArt = ?
  and stamm.base.cls.SBCHedgeContractSvc:prpoInstance:cHedgeContObjOfDocHead
        (E_BelegKopf.E_BelegKopf_Obj) > '':U then

  adm.method.cls.DMCMessageSvc:prpoInstance:showError
    ('sbhdc00038':U,
     string(E_BelegKopf.Belegnummer),
     string(E_BelegPos.PositionsNr)).

end procedure. /* checkHedgeContractAsgForReturn */

/* _UIB-CODE-BLOCK-END */
&ANALYZE-RESUME

&ANALYZE-SUSPEND _UIB-CODE-BLOCK _PROCEDURE display-BelegInfo V-table-Win 
PROCEDURE display-BelegInfo :
/*------------------------------------------------------------------------------
  Purpose:     Die Beleginformation wird ausgegeben. Dabei wird das Kreditlimit
               bzw. der Warenwert farblich ver�ndert, sofern der Warenwert zu-
               z�glich dem Saldo das Kreditlimit �berschreiten bzw. der Waren-
               wert geringer als der Mindesbestellwert ist
  Parameters:  <none>
  Notes:
------------------------------------------------------------------------------*/

  define variable dWarenwert like E_BelegPos.Warenwert no-undo.

  /* Berechne Belegwarenwert in EW, damit nach Speichern von Position auch der */
  /* Warenwert neu angezeigt wird.                                             */

  if available E_BelegKopf then
  do:

    gdWarenwert = round(E_BelegKopf.Warenwert_offen
                        * {fnarg
                            pa_dCurGetExchangeRate
                            "E_BelegKopf.Firma,
                             E_BelegKopf.Waehrung,
                             E_BelegKopf.BelegDatum,
                             string({&pa_E_Kurs}),
                             E_BelegKopf.Lieferant,
                             E_BelegKopf.E_BelegKopf_Obj"},
                        giWaehrungNK).

    dWarenwert = (if E_BelegKopf.BelegArt = 'EBA':U then
                    - gdWarenwert
                  else
                    gdWarenwert).

  end. /* if available E_BelegKopf */

  if gdWarenwert:hidden in frame {&FRAME-NAME} = no then do:

    if    gdKreditlimit                        > 0
      and gdKreditlimit - gdSaldo - dWarenwert < 0 then

      {fnarg
        pa_lUISvcSetWidgetColor
        "gdKreditlimit:handle in frame {&FRAME-NAME},
         'DM_WarningBGColor,DM_WarningFGColor':U"}.

    else

      {fnarg
        pa_lUISvcSetWidgetColor
        "gdKreditlimit:handle in frame {&FRAME-NAME},
         'DM_DataEntryBGColorDisabled,DM_DataDisplayFGColor':U"}.

    if    can-do ('EB,EAB':U,gcBelegart)
      and gdWarenwert < gdMindestbestellwert then

      {fnarg
        pa_lUISvcSetWidgetColor
        "gdWarenwert:handle in frame {&FRAME-NAME},
         'DM_WarningBGColor,DM_WarningFGColor':U"}.

    else

      {fnarg
        pa_lUISvcSetWidgetColor
        "gdWarenwert:handle in frame {&FRAME-NAME},
         'DM_DataEntryBGColorDisabled,DM_DataDisplayFGColor':U"}.

    assign
      {setwidgetattr
         "gdWarenwert"
         "format"
         "entry(giWaehrungNK + 1,{&pa_WERTGESAMTFORMAT},{&PA-DELIMITER4})"
         "in frame {&frame-name}"}
      {setwidgetattr
         "gdKreditlimit"
         "format"
         "entry(giWaehrungNK + 1,{&pa_WertSummenFormat},{&PA-DELIMITER4})"
         "in frame {&frame-name}"}
      {setwidgetattr
         "gdSaldo"
         "format"
         "entry(giWaehrungNK + 1,{&pa_WertSummenFormat},{&PA-DELIMITER4})"
         "in frame {&frame-name}"}
      gdWarenwert = round (gdWarenwert,giWaehrungNK)
      no-error
      .

    {adm/incl/d__duh00.if
       &Var1     = "gdKreditlimit"
       &Var2     = "gdSaldo"
       &Var3     = "gdWarenwert"
       &WithFrame = "frame {&FRAME-NAME}"
       &NoError  = "yes"}

  end. /* if gdWarenwert:hidden in frame {&FRAME-NAME} = no */
  
  /* --> MO#DWTS-BGi-1105 thongdi_p 19/06/2026 Freigabegrenzen Bestellung */ 
  if gdWarenwert > decimal(adm.config.cls.DCCAppConfigSvc:prpoInstance:cParameterValue('XE_NetPurchase':U)) then
  do:
    {fnarg
        pa_lUISvcSetWidgetColor
        "gdWarenwert:handle in frame {&FRAME-NAME},
         'DM_ColorPool_red_1,DM_DataDisplayFGColor':U"}.   
  end. /* if gdWarenwert > adm.config.cls.DCCAppConfigSvc */
  
  else if gdMindestbestellwert > decimal(adm.config.cls.DCCAppConfigSvc:prpoInstance:cParameterValue('XE_NetPurchase':U)) then
  do:
    {fnarg
        pa_lUISvcSetWidgetColor
        "gdWarenwert:handle in frame {&FRAME-NAME},
         'DM_WarningBGColor,DM_WarningFGColor':U"}.
  end. /* delse if gdMindestbestellwert > adm.config.cls.DCCAppConfigSvc */
    
  /* <-- MO#DWTS-BGi-1105 thongdi_p 19/06/2026 Freigabegrenzen Bestellung */ 
  
  return.

end procedure.

/* _UIB-CODE-BLOCK-END */
&ANALYZE-RESUME

&ANALYZE-SUSPEND _UIB-CODE-BLOCK _PROCEDURE dms-send-wordattributes V-table-Win 
PROCEDURE dms-send-wordattributes :
/* Description ---------------------------------------------------------------*/
/*                                                                            */
/* Build data-fields to create a new Office Document                          */
/*                                                                            */
/* Parameters ----------------------------------------------------------------*/
/*                                                                            */
/* see include o__snd02.if                                                    */
/*                                                                            */
/*----------------------------------------------------------------------------*/

/* Variables -----------------------------------------------------------------*/
/*----------------------------------------------------------------------------*/

&IF LOOKUP("O_":U,"{&PA-MODULE}":U) > 0 &THEN

  define variable c_pkstmp as char init '':U no-undo.

/* Buffers -------------------------------------------------------------------*/

  define buffer bS_Lieferant for S_Lieferant.
  define buffer bS_Adresse   for S_Adresse.

/*----------------------------------------------------------------------------*/
/* Processing                                                                 */
/*----------------------------------------------------------------------------*/

  if available E_BelegPos then
  do:

    find bS_Lieferant
      where bS_Lieferant.Firma     = {firma/sliefera.fir pa-Firma}
        and bS_Lieferant.Lieferant = E_BelegPos.Lieferant
      no-lock no-error.

    if available bS_Lieferant then
    do:

      find bS_Adresse
        where bS_Adresse.Firma    = {firma/s_adres.fir pACConnectionSvc:prpcCompany}
          and bS_Adresse.AdressNr = bS_Lieferant.AdressNr
        no-lock no-error.

      if available bS_Adresse then

        assign
          c_pkstmp = adm.method.cls.DMCParameterStringSvc:cWriteValue
                       ('':U,
                        'Name1':U,
                        bS_Adresse.Name1)
          c_pkstmp = adm.method.cls.DMCParameterStringSvc:cWriteValue
                       (c_pkstmp,
                        'Name2':U,
                        bS_Adresse.Name2)
          c_pkstmp = adm.method.cls.DMCParameterStringSvc:cWriteValue
                       (c_pkstmp,
                        'Strasse':U,
                        bS_Adresse.Strasse)
          c_pkstmp = adm.method.cls.DMCParameterStringSvc:cWriteValue
                       (c_pkstmp,
                        'Ort':U,
                        bS_Adresse.Ort)
          .

    end. /* if available S_Lieferant */
  end. /* if available E_BelegPos */

  {arch/incl/o__snd02.if
    &PKS = "c_pkstmp"
  }

&ENDIF

end procedure.

/* _UIB-CODE-BLOCK-END */
&ANALYZE-RESUME

&ANALYZE-SUSPEND _UIB-CODE-BLOCK _PROCEDURE get-OrderConfLinesAvail V-table-Win 
PROCEDURE get-OrderConfLinesAvail :
/* Description ---------------------------------------------------------------*/
/*                                                                            */
/* Return if exists Order Confirmation lines.                                 */
/*                                                                            */
/* Notes ---------------------------------------------------------------------*/
/*                                                                            */
/*                                                                            */
/*                                                                            */
/* Parameters ----------------------------------------------------------------*/
/*                                                                            */
/* <none>                                                                     */
/*                                                                            */
/* Examples ------------------------------------------------------------------*/
/*                                                                            */
/*                                                                            */
/*                                                                            */
/*----------------------------------------------------------------------------*/

/* Variables -----------------------------------------------------------------*/
/*----------------------------------------------------------------------------*/

/* Buffers -------------------------------------------------------------------*/

/*----------------------------------------------------------------------------*/
/* Processing                                                                 */
/*----------------------------------------------------------------------------*/

if    available E_BelegPos
  and can-find (first E_AB_Pos
    where E_AB_Pos.Firma            = E_BelegPos.Firma
      and E_AB_Pos.Herk_Belegart    = E_BelegPos.Belegart
      and E_AB_Pos.Herk_ReferenzNr  = E_BelegPos.ReferenzNr
      and E_AB_Pos.Herk_PositionsNr = E_BelegPos.PositionsNr) then
  return 'yes':U.
else
  return 'no':U.

end procedure. /* get-OrderConfLinesAvail */

/* _UIB-CODE-BLOCK-END */
&ANALYZE-RESUME

&ANALYZE-SUSPEND _UIB-CODE-BLOCK _PROCEDURE get-PositionArchivable V-table-Win 
PROCEDURE get-PositionArchivable :
/* Description ---------------------------------------------------------------*/
/*                                                                            */
/* Return if the position is archivable.                                      */
/*                                                                            */
/* Notes ---------------------------------------------------------------------*/
/*                                                                            */
/*                                                                            */
/*                                                                            */
/* Parameters ----------------------------------------------------------------*/
/*                                                                            */
/* <none>                                                                     */
/*                                                                            */
/* Examples ------------------------------------------------------------------*/
/*                                                                            */
/*                                                                            */
/*                                                                            */
/*----------------------------------------------------------------------------*/

/* Variables -----------------------------------------------------------------*/

define variable lPurchaseOrder_Archivable as   logical init yes              no-undo.

&IF lookup ("VS_Repair":U,"{&PA-OPTIONEN}":U) > 0 &THEN
  define variable dAdoptableQtyPP         like TD_E_BelegPosBei.Gesamtmenge  no-undo.
&ENDIF.

/*----------------------------------------------------------------------------*/

/* Buffers -------------------------------------------------------------------*/

/*----------------------------------------------------------------------------*/
/* Processing                                                                 */
/*----------------------------------------------------------------------------*/

/* Check if the purchase order was generated from a repair order. It mustn't  */
/* be possible to archive a purchase order line, if there are still adoptable */
/* provided parts.                                                            */

&IF lookup ("VS_Repair":U,"{&PA-OPTIONEN}":U) > 0 &THEN

  if    available E_BelegPos
    and E_BelegPos.BelegArt = 'EB':U
    and eink.base.cls.EBCPurchaseDocSvc:prpoInstance:lIsRepairOrderDocumentLine
          (E_BelegPos.E_BelegPos_Obj) then
  do:

    dAdoptableQtyPP = eink.base.cls.EBCPurchaseDocSvc:prpoInstance:dAdoptableRepairProvPartsToEWE
                        (E_BelegPos.E_BelegPos_Obj).

    lPurchaseOrder_Archivable = dAdoptableQtyPP = 0.

  end. /* if available E_BelegPos */

&ENDIF.

/* the alternative for pa-fields-enabled does not corrupt consistency,        */
/* because in this case the line can not be editable in any other session     */
/* by blocking with error e_bel00053 in e_wbel00.w                            */

if    available E_BelegPos
  and (   pa-fields-enabled
       &IF lookup("E_Intra":U,"{&PA-OPTIONEN}":U) > 0 &THEN
       or (    E_BelegPos.BelegArt = 'ERL':U
           and can-find (first S_IntraHandel
                           where S_IntraHandel.Firma           = E_BelegKopf.Firma
                             and S_IntraHandel.Herk_BelegArt   = E_BelegKopf.BelegArt
                             and S_IntraHandel.Herk_ReferenzNr = E_BelegKopf.ReferenzNr))
       &ENDIF
          )
  and E_BelegPos.Satzart   = 'A':U
  and E_BelegPos.offen     = yes
  and can-do('EB,EAB,ERL':U,E_BelegPos.BelegArt)
  and lPurchaseOrder_Archivable then
  return 'yes':U.
else
  return 'no':U.

end procedure. /* get-PositionArchivable */

/* _UIB-CODE-BLOCK-END */
&ANALYZE-RESUME

&ANALYZE-SUSPEND _UIB-CODE-BLOCK _PROCEDURE get-ProjectSensitive V-table-Win 
PROCEDURE get-ProjectSensitive :
/* Description ---------------------------------------------------------------*/
/*                                                                            */
/* Return if Project is sensitive.                                            */
/*                                                                            */
/* Notes ---------------------------------------------------------------------*/
/*                                                                            */
/*                                                                            */
/*                                                                            */
/* Parameters ----------------------------------------------------------------*/
/*                                                                            */
/* <none>                                                                     */
/*                                                                            */
/* Examples ------------------------------------------------------------------*/
/*                                                                            */
/*                                                                            */
/*                                                                            */
/*----------------------------------------------------------------------------*/

/* Variables -----------------------------------------------------------------*/
/*----------------------------------------------------------------------------*/

/* Buffers -------------------------------------------------------------------*/

/*----------------------------------------------------------------------------*/
/* Processing                                                                 */
/*----------------------------------------------------------------------------*/

return string(lMenuProjekt()).

end procedure. /* get-ProjectSensitive */

/* _UIB-CODE-BLOCK-END */
&ANALYZE-RESUME

&ANALYZE-SUSPEND _UIB-CODE-BLOCK _PROCEDURE LiefereAktuelleBelegArt V-table-Win 
PROCEDURE LiefereAktuelleBelegArt :
/*------------------------------------------------------------------------------
  Purpose:     Die aktuelle Belegart wird zur�ckgegeben
  Parameters:  output pcBelegArt
  Notes:
------------------------------------------------------------------------------*/

  define output parameter pcBelegArt as character no-undo.

  pcBelegArt = gcBelegArt.

end procedure.

/* _UIB-CODE-BLOCK-END */
&ANALYZE-RESUME

&ANALYZE-SUSPEND _UIB-CODE-BLOCK _PROCEDURE local-add-record V-table-Win 
PROCEDURE local-add-record :
/* Description ---------------------------------------------------------------*/
/*                                                                            */
/* Super Override                                                             */
/*                                                                            */
/* Notes ---------------------------------------------------------------------*/
/*                                                                            */
/*                                                                            */
/*                                                                            */
/* Parameters ----------------------------------------------------------------*/
/*                                                                            */
/* <none>                                                                     */
/*                                                                            */
/* Examples ------------------------------------------------------------------*/
/*                                                                            */
/*                                                                            */
/*                                                                            */
/*----------------------------------------------------------------------------*/

/* Variables -----------------------------------------------------------------*/
/*----------------------------------------------------------------------------*/

define variable cPart    like E_BelegPos.Artikel no-undo.
define variable cPartVar like E_BelegPos.ArtVar  no-undo.

/* Buffers -------------------------------------------------------------------*/

/*----------------------------------------------------------------------------*/
/* Processing                                                                 */
/*----------------------------------------------------------------------------*/

/* Code placed here will execute PRIOR to standard behavior. */

/* Assure, that part info would not be taken from previous position. */

if available E_BelegPos then
do:

  release E_BelegPos.

  {setwidgetattr
     "E_BelegPos.Artikel"
     "screen-value"
     "'':U"
     "in frame {&frame-name}"}.

  {setwidgetattr
     "E_BelegPos.ArtVar"
     "screen-value"
     "'':U"
     "in frame {&frame-name}"}.

end. /* if available E_BelegPos */

/* Assure, that page-down starts with the present part. */

release E_ArtLief.

if    available E_BelegKopf
  and can-do('ERL,EBA':U,E_BelegKopf.Belegart)
  and gcSatzart = 'A':U
  and not stamm.base.cls.SBCPostingPeriodSvc:prpoInstance:lPostingPeriodIsOpen
        ({&pa_SB_PostPeriodType_Material},
         E_BelegKopf.Belegdatum) then

  adm.method.cls.DMCMessageSvc:prpoInstance:showError('s_buc00101':U,
                                                      string(E_BelegKopf.Belegdatum,'{&PA_DATEFORMAT}':U)).

if    available wt_E_BelegPos_source
  and wt_E_BelegPos_source.SatzArt <> 'A':U
  and adm.method.cls.DMCMessageSvc:prpoInstance:lShowMessage
        ('e_bel00041':U) then
do:

  {setwidgetattr
     "E_BelegPos.PositionsNr"
     "screen-value"
     "string(wt_E_BelegPos_source.PositionsNr)"
     "in frame {&FRAME-NAME}"}.

  return 'ADM-ERROR':U.

end.

/* Bei Belastungsanzeige wird bei Neuanlage nach bet�tigen des Bearbeiten-    */
/* Buttons automatisch eine neue Wertposition angelegt. Nur sofern der        */
/* Text-Button bet�tigt wurde, werden die Variablen gcSatzart und             */
/* glWertposition nicht ver�ndert.                                            */

glSatzKopiert = no.

if    E_BelegKopf.BelegArt = 'EBA':U
  and gcSatzart           <> 'T':U then
do:

  &IF LOOKUP("S_FORDMNGT":U,"{&PA-OPTIONEN}":U) > 0 &THEN

    /* check in the case of foreign currency that creating a new part line    */
    /* is not allowed if the debit memo is assigned to a hedge contract       */

    if    E_BelegKopf.Waehrung            > 0
      and stamm.base.cls.SBCHedgeContractSvc:prpoInstance:cHedgeContObjOfDocHead
            (E_BelegKopf.E_BelegKopf_Obj) > '':U then

      adm.method.cls.DMCMessageSvc:prpoInstance:showError
        ('sbhdc00038':U,
         string(E_BelegKopf.Belegnummer),
         E_BelegPos.PositionsNr:screen-value in frame {&FRAME-NAME}).

  &ENDIF

  assign
    gcSatzart      = 'A':U
    glWertposition = yes
    .

end. /* if E_BelegKopf.BelegArt = 'EBA':U */

/* If the line should be a copy and the copy template is a value item then    */
/* the new line also should be a value item.                                  */

if    available wt_E_BelegPos_source
  and wt_E_BelegPos_source.SatzArt      = 'A':U
  and wt_E_BelegPos_source.Wertposition = yes then

  assign
    gcSatzart      = 'A':U
    glWertposition = yes
    .

/* Damit Abfrage nach R�cklieferung nicht zweimal kommt */

glEnableNachAdd = yes.

{adm/incl/d__duh00.if
   &Var1     = "glWertposition"
   &At1      = "E_BelegPos.wertposition"
   &WithFrame = "Frame {&FRAME-NAME}"}

{setwidgetattr
   "E_BelegPos.Satzart"
   "screen-value"
   "gcSatzart"
   "in frame {&FRAME-NAME}"}.

{fnarg
  pa_lUISvcSetWidgetHiddenState
  "E_BelegPos.Satzart:handle in frame {&frame-name}, yes"}.

/* Bearbeitung aus der Satzart */

run Satzart-Bearbeitung (gcSatzart).

&IF LOOKUP("U_CE":U,"{&PA-OPTIONEN}":U) > 0 &THEN

  if not pa-add-on-enable then

    assign
      BestellNr_var                                     = '':U
      {setwidgetattr
         "BestellNr_var"
         "screen-value"
         "'':U"
         "in frame {&FRAME-NAME}"}
      .

  else

    assign
      BestellNr_var
      .

  {adm/incl/d__duh00.if
     &Var1     = "BestellNr_var"
     &WithFrame = "frame {&FRAME-NAME}"}

&ENDIF /* U_CE */

assign
  cPart    = input frame {&FRAME-NAME} E_BelegPos.Artikel
  cPartVar = input frame {&FRAME-NAME} E_BelegPos.ArtVar
  .

/* Dispatch standard ADM method.                             */

run dispatch in this-procedure ( 'add-record':U ) .

/* Code placed here will execute AFTER standard behavior.    */

if return-value <> 'ADM-ERROR':U then
do:

  run Anzeige-BestellNr/Variante.

  if    pa-add-on-enable
    and gcSatzart = 'A':U
    and available wt_E_BelegPos_source then
  do:

    {setwidgetattr
       "E_BelegPos.Artikel"
       "screen-value"
       "wt_E_BelegPos_Source.Artikel"
       "in frame {&FRAME-NAME}"}.

    if wt_E_BelegPos_Source.ArtVar <> '':U then
      {setwidgetattr
         "E_BelegPos.ArtVar"
         "screen-value"
         "wt_E_BelegPos_Source.ArtVar"
         "in frame {&FRAME-NAME}"}.

    run dispatch ('enable-fields':U).

    if return-value = 'ADM-ERROR':U then
      return 'ADM-ERROR':U.

  end.

  /*-----------------------------------------------------------------------*/
  /* die Beleginfo wird hier angezeigt, da die Werte durch den add-record  */
  /* mit 0 angezeigt werden.                                               */
  /*                                                                       */
  /* Das  gleiche gilt f�r die Wertposition                                */
  /*-----------------------------------------------------------------------*/

  run display-BelegInfo.

  {adm/incl/d__duh00.if
     &Var1     = "glWertposition"
     &At1      = "E_BelegPos.Wertposition"
     &WithFrame = "Frame {&FRAME-NAME}"}

end. /* if return-value <> 'ADM-ERROR':U */

if    cPart                                        <> '':U
  and input frame {&FRAME-NAME} E_BelegPos.Artikel  = '':U then
do:

  {setwidgetattr
     "E_BelegPos.Artikel"
     "screen-value"
     "cPart"
     "in frame {&frame-name}"}.

  run Anzeige-BestellNr/Variante.

  {setwidgetattr
     "E_BelegPos.ArtVar"
     "screen-value"
     "cPartVar"
     "in frame {&frame-name}"}.

  if valid-handle (ghFocus) then
    run pa_UISvcApplyEventToWidgetByHandle
      ('entry':U,
       ghFocus).

end. /* if cPart <> '':U ... */

&IF LOOKUP("U_CE":U,"{&PA-OPTIONEN}":U) > 0 &THEN

  find gbuUSM_SupplierPONumbers /* code checked by dennler_m 18.04.2018 */
    where gbuUSM_SupplierPONumbers.Company  = {firma/e_artli.fir pACConnectionSvc:prpcCompany}
      and gbuUSM_SupplierPONumbers.Part     = input frame {&FRAME-NAME} E_BelegPos.Artikel
      and gbuUSM_SupplierPONumbers.Supplier = E_BelegKopf.Lieferant
      and gbuUSM_SupplierPONumbers.archived = no
    no-lock no-error.

  if (    not available gbuUSM_SupplierPONumbers
      and ambiguous gbuUSM_SupplierPONumbers 
      and gcSatzart <> 'T':U) then

    adm.method.cls.DMCMessageSvc:prpoInstance:lShowMessage
      ('usspo00007':U,
       input frame {&FRAME-NAME} E_BelegPos.Artikel,
       string(E_BelegKopf.Lieferant)).

&ENDIF /* U_CE */

end procedure.

/* _UIB-CODE-BLOCK-END */
&ANALYZE-RESUME

&ANALYZE-SUSPEND _UIB-CODE-BLOCK _PROCEDURE local-assign-statement V-table-Win 
PROCEDURE local-assign-statement :
/* Description ---------------------------------------------------------------*/
/*                                                                            */
/* Super Override                                                             */
/*                                                                            */
/* Notes ---------------------------------------------------------------------*/
/*                                                                            */
/*                                                                            */
/*                                                                            */
/* Parameters ----------------------------------------------------------------*/
/*                                                                            */
/* <none>                                                                     */
/*                                                                            */
/* Examples ------------------------------------------------------------------*/
/*                                                                            */
/*                                                                            */
/*                                                                            */
/*----------------------------------------------------------------------------*/

/* Variables -----------------------------------------------------------------*/
/* iReferenceNoEBA  reference number of generated debit demo (used as flag)   */
/* iDocNoEBA        document number of generated debit demo  (used in message)*/
/* iNoLinesEBA      number of lines of generated debit demo (used in message) */
/*----------------------------------------------------------------------------*/

define variable lGenerateDebitMemo as   logical                    no-undo.
define variable lAdoptOrderType    as   logical                    no-undo.
define variable iReferenceNoEBA    like E_BelegKopf.ReferenzNr     no-undo.
define variable iDocNoEBA          like E_BelegKopf.Belegnummer    no-undo.
define variable iNoLinesEBA        as   integer                    no-undo.
define variable dWarenwert_offen   like E_BelegPos.Warenwert_offen no-undo.
define variable cQuestionMessage   as   character                  no-undo.

/* Buffers -------------------------------------------------------------------*/

define buffer   bE_BelegPos     for E_BelegPos.
define buffer   bE_BelegKopf-PO for E_BelegKopf.
define buffer   bE_WE_Pos       for E_WE_Pos.
&IF lookup("EB_DESADV":U,"{&PA-OPTIONEN}":U) > 0 &THEN
  define buffer EBT_DeliveryPos for EBT_DeliveryPos.
  define buffer EBT_Delivery    for EBT_Delivery.
  define buffer EBT_DesAdv      for EBT_DesAdv.
&ENDIF

/*----------------------------------------------------------------------------*/
/* Processing                                                                 */
/*----------------------------------------------------------------------------*/

if glArchivieren = yes then
do:

  /* If there exists an open delivery line, the purchase document line may    */
  /* not be archived.                                                         */

  &IF lookup("EB_DESADV":U,"{&PA-OPTIONEN}":U) > 0 &THEN

    find first EBT_DeliveryPos
      where EBT_DeliveryPos.Source_Obj = E_BelegPos.E_BelegPos_Obj
        and EBT_DeliveryPos.offen      = yes
      no-lock no-error.

    if available EBT_DeliveryPos then
    do:

      find EBT_Delivery
        where EBT_Delivery.EBT_Delivery_Obj = EBT_DeliveryPos.EBT_Delivery_Obj
        no-lock.

      find EBT_DesAdv
        where EBT_DesAdv.EBT_DesAdv_Obj = EBT_Delivery.EBT_DesAdv_Obj
        no-lock.

      glArchivieren = no.

      adm.method.cls.DMCMessageSvc:prpoInstance:showError
        ('ebdea00052':U,
         string(E_BelegPos.PositionsNr),
         string(EBT_DesAdv.BelegNummer) + '/':U + EBT_Delivery.LieferscheinNr,
         string(EBT_DeliveryPos.PositionsNr)).

    end. /* if available EBT_DeliveryPos */

  &ENDIF

  &IF LOOKUP("U_CI":U,"{&PA-OPTIONEN}":U) > 0 &THEN
    &IF LOOKUP("U_WMS":U,"{&PA-OPTIONEN}":U) > 0 &THEN
      if not gluLVSArchivieren then
    &ENDIF
  &ENDIF
  if adm.method.cls.DMCMessageSvc:prpoInstance:lShowMessage
       ((if available E_BelegPos
           and E_BelegPos.BelegArt    = 'ERL':U
           and E_BelegPos.SatzArt     = 'A':U
           and E_BelegPos.WareLiefern = no then
           'e_bel00054':U
         else
           'e_bel00039':U),
        string(E_BelegKopf.Belegnummer),
        string(E_BelegPos.PositionsNr)) = no then
  do:

    glArchivieren = no.
    return 'adm-error':U.

  end.

  &IF LOOKUP("U_WMS":U,"{&PA-OPTIONEN}":U) > 0 &THEN
  Archiv:
  do on error undo, return 'adm-error':U:
  &ELSE
  else 
    Archiv: 
    do on error undo, return 'adm-error':U:
  &ENDIF

    if    E_BelegPos.Belegart    = 'ERL':U
      and E_BelegPos.WareLiefern = yes
      and E_BelegPos.Lagerort   <> ?
      and not lSaveRecord(pa-Firma,
                          E_BelegKopf.Belegdatum) then
    do:

      glArchivieren = no.

      return 'ADM-ERROR':U.

    end. /* if    E_BelegPos.Belegart    = 'ERL':U */

    /* offene Restmengen als Fehlmengen verbuchen */

    if    available E_BelegPos
      and can-do('EB,ERL,EAB':U,E_BelegPos.BelegArt)
      and E_BelegPos.Satzart = 'A':U then
    do:

      if E_BelegPos.BelegArt = 'ERL':U then
      do:

        if    E_BelegPos.WareLiefern = no
          and E_BelegPos.KoAuftrag   = no
          and E_BelegPos.Menge       > 0
          /* If the return line is archived ask whether a debit memo should   */
          /* be created, but only, if there does not yet exist one.           */
          and not can-find (first bE_BelegPos
            where bE_BelegPos.Firma            = E_BelegKopf.Firma
              and bE_BelegPos.BelegArt         = 'EBA':U
              and bE_BelegPos.Herk_BelegArt    = E_BelegKopf.BelegArt
              and bE_BelegPos.Herk_ReferenzNr  = E_BelegKopf.ReferenzNr
              and bE_BelegPos.Herk_PositionsNr = E_BelegPos.PositionsNr)
          /* A/P invoice voucher which later will create a debit memo.        */
          and not can-find (first ER_BelegPos
            where ER_BelegPos.Firma             = E_BelegKopf.Firma
              and ER_BelegPos.BelegArt          = 'ERR':U
              and ER_BelegPos.Herk_BelegArt     = 'ERL':U
              and ER_BelegPos.Herk_ReferenzNr   = E_BelegPos.ReferenzNr
              and ER_BelegPos.Herk_PositionsNr  = E_BelegPos.PositionsNr
              and ER_BelegPos.Belastungsanzeige = yes)
          /* Debit memo is forced by excess adoption to A/P invoice voucher.  */
          and not can-find (first ER_BelegPos
            where ER_BelegPos.Firma              = E_BelegKopf.Firma
              and ER_BelegPos.BelegArt           = 'ERR':U
              and ER_BelegPos.WE_ReferenzNr      = E_BelegPos.Herk_ReferenzNr
              and ER_BelegPos.WE_PositionsNr     = E_BelegPos.Herk_PositionsNr
              and ER_BelegPos.Lieferkennzeichen  = 'M':U
              and ER_BelegPos.Belastungsanzeige  = yes) then

          if can-find (E_WE_Pos
            where E_WE_Pos.Firma       = {firma/ebelkop.fir pa-Firma}
              and E_WE_Pos.ReferenzNr  = E_BelegPos.Herk_ReferenzNr
              and E_WE_Pos.PositionsNr = E_BelegPos.Herk_PositionsNr) then

            /* Um zu verhindern, da� nach Abbruch e_bel00054 aufgerufen wird. */

            assign
              glArchivieren = no
              cQuestionMessage = 'e_bel00046':U
              .

          else

            /* Um zu verhindern, da� nach Abbruch e_bel00054 aufgerufen wird. */

            assign
              glArchivieren    = no
              cQuestionMessage = 'e_bel00066':U
              .

        if E_BelegPos.WareLiefern  = yes
          and E_BelegPos.KoAuftrag = no
          and E_BelegPos.FehlMenge <
                E_BelegPos.Menge - E_BelegPos.gelieferte_Menge
          and not can-find (first bE_BelegPos
            where bE_BelegPos.Firma            = E_BelegKopf.Firma
              and bE_BelegPos.BelegArt         = 'EBA':U
              and bE_BelegPos.Herk_BelegArt    = E_BelegKopf.BelegArt
              and bE_BelegPos.Herk_ReferenzNr  = E_BelegKopf.ReferenzNr
              and bE_BelegPos.Herk_PositionsNr = E_BelegPos.PositionsNr)
          and not can-find (first ER_BelegPos
            where ER_BelegPos.Firma             = E_BelegKopf.Firma
              and ER_BelegPos.BelegArt          = 'ERR':U
              and ER_BelegPos.Herk_BelegArt     = 'ERL':U
              and ER_BelegPos.Herk_ReferenzNr   = E_BelegPos.ReferenzNr
              and ER_BelegPos.Herk_PositionsNr  = E_BelegPos.PositionsNr
              and ER_BelegPos.Belastungsanzeige = yes)
          /* Debit memo is forced by excess adoption to A/P invoice voucher.  */
          and not can-find (first ER_BelegPos
            where ER_BelegPos.Firma              = E_BelegKopf.Firma
              and ER_BelegPos.BelegArt           = 'ERR':U
              and ER_BelegPos.WE_ReferenzNr      = E_BelegPos.Herk_ReferenzNr
              and ER_BelegPos.WE_PositionsNr     = E_BelegPos.Herk_PositionsNr
              and ER_BelegPos.Lieferkennzeichen  = 'M':U
              and ER_BelegPos.Belastungsanzeige  = yes) then

          /* Um zu verhindern, da� nach Abbruch e_bel00039 aufgerufen wird. */

          assign
            glArchivieren    = no
            cQuestionMessage = 'e_bel00061':U
            .

        /* A return cannot be archived if generating of a debit memo is not   */
        /* allowed. If the program e_pbla00.w is released and function        */
        /* security for new entries is allowed then ask user for debit memo   */

        if cQuestionMessage > '':U then
          if eink.base.cls.EBCPurchaseDocSvc:prpoInstance:lIsDebitMemoGeneratingAllowed() then
            lGenerateDebitMemo = adm.method.cls.DMCMessageSvc:prpoInstance:lShowMessage
                                   (cQuestionMessage).

          else
            adm.method.cls.DMCMessageSvc:prpoInstance:showError('e_bel00201':U).

        if lGenerateDebitMemo then
        do:

          if E_BelegKopf.Auftragsart > '':U then

            lAdoptOrderType = adm.method.cls.DMCMessageSvc:prpoInstance:lShowMessage
                                ('e_bel00062':U,
                                 E_BelegKopf.Auftragsart).

          /* Check lock level document header for document type EBA (Debit Memo) */

          basis.buro.cls.BBCWorkflowSvc:prpoInstance:showLockStatus
            (E_BelegKopf.E_BelegKopf_Obj,
             'E_EBA':U).

          basis.buro.cls.BBCWorkflowSvc:prpoInstance:showLockStatus
            (S_Lieferant.S_Lieferant_Obj,
            'E_EBA':U).

          eink.base.cls.EBCPurchaseDocSvc:prpoInstance:GenerateDebitMemoOfReturn(input-output iReferenceNoEBA,         /* flag, if a debit memo header is present */
                                                                                 input        E_BelegPos.E_BelegPos_Obj,
                                                                                 input        lAdoptOrderType,
                                                                                       output iDocNoEBA,
                                                                                       output iNoLinesEBA).

          adm.method.cls.DMCMessageSvc:prpoInstance:lShowMessage
           ('e_bel00050':U,
             string(iDocNoEBA),
             string(iNoLinesEBA)).

        end. /* if lGenerateDebitMemo then */

      end. /* if E_BelegPos.BelegArt = 'ERL':U  */

      &IF LOOKUP("Q_AEBW":U,"{&PA-OPTIONEN}":U) > 0 &THEN
        basis.inwb.cls.BOCInwbSvc:prpoInstance:prplOaPArchiveDoc = yes.
      &ENDIF

      assign
        E_BelegPos.FehlMenge = max(0,E_BelegPos.Menge
                                     - E_BelegPos.gelieferte_Menge)
        E_BelegPos.offen     = no
        .

      validate E_BelegPos.

      if E_BelegPos.BelegArt = 'EAB':U then
        eink.base.cls.EBCPODeliveryPlanSvc:prpoInstance:RebuildCoverage
          (E_BelegPos.E_BelegPos_Obj).

      else
        eink.base.cls.EBCPurchaseDocSvc:prpoInstance:RebuildCoverage
          (E_BelegPos.E_BelegPos_Obj).

    end. /* if available E_BelegPos */

  end. /* else Archiv: do on error undo, return 'adm-error':U */

end. /* if glArchivieren = yes */

/* Wurde der Warenwert einer Belastungsanzeige auf eine Rechnungskontrolle  */
/* ver�ndert, so wird diese Wertver�nderung als Belastungskorrektur an die  */
/* Fibu �bergeben. Die Buchungsperiode zum Belegdatum muss in diesem Fall   */
/* noch offen sein.                                                         */

&IF "{&pa_ER_Belastungskorrektur}":U <> "0":U &THEN

  if    E_BelegPos.Belegart      = 'EBA':U
    and E_BelegPos.Herk_Belegart = 'ERR':U
    and glArchivieren            = no
    and adm.config.cls.DCCAppConfigSvc:prpoInstance:lParameterValue('ML_ValueFlowFNA':U) = yes then
  do:

    /* F�llen des Preisfindungstemptables */

    empty temp-table TT_E_PreisFind.

    create TT_E_PreisFind.

    {buffer-copy
       E_BelegKopf
       to TT_E_PreisFind}

    {buffer-copy
       E_BelegPos
       to TT_E_PreisFind}

    &IF LOOKUP("Q_DEL":U,"{&PA-OPTIONEN}":U) > 0 &THEN
      TT_E_PreisFind.Metalsurcharge = (if E_BelegPos.MetalSurchargeChangeable = yes then
                                         E_BelegPos.Metalsurcharge
                                       else
                                         ?).
    &ENDIF

    dWarenwert_offen = eink.base.cls.EBCPurchasePriceSvc:prpoInstance:dLineTotalAmountOpen(buffer TT_E_PreisFind).

    if    dWarenwert_offen <> E_BelegPos.Warenwert_offen
      and not lSaveRecord(pa-Firma,
                          E_BelegKopf.Belegdatum) then

      return 'ADM-ERROR':U.

  end. /* if    E_BelegPos.Belegart      = 'EBA':U */

&ENDIF

&IF LOOKUP("U_CE":U,"{&PA-OPTIONEN}":U) > 0 &THEN

  /* fallback - if no USM_SupplierPONumbers available for pA standard part  */

  if  ( E_BelegPos.Satzart = 'A':U
    and not branche.stamm.cls.USCPartManufacturerSvc:prpoInstance:lIsManufacturerAlternativePart
              (input frame {&FRAME-NAME} E_BelegPos.Artikel)
    and not can-find(first gbuUSM_SupplierPONumbers
                       where gbuUSM_SupplierPONumbers.Company  = {firma/e_artli.fir pACConnectionSvc:prpcCompany}
                         and gbuUSM_SupplierPONumbers.Supplier = E_BelegKopf.Lieferant
                         and gbuUSM_SupplierPONumbers.Part     = input frame {&FRAME-NAME} E_BelegPos.Artikel
                       no-lock) ) then
  do:

    find gbuE_ArtLief
      where gbuE_ArtLief.Firma     = {firma/e_artli.fir pACConnectionSvc:prpcCompany}
        and gbuE_ArtLief.Artikel   = input frame {&FRAME-NAME} E_BelegPos.Artikel
        and gbuE_ArtLief.Lieferant = E_BelegKopf.Lieferant
      no-lock no-error.

    if available gbuE_ArtLief then
    do:

      branche.stamm.cls.USCSupplierPONumbersSvc:prpoInstance:writeUSM_SupplierPONumbersRecord
        (gbuE_ArtLief.E_ArtLief_Obj).

      release gbuE_ArtLief no-error.

    end. /* available gbuE_ArtLief */

  end. /* fallback */

  /* check PO number */

  if (input frame {&FRAME-NAME} BestellNr_var > '':U) then

    branche.stamm.cls.USCSupplierPONumbersSvc:prpoInstance:checkSupplierPONumber
      (E_BelegPos.Satzart,
       input frame {&FRAME-NAME} E_BelegPos.Artikel,
       E_BelegKopf.Lieferant,
       input frame {&FRAME-NAME} BestellNr_var).

&ENDIF /* U_CE */

/* Dispatch standard ADM method.                             */
run dispatch in this-procedure ( 'assign-statement':U ) .

/* Code placed here will execute AFTER standard behavior.    */

if return-value <> 'ADM-ERROR':U then
do:

  run notify ('display-fields,record-target':U).

  // Adopt remit-to address of first stock receipt line from purchase order

  if    E_BelegPos.BelegArt = 'ERL':U
    and can-find (E_BelegPos /* code checked by sy 29.10.2015 'can-find' without 'first' to adopt the address only once. */
                  where E_BelegPos.Firma      = E_BelegKopf.Firma
                    and E_BelegPos.BelegArt   = E_BelegKopf.BelegArt
                    and E_BelegPos.ReferenzNr = E_BelegKopf.ReferenzNr) then

    find bE_WE_Pos
      where bE_WE_Pos.Firma       = E_BelegPos.Firma
        and bE_WE_Pos.ReferenzNr  = E_BelegPos.Herk_ReferenzNr
        and bE_WE_Pos.PositionsNr = E_BelegPos.Herk_PositionsNr
      no-lock no-error.

  if available bE_WE_Pos then
  do:

    find bE_BelegKopf-PO
      where bE_BelegKopf-PO.Firma      = bE_WE_Pos.Firma
        and bE_BelegKopf-PO.BelegArt   = bE_WE_Pos.Herk_BelegArt
        and bE_BelegKopf-PO.ReferenzNr = bE_WE_Pos.Herk_ReferenzNr
      no-lock no-error.

    if    available bE_BelegKopf-PO
      and eink.base.cls.EBCPurchaseDocSvc:prpoInstance:lCopyPurchasingAddress(bE_BelegKopf-PO.E_BelegKopf_Obj,
                                                                              E_BelegKopf.E_BelegKopf_Obj,
                                                                              'P':U) then
      run new-state('RemitToAddressAdopted,container-source':U).

  end. /* if available bE_WE_Pos */

  &IF LOOKUP("U_CE":U,"{&PA-OPTIONEN}":U) > 0 &THEN
  
    assign
      E_BelegPos.uCE_PONumber = BestellNr_var
      .
  
  &ENDIF /* U_CE */

end. /* if return-value <> 'ADM-ERROR':U */

&IF LOOKUP("Q_AEBW":U,"{&PA-OPTIONEN}":U) > 0 &THEN
  finally:

    basis.inwb.cls.BOCInwbSvc:prpoInstance:prplOaPArchiveDoc = no.

  end finally.
&ENDIF

end procedure.

/* _UIB-CODE-BLOCK-END */
&ANALYZE-RESUME

&ANALYZE-SUSPEND _UIB-CODE-BLOCK _PROCEDURE local-cancel-record V-table-Win 
PROCEDURE local-cancel-record :
/* Description ---------------------------------------------------------------*/
/*                                                                            */
/* Super Override                                                             */
/*                                                                            */
/* Notes ---------------------------------------------------------------------*/
/*                                                                            */
/*                                                                            */
/*                                                                            */
/* Parameters ----------------------------------------------------------------*/
/*                                                                            */
/* <none>                                                                     */
/*                                                                            */
/* Examples ------------------------------------------------------------------*/
/*                                                                            */
/*                                                                            */
/*                                                                            */
/*----------------------------------------------------------------------------*/

/* Variables -----------------------------------------------------------------*/
/*----------------------------------------------------------------------------*/

/* Buffers -------------------------------------------------------------------*/

/*----------------------------------------------------------------------------*/
/* Processing                                                                 */
/*----------------------------------------------------------------------------*/

/* Code placed here will execute PRIOR to standard behavior. */

/* Dispatch standard ADM method.                             */
run dispatch in this-procedure ( 'cancel-record':U ) .

/* Code placed here will execute AFTER standard behavior.    */

if return-value <> 'ADM-ERROR':U then
do:

  assign
    gcSatzart      = 'A':U
    glWertposition = no
    .

  {fnarg
    pa_lUISvcSetWidgetHiddenState
    "E_BelegPos.Textschluessel:handle in frame {&frame-name},
     (gcSatzart <> 'T':U)"}.

  &IF LOOKUP("U_CE":U,"{&PA-OPTIONEN}":U) > 0 &THEN

  run Anzeige-BestellNr/Variante.

  &ENDIF

end. /* if return-value <> 'ADM-ERROR':U */

end procedure.

/* _UIB-CODE-BLOCK-END */
&ANALYZE-RESUME

&ANALYZE-SUSPEND _UIB-CODE-BLOCK _PROCEDURE local-copy-source V-table-Win 
PROCEDURE local-copy-source :
/* Description ---------------------------------------------------------------*/
/*                                                                            */
/* Super Override                                                             */
/*                                                                            */
/* Notes ---------------------------------------------------------------------*/
/*                                                                            */
/*                                                                            */
/*                                                                            */
/* Parameters ----------------------------------------------------------------*/
/*                                                                            */
/* <none>                                                                     */
/*                                                                            */
/* Examples ------------------------------------------------------------------*/
/*                                                                            */
/*                                                                            */
/*                                                                            */
/*----------------------------------------------------------------------------*/

/* Variables -----------------------------------------------------------------*/
/*----------------------------------------------------------------------------*/

define variable lRueckgabe      as   logical init yes      no-undo.

/* Buffers -------------------------------------------------------------------*/

define buffer bE_BelegKopf   for E_BelegKopf.
define buffer bE_BelegPos    for E_BelegPos.

/*----------------------------------------------------------------------------*/
/* Processing                                                                 */
/*----------------------------------------------------------------------------*/

if pa-created-records = '':U then
  return.

if gcSatzart <> 'A':U then
  return.

/* Stammsatz kopieren */

if can-do(pa-created-records,'E_BelegPos':U) then
do transaction on error undo, throw:

  find first wt_E_BelegPos_source
    no-error.

  if not available wt_E_BelegPos_source then
    return.

  else
  do:

    if not can-find(first bE_BelegPos
                      where bE_BelegPos.E_BelegPos_Obj = wt_E_BelegPos_source.E_BelegPos_Obj) then

      adm.method.cls.DMCMessageSvc:prpoInstance:showError('v_bel00124':U,
                                                          string(wt_E_BelegPos_source.PositionsNr)).

    find bE_BelegKopf
      where bE_BelegKopf.Firma      = {firma/ebelkop.fir pa-Firma}
        and bE_BelegKopf.BelegArt   = wt_E_BelegPos_source.BelegArt
        and bE_BelegKopf.ReferenzNr = wt_E_BelegPos_source.ReferenzNr
      no-lock.

    if    bE_BelegKopf.Waehrung <> E_BelegKopf.Waehrung
      and adm.method.cls.DMCMessageSvc:prpoInstance:lShowMessage
            ('e_bel00014':U,
             string(bE_BelegKopf.Waehrung),
             {fnarg
               pa_cCurShortDescOfCurrency
               "pa-Firma,
                bE_BelegKopf.Waehrung"},
             string(E_BelegKopf.Waehrung),
             {fnarg
               pa_cCurShortDescOfCurrency
               "pa-Firma,
                E_BelegKopf.Waehrung"}) = no then

      return.

    /* jetzt soll kopiert werden */

    buffer-copy
      wt_E_BelegPos_source
        except
          {&PA-FIRST-EXCEPT-FIELDS}
          offen
          gelieferte_Menge
          Fehlmenge
          Warenwert_offen
          WareLiefern
          Zugangstermin       /* wird im Trigger gesetzt */
          Liefertermin
          SB_Dispo
          Herk_Belegart
          Herk_ReferenzNr
          Herk_PositionsNr
          E_BelegPos_Obj
          {&{&pa-XBasisName}_C_ExceptCopyFields}
          {&{&pa-XBasisName}_U_ExceptCopyFields}
          {&{&pa-XBasisName}_Q_ExceptCopyFields}
          {&{&pa-XBasisName}_ExceptCopyFields}
          {&{&pa-XBasisName}_Y_ExceptCopyFields}
      to E_BelegPos.

    E_BelegPos.Wunschtermin = (if E_BelegKopf.Wunschtermin >= today then
                                 E_BelegKopf.Wunschtermin
                               else
                                 today).

    glSatzKopiert = yes.

    validate E_BelegPos.

    if wt_E_BelegPos_Source.Herk_Belegart <> ? then
    do:

      if wt_E_BelegPos_Source.Herk_Belegart = 'ERA':U then
      do:

        find E_RA_Kopf
          where E_RA_Kopf.Firma      = {firma/ebelkop.fir pa-Firma}
            and E_RA_Kopf.BelegArt   = wt_E_BelegPos_Source.Herk_Belegart
            and E_RA_Kopf.ReferenzNr = wt_E_BelegPos_Source.Herk_ReferenzNr
          no-lock no-error.

        if    available E_RA_Kopf
          and E_RA_Kopf.Waehrung <> E_BelegKopf.Waehrung then

          adm.method.cls.DMCMessageSvc:prpoInstance:lShowMessage
            ('e_bel00025':U,
             string(E_RA_Kopf.Belegnummer),
             string(wt_E_BelegPos_source.PositionsNr),
             {fnarg
               pa_cCurShortDescOfCurrency
               "pa-Firma,
                E_RA_Kopf.Waehrung"}).

        else
          assign
            E_BelegPos.Herk_BelegArt    = wt_E_BelegPos_source.Herk_BelegArt
            E_BelegPos.Herk_ReferenzNr  = wt_E_BelegPos_source.Herk_ReferenzNr
            E_BelegPos.Herk_PositionsNr = wt_E_BelegPos_source.Herk_PositionsNr
            .

      end. /* if wt_E_BelegPos_Source.Herk_BelegArt = 'ERA':U */

      lRueckgabe = no.

      if wt_E_BelegPos_Source.Herk_Belegart = 'EAA':U then
      do:

        find EA_AnfKopf
          where EA_AnfKopf.Firma      = {firma/ebelkop.fir pa-Firma}
            and EA_AnfKopf.ReferenzNr = wt_E_BelegPos_Source.Herk_ReferenzNr
          no-lock no-error.

        if available EA_AnfKopf then

          lRueckgabe = adm.method.cls.DMCMessageSvc:prpoInstance:lShowMessage
                         ('e_bel00004':U,
                          string(EA_AnfKopf.Belegnummer),
                          string(wt_E_BelegPos_source.PositionsNr)).

      end. /* if wt_E_BelegPos_Source.Herk_Belegart = 'EAA':U */

      if lRueckgabe then
        assign
          E_BelegPos.Herk_BelegArt    = wt_E_BelegPos_source.Herk_BelegArt
          E_BelegPos.Herk_ReferenzNr  = wt_E_BelegPos_source.Herk_ReferenzNr
          E_BelegPos.Herk_PositionsNr = wt_E_BelegPos_source.Herk_PositionsNr
          .

    end. /* if wt_E_BelegPos_Source.Herk_Belegart <> ? */

    /* f�r die neu entstandene und die kopierte Bestellposition darf */
    /* keine Preisfindung mehr stattfinden                           */

    E_BelegPos.KopierPosition = yes.

    if not wt_E_BelegPos_source.KopierPosition then
    do:

      find bE_BelegPos
        where bE_BelegPos.Firma       = wt_E_BelegPos_source.Firma
          and bE_BelegPos.BelegArt    = wt_E_BelegPos_source.BelegArt
          and bE_BelegPos.ReferenzNr  = wt_E_BelegPos_source.ReferenzNr
          and bE_BelegPos.PositionsNr = wt_E_BelegPos_source.PositionsNr
        exclusive-lock no-error.

      if available bE_BelegPos then
        bE_BelegPos.KopierPosition = yes.

    end.

  end. /* available wt_E_BelegPos_source */

  eink.base.cls.EBCPurchaseDocSvc:prpoInstance:copyPurchaseOrderLineDependingData
    (wt_E_BelegPos_source.E_BelegPos_Obj,
     bE_BelegKopf.E_BelegKopf_Obj,
     E_BelegPos.E_BelegPos_Obj,
     E_BelegKopf.E_BelegKopf_Obj).

  catch oError as Progress.Lang.Error:

    (new adm.method.cls.DMCErrorMessageErr(oError)):displayProgressErrorsOnly().

    run dispatch('deselect-copy-source':U).

    if return-value <> 'ADM-ERROR':U then

      adm.method.cls.DMCMessageSvc:prpoInstance:showError('e_bel00186':U).

  end catch.

end. /* if can-do(pa-created-records ...) */

end procedure.

/* _UIB-CODE-BLOCK-END */
&ANALYZE-RESUME

&ANALYZE-SUSPEND _UIB-CODE-BLOCK _PROCEDURE local-create-record V-table-Win 
PROCEDURE local-create-record :
/* Description ---------------------------------------------------------------*/
/*                                                                            */
/* Super Override                                                             */
/*                                                                            */
/* Notes ---------------------------------------------------------------------*/
/*                                                                            */
/*                                                                            */
/*                                                                            */
/* Parameters ----------------------------------------------------------------*/
/*                                                                            */
/* <none>                                                                     */
/*                                                                            */
/* Examples ------------------------------------------------------------------*/
/*                                                                            */
/*                                                                            */
/*                                                                            */
/*----------------------------------------------------------------------------*/

/* Variables -----------------------------------------------------------------*/
/*----------------------------------------------------------------------------*/

define variable tGueltigkeit as date      no-undo.
&IF lookup("Q_DEL":U,"{&PA-OPTIONEN}":U) > 0 &THEN
  define variable lRecordNotAvailable as logical       no-undo.
&ENDIF

/* Buffers -------------------------------------------------------------------*/

define buffer bS_Artikel for S_Artikel.

/*----------------------------------------------------------------------------*/
/* Processing                                                                 */
/*----------------------------------------------------------------------------*/

/* Code placed here will execute PRIOR to standard behavior. */

&IF DEFINED(PA-EXTERNAL-KEYS) > 0 &THEN
  run load-external-keys in this-procedure no-error.
  if error-status:error then
    return 'ADM-ERROR':U.

&ENDIF

&IF lookup("Q_DEL":U,"{&PA-OPTIONEN}":U) > 0 &THEN

  lRecordNotAvailable = not can-find(first {&ADM-FIRST-ENABLED-TABLE}
                                     where {&PA-FIRST-COMPARE}).

&ENDIF

/* Pr�fungen auf Teileart/Artikel nur bei Satzart 'A' */

if gcSatzart = 'A':U then
do:

  if BestellNr_var:screen-value in frame {&frame-name} > '':U then

    apply 'leave':U to BestellNr_var in frame {&frame-name}.

  find bS_Artikel
    where bS_Artikel.Firma   = {firma/sartikel.fir pa-Firma}
      and bS_Artikel.Artikel = input frame {&frame-name} E_BelegPos.Artikel
    no-lock no-error.

  if not available bS_Artikel then

    adm.method.cls.DMCMessageSvc:prpoInstance:showError
      ('s_art00002':U,
       input frame {&frame-name} E_BelegPos.Artikel).

  else if can-do({&pa_S_PTList_VariantPartTypes},string(bS_Artikel.ArtikelArt)) then

    adm.method.cls.DMCMessageSvc:prpoInstance:showError
      ('e_bel00030':U,
       input frame {&frame-name} E_BelegPos.Artikel).

  else if bS_Artikel.archiviert = yes
    and can-do('ERL,EBA':U,E_BelegKopf.BelegArt)
    and adm.method.cls.DMCMessageSvc:prpoInstance:lShowMessage
          ('v_trg00101':U,
           input frame {&frame-name} E_BelegPos.Artikel) = no then

    return 'ADM-ERROR':U.

end. /* if gcSatzart = 'A':U */

/* Datensatz noch nicht vorhanden */

if not can-find(first {&ADM-FIRST-ENABLED-TABLE}
                where {&PA-FIRST-COMPARE}) then
do:

  /* Pr�fe, ob Kopiervorlage ausgew�hlt */

  find first wt_E_BelegPos_source
    no-error.

  if    glWertposition = no
    and gcSatzart = 'A':U
    and can-do('EB,EAB':U,E_BelegKopf.Belegart) then
  do:

    /* Inform the trigger that it is a copied line, in order to attribute     */
    /* only provided parts of the source line.                                */

    if available wt_E_BelegPos_source then

      glSatzKopiert = yes.

    else
    do:

      assign
        gcHerk_BelegArt    = ?
        giHerk_ReferenzNr  = ?
        gdHerk_PositionsNr = ?
        tGueltigkeit       = (if adm.config.cls.DCCAppConfigSvc:prpoInstance:lParameterValue
                                   ('EB_BlanketPurOrderToPriceValidity':U) = yes then
                                E_BelegKopf.Preisgueltigkeit
                              else
                                E_BelegKopf.BelegDatum)
        .

      find E_RA_Pos     /* Code checked by wl 04.06.2003 */
        where E_RA_Pos.Firma     = {firma/ebelkop.fir pa-firma}
          and E_RA_Pos.Belegart  = 'ERA':U
          and E_RA_Pos.offen     = yes
          and E_RA_Pos.Lieferant = E_BelegKopf.Lieferant
          and E_RA_Pos.Artikel   = input frame {&frame-name} E_BelegPos.Artikel
          and E_RA_Pos.ArtVar    = input frame {&frame-name} E_BelegPos.ArtVar
          and can-find(E_RA_Kopf of E_RA_Pos
                       where E_RA_Kopf.gueltig_ab <= tGueltigkeit
                         and (E_RA_Kopf.gueltig_bis = ?
                              or E_RA_Kopf.gueltig_bis >= tGueltigkeit)
                         and E_RA_Kopf.Waehrung = E_BelegKopf.Waehrung)
        no-lock no-error.

      /* gibt es einen oder mehrere in Frage kommenden Rahmenauftr�ge, so �bersicht */

      if   ambiguous E_RA_Pos
        or available E_RA_Pos then
        run eink/proc/e_urah02.w (E_BelegKopf.Firma,
                                  E_BelegKopf.Lieferant,
                                  tGueltigkeit,
                                  E_BelegKopf.Waehrung,
                                  input frame {&frame-name} E_BelegPos.Artikel,
                                  input frame {&frame-name} E_BelegPos.ArtVar,
                                  'E_':U + E_BelegKopf.BelegArt,
                                  no,
                                  input-output gcHerk_Belegart,
                                  input-output giHerk_ReferenzNr,
                                  input-output gdHerk_PositionsNr).

    end. /* else do: */

  end. /* if glWertposition = no ... */

  if    gcSatzart = 'A':U
    and not can-find (E_ArtLief
      where E_ArtLief.Firma     = {firma/e_artli.fir pa-Firma}
        and E_ArtLief.Lieferant = E_BelegKopf.Lieferant
        and E_ArtLief.Artikel   = input frame {&frame-name} E_BelegPos.Artikel)
    and adm.method.cls.DMCMessageSvc:prpoInstance:lShowMessage
          ('e_bel00124':U,
           input frame {&frame-name} E_BelegPos.Artikel,
           string(E_BelegKopf.Lieferant)) = yes then
  do:

  /* If either part-supplier or supplier-part are not allowed, then           */
  /* E_ArtLief may not be created via new documents.                          */

  if    basis.user.cls.BUCFunctionSecuritySvc:prpoInstance:lCheckFunctionSecurityForInstance
          ('e_pali00.w':U,
           'create':U,
           pACConnectionSvc:prpcUserID,
           pACConnectionSvc:prpcCompany) = yes
    and basis.user.cls.BUCFunctionSecuritySvc:prpoInstance:lCheckFunctionSecurityForInstance
          ('e_pali01.w':U,
           'create':U,
           pACConnectionSvc:prpcUserID,
           pACConnectionSvc:prpcCompany) = yes then
    do:

      create E_ArtLief.

      assign
        E_ArtLief.Firma     = {firma/e_artli.fir pa-Firma}
        E_ArtLief.Artikel   = input frame {&frame-name} E_BelegPos.Artikel
        E_ArtLief.Lieferant = E_BelegKopf.Lieferant
        .

      validate E_ArtLief.

      /* weitere Initialisierungen erfolgen im Schreibtrigger */

    end.
    else

      adm.method.cls.DMCMessageSvc:prpoInstance:showError
        ('e_bel00128':U).

  end. /* if gcSatzart = 'A':U and not can-find (E_ArtLief ... */

  if gcSatzart <> 'T':U then
    {setwidgetattr
       "E_BelegPos.TextSchluessel"
       "screen-value"
       "'':U"
       "in frame {&FRAME-NAME}"}.

  &IF LOOKUP("U_CE":U,"{&PA-OPTIONEN}":U) > 0 &THEN

  /* check PO number */

  if (input frame {&FRAME-NAME} BestellNr_var > '':U) then

    branche.stamm.cls.USCSupplierPONumbersSvc:prpoInstance:checkSupplierPONumber
      (gcSatzart,
       input frame {&FRAME-NAME} E_BelegPos.Artikel,
       E_BelegKopf.Lieferant,
       input frame {&FRAME-NAME} BestellNr_var).

  &ENDIF /* U_CE */

end. /* Datensatz besteht noch nicht und Neuanlagebutton wurde gedr�ckt */

ghFocus = {focus}.

/* Dispatch standard ADM method.                             */

run dispatch in this-procedure ( 'create-record':U ) .

/* Code placed here will execute AFTER standard behavior.    */

if return-value <> 'ADM-ERROR':U then
do:

  &IF lookup("Q_DEL":U,"{&PA-OPTIONEN}":U) > 0 &THEN

    /* Select metal agreement position                                        */
    /* Start only if blanket purchase agreement is not selected               */

    if    can-do('EAB,EB':U, gcBelegart)
      and gcSatzart           = 'A':U
      and gcHerk_Belegart     = ?
      and lRecordNotAvailable = yes then
      stamm.base.cls.SBCMetalSvc:prpoInstance:selectMetalAgreementPosForAdoption
        (E_BelegPos.E_BelegPos_Obj).    

  &ENDIF

  /* Zur�cksetzen der Herkunftsreferenz */

  assign
    gcHerk_Belegart    = ?
    giHerk_ReferenzNr  = ?
    gdHerk_PositionsNr = ?
    .

end. /* if return-value <> 'ADM-ERROR':U then */    

end procedure.

/* _UIB-CODE-BLOCK-END */
&ANALYZE-RESUME

&ANALYZE-SUSPEND _UIB-CODE-BLOCK _PROCEDURE local-delete-record V-table-Win 
PROCEDURE local-delete-record :
/* Description ---------------------------------------------------------------*/
/*                                                                            */
/* Super Override                                                             */
/*                                                                            */
/* Notes ---------------------------------------------------------------------*/
/*                                                                            */
/*                                                                            */
/*                                                                            */
/* Parameters ----------------------------------------------------------------*/
/*                                                                            */
/* <none>                                                                     */
/*                                                                            */
/* Examples ------------------------------------------------------------------*/
/*                                                                            */
/*                                                                            */
/*                                                                            */
/*----------------------------------------------------------------------------*/

/* Variables -----------------------------------------------------------------*/
/*----------------------------------------------------------------------------*/

&IF LOOKUP("Q_SVPSUP":U,"{&PA-OPTIONEN}":U) > 0 &THEN 

  define variable cOriginObjSuppCall        like EBT_SupplierCallLine.Origin_Obj     no-undo.
  define variable cOwningObjSuppCall        like EBT_SupplierCallHandLine.Owning_Obj no-undo.
  define variable cOwningTableSuppCall      as   character                           no-undo.
  define variable lisPostCodeRLZ            as   logical                             no-undo. 

&ENDIF

/* Buffers -------------------------------------------------------------------*/

define buffer bML_Ort     for ML_Ort.
define buffer bS_Artikel  for S_Artikel.

&IF lookup("E_ANZ":U,"{&PA-OPTIONEN}":U) > 0 &THEN

  define buffer bER_BelegKopf for ER_BelegKopf.
  define buffer bER_BelegPos  for ER_BelegPos.

&ENDIF

/*----------------------------------------------------------------------------*/
/* Processing                                                                 */
/*----------------------------------------------------------------------------*/

/* Code placed here will execute PRIOR to standard behavior. */

if available E_BelegKopf then
do:

  /* For running showLockStatus in header and to check workflow event 80      */
  /* (save or cancel) the document header must be in update mode first.       */

  if valid-handle(ghContainerSource) then
  do:

    run new-state in ghContainerSource('toolbar-update,container-target':U).                     

    run get-ContainerInUpdate in ghContainerSource.

    if return-value = 'no':U then
      return 'ADM-ERROR':U.

  end. /* if valid-handle(ghContainerSource)then */

  &IF lookup("M_Pack-Plus":U,"{&PA-OPTIONEN}":U) > 0 &THEN

    if    E_BelegKopf.Belegart = 'ERL':U
      and E_BelegPos.Satzart   = 'A':U then

      if mawi.base.cls.MMCPackagingSvc:prpoInstance:lDocHasPackageMovement(E_BelegPos.E_BelegPos_Obj) then

        adm.method.cls.DMCMessageSvc:prpoInstance:showError('mmpac000047':U).

  &ENDIF

  /* If the line to delete is currently selected for copy */

  if    available wt_E_BelegPos_source
    and wt_E_BelegPos_source.PositionsNr = E_BelegPos.PositionsNr then

    run dispatch('deselect-copy-source':U).

  if return-value <> 'ADM-ERROR':U then
  do:

    /* In case the document has already been send by INWB or EDI a deletion of*/
    /* the document should always be considered carefully. Show a message for */
    /* that case.                                                             */

    if     stamm.base.cls.SBCBusProcTransmissionSvc:prpoInstance:iGetTransmissionState
             (E_BelegKopf.E_BelegKopf_Obj) = {&pa_SB_TransState_transmitted}
       and not adm.method.cls.DMCMessageSvc:prpoInstance:lShowMessage
                 ('sbinw00004':U,
                  string(E_BelegKopf.BelegNummer)) then

      return 'adm-error':U.  

    &IF "{&pa_ER_Belastungskorrektur}":U = "2":U &THEN

      if    E_BelegPos.Belegart      = 'EBA':U
        and E_BelegPos.Herk_Belegart = 'ERR':U
        and E_BelegPos.Satzart       = 'A':U
        and not stamm.base.cls.SBCPostingPeriodSvc:prpoInstance:lPostingPeriodIsOpen
                   ({&pa_SB_PostPeriodType_Material},
                    E_BelegKopf.Belegdatum)
        and mawi.base.cls.MMCPostingSvc:prpoInstance:lAskContinuePosting(E_BelegKopf.Belegdatum) = no then

        return 'ADM-ERROR':U.

    &ENDIF /* &IF "{&pa_ER_Belastungskorrektur}":U = "2":U */

    if    E_BelegKopf.Belegart = 'ERL':U
      and E_BelegPos.Satzart   = 'A':U then
    do:

      if    not stamm.base.cls.SBCPostingPeriodSvc:prpoInstance:lPostingPeriodIsOpen
              ({&pa_SB_PostPeriodType_Material},
               E_BelegKopf.Belegdatum)
        and mawi.base.cls.MMCPostingSvc:prpoInstance:lAskContinuePosting(E_BelegKopf.Belegdatum) = no then

        return 'ADM-ERROR':U.

      if E_BelegPos.LagerOrt <> ? then
      do:

        &IF lookup ("M_Pack":U,"{&PA-OPTIONEN}":U) > 0 &THEN

          /* Delete packaging. Returns must be handeled here, because the record  */
          /* which is about to be deleted is still needed in m_ltposd.p in order  */
          /* to post back packaging. There it would not found if deletion would   */
          /* happen in the delete trigger of E_BelegPos.                          */

          run mawi/proc/m_vpmi04.p(E_BelegPos.Firma,
                                   'E':U,
                                   {&pa_MM_PackagingDelivery}, /* Function Code 4 */
                                   '':U,
                                   '':U,
                                   E_BelegPos.Belegart,
                                   E_BelegKopf.E_BelegKopf_Obj,
                                   E_BelegPos.Belegart,
                                   E_BelegPos.E_BelegPos_Obj,
                                   E_BelegPos.offen).

        &ENDIF /* &IF lookup ("M_Pack":U,"{&PA-OPTIONEN}":U) > 0 &THEN */

        find bML_Ort
          where bML_Ort.Firma    = {firma/mlort.fir pa-Firma}
            and bML_Ort.Lagerort = E_BelegPos.LagerOrt
          no-lock.

        find bS_Artikel
          where bS_Artikel.Firma   = {firma/sartikel.fir pa-Firma}
            and bS_Artikel.Artikel = E_BelegPos.Artikel
          no-lock.

        /* Reservate the return quantity */
        if not can-do({&pa_M_PTList_PackagingReturnable}, string(bS_Artikel.ArtikelArt)) then
        do:

          &IF LOOKUP("Q_SVPSUP":U,"{&PA-OPTIONEN}":U) > 0 &THEN

            if E_BelegPos.Herk_BelegArt = 'ESC':U then
            do:

              assign         
                cOwningObjSuppCall   = eink.base.cls.EBCSupCallSvc:prpoInstance:cSuppCallHandLineOwningObj(E_BelegPos.E_BelegPos_Obj)
                cOriginObjSuppCall   = eink.base.cls.EBCSupCallSvc:prpoInstance:cGetOriginObjFromSupCallLine(cOwningObjSuppCall)
                cOwningTableSuppCall = adm.method.cls.DMCSessionSvc:cOwningTable(cOriginObjSuppCall)
                .

              /* To select the correct posting code when the origin document is a supplier call, it must */
              /* be checked if the supplier call also has a predecessor document and whether this is a   */ 
              /* stock receipt.                                                                          */ 
              /* Limitation to stock receipt because a return without a supplier call as predecessor can */
              /* have a stock receipt as origin document or no origin document => .Herk_Belegart is ?    */
              /* This is important to determine the correct posting code                                 */

              lisPostCodeRLZ = (if cOwningTableSuppCall  <> 'E_WE_Pos':U then
                                   eink.base.cls.EBCSupCallSvc:prpoInstance:lisPostingCodeRLZ
                                     (E_BelegPos.WareLiefern)   
                                 else
                                   no).  

            end. /* if E_BelegPos.Herk_BelegArt = 'ESC':U */   

          &ENDIF

          mawi.base.cls.MMCReservationSvc:prpoInstance:deleteDocumentPosSilent
            (E_BelegPos.E_BelegPos_Obj,             /* Origin                 */  
             bS_Artikel.S_Artikel_Obj,              /* Object-ID Part         */
             bML_Ort.ML_Ort_Obj,                    /* Object-ID Storage Area */
             (if    E_BelegPos.Herk_Belegart   = ?  /* PostingCode            */  
                and E_BelegPos.WareLiefern     = no
                and bML_Ort.StorageType       <> {&pa_ML_ExternalOwnedStorArea}
                &IF LOOKUP("Q_SVPSUP":U,"{&PA-OPTIONEN}":U) > 0 &THEN
                  or (    lisPostCodeRLZ
                      and bML_Ort.StorageType <> {&pa_ML_ExternalOwnedStorArea}) 
                &ENDIF then
                'RLZ':U
              else
                'ERL':U)) no-error.                    /* Option              */

          if error-status:error then

            return 'ADM-ERROR':U.

      end. /* if not can-do({&pa_M_PTList_PackagingReturnable}, string(bS_Artikel.ArtikelArt)) */

    end. /* if E_BelegPos.LagerOrt <> ? then */

  end. /* if E_BelegPos.Belegart  = 'ERL':U */

    &IF lookup("E_ANZ":U,"{&PA-OPTIONEN}":U) > 0 &THEN

      /* When a following partial payment document line has been created then   */
      /* we warn the user so that he can cancel the deletion.                   */

      find first bER_BelegPos
        where bER_BelegPos.Firma           = E_BelegKopf.Firma
          and bER_BelegPos.BelegArt        = 'ERZ':U
          and bER_BelegPos.Herk_BelegArt   = E_BelegKopf.BelegArt
          and bER_BelegPos.Herk_ReferenzNr = E_BelegKopf.ReferenzNr
        no-lock no-error.

      if available bER_BelegPos then
      do:

        find bER_BelegKopf
          where bER_BelegKopf.Firma      = bER_BelegPos.Firma
            and bER_BelegKopf.BelegArt   = bER_BelegPos.BelegArt
            and bER_BelegKopf.ReferenzNr = bER_BelegPos.ReferenzNr
          no-lock.

        adm.method.cls.DMCMessageSvc:prpoInstance:lShowMessage
          ('e_bel00191':U,
           string(E_BelegKopf.Belegnummer),
           string(E_BelegPos.PositionsNr),
           string(bER_BelegKopf.Belegnummer)).

      end. /* if available bER_BelegPos */

    &ENDIF

  end. /* if return-value <> 'ADM-ERROR':U then */

end. /* if available E_BelegKopf then */

&IF LOOKUP("U_CI":U,"{&PA-OPTIONEN}":U) > 0 &THEN
  &IF LOOKUP("U_WMS","{&PA-OPTIONEN}") > 0 &THEN
    if    not adm-new-record
      and branche.gateway.cls.UGC_CIWarehouseManagementSystem:prpoInstance:lSentToWMS(E_BelegKopf.E_BelegKopf_Obj) then
    do:
  
      /* Es soll keine Meldung beim Archivieren angezeigt werden */
      gluLVSArchivieren = yes.
  
      run paCntrEvt_ArchivePosition.
  
      gluLVSArchivieren = no.
  
      adm.method.cls.DMCMessageSvc:prpoInstance:lShowMessage
        ('ugwms00002':U, string(E_BelegKopf.BelegNummer)).
  
    end.
    else
    do:
  &ENDIF
&ENDIF

    run dispatch in this-procedure ('delete-record':U).

    if    return-value        = 'ADM-ERROR':U
      and available E_BelegPos
      and E_BelegPos.Belegart = 'ERL':U
      and E_BelegPos.Satzart  = 'A':U then

      mawi.base.cls.MMCReservationSvc:prpoInstance:CancelReservation(E_BelegPos.E_BelegPos_Obj).

&IF LOOKUP("U_CI":U,"{&PA-OPTIONEN}":U) > 0 &THEN
  &IF LOOKUP("U_WMS","{&PA-OPTIONEN}") > 0 &THEN
    end.
  &ENDIF
&ENDIF

  /* Since the print identifier has been reset, the display should be         */
  /* refreshed in the document header.                                        */

  run new-state in ghContainerSource('refresh,container-target':U).

end procedure.

/* _UIB-CODE-BLOCK-END */
&ANALYZE-RESUME

&ANALYZE-SUSPEND _UIB-CODE-BLOCK _PROCEDURE local-destroy V-table-Win 
PROCEDURE local-destroy :
/* Description ---------------------------------------------------------------*/
/*                                                                            */
/* Super Override                                                             */
/*                                                                            */
/* Notes ---------------------------------------------------------------------*/
/*                                                                            */
/*                                                                            */
/*                                                                            */
/* Parameters ----------------------------------------------------------------*/
/*                                                                            */
/* <none>                                                                     */
/*                                                                            */
/* Examples ------------------------------------------------------------------*/
/*                                                                            */
/*                                                                            */
/*                                                                            */
/*----------------------------------------------------------------------------*/

/* Variables -----------------------------------------------------------------*/
/*----------------------------------------------------------------------------*/

/* Buffers -------------------------------------------------------------------*/

/*----------------------------------------------------------------------------*/
/* Processing                                                                 */
/*----------------------------------------------------------------------------*/

/* Code placed here will execute PRIOR to standard behavior. */

glDestroy = yes.

/* Dispatch standard ADM method.                             */

run dispatch in this-procedure ( 'destroy':U ) .

/* Code placed here will execute AFTER standard behavior.    */

end procedure.

/* _UIB-CODE-BLOCK-END */
&ANALYZE-RESUME

&ANALYZE-SUSPEND _UIB-CODE-BLOCK _PROCEDURE local-display-fields V-table-Win 
PROCEDURE local-display-fields :
/* Description ---------------------------------------------------------------*/
/*                                                                            */
/* Super Override                                                             */
/*                                                                            */
/* Notes ---------------------------------------------------------------------*/
/*                                                                            */
/*                                                                            */
/*                                                                            */
/* Parameters ----------------------------------------------------------------*/
/*                                                                            */
/* <none>                                                                     */
/*                                                                            */
/* Examples ------------------------------------------------------------------*/
/*                                                                            */
/*                                                                            */
/*                                                                            */
/*----------------------------------------------------------------------------*/

/* Variables -----------------------------------------------------------------*/
/*----------------------------------------------------------------------------*/

/* Buffers -------------------------------------------------------------------*/

/*----------------------------------------------------------------------------*/
/* Processing                                                                 */
/*----------------------------------------------------------------------------*/

/* Code placed here will execute PRIOR to standard behavior. */

if available E_BelegKopf then
do:

  /* Lieferant hat sich ge�ndert */

  if giLieferant <> E_BelegKopf.Lieferant then
  do:

    find S_Lieferant
      where S_Lieferant.Firma = {firma/sliefera.fir pa-firma}
        and S_Lieferant.Lieferant = E_BelegKopf.Lieferant
      no-lock.

    assign
      gdKreditlimit        = S_Lieferant.Kreditlimit
      giLieferant          = E_BelegKopf.Lieferant
      gdMindestbestellwert = S_Lieferant.Mindestbestellwert
                             * {fnarg
                                 pa_dCurGetExchangeRate
                                 "E_BelegKopf.Firma,
                                  E_BelegKopf.Waehrung,
                                  E_BelegKopf.BelegDatum,
                                  string({&pa_E_Kurs}),
                                  E_BelegKopf.Lieferant,
                                  E_BelegKopf.E_BelegKopf_Obj"}
      .

  end. /* if giLieferant <> E_BelegKopf.Lieferant */

  /* Rundung auf die Nachkommastellen der Eigenw�hrung */

  assign
    gdWarenwert = round(E_BelegKopf.Warenwert_offen
                        * {fnarg
                            pa_dCurGetExchangeRate
                            "E_BelegKopf.Firma,
                             E_BelegKopf.Waehrung,
                             E_BelegKopf.BelegDatum,
                             string({&pa_E_Kurs}),
                             E_BelegKopf.Lieferant,
                             E_BelegKopf.E_BelegKopf_Obj"},
                        giWaehrungNK)

    gdSaldo = (if S_Lieferant.AdressNr <> 0 then
                 gateway.cls.GSCBalanceSvc:prpoInstance:dTotalBalance
                   (E_BelegKopf.Firma,
                    E_BelegKopf.Lieferant,
                    yes /* Run on Appserver? */)
               else
                 0)
    .


end. /* if available E_BelegKopf */

else
do:

  assign
    gdWarenwert   = 0
    gdSaldo       = 0
    gdKreditlimit = 0
    gdMindestbestellwert = 0
    .

  release E_BelegPos.

end. /* else do: */

if available E_BelegPos then
  run satzart-bearbeitung (E_BelegPos.SatzArt).

else
do:

  release gbS_Artikel.

  RUN set-link-attribute IN adm-broker-hdl (THIS-PROCEDURE,'container-source':U,'SatzArt=A':U).

  {fnarg
    pa_lUISvcSetWidgetHiddenState
    "E_BelegPos.Artikel:handle in frame {&frame-name}, no"}.

  {fnarg
    pa_lUISvcSetWidgetHiddenState
    "E_BelegPos.Textschluessel:handle in frame {&frame-name}, yes"}.

  {setwidgetattr
     "E_BelegPos.PositionsNr"
     "screen-value"
     "'1':U"
     "in frame {&FRAME-NAME}"}.

end.

if    available E_BelegPos
  and E_BelegPos.SatzArt = 'A':U then
do:

  assign
    gcInfo-1       =  '(':U
                      + (if E_BelegPos.offen = no then
                           (if E_BelegPos.gelieferte_Menge > 0 then
                              (if E_BelegPos.BelegArt = 'EBA':U then
                                 'Berechnet':T15
                               else
                                 'geliefert':T15)
                            else
                              'archiviert':T15)
                         else if E_BelegPos.gelieferte_Menge = 0
                           and E_BelegPos.Fehlmenge = 0 then
                           'offen':T15
                         else
                           (if E_BelegPos.BelegArt = 'EBA':U then
                              'teilberechnet':T15
                            else
                              'teilgeliefert':T15))
                      + ')':U

    gcMRPAreaObj   = mawi.dispo.cls.MDCMRPAreaSvc:prpoInstance:cGetMRPAreaPart
                       (E_BelegPos.Artikel,
                        E_BelegPos.LagerOrt)
    gcSArtKundeObj = stamm.base.cls.SBCDropShippingSvc:prpoInstance:cGetEndCustomerPart
                       (E_BelegPos.E_BelegPos_Obj)
    .


end. /* if available E_BelegPos */
else

  assign
    gcInfo-1                                              = '':U
    gcMRPAreaObj                                          = '':U
    gcSArtKundeObj                                        = '':U
    .



&IF LOOKUP("U_CE":U,"{&PA-OPTIONEN}":U) > 0 &THEN

  if not adm-new-record then

    assign
      BestellNr_var = (if available E_BelegPos and E_BelegPos.uCE_PONumber <> ? then
                         trim(string(E_BelegPos.uCE_PONumber))
                       else
                         '':U)
      .

&ENDIF /* U_CE */

/* Dispatch standard ADM method.                             */
run dispatch in this-procedure ( 'display-fields':U ) .

/* Code placed here will execute AFTER standard behavior.    */

if return-value <> 'ADM-ERROR':U then
do:

  run Anzeige-BestellNr/Variante.

  run display-BelegInfo.

  if    available E_BelegKopf
    and not can-find(first E_BelegPos
                     of E_BelegKopf) then
    {adm/incl/d__duh00.if
       &Var1          = "1"
       &At1           = "E_BelegPos.PositionsNr"
       &Unless-hidden = "no"
       &WithFrame     = "Frame {&FRAME-NAME}"}

end. /* if return-value <> 'ADM-ERROR':U */

end procedure.

/* _UIB-CODE-BLOCK-END */
&ANALYZE-RESUME

&ANALYZE-SUSPEND _UIB-CODE-BLOCK _PROCEDURE local-enable-fields V-table-Win 
PROCEDURE local-enable-fields :
/* Description ---------------------------------------------------------------*/
/*                                                                            */
/* Super Override                                                             */
/*                                                                            */
/* Notes ---------------------------------------------------------------------*/
/*                                                                            */
/*                                                                            */
/*                                                                            */
/* Parameters ----------------------------------------------------------------*/
/*                                                                            */
/* <none>                                                                     */
/*                                                                            */
/* Examples ------------------------------------------------------------------*/
/*                                                                            */
/*                                                                            */
/*                                                                            */
/*----------------------------------------------------------------------------*/

/* Variables -----------------------------------------------------------------*/
/*----------------------------------------------------------------------------*/

define variable lAbbruch     as   logical         no-undo.
define variable i            as   integer         no-undo.
define variable cTemp        as   character       no-undo.
define variable cTeile       as   character       no-undo.
define variable iStoragearea like ML_Ort.Lagerort no-undo.
define variable hContainer   as   handle          no-undo.

/* Buffers -------------------------------------------------------------------*/

define buffer bE_BelegKopf    for E_BelegKopf.
define buffer bE_BelegPos     for E_BelegPos.
define buffer bE_WE_Pos       for E_WE_Pos.
define buffer E_ArtLiefBei    for E_ArtLiefBei.
define buffer E_BelegPosBei   for E_BelegPosBei.
define buffer bS_Artikel      for S_Artikel.
define buffer bS_Lieferant    for S_Lieferant.

/*----------------------------------------------------------------------------*/
/* Processing                                                                 */
/*----------------------------------------------------------------------------*/

/* Code placed here will execute PRIOR to standard behavior. */

/* When this program has been called in 'slavemode' then it is not allowed  */
/* to create a new record.                                                  */

if    glSlaveMode
  and not {&PA-FIRST-CHECK}
  and not can-find(first bE_BelegPos
    where bE_BelegPos.Firma       = E_BelegPos.Firma
      and bE_BelegPos.Belegart    = E_BelegPos.Belegart
      and bE_BelegPos.ReferenzNr  = E_BelegPos.ReferenzNr
      and bE_BelegPos.PositionsNr = input frame {&FRAME-NAME} E_BelegPos.PositionsNr) then

  adm.method.cls.DMCMessageSvc:prpoInstance:showError('e_bel00166':U).

  if    available E_BelegPos
    and E_BelegPos.Satzart   = 'A':U
    and E_BelegKopf.Belegart = 'EBA':U
    and not stamm.base.cls.SBCPostingPeriodSvc:prpoInstance:lPostingPeriodIsOpen
          ({&pa_SB_PostPeriodType_Material},
           E_BelegKopf.Belegdatum) then

    adm.method.cls.DMCMessageSvc:prpoInstance:showError('s_buc00101':U,
                                                        string(E_BelegKopf.Belegdatum,'{&PA_DATEFORMAT}':U)).

/* Pr�fe, ob zum Lieferanten bzw. zum Beleg f�r die Beistellung Zust�nde    */
/* existieren.                                                              */
/* Die Pr�fung muss bereits hier erfolgen, da andernfalls (_check-record)   */
/* das Ereignis zur Beistellung feuert und somit f�lschlicherweise der      */
/* diesem Ereignis zugeordnete Zustand dem Beleg zugeordnet w�rde.          */

if    can-do('EB,EAB':U,gcBelegart)
  and pa-add-on-enable
  and input frame {&frame-name} E_BelegPos.Artikel > '':U
  and (can-find(first E_ArtLiefBei
    where E_ArtLiefBei.Firma     = {firma/e_artli.fir pa-Firma}
      and E_ArtLiefBei.Artikel   = input frame {&frame-name} E_BelegPos.Artikel
      and E_ArtLiefBei.Lieferant = E_BelegKopf.Lieferant)
    or available wt_E_BelegPos_source
      and can-find(first E_BelegPosBei
        where E_BelegPosBei.Firma       = wt_E_BelegPos_source.Firma
          and E_BelegPosBei.Belegart    = wt_E_BelegPos_source.Belegart
          and E_BelegPosBei.ReferenzNr  = wt_E_BelegPos_source.ReferenzNr
          and E_BelegPosBei.PositionsNr = wt_E_BelegPos_source.PositionsNr)) then
do:

  find bS_Lieferant
    where bS_Lieferant.Firma     = {firma/sliefera.fir pa-Firma}
      and bS_Lieferant.Lieferant = E_BelegKopf.Lieferant
    no-lock.

  basis.buro.cls.BBCWorkflowSvc:prpoInstance:showLockStatus
    (bS_Lieferant.S_Lieferant_Obj,
     'E_BBei':U).

  basis.buro.cls.BBCWorkflowSvc:prpoInstance:showLockStatus
    (E_BelegKopf.E_BelegKopf_Obj,
     'E_BBei':U).

  /* Pr�fe, ob eines der verwendeten Beistellteile inzwischen mit einem Zu- */
  /* stand zum Bereich 'Beistellung' versehen ist.                          */
  /* Bei Kopiervorlage m�ssen auch die Beistellteile der zu kopierenden Be- */
  /* stellposition beachtet werden.                                         */

  /* Erstelle zuerst eine Liste der Beistellteile aus E_ArtLiefBei und bei  */
  /* Verwendung der Kopiervorlage zus�tzlich aus E_BelegPosBei.             */

  cTeile = '':U.

  for each E_ArtLiefBei
    where E_ArtLiefBei.Firma     = {firma/e_artli.fir pa-Firma}
      and E_ArtLiefBei.Artikel   = input frame {&frame-name} E_BelegPos.Artikel
      and E_ArtLiefBei.Lieferant = E_BelegKopf.Lieferant
    no-lock
    on error undo, throw:

    cTeile = adm.method.cls.DMCStringSvc:cStringListAddItem
               (cTeile,
                E_ArtLiefBei.BeistellArtikel,
                {&PA-DELIMITER1}).

  end. /* for each E_ArtLiefBei */

  if available wt_E_BelegPos_source then

    for each E_BelegPosBei
      where E_BelegPosBei.Firma       = wt_E_BelegPos_source.Firma
        and E_BelegPosBei.Belegart    = wt_E_BelegPos_source.Belegart
        and E_BelegPosBei.ReferenzNr  = wt_E_BelegPos_source.ReferenzNr
        and E_BelegPosBei.PositionsNr = wt_E_BelegPos_source.PositionsNr
      no-lock
      on error undo, throw:

      cTeile = adm.method.cls.DMCStringSvc:cStringListAddItem
                 (cTeile,
                  E_BelegPosBei.BeistellArtikel,
                  {&PA-DELIMITER1},
                  no).

    end. /* for each E_BelegPosBei */

  if cTeile > '':U then

    do i = 1 to num-entries(cTeile,{&PA-DELIMITER1}):

      find bS_Artikel
        where bS_Artikel.Firma   = {firma/sartikel.fir pa-Firma}
          and bS_Artikel.Artikel = entry(i,cTeile,{&PA-DELIMITER1})
        no-lock no-error.

      if available bS_Artikel then
        basis.buro.cls.BBCWorkflowSvc:prpoInstance:showLockStatus
          (bS_Artikel.S_Artikel_Obj,
           'E_BBei':U).

    end. /* do i = 1 to num-entries(cTeile,{&PA-DELIMITER1}) */

end. /* if    can-do('EB,EAB':U,gcBelegart) */

/* Dispatch standard ADM method.                             */
run dispatch in this-procedure ( 'enable-fields':U ) .

/* Code placed here will execute AFTER standard behavior.    */

/* sicherheitshalber den Screen-value von gcSatzart zur�cksetzen */

if return-value <> 'ADM-ERROR':U then
do:

  if pa-fields-enabled then
  do:

    assign
      gcSatzart      = E_BelegPos.Satzart
      {setwidgetattr
         "E_BelegPos.Satzart"
         "screen-value"
         "gcSatzart"
         "in frame {&frame-name}"}
      glWertposition = E_BelegPos.Wertposition
      .

  end.

  /* Nur offene Positionen zur Bearbeitung freigeben */

  if    pa-fields-enabled
    and not pa-add-on-enable
    and available E_BelegPos
    and E_BelegPos.Satzart = 'T':U then
  do:

    hContainer = {fnarg
                   pa_hADMGetFirstLinkHandle
                   "this-procedure,
                    'container-source':U"}.

    if    valid-handle(hContainer)
      and adm.method.cls.DMCMenuSvc:prpoInstance:lIsMenuItemExistingByName('BT_TextEditor:EBELP':U,hContainer) then

      adm.method.cls.DMCMenuSvc:prpoInstance:applyChooseToMenuElementByName('BT_TextEditor:EBELP':U,hContainer).

  end. /* if pa-fields-enabled ... */

  /* Schlie�e die Neuanlage des Lieferanten */

  if    pa-fields-enabled
    and not pa-add-on-enable
    and valid-handle (ghE_ArtLief) then

    run dispatch in ghE_ArtLief ('exit':U).

  if    pa-fields-enabled
    and adm-new-record
    and E_BelegPos.Belegart = 'ERL':U
    and E_BelegPos.Satzart = 'A':U
    and glEnableNachAdd = yes then
  do:

    /* Soll R�cklieferung auf vorhandenen offenen Wareneingang erfolgen */

    if can-find (first E_WE_Pos
      where E_WE_Pos.Firma        = {firma/ebelkop.fir pa-Firma}
        and E_WE_Pos.berechnet    = no
        and E_WE_Pos.Artikel      = E_BelegPos.Artikel
        and E_WE_Pos.ArtVar       = E_BelegPos.ArtVar
        and E_WE_Pos.Lieferant    = E_BelegKopf.Lieferant) then
    do:

      /* Wenn komplett auf nur einen anderen Lagerort umgebucht wurde, dann soll der neue */
      /* Lagerort einschlie�lich umgebuchter Menge angezeigt werden.                      */

      AuswahlWareneingang:
      for each E_WE_Pos
        where E_WE_Pos.Firma        = {firma/ebelkop.fir pa-Firma}
          and E_WE_Pos.berechnet    = no
          and E_WE_Pos.Artikel      = E_BelegPos.Artikel
          and E_WE_Pos.ArtVar       = E_BelegPos.ArtVar
          and E_WE_Pos.Lieferant    = E_BelegKopf.Lieferant
        no-lock
        on error undo, throw:

        iStoragearea = iCheckStoragearea(E_WE_Pos.E_WE_Pos_Obj).

        if can-find (first E_WE_Pos
             where E_WE_Pos.Firma                  = {firma/ebelkop.fir pa-Firma}
               and E_WE_Pos.berechnet              = no
               and E_WE_Pos.Artikel                = E_BelegPos.Artikel
               and E_WE_Pos.ArtVar                 = E_BelegPos.ArtVar
               and E_WE_Pos.Lieferant              = E_BelegKopf.Lieferant
               and E_WE_Pos.Wertposition           = no
               and (   E_WE_Pos.WE_LagerOrt        = ?    /* alles schon auf Ziellager */
                    or E_WE_Pos.Lager_gebucht      = no   /* noch nicht vollst�ndig vom WE-Lager umgebucht */
                    or E_WE_Pos.Lager_gebucht      = yes  /* alles auf einen einzigen LO umgebucht */
                       and iStoragearea           <> ?)
               and E_WE_Pos.Liefermenge > E_WE_Pos.Rueckmenge
               and (   E_WE_Pos.Herk_ReferenzNr  <> ?
                    or E_WE_Pos.Herk_ReferenzNr   = ?
                      and not can-find(first E_ArtLief
                                where E_ArtLief.Firma      = {firma/e_artli.fir pa-Firma}
                                  and E_ArtLief.archiviert = no
                                  and E_ArtLief.Artikel    = E_WE_Pos.Artikel
                                  and E_ArtLief.Lieferant  = E_WE_Pos.Lieferant
                                  and (   can-find(first S_RabZuArt
                                                   where S_RabZuArt.S_RabZuArt_Obj        = E_ArtLief.Value1_S_RabZuArt_Obj
                                                     and S_RabZuArt.isDiscSurOnTotalPrice = yes
                                                   use-index Obj)
                                       or can-find(first S_RabZuArt
                                                   where S_RabZuArt.S_RabZuArt_Obj        = E_ArtLief.Value2_S_RabZuArt_Obj
                                                     and S_RabZuArt.isDiscSurOnTotalPrice = yes
                                                   use-index Obj)
                                       or can-find(first S_RabZuArt
                                                   where S_RabZuArt.S_RabZuArt_Obj        = E_ArtLief.Value3_S_RabZuArt_Obj
                                                     and S_RabZuArt.isDiscSurOnTotalPrice = yes
                                                   use-index Obj)
                                       or can-find(first S_RabZuArt
                                                   where S_RabZuArt.S_RabZuArt_Obj        = E_ArtLief.Value4_S_RabZuArt_Obj
                                                     and S_RabZuArt.isDiscSurOnTotalPrice = yes
                                                   use-index Obj)
                                       or can-find(first S_RabZuArt
                                                   where S_RabZuArt.S_RabZuArt_Obj        = E_ArtLief.Value5_S_RabZuArt_Obj
                                                     and S_RabZuArt.isDiscSurOnTotalPrice = yes
                                                   use-index Obj)))))
          &IF LOOKUP("VS_Repair":U,"{&PA-OPTIONEN}":U) > 0 &THEN
            and eink.base.cls.EBCPurchaseDocSvc:prpoInstance:lIsRepairOrderDocumentLine
                  (E_WE_Pos.E_WE_Pos_Obj) = no
          &ENDIF
          then
        do:

          if adm.method.cls.DMCMessageSvc:prpoInstance:lShowMessage ('e_bel00031':U) = yes then
          do:

            run eink/proc/e_prli02.w (input        rowid (E_BelegPos),
                                            output lAbbruch,
                                      input-output cTemp) no-error.

            if   error-status:error
              or lAbbruch then
            do:

              &IF lookup ("M_Pack":U,"{&PA-OPTIONEN}":U) > 0 &THEN

                /* Delete existing Packaging -------------------------------- */

                if can-find (first M_LTPos
                               where M_LTPos.Firma            = {firma/mlartort.fir E_BelegPos.Firma}
                                 and M_LTPos.Bereich          = {&pa_ML_PackagingArea_Purchasing}
                                 and M_LTPos.Funktion         = {&pa_MM_PackagingDelivery}  /* 4 */
                                 and M_LTPos.Herk_BelegArt2   = E_BelegPos.BelegArt
                                 and M_LTPos.Herk_Schluessel2 = E_BelegKopf.E_BelegKopf_Obj
                                 and M_LTPos.Herk_BelegArt3   = E_BelegPos.BelegArt
                                 and M_LTPos.Herk_Schluessel3 = E_BelegPos.E_BelegPos_Obj) then

                run mawi/proc/m_vpmi04.p (pACConnectionSvc:prpcCompany,
                                          {&pa_ML_PackagingArea_Purchasing},
                                          {&pa_MM_PackagingDelivery},    /* 4 */
                                          'EWE':U,
                                          '':U,
                                          E_BelegPos.BelegArt,
                                          E_BelegKopf.E_BelegKopf_Obj,
                                          E_BelegPos.BelegArt,
                                          E_BelegPos.E_BelegPos_Obj,
                                          yes).

              &ENDIF /* M_Pack */

              &IF LOOKUP("S_FORDMNGT":U,"{&PA-OPTIONEN}":U) > 0 &THEN

                run checkHedgeContractAsgForReturn.

              &ENDIF

              adm.method.cls.DMCMessageSvc:prpoInstance:lShowMessage ('e_bel00029':U).

              /* Es wird doch nicht auf vorhandenen offenen Wareneingang zur�ckgeliefert. */
              /* R�cklieferung in Lager- oder Lieferantenmengeneinheit anlegen?           */

              {eink/incl/e__mng01.if
                &Artikel   = "E_BelegPos.Artikel"
                &Lieferant = "giLieferant"
              }

            end. /* if error-status:error or lAbbruch */
            else
            do:

              /* Wegen Incoterm, vor �bernahme WE pr�fen, ob sich Lieferbedingung ge�ndert hat. */

              if E_BelegPos.Herk_BelegArt = 'EWE':U then
              do:

                find bE_WE_Pos
                  where bE_WE_Pos.Firma       = E_BelegPos.Firma
                    and bE_WE_Pos.ReferenzNr  = E_BelegPos.Herk_ReferenzNr
                    and bE_WE_Pos.PositionsNr = E_BelegPos.Herk_PositionsNr
                  no-lock.

                find bE_BelegKopf
                  where bE_BelegKopf.Firma      = bE_WE_Pos.Firma
                    and bE_BelegKopf.BelegArt   = bE_WE_Pos.Herk_BelegArt
                    and bE_BelegKopf.ReferenzNr = bE_WE_Pos.Herk_ReferenzNr
                  no-lock no-error.

                if    available bE_BelegKopf
                  and bE_BelegKopf.Lieferbedingung <> E_BelegKopf.Lieferbedingung
                  and adm.method.cls.DMCMessageSvc:prpoInstance:lShowMessage
                        ('e_bel00055':U,
                         string(bE_BelegKopf.Lieferbedingung),
                         string(E_BelegKopf.Lieferbedingung)) = no then

                  return 'ADM-ERROR':U.

                &IF LOOKUP("Q_DEL":U,"{&PA-OPTIONEN}":U) > 0 &THEN

                  /* The source of document is known to late. Therefore first */
                  /* reset metal data (without stock receipt).                */

                  stamm.base.cls.SBCMetalSvc:prpoInstance:deleteDependantMetalDataFromPosition(E_BelegPos.E_BelegPos_Obj).

                  /* Create metal data with stock receipt                     */

                  stamm.base.cls.SBCMetalSvc:prpoInstance:createMetalTransactionData(E_BelegPos.E_BelegPos_Obj).

                &ENDIF 

              end. /* if E_BelegPos.Herk_BelegArt = 'EWE':U */

              run new-state ('UebernahmeWE,record-target':U).

              if pACConnectionSvc:prpcLocalization = 'H':U then
                run new-state ('special-fields,container-source':U).

              {&{&pa-XBasisName}_C_AdoptStockReceipt}
              {&{&pa-XBasisName}_U_AdoptStockReceipt}
              {&{&pa-XBasisName}_Q_AdoptStockReceipt}
              {&{&pa-XBasisName}_AdoptStockReceipt}
              {&{&pa-XBasisName}_Y_AdoptStockReceipt}

            end. /* else (if error-status:error or lAbbruch) */

          end. /* if adm.method.cls.DMCMessageSvc:prpoInstance:lShowMessage */
          else
          do:

            &IF LOOKUP("S_FORDMNGT":U,"{&PA-OPTIONEN}":U) > 0 &THEN

              run checkHedgeContractAsgForReturn.

            &ENDIF

            /* Es wird nicht auf vorhandenen offenen Wareneingang zur�ckgeliefert. */
            /* R�cklieferung in Lager- oder Lieferantenmengeneinheit anlegen?      */

            {eink/incl/e__mng01.if
              &Artikel   = "E_BelegPos.Artikel"
              &Lieferant = "giLieferant"
            }

          end.

          glEnableNachAdd = no.

          leave AuswahlWareneingang.

        end. /* if can-find (first E_WE_Pos */

      end. /* for each E_WE_Pos */

    end. /* if can-find (first E_WE_Pos */

    /* Es liegt kein offener Wareneingang vor, auf den zur�ckgeliefert werden k�nnte. */
    /* R�cklieferung in Lager- oder Lieferantenmengeneinheit anlegen?                 */

    else
    do:

      &IF LOOKUP("S_FORDMNGT":U,"{&PA-OPTIONEN}":U) > 0 &THEN

        run checkHedgeContractAsgForReturn.

      &ENDIF

      {eink/incl/e__mng01.if
        &Artikel   = "E_BelegPos.Artikel"
        &Lieferant = "giLieferant"
      }

      /* The question, whether the delivery should be returned using        */
      /* supplier units of measure or storage units may only come once.     */

      glEnableNachAdd = no.

    end. /* else do: */

  end. /* R�cklieferung auf offenen WE */

  glArchivieren = no.

&IF LOOKUP("U_CE":U,"{&PA-OPTIONEN}":U) > 0 &THEN

  /* enable field (in case of available record) */

  if pa-add-on-enable = no then
    {fnarg
      pa_lUISvcSetWidgetSensitiveState
      "BestellNr_var:handle in frame {&FRAME-NAME},
       (    branche.stamm.cls.USCPartManufacturerSvc:prpoInstance:lIsManufacturerAlternativePart
              (input frame {&FRAME-NAME} E_BelegPos.Artikel)
        and not adm-new-record )"}.

&ENDIF /* U_CE */

end. /* return-value <> 'ADM-ERROR':U */

end procedure.

/* _UIB-CODE-BLOCK-END */
&ANALYZE-RESUME

&ANALYZE-SUSPEND _UIB-CODE-BLOCK _PROCEDURE local-end-update V-table-Win 
PROCEDURE local-end-update :
/* Description ---------------------------------------------------------------*/
/*                                                                            */
/* Super Override                                                             */
/*                                                                            */
/* Notes ---------------------------------------------------------------------*/
/*                                                                            */
/*                                                                            */
/*                                                                            */
/* Parameters ----------------------------------------------------------------*/
/*                                                                            */
/* <none>                                                                     */
/*                                                                            */
/* Examples ------------------------------------------------------------------*/
/*                                                                            */
/*                                                                            */
/*                                                                            */
/*----------------------------------------------------------------------------*/

/* Variables -----------------------------------------------------------------*/
/*----------------------------------------------------------------------------*/

define variable lNeuerSatz   as logical   no-undo.
define variable cPositionsNr as character no-undo.

/* Buffers -------------------------------------------------------------------*/

/*----------------------------------------------------------------------------*/
/* Processing                                                                 */
/*----------------------------------------------------------------------------*/

/* Code placed here will execute PRIOR to standard behavior. */

lNeuerSatz =     adm-new-record
             and gcSatzart = 'A':U
             and (glWertposition = no
               or glWertposition = yes and gcBelegArt = 'EBA':U).

/* Dispatch standard ADM method.                             */
run dispatch in this-procedure ( 'end-update':U ) .

/* Code placed here will execute AFTER standard behavior.    */

if return-value <> 'adm-error':U then
do:

  assign
    gcSatzart      = 'A':U
    glWertposition = no
    .

  /* handelte es sich bei dem letzten Satz um die Neuanlage einer Artikel-  */
  /* position (keine Wertposition), wurde dieser Satz nicht kopiert, und    */
  /* wurde nicht die CLOSE-BOX bet�tigt, so lege sofort unter der letzten   */
  /* Nummer + 1 einen neuen Satz an.                                        */

  if    lNeuerSatz
    &IF LOOKUP("Q_DEL":U,"{&PA-OPTIONEN}":U) > 0 &THEN  
    and glUpdateMetals = no
    &ENDIF  
    and not glSatzKopiert
    and not glDestroy then
  do:

    run request-attribute (THIS-PROCEDURE, 'record-source':U, 'next-position':U).

    if return-value <> ? then
    do:

      cPositionsNr = return-value.

      release E_BelegPos.

      if integer(cPositionsNr) >= 1000 then
      do:

        adm.method.cls.DMCMessageSvc:prpoInstance:lShowMessage
          ('m_bel00006':U).

        return 'adm-error':U.

      end.

      run dispatch ('display-fields':U).
      run notify ('row-available':U).

      {setwidgetattr
         "E_BelegPos.PositionsNr"
         "screen-value"
         "cPositionsNr"
         "in frame {&FRAME-NAME}"}.

      run new-state ('positionpage,container-source':U).

    end.

    RUN dispatch IN THIS-PROCEDURE ('add-record':U).

  end. /* if lNeuerSatz */
  else
  do:

    run dispatch ('display-fields':U).
    run notify ('row-available':U).

  end.

  &IF LOOKUP("Q_DEL":U,"{&PA-OPTIONEN}":U) > 0 &THEN
    glUpdateMetals = no.
  &ENDIF

end. /* if return-value <> 'adm-error':U */

end procedure.

/* _UIB-CODE-BLOCK-END */
&ANALYZE-RESUME

&ANALYZE-SUSPEND _UIB-CODE-BLOCK _PROCEDURE local-help-begin V-table-Win 
PROCEDURE local-help-begin :
/* Description ---------------------------------------------------------------*/
/*                                                                            */
/* Super Override                                                             */
/*                                                                            */
/* Notes ---------------------------------------------------------------------*/
/*                                                                            */
/*                                                                            */
/*                                                                            */
/* Parameters ----------------------------------------------------------------*/
/*                                                                            */
/* <none>                                                                     */
/*                                                                            */
/* Examples ------------------------------------------------------------------*/
/*                                                                            */
/*                                                                            */
/*                                                                            */
/*----------------------------------------------------------------------------*/

/* Variables -----------------------------------------------------------------*/
/*----------------------------------------------------------------------------*/

/* Buffers -------------------------------------------------------------------*/

define buffer bS_Artikel for S_Artikel.

/*----------------------------------------------------------------------------*/
/* Processing                                                                 */
/*----------------------------------------------------------------------------*/

/* Code placed here will execute PRIOR to standard behavior. */

if available E_BelegKopf then
do:

  assign
    pa-hlp-string = adm.method.cls.DMCParameterStringSvc:cWriteValue(pa-hlp-string, 'ReferenzNr':U, E_BelegKopf.ReferenzNr)
    pa-hlp-string = adm.method.cls.DMCParameterStringSvc:cWriteValue(pa-hlp-string, 'BelegArt':U, E_BelegKopf.BelegArt)
    pa-hlp-string = adm.method.cls.DMCParameterStringSvc:cWriteValue(pa-hlp-string, 'Lieferant':U, E_BelegKopf.Lieferant)
    .

  find bS_Artikel
    where bS_Artikel.Firma   = {firma/sartikel.fir pa-Firma}
      and bS_Artikel.Artikel = input frame {&frame-name} E_BelegPos.Artikel
    no-lock no-error.

  if available bS_Artikel then

    pa-hlp-string = adm.method.cls.DMCParameterStringSvc:cWriteValue(pa-hlp-string, 'ArtVarTyp':U, bS_Artikel.ArtVarTyp).

end. /* if available E_BelegKopf */

&IF LOOKUP("U_CE":U,"{&PA-OPTIONEN}":U) > 0 &THEN

  /* set help-string (only for CTRL-A) */

  if   ({focus name} = 'BestellNr_var':U
     or {focus name} = 'Artikel':U)
    and entry(1,pa-hlp-function) = 'A':U then

    assign
      pa-hlp-string = adm.method.cls.DMCParameterStringSvc:cWriteValue
                        (pa-hlp-string,
                         'USM_SupplierPONumbers':U,
                         'yes':U)
      pa-hlp-string = adm.method.cls.DMCParameterStringSvc:cWriteValue
                        (pa-hlp-string,
                         'Supplier':U,
                         trim(string(E_BelegKopf.Lieferant)))
      pa-hlp-string = adm.method.cls.DMCParameterStringSvc:cWriteValue
                        (pa-hlp-string, 'Part':U,
                         (if    {focus name} = 'BestellNr_var':U
                            and can-find(first gbuUSM_SupplierPONumbers
                                           where gbuUSM_SupplierPONumbers.Company  = {firma/e_artli.fir pACConnectionSvc:prpcCompany}
                                             and gbuUSM_SupplierPONumbers.Supplier = E_BelegKopf.Lieferant
                                             and gbuUSM_SupplierPONumbers.Part     = input frame {&FRAME-NAME} E_BelegPos.Artikel
                                           no-lock) then
                            input frame {&FRAME-NAME} E_BelegPos.Artikel
                          else
                            '':U))
      pa-hlp-string = adm.method.cls.DMCParameterStringSvc:cWriteValue
                        (pa-hlp-string,
                         'key-name':U,
                         (if {focus name} = 'Artikel':U then
                           'Part':U
                          else (if {focus name} = 'BestellNr_var':U then
                                  'PONumber':U
                                else
                                  '':U)))
    .

&ENDIF /* U_CE */

/* Dispatch standard ADM method.                             */
run dispatch in this-procedure ( 'help-begin':U ) .

/* Code placed here will execute AFTER standard behavior.    */


end procedure.

/* _UIB-CODE-BLOCK-END */
&ANALYZE-RESUME

&ANALYZE-SUSPEND _UIB-CODE-BLOCK _PROCEDURE local-initialize V-table-Win 
PROCEDURE local-initialize :
/* Description ---------------------------------------------------------------*/
/*                                                                            */
/* Super Override                                                             */
/*                                                                            */
/* Notes ---------------------------------------------------------------------*/
/*                                                                            */
/*                                                                            */
/*                                                                            */
/* Parameters ----------------------------------------------------------------*/
/*                                                                            */
/* <none>                                                                     */
/*                                                                            */
/* Examples ------------------------------------------------------------------*/
/*                                                                            */
/*                                                                            */
/*                                                                            */
/*----------------------------------------------------------------------------*/

/* Variables -----------------------------------------------------------------*/
/*----------------------------------------------------------------------------*/

define variable hQuery        as handle        no-undo.
define variable hRecordSource as handle        no-undo.

/* Buffers -------------------------------------------------------------------*/

/*----------------------------------------------------------------------------*/
/* Processing                                                                 */
/*----------------------------------------------------------------------------*/

/* Code placed here will execute PRIOR to standard behavior. */

run get-attribute ('Belegart':U).

assign
  gcBelegArt = return-value
  gcBereich  = 'E_':U + gcBelegArt

  /* setze W�hrungsbezeichnung auf Eigenw�hrung */

  giWaehrungNK = {fn pa_iCurDecimalsOfDomCur}
  gcWBez-1     = {fn pa_cCurShortDescOfDomCur}
  gcWBez-2     = gcWBez-1
  gcWBez-3     = gcWBez-1
  ghContainer  = {fnarg
                   pa_hADMGetFirstLinkHandle
                   "this-procedure,
                   'container-source':U"}
  .

/* Dispatch standard ADM method.                             */
run dispatch in this-procedure ( 'initialize':U ) .

/* Code placed here will execute AFTER standard behavior.    */

if return-value <> 'ADM-ERROR':U then
do:

  /* Bind "info"-fields to their base widgets. */

  {fnarg
    pa_lUISvcAttachWidget
    "gdKreditlimit:handle in frame {&frame-name},
     gcWBez-1:handle in frame {&frame-name}"}.

  {fnarg
    pa_lUISvcAttachWidget
    "gdSaldo:handle in frame {&frame-name},
     gcWBez-2:handle in frame {&frame-name}"}.

  {fnarg
    pa_lUISvcAttachWidget
    "gdWarenwert:handle in frame {&frame-name},
     gcWBez-3:handle in frame {&frame-name}"}.

  {fnarg
    pa_lUISvcAttachWidget
    "E_BelegPos.ArtVar:handle in frame {&frame-name},
     gcArtVar:handle in frame {&frame-name}"}.

  /* Debit memos do not have the menu item 'Documents' */

  if gcBelegArt = 'EBA':U then

    {fnarg
      pa_lUISvcSetWidgetHiddenState
      "sDocInfo:handle in frame {&frame-name}, yes"}.

  assign
    hQuery            = {fnarg
                          pa_hADMGetFirstLinkHandle
                          "this-procedure,
                           'record-source':U"}
    hRecordSource     = {fnarg
                          pa_hADMGetFirstLinkHandle
                          "hQuery,
                           'record-source':U"}
    .

  if valid-handle(hRecordSource) then                         
    ghContainerSource = {fnarg
                          pa_hADMGetFirstLinkHandle
                          "hRecordSource,
                           'container-source':U"}.

end. /* if return-value <> 'ADM-ERROR':U then */

end procedure.

/* _UIB-CODE-BLOCK-END */
&ANALYZE-RESUME

&ANALYZE-SUSPEND _UIB-CODE-BLOCK _PROCEDURE local-row-available V-table-Win 
PROCEDURE local-row-available :
/* Description ---------------------------------------------------------------*/
/*                                                                            */
/* Super Override                                                             */
/*                                                                            */
/* Notes ---------------------------------------------------------------------*/
/*                                                                            */
/*                                                                            */
/*                                                                            */
/* Parameters ----------------------------------------------------------------*/
/*                                                                            */
/* <none>                                                                     */
/*                                                                            */
/* Examples ------------------------------------------------------------------*/
/*                                                                            */
/*                                                                            */
/*                                                                            */
/*----------------------------------------------------------------------------*/

/* Variables -----------------------------------------------------------------*/
/*----------------------------------------------------------------------------*/

/* Buffers -------------------------------------------------------------------*/

/*----------------------------------------------------------------------------*/
/* Processing                                                                 */
/*----------------------------------------------------------------------------*/

/* Code placed here will execute PRIOR to standard behavior. */

run dispatch in this-procedure ( 'row-available':U ) .

/* Code placed here will execute AFTER standard behavior.    */

if return-value <> 'ADM-ERROR':U then
do:

  if available E_BelegPos then
  do:

    /* BelegArt kann wechseln, im Folgefenster zur Auftragsbest�tigung. */

    if E_BelegPos.BelegArt <> gcBelegArt then
    do:

      assign
        gcBelegArt = E_BelegPos.BelegArt
        gcBereich  = 'E_':U + gcBelegArt
        .

      /* Set window title, if source document lines are called for order      */
      /* confirmations.                                                       */

      adm.method.cls.DMCUISvc:setWindowTitle
        (ghContainer, (if gcBelegart = 'EB':U then
                         'Bestellpositionen':T40
                       else if gcBelegart = 'EAB':U then
                         'Positionen Bestellung mit Lieferplan':T40
                       else
                         'R�cklieferpositionen':T60)).

    end. /* if E_BelegPos.BelegArt <> gcBelegArt then */

    case E_BelegPos.Satzart:

      when 'A':U then

        run new-state ('positionpage,container-source':U).

      when 'T':U then

        run new-state ('textpage,container-source':U).

    end case.

  end. /* if available E_BelegPos */

  if    available wt_E_BelegPos_source
    and wt_E_BelegPos_source.Lieferant <> E_BelegKopf.Lieferant then

    run new-state ('KopiervorlageL�schen,container-source':U).

end. /* if return-value <> 'ADM-ERROR':U */

end procedure.

/* _UIB-CODE-BLOCK-END */
&ANALYZE-RESUME

&ANALYZE-SUSPEND _UIB-CODE-BLOCK _PROCEDURE local-select-copy-source V-table-Win 
PROCEDURE local-select-copy-source :
/* Description ---------------------------------------------------------------*/
/*                                                                            */
/* Super Override                                                             */
/*                                                                            */
/* Notes ---------------------------------------------------------------------*/
/*                                                                            */
/*                                                                            */
/*                                                                            */
/* Parameters ----------------------------------------------------------------*/
/*                                                                            */
/* <none>                                                                     */
/*                                                                            */
/* Examples ------------------------------------------------------------------*/
/*                                                                            */
/*                                                                            */
/*                                                                            */
/*----------------------------------------------------------------------------*/

/* Variables -----------------------------------------------------------------*/
/*----------------------------------------------------------------------------*/

/* Buffers -------------------------------------------------------------------*/

/*----------------------------------------------------------------------------*/
/* Processing                                                                 */
/*----------------------------------------------------------------------------*/

/* Code placed here will execute PRIOR to standard behavior ------------------*/

if    available E_BelegPos
  and E_BelegPos.Coverage_MRPDocType > '':U then

  adm.method.cls.DMCMessageSvc:prpoInstance:showError('e_bel00185':U).

/* Execute standard behavior -------------------------------------------------*/

run dispatch('select-copy-source':U).

/* Code placed here will execute AFTER standard behavior ---------------------*/

end procedure. /* local-select-copy-source */

/* _UIB-CODE-BLOCK-END */
&ANALYZE-RESUME

&ANALYZE-SUSPEND _UIB-CODE-BLOCK _PROCEDURE local-update-record V-table-Win 
PROCEDURE local-update-record :
/* Description ---------------------------------------------------------------*/
/*                                                                            */
/* Super Override                                                             */
/*                                                                            */
/* Notes ---------------------------------------------------------------------*/
/*                                                                            */
/*                                                                            */
/*                                                                            */
/* Parameters ----------------------------------------------------------------*/
/*                                                                            */
/* <none>                                                                     */
/*                                                                            */
/* Examples ------------------------------------------------------------------*/
/*                                                                            */
/*                                                                            */
/*                                                                            */
/*----------------------------------------------------------------------------*/

/* Variables -----------------------------------------------------------------*/
/*----------------------------------------------------------------------------*/

/* Buffers -------------------------------------------------------------------*/

/*----------------------------------------------------------------------------*/
/* Processing                                                                 */
/*----------------------------------------------------------------------------*/

/* Code placed here will execute PRIOR to standard behavior. */

/* Dispatch standard ADM method.                             */
run dispatch in this-procedure ( 'update-record':U ) .

/* Code placed here will execute AFTER standard behavior.    */

/* f�r Aktualisierung der Anzeige, 02.04.98 */

if return-value <> 'ADM-ERROR':U then
  run display-BelegInfo.

end procedure.

/* _UIB-CODE-BLOCK-END */
&ANALYZE-RESUME

&ANALYZE-SUSPEND _UIB-CODE-BLOCK _PROCEDURE paCntrEvt_ArchivePosition V-table-Win 
PROCEDURE paCntrEvt_ArchivePosition :
/*------------------------------------------------------------------------------
  Purpose:     Archive the position.
  Parameters:  <none>
  Notes:
------------------------------------------------------------------------------*/

define variable rRowId             as rowid         no-undo.
define variable cE_BelegKopf_Obj   as character     no-undo.

define buffer bER_BelegPos   for ER_BelegPos.
define buffer bE_BelegPos    for E_BelegPos.

if    available E_BelegPos
  and can-do('EB,ERL,EAB':U,E_BelegPos.BelegArt) then
do:

  /* Check lock level document header */

  basis.buro.cls.BBCWorkflowSvc:prpoInstance:showLockStatus
    (E_BelegKopf.E_BelegKopf_Obj,
     gcBereich).

  &IF lookup ("E_ANZ":U,"{&PA-OPTIONEN}":U) > 0 &THEN

    if    can-do('EB,EAB':U,E_BelegPos.Belegart)
      and (   can-find(first ER_BelegPos
                 where ER_BelegPos.Firma           = {firma/ebelkop.fir pa-firma}
                   and ER_BelegPos.Belegart        = 'ERZ':U
                   and ER_BelegPos.Herk_BelegArt   = E_BelegPos.BelegArt
                   and ER_BelegPos.Herk_ReferenzNr = E_BelegPos.ReferenzNr
                   and ER_BelegPos.uebernommen     = no)
           or can-find(first ER_BelegPos
                 where ER_BelegPos.Firma           = {firma/ebelkop.fir pa-firma}
                   and ER_BelegPos.Belegart        = 'ERZ':U
                   and ER_BelegPos.Herk_BelegArt   = E_BelegKopf.BelegArt
                   and ER_BelegPos.Herk_ReferenzNr = E_BelegKopf.ReferenzNr
                   and ER_BelegPos.uebernommen     = yes
                   and can-find(first bER_BelegPos
                     where bER_BelegPos.Firma            = {firma/ebelkop.fir pa-firma}
                       and bER_BelegPos.Belegart         = 'ERR':U
                       and bER_BelegPos.Herk_BelegArt    = ER_BelegPos.BelegArt
                       and bER_BelegPos.Herk_ReferenzNr  = ER_BelegPos.ReferenzNr
                       and bER_BelegPos.Herk_PositionsNr = ER_BelegPos.PositionsNr
                       and bER_BelegPos.verbucht         = no))) then

      if can-find(first bE_BelegPos
            where bE_BelegPos.Firma        = E_BelegPos.Firma
              and bE_BelegPos.Belegart     = E_BelegPos.Belegart
              and bE_BelegPos.ReferenzNr   = E_BelegPos.ReferenzNr
              and bE_BelegPos.PositionsNr <> E_BelegPos.PositionsNr
              and bE_BelegPos.offen        = yes) then
      do:

        if adm.method.cls.DMCMessageSvc:prpoInstance:lShowMessage
             ('errec00165':U) = no then

          return.

      end. /* if can-find(first bE_BelegPos */
      else
      do
        on error undo, return:

        adm.method.cls.DMCMessageSvc:prpoInstance:showError
          ('errec00164':U).

      end. /* else: if can-find(first bE_BelegPos */

  &ENDIF

  /* Since the "Document Printed" indicator is reset at the end of the        */
  /* archiving, the document header first has to be accessed exclusively.     */ 

  if    valid-handle(ghContainerSource)
    and ghContainerSource:name = 'eink/proc/e_pbes00.w':U then
  do:

    run new-state in ghContainerSource('toolbar-update,container-target':U).                     

    run get-ContainerInUpdate in ghContainerSource.

    if return-value = 'no':U then
      return 'ADM-ERROR':U.

  end. /* if E_BelegKopf.BelegArt = 'EB':U then */

  /* Sofern man sich nicht im Update-Modus befindet, muss erst noch die    */
  /* Position im exclusive-lock gelesen werden.                            */

  if not pa-fields-enabled then
  do:

    rRowId = rowid(E_BelegPos).

    find current E_BelegPos
      exclusive-lock no-wait no-error.

    /* Sofern die Position nicht im exclusive-lock gelesen werden kann ist */
    /* die Archivierung nicht m�glich.                                     */

    if not available E_BelegPos then
    do:

      find E_BelegPos
        where rowid(E_BelegPos) = rRowId
        no-lock.

      return error.

    end. /* if not available E_BelegPos */

  end. /* if not pa-fields-enabled */

  glArchivieren = yes.

  run set-link-attribute in adm-broker-hdl (THIS-PROCEDURE,
                                            'record-target':U,
                                            'Archive=':U + string(glArchivieren)).

  cE_BelegKopf_Obj = E_BelegKopf.E_BelegKopf_Obj.

  run dispatch ('update-record':U).

  if return-value = 'adm-error':U then
    return error.

  run notify ('open-query,record-source':U).

  &IF LOOKUP("U_WMS":U,"{&PA-OPTIONEN}":U) > 0 &THEN
  branche.gateway.cls.UGC_CIWarehouseManagementSystem:prpoInstance:SentDocToWMS(cE_BelegKopf_Obj).
  &ENDIF

  /* For SRM send message after archiving                                     */

  if stamm.base.cls.SBCBusProcTransmissionSvc:prpoInstance:iGetTransmissionState
       (cE_BelegKopf_Obj) = {&pa_SB_TransState_transmitted} then
    stamm.base.cls.SBCBusProcTransmissionSvc:prpoInstance:sendMessage(cE_BelegKopf_Obj).

  /* Reset the "Document Printed" indicator */

  eink.base.cls.EBCPurchaseOrderDocSvc:prpoInstance:ResetDocumentPrintedIndicator
    (cE_BelegKopf_Obj).

  /* Since the print identifier has been reset, the display should be         */
  /* refreshed in the document header.                                        */

  run new-state in ghContainerSource('refresh,container-target':U).

end. /* if available E_BelegPos */

catch oError as Progress.Lang.Error:

  (new adm.method.cls.DMCErrorFrw(oError)):displayProgressErrorsOnly().

end catch.

end procedure.

/* _UIB-CODE-BLOCK-END */
&ANALYZE-RESUME

&ANALYZE-SUSPEND _UIB-CODE-BLOCK _PROCEDURE paCntrEvt_CheckMinPurValue V-table-Win 
PROCEDURE paCntrEvt_CheckMinPurValue :
/* Description ---------------------------------------------------------------*/
/*                                                                            */
/* Check if the Minimum Purchase Value has been solved.                       */
/*                                                                            */
/* Notes ---------------------------------------------------------------------*/
/*                                                                            */
/*                                                                            */
/*                                                                            */
/* Parameters ----------------------------------------------------------------*/
/*                                                                            */
/* <none>                                                                     */
/*                                                                            */
/* Examples ------------------------------------------------------------------*/
/*                                                                            */
/*                                                                            */
/*                                                                            */
/*----------------------------------------------------------------------------*/

/* Variables -----------------------------------------------------------------*/
/*----------------------------------------------------------------------------*/

define variable cWaeBez         like S_WaehrungSpr.KurzBez           no-undo.
define variable iNachkomma      like S_Waehrung.R_Nachkomma          no-undo.
define variable dKurs           as   decimal   decimals 10           no-undo.
define variable dWarenwert_EW   like E_BelegKopf.Warenwert           no-undo.
define variable dZuschlSumme_EW like E_BelegKopf.ZuschlSumme         no-undo.
define variable dMBW_EW         like S_Lieferant.Mindestbestellwert  no-undo.

/* Buffers -------------------------------------------------------------------*/

/*----------------------------------------------------------------------------*/
/* Processing                                                                 */
/*----------------------------------------------------------------------------*/

if    not pa-fields-enabled
  and available E_BelegKopf
  and can-do('EAB,EB':U,E_BelegKopf.BelegArt) then
do:

  if   not available S_Lieferant
    or S_Lieferant.Lieferant <> E_BelegKopf.Lieferant then

    find S_Lieferant
      where S_Lieferant.Firma     = {firma/sliefera.fir pa-firma}
        and S_Lieferant.Lieferant = E_BelegKopf.Lieferant
      no-lock.

  if S_Lieferant.Waehrung = E_BelegKopf.Waehrung then

    assign
      cWaeBez         = {fnarg
                          pa_cCurShortDescOfCurrency
                          "pa-Firma,
                           E_BelegKopf.Waehrung"}
      dWarenwert_EW   = E_BelegKopf.Warenwert
      dZuschlSumme_EW = E_BelegKopf.ZuschlSumme
      dMBW_EW         = S_Lieferant.Mindestbestellwert
      iNachkomma      = E_BelegKopf.WaehrungNK
      .

  else

    /* Wechselkurs der Lieferantenw�hrung und Waehrungskurzbezeichnung (EW) */

    assign
      cWaeBez         = gcWBez-1
      dKurs           = {fnarg
                          pa_dCurGetExchangeRate
                          "E_BelegKopf.Firma,
                           E_BelegKopf.Waehrung,
                           E_BelegKopf.BelegDatum,
                           string({&pa_E_Kurs}),
                           E_BelegKopf.Lieferant,
                           E_BelegKopf.E_BelegKopf_Obj"}
      dWarenwert_EW   = E_BelegKopf.Warenwert          * dKurs
      dZuschlSumme_EW = E_BelegKopf.ZuschlSumme        * dKurs
      dMBW_EW         = S_Lieferant.Mindestbestellwert * {fnarg
                                                           pa_dCurGetExchangeRate
                                                           "E_BelegKopf.Firma,
                                                            S_Lieferant.Waehrung,
                                                            E_BelegKopf.BelegDatum,
                                                            string({&pa_E_Kurs}),
                                                            E_BelegKopf.Lieferant,
                                                            E_BelegKopf.E_BelegKopf_Obj"}
      iNachkomma      = giWaehrungNK
      .

  adm.method.cls.DMCMessageSvc:prpoInstance:lShowMessage
    ((if dWarenwert_EW < dMBW_EW then
        'e_bel00012':U
      else
        'e_bel00011':U),
     trim(string(dWarenwert_EW,  entry(iNachkomma + 1,{&pa_WertGesamtFormat},{&pa-Delimiter4}))),
     trim(string(dZuschlSumme_EW,entry(iNachkomma + 1,{&pa_WertGesamtFormat},{&pa-Delimiter4}))),
     trim(string(dMBW_EW,        entry(iNachkomma + 1,{&pa_WertSummenFormat},{&pa-Delimiter4}))),
     cWaeBez).

end. /* Felder nicht enabled */

end procedure. /* paCntrEvt_CheckMinPurValue */

/* _UIB-CODE-BLOCK-END */
&ANALYZE-RESUME

&ANALYZE-SUSPEND _UIB-CODE-BLOCK _PROCEDURE Satzart-Bearbeitung V-table-Win 
PROCEDURE Satzart-Bearbeitung :
/*------------------------------------------------------------------------------
  Purpose:     Initialisierung f�r die einzelnen Satzarten
  Parameters:  <none>
  Notes:
------------------------------------------------------------------------------*/

  define input parameter pcSatzart as character no-undo.

  run set-link-attribute in adm-broker-hdl (THIS-PROCEDURE,
                                            'container-source':U,
                                            'SatzArt=':U
                                             + string(pcSatzart = 'T':U,'T/A':U)).

  {fnarg
    pa_lUISvcSetWidgetHiddenState
    "E_BelegPos.Textschluessel:handle in frame {&frame-name}, (pcSatzart <> 'T':U)"}.

  {fnarg
    pa_lUISvcSetWidgetHiddenState
    "E_BelegPos.Artikel:handle in frame {&frame-name}, (pcSatzart <> 'A':U)"}.

  {fnarg
    pa_lUISvcSetWidgetHiddenState
    "BestellNr_var:handle in frame {&frame-name}, (pcSatzart <> 'A':U)"}.

  {fnarg
    pa_lUISvcSetWidgetHiddenState
    "E_BelegPos.ArtVar:handle in frame {&frame-name}, (pcSatzart <> 'A':U)"}.


  return.

end procedure.

/* _UIB-CODE-BLOCK-END */
&ANALYZE-RESUME

&ANALYZE-SUSPEND _UIB-CODE-BLOCK _PROCEDURE send-key V-table-Win  adm/support/proc/_key-snd.p
PROCEDURE send-key :
/* Description ---------------------------------------------------------------*/
/*                                                                            */
/* Sends a requested KEY value back to the calling SmartObject                */
/*                                                                            */
/* Parameters ----------------------------------------------------------------*/
/*                                                                            */
/* see adm/template/sndkytop.i                                                */
/*                                                                            */
/*----------------------------------------------------------------------------*/

/*----------------------------------------------------------------------------*/
/* Processing                                                                 */
/*----------------------------------------------------------------------------*/

/* Define variables needed by this internal procedure.                        */

{adm/template/incl/sndkytop.i}

/* Return the key value associated with each key case.                        */

{adm/template/incl/sndkycas.i "BelegArt" "E_BelegPos" "BelegArt" " "}
{adm/template/incl/sndkycas.i "Lieferant" "E_BelegKopf" "Lieferant" " "}
{adm/template/incl/sndkycas.i "Doc_Obj" "E_BelegPos" "E_BelegPos_Obj" " "}
{adm/template/incl/sndkycas.i "Artikel" "E_BelegPos" "Artikel" " "}
{adm/template/incl/sndkycas.i "S_Artikel_Obj" "gbS_Artikel" "S_Artikel_Obj" " "}
{adm/template/incl/sndkycas.i "Herk_Belegart" "E_BelegPos" "Herk_Belegart" " "}
{adm/template/incl/sndkycas.i "Herk_ReferenzNr" "E_BelegPos" "Herk_ReferenzNr" " "}
{adm/template/incl/sndkycas.i "Herk_PositionsNr" "E_BelegPos" "Herk_PositionsNr" " "}
{adm/template/incl/sndkycas.i "Firma" "E_BelegPos" "Firma" " "}
{adm/template/incl/sndkycas.i "ReferenzNr" "E_BelegPos" "ReferenzNr" " "}
{adm/template/incl/sndkycas.i "PositionsNr" "E_BelegPos" "PositionsNr" " "}
{adm/template/incl/sndkycas.i "BelegNummer" "E_BelegKopf" "BelegNummer" " "}
{adm/template/incl/sndkycas.i "ArtVar" "E_BelegPos" "ArtVar" " "}
{adm/template/incl/sndkycas.i "gueltig_ab" "E_BelegKopf" "Preisgueltigkeit" " "}
{adm/template/incl/sndkycas.i "Waehrung" "E_BelegKopf" "Waehrung" " "}
{adm/template/incl/sndkycas.i "$KEY" "E_BelegPos" " " "eink/incl/e_belpo.sl "}
{adm/template/incl/sndkycas.i "E_BelegPos_Obj" "E_BelegPos" "E_BelegPos_Obj" " "}
{adm/template/incl/sndkycas.i "Source_Obj" "E_BelegPos" "E_BelegPos_Obj" " "}
{adm/template/incl/sndkycas.i "E_BelegKopf_Obj" "E_BelegKopf" "E_BelegKopf_Obj" " "}
{adm/template/incl/sndkycas.i "PosObj" "E_BelegPos" "E_BelegPos_Obj" " "}
{adm/template/incl/sndkycas.i "Coverage_Obj" "E_BelegPos" "Coverage_Obj" " "}
{adm/template/incl/sndkycas.i "Origin_Obj" "E_BelegPos" "E_BelegPos_Obj" " "}
{adm/template/incl/sndkycas.i "ML_Lagergruppe_Obj" " " "gcMRPAreaObj" " "}
{adm/template/incl/sndkycas.i "S_ArtKunde_Obj" " " "gcSArtKundeObj" " "}
{adm/template/incl/sndkycas.i "MMM_CusRefOrder_Obj" "E_BelegPos" "MMM_CusRefOrder_Obj" " "}
{adm/template/incl/sndkycas.i "Driver_Obj" "E_BelegPos" "Driver_Obj" " "}
{adm/template/incl/sndkycas.i "Owning_Obj" "E_BelegPos" "E_BelegPos_Obj" " "}
{adm/template/incl/sndkycas.i "S_Kostenstelle_Obj" "E_BelegPos" "S_Kostenstelle_Obj" " "}
{adm/template/incl/sndkycas.i "Driver_Obj" "E_BelegKopf" "Driver_Obj" " "}
{adm/template/incl/sndkycas.i "S_Kostenstelle_Obj" "E_BelegKopf" "S_Kostenstelle_Obj" " "}
{adm/template/incl/sndkycas.i "SBM_ProfitCenter_Obj" "E_BelegKopf" "SBM_ProfitCenter_Obj" " "}
{adm/template/incl/sndkycas.i "SBM_TaxCase_Obj" "E_BelegKopf" "SBM_TaxCase_Obj" " "}
{adm/template/incl/sndkycas.i "SBM_FiscalText_Obj" "E_BelegKopf" "SBM_FiscalText_Obj" " "}
{adm/template/incl/sndkycas.i "uCI_Coverage_Obj" "E_BelegPos" "uCI_Coverage_Obj" " "}

/* Close the CASE statement and end the procedure.                            */

{adm/template/incl/sndkyend.i}

end procedure. /* send-key */

/* _UIB-CODE-BLOCK-END */
&ANALYZE-RESUME

&ANALYZE-SUSPEND _UIB-CODE-BLOCK _PROCEDURE send-records V-table-Win  adm/support/proc/ds_rec01.p
PROCEDURE send-records :
/* Description ---------------------------------------------------------------*/
/*                                                                            */
/* Send record ROWID's for all tables used by this file.                      */
/*                                                                            */
/* Parameters ----------------------------------------------------------------*/
/*                                                                            */
/* see template/incl/snd-head.i                                               */
/*                                                                            */
/*----------------------------------------------------------------------------*/

/*----------------------------------------------------------------------------*/
/* Processing                                                                 */
/*----------------------------------------------------------------------------*/

/* Define variables needed by this internal procedure.                        */

{adm/template/incl/snd-head.i}

/* For each requested table, put it's ROWID in the output list.               */

{adm/template/incl/snd-list.i "E_BelegPos"}
{adm/template/incl/snd-list.i "E_BelegKopf"}

/* Deal with any unexpected table requests before closing.                    */

{adm/template/incl/snd-end.i}

end procedure. /* send-records */

/* _UIB-CODE-BLOCK-END */
&ANALYZE-RESUME

&ANALYZE-SUSPEND _UIB-CODE-BLOCK _PROCEDURE state-changed V-table-Win 
PROCEDURE state-changed :
/* Description ---------------------------------------------------------------*/
/*                                                                            */
/* Handle state-changed messages                                              */
/*                                                                            */
/* Notes ---------------------------------------------------------------------*/
/*                                                                            */
/*                                                                            */
/*                                                                            */
/* Parameters ----------------------------------------------------------------*/
/*                                                                            */
/* p-issuer-hdl   Handle of calling object                                    */
/* p-state        new state                                                   */
/*                                                                            */
/* Examples ------------------------------------------------------------------*/
/*                                                                            */
/*                                                                            */
/*                                                                            */
/*----------------------------------------------------------------------------*/

define input        parameter p-issuer-hdl as handle        no-undo.
define input        parameter p-state      as character     no-undo.

/* Variables -----------------------------------------------------------------*/
/*----------------------------------------------------------------------------*/

define variable cPKS                       as character     no-undo.

&IF LOOKUP("JB":U,"{&PA-MODULE}":U) > 0 &THEN
  define variable cTmp                     as character     no-undo.
&ENDIF

/* Buffers -------------------------------------------------------------------*/

define buffer bE_ArtLief   for E_ArtLief.

/*----------------------------------------------------------------------------*/
/* Processing                                                                 */
/*----------------------------------------------------------------------------*/

  case p-state:

    /* Object instance CASEs can go here to replace standard behavior         */
    /* or add new cases.                                                      */

    when 'E_ArtLief_Anlegen':U then

      if    available E_BelegKopf
        and gcSatzart = 'A':U then
      do:

        find bE_ArtLief
          where bE_ArtLief.Firma     = {firma/e_artli.fir pa-Firma}
            and bE_ArtLief.Lieferant = E_BelegKopf.Lieferant
            and bE_ArtLief.Artikel   = E_BelegPos.Artikel:screen-value in frame {&Frame-Name}
          no-lock no-error.

        if not available bE_ArtLief then
        do:

          create bE_ArtLief.

          assign
            bE_ArtLief.Firma     = {firma/e_artli.fir pa-Firma}
            bE_ArtLief.Lieferant = E_BelegKopf.Lieferant
            bE_ArtLief.Artikel   = E_BelegPos.Artikel:screen-value in frame {&Frame-Name}
            .

          validate bE_ArtLief.

        end. /* if not available bE_ArtLief */

        assign
          cPKS = adm.method.cls.DMCParameterStringSvc:cWriteValue(cPKS,'Neuanlage':U,yes)
          cPKS = adm.method.cls.DMCParameterStringSvc:cWriteValue(cPKS,'E_ArtLief_Obj':U,bE_ArtLief.E_ArtLief_Obj)
          .

        {adm/incl/d__run01.if
          &Programm      = "eink/proc/e_pali01.w"
          &Link1         = "'record':U"
          &Source1       = "this-procedure"
          &Handle        = "ghE_ArtLief"
          &PKS           = "cPKS"
        }

      end. /* if    available E_BelegKopf */

    when 'button-Text-pressed':U then
    do:

      gcSatzart = 'T':U.

      run dispatch ('add-record':U).

    end. /* when 'button-Text-pressed':U */

    when 'button-value-pressed':U then
    do:

      assign
        gcSatzart      = 'A':U
        glWertposition = yes
        .

      run dispatch ('add-record':U).

    end. /* when 'button-value-pressed':U */

    when 'text-modified':U then
    do:

      run new-state ('text-modified,record-target':U).

      if    available E_BelegPos
        and E_BelegPos.Satzart = 'T':U
        and pa-fields-enabled then
      do:

        run dispatch ('update-record':U).

        if return-value = 'ADM-ERROR':U then
          return error.

      end. /* if available E_BelegPos */

    end. /* when 'text-modified':U */

    when 'SlaveMode':U then
      glSlaveMode = yes.

    &IF LOOKUP("JB":U,"{&PA-MODULE}":U) > 0 &THEN

      when 'Projekt':U then

        if lMenuProjekt() = yes then
        do:

          run proj/base/proc/jbpzuo10.w (       'Einkauf':U,
                                                E_BelegPos.E_BelegPos_Obj,
                                                no,
                                         output cTmp) no-error.

          if error-status:error then
            return.

          run new-state('refresh,group-assign-target':U).

          /* dispatch OK, da Felder geschlossen sind */

          run dispatch ('display-fields':U).

        end. /* if lMenuProjekt() */
    &ENDIF /* &IF LOOKUP("JB":U,"{&PA-MODULE}":U) > 0 */

    &IF LOOKUP("Q_DEL":U,"{&PA-OPTIONEN}":U) > 0 &THEN

      when 'UpdateMetals':U then
        glUpdateMetals = yes.

    &ENDIF

    &IF LOOKUP("Q_DEL":U,"{&PA-OPTIONEN}":U) > 0 &THEN

      when 'MetalSurchargeChanged':U then
        run new-state('MetalSurchargeChanged,group-assign-target':U).

    &ENDIF

    {adm/template/incl/dt_viw00.if}

  end case.
end procedure.

/* _UIB-CODE-BLOCK-END */
&ANALYZE-RESUME

/* ************************  Function Implementations ***************** */

&ANALYZE-SUSPEND _UIB-CODE-BLOCK _FUNCTION FelderEnablen V-table-Win
FUNCTION FelderEnablen RETURNS LOGICAL
  ( /* parameter-definitions */ ) :
/* Description ---------------------------------------------------------------*/
/*                                                                            */
/* It is not allowed to change a line with a following intra record.          */
/*                                                                            */
/* Notes ---------------------------------------------------------------------*/
/*                                                                            */
/*                                                                            */
/*                                                                            */
/* Parameters ----------------------------------------------------------------*/
/*                                                                            */
/* <none>                                                                     */
/*                                                                            */
/* Examples ------------------------------------------------------------------*/
/*                                                                            */
/*                                                                            */
/*                                                                            */
/*----------------------------------------------------------------------------*/

&IF lookup("E_Intra":U,"{&PA-OPTIONEN}":U) > 0 &THEN

  /*-----------------------------------------------------------------------*/
  /* Intrahandelsstatistik                                                 */
  /*-----------------------------------------------------------------------*/
  /* ein bereits gemeldeter Beleg kann nicht mehr bearbeitet werden.       */
  /*-----------------------------------------------------------------------*/

  if stamm.base.cls.SBCBusinessCategorySvc:prpoInstance:lHasCompanyIntraStatPurchasing(E_BelegKopf.Belegdatum) then

    case pACConnectionSvc:prpcLocalization:

      {&{&PA-XBasisName}_C_Intra_Check}
      {&{&PA-XBasisName}_U_Intra_Check}
      {&{&PA-XBasisName}_Q_Intra_Check}
      {&{&PA-XBasisName}_Intra_Check}
      {&{&PA-XBasisName}_Y_Intra_Check}

      otherwise
      do:

        if    available E_BelegPos
          and E_BelegPos.BelegArt = 'ERL':U
          and can-find (first S_IntraHandel
                 where S_IntraHandel.Firma            = E_BelegPos.Firma
                   and S_IntraHandel.Herk_BelegArt    = E_BelegPos.BelegArt
                   and S_IntraHandel.Herk_ReferenzNr  = E_BelegPos.ReferenzNr
                   and S_IntraHandel.Herk_LfdNr_SR    = 0
                   and S_IntraHandel.Herk_PositionsNr = E_BelegPos.PositionsNr) then
        do
          on error undo, return no:

          adm.method.cls.DMCMessageSvc:prpoInstance:showError
            ('e_bel00008':U).

        end. /* if    available E_BelegPos */

      end. /* otherwise */

    end case. /* pACConnectionSvc:prpcLocalization */

&ENDIF /* &IF lookup("E_Intra":U,"{&PA-OPTIONEN}":U) > 0 */



return yes.

END FUNCTION.

/* _UIB-CODE-BLOCK-END */
&ANALYZE-RESUME

&ANALYZE-SUSPEND _UIB-CODE-BLOCK _FUNCTION lMenuProjekt V-table-Win
FUNCTION lMenuProjekt RETURNS LOGICAL
  ( /* parameter-definitions */ ) :

/*------------------------------------------------------------------------------
  Purpose: Ermittelt, ob eine Pflege der Projektzuordnung �ber Menu m�glich ist
    Notes: Funktion operiert auf globalem Buffer E_BelegPos
------------------------------------------------------------------------------*/

&IF LOOKUP("JB":U,"{&PA-MODULE}":U) > 0 &THEN

  if not pa-fields-enabled
    and available E_BelegPos
    and E_BelegPos.Satzart = 'A':U
    and E_BelegPos.offen   = yes
    and can-do ('EAB,EB,ERL':U,E_BelegPos.Belegart) then

    return yes.
  else
&ENDIF
    return no.

END FUNCTION.

/* _UIB-CODE-BLOCK-END */
&ANALYZE-RESUME

