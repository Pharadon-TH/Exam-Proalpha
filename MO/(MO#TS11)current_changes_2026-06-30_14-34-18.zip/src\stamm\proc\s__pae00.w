&ANALYZE-SUSPEND _VERSION-NUMBER UIB_v8r12 GUI
&ANALYZE-RESUME
&Scoped-define WINDOW-NAME CURRENT-WINDOW
&Scoped-define FRAME-NAME Dialog-Frame

&ANALYZE-SUSPEND _UIB-CODE-BLOCK _CUSTOM _DECLARATIONS Dialog-Frame 

/* _UIB-CODE-BLOCK-END */
&ANALYZE-RESUME


&ANALYZE-SUSPEND _UIB-CODE-BLOCK _XFTR "Update Information" Dialog-Frame _INLINE
/* Actions: ? ? ? ? adm/support/proc/ds_pa_01.w */

/* _UIB-CODE-BLOCK-END */
&ANALYZE-RESUME

&ANALYZE-SUSPEND _UIB-CODE-BLOCK _CUSTOM _DEFINITIONS Dialog-Frame 
/*****************************************************************************/
/* @COPYRIGHT@                                                               */
/*                                                                           */
/*  Projekt....: Proalpha                                                    */
/*                                                                           */
/*  Name.......: s__pae00.w                                                  */
/*  Bereich....: STAMM/KERN                                                  */
/*                                                                           */
/*  erstellt am: 23.07.1997                                                  */
/*  Autor......: Michael Schmidt                                             */
/*                                                                           */
/*  Version....: @PAVERSION@ vom @PADATE@/@PALASTAUTHOR@                     */
/*                                                                           */
/*---------------------------------------------------------------------------*/
/*  AUFGABE                                                                  */
/*---------------------------------------------------------------------------*/
/*                                                                           */
/*  �nderungen zwischen zwei Preisgruppen                                    */
/*                                                                           */
/*---------------------------------------------------------------------------*/
/*  ARGUMENTE/PARAMETER                                                      */
/*---------------------------------------------------------------------------*/
/*                                                                           */
/*  Name                Art Funktion/Inhalt                                  */
/*  ------------------- --- ------------------------------------------------ */
/*---------------------------------------------------------------------------*/
/*  �NDERUNGSPROTOKOLL                                                       */
/*---------------------------------------------------------------------------*/
/* @FILEHISTORY@                                                             */
/*****************************************************************************/

/*----------------------------------------------------------------------     */
/*          This .W file was created with the Progress UIB.                  */
/*----------------------------------------------------------------------     */

/* Create an unnamed pool to store all the widgets created
     by this procedure. This is a good default which assures
     that this procedure's triggers and internal procedures
     will execute in this procedure's storage, and that proper
     cleanup will occur on deletion of the procedure. */

CREATE WIDGET-POOL.

/*---------------------------------------------------------------------------*/
/* Definitionen                                                              */
/*---------------------------------------------------------------------------*/

/* KONSTANTEN ---------------------------------------------------------------*/
/* Systemkonstanten **********************************************************/

&GLOBAL-DEFINE pa-Autor             Michael Schmidt
&GLOBAL-DEFINE pa-Version           @PAVERSION@
&GLOBAL-DEFINE pa-Datum             @PADATE@
&GLOBAL-DEFINE pa-Letzter           @PALASTAUTHOR@

&GLOBAL-DEFINE pa-GenVersion       UIB
&GLOBAL-DEFINE pa-ProgrammTyp      PrintDialog
&GLOBAL-DEFINE pa-Template         adm/template/dt_dlg02.w
&GLOBAL-DEFINE pa-TemplateVersion  1.03

&GLOBAL-DEFINE pa-XBasisName       s__pae00_w


/* lokale Konstanten *********************************************************/

&GLOBAL-DEFINE pa-ZielProgramm 's_vpae01.p':U
&GLOBAL-DEFINE pa-SMArt        'SAR':U
&GLOBAL-DEFINE pa-SMLFirma     firma/sartikel.fir

&SCOP   PA-HLP-InitialHelpString gcInitialHelpString

&SCOP   pa-hlp-keynames    Suchbegriff,Suchbegriff,Selektion,Selektion,Preisgruppe,Preisgruppe
&SCOP   pa-hlp-fieldnames  ArtGrpSuchbegriff_min,ArtGrpSuchbegriff_max,ArtGrpSelektion_min,~
ArtGrpSelektion_max,Preisgruppe_alt_var,Preisgruppe_neu_var

/* EXTERNE DEFINITIONEN -----------------------------------------------------*/

{adm/template/incl/dt_dlg01.df}

/* LOKALE OBJEKTE -----------------------------------------------------------*/
/* Variable ******************************************************************/
/*   Name               Funktion                                             */
/*   ------------------ ---------------------------------------------------- */
/*****************************************************************************/

define variable gcBenutzer          as char format 'x(10)':U no-undo.
define variable glAenderung         as logical               no-undo.
define variable gcInitialHelpString as character             no-undo.

/* Buffer ********************************************************************/

/* Work-/Temp-Tables *********************************************************/

/* _UIB-CODE-BLOCK-END */
&ANALYZE-RESUME


&ANALYZE-SUSPEND _UIB-PREPROCESSOR-BLOCK

/* ********************  Preprocessor Definitions  ******************** */

&Scoped-define PROCEDURE-TYPE DIALOG-BOX
&Scoped-define DB-AWARE no

/* Name of designated FRAME-NAME and/or first browse and/or first query */
&Scoped-define FRAME-NAME Dialog-Frame

/* --> MO#DIETZ-SFL-0010 thongdi_p 29/06/2026 V�nderung Kundensonderpreise */ 
/* Standard List Definitions                                            */
/* Add xKundensonderpreise in &Scoped-Define ENABLED-OBJECTS and &Scoped-Define DISPLAYED-OBJECTS */
&Scoped-Define ENABLED-OBJECTS ArtikelGruppe_min ArtikelGruppe_max ~
ArtGrpSuchbegriff_min ArtGrpSuchbegriff_max ArtGrpSelektion_min ~
ArtGrpSelektion_max Artikel_min Artikel_max Selektion_min Selektion_max ~
Selektion_var Preisgruppe_alt_var gueltig_ab_alt_var Preisgruppe_neu_var ~
gueltig_ab_neu_var gueltig_bis_neu_var Zuschlag_var lZuschlagsart_var ~
Rundungswert_var AenderungsGrund_var Bemerkung_var Btn_Start Btn_Cancel ~
xKundensonderpreise ~
Btn_SML Btn_Help
&Scoped-Define DISPLAYED-OBJECTS ArtikelGruppe_min ArtikelGruppe_max ~
ArtGrpSuchbegriff_min ArtGrpSuchbegriff_max ArtGrpSelektion_min ~
ArtGrpSelektion_max Artikel_min Artikel_max Selektion_min Selektion_max ~
Selektion_var Preisgruppe_alt_var Preisgruppe_alt_var_Info ~
gueltig_ab_alt_var gueltig_ab_alt_var_Info Preisgruppe_neu_var ~
Preisgruppe_neu_var_Info gueltig_ab_neu_var gueltig_ab_neu_var_Info ~
gueltig_bis_neu_var gueltig_bis_neu_var_Info Zuschlag_var lZuschlagsart_var ~
Rundungswert_var AenderungsGrund_var AenderungsGrund_var_Info Bemerkung_var ~
xKundensonderpreise ~
c_bis c_von
/* <-- MO#DIETZ-SFL-0010 thongdi_p 29/06/2026 V�nderung Kundensonderpreise */ 

/* Custom List Definitions                                              */
/* List-1,List-2,List-3,List-4,List-5,List-6                            */

/* _UIB-PREPROCESSOR-BLOCK-END */
&ANALYZE-RESUME


&ANALYZE-SUSPEND _UIB-CODE-BLOCK _XFTR "InfoFields" Dialog-Frame _INLINE
/* Actions: ? ? ? ? adm/support/proc/ds_inf01.p */
/* STRUCTURED-DATA
<Build-Information>
1.02
</Build-Information>
<Constants>
***/
/***
</Constants>
<InfoFields>
Preisgruppe_alt_var|Text|Basis.S_PreisGruppeSpr.Bezeichnung|S_PreisGruppeSpr.Firma = {firma/spreisgr.fir pa-Firma};S_PreisGruppeSpr.Preisgruppe = input frame {&Frame-Name} Preisgruppe_alt_var|Preisgruppe_alt_var_Info
Preisgruppe_neu_var|Text|Basis.S_PreisGruppeSpr.Bezeichnung|S_PreisGruppeSpr.Firma = {firma/spreisgr.fir pa-Firma};S_PreisGruppeSpr.Preisgruppe = input frame {&Frame-Name} Preisgruppe_neu_var|Preisgruppe_neu_var_Info 
AenderungsGrund_var|Text|Basis.BB_AenderungsGrundSpr.Bezeichnung|BB_AenderungsGrundSpr.Firma = {firma/sartikel.fir pa-Firma};BB_AenderungsGrundSpr.DRC_Table_ID = 'S_Artikel':U;BB_AenderungsGrundSpr.AenderungsGrund = input frame {&Frame-Name} AenderungsGrund_var|AenderungsGrund_var_Info
gueltig_ab_alt_var|day|||gueltig_ab_alt_var_Info
gueltig_ab_neu_var|day|||gueltig_ab_neu_var_Info
gueltig_bis_neu_var|day|||gueltig_bis_neu_var_Info
</InfoFields> */
/* _UIB-CODE-BLOCK-END */
&ANALYZE-RESUME

&ANALYZE-SUSPEND _UIB-CODE-BLOCK _XFTR "FieldDefinitions" Dialog-Frame _INLINE
/* Actions: ? ? ? ? adm/support/proc/ds_dlg01.p */
/* STRUCTURED-DATA
<DATA>
S_ArtGruppe.ArtikelGruppe|ArtikelGruppe_min|ArtikelGruppe_max||S_ArtGruppe.Firma = {firma/sartgrp.fir pa-Firma};use-index Main
S_Artikel.Artikel|Artikel_min|Artikel_max||S_Artikel.Firma = {firma/sartikel.fir pa-Firma};use-index Main
S_Artikel.Selektion|Selektion_min|Selektion_max|Selektion_var|S_Artikel.Firma = {firma/sartikel.fir pa-Firma};use-index Selekt
Preisgruppe_alt|||Preisgruppe_alt_var|NO SELECTION
Preisgruppe_neu|||Preisgruppe_neu_var|NO SELECTION
Zuschlag|||Zuschlag_var|NO SELECTION
Rundungswert|||Rundungswert_var|NO SELECTION
BB_AenderungsGrund.AenderungsGrund|||AenderungsGrund_var|NO SELECTION
Bemerkung|||Bemerkung_var|NO SELECTION
S_ArtPreiseDatum.AnlageDatum|||gueltig_ab_alt_var|NO SELECTION||
S_ArtPreiseDatum.gueltig_ab|||gueltig_ab_neu_var|NO SELECTION||
S_ArtPreiseDatum.gueltig_bis|||gueltig_bis_neu_var|NO SELECTION||
lZuschlagsart|||lZuschlagsart_var|NO SELECTION|logical|yes/no
</DATA>
<FRAME>
****/
define frame f_dummy
  S_ArtGruppe.ArtikelGruppe view-as fill-in skip
  S_Artikel.Artikel view-as fill-in skip
  S_Artikel.Selektion view-as fill-in skip
  BB_AenderungsGrund.AenderungsGrund view-as fill-in skip
  S_ArtPreiseDatum.AnlageDatum view-as fill-in skip
  S_ArtPreiseDatum.gueltig_ab view-as fill-in skip
  S_ArtPreiseDatum.gueltig_bis view-as fill-in skip
with side-labels width 255 stream-io.
/****
</FRAME> */
/* _UIB-CODE-BLOCK-END */
&ANALYZE-RESUME

&ANALYZE-SUSPEND _UIB-CODE-BLOCK _XFTR "Skin Client Support" Dialog-Frame _INLINE
/* Actions: ? ? ? ? adm/support/proc/ds_skc00.p */
/* _UIB-CODE-BLOCK-END */
&ANALYZE-RESUME


/* ***********************  Control Definitions  ********************** */

/* Define a dialog box                                                  */

/* Definitions of the field level widgets                               */
DEFINE BUTTON Btn_Cancel AUTO-END-KEY 
     LABEL "&Abbruch":T8 
     SIZE 12 BY 1.

DEFINE BUTTON Btn_Help 
     LABEL "&Hilfe":T8 
     SIZE 12 BY 1.

DEFINE BUTTON Btn_SML 
     LABEL "&MML":T8 
     SIZE 12 BY 1.

DEFINE BUTTON Btn_Start AUTO-GO 
     LABEL "&OK":T12 
     SIZE 12 BY 1.

DEFINE VARIABLE AenderungsGrund_var AS INTEGER FORMAT "zz9":U INITIAL 0 
     LABEL "�nderungsgrund":R18 
     VIEW-AS FILL-IN 
     SIZE 4 BY 1 NO-UNDO.

DEFINE VARIABLE AenderungsGrund_var_Info AS CHARACTER FORMAT "x(30)":U 
     VIEW-AS FILL-IN 
     SIZE 36 BY 1 NO-UNDO.

DEFINE VARIABLE ArtGrpSelektion_max AS CHARACTER FORMAT "x(20)":U 
     VIEW-AS FILL-IN 
     SIZE 16 BY 1 NO-UNDO.

DEFINE VARIABLE ArtGrpSelektion_min AS CHARACTER FORMAT "x(20)":U 
     LABEL "Selektion TeilGr":R18 
     VIEW-AS FILL-IN 
     SIZE 16 BY 1 NO-UNDO.

DEFINE VARIABLE ArtGrpSuchbegriff_max AS CHARACTER FORMAT "x(12)":U 
     VIEW-AS FILL-IN 
     SIZE 16 BY 1 NO-UNDO.

DEFINE VARIABLE ArtGrpSuchbegriff_min AS CHARACTER FORMAT "x(12)":U 
     LABEL "Suchbegriff TeilGr":R18 
     VIEW-AS FILL-IN 
     SIZE 16 BY 1 NO-UNDO.

DEFINE VARIABLE Artikel_max LIKE S_Artikel.Artikel 
     VIEW-AS FILL-IN 
     SIZE 24 BY 1 NO-UNDO.

DEFINE VARIABLE Artikel_min LIKE S_Artikel.Artikel 
     LABEL "Teil":R18 
     VIEW-AS FILL-IN 
     SIZE 24 BY 1 NO-UNDO.

DEFINE VARIABLE ArtikelGruppe_max AS CHARACTER FORMAT "x(6)":U 
     VIEW-AS FILL-IN 
     SIZE 12 BY 1 NO-UNDO.

DEFINE VARIABLE ArtikelGruppe_min AS CHARACTER FORMAT "x(6)":U 
     LABEL "Teilegruppe":R18 
     VIEW-AS FILL-IN 
     SIZE 12 BY 1 NO-UNDO.

DEFINE VARIABLE Bemerkung_var AS CHARACTER FORMAT "x(30)":U 
     LABEL "Bemerkung":R18 
     VIEW-AS FILL-IN 
     SIZE 40 BY 1 NO-UNDO.

DEFINE VARIABLE c_bis AS CHARACTER FORMAT "X(256)":U 
      VIEW-AS TEXT 
     SIZE 14 BY .63 NO-UNDO.

DEFINE VARIABLE c_von AS CHARACTER FORMAT "X(256)":U 
      VIEW-AS TEXT 
     SIZE 14 BY .63 NO-UNDO.

DEFINE VARIABLE gueltig_ab_alt_var AS DATE FORMAT "99.99.9999":U 
     LABEL "g�ltig am":R18 
     VIEW-AS FILL-IN 
     SIZE 12 BY 1 NO-UNDO.

DEFINE VARIABLE gueltig_ab_alt_var_Info AS CHARACTER FORMAT "x(256)":U 
     VIEW-AS FILL-IN 
     SIZE 4 BY 1 NO-UNDO.

DEFINE VARIABLE gueltig_ab_neu_var AS DATE FORMAT "99.99.9999":U 
     LABEL "g�ltig ab":R18 
     VIEW-AS FILL-IN 
     SIZE 12 BY 1 NO-UNDO.

DEFINE VARIABLE gueltig_ab_neu_var_Info AS CHARACTER FORMAT "x(256)":U 
     VIEW-AS FILL-IN 
     SIZE 4 BY 1 NO-UNDO.

DEFINE VARIABLE gueltig_bis_neu_var AS DATE FORMAT "99.99.9999":U 
     LABEL "g�ltig bis":R18 
     VIEW-AS FILL-IN 
     SIZE 12 BY 1 NO-UNDO.

DEFINE VARIABLE gueltig_bis_neu_var_Info AS CHARACTER FORMAT "x(256)":U 
     VIEW-AS FILL-IN 
     SIZE 4 BY 1 NO-UNDO.

DEFINE VARIABLE Preisgruppe_alt_var AS CHARACTER FORMAT "x(6)":U 
     LABEL "Preisliste alt":R18 
     VIEW-AS FILL-IN 
     SIZE 12 BY 1 NO-UNDO.

DEFINE VARIABLE Preisgruppe_alt_var_Info AS CHARACTER FORMAT "x(30)":U 
     VIEW-AS FILL-IN 
     SIZE 28 BY 1 NO-UNDO.

DEFINE VARIABLE Preisgruppe_neu_var AS CHARACTER FORMAT "x(6)":U 
     LABEL "Preisliste neu":R18 
     VIEW-AS FILL-IN 
     SIZE 12 BY 1 NO-UNDO.

DEFINE VARIABLE Preisgruppe_neu_var_Info AS CHARACTER FORMAT "x(30)":U 
     VIEW-AS FILL-IN 
     SIZE 28 BY 1 NO-UNDO.
     
/* --> MO#DIETZ-SFL-0010 thongdi_p 29/06/2026 V�nderung Kundensonderpreise */

define variable xKundensonderpreise as logical
     label 'Kundensonderpreise' 
     view-as toggle-box
     size 24 by 1 no-undo.
     
/* <-- MO#DIETZ-SFL-0010 thongdi_p 29/06/2026 V�nderung Kundensonderpreise */     

DEFINE VARIABLE Rundungswert_var AS DECIMAL FORMAT "zzz9.9":U INITIAL 0 
     LABEL "Rundungswert":R18 
     VIEW-AS FILL-IN 
     SIZE 8 BY 1 NO-UNDO.

DEFINE VARIABLE Selektion_max AS CHARACTER FORMAT "x(20)":U 
     VIEW-AS FILL-IN 
     SIZE 24 BY 1 NO-UNDO.

DEFINE VARIABLE Selektion_min AS CHARACTER FORMAT "x(20)":U 
     LABEL "Selektion Teil":R18 
     VIEW-AS FILL-IN 
     SIZE 24 BY 1 NO-UNDO.

DEFINE VARIABLE Selektion_var AS CHARACTER FORMAT "x(20)":U 
     LABEL "Selektion Teil":R18 
     VIEW-AS FILL-IN 
     SIZE 24 BY 1 NO-UNDO.

DEFINE VARIABLE Zuschlag_var AS DECIMAL FORMAT "zzz,zz9.99-":U INITIAL 0 
     LABEL "Zu-/Abschlag":R18 
     VIEW-AS FILL-IN 
     SIZE 16 BY 1 NO-UNDO.

DEFINE VARIABLE lZuschlagsart_var AS LOGICAL 
     VIEW-AS RADIO-SET VERTICAL 
     RADIO-BUTTONS 
          "wertm��ig":L18, yes, 
"prozentual":L18, no 
     SIZE 20 BY 2 NO-UNDO.


/* ************************  Frame Definitions  *********************** */

DEFINE FRAME Dialog-Frame
     ArtikelGruppe_min AT ROW 2.5 COL 21 COLON-ALIGNED
     ArtikelGruppe_max AT ROW 2.5 COL 69 COLON-ALIGNED NO-LABEL
     ArtGrpSuchbegriff_min AT ROW 3.5 COL 21 COLON-ALIGNED
     ArtGrpSuchbegriff_max AT ROW 3.5 COL 69 COLON-ALIGNED NO-LABEL
     ArtGrpSelektion_min AT ROW 4.5 COL 21 COLON-ALIGNED
     ArtGrpSelektion_max AT ROW 4.5 COL 69 COLON-ALIGNED NO-LABEL
     Artikel_min AT ROW 5.5 COL 21 COLON-ALIGNED
     Artikel_max AT ROW 5.5 COL 69 COLON-ALIGNED NO-LABEL
     Selektion_min AT ROW 6.5 COL 21 COLON-ALIGNED
     Selektion_max AT ROW 6.5 COL 69 COLON-ALIGNED NO-LABEL
     Selektion_var AT ROW 7.5 COL 21 COLON-ALIGNED
     Preisgruppe_alt_var AT ROW 9 COL 21 COLON-ALIGNED
     Preisgruppe_alt_var_Info AT ROW 9 COL 33 COLON-ALIGNED NO-LABEL
     gueltig_ab_alt_var AT ROW 9 COL 81 COLON-ALIGNED
     gueltig_ab_alt_var_Info AT ROW 9 COL 93 COLON-ALIGNED NO-LABEL
     Preisgruppe_neu_var AT ROW 10 COL 21 COLON-ALIGNED
     Preisgruppe_neu_var_Info AT ROW 10 COL 33 COLON-ALIGNED NO-LABEL
     
     /* --> MO#DIETZ-SFL-0010 thongdi_p 29/06/2026 V�nderung Kundensonderpreise */
     xKundensonderpreise at row 11.5 col 21 
     /* <-- MO#DIETZ-SFL-0010 thongdi_p 29/06/2026 V�nderung Kundensonderpreise */
     
     gueltig_ab_neu_var AT ROW 10 COL 81 COLON-ALIGNED
     gueltig_ab_neu_var_Info AT ROW 10 COL 93 COLON-ALIGNED NO-LABEL
     gueltig_bis_neu_var AT ROW 11 COL 81 COLON-ALIGNED
     gueltig_bis_neu_var_Info AT ROW 11 COL 93 COLON-ALIGNED NO-LABEL
     Zuschlag_var AT ROW 13 COL 21 COLON-ALIGNED
     lZuschlagsart_var AT ROW 13 COL 79 NO-LABEL
     Rundungswert_var AT ROW 14 COL 21 COLON-ALIGNED
     AenderungsGrund_var AT ROW 15.5 COL 21 COLON-ALIGNED
     AenderungsGrund_var_Info AT ROW 15.5 COL 25 COLON-ALIGNED NO-LABEL
     Bemerkung_var AT ROW 16.5 COL 21 COLON-ALIGNED
     Btn_Start AT ROW 19 COL 2
     Btn_Cancel AT ROW 19 COL 15
     Btn_SML AT ROW 19 COL 31
     Btn_Help AT ROW 19 COL 83
     c_bis AT ROW 1.5 COL 69 COLON-ALIGNED NO-LABEL
     c_von AT ROW 1.58 COL 21 COLON-ALIGNED NO-LABEL
     SPACE(63.99) SKIP(18.82)
    WITH VIEW-AS DIALOG-BOX KEEP-TAB-ORDER
         SIDE-LABELS NO-UNDERLINE THREE-D  SCROLLABLE
         TITLE "�nderungen zwischen zwei Preislisten":T60
         DEFAULT-BUTTON Btn_Start CANCEL-BUTTON Btn_Cancel.


/* *********************** Procedure Settings ************************ */

&ANALYZE-SUSPEND _PROCEDURE-SETTINGS
/* Settings for THIS-PROCEDURE
   Type: DIALOG-BOX
   Allow: Basic,DB-Fields
 */
&ANALYZE-RESUME _END-PROCEDURE-SETTINGS

&ANALYZE-SUSPEND _UIB-CODE-BLOCK _CUSTOM _INCLUDED-LIB Dialog-Frame 
/* ************************* Included-Libraries *********************** */

{adm/method/incl/dm_dlg00.lib}

/* _UIB-CODE-BLOCK-END */
&ANALYZE-RESUME




/* ***********  Runtime Attributes and AppBuilder Settings  *********** */

&ANALYZE-SUSPEND _RUN-TIME-ATTRIBUTES
/* SETTINGS FOR DIALOG-BOX Dialog-Frame
   FRAME-NAME L-To-R                                                    */
ASSIGN
       FRAME Dialog-Frame:SCROLLABLE       = FALSE
       FRAME Dialog-Frame:HIDDEN           = TRUE.

/* SETTINGS FOR FILL-IN AenderungsGrund_var_Info IN FRAME Dialog-Frame
   NO-ENABLE                                                            */
/* SETTINGS FOR FILL-IN c_bis IN FRAME Dialog-Frame
   NO-ENABLE                                                            */
/* SETTINGS FOR FILL-IN c_von IN FRAME Dialog-Frame
   NO-ENABLE                                                            */
/* SETTINGS FOR FILL-IN gueltig_ab_alt_var_Info IN FRAME Dialog-Frame
   NO-ENABLE                                                            */
/* SETTINGS FOR FILL-IN gueltig_ab_neu_var_Info IN FRAME Dialog-Frame
   NO-ENABLE                                                            */
/* SETTINGS FOR FILL-IN gueltig_bis_neu_var_Info IN FRAME Dialog-Frame
   NO-ENABLE                                                            */
/* SETTINGS FOR FILL-IN Preisgruppe_alt_var_Info IN FRAME Dialog-Frame
   NO-ENABLE                                                            */
/* SETTINGS FOR FILL-IN Preisgruppe_neu_var_Info IN FRAME Dialog-Frame
   NO-ENABLE                                                            */
/* _RUN-TIME-ATTRIBUTES-END */
&ANALYZE-RESUME





/* ************************  Control Triggers  ************************ */

&Scoped-define SELF-NAME Dialog-Frame


&Scoped-define SELF-NAME AenderungsGrund_var
&ANALYZE-SUSPEND _UIB-CODE-BLOCK _CONTROL AenderungsGrund_var Dialog-Frame
ON LEAVE OF AenderungsGrund_var IN FRAME Dialog-Frame /* �nderungsgrund */
do:
  {adm/template/incl/dt_uit00.if
     &UserExitName = "ON_LEAVE_OF_AenderungsGrund_var"}

  {adm/template/incl/dt_viw03.if}

  {adm/template/incl/dt_uit01.if
     &UserExitName = "ON_LEAVE_OF_AenderungsGrund_var"}
end.

/* _UIB-CODE-BLOCK-END */
&ANALYZE-RESUME


&Scoped-define SELF-NAME ArtGrpSelektion_min
&ANALYZE-SUSPEND _UIB-CODE-BLOCK _CONTROL ArtGrpSelektion_min Dialog-Frame
ON LEAVE OF ArtGrpSelektion_min IN FRAME Dialog-Frame /* Selektion TeilGr */
DO:
  {adm/template/incl/dt_uit00.if
     &UserExitName = "ON_LEAVE_OF_ArtGrpSelektion_min"}

  {adm/template/incl/dt_dlg00.if &MAX-FELD = "ArtGrpSelektion_max"}

  {adm/template/incl/dt_uit01.if
     &UserExitName = "ON_LEAVE_OF_ArtGrpSelektion_min"}
END.

/* _UIB-CODE-BLOCK-END */
&ANALYZE-RESUME


&Scoped-define SELF-NAME ArtGrpSuchbegriff_min
&ANALYZE-SUSPEND _UIB-CODE-BLOCK _CONTROL ArtGrpSuchbegriff_min Dialog-Frame
ON LEAVE OF ArtGrpSuchbegriff_min IN FRAME Dialog-Frame /* Suchbegriff TeilGr */
DO:
  {adm/template/incl/dt_uit00.if
     &UserExitName = "ON_LEAVE_OF_ArtGrpSuchbegriff_min"}

  {adm/template/incl/dt_dlg00.if &MAX-FELD = "ArtGrpSuchbegriff_max"}

  {adm/template/incl/dt_uit01.if
     &UserExitName = "ON_LEAVE_OF_ArtGrpSuchbegriff_min"}
END.

/* _UIB-CODE-BLOCK-END */
&ANALYZE-RESUME


&Scoped-define SELF-NAME Artikel_min
&ANALYZE-SUSPEND _UIB-CODE-BLOCK _CONTROL Artikel_min Dialog-Frame
ON leave OF Artikel_min IN FRAME Dialog-Frame /* Teil */
DO:
  {adm/template/incl/dt_uit00.if
     &UserExitName = "ON_LEAVE_OF_Artikel_min"}

  {adm/template/incl/dt_dlg00.if &MAX-FELD = "Artikel_max"}

  {adm/template/incl/dt_uit01.if
     &UserExitName = "ON_LEAVE_OF_Artikel_min"}
END.

/* _UIB-CODE-BLOCK-END */
&ANALYZE-RESUME


&Scoped-define SELF-NAME ArtikelGruppe_min
&ANALYZE-SUSPEND _UIB-CODE-BLOCK _CONTROL ArtikelGruppe_min Dialog-Frame
ON leave OF ArtikelGruppe_min IN FRAME Dialog-Frame /* Teilegruppe */
DO:
  {adm/template/incl/dt_uit00.if
     &UserExitName = "ON_LEAVE_OF_ArtikelGruppe_min"}

  {adm/template/incl/dt_dlg00.if &MAX-FELD = "ArtikelGruppe_max"}

  {adm/template/incl/dt_uit01.if
     &UserExitName = "ON_LEAVE_OF_ArtikelGruppe_min"}
END.

/* _UIB-CODE-BLOCK-END */
&ANALYZE-RESUME


&Scoped-define SELF-NAME Btn_Help
&ANALYZE-SUSPEND _UIB-CODE-BLOCK _CONTROL Btn_Help Dialog-Frame
ON CHOOSE OF Btn_Help IN FRAME Dialog-Frame /* Hilfe */
DO:
  {adm/template/incl/dt_uit00.if
     &UserExitName = "ON_CHOOSE_OF_Btn_Help"}

  {adm/template/incl/dt_btn00.if}

  {adm/template/incl/dt_uit01.if
     &UserExitName = "ON_CHOOSE_OF_Btn_Help"}
END.

/* _UIB-CODE-BLOCK-END */
&ANALYZE-RESUME


&Scoped-define SELF-NAME Btn_SML
&ANALYZE-SUSPEND _UIB-CODE-BLOCK _CONTROL Btn_SML Dialog-Frame
ON CHOOSE OF Btn_SML IN FRAME Dialog-Frame /* MML */
DO:
  {adm/template/incl/dt_uit00.if
     &UserExitName = "ON_CHOOSE_OF_Btn_SML"}

  {adm/template/incl/dt_btn03.if}

  {adm/template/incl/dt_uit01.if
     &UserExitName = "ON_CHOOSE_OF_Btn_SML"}
END.

/* _UIB-CODE-BLOCK-END */
&ANALYZE-RESUME


&Scoped-define SELF-NAME Btn_Start
&ANALYZE-SUSPEND _UIB-CODE-BLOCK _CONTROL Btn_Start Dialog-Frame
ON CHOOSE OF Btn_Start IN FRAME Dialog-Frame /* OK */
DO:
  
  /* --> MO#DIETZ-SFL-0010 thongdi_p 29/06/2026 V�nderung Kundensonderpreise */
  if input frame {&frame-name} xKundensonderpreise = no then
  do:
  /* <-- MO#DIETZ-SFL-0010 thongdi_p 29/06/2026 V�nderung Kundensonderpreise */
       
    /* Pr�fung "g�ltig ab alt"-Datum */
  
    {adm/template/incl/dt_uit00.if
       &UserExitName = "ON_CHOOSE_OF_Btn_Start"}
  
    if input frame {&frame-name} gueltig_ab_alt_var = ? then do:
  
      {adm/incl/d__msg00.if
        &Meldung = "'s_pfi00004':U"
      }
      {returnnoapply}.
  
    end.
  
    /* Pr�fung "g�ltig ab neu"-Datum  ek  */
  
    if input frame {&frame-name} gueltig_ab_neu_var = ? then do:
  
      {adm/incl/d__msg00.if
        &Meldung = "'s_pfi00003':U"
      }
      {returnnoapply}.
  
    end.
  
  
    &IF "{&PA_BB_MANAEG}":U = "1":U &THEN
  
      /* Pr�fung �nderungsgrund */
  
      if not can-find(BB_Aenderungsgrund
        where BB_Aenderungsgrund.Firma           = {firma/sartikel.fir pa-firma}
          and BB_Aenderungsgrund.Aenderungsgrund = input frame {&frame-name} AenderungsGrund_var
          and BB_Aenderungsgrund.DRC_Table_ID    = 'S_Artikel':U)
        and glAenderung = yes then do:
  
        {adm/incl/d__msg00.if
          &Meldung = "'s_pfi00002':U"
          &Liste   = "string(input frame {&frame-name} AenderungsGrund_var)"
        }
        {returnnoapply}.
  
      end.
  
    &ENDIF
  
    /* Pr�fung Preisliste */
  
    if not can-find(S_Preisgruppe
      where S_Preisgruppe.Firma       = {firma/spreisgr.fir pa-firma}
        and S_Preisgruppe.Preisgruppe = input frame {&frame-name} Preisgruppe_alt_var) then do:
  
      {adm/incl/d__msg00.if
        &Meldung = "'s_trg00126':U"
        &Liste   = "input frame {&frame-name} PreisGruppe_alt_var"
      }
      {returnnoapply}.
  
    end.
  
    if not can-find(S_Preisgruppe
      where S_Preisgruppe.Firma       = {firma/spreisgr.fir pa-firma}
        and S_Preisgruppe.Preisgruppe = input frame {&frame-name} Preisgruppe_neu_var) then do:
  
      {adm/incl/d__msg00.if
        &Meldung = "'s_trg00126':U"
        &Liste   = "input frame {&frame-name} PreisGruppe_neu_var"
      }
      {returnnoapply}.
  
    end.
  
    /* Pr�fung, ob g�ltig bis >= g�ltig ab --------------------------------------*/
  
    if input frame {&Frame-Name} gueltig_bis_neu_var <
       input frame {&Frame-Name} gueltig_ab_neu_var then do:
  
      {adm/incl/d__msg00.if
        &Meldung = "'s_art00023':U"
      }
      {returnnoapply}.
  
    end. /* if gueltig_bis < gueltig_ab */
  
    /* Pr�fung, ob �nderung einer Preisliste auf sich selbst -------------------------*/
  
    /* Bei der neuen Preisliste wird �berpr�ft, ob schon Daten vorhanden sind.        */
    /* Ist dies der Fall, so werden die vorhandenen Daten gel�scht, bevor neue        */
    /* Daten erzeugt werden. Genau diese (jetzt gel�schten) Daten sind aber die Basis */
    /* (alte Preisliste) zur Erzeugung der neuen Preisliste.                          */
  
    if input frame {&frame-name} gueltig_ab_alt_var     = input frame {&frame-name} gueltig_ab_neu_var
      and input frame {&frame-name} Preisgruppe_alt_var = input frame {&frame-name} Preisgruppe_neu_var then do:
  
      {adm/incl/d__msg00.if
        &Meldung = "'s_trg00229':U"
        &Liste   = "input frame {&frame-name} Preisgruppe_alt_var
                    + ',':U
                    + input frame {&frame-name} Preisgruppe_neu_var"
      }
  
      {returnnoapply}.
  
    end.
  
    &IF "{&pa_V_Bruttopreise}":U = "1":U &THEN   /* Bruttopreislisten m�glich */
  
      define Buffer Buf_S_Preisgruppe for S_Preisgruppe.
  
      find Buf_S_Preisgruppe
        where Buf_S_Preisgruppe.Firma       = {firma/spreisgr.fir pa-firma}
          and Buf_S_Preisgruppe.Preisgruppe = input frame {&frame-name} Preisgruppe_alt_var
        no-lock no-error.
  
      if available Buf_S_Preisgruppe
          and not can-find(S_Preisgruppe
            where S_Preisgruppe.Firma       = {firma/spreisgr.fir pa-firma}
              and S_Preisgruppe.Preisgruppe = input frame {&frame-name} Preisgruppe_neu_var
              and S_Preisgruppe.Brutto      = Buf_S_Preisgruppe.Brutto) then do:
  
        {adm/incl/d__msg00.if
          &Meldung = "'s_trg00233':U"
          &Liste   = "input frame {&frame-name} Preisgruppe_alt_var
                      + ',':U
                      + input frame {&frame-name} Preisgruppe_neu_var"
        }
  
        {returnnoapply}.
  
      end.
  
    &ENDIF
    
  /* --> MO#DIETZ-SFL-0010 thongdi_p 29/06/2026 V�nderung Kundensonderpreise */
  end. /* if input frame {&frame-name} xKundensonderpreise = no */
  /* <-- MO#DIETZ-SFL-0010 thongdi_p 29/06/2026 V�nderung Kundensonderpreise */
    
  {adm/template/incl/dt_btn01.if}

  {adm/template/incl/dt_uit01.if
     &UserExitName = "ON_CHOOSE_OF_Btn_Start"}
END.

/* _UIB-CODE-BLOCK-END */
&ANALYZE-RESUME


&Scoped-define SELF-NAME gueltig_ab_alt_var
&ANALYZE-SUSPEND _UIB-CODE-BLOCK _CONTROL gueltig_ab_alt_var Dialog-Frame
ON LEAVE OF gueltig_ab_alt_var IN FRAME Dialog-Frame /* g�ltig am */
do:
  {adm/template/incl/dt_uit00.if
     &UserExitName = "ON_LEAVE_OF_gueltig_ab_alt_var"}

  {adm/template/incl/dt_viw03.if}

  {adm/template/incl/dt_uit01.if
     &UserExitName = "ON_LEAVE_OF_gueltig_ab_alt_var"}
end.

/* _UIB-CODE-BLOCK-END */
&ANALYZE-RESUME


&Scoped-define SELF-NAME gueltig_ab_neu_var
&ANALYZE-SUSPEND _UIB-CODE-BLOCK _CONTROL gueltig_ab_neu_var Dialog-Frame
ON LEAVE OF gueltig_ab_neu_var IN FRAME Dialog-Frame /* g�ltig ab */
do:
  {adm/template/incl/dt_uit00.if
     &UserExitName = "ON_LEAVE_OF_gueltig_ab_neu_var"}

  {adm/template/incl/dt_viw03.if}

  {adm/template/incl/dt_uit01.if
     &UserExitName = "ON_LEAVE_OF_gueltig_ab_neu_var"}
end.

/* _UIB-CODE-BLOCK-END */
&ANALYZE-RESUME


&Scoped-define SELF-NAME gueltig_bis_neu_var
&ANALYZE-SUSPEND _UIB-CODE-BLOCK _CONTROL gueltig_bis_neu_var Dialog-Frame
ON LEAVE OF gueltig_bis_neu_var IN FRAME Dialog-Frame /* g�ltig bis */
do:

  /* Pr�fung, ob g�ltig bis >= g�ltig ab --------------------------------------*/

  {adm/template/incl/dt_uit00.if
     &UserExitName = "ON_LEAVE_OF_gueltig_bis_neu_var"}

  if  input frame {&Frame-Name} gueltig_bis_neu_var
    < input frame {&Frame-Name} gueltig_ab_neu_var then
  do:

    {adm/incl/d__msg00.if
     &Meldung =  "'s_art00023':U"
      }
    return 'ADM-error':U.

  end. /* if gueltig_bis < gueltig_ab */

  {adm/template/incl/dt_viw03.if}

  {adm/template/incl/dt_uit01.if
     &UserExitName = "ON_LEAVE_OF_gueltig_bis_neu_var"}
end.

/* _UIB-CODE-BLOCK-END */
&ANALYZE-RESUME


&Scoped-define SELF-NAME Preisgruppe_alt_var
&ANALYZE-SUSPEND _UIB-CODE-BLOCK _CONTROL Preisgruppe_alt_var Dialog-Frame
ON LEAVE OF Preisgruppe_alt_var IN FRAME Dialog-Frame /* Preisliste alt */
do:
  {adm/template/incl/dt_uit00.if
     &UserExitName = "ON_LEAVE_OF_Preisgruppe_alt_var"}

  {adm/template/incl/dt_viw03.if}

  {adm/template/incl/dt_uit01.if
     &UserExitName = "ON_LEAVE_OF_Preisgruppe_alt_var"}
end.

/* _UIB-CODE-BLOCK-END */
&ANALYZE-RESUME


&Scoped-define SELF-NAME Preisgruppe_neu_var
&ANALYZE-SUSPEND _UIB-CODE-BLOCK _CONTROL Preisgruppe_neu_var Dialog-Frame
ON LEAVE OF Preisgruppe_neu_var IN FRAME Dialog-Frame /* Preisliste neu */
do:
  {adm/template/incl/dt_uit00.if
     &UserExitName = "ON_LEAVE_OF_Preisgruppe_neu_var"}

  {adm/template/incl/dt_viw03.if}

  {adm/template/incl/dt_uit01.if
     &UserExitName = "ON_LEAVE_OF_Preisgruppe_neu_var"}
end.

/* _UIB-CODE-BLOCK-END */
&ANALYZE-RESUME


&Scoped-define SELF-NAME Selektion_min
&ANALYZE-SUSPEND _UIB-CODE-BLOCK _CONTROL Selektion_min Dialog-Frame
ON leave OF Selektion_min IN FRAME Dialog-Frame /* Selektion Teil */
DO:
  {adm/template/incl/dt_uit00.if
     &UserExitName = "ON_LEAVE_OF_Selektion_min"}

  {adm/template/incl/dt_dlg00.if &MAX-FELD = "Selektion_max"}

  {adm/template/incl/dt_uit01.if
     &UserExitName = "ON_LEAVE_OF_Selektion_min"}
END.

/* _UIB-CODE-BLOCK-END */
&ANALYZE-RESUME


&UNDEFINE SELF-NAME

&ANALYZE-SUSPEND _UIB-CODE-BLOCK _CUSTOM _MAIN-BLOCK Dialog-Frame 


/* ***************************  Main Block  *************************** */

{adm/template/incl/dt_dlg00.i}

Selektion_var = '*':U.

run initialize in this-procedure.

{fnarg
  pa_lUISvcCreateLabel
  "lZuschlagsart_var:handle in frame {&FRAME-NAME},
   'Zuschlagsart':R18"}.

/* Now enable the interface and wait for the exit condition.            */
/* (NOTE: handle ERROR and END-KEY so cleanup code will always fire.    */
MAIN-BLOCK:
DO ON ERROR   UNDO MAIN-BLOCK, LEAVE MAIN-BLOCK
   ON END-KEY UNDO MAIN-BLOCK, LEAVE MAIN-BLOCK:
  RUN enable_UI.

  /* Wait-for go of frame                                                     */

  {adm/template/incl/dt_dlg11.if}
END.
RUN disable_UI.

/* _UIB-CODE-BLOCK-END */
&ANALYZE-RESUME


/* **********************  Internal Procedures  *********************** */

&ANALYZE-SUSPEND _UIB-CODE-BLOCK _PROCEDURE _assignData Dialog-Frame 
PROCEDURE _assignData :
/* Description ---------------------------------------------------------------*/
/*                                                                            */
/* Overwrite of AssignData                                                    */
/*                                                                            */
/* Notes ---------------------------------------------------------------------*/
/*                                                                            */
/* Assign Special Values                                                      */
/*                                                                            */
/* Parameters ----------------------------------------------------------------*/
/*                                                                            */
/* iopcParamString  List with data in Proalpha String format                  */
/*                                                                            */
/*----------------------------------------------------------------------------*/

define input-output parameter pcParamListe as char no-undo.

/* Variables -----------------------------------------------------------------*/
/*----------------------------------------------------------------------------*/

/* Buffers -------------------------------------------------------------------*/

/*----------------------------------------------------------------------------*/
/* Processing                                                                 */
/*----------------------------------------------------------------------------*/

 {adm/incl/d__par00.if
   &ParameterListe = "pcParamListe"
   &Parameter      = "ArtGrpSuchbegriff"
   &Variable1      = "ArtGrpSuchbegriff_min"
   &Variable2      = "ArtGrpSuchbegriff_max"
 }

 {adm/incl/d__par00.if
   &ParameterListe = "pcParamListe"
   &Parameter      = "ArtGrpSelektion"
   &Variable1      = "ArtGrpSelektion_min"
   &Variable2      = "ArtGrpSelektion_max"
 }

end procedure. /* _assignData */

/* _UIB-CODE-BLOCK-END */
&ANALYZE-RESUME

&ANALYZE-SUSPEND _UIB-CODE-BLOCK _PROCEDURE _initialize Dialog-Frame 
PROCEDURE _initialize :
/*------------------------------------------------------------------------------
  Purpose:
  Parameters:  <none>
  Notes:
------------------------------------------------------------------------------*/
  define variable l_external as logical no-undo.

  gcBenutzer = pACConnectionSvc:prpcUserID.

  {setwidgetattr 
     gueltig_ab_alt_var 
     label 
     "'g�ltig am':R18" 
     "in frame {&frame-name}"}.

  &IF "{&PA_BB_MANAEG}":U <> "1":U &THEN

    {fnarg
       pa_lUISvcSetWidgetHiddenState
       "AenderungsGrund_var:handle in frame {&FRAME-NAME},
        yes"}.

    {fnarg
       pa_lUISvcSetWidgetHiddenState
       "Bemerkung_var:handle in frame {&FRAME-NAME},
        yes"}.

    glAenderung = no.

  &ENDIF

  l_external = no.

  {adm/incl/d__par01.if
    &ParameterListe = "pc_Options"
    &Parameter      = "ArtGrpSuchbegriff"
    &Variable1      = "ArtGrpSuchbegriff_min"
    &Variable2      = "ArtGrpSuchbegriff_max"
    &Flag           = "l_external"
  }

  if not l_external then
  do:

   find last S_ArtGruppe
     where S_ArtGruppe.Firma = {firma/sartgrp.fir pa-Firma}
     use-index Such
     no-lock no-error.
   if available S_ArtGruppe then
     ArtGrpSuchbegriff_max = S_ArtGruppe.Suchbegriff.

  end.

  l_external = no.

  {adm/incl/d__par01.if
    &ParameterListe = "pc_Options"
    &Parameter      = "ArtGrpSelektion"
    &Variable1      = "ArtGrpSelektion_min"
    &Variable2      = "ArtGrpSelektion_max"
    &Flag           = "l_external"
  }

  if not l_external then
  do:

   find last S_ArtGruppe
     where S_ArtGruppe.Firma = {firma/sartgrp.fir pa-Firma}
     use-index Selekt
     no-lock no-error.
   if available S_ArtGruppe then
     ArtGrpSelektion_max = S_ArtGruppe.Selektion.

  end.

  /* Write Company and Category to Initial-Help-String  */

  assign
    gcInitialHelpString = adm.method.cls.DMCParameterStringSvc:cWriteValue('':U, 'Firma':U, {firma/sartikel.fir pa-Firma})
    gcInitialHelpString = adm.method.cls.DMCParameterStringSvc:cWriteValue(gcInitialHelpString, 'DRC_Table_ID':U, 'S_Artikel':U)
    .

end procedure.

/* _UIB-CODE-BLOCK-END */
&ANALYZE-RESUME

&ANALYZE-SUSPEND _UIB-CODE-BLOCK _PROCEDURE _process-data Dialog-Frame 
PROCEDURE _process-data :
/*------------------------------------------------------------------------------
  Purpose:
  Parameters:  <none>
  Notes:
------------------------------------------------------------------------------*/

  define input-output parameter pc_ParamListe   as char no-undo.
  define input-output parameter pc_Options      as char no-undo.
  define input-output parameter pc_ZielProgramm as char no-undo.

  {adm/incl/d__par00.if
    &ParameterListe = "pc_ParamListe"
    &Parameter      = "Zuschlagsart"
    &Variable1      = "lZuschlagsart_var"
  }

  {adm/incl/d__par00.if
    &ParameterListe = "pc_ParamListe"
    &Parameter      = "Benutzer"
    &Variable1      = "gcBenutzer"
  }

  {adm/incl/d__par00.if
    &ParameterListe = "pc_ParamListe"
    &Parameter      = "Aenderung"
    &Variable1      = "glAenderung"
  }

  {adm/incl/d__par00.if
    &ParameterListe = "pc_ParamListe"
    &Parameter      = "gueltig_alt"
    &Variable1      = "gueltig_ab_alt_var"
  }

  {adm/incl/d__par00.if
    &ParameterListe = "pc_ParamListe"
    &Parameter      = "gueltig_neu"
    &Variable1      = "gueltig_ab_neu_var"
    &Variable2      = "gueltig_bis_neu_var"
  }

end procedure.

/* _UIB-CODE-BLOCK-END */
&ANALYZE-RESUME

&ANALYZE-SUSPEND _UIB-CODE-BLOCK _PROCEDURE assignData Dialog-Frame  adm/support/proc/ds_dlg10.p
PROCEDURE assignData :
/* Description ---------------------------------------------------------------*/
/*                                                                            */
/* Assign screen values to parameter string                                   */
/*                                                                            */
/* Parameters ----------------------------------------------------------------*/
/*                                                                            */
/* pcParamListe  List with data in Proalpha String format                     */
/*                                                                            */
/*----------------------------------------------------------------------------*/

define       output parameter pcParamListe as character     no-undo.

/* Variables -----------------------------------------------------------------*/
/*----------------------------------------------------------------------------*/

/* Buffers -------------------------------------------------------------------*/

/*----------------------------------------------------------------------------*/
/* Processing                                                                 */
/*----------------------------------------------------------------------------*/

/* Assign Screen Buffer                                                       */

{adm/template/incl/dt_dlg12.if}

/* Assign Default Values                                                      */

{adm/incl/d__par00.if
  &ParameterListe = "pcParamListe"
  &Parameter      = "ArtikelGruppe"
  &Variable1      = "ArtikelGruppe_min"
  &Variable2      = "ArtikelGruppe_max"
}

{adm/incl/d__par00.if
  &ParameterListe = "pcParamListe"
  &Parameter      = "Artikel"
  &Variable1      = "Artikel_min"
  &Variable2      = "Artikel_max"
}

{adm/incl/d__par00.if
  &ParameterListe = "pcParamListe"
  &Parameter      = "Selektion"
  &Variable1      = "Selektion_min"
  &Variable2      = "Selektion_max"
  &Variable3      = "Selektion_var"
}

{adm/incl/d__par00.if
  &ParameterListe = "pcParamListe"
  &Parameter      = "Preisgruppe_alt"
  &Variable1      = "Preisgruppe_alt_var"
}

{adm/incl/d__par00.if
  &ParameterListe = "pcParamListe"
  &Parameter      = "Preisgruppe_neu"
  &Variable1      = "Preisgruppe_neu_var"
}

{adm/incl/d__par00.if
  &ParameterListe = "pcParamListe"
  &Parameter      = "Zuschlag"
  &Variable1      = "Zuschlag_var"
}

{adm/incl/d__par00.if
  &ParameterListe = "pcParamListe"
  &Parameter      = "Rundungswert"
  &Variable1      = "Rundungswert_var"
}

{adm/incl/d__par00.if
  &ParameterListe = "pcParamListe"
  &Parameter      = "AenderungsGrund"
  &Variable1      = "AenderungsGrund_var"
}

{adm/incl/d__par00.if
  &ParameterListe = "pcParamListe"
  &Parameter      = "Bemerkung"
  &Variable1      = "Bemerkung_var"
}

{adm/incl/d__par00.if
  &ParameterListe = "pcParamListe"
  &Parameter      = "AnlageDatum"
  &Variable1      = "gueltig_ab_alt_var"
}

{adm/incl/d__par00.if
  &ParameterListe = "pcParamListe"
  &Parameter      = "gueltig_ab"
  &Variable1      = "gueltig_ab_neu_var"
}

{adm/incl/d__par00.if
  &ParameterListe = "pcParamListe"
  &Parameter      = "gueltig_bis"
  &Variable1      = "gueltig_bis_neu_var"
}

{adm/incl/d__par00.if
  &ParameterListe = "pcParamListe"
  &Parameter      = "lZuschlagsart"
  &Variable1      = "lZuschlagsart_var"
}

/* Default Code                                                               */

{adm/template/incl/dt_dlg07.if}

return.

end procedure. /* assignData */

/* _UIB-CODE-BLOCK-END */
&ANALYZE-RESUME

&ANALYZE-SUSPEND _UIB-CODE-BLOCK _PROCEDURE disable_UI Dialog-Frame 
PROCEDURE disable_UI :
/*------------------------------------------------------------------------------
  Purpose:     DISABLE the User Interface
  Parameters:  <none>
  Notes:       Here we clean-up the user-interface by deleting
               dynamic widgets we have created and/or hide
               frames.  This procedure is usually called when
               we are ready to "clean-up" after running.
------------------------------------------------------------------------------*/

  {adm/template/incl/dt_dlg06.if}

end procedure.

/* _UIB-CODE-BLOCK-END */
&ANALYZE-RESUME

&ANALYZE-SUSPEND _UIB-CODE-BLOCK _PROCEDURE display-InfoFields Dialog-Frame  adm/support/proc/ds_inf02.p
PROCEDURE display-InfoFields :
/* Description ---------------------------------------------------------------*/
/*                                                                            */
/* Display Infofields                                                         */
/*                                                                            */
/* Parameters ----------------------------------------------------------------*/
/*                                                                            */
/* pcFields    list of fields to display                                      */
/*                                                                            */
/*----------------------------------------------------------------------------*/

define input        parameter pcFields as character     no-undo.

/*----------------------------------------------------------------------------*/
/* Processing                                                                 */
/*----------------------------------------------------------------------------*/

do with frame {&Frame-Name}:

  if can-do(pcFields,'Preisgruppe_alt_var':U) then
    if Preisgruppe_alt_var_Info:private-data <> Preisgruppe_alt_var:screen-value then
    do:
      {adm/incl/d__spr00.if
        &Tabelle  = "S_PreisGruppeSpr"
        &Selekt   = "where S_PreisGruppeSpr.Firma = {firma/spreisgr.fir pa-Firma}
                       and S_PreisGruppeSpr.Preisgruppe = input frame {&Frame-Name} Preisgruppe_alt_var"
        &no-error = "no-error"}

      if available S_PreisGruppeSpr then
        assign
          {setwidgetattr 
             Preisgruppe_alt_var_Info 
             private-data 
             Preisgruppe_alt_var:screen-value}
          Preisgruppe_alt_var_Info = S_PreisGruppeSpr.Bezeichnung
          .
      else
        assign
          {setwidgetattr Preisgruppe_alt_var_Info private-data string(?)}
          Preisgruppe_alt_var_Info = '':U
          .

      {setwidgetattr Preisgruppe_alt_var_Info screen-value Preisgruppe_alt_var_Info}.
    end.

  if can-do(pcFields,'Preisgruppe_neu_var':U) then
    if Preisgruppe_neu_var_Info:private-data <> Preisgruppe_neu_var:screen-value then
    do:
      {adm/incl/d__spr00.if
        &Tabelle  = "S_PreisGruppeSpr"
        &Selekt   = "where S_PreisGruppeSpr.Firma = {firma/spreisgr.fir pa-Firma}
                       and S_PreisGruppeSpr.Preisgruppe = input frame {&Frame-Name} Preisgruppe_neu_var"
        &no-error = "no-error"}

      if available S_PreisGruppeSpr then
        assign
          {setwidgetattr 
             Preisgruppe_neu_var_Info 
             private-data 
             Preisgruppe_neu_var:screen-value}
          Preisgruppe_neu_var_Info = S_PreisGruppeSpr.Bezeichnung
          .
      else
        assign
          {setwidgetattr Preisgruppe_neu_var_Info private-data string(?)}
          Preisgruppe_neu_var_Info = '':U
          .

      {setwidgetattr Preisgruppe_neu_var_Info screen-value Preisgruppe_neu_var_Info}.
    end.

  if can-do(pcFields,'AenderungsGrund_var':U) then
    if AenderungsGrund_var_Info:private-data <> AenderungsGrund_var:screen-value then
    do:
      {adm/incl/d__spr00.if
        &Tabelle  = "BB_AenderungsGrundSpr"
        &Selekt   = "where BB_AenderungsGrundSpr.Firma = {firma/sartikel.fir pa-Firma}
                       and BB_AenderungsGrundSpr.DRC_Table_ID = 'S_Artikel':U
                       and BB_AenderungsGrundSpr.AenderungsGrund = input frame {&Frame-Name} AenderungsGrund_var"
        &no-error = "no-error"}

      if available BB_AenderungsGrundSpr then
        assign
          {setwidgetattr 
             AenderungsGrund_var_Info 
             private-data 
             AenderungsGrund_var:screen-value}
          AenderungsGrund_var_Info = BB_AenderungsGrundSpr.Bezeichnung
          .
      else
        assign
          {setwidgetattr AenderungsGrund_var_Info private-data string(?)}
          AenderungsGrund_var_Info = '':U
          .

      {setwidgetattr AenderungsGrund_var_Info screen-value AenderungsGrund_var_Info}.
    end.

end. /* do with frame */

/* User Exits */

{&{&PA-XBasisName}_C_Display-InfoFields}
{&{&PA-XBasisName}_U_Display-InfoFields}
{&{&PA-XBasisName}_Q_Display-InfoFields}
{&{&PA-XBasisName}_Display-InfoFields}
{&{&PA-XBasisName}_Y_Display-InfoFields}

return.

end procedure. /* display-InfoFields */

/* _UIB-CODE-BLOCK-END */
&ANALYZE-RESUME

&ANALYZE-SUSPEND _UIB-CODE-BLOCK _PROCEDURE enable_UI Dialog-Frame 
PROCEDURE enable_UI :
/*------------------------------------------------------------------------------
  Purpose:     ENABLE the User Interface
  Parameters:  <none>
  Notes:       Here we display/view/enable the widgets in the
               user-interface.  In addition, OPEN all queries
               associated with each FRAME and BROWSE.
               These statements here are based on the "Other
               Settings" section of the widget Property Sheets.
------------------------------------------------------------------------------*/

  {adm/template/incl/dt_dlg03.if}

  if not can-find(first BB_AenderungsGrund
         where BB_AenderungsGrund.Firma = {firma/sartikel.fir pa-firma}
           and BB_AenderungsGrund.DRC_Table_ID = 'S_Artikel':U) then do:

    {fnarg
      pa_lUISvcDisableWidget
      "AenderungsGrund_var:handle in frame {&frame-name}"}.

    {fnarg
      pa_lUISvcDisableWidget
      "Bemerkung_var:handle in frame {&frame-name}"}.

    glAenderung = no.

  end. /* if not can-find(first BB_AenderungsGrund */

  &IF "{&PA_BB_MANAEG}":U = "1":U &THEN
  else
    glAenderung = yes.
  &ENDIF

end procedure.

/* _UIB-CODE-BLOCK-END */
&ANALYZE-RESUME

&ANALYZE-SUSPEND _UIB-CODE-BLOCK _PROCEDURE initialize Dialog-Frame  adm/support/proc/ds_dlg02.p
PROCEDURE initialize :
/* Description ---------------------------------------------------------------*/
/*                                                                            */
/* Initialization                                                             */
/*                                                                            */
/* Notes ---------------------------------------------------------------------*/
/*                                                                            */
/* - Initialization of variables                                              */
/* - Assign format                                                            */
/*                                                                            */
/* Parameters ----------------------------------------------------------------*/
/*                                                                            */
/* <none>                                                                     */
/*                                                                            */
/*----------------------------------------------------------------------------*/

/* Variables -----------------------------------------------------------------*/
/* lExternalValueAvailable     Flag                                           */
/*----------------------------------------------------------------------------*/

define variable lExternalValueAvailable as logical       no-undo.

/*----------------------------------------------------------------------------*/
/* Processing                                                                 */
/*----------------------------------------------------------------------------*/

/* Initialize maximum values (use external data, if available)                */

{adm/incl/d__par01.if
  &ParameterListe = "pc_Options"
  &Parameter      = "ArtikelGruppe"
  &Variable1      = "ArtikelGruppe_min"
  &Variable2      = "ArtikelGruppe_max"
  &Flag           = "lExternalValueAvailable"
}

if not lExternalValueAvailable then
do:
  {adm/template/incl/dt_dlg04.if
    &Variable = "ArtikelGruppe_min"
  }
  find last S_ArtGruppe
    where S_ArtGruppe.Firma = {firma/sartgrp.fir pa-Firma}
    use-index Main
    no-lock no-error.
  if available S_ArtGruppe then
    ArtikelGruppe_max = S_ArtGruppe.ArtikelGruppe.
end. /* not lExternalValueAvailable */

{adm/incl/d__par01.if
  &ParameterListe = "pc_Options"
  &Parameter      = "Artikel"
  &Variable1      = "Artikel_min"
  &Variable2      = "Artikel_max"
  &Flag           = "lExternalValueAvailable"
}

if not lExternalValueAvailable then
do:
  {adm/template/incl/dt_dlg04.if
    &Variable = "Artikel_min"
  }
  find last S_Artikel
    where S_Artikel.Firma = {firma/sartikel.fir pa-Firma}
    use-index Main
    no-lock no-error.
  if available S_Artikel then
    Artikel_max = S_Artikel.Artikel.
end. /* not lExternalValueAvailable */

{adm/incl/d__par01.if
  &ParameterListe = "pc_Options"
  &Parameter      = "Selektion"
  &Variable1      = "Selektion_min"
  &Variable2      = "Selektion_max"
  &Variable3      = "Selektion_var"
  &Flag           = "lExternalValueAvailable"
}

if not lExternalValueAvailable then
do:
  {adm/template/incl/dt_dlg04.if
    &Variable = "Selektion_min"
  }
  find last S_Artikel
    where S_Artikel.Firma = {firma/sartikel.fir pa-Firma}
    use-index Selekt
    no-lock no-error.
  if available S_Artikel then
    Selektion_max = S_Artikel.Selektion.
  {adm/template/incl/dt_dlg04.if
    &Variable = "Selektion_var"
  }
end. /* not lExternalValueAvailable */

{adm/incl/d__par01.if
  &ParameterListe = "pc_Options"
  &Parameter      = "Preisgruppe_alt"
  &Variable1      = "Preisgruppe_alt_var"
  &Flag           = "lExternalValueAvailable"
}

if not lExternalValueAvailable then
do:
  {adm/template/incl/dt_dlg04.if
    &Variable = "Preisgruppe_alt_var"
  }
end. /* not lExternalValueAvailable */

{adm/incl/d__par01.if
  &ParameterListe = "pc_Options"
  &Parameter      = "Preisgruppe_neu"
  &Variable1      = "Preisgruppe_neu_var"
  &Flag           = "lExternalValueAvailable"
}

if not lExternalValueAvailable then
do:
  {adm/template/incl/dt_dlg04.if
    &Variable = "Preisgruppe_neu_var"
  }
end. /* not lExternalValueAvailable */

{adm/incl/d__par01.if
  &ParameterListe = "pc_Options"
  &Parameter      = "Zuschlag"
  &Variable1      = "Zuschlag_var"
  &Datentyp       = "DECIMAL"
  &Flag           = "lExternalValueAvailable"
}

if not lExternalValueAvailable then
do:
  {adm/template/incl/dt_dlg04.if
    &Variable = "Zuschlag_var"
    &Datentyp = "DECIMAL"
  }
end. /* not lExternalValueAvailable */

{adm/incl/d__par01.if
  &ParameterListe = "pc_Options"
  &Parameter      = "Rundungswert"
  &Variable1      = "Rundungswert_var"
  &Datentyp       = "DECIMAL"
  &Flag           = "lExternalValueAvailable"
}

if not lExternalValueAvailable then
do:
  {adm/template/incl/dt_dlg04.if
    &Variable = "Rundungswert_var"
    &Datentyp = "DECIMAL"
  }
end. /* not lExternalValueAvailable */

{adm/incl/d__par01.if
  &ParameterListe = "pc_Options"
  &Parameter      = "AenderungsGrund"
  &Variable1      = "AenderungsGrund_var"
  &Datentyp       = "integer"
  &Flag           = "lExternalValueAvailable"
}

if not lExternalValueAvailable then
do:
  {adm/template/incl/dt_dlg04.if
    &Variable = "AenderungsGrund_var"
    &Datentyp = "integer"
  }
end. /* not lExternalValueAvailable */

{adm/incl/d__par01.if
  &ParameterListe = "pc_Options"
  &Parameter      = "Bemerkung"
  &Variable1      = "Bemerkung_var"
  &Flag           = "lExternalValueAvailable"
}

if not lExternalValueAvailable then
do:
  {adm/template/incl/dt_dlg04.if
    &Variable = "Bemerkung_var"
  }
end. /* not lExternalValueAvailable */

{adm/incl/d__par01.if
  &ParameterListe = "pc_Options"
  &Parameter      = "AnlageDatum"
  &Variable1      = "gueltig_ab_alt_var"
  &cc_Date        = "yes"
  &Flag           = "lExternalValueAvailable"
}

if not lExternalValueAvailable then
do:
  {adm/template/incl/dt_dlg04.if
    &Variable = "gueltig_ab_alt_var"
    &Datentyp = "date"
  }
end. /* not lExternalValueAvailable */

{adm/incl/d__par01.if
  &ParameterListe = "pc_Options"
  &Parameter      = "gueltig_ab"
  &Variable1      = "gueltig_ab_neu_var"
  &cc_Date        = "yes"
  &Flag           = "lExternalValueAvailable"
}

if not lExternalValueAvailable then
do:
  {adm/template/incl/dt_dlg04.if
    &Variable = "gueltig_ab_neu_var"
    &Datentyp = "date"
  }
end. /* not lExternalValueAvailable */

{adm/incl/d__par01.if
  &ParameterListe = "pc_Options"
  &Parameter      = "gueltig_bis"
  &Variable1      = "gueltig_bis_neu_var"
  &cc_Date        = "yes"
  &Flag           = "lExternalValueAvailable"
}

if not lExternalValueAvailable then
do:
  {adm/template/incl/dt_dlg04.if
    &Variable = "gueltig_bis_neu_var"
    &Datentyp = "date"
  }
end. /* not lExternalValueAvailable */

{adm/incl/d__par01.if
  &ParameterListe = "pc_Options"
  &Parameter      = "lZuschlagsart"
  &Variable1      = "lZuschlagsart_var"
  &cc_Log         = "yes"
  &Flag           = "lExternalValueAvailable"
}

if not lExternalValueAvailable then
do:
  {adm/template/incl/dt_dlg04.if
    &Variable = "lZuschlagsart_var"
    &Datentyp = "logical"
  }
end. /* not lExternalValueAvailable */

/* Copy setup from dummy frame                                                */

if frame {&FRAME-NAME}:hidden then
  assign

    {setwidgetattr 
       ArtikelGruppe_min 
       format 
       "S_ArtGruppe.ArtikelGruppe:format in frame f_dummy" 
       "in frame {&frame-name}"}

    {setwidgetattr 
       ArtikelGruppe_min 
       label 
       "S_ArtGruppe.ArtikelGruppe:label in frame f_dummy" 
       "in frame {&frame-name}"}

    {setwidgetattr 
       ArtikelGruppe_max 
       format 
       "S_ArtGruppe.ArtikelGruppe:format in frame f_dummy" 
       "in frame {&frame-name}"}

    {setwidgetattr 
       Artikel_min 
       format 
       "S_Artikel.Artikel:format in frame f_dummy" 
       "in frame {&frame-name}"}

    {setwidgetattr 
       Artikel_min 
       label 
       "S_Artikel.Artikel:label in frame f_dummy" 
       "in frame {&frame-name}"}

    {setwidgetattr 
       Artikel_max 
       format 
       "S_Artikel.Artikel:format in frame f_dummy" 
       "in frame {&frame-name}"}

    {setwidgetattr 
       Selektion_min 
       format 
       "S_Artikel.Selektion:format in frame f_dummy" 
       "in frame {&frame-name}"}

    {setwidgetattr 
       Selektion_min 
       label 
       "S_Artikel.Selektion:label in frame f_dummy" 
       "in frame {&frame-name}"}

    {setwidgetattr 
       Selektion_max 
       format 
       "S_Artikel.Selektion:format in frame f_dummy" 
       "in frame {&frame-name}"}

    {setwidgetattr 
       Selektion_var 
       format 
       "S_Artikel.Selektion:format in frame f_dummy" 
       "in frame {&frame-name}"}

    {setwidgetattr 
       Selektion_var 
       label 
       "S_Artikel.Selektion:label in frame f_dummy" 
       "in frame {&frame-name}"}

    {setwidgetattr 
       AenderungsGrund_var 
       format 
       "BB_AenderungsGrund.AenderungsGrund:format in frame f_dummy" 
       "in frame {&frame-name}"}

    {setwidgetattr 
       AenderungsGrund_var 
       label 
       "BB_AenderungsGrund.AenderungsGrund:label in frame f_dummy" 
       "in frame {&frame-name}"}

    {setwidgetattr 
       gueltig_ab_alt_var 
       format 
       "S_ArtPreiseDatum.AnlageDatum:format in frame f_dummy" 
       "in frame {&frame-name}"}

    {setwidgetattr 
       gueltig_ab_alt_var 
       label 
       "S_ArtPreiseDatum.AnlageDatum:label in frame f_dummy" 
       "in frame {&frame-name}"}

    {setwidgetattr 
       gueltig_ab_neu_var 
       format 
       "S_ArtPreiseDatum.gueltig_ab:format in frame f_dummy" 
       "in frame {&frame-name}"}

    {setwidgetattr 
       gueltig_ab_neu_var 
       label 
       "S_ArtPreiseDatum.gueltig_ab:label in frame f_dummy" 
       "in frame {&frame-name}"}

    {setwidgetattr 
       gueltig_bis_neu_var 
       format 
       "S_ArtPreiseDatum.gueltig_bis:format in frame f_dummy" 
       "in frame {&frame-name}"}

    {setwidgetattr 
       gueltig_bis_neu_var 
       label 
       "S_ArtPreiseDatum.gueltig_bis:label in frame f_dummy" 
       "in frame {&frame-name}"}
    no-error.

/* Default Code                                                               */

{adm/template/incl/dt_dlg01.if}

end procedure. /* initialize */

/* _UIB-CODE-BLOCK-END */
&ANALYZE-RESUME

&ANALYZE-SUSPEND _UIB-CODE-BLOCK _PROCEDURE process-data Dialog-Frame  adm/support/proc/ds_dlg04.p
PROCEDURE process-data :
/* Description ---------------------------------------------------------------*/
/*                                                                            */
/* Save data into parameter string and start processing                       */
/*                                                                            */
/* Parameters ----------------------------------------------------------------*/
/*                                                                            */
/* <none>                                                                     */
/*                                                                            */
/*----------------------------------------------------------------------------*/

/* Variables -----------------------------------------------------------------*/
/* c_ParamListe        Parameter string                                       */
/* c_Options           Options of target program                              */
/* c_ZielProgramm      Target Program                                         */
/*----------------------------------------------------------------------------*/

define variable c_ParamListe   as character     no-undo.
define variable c_Options      as character     no-undo.
define variable c_ZielProgramm as character     no-undo.

/*----------------------------------------------------------------------------*/
/* Processing                                                                 */
/*----------------------------------------------------------------------------*/

run assignData in this-procedure (output c_ParamListe).

{adm/template/incl/dt_dlg02.if}

end procedure. /* process-data */

/* _UIB-CODE-BLOCK-END */
&ANALYZE-RESUME

