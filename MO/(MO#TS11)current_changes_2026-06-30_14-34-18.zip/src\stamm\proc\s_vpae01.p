&ANALYZE-SUSPEND _VERSION-NUMBER UIB_v8r12
&ANALYZE-RESUME

&ANALYZE-SUSPEND _UIB-CODE-BLOCK _CUSTOM _DECLARATIONS Procedure

/* _UIB-CODE-BLOCK-END */
&ANALYZE-RESUME


&ANALYZE-SUSPEND _UIB-CODE-BLOCK _XFTR "Update Information" Procedure _INLINE
/* Actions: ? ? ? ? adm/support/proc/ds_pa_01.w */

/* _UIB-CODE-BLOCK-END */
&ANALYZE-RESUME

&ANALYZE-SUSPEND _UIB-CODE-BLOCK _CUSTOM _DEFINITIONS Procedure
/*****************************************************************************/
/* @COPYRIGHT@                                                               */
/*                                                                           */
/*  Projekt....: Proalpha                                                    */
/*                                                                           */
/*  Name.......: s_vpae01.p                                                  */
/*  Bereich....: STAMM/KERN                                                  */
/*                                                                           */
/*  erstellt am: 24.07.1997                                                  */
/*  Autor......: Michael Schmidt                                             */
/*                                                                           */
/*  Version....: @PAVERSION@ vom @PADATE@/@PALASTAUTHOR@                     */
/*                                                                           */
/*---------------------------------------------------------------------------*/
/*  AUFGABE                                                                  */
/*---------------------------------------------------------------------------*/
/*                                                                           */
/*  Verarbeitungsprogramm - �nderung zw. zwei Preislisten                    */
/*                                                                           */
/*---------------------------------------------------------------------------*/
/*  ARGUMENTE/PARAMETER                                                      */
/*---------------------------------------------------------------------------*/
/*                                                                           */
/*  Name                Art Funktion/Inhalt                                  */
/*  ------------------- --- ------------------------------------------------ */
/*---------------------------------------------------------------------------*/
/*  �NDERUNGSPROTOKOLL                                                       */
/*---------------------------------------------------------------------------*/
/* @FILEHISTORY@                                                             */
/*****************************************************************************/

/*---------------------------------------------------------------------------*/
/* Definitionen                                                              */
/*---------------------------------------------------------------------------*/

/* KONSTANTEN ---------------------------------------------------------------*/
/* Systemkonstanten **********************************************************/

&GLOBAL-DEFINE pa-Autor             Michael Schmidt
&GLOBAL-DEFINE pa-Version           @PAVERSION@
&GLOBAL-DEFINE pa-Datum             @PADATE@
&GLOBAL-DEFINE pa-Letzter           @PALASTAUTHOR@

&GLOBAL-DEFINE pa-GenVersion       UIB
&GLOBAL-DEFINE pa-ProgrammTyp      Procedure
&GLOBAL-DEFINE pa-Template         adm/template/proc/dt_pro00.p
&GLOBAL-DEFINE pa-TemplateVersion  1.01

&GLOBAL-DEFINE pa-XBasisName       s_vpae01_p


/* lokale Konstanten *********************************************************/

/* EXTERNE DEFINITIONEN -----------------------------------------------------*/

{adm/template/incl/dt_job00.df}

/* LOKALE OBJEKTE -----------------------------------------------------------*/
/* Variable ******************************************************************/
/*   Name               Funktion                                             */
/*   ------------------ ---------------------------------------------------- */
/*****************************************************************************/

define variable Artikel_min           like S_Artikel.Artikel         no-undo.
define variable Artikel_max           like S_Artikel.Artikel         no-undo.
define variable ArtikelGruppe_min     like S_ArtGruppe.ArtikelGruppe no-undo.
define variable ArtikelGruppe_max     like S_ArtGruppe.ArtikelGruppe no-undo.
define variable ArtGrpSuchbegriff_min like S_ArtGruppe.Suchbegriff   no-undo.
define variable ArtGrpSuchbegriff_max like S_ArtGruppe.Suchbegriff   no-undo.
define variable ArtGrpSelektion_min   like S_ArtGruppe.Selektion     no-undo.
define variable ArtGrpSelektion_max   like S_ArtGruppe.Selektion     no-undo.
define variable Selektion_min         like S_Artikel.Selektion            no-undo.
define variable Selektion_max         like S_Artikel.Selektion            no-undo.
define variable Selektion_var         like S_Artikel.Selektion            no-undo.

define variable PreisGruppe_alt_var like S_PreisGruppe.PreisGruppe        no-undo.
define variable PreisGruppe_neu_var like S_PreisGruppe.PreisGruppe        no-undo.

define variable gueltig_ab_alt_var  like S_ArtPreiseDatum.gueltig_ab      no-undo.
define variable gueltig_ab_neu_var  like S_ArtPreiseDatum.gueltig_ab      no-undo.
define variable gueltig_bis_neu_var like S_ArtPreiseDatum.gueltig_bis     no-undo.

define variable Zuschlag_var        as   dec format 'zzz,zz9.99-':U decimals 2  no-undo.
define variable ZuschlagsArt_var    as   log format 'Wert/%':R18          no-undo.
define variable Rundungswert_var    like S_PreisBearbArtGr.Rundungswert   no-undo.
define variable Aenderung_var       as   logical                          no-undo.
define variable d_Kurs_alt          like S_TagesKurs.GeldKurs decimals 10 no-undo.
define variable d_Kurs_neu          like S_TagesKurs.GeldKurs decimals 10 no-undo.
define variable d_Kursfaktor        like S_TagesKurs.GeldKurs decimals 10 no-undo.

define variable AenderungsGrund_var as   integer init 0                   no-undo.
define variable Bemerkung_var       as   char format 'x(30)':U init '':U  no-undo.

define variable c_Benutzer          as   character format 'x(10)':U       no-undo.

define variable lGeaendert          as   logical init no                  no-undo.

/* --> MO#DIETZ-SFL-0010 thongdi_p 29/06/2026 V�nderung Kundensonderpreise */
define variable lKundensonderpreise as   logical                          no-undo.
define variable iCustomer_min       like S_Kunde.Kunde                    no-undo.
define variable iCustomer_max       like S_Kunde.Kunde                    no-undo.
define variable tGueltig_ab_alt     as   date                             no-undo.
define variable tGueltig_ab_neu     as   date                             no-undo.
define variable tGueltig_bis_neu    as   date                             no-undo.
/* <-- MO#DIETZ-SFL-0010 thongdi_p 29/06/2026 V�nderung Kundensonderpreise */

/* Buffer ********************************************************************/

define buffer bS_ArtPreiseDatum     for S_ArtPreiseDatum.
define buffer Buf_Alt_PreiseDatum   for S_ArtPreiseDatum.
define buffer Buf2_Alt_PreiseDatum  for S_ArtPreiseDatum.
define buffer Buf_Alt_PreiseStaffel for S_ArtPreiseStaffel.
define buffer Buf_Alt_PreisGruppe   for S_PreisGruppe.

/* --> MO#DIETZ-SFL-0010 thongdi_p 29/06/2026 V�nderung Kundensonderpreise */
define buffer bS_ArtKundeDatum      for S_ArtKundeDatum.
define buffer Buf_Alt_KundeDatum    for S_ArtKundeDatum.
define buffer Buf2_Alt_KundeDatum   for S_ArtKundeDatum.
define buffer Buf_Alt_KundeStaffel  for S_ArtKundeStaffel.
/* <-- MO#DIETZ-SFL-0010 thongdi_p 29/06/2026 V�nderung Kundensonderpreise */


/* Work-/Temp-Tables *********************************************************/

 {stamm/incl/s__adp00.tdf &ippNoReferenceOnlySwitch = "YES"}
 {stamm/incl/s__aps00.tdf &ippNoReferenceOnlySwitch = "YES"}
 
/* --> MO#DIETZ-SFL-0010 thongdi_p 30/06/2026 V�nderung Kundensonderpreise */ 
 {stamm/base/incl/sb_psd00.tdf &ippNoReferenceOnlySwitch = "YES"}
 {stamm/base/incl/sb_psd02.tdf &ippNoReferenceOnlySwitch = "YES"}
/* <-- MO#DIETZ-SFL-0010 thongdi_p 30/06/2026 V�nderung Kundensonderpreise */ 
 
/* _UIB-CODE-BLOCK-END */
&ANALYZE-RESUME


&ANALYZE-SUSPEND _UIB-PREPROCESSOR-BLOCK

/* ********************  Preprocessor Definitions  ******************** */

&Scoped-define PROCEDURE-TYPE Procedure



/* _UIB-PREPROCESSOR-BLOCK-END */
&ANALYZE-RESUME



/* *********************** Procedure Settings ************************ */

&ANALYZE-SUSPEND _PROCEDURE-SETTINGS
/* Settings for THIS-PROCEDURE
   Type: Procedure
   Allow:
   Frames: 0
   Add Fields to: Neither
   Other Settings: CODE-ONLY
 */
&ANALYZE-RESUME _END-PROCEDURE-SETTINGS

/* *************************  Create Window  ************************** */

&ANALYZE-SUSPEND _CREATE-WINDOW
/* DESIGN Window definition (used by the UIB)
  CREATE WINDOW Procedure ASSIGN
         HEIGHT             = 2.76
         WIDTH              = 50.4.
/* END WINDOW DEFINITION */
                                                                        */
&ANALYZE-RESUME



&ANALYZE-SUSPEND _UIB-CODE-BLOCK _CUSTOM _INCLUDED-LIB Procedure
/* ************************* Included-Libraries *********************** */

{adm/method/incl/dm_pro00.lib}
{basis/job/incl/bj_job00.lib}

/* _UIB-CODE-BLOCK-END */
&ANALYZE-RESUME



&ANALYZE-SUSPEND _UIB-CODE-BLOCK _CUSTOM _MAIN-BLOCK Procedure


/*---------------------------------------------------------------------------*/
/* Verarbeitung                                                              */
/*---------------------------------------------------------------------------*/

Main: do on error undo, leave:

  /* Lade die Parameter */

  {adm/incl/d__par01.if
    &Parameter      = "ArtikelGruppe"
    &ParameterListe = "pc_ParamListe"
    &Variable1      = "ArtikelGruppe_min"
    &Variable2      = "ArtikelGruppe_max"
  }

  {adm/incl/d__par01.if
    &Parameter      = "ArtGrpSuchbegriff"
    &ParameterListe = "pc_ParamListe"
    &Variable1      = "ArtGrpSuchbegriff_min"
    &Variable2      = "ArtGrpSuchbegriff_max"
  }

  {adm/incl/d__par01.if
    &Parameter      = "ArtGrpSelektion"
    &ParameterListe = "pc_ParamListe"
    &Variable1      = "ArtGrpSelektion_min"
    &Variable2      = "ArtGrpSelektion_max"
  }

  {adm/incl/d__par01.if
    &Parameter      = "Artikel"
    &ParameterListe = "pc_ParamListe"
    &Variable1      = "Artikel_min"
    &Variable2      = "Artikel_max"
  }

  {adm/incl/d__par01.if
    &Parameter      = "Selektion"
    &ParameterListe = "pc_ParamListe"
    &Variable1      = "Selektion_min"
    &Variable2      = "Selektion_max"
    &Variable3      = "Selektion_var"
  }

  {adm/incl/d__par01.if
    &Parameter      = "Preisgruppe_neu"
    &ParameterListe = "pc_ParamListe"
    &Variable1      = "Preisgruppe_neu_var"
  }


  {adm/incl/d__par01.if
    &Parameter      = "Preisgruppe_alt"
    &ParameterListe = "pc_ParamListe"
    &Variable1      = "Preisgruppe_alt_var"
  }

  {adm/incl/d__par01.if
    &Parameter      = "gueltig_alt"
    &ParameterListe = "pc_ParamListe"
    &Variable1      = "gueltig_ab_alt_var"
    &cc_Date        = "true"
  }

  {adm/incl/d__par01.if
    &Parameter      = "gueltig_neu"
    &ParameterListe = "pc_ParamListe"
    &Variable1      = "gueltig_ab_neu_var"
    &Variable2      = "gueltig_bis_neu_var"
    &cc_Date        = "true"
  }

  {adm/incl/d__par01.if
    &Parameter      = "Zuschlag"
    &ParameterListe = "pc_ParamListe"
    &Variable1      = "Zuschlag_var"
    &DatenTyp       = "decimal"
  }

  {adm/incl/d__par01.if
    &Parameter      = "ZuschlagsArt"
    &ParameterListe = "pc_ParamListe"
    &Variable1      = "ZuschlagsArt_var"
    &cc_log         = "true"
  }

  {adm/incl/d__par01.if
    &Parameter      = "Rundungswert"
    &ParameterListe = "pc_ParamListe"
    &Variable1      = "Rundungswert_var"
    &DatenTyp       = "decimal"
  }

  {adm/incl/d__par01.if
    &Parameter      = "AenderungsGrund"
    &ParameterListe = "pc_ParamListe"
    &Variable1      = "AenderungsGrund_var"
    &DatenTyp       = "integer"
  }

  {adm/incl/d__par01.if
    &Parameter      = "Bemerkung"
    &ParameterListe = "pc_ParamListe"
    &Variable1      = "Bemerkung_var"
  }

  {adm/incl/d__par01.if
    &Parameter      = "Benutzer"
    &ParameterListe = "pc_ParamListe"
    &Variable1      = "c_Benutzer"
  }

  {adm/incl/d__par01.if
    &Parameter      = "Aenderung"
    &ParameterListe = "pc_ParamListe"
    &Variable1      = "Aenderung_var"
    &cc_log         = "true"
  }
  
  /* --> MO#DIETZ-SFL-0010 thongdi_p 29/06/2026 V�nderung Kundensonderpreise */ 
  assign  
    lKundensonderpreise   = adm.method.cls.DMCParameterStringSvc:lReadValue
                              ( /* pcPString */ pc_ParamListe,
                                /* pcKey     */ 'Kundensonderpreise':U,
                                /* piEntry   */ 1 )
   
    iCustomer_min         = adm.method.cls.DMCParameterStringSvc:iReadValue
                              ( /* pcPString */ pc_ParamListe,
                                /* pcKey     */ 'Kundemin':U,
                                /* piEntry   */ 1 )
    
    iCustomer_max         = adm.method.cls.DMCParameterStringSvc:iReadValue
                              ( /* pcPString */ pc_ParamListe,
                                /* pcKey     */ 'Kundemax':U,
                                /* piEntry   */ 1 ) 
                                
    tGueltig_ab_alt       = adm.method.cls.DMCParameterStringSvc:tReadValue
                              ( /* pcPString */ pc_ParamListe,
                                /* pcKey     */ 'Gueltig_ab_alt_var':U,
                                /* piEntry   */ 1 )                                   
    
    tGueltig_ab_neu       = adm.method.cls.DMCParameterStringSvc:tReadValue
                              ( /* pcPString */ pc_ParamListe,
                                /* pcKey     */ 'Gueltig_ab_neu_var':U,
                                /* piEntry   */ 1 )
    
    tGueltig_bis_neu      = adm.method.cls.DMCParameterStringSvc:tReadValue
                              ( /* pcPString */ pc_ParamListe,
                                /* pcKey     */ 'Gueltig_bis_neu_var':U,
                                /* piEntry   */ 1 )                                                         
    .     
/*    message lKundensonderpreise skip iCustomer_min skip iCustomer_max skip tGueltig_ab_alt skip tGueltig_ab_neu skip tGueltig_bis_neu.*/
  /* <-- MO#DIETZ-SFL-0010 thongdi_p 29/06/2026 V�nderung Kundensonderpreise */
  
  
  /*-------------------------------------------------------------------------*/
  /* Umsetzen der ausgew�hlten Artikel                                       */
  /*-------------------------------------------------------------------------*/
  
  Schleife:
    
  for each S_Artikel
    where S_Artikel.Firma           = {firma/sartikel.fir pa-firma}
      and S_Artikel.archiviert      = no
      and S_Artikel.Artikelgruppe  >= Artikelgruppe_min
      and S_Artikel.Artikelgruppe  <= Artikelgruppe_max
      and S_Artikel.Artikel        >= Artikel_min
      and S_Artikel.Artikel        <= Artikel_max
      and S_Artikel.Selektion      >= Selektion_min
      and S_Artikel.Selektion      <= Selektion_max
      and S_Artikel.Selektion matches Selektion_var
      and can-find (S_ArtGruppe
        where S_ArtGruppe.Firma          = {firma/sartgrp.fir pa-firma}
          and S_ArtGruppe.ArtikelGruppe  = S_Artikel.ArtikelGruppe
          and S_ArtGruppe.Suchbegriff   >= ArtGrpSuchbegriff_min
          and S_ArtGruppe.Suchbegriff   <= ArtGrpSuchbegriff_max
          and S_ArtGruppe.Selektion     >= ArtGrpSelektion_min
          and S_ArtGruppe.Selektion     <= ArtGrpSelektion_max)
      and can-find (first bS_ArtPreiseDatum
        where bS_ArtPreiseDatum.Firma       = {firma/sartprda.fir S_Artikel.Firma}
          and bS_ArtPreiseDatum.Artikel     = S_Artikel.Artikel
          and bS_ArtPreiseDatum.PreisGruppe = PreisGruppe_alt_var)
    {&{&PA-XBasisName}_C_Selektion}
    {&{&PA-XBasisName}_U_Selektion}
    {&{&PA-XBasisName}_Q_Selektion}
    {&{&PA-XBasisName}_Selektion}
    {&{&PA-XBasisName}_Y_Selektion}
    no-lock
    transaction
    on error  undo, retry
    on endkey undo, retry:

    /*-----------------------------------------------------------------------*/
    /* Pr�fe gegen Abbruch                                                   */
    /*-----------------------------------------------------------------------*/

    {adm/template/incl/dt_job11.if
      &AbbruchFkt = "leave Schleife."
    }

    if not basis.sml.cls.BSCClassificationSvc:prpoInstance:lInSelection
             ('SAR':U,
              S_Artikel.Firma,
              S_Artikel.S_Artikel_Obj,
              pc_ParamListe) then

      next Schleife.

    lGeaendert = no.

    /*-----------------------------------------------------------------------*/
    /* Preislisten neu=alt                                                   */
    /*-----------------------------------------------------------------------*/

    if PreisGruppe_neu_var = PreisGruppe_alt_var then do:

      find last Buf_Alt_PreiseDatum
        where Buf_Alt_PreiseDatum.Firma        = {firma/sartprda.fir S_Artikel.Firma}
          and Buf_Alt_PreiseDatum.Artikel      = S_Artikel.Artikel
          and Buf_Alt_PreiseDatum.PreisGruppe  = PreisGruppe_alt_var
          and Buf_Alt_PreiseDatum.gueltig_ab  <= gueltig_ab_alt_var
          and Buf_Alt_PreiseDatum.gueltig_bis >= gueltig_ab_alt_var
        use-index PreisFind
        no-lock no-error.

      if not available Buf_Alt_PreiseDatum
        or can-find(last Buf2_Alt_PreiseDatum
          where Buf2_Alt_PreiseDatum.Firma        = {firma/sartprda.fir S_Artikel.Firma}
            and Buf2_Alt_PreiseDatum.Artikel      = S_Artikel.Artikel
            and Buf2_Alt_PreiseDatum.PreisGruppe  = PreisGruppe_alt_var
            and Buf2_Alt_PreiseDatum.gueltig_ab  <= gueltig_ab_alt_var
            and Buf2_Alt_PreiseDatum.gueltig_ab  >  Buf_Alt_PreiseDatum.gueltig_ab
            and Buf2_Alt_PreiseDatum.gueltig_bis  = ?
          use-index PreisFind)
      then

        find last Buf_Alt_PreiseDatum
          where Buf_Alt_PreiseDatum.Firma        = {firma/sartprda.fir S_Artikel.Firma}
            and Buf_Alt_PreiseDatum.Artikel      = S_Artikel.Artikel
            and Buf_Alt_PreiseDatum.PreisGruppe  = PreisGruppe_alt_var
            and Buf_Alt_PreiseDatum.gueltig_ab  <= gueltig_ab_alt_var
            and Buf_Alt_PreiseDatum.gueltig_bis  = ?
          use-index PreisFind
          no-lock no-error.

      if available Buf_Alt_PreiseDatum then do:

        /* depending on the filter settings it might happen, that the record  */        
        /* currently available in Buf_Alt_PreiseDatum gets deleted with the   */
        /* buffer S_ArtPreiseDatum. As a result of this the creation of the   */
        /* record using the buffer values would fail with a Progress error 91 */
        /* To avoid this we copy the relevant data into temp tables before    */
        /* the deletion.                                                      */

        empty temp-table ttS_ArtPreiseDatum-P.
        empty temp-table ttS_ArtPreiseStaffel-P.

        create ttS_ArtPreiseDatum-P.

        {buffer-copy
           Buf_Alt_PreiseDatum
           to ttS_ArtPreiseDatum-P}

        for each Buf_Alt_PreiseStaffel
          where Buf_Alt_PreiseStaffel.Firma       = {firma/sartprda.fir S_Artikel.Firma}
            and Buf_Alt_PreiseStaffel.Artikel     = Buf_Alt_PreiseDatum.Artikel
            and Buf_Alt_PreiseStaffel.PreisGruppe = Buf_Alt_PreiseDatum.PreisGruppe
            and Buf_Alt_PreiseStaffel.gueltig_ab  = Buf_Alt_PreiseDatum.gueltig_ab
            and Buf_Alt_PreiseStaffel.gueltig_bis = Buf_Alt_PreiseDatum.gueltig_bis
          no-lock
          on error undo, throw:

          create ttS_ArtPreiseStaffel-P.            

          {buffer-copy
             Buf_Alt_PreiseStaffel
             to ttS_ArtPreiseStaffel-P}

        end. /* for each Buf_Alt_PreiseStaffel */                

        /*-------------------------------------------------------------------*/
        /* wenn neue Preisliste mit dem neuen Datum bereits vorhanden ist,   */
        /* wird diese zuerst einmal gel�scht.                                */
        /*-------------------------------------------------------------------*/          

        find S_ArtPreiseDatum
          where S_ArtPreiseDatum.Firma       = {firma/sartprda.fir S_Artikel.Firma}
            and S_ArtPreiseDatum.Artikel     = S_Artikel.Artikel
            and S_ArtPreiseDatum.PreisGruppe = PreisGruppe_neu_var
            and S_ArtPreiseDatum.gueltig_ab  = gueltig_ab_neu_var
            and S_ArtPreiseDatum.gueltig_bis = gueltig_bis_neu_var
          exclusive-lock no-error.

        if available S_ArtPreiseDatum then                                                                 

          delete S_ArtPreiseDatum.

        /*-------------------------------------------------------------------*/
        /* neue Preisliste anlegen                                           */
        /*-------------------------------------------------------------------*/

        create S_ArtPreiseDatum.

        assign
          S_ArtPreiseDatum.Firma         = {firma/sartprda.fir S_Artikel.Firma}
          S_ArtPreiseDatum.Artikel       = S_Artikel.Artikel
          S_ArtPreiseDatum.PreisGruppe   = PreisGruppe_neu_var
          S_ArtPreiseDatum.StaffelGruppe = ttS_ArtPreiseDatum-P.StaffelGruppe
          S_ArtPreiseDatum.gueltig_ab    = gueltig_ab_neu_var
          S_ArtPreiseDatum.gueltig_bis   = gueltig_bis_neu_var
          .

        validate S_ArtPreiseDatum.

        for each ttS_ArtPreiseStaffel-P
          where ttS_ArtPreiseStaffel-P.Firma       = {firma/sartprda.fir S_Artikel.Firma}
            and ttS_ArtPreiseStaffel-P.Artikel     = ttS_ArtPreiseDatum-P.Artikel
            and ttS_ArtPreiseStaffel-P.PreisGruppe = ttS_ArtPreiseDatum-P.PreisGruppe
            and ttS_ArtPreiseStaffel-P.gueltig_ab  = ttS_ArtPreiseDatum-P.gueltig_ab
            and ttS_ArtPreiseStaffel-P.gueltig_bis = ttS_ArtPreiseDatum-P.gueltig_bis
          no-lock
          on error undo Schleife, retry Schleife:

          create S_ArtPreiseStaffel.

          assign
            S_ArtPreiseStaffel.Firma         = {firma/sartprda.fir S_Artikel.Firma}
            S_ArtPreiseStaffel.Artikel       = S_Artikel.Artikel
            S_ArtPreiseStaffel.PreisGruppe   = PreisGruppe_neu_var
            S_ArtPreiseStaffel.gueltig_ab    = S_ArtPreiseDatum.gueltig_ab
            S_ArtPreiseStaffel.gueltig_bis   = S_ArtPreiseDatum.gueltig_bis
            S_ArtPreiseStaffel.StaffelMenge  = ttS_ArtPreiseStaffel-P.StaffelMenge
            S_ArtPreiseStaffel.Preis         = if ZuschlagsArt_var = true then
                                                 ttS_ArtPreiseStaffel-P.Preis + Zuschlag_var
                                               else
                                                 ttS_ArtPreiseStaffel-P.Preis *   (1 + Zuschlag_var / 100)
            .

          validate S_ArtPreiseStaffel.

          if Rundungswert_var > 0 then

            S_ArtPreiseStaffel.Preis = round(S_ArtPreiseStaffel.Preis / (Rundungswert_var * 10) , 1)
                                             * Rundungswert_var * 10.

        end. /* for each Buf_Alt_PreiseStaffel */

        lGeaendert = yes.

      end. /* preis vorhanden */

    end. /* alt=neu */

    else do:

      /*---------------------------------------------------------------------*/
      /* neu <> alt                                                          */
      /*---------------------------------------------------------------------*/

      find last Buf_Alt_PreiseDatum
        where Buf_Alt_PreiseDatum.Firma        = {firma/sartprda.fir S_Artikel.Firma}
          and Buf_Alt_PreiseDatum.Artikel      = S_Artikel.Artikel
          and Buf_Alt_PreiseDatum.PreisGruppe  = PreisGruppe_alt_var
          and Buf_Alt_PreiseDatum.gueltig_ab  <= gueltig_ab_alt_var
          and Buf_Alt_PreiseDatum.gueltig_bis >= gueltig_ab_alt_var
        use-index PreisFind
        no-lock no-error.

      if not available Buf_Alt_PreiseDatum
        or can-find(last Buf2_Alt_PreiseDatum
          where Buf2_Alt_PreiseDatum.Firma        = {firma/sartprda.fir S_Artikel.Firma}
            and Buf2_Alt_PreiseDatum.Artikel      = S_Artikel.Artikel
            and Buf2_Alt_PreiseDatum.PreisGruppe  = PreisGruppe_alt_var
            and Buf2_Alt_PreiseDatum.gueltig_ab  <= gueltig_ab_alt_var
            and Buf2_Alt_PreiseDatum.gueltig_ab  >  Buf_Alt_PreiseDatum.gueltig_ab
            and Buf2_Alt_PreiseDatum.gueltig_bis  = ?
          use-index PreisFind)
      then

        find last Buf_Alt_PreiseDatum
          where Buf_Alt_PreiseDatum.Firma        = {firma/sartprda.fir S_Artikel.Firma}
            and Buf_Alt_PreiseDatum.Artikel      = S_Artikel.Artikel
            and Buf_Alt_PreiseDatum.PreisGruppe  = PreisGruppe_alt_var
            and Buf_Alt_PreiseDatum.gueltig_ab  <= gueltig_ab_alt_var
            and Buf_Alt_PreiseDatum.gueltig_bis  = ?
          use-index PreisFind
          no-lock no-error.

      if available Buf_Alt_PreiseDatum then do:

        /*-------------------------------------------------------------------*/
        /* weicht die W�hrung der Preislisten voneinander ab, so ist         */
        /* die Kursdifferenz zu ermitteln                                    */
        /*-------------------------------------------------------------------*/

        d_Kursfaktor = 1.

        find Buf_Alt_Preisgruppe
          where Buf_Alt_PreisGruppe.Firma       = {firma/spreisgr.fir pa-firma}
            and Buf_Alt_PreisGruppe.PreisGruppe = PreisGruppe_alt_var
          no-lock.

        find S_Preisgruppe
          where S_PreisGruppe.Firma       = {firma/spreisgr.fir pa-firma}
            and S_PreisGruppe.PreisGruppe = PreisGruppe_neu_var
          no-lock.

        if Buf_Alt_PreisGruppe.Waehrung <> S_Preisgruppe.Waehrung then do:

          &IF lookup ("V_":U,"{&pa-Module}":U) > 0 &THEN

            d_Kurs_alt = {fnarg
                           pa_dCurGetExchangeRate
                           "pa-Firma,
                            Buf_Alt_PreisGruppe.Waehrung,
                            today,
                            string({&pa_V_Kurs}),
                            0,
                            '':U"}. /* ohne Bezug zum Konto */

            if d_Kurs_alt = ? then

               next Schleife.

            d_Kurs_neu = {fnarg
                           pa_dCurGetExchangeRate
                           "pa-Firma,
                            S_PreisGruppe.Waehrung,
                            today,
                            string({&pa_V_Kurs}),
                            0,
                            '':U"}. /* ohne Bezug zum Konto */

            if d_Kurs_neu = ? then

              next Schleife.

            d_KursFaktor = d_Kurs_alt / d_Kurs_neu.


          &ELSE

            d_Kurs_alt = {fnarg
                           pa_dCurGetExchangeRate
                           "pa-Firma,
                            Buf_Alt_PreisGruppe.Waehrung,
                            today,
                            {&pa_Mittelkurs},
                            0,
                            '':U"}. /* ohne Bezug zum Konto */

            if d_Kurs_alt = ? then

               next Schleife.

            d_Kurs_neu = {fnarg
                           pa_dCurGetExchangeRate
                           "pa-Firma,
                            S_PreisGruppe.Waehrung,
                            today,
                            {&pa_Mittelkurs},
                            0,
                            '':U"}. /* ohne Bezug zum Konto */

            if d_Kurs_neu = ? then

               next Schleife.

            d_KursFaktor = d_Kurs_alt / d_Kurs_neu.

          &ENDIF

        end. /* if Buf_Alt_PreisGruppe.Waehrung <> S_Preisgruppe.Waehrung */

        /*-------------------------------------------------------------------*/
        /* wenn neue Preisliste mit dem neuen Datum bereits vorhanden ist,   */
        /* wird diese zuerst einmal gel�scht.                                */
        /*-------------------------------------------------------------------*/

        find S_ArtPreiseDatum
          where S_ArtPreiseDatum.Firma       = {firma/sartprda.fir pa-firma}
            and S_ArtPreiseDatum.Artikel     = S_Artikel.Artikel
            and S_ArtPreiseDatum.PreisGruppe = PreisGruppe_neu_var
            and S_ArtPreiseDatum.gueltig_ab  = gueltig_ab_neu_var
            and S_ArtPreiseDatum.gueltig_bis = gueltig_bis_neu_var
          exclusive-lock no-error.

        if available S_ArtPreiseDatum then

          delete S_ArtPreiseDatum.

        /*-------------------------------------------------------------------*/
        /* neue Preisliste anlegen                                           */
        /*-------------------------------------------------------------------*/

        create S_ArtPreiseDatum.

        assign
          S_ArtPreiseDatum.Firma         = {firma/sartprda.fir pa-firma}
          S_ArtPreiseDatum.Artikel       = S_Artikel.Artikel
          S_ArtPreiseDatum.PreisGruppe   = PreisGruppe_neu_var
          S_ArtPreiseDatum.StaffelGruppe = Buf_Alt_PreiseDatum.StaffelGruppe
          S_ArtPreiseDatum.gueltig_ab    = gueltig_ab_neu_var
          S_ArtPreiseDatum.gueltig_bis   = gueltig_bis_neu_var
          .

        validate S_ArtPreiseDatum.

        for each Buf_Alt_PreiseStaffel
          where Buf_Alt_PreiseStaffel.Firma       = Buf_Alt_PreiseDatum.Firma
            and Buf_Alt_PreiseStaffel.Artikel     = Buf_Alt_PreiseDatum.Artikel
            and Buf_Alt_PreiseStaffel.PreisGruppe = Buf_Alt_PreiseDatum.PreisGruppe
            and Buf_Alt_PreiseStaffel.gueltig_ab  = Buf_Alt_PreiseDatum.gueltig_ab
            and Buf_Alt_PreiseStaffel.gueltig_bis = Buf_Alt_PreiseDatum.gueltig_bis
          no-lock
          on error undo Schleife, retry Schleife:

          create S_ArtPreiseStaffel.

          assign
            S_ArtPreiseStaffel.Firma        = {firma/sartprda.fir S_Artikel.Firma}
            S_ArtPreiseStaffel.Artikel      = S_Artikel.Artikel
            S_ArtPreiseStaffel.PreisGruppe  = PreisGruppe_neu_var
            S_ArtPreiseStaffel.gueltig_ab   = S_ArtPreiseDatum.gueltig_ab
            S_ArtPreiseStaffel.gueltig_bis  = S_ArtPreiseDatum.gueltig_bis
            S_ArtPreiseStaffel.StaffelMenge = Buf_Alt_PreiseStaffel.StaffelMenge
            S_ArtPreiseStaffel.Preis        = (if ZuschlagsArt_var = true then
                                                 (Buf_Alt_PreiseStaffel.Preis + Zuschlag_var) * d_Kursfaktor
                                               else
                                                 Buf_Alt_PreiseStaffel.Preis * (1 + Zuschlag_var / 100) * d_Kursfaktor)

            .

          validate S_ArtPreiseStaffel.

          if Rundungswert_var > 0 then

            S_ArtPreiseStaffel.Preis = round(S_ArtPreiseStaffel.Preis / (Rundungswert_var * 10) , 1)
                                             * Rundungswert_var * 10.

        end. /* for each Buf_Alt_PreiseStaffel */

        lGeaendert = yes.

      end. /* preis vorhanden */

    end. /* neu <> alt */

    &IF "{&PA_BB_MANAEG}":U = "1":U &THEN

      /*---------------------------------------------------------------------*/
      /* Schreibe Anderungsgrund wenn vorhanden                              */
      /*---------------------------------------------------------------------*/

      if    lGeaendert
        and Aenderung_var then
      do:

        basis.buro.cls.BBCAuditSvc:prpoInstance:lLogUpdateReason ('':U,
                                                                  S_ArtPreiseDatum.S_ArtPreiseDatum_Obj,
                                                                  AenderungsGrund_var,
                                                                  Bemerkung_var,
                                                                  c_Benutzer).

        basis.buro.cls.BBCAuditSvc:prpoInstance:ClearApplicationContext().

      end. /* �nderung durchgef�hrt */

    &ENDIF

  end. /* for each */ 

/* --> MO#DIETZ-SFL-0010 thongdi_p 29/06/2026 V�nderung Kundensonderpreise */
if lKundensonderpreise = yes then
do:
  
  /*-------------------------------------------------------------------------*/
  /* Implementing customer special prices                                    */
  /*-------------------------------------------------------------------------*/
   
  if   iCustomer_min <> 0 
    or iCustomer_max <> 0 then
  do:   
    
    lKundensonderpreise:
      
    for each S_ArtKunde
      where S_ArtKunde.Firma   = {firma/sartkund.fir pACConnectionSvc:prpcCompany}
        and S_ArtKunde.Kunde  >= iCustomer_min
        and S_ArtKunde.Kunde  <= iCustomer_max
      no-lock:
        
      for each Buf_Alt_KundeDatum
        where  Buf_Alt_KundeDatum.Firma        =  {firma/sartkund.fir pACConnectionSvc:prpcCompany}
          and  Buf_Alt_KundeDatum.Artikel      =  S_ArtKunde.Artikel
          and  Buf_Alt_KundeDatum.Kunde        =  S_ArtKunde.Kunde
          and  Buf_Alt_KundeDatum.gueltig_ab   <= tGueltig_ab_alt
          and (Buf_Alt_KundeDatum.gueltig_bis  >= tGueltig_ab_alt
           or  Buf_Alt_KundeDatum.gueltig_bis  =  ?)
        no-lock
        transaction
        on error  undo, retry
        on endkey undo, retry:
        
        /*-------------------------------------------------------------------*/
        /* Check against cancellation                                        */
        /*-------------------------------------------------------------------*/
        
        {adm/template/incl/dt_job11.if
          &AbbruchFkt = "leave lKundensonderpreise."
        }
        
        /*-------------------------------------------------------------------*/
        /* Copy data to temp tables (as per the standard)                    */
        /*-------------------------------------------------------------------*/
        empty temp-table ttS_ArtKundeDatum-P.
        empty temp-table ttS_ArtKundeStaffel-P.
        
        create ttS_ArtKundeDatum-P.
        
        {buffer-copy
           Buf_Alt_KundeDatum
           to ttS_ArtKundeDatum-P}
           
        for each Buf_Alt_KundeStaffel
          where Buf_Alt_KundeStaffel.Firma       = {firma/sartkund.fir pACConnectionSvc:prpcCompany}
            and Buf_Alt_KundeStaffel.Artikel     = Buf_Alt_KundeDatum.Artikel
            and Buf_Alt_KundeStaffel.Kunde       = Buf_Alt_KundeDatum.Kunde
            and Buf_Alt_KundeStaffel.gueltig_ab  = Buf_Alt_KundeDatum.gueltig_ab
            and Buf_Alt_KundeStaffel.gueltig_bis = Buf_Alt_KundeDatum.gueltig_bis
          no-lock
          on error undo, throw:
            
          create ttS_ArtKundeStaffel-P.
          
          {buffer-copy
             Buf_Alt_KundeStaffel
             to ttS_ArtKundeStaffel-P}
             
        end. /* for each Buf_Alt_KundeStaffel */
        
        /*-------------------------------------------------------------------*/
        /* If a customer special price with a new date already exists, it    */
        /* will be deleted first.                                            */
        /*-------------------------------------------------------------------*/
        
        find S_ArtKundeDatum
          where S_ArtKundeDatum.Firma       = {firma/sartkund.fir pACConnectionSvc:prpcCompany}
            and S_ArtKundeDatum.Artikel     = S_ArtKunde.Artikel
            and S_ArtKundeDatum.Kunde       = S_ArtKunde.Kunde
            and S_ArtKundeDatum.gueltig_ab  = tGueltig_ab_neu
            and S_ArtKundeDatum.gueltig_bis = tGueltig_bis_neu
          exclusive-lock no-error.
        
        if available S_ArtKundeDatum then
          delete S_ArtKundeDatum.
        
        /*-------------------------------------------------------------------*/
        /* Create a new special customer price                               */
        /*-------------------------------------------------------------------*/
        
        create S_ArtKundeDatum.
        
        assign
          S_ArtKundeDatum.Firma         = {firma/sartkund.fir pACConnectionSvc:prpcCompany}
          S_ArtKundeDatum.Artikel       = S_ArtKunde.Artikel
          S_ArtKundeDatum.Kunde         = S_ArtKunde.Kunde
          S_ArtKundeDatum.gueltig_ab    = tGueltig_ab_neu
          S_ArtKundeDatum.gueltig_bis   = tGueltig_bis_neu
          .
          
        validate S_ArtKundeDatum.
        
        /*-------------------------------------------------------------------*/
        /* Copy tiered pricing                                               */
        /*-------------------------------------------------------------------*/
        
        for each ttS_ArtKundeStaffel-P
          where ttS_ArtKundeStaffel-P.Firma       = {firma/sartkund.fir pACConnectionSvc:prpcCompany}
            and ttS_ArtKundeStaffel-P.Artikel     = ttS_ArtKundeDatum-P.Artikel
            and ttS_ArtKundeStaffel-P.Kunde       = ttS_ArtKundeDatum-P.Kunde
            and ttS_ArtKundeStaffel-P.gueltig_ab  = ttS_ArtKundeDatum-P.gueltig_ab
            and ttS_ArtKundeStaffel-P.gueltig_bis = ttS_ArtKundeDatum-P.gueltig_bis
          no-lock
          on error undo lKundensonderpreise, retry lKundensonderpreise:
          
          create S_ArtKundeStaffel.
          
          assign
            S_ArtKundeStaffel.Firma         = {firma/sartkund.fir pACConnectionSvc:prpcCompany}
            S_ArtKundeStaffel.Artikel       = S_ArtKunde.Artikel
            S_ArtKundeStaffel.Kunde         = S_ArtKunde.Kunde
            S_ArtKundeStaffel.gueltig_ab    = S_ArtKundeDatum.gueltig_ab
            S_ArtKundeStaffel.gueltig_bis   = S_ArtKundeDatum.gueltig_bis
            S_ArtKundeStaffel.StaffelMenge  = ttS_ArtKundeStaffel-P.StaffelMenge
            S_ArtKundeStaffel.Preis         = if ZuschlagsArt_var = true then
                                                ttS_ArtKundeStaffel-P.Preis + Zuschlag_var
                                              else
                                                ttS_ArtKundeStaffel-P.Preis * (1 + Zuschlag_var / 100)
            .
            
          validate S_ArtKundeStaffel.
          
          if Rundungswert_var > 0 then
            S_ArtKundeStaffel.Preis = round(S_ArtKundeStaffel.Preis / (Rundungswert_var * 10), 1)
                                            * Rundungswert_var * 10.
          
        end. /* for each ttS_ArtKundeStaffel-P */
             
      end. /* for each Buf_Alt_KundeDatum */ 
      
    end. /* for each S_ArtKunde */   
        
  end. /* if   iCustomer_min <> 0 
            or iCustomer_max <> 0 */
                      
end. /* else if lKundensonderpreise = yes */  
  
/* <-- MO#DIETZ-SFL-0010 thongdi_p 29/06/2026 V�nderung Kundensonderpreise */

  /*-------------------------------------------------------------------------*/
  /* gebe den Status zur�ck                                                  */
  /*-------------------------------------------------------------------------*/

  {adm/template/incl/dt_job07.if}

  end. /* Main */

/*---------------------------------------------------------------------------*/
/* Ende s_vpae01.p                                                           */
/*---------------------------------------------------------------------------*/

{adm/template/incl/dt_job00.if}

/* _UIB-CODE-BLOCK-END */
&ANALYZE-RESUME

