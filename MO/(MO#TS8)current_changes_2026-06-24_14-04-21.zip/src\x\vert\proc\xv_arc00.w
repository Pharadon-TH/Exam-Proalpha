&ANALYZE-SUSPEND _VERSION-NUMBER UIB_v8r12 GUI
&ANALYZE-RESUME
&Scoped-define WINDOW-NAME CURRENT-WINDOW
&Scoped-define FRAME-NAME Dialog-Frame

&ANALYZE-SUSPEND _UIB-CODE-BLOCK _CUSTOM _DECLARATIONS Dialog-Frame 

/* _UIB-CODE-BLOCK-END */
&ANALYZE-RESUME


&ANALYZE-SUSPEND _UIB-CODE-BLOCK _XFTR "Update Information" Dialog-Frame _INLINE
/* Actions: ? ? ? ? adm/support/proc/ds_pa_01.w */

/* _UIB-CODE-BLOCK-END */
&ANALYZE-RESUME

&ANALYZE-SUSPEND _UIB-CODE-BLOCK _CUSTOM _DEFINITIONS Dialog-Frame 
/******************************************************************************/
/* @COPYRIGHT@                                                                */
/* Project: Proalpha                                                          */
/*                                                                            */
/* Name   : xv_arc00.w                                                        */
/* Product: X            - Individualanpassungen extern                       */
/* Module : VERT         - Vertrieb                                           */
/*                                                                            */
/* Created: 9.5 as of 24.06.2026/thongdi_p                                    */
/* Current: @PAVERSION@ as of @PADATE@/@PALASTAUTHOR@                         */
/*                                                                            */
/*----------------------------------------------------------------------------*/
/* DESCRIPTION                                                                */
/*----------------------------------------------------------------------------*/
/*                                                                            */
/* Dialog Archived Quotes for Angebot (Filter)                                */
/*                                                                            */
/*----------------------------------------------------------------------------*/
/* PARAMETERS                                                                 */
/*----------------------------------------------------------------------------*/
/* Name                      Description                                      */
/*----------------------------------------------------------------------------*/
/*                                                                            */
/*----------------------------------------------------------------------------*/
/* HISTORY                                                                    */
/*----------------------------------------------------------------------------*/
/* @FILEHISTORY@                                                              */
/******************************************************************************/

create widget-pool.

/* Procedure Information -----------------------------------------------------*/

&GLOBAL-DEFINE pa-Autor            thongdi_p
&GLOBAL-DEFINE pa-Version          @PAVERSION@
&GLOBAL-DEFINE pa-Datum            @PADATE@
&GLOBAL-DEFINE pa-Letzter          @PALASTAUTHOR@

&GLOBAL-DEFINE pa-GenVersion       UIB
&GLOBAL-DEFINE pa-ProgrammTyp      PrintDialog
&GLOBAL-DEFINE pa-Template         adm/template/dt_dlg02.w
&GLOBAL-DEFINE pa-TemplateVersion  3.01
&GLOBAL-DEFINE pa-XBasisName       xv_arc00_w
&GLOBAL-DEFINE pa-NameSpace        2.10
&GLOBAL-DEFINE pa-ZielProgramm 'bjvjob02.p#XVCArchiveQuotesJob':U

/* Parameters ----------------------------------------------------------------*/

/* Globals -------------------------------------------------------------------*/

{adm/template/incl/dt_dlg01.df}

/* SCOPEDs -------------------------------------------------------------------*/

&GLOBAL-DEFINE pa-WflArea
&GLOBAL-DEFINE pa-WflCompany

/* Variables -----------------------------------------------------------------*/
/*----------------------------------------------------------------------------*/

/* Buffers -------------------------------------------------------------------*/

/* _UIB-CODE-BLOCK-END */
&ANALYZE-RESUME


&ANALYZE-SUSPEND _UIB-PREPROCESSOR-BLOCK 

/* ********************  Preprocessor Definitions  ******************** */

&Scoped-define PROCEDURE-TYPE DIALOG-BOX
&Scoped-define DB-AWARE no

/* Name of designated FRAME-NAME and/or first browse and/or first query */
&Scoped-define FRAME-NAME Dialog-Frame

/* Standard List Definitions                                            */
&Scoped-Define ENABLED-OBJECTS AuftragsArt_min AuftragsArt_max ~
gueltig_bis_min gueltig_bis_max AnlageDatum_min AnlageDatum_max Btn_Start ~
Btn_Cancel 
&Scoped-Define DISPLAYED-OBJECTS AuftragsArt_min AuftragsArt_max ~
gueltig_bis_min gueltig_bis_max AnlageDatum_min AnlageDatum_max c_von c_bis 

/* Custom List Definitions                                              */
/* pa-YearFields,pa-ResetFields,List-3,List-4,List-5,List-6             */

/* _UIB-PREPROCESSOR-BLOCK-END */
&ANALYZE-RESUME


&ANALYZE-SUSPEND _UIB-CODE-BLOCK _XFTR "InfoFields" Dialog-Frame _INLINE
/* Actions: ? ? ? ? adm/support/proc/ds_inf01.p */
/* STRUCTURED-DATA
<Build-Information>
1.02
</Build-Information>
<Constants></Constants>
<InfoFields></InfoFields> */
/* _UIB-CODE-BLOCK-END */
&ANALYZE-RESUME

&ANALYZE-SUSPEND _UIB-CODE-BLOCK _XFTR "Dynamic InfoFields" Dialog-Frame _INLINE
/* Actions: ? ? ? ? adm/support/proc/ds_viw09.p */
/* _UIB-CODE-BLOCK-END */
&ANALYZE-RESUME

&ANALYZE-SUSPEND _UIB-CODE-BLOCK _XFTR "FieldDefinitions" Dialog-Frame _INLINE
/* Actions: ? ? ? ? adm/support/proc/ds_dlg01.p */
/* STRUCTURED-DATA
<DATA></DATA>
<FRAME>
****/
define frame f_dummy
with side-labels width 255 stream-io.
/****
</FRAME> */
/* _UIB-CODE-BLOCK-END */
&ANALYZE-RESUME

&ANALYZE-SUSPEND _UIB-CODE-BLOCK _XFTR "Skin Client Support" Dialog-Frame _INLINE
/* Actions: ? ? ? ? adm/support/proc/ds_skc00.p */
/* _UIB-CODE-BLOCK-END */
&ANALYZE-RESUME


/* ***********************  Control Definitions  ********************** */

/* Define a dialog box                                                  */

/* Definitions of the field level widgets                               */
DEFINE BUTTON Btn_Cancel AUTO-END-KEY 
     LABEL "Abbruch":T8 
     SIZE 12 BY 1.

DEFINE BUTTON Btn_Start AUTO-GO 
     LABEL "OK":T8 
     SIZE 12 BY 1.

DEFINE VARIABLE AnlageDatum_max AS DATE FORMAT "99.99.9999":U 
     VIEW-AS FILL-IN 
     SIZE 12 BY 1 NO-UNDO.

DEFINE VARIABLE AnlageDatum_min AS DATE FORMAT "99.99.9999":U 
     LABEL "Anlagedatum":R18 
     VIEW-AS FILL-IN 
     SIZE 12 BY 1 NO-UNDO.

DEFINE VARIABLE AuftragsArt_max AS CHARACTER FORMAT "x(2)":U 
     VIEW-AS FILL-IN 
     SIZE 4 BY 1 NO-UNDO.

DEFINE VARIABLE AuftragsArt_min AS CHARACTER FORMAT "x(2)":U 
     LABEL "Auftragsart":R18 
     VIEW-AS FILL-IN 
     SIZE 4 BY 1 NO-UNDO.

DEFINE VARIABLE c_bis AS CHARACTER FORMAT "X(256)":U 
      VIEW-AS TEXT 
     SIZE 14 BY .63 NO-UNDO.

DEFINE VARIABLE c_von AS CHARACTER FORMAT "X(256)":U 
      VIEW-AS TEXT 
     SIZE 14 BY .63 NO-UNDO.

DEFINE VARIABLE gueltig_bis_max AS DATE FORMAT "99.99.9999":U 
     VIEW-AS FILL-IN 
     SIZE 12 BY 1 NO-UNDO.

DEFINE VARIABLE gueltig_bis_min AS DATE FORMAT "99.99.9999":U 
     LABEL "G�ltig bis":R18 
     VIEW-AS FILL-IN 
     SIZE 12 BY 1 NO-UNDO.


/* ************************  Frame Definitions  *********************** */

DEFINE FRAME Dialog-Frame
     AuftragsArt_min AT ROW 2.5 COL 21 COLON-ALIGNED
     AuftragsArt_max AT ROW 2.5 COL 46 COLON-ALIGNED NO-LABEL
     gueltig_bis_min AT ROW 3.5 COL 21 COLON-ALIGNED
     gueltig_bis_max AT ROW 3.5 COL 46 COLON-ALIGNED NO-LABEL
     AnlageDatum_min AT ROW 5 COL 21 COLON-ALIGNED
     AnlageDatum_max AT ROW 5 COL 46 COLON-ALIGNED NO-LABEL
     Btn_Start AT ROW 7 COL 2
     Btn_Cancel AT ROW 7 COL 15
     c_von AT ROW 1.5 COL 21 COLON-ALIGNED NO-LABEL
     c_bis AT ROW 1.5 COL 46 COLON-ALIGNED NO-LABEL
     SPACE(18.16) SKIP(6.36)
    WITH VIEW-AS DIALOG-BOX KEEP-TAB-ORDER 
         SIDE-LABELS NO-UNDERLINE THREE-D  SCROLLABLE 
         TITLE "Filter Angebote":T60
         DEFAULT-BUTTON Btn_Start CANCEL-BUTTON Btn_Cancel.


/* *********************** Procedure Settings ************************ */

&ANALYZE-SUSPEND _PROCEDURE-SETTINGS
/* Settings for THIS-PROCEDURE
   Type: DIALOG-BOX
   Allow: Basic,DB-Fields
 */
&ANALYZE-RESUME _END-PROCEDURE-SETTINGS

&ANALYZE-SUSPEND _UIB-CODE-BLOCK _CUSTOM _INCLUDED-LIB Dialog-Frame 
/* ************************* Included-Libraries *********************** */

{adm/method/incl/dm_dlg00.lib}

/* _UIB-CODE-BLOCK-END */
&ANALYZE-RESUME




/* ***********  Runtime Attributes and AppBuilder Settings  *********** */

&ANALYZE-SUSPEND _RUN-TIME-ATTRIBUTES
/* SETTINGS FOR DIALOG-BOX Dialog-Frame
   FRAME-NAME L-To-R                                                    */
ASSIGN 
       FRAME Dialog-Frame:SCROLLABLE       = FALSE
       FRAME Dialog-Frame:HIDDEN           = TRUE.

/* SETTINGS FOR FILL-IN c_bis IN FRAME Dialog-Frame
   NO-ENABLE                                                            */
/* SETTINGS FOR FILL-IN c_von IN FRAME Dialog-Frame
   NO-ENABLE                                                            */
/* _RUN-TIME-ATTRIBUTES-END */
&ANALYZE-RESUME

 



/* ************************  Control Triggers  ************************ */

&Scoped-define SELF-NAME Dialog-Frame
&ANALYZE-SUSPEND _UIB-CODE-BLOCK _CONTROL Dialog-Frame Dialog-Frame
ON WINDOW-CLOSE OF FRAME Dialog-Frame /* Filter Angebote */
DO:
  {adm/template/incl/dt_uit00.if
     &UserExitName = "ON_WINDOW-CLOSE_OF_FRAME"}

  {adm/template/incl/dt_dlg09.if}

  {adm/template/incl/dt_uit01.if
     &UserExitName = "ON_WINDOW-CLOSE_OF_FRAME"}
END.

/* _UIB-CODE-BLOCK-END */
&ANALYZE-RESUME


&Scoped-define SELF-NAME AnlageDatum_min
&ANALYZE-SUSPEND _UIB-CODE-BLOCK _CONTROL AnlageDatum_min Dialog-Frame
ON LEAVE OF AnlageDatum_min IN FRAME Dialog-Frame /* Anlagedatum */
do:
  {adm/template/incl/dt_uit00.if
     &UserExitName = "ON_LEAVE_OF_AnlageDatum_min"}

  {adm/template/incl/dt_dlg00.if &MAX-FELD = "AnlageDatum_max"}

  {adm/template/incl/dt_uit01.if
     &UserExitName = "ON_LEAVE_OF_AnlageDatum_min"}
end.

/* _UIB-CODE-BLOCK-END */
&ANALYZE-RESUME


&Scoped-define SELF-NAME AuftragsArt_min
&ANALYZE-SUSPEND _UIB-CODE-BLOCK _CONTROL AuftragsArt_min Dialog-Frame
ON LEAVE OF AuftragsArt_min IN FRAME Dialog-Frame /* Auftragsart */
do:
  {adm/template/incl/dt_uit00.if
     &UserExitName = "ON_LEAVE_OF_AuftragsArt_min"}

  {adm/template/incl/dt_dlg00.if &MAX-FELD = "AuftragsArt_max"}

  {adm/template/incl/dt_uit01.if
     &UserExitName = "ON_LEAVE_OF_AuftragsArt_min"}
end.

/* _UIB-CODE-BLOCK-END */
&ANALYZE-RESUME


&Scoped-define SELF-NAME Btn_Start
&ANALYZE-SUSPEND _UIB-CODE-BLOCK _CONTROL Btn_Start Dialog-Frame
ON CHOOSE OF Btn_Start IN FRAME Dialog-Frame /* OK */
DO:
  {adm/template/incl/dt_uit00.if
     &UserExitName = "ON_CHOOSE_OF_Btn_Start"}

  {adm/template/incl/dt_btn01.if}

  {adm/template/incl/dt_uit01.if
     &UserExitName = "ON_CHOOSE_OF_Btn_Start"}
END.

/* _UIB-CODE-BLOCK-END */
&ANALYZE-RESUME


&Scoped-define SELF-NAME gueltig_bis_max
&ANALYZE-SUSPEND _UIB-CODE-BLOCK _CONTROL gueltig_bis_max Dialog-Frame
ON LEAVE OF gueltig_bis_max IN FRAME Dialog-Frame
do:
  {adm/template/incl/dt_uit00.if
     &UserExitName = "ON_LEAVE_OF_gueltig_bis_max"}

  {adm/template/incl/dt_dlg00.if &MAX-FELD = "AnlageDatum_max"}

  {adm/template/incl/dt_uit01.if
     &UserExitName = "ON_LEAVE_OF_gueltig_bis_max"}
end.

/* _UIB-CODE-BLOCK-END */
&ANALYZE-RESUME


&Scoped-define SELF-NAME gueltig_bis_min
&ANALYZE-SUSPEND _UIB-CODE-BLOCK _CONTROL gueltig_bis_min Dialog-Frame
ON LEAVE OF gueltig_bis_min IN FRAME Dialog-Frame /* G�ltig bis */
do:
  {adm/template/incl/dt_uit00.if
     &UserExitName = "ON_LEAVE_OF_gueltig_bis_min"}

  {adm/template/incl/dt_dlg00.if &MAX-FELD = "AnlageDatum_max"}

  {adm/template/incl/dt_uit01.if
     &UserExitName = "ON_LEAVE_OF_gueltig_bis_min"}
end.

/* _UIB-CODE-BLOCK-END */
&ANALYZE-RESUME


&UNDEFINE SELF-NAME

&ANALYZE-SUSPEND _UIB-CODE-BLOCK _CUSTOM _MAIN-BLOCK Dialog-Frame 


/* ***************************  Main Block  *************************** */

{adm/template/incl/dt_dlg00.i}

run initialize in this-procedure.

/* Now enable the interface and wait for the exit condition.            */
/* (NOTE: handle ERROR and END-KEY so cleanup code will always fire.    */
MAIN-BLOCK:
DO ON ERROR   UNDO MAIN-BLOCK, LEAVE MAIN-BLOCK
   ON END-KEY UNDO MAIN-BLOCK, LEAVE MAIN-BLOCK:
  RUN enable_UI.

  /* Wait-for go of frame                                                     */

  {adm/template/incl/dt_dlg11.if}

END.
RUN disable_UI.


{adm/template/incl/dt_dlg08.if}

/* _UIB-CODE-BLOCK-END */
&ANALYZE-RESUME


/* **********************  Internal Procedures  *********************** */

&ANALYZE-SUSPEND _UIB-CODE-BLOCK _PROCEDURE assignData Dialog-Frame  adm/support/proc/ds_dlg10.p
PROCEDURE assignData :
/* Description ---------------------------------------------------------------*/
/*                                                                            */
/* Assign screen values to parameter string                                   */
/*                                                                            */
/* Parameters ----------------------------------------------------------------*/
/*                                                                            */
/* pcParamListe  List with data in Proalpha String format                     */
/*                                                                            */
/*----------------------------------------------------------------------------*/

define       output parameter pcParamListe as character     no-undo.

/* Variables -----------------------------------------------------------------*/
/*----------------------------------------------------------------------------*/

/* Buffers -------------------------------------------------------------------*/

/*----------------------------------------------------------------------------*/
/* Processing                                                                 */
/*----------------------------------------------------------------------------*/

/* Assign Screen Buffer                                                       */

{adm/template/incl/dt_dlg12.if}

/* Assign Default Values                                                      */

/* --> MO#SOPL-LGa-0805 thongdi_p 24/06/2026 Vertriebsangebote archivieren anhand Filterselektion */

pcParamListe = adm.method.cls.DMCParameterStringSvc:cWriteValue
                 ( /* pcPString */ pcParamListe,
                   /* pcKey     */ 'AuftragsArt_min':U,
                   /* pcValue   */ AuftragsArt_min ).
                   
pcParamListe = adm.method.cls.DMCParameterStringSvc:cWriteValue
                 ( /* pcPString */ pcParamListe,
                   /* pcKey     */ 'AuftragsArt_max':U,
                   /* pcValue   */ AuftragsArt_max ).
                   
pcParamListe = adm.method.cls.DMCParameterStringSvc:cWriteValue
                 ( /* pcPString */ pcParamListe,
                   /* pcKey     */ 'gueltig_bis_min':U,
                   /* pcValue   */ gueltig_bis_min ). 
                   
pcParamListe = adm.method.cls.DMCParameterStringSvc:cWriteValue
                 ( /* pcPString */ pcParamListe,
                   /* pcKey     */ 'gueltig_bis_max':U,
                   /* pcValue   */ gueltig_bis_max ). 
                   
pcParamListe = adm.method.cls.DMCParameterStringSvc:cWriteValue
                 ( /* pcPString */ pcParamListe,
                   /* pcKey     */ 'AnlageDatum_min':U,
                   /* pcValue   */ AnlageDatum_min ).
                   
pcParamListe = adm.method.cls.DMCParameterStringSvc:cWriteValue
                 ( /* pcPString */ pcParamListe,
                   /* pcKey     */ 'AnlageDatum_max':U,
                   /* pcValue   */ AnlageDatum_max ).                                         

/* <-- MO#SOPL-LGa-0805 thongdi_p 24/06/2026 Vertriebsangebote archivieren anhand Filterselektion */
                                                                           
/* Default Code                                                               */

{adm/template/incl/dt_dlg07.if}

return.

end procedure. /* assignData */

/* _UIB-CODE-BLOCK-END */
&ANALYZE-RESUME

&ANALYZE-SUSPEND _UIB-CODE-BLOCK _PROCEDURE disable_UI Dialog-Frame 
PROCEDURE disable_UI :
/* Description ---------------------------------------------------------------*/
/*                                                                            */
/* DISABLE the User Interface                                                 */
/*                                                                            */
/* Notes ---------------------------------------------------------------------*/
/*                                                                            */
/* Here we clean-up the user-interface by deleting dynamic widgets we have    */
/* created and/or hide frames.  This procedure is usually called when we are  */
/* ready to "clean-up" after running                                          */
/*                                                                            */
/* Parameters ----------------------------------------------------------------*/
/*                                                                            */
/* <none>                                                                     */
/*                                                                            */
/*----------------------------------------------------------------------------*/

/* Variables -----------------------------------------------------------------*/
/*----------------------------------------------------------------------------*/

/* Buffers -------------------------------------------------------------------*/

/*----------------------------------------------------------------------------*/
/* Processing                                                                 */
/*----------------------------------------------------------------------------*/

{adm/template/incl/dt_dlg06.if}

end procedure. /* disable_UI */

/* _UIB-CODE-BLOCK-END */
&ANALYZE-RESUME

&ANALYZE-SUSPEND _UIB-CODE-BLOCK _PROCEDURE enable_UI Dialog-Frame 
PROCEDURE enable_UI :
/* Description ---------------------------------------------------------------*/
/*                                                                            */
/* ENABLE the User Interface                                                  */
/*                                                                            */
/* Notes ---------------------------------------------------------------------*/
/*                                                                            */
/* Here we display/view/enable the widgets in the user-interface.             */
/* In addition, OPEN all queries associated with each FRAME and BROWSE.       */
/* These statements here are based on the "Other Settings" section of the     */
/* widget Property Sheets.                                                    */
/*                                                                            */
/* Parameters ----------------------------------------------------------------*/
/*                                                                            */
/* <none>                                                                     */
/*                                                                            */
/*----------------------------------------------------------------------------*/

/* Variables -----------------------------------------------------------------*/
/*----------------------------------------------------------------------------*/

/* Buffers -------------------------------------------------------------------*/

/*----------------------------------------------------------------------------*/
/* Processing                                                                 */
/*----------------------------------------------------------------------------*/

{adm/template/incl/dt_dlg03.if}

end procedure. /* enable_UI */

/* _UIB-CODE-BLOCK-END */
&ANALYZE-RESUME

&ANALYZE-SUSPEND _UIB-CODE-BLOCK _PROCEDURE initialize Dialog-Frame  adm/support/proc/ds_dlg02.p
PROCEDURE initialize :
/* Description ---------------------------------------------------------------*/
/*                                                                            */
/* Initialization                                                             */
/*                                                                            */
/* Notes ---------------------------------------------------------------------*/
/*                                                                            */
/* - Initialization of variables                                              */
/* - Assign format                                                            */
/*                                                                            */
/* Parameters ----------------------------------------------------------------*/
/*                                                                            */
/* <none>                                                                     */
/*                                                                            */
/*----------------------------------------------------------------------------*/

/* Variables -----------------------------------------------------------------*/
/* lExternalValueAvailable     Flag                                           */
/*----------------------------------------------------------------------------*/

define variable lExternalValueAvailable as logical       no-undo.

/*----------------------------------------------------------------------------*/
/* Processing                                                                 */
/*----------------------------------------------------------------------------*/

/* Initialize maximum values (use external data, if available)                */

/* --> MO#SOPL-LGa-0805 thongdi_p 24/06/2026 Vertriebsangebote archivieren anhand Filterselektion */

{adm/incl/d__par01.if
  &ParameterListe = "pc_Options"
  &Parameter      = "AuftragsArt"
  &Variable1      = "AuftragsArt_min"
  &Variable2      = "AuftragsArt_max"
  &Flag           = "lExternalValueAvailable"
}

if not lExternalValueAvailable then
do:
  {adm/template/incl/dt_dlg04.if
    &Variable = "AuftragsArt_min"
  }
  find last S_AuftragsArt
    where S_AuftragsArt.Firma = {firma/saufart.fir pa-Firma}
    use-index Main
    no-lock no-error.
  if available S_AuftragsArt then 
    AuftragsArt_max = S_AuftragsArt.AuftragsArt.
end. /* not lExternalValueAvailable */

{adm/incl/d__par01.if
  &ParameterListe = "pc_Options"
  &Parameter      = "gueltig_bis"
  &Variable1      = "gueltig_bis_min"
  &Variable2      = "gueltig_bis_max"
  &cc_Date        = "yes"
  &Flag           = "lExternalValueAvailable"
}

if not lExternalValueAvailable then
do:
  {adm/template/incl/dt_dlg04.if
    &Variable = "gueltig_bis_min"
    &Datentyp = "date"
  }
  {adm/template/incl/dt_dlg04.if
    &Variable = "gueltig_bis_max"
    &Datentyp = "date"
  }
end. /* not lExternalValueAvailable */

{adm/incl/d__par01.if
  &ParameterListe = "pc_Options"
  &Parameter      = "AnlageDatum"
  &Variable1      = "AnlageDatum_min"
  &Variable2      = "AnlageDatum_max"
  &cc_Date        = "yes"
  &Flag           = "lExternalValueAvailable"
}

if not lExternalValueAvailable then
do:
  {adm/template/incl/dt_dlg04.if
    &Variable = "AnlageDatum_min"
    &Datentyp = "date"
  }
  {adm/template/incl/dt_dlg04.if
    &Variable = "AnlageDatum_max"
    &Datentyp = "date"
  }
end. /* not lExternalValueAvailable */

/* <-- MO#SOPL-LGa-0805 thongdi_p 24/06/2026 Vertriebsangebote archivieren anhand Filterselektion */ 

/* Copy setup from dummy frame                                                */



/* Default Code                                                               */

{adm/template/incl/dt_dlg01.if}

end procedure. /* initialize */

/* _UIB-CODE-BLOCK-END */
&ANALYZE-RESUME

&ANALYZE-SUSPEND _UIB-CODE-BLOCK _PROCEDURE process-data Dialog-Frame  adm/support/proc/ds_dlg04.p
PROCEDURE process-data :
/* Description ---------------------------------------------------------------*/
/*                                                                            */
/* Save data into parameter string and start processing                       */
/*                                                                            */
/* Parameters ----------------------------------------------------------------*/
/*                                                                            */
/* <none>                                                                     */
/*                                                                            */
/*----------------------------------------------------------------------------*/

/* Variables -----------------------------------------------------------------*/
/* c_ParamListe        Parameter string                                       */
/* c_Options           Options of target program                              */
/* c_ZielProgramm      Target Program                                         */
/*----------------------------------------------------------------------------*/

define variable c_ParamListe   as character     no-undo.
define variable c_Options      as character     no-undo.
define variable c_ZielProgramm as character     no-undo.

/*----------------------------------------------------------------------------*/
/* Processing                                                                 */
/*----------------------------------------------------------------------------*/

run assignData in this-procedure (output c_ParamListe).

{adm/template/incl/dt_dlg02.if}

end procedure. /* process-data */

/* _UIB-CODE-BLOCK-END */
&ANALYZE-RESUME

