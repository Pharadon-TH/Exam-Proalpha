&ANALYZE-SUSPEND _VERSION-NUMBER UIB_v8r12 GUI
&ANALYZE-RESUME
&Scoped-define WINDOW-NAME CURRENT-WINDOW
&Scoped-define FRAME-NAME Dialog-Frame

&ANALYZE-SUSPEND _UIB-CODE-BLOCK _CUSTOM _DECLARATIONS Dialog-Frame 

/* _UIB-CODE-BLOCK-END */
&ANALYZE-RESUME


&ANALYZE-SUSPEND _UIB-CODE-BLOCK _XFTR "Update Information" Dialog-Frame _INLINE
/* Actions: ? ? ? ? adm/support/proc/ds_pa_01.w */

/* _UIB-CODE-BLOCK-END */
&ANALYZE-RESUME

&ANALYZE-SUSPEND _UIB-CODE-BLOCK _CUSTOM _DEFINITIONS Dialog-Frame 
/******************************************************************************/
/* @COPYRIGHT@                                                                */
/* Project: Proalpha                                                          */
/*                                                                            */
/* Name   : uv_vmo00.w                                                        */
/* Product: BRANCHE      - Branchentemplates                                  */
/* Module : VERT         - Vertrieb                                           */
/*                                                                            */
/* Created: 61e as of 15.11.2016/Claas Kuehnlenz                              */
/* Current: @PAVERSION@ as of @PADATE@/@PALASTAUTHOR@                         */
/*                                                                            */
/*----------------------------------------------------------------------------*/
/* DESCRIPTION                                                                */
/*----------------------------------------------------------------------------*/
/*                                                                            */
/* Versandmonitor (Filter)                                                    */
/*                                                                            */
/*----------------------------------------------------------------------------*/
/* PARAMETERS                                                                 */
/*----------------------------------------------------------------------------*/
/* Name                      Description                                      */
/*----------------------------------------------------------------------------*/
/*                                                                            */
/*----------------------------------------------------------------------------*/
/* HISTORY                                                                    */
/*----------------------------------------------------------------------------*/
/* @FILEHISTORY@                                                              */
/******************************************************************************/

create widget-pool.

/* Procedure Information -----------------------------------------------------*/

&GLOBAL-DEFINE pa-Autor             Claas Kuehnlenz
&GLOBAL-DEFINE pa-Version           @PAVERSION@
&GLOBAL-DEFINE pa-Datum             @PADATE@
&GLOBAL-DEFINE pa-Letzter           @PALASTAUTHOR@

&GLOBAL-DEFINE pa-GenVersion       UIB
&GLOBAL-DEFINE pa-ProgrammTyp      FilterDialog
&GLOBAL-DEFINE pa-Template         adm/template/dt_dlg03.w
&GLOBAL-DEFINE pa-TemplateVersion  2.01
&GLOBAL-DEFINE pa-XBasisName       uv_vmo00_w
&GLOBAL-DEFINE pa-NameSpace        2.10

/* Parameters ----------------------------------------------------------------*/

/* Globals -------------------------------------------------------------------*/

{adm/template/incl/dt_dlg01.df}

/* SCOPEDs -------------------------------------------------------------------*/

&SCOP PA-HLP-FIELDNAMES Konto_min,Konto_max,Lieferadresse_min,Lieferadresse_max
&SCOP PA-HLP-KEYNAMES   Kunde,Kunde,Adresse,Adresse

/* Variables -----------------------------------------------------------------*/
/*----------------------------------------------------------------------------*/

/* Buffers -------------------------------------------------------------------*/

/* _UIB-CODE-BLOCK-END */
&ANALYZE-RESUME


&ANALYZE-SUSPEND _UIB-PREPROCESSOR-BLOCK 

/* ********************  Preprocessor Definitions  ******************** */

&Scoped-define PROCEDURE-TYPE DIALOG-BOX
&Scoped-define DB-AWARE no

/* Name of designated FRAME-NAME and/or first browse and/or first query */
&Scoped-define FRAME-NAME Dialog-Frame
/* --> MO#HIDR-AH4-1123 thongdi_p 20.07.2026 Erweiterung Versandmonitor im Feld Best. Termin */
/* add xEbLiefertermin_min xEbLiefertermin_max in &Scoped-Define ENABLED-OBJECTS and &Scoped-Define DISPLAYED-OBJECTS */
/* Standard List Definitions                                            */
&Scoped-Define ENABLED-OBJECTS Konto_min Konto_max Artikel_min Artikel_max ~
ArtikelGruppe_min ArtikelGruppe_max Sparte_min Sparte_max ArtikelArt_min ~
ArtikelArt_max Wunschtermin_min Wunschtermin_max Liefertermin_min ~
Liefertermin_max xEbLiefertermin_min xEbLiefertermin_max uCI_Warenausgangstermin_min uCI_Warenausgangstermin_max ~
Versandtermin_min Versandtermin_max lPastOrderLines_var iBezugsdatum_var ~
lTodayOrderLines_var lFutureOrderLines_var iHorizont_var iMRPRelease_var ~
BelegNummer_min BelegNummer_max Sachbearbeiter_min Sachbearbeiter_max ~
AuftragsArt_min AuftragsArt_max LieferAdresse_min LieferAdresse_max ~
AdressKennung_min AdressKennung_max Abladestelle_min Abladestelle_max ~
uCI_LagerortKunde_min uCI_LagerortKunde_max VersandArt_min VersandArt_max ~
LieferBedingung_min LieferBedingung_max Lieferant_min Lieferant_max ~
LieferRestrikt_min LieferRestrikt_max ZahlungsZiel_min ZahlungsZiel_max ~
Lagergruppe_min Lagergruppe_max LagerOrt_min LagerOrt_max Btn_Start ~
Btn_Cancel Btn_Help 
&Scoped-Define DISPLAYED-OBJECTS Konto_min Konto_max Artikel_min ~
Artikel_max ArtikelGruppe_min ArtikelGruppe_max Sparte_min Sparte_max ~
ArtikelArt_min ArtikelArt_max Wunschtermin_min Wunschtermin_max ~
Liefertermin_min Liefertermin_max xEbLiefertermin_min xEbLiefertermin_max uCI_Warenausgangstermin_min ~
uCI_Warenausgangstermin_max Versandtermin_min Versandtermin_max ~
lPastOrderLines_var iBezugsdatum_var lTodayOrderLines_var ~
lFutureOrderLines_var iHorizont_var cTimeUnit iMRPRelease_var ~
BelegNummer_min BelegNummer_max Sachbearbeiter_min Sachbearbeiter_max ~
AuftragsArt_min AuftragsArt_max LieferAdresse_min LieferAdresse_max ~
AdressKennung_min AdressKennung_max Abladestelle_min Abladestelle_max ~
uCI_LagerortKunde_min uCI_LagerortKunde_max VersandArt_min VersandArt_max ~
LieferBedingung_min LieferBedingung_max Lieferant_min Lieferant_max ~
LieferRestrikt_min LieferRestrikt_max ZahlungsZiel_min ZahlungsZiel_max ~
Lagergruppe_min Lagergruppe_max LagerOrt_min LagerOrt_max c_von c_bis 

/* <-- MO#HIDR-AH4-1123 thongdi_p 20.07.2026 Erweiterung Versandmonitor im Feld Best. Termin */
/* Custom List Definitions                                              */
/* pa-YearFields,pa-ResetFields,List-3,List-4,List-5,List-6             */

/* _UIB-PREPROCESSOR-BLOCK-END */
&ANALYZE-RESUME


&ANALYZE-SUSPEND _UIB-CODE-BLOCK _XFTR "InfoFields" Dialog-Frame _INLINE
/* Actions: ? ? ? ? adm/support/proc/ds_inf01.p */
/* STRUCTURED-DATA
<Build-Information>
1.02
</Build-Information>
<Constants></Constants>
<InfoFields></InfoFields> */

/* _UIB-CODE-BLOCK-END */
&ANALYZE-RESUME

&ANALYZE-SUSPEND _UIB-CODE-BLOCK _XFTR "Dynamic InfoFields" Dialog-Frame _INLINE
/* Actions: ? ? ? ? adm/support/proc/ds_viw09.p */
/* _UIB-CODE-BLOCK-END */
&ANALYZE-RESUME

&ANALYZE-SUSPEND _UIB-CODE-BLOCK _XFTR "FieldDefinitions" Dialog-Frame _INLINE
/* Actions: ? ? ? ? adm/support/proc/ds_dlg01.p */
/* STRUCTURED-DATA
<DATA>
S_BelegParam.Konto|Konto_min|Konto_max||NO SELECTION||
S_Artikel.Artikel|Artikel_min|Artikel_max||S_Artikel.Firma = {firma/sartikel.fir pa-Firma};use-index Main||
S_ArtGruppe.ArtikelGruppe|ArtikelGruppe_min|ArtikelGruppe_max||S_ArtGruppe.Firma = {firma/sartgrp.fir pa-Firma};use-index Main||
S_ArtikelArt.ArtikelArt|ArtikelArt_min|ArtikelArt_max||use-index Main||
V_BelegPos.Wunschtermin|Wunschtermin_min|Wunschtermin_max||NO SELECTION||
V_BelegPos.Liefertermin|Liefertermin_min|Liefertermin_max||NO SELECTION||
/* --> MO#HIDR-AH4-1123 thongdi_p 20.07.2026 Erweiterung Versandmonitor im Feld Best. Termin */
xEbLiefertermin|xEbLiefertermin_min|xEbLiefertermin_max||NO SELECTION|date|99.99.9999
/* <-- MO#HIDR-AH4-1123 thongdi_p 20.07.2026 Erweiterung Versandmonitor im Feld Best. Termin */
V_BelegPos.uCI_Warenausgangstermin|uCI_Warenausgangstermin_min|uCI_Warenausgangstermin_max||NO SELECTION||
V_BelegPos.Versandtermin|Versandtermin_min|Versandtermin_max||NO SELECTION||
S_LieferAdresse.AdressKennung|AdressKennung_min|AdressKennung_max||NO SELECTION||
VU_RA_Pos.Abladestelle|Abladestelle_min|Abladestelle_max||NO SELECTION||
VU_RA_Abruf.uCI_LagerortKunde|uCI_LagerortKunde_min|uCI_LagerortKunde_max||NO SELECTION||
S_VersandArt.VersandArt|VersandArt_min|VersandArt_max||S_VersandArt.Firma = {firma/sversart.fir pa-Firma};use-index Main||
S_LieferBed.LieferBedingung|LieferBedingung_min|LieferBedingung_max||S_LieferBed.Firma = {firma/sliefbed.fir pa-Firma};use-index Main||
S_Lieferant.Lieferant|Lieferant_min|Lieferant_max||S_Lieferant.Firma = {firma/sliefera.fir pa-Firma};use-index Main||
V_BelegKopf.BelegNummer|BelegNummer_min|BelegNummer_max||NO SELECTION||
V_BelegKopf.Sachbearbeiter|Sachbearbeiter_min|Sachbearbeiter_max||NO SELECTION||
S_AuftragsArt.AuftragsArt|AuftragsArt_min|AuftragsArt_max||S_AuftragsArt.Firma = {firma/saufart.fir pa-Firma};use-index Main||
S_LieferAdresse.LieferAdresse|LieferAdresse_min|LieferAdresse_max||NO SELECTION||
iHorizont|||iHorizont_var|NO SELECTION|integer|zz9
iMRPRelease|||iMRPRelease_var|NO SELECTION|integer|9
iBezugsdatum|||iBezugsdatum_var|NO SELECTION|integer|9
S_Sparte.Sparte|Sparte_min|Sparte_max||S_Sparte.Firma = {firma/ssparte.fir pa-Firma};use-index Main||
ML_Ort.LagerOrt|LagerOrt_min|LagerOrt_max||ML_Ort.Firma = {firma/mlort.fir pa-Firma};use-index Main||
V_BelegKopf.LieferRestrikt|LieferRestrikt_min|LieferRestrikt_max||NO SELECTION||
S_ZahlZiel.ZahlungsZiel|ZahlungsZiel_min|ZahlungsZiel_max||S_ZahlZiel.Firma = {firma/szahlzie.fir pa-Firma};use-index Main||
ML_Lagergruppe.Lagergruppe|Lagergruppe_min|Lagergruppe_max||ML_Lagergruppe.Firma = {firma/mlort.fir pa-Firma};use-index Main||
lTodayOrderLines|||lTodayOrderLines_var|NO SELECTION|logical|yes/no
lFutureOrderLines|||lFutureOrderLines_var|NO SELECTION|logical|yes/no
lPastOrderLines|||lPastOrderLines_var|NO SELECTION|logical|Yes/No
</DATA>
<FRAME>
****/
define frame f_dummy
  S_BelegParam.Konto view-as fill-in skip
  S_Artikel.Artikel view-as fill-in skip
  S_ArtGruppe.ArtikelGruppe view-as fill-in skip
  S_ArtikelArt.ArtikelArt view-as fill-in skip
  V_BelegPos.Wunschtermin view-as fill-in skip
  V_BelegPos.Liefertermin view-as fill-in skip
  V_BelegPos.uCI_Warenausgangstermin view-as fill-in skip
  V_BelegPos.Versandtermin view-as fill-in skip
  S_LieferAdresse.AdressKennung view-as fill-in skip
  VU_RA_Pos.Abladestelle view-as fill-in skip
  VU_RA_Abruf.uCI_LagerortKunde view-as fill-in skip
  S_VersandArt.VersandArt view-as fill-in skip
  S_LieferBed.LieferBedingung view-as fill-in skip
  S_Lieferant.Lieferant view-as fill-in skip
  V_BelegKopf.BelegNummer view-as fill-in skip
  V_BelegKopf.Sachbearbeiter view-as fill-in skip
  S_AuftragsArt.AuftragsArt view-as fill-in skip
  S_LieferAdresse.LieferAdresse view-as fill-in skip
  S_Sparte.Sparte view-as fill-in skip
  ML_Ort.LagerOrt view-as fill-in skip
  V_BelegKopf.LieferRestrikt view-as fill-in skip
  S_ZahlZiel.ZahlungsZiel view-as fill-in skip
  ML_Lagergruppe.Lagergruppe view-as fill-in skip
with side-labels width 255 stream-io.
/****
</FRAME> */
/* _UIB-CODE-BLOCK-END */
&ANALYZE-RESUME

&ANALYZE-SUSPEND _UIB-CODE-BLOCK _XFTR "Skin Client Support" Dialog-Frame _INLINE
/* Actions: ? ? ? ? adm/support/proc/ds_skc00.p */

&SCOPED-DEFINE pa-DisplaySkinClientWidgets ~
  if not LieferRestrikt_max:hidden in frame ~{&FRAME-NAME~} then dynamic-function('pa_cUISvcSetWidgetAttribute':U in target-procedure, LieferRestrikt_max:handle, 'screen-value':U, string(LieferRestrikt_max)). ~
  if not LieferRestrikt_min:hidden in frame ~{&FRAME-NAME~} then dynamic-function('pa_cUISvcSetWidgetAttribute':U in target-procedure, LieferRestrikt_min:handle, 'screen-value':U, string(LieferRestrikt_min)).

&SCOPED-DEFINE pa-AssignSkinClientWidgets ~
  assign ~
    LieferRestrikt_max = integer(dynamic-function('pa_cUISvcGetWidgetAssignValue':U in target-procedure, LieferRestrikt_max:handle in frame ~{&FRAME-NAME~}, string(LieferRestrikt_max))) ~
    LieferRestrikt_min = integer(dynamic-function('pa_cUISvcGetWidgetAssignValue':U in target-procedure, LieferRestrikt_min:handle in frame ~{&FRAME-NAME~}, string(LieferRestrikt_min))) ~
    .
/* _UIB-CODE-BLOCK-END */
&ANALYZE-RESUME


/* ***********************  Control Definitions  ********************** */

/* Define a dialog box                                                  */

/* Definitions of the field level widgets                               */
DEFINE BUTTON Btn_Cancel AUTO-END-KEY 
     LABEL "Abbruch":T8 
     SIZE 12 BY 1.

DEFINE BUTTON Btn_Help 
     LABEL "&Hilfe":T8 
     SIZE 12 BY 1.

DEFINE BUTTON Btn_Start AUTO-GO 
     LABEL "OK":T8 
     SIZE 12 BY 1.

DEFINE VARIABLE LieferRestrikt_max AS INTEGER FORMAT "z9":U INITIAL 0 
     VIEW-AS COMBO-BOX INNER-LINES 5
     LIST-ITEM-PAIRS "Item 1",1
     DROP-DOWN-LIST
     SIZE 28 BY 1 NO-UNDO.

DEFINE VARIABLE LieferRestrikt_min AS INTEGER FORMAT "z9":U INITIAL 0 
     LABEL "Lieferrestriktion":R18 
     VIEW-AS COMBO-BOX INNER-LINES 5
     LIST-ITEM-PAIRS "Item 1",1
     DROP-DOWN-LIST
     SIZE 28 BY 1 NO-UNDO.

DEFINE VARIABLE Abladestelle_max AS CHARACTER FORMAT "x(17)":U 
     VIEW-AS FILL-IN 
     SIZE 19 BY 1 NO-UNDO.

DEFINE VARIABLE Abladestelle_min AS CHARACTER FORMAT "x(17)":U 
     LABEL "Abladestelle":R18 
     VIEW-AS FILL-IN 
     SIZE 19 BY 1 NO-UNDO.

DEFINE VARIABLE AdressKennung_max AS CHARACTER FORMAT "x(20)":U 
     VIEW-AS FILL-IN 
     SIZE 22 BY 1 NO-UNDO.

DEFINE VARIABLE AdressKennung_min AS CHARACTER FORMAT "x(20)":U 
     LABEL "Werk des Kunden":R18 
     VIEW-AS FILL-IN 
     SIZE 22 BY 1 NO-UNDO.

DEFINE VARIABLE Artikel_max AS CHARACTER FORMAT "x(20)":U 
     VIEW-AS FILL-IN 
     SIZE 22 BY 1 NO-UNDO.

DEFINE VARIABLE Artikel_min AS CHARACTER FORMAT "x(20)":U 
     LABEL "Teil":R18 
     VIEW-AS FILL-IN 
     SIZE 22 BY 1 NO-UNDO.

DEFINE VARIABLE ArtikelArt_max AS INTEGER FORMAT "z9":U INITIAL 0 
     VIEW-AS FILL-IN 
     SIZE 4 BY 1 NO-UNDO.

DEFINE VARIABLE ArtikelArt_min AS INTEGER FORMAT "z9":U INITIAL 0 
     LABEL "Teileart":R18 
     VIEW-AS FILL-IN 
     SIZE 4 BY 1 NO-UNDO.

DEFINE VARIABLE ArtikelGruppe_max AS CHARACTER FORMAT "x(6)":U 
     VIEW-AS FILL-IN 
     SIZE 8 BY 1 NO-UNDO.

DEFINE VARIABLE ArtikelGruppe_min AS CHARACTER FORMAT "x(6)":U 
     LABEL "Teilegruppe":R18 
     VIEW-AS FILL-IN 
     SIZE 8 BY 1 NO-UNDO.

DEFINE VARIABLE AuftragsArt_max AS CHARACTER FORMAT "x(2)":U 
     VIEW-AS FILL-IN 
     SIZE 4 BY 1 NO-UNDO.

DEFINE VARIABLE AuftragsArt_min AS CHARACTER FORMAT "x(2)":U 
     LABEL "Auftragsart":R18 
     VIEW-AS FILL-IN 
     SIZE 4 BY 1 NO-UNDO.

DEFINE VARIABLE BelegNummer_max AS INTEGER FORMAT "zzzzzzz9":U INITIAL 99999999 
     VIEW-AS FILL-IN 
     SIZE 10 BY 1 NO-UNDO.

DEFINE VARIABLE BelegNummer_min AS INTEGER FORMAT "zzzzzzz9":U INITIAL 0 
     LABEL "Belegnummer":R18 
     VIEW-AS FILL-IN 
     SIZE 10 BY 1 NO-UNDO.

DEFINE VARIABLE c_bis AS CHARACTER FORMAT "X(256)":U 
      VIEW-AS TEXT 
     SIZE 14 BY .63 NO-UNDO.

DEFINE VARIABLE c_von AS CHARACTER FORMAT "X(256)":U 
      VIEW-AS TEXT 
     SIZE 14 BY .63 NO-UNDO.

DEFINE VARIABLE cTimeUnit AS CHARACTER FORMAT "X(4)":U 
     VIEW-AS FILL-IN 
     SIZE 5.5 BY 1 NO-UNDO.

DEFINE VARIABLE iHorizont_var AS INTEGER FORMAT "zz9":U INITIAL 7 
     LABEL "Horizont Zukunft":R18 
     VIEW-AS FILL-IN 
     SIZE 5 BY 1 NO-UNDO.

DEFINE VARIABLE Konto_max AS INTEGER FORMAT "zzzzzzzz":U INITIAL 99999999 
     VIEW-AS FILL-IN 
     SIZE 10 BY 1 NO-UNDO.

DEFINE VARIABLE Konto_min AS INTEGER FORMAT "zzzzzzzz":U INITIAL 0 
     LABEL "Kunde/Lieferant":R18 
     VIEW-AS FILL-IN 
     SIZE 10 BY 1 NO-UNDO.

DEFINE VARIABLE Lagergruppe_max AS INTEGER FORMAT "zzzzzzz9":U INITIAL 0 
     VIEW-AS FILL-IN 
     SIZE 10 BY 1 NO-UNDO.

DEFINE VARIABLE Lagergruppe_min AS INTEGER FORMAT "zzzzzzz9":U INITIAL 0 
     LABEL "Dispobereich":R18 
     VIEW-AS FILL-IN 
     SIZE 10 BY 1 NO-UNDO.

DEFINE VARIABLE LagerOrt_max AS INTEGER FORMAT "zzzzzzz9":U INITIAL 0 
     VIEW-AS FILL-IN 
     SIZE 10 BY 1 NO-UNDO.

DEFINE VARIABLE LagerOrt_min AS INTEGER FORMAT "zzzzzzz9":U INITIAL 0 
     LABEL "Lagerort":R18 
     VIEW-AS FILL-IN 
     SIZE 10 BY 1 NO-UNDO.

DEFINE VARIABLE LieferAdresse_max AS INTEGER FORMAT "zz9":U INITIAL 999 
     VIEW-AS FILL-IN 
     SIZE 5 BY 1 NO-UNDO.

DEFINE VARIABLE LieferAdresse_min AS INTEGER FORMAT "zz9":U INITIAL 0 
     LABEL "Lieferadresse":R18 
     VIEW-AS FILL-IN 
     SIZE 5 BY 1 NO-UNDO.

DEFINE VARIABLE Lieferant_max AS INTEGER FORMAT "zzzzzzzz":U INITIAL 0 
     VIEW-AS FILL-IN 
     SIZE 10 BY 1 NO-UNDO.

DEFINE VARIABLE Lieferant_min AS INTEGER FORMAT "zzzzzzzz":U INITIAL 0 
     LABEL "Lieferant":R18 
     VIEW-AS FILL-IN 
     SIZE 10 BY 1 NO-UNDO.

DEFINE VARIABLE LieferBedingung_max AS INTEGER FORMAT "zz9":U INITIAL 0 
     VIEW-AS FILL-IN 
     SIZE 5 BY 1 NO-UNDO.

DEFINE VARIABLE LieferBedingung_min AS INTEGER FORMAT "zz9":U INITIAL 0 
     LABEL "Lieferbedingung":R18 
     VIEW-AS FILL-IN 
     SIZE 5 BY 1 NO-UNDO.

DEFINE VARIABLE Liefertermin_max AS DATE FORMAT "99.99.9999":U 
     VIEW-AS FILL-IN 
     SIZE 12 BY 1 NO-UNDO.

DEFINE VARIABLE Liefertermin_min AS DATE FORMAT "99.99.9999":U 
     LABEL "Liefertermin":R18 
     VIEW-AS FILL-IN 
     SIZE 12 BY 1 NO-UNDO.
     
/* --> MO#HIDR-AH4-1123 thongdi_p 20.07.2026 Erweiterung Versandmonitor im Feld Best. Termin */     
DEFINE VARIABLE xEbLiefertermin_min AS DATE FORMAT "99.99.9999":U 
     LABEL "1.best.Liefertermin":R18
     VIEW-AS FILL-IN SIZE 12 BY 1 NO-UNDO.

DEFINE VARIABLE xEbLiefertermin_max AS DATE FORMAT "99.99.9999":U 
     VIEW-AS FILL-IN SIZE 12 BY 1 NO-UNDO.     
/* <-- MO#HIDR-AH4-1123 thongdi_p 20.07.2026 Erweiterung Versandmonitor im Feld Best. Termin */

DEFINE VARIABLE Sachbearbeiter_max AS CHARACTER FORMAT "x(12)":U 
     VIEW-AS FILL-IN 
     SIZE 14 BY 1 NO-UNDO.

DEFINE VARIABLE Sachbearbeiter_min AS CHARACTER FORMAT "x(12)":U 
     LABEL "Sachbearbeiter":R18 
     VIEW-AS FILL-IN 
     SIZE 14 BY 1 NO-UNDO.

DEFINE VARIABLE Sparte_max AS CHARACTER FORMAT "x(6)":U 
     VIEW-AS FILL-IN 
     SIZE 8 BY 1 NO-UNDO.

DEFINE VARIABLE Sparte_min AS CHARACTER FORMAT "x(6)":U 
     LABEL "Sparte":R18 
     VIEW-AS FILL-IN 
     SIZE 8 BY 1 NO-UNDO.

DEFINE VARIABLE uCI_LagerortKunde_max AS CHARACTER FORMAT "X(7)":U 
     VIEW-AS FILL-IN 
     SIZE 9 BY 1 NO-UNDO.

DEFINE VARIABLE uCI_LagerortKunde_min AS CHARACTER FORMAT "X(7)":U 
     LABEL "Lagerort Kunde":R18 
     VIEW-AS FILL-IN 
     SIZE 9 BY 1 NO-UNDO.

DEFINE VARIABLE uCI_Warenausgangstermin_max AS DATE FORMAT "99.99.9999":U 
     VIEW-AS FILL-IN 
     SIZE 12 BY 1 NO-UNDO.

DEFINE VARIABLE uCI_Warenausgangstermin_min AS DATE FORMAT "99.99.9999":U 
     LABEL "Versandtermin":R18 
     VIEW-AS FILL-IN 
     SIZE 12 BY 1 NO-UNDO.

DEFINE VARIABLE VersandArt_max AS INTEGER FORMAT "zz9":U INITIAL 0 
     VIEW-AS FILL-IN 
     SIZE 5 BY 1 NO-UNDO.

DEFINE VARIABLE VersandArt_min AS INTEGER FORMAT "zz9":U INITIAL 0 
     LABEL "Versandart":R18 
     VIEW-AS FILL-IN 
     SIZE 5 BY 1 NO-UNDO.

DEFINE VARIABLE Versandtermin_max AS DATE FORMAT "99.99.9999":U 
     VIEW-AS FILL-IN 
     SIZE 12 BY 1 NO-UNDO.

DEFINE VARIABLE Versandtermin_min AS DATE FORMAT "99.99.9999":U 
     LABEL "Bereitstelltermin":R18 
     VIEW-AS FILL-IN 
     SIZE 12 BY 1 NO-UNDO.

DEFINE VARIABLE Wunschtermin_max AS DATE FORMAT "99.99.9999":U 
     VIEW-AS FILL-IN 
     SIZE 12 BY 1 NO-UNDO.

DEFINE VARIABLE Wunschtermin_min AS DATE FORMAT "99.99.9999":U 
     LABEL "Wunschtermin":R18 
     VIEW-AS FILL-IN 
     SIZE 12 BY 1 NO-UNDO.

DEFINE VARIABLE ZahlungsZiel_max AS INTEGER FORMAT "zz9":U INITIAL 0 
     VIEW-AS FILL-IN 
     SIZE 5 BY 1 NO-UNDO.

DEFINE VARIABLE ZahlungsZiel_min AS INTEGER FORMAT "zz9":U INITIAL 0 
     LABEL "Zahlungsziel":R18 
     VIEW-AS FILL-IN 
     SIZE 5 BY 1 NO-UNDO.

DEFINE VARIABLE iBezugsdatum_var AS INTEGER INITIAL 1 
     VIEW-AS RADIO-SET VERTICAL
     RADIO-BUTTONS 
          "Wunschtermin":L18, 1,
"Liefertermin":L18, 2,
"Versandtermin":L18, 3,
"Bereitstelltermin":L18, 4,
/* --> MO#HIDR-AH4-1123 thongdi_p 20.07.2026 Erweiterung Versandmonitor im Feld Best. Termin */
"1.best.Liefertermin", 5
/* <-- MO#HIDR-AH4-1123 thongdi_p 20.07.2026 Erweiterung Versandmonitor im Feld Best. Termin */
     SIZE 22.5 BY 3.5 NO-UNDO.

DEFINE VARIABLE iMRPRelease_var AS INTEGER INITIAL 1 
     VIEW-AS RADIO-SET HORIZONTAL
     RADIO-BUTTONS 
          "ja":L6, 1,
"nein":L6, 2,
"alle":L6, 3
     SIZE 41.5 BY 1 NO-UNDO.

DEFINE VARIABLE lFutureOrderLines_var AS LOGICAL INITIAL yes 
     LABEL "Zukunft":L18 
     VIEW-AS TOGGLE-BOX
     SIZE 20 BY 1 NO-UNDO.

DEFINE VARIABLE lPastOrderLines_var AS LOGICAL INITIAL yes 
     LABEL "Vergangenheit":L18 
     VIEW-AS TOGGLE-BOX
     SIZE 20 BY 1 NO-UNDO.

DEFINE VARIABLE lTodayOrderLines_var AS LOGICAL INITIAL yes 
     LABEL "Heute":L18 
     VIEW-AS TOGGLE-BOX
     SIZE 20 BY 1 NO-UNDO.


/* ************************  Frame Definitions  *********************** */

DEFINE FRAME Dialog-Frame
/* --> MO#HIDR-AH4-1123 thongdi_p 20.07.2026 Erweiterung Versandmonitor im Feld Best. Termin */
xEbLiefertermin_min AT ROW 1.5 COL 21 COLON-ALIGNED
     xEbLiefertermin_max AT ROW 1.5 COL 53 COLON-ALIGNED NO-LABEL
     c_von AT ROW 2.5 COL 21 COLON-ALIGNED NO-LABEL
     c_bis AT ROW 2.5 COL 53 COLON-ALIGNED NO-LABEL
     Konto_min AT ROW 3.5 COL 21 COLON-ALIGNED
     Konto_max AT ROW 3.5 COL 53 COLON-ALIGNED NO-LABEL
     Artikel_min AT ROW 4.5 COL 21 COLON-ALIGNED
     Artikel_max AT ROW 4.5 COL 53 COLON-ALIGNED NO-LABEL
     ArtikelGruppe_min AT ROW 5.5 COL 21 COLON-ALIGNED
     ArtikelGruppe_max AT ROW 5.5 COL 53 COLON-ALIGNED NO-LABEL
     Sparte_min AT ROW 6.5 COL 21 COLON-ALIGNED
     Sparte_max AT ROW 6.5 COL 53 COLON-ALIGNED NO-LABEL
     ArtikelArt_min AT ROW 7.5 COL 21 COLON-ALIGNED
     ArtikelArt_max AT ROW 7.5 COL 53 COLON-ALIGNED NO-LABEL
     Wunschtermin_min AT ROW 8.5 COL 21 COLON-ALIGNED
     Wunschtermin_max AT ROW 8.5 COL 53 COLON-ALIGNED NO-LABEL
     Liefertermin_min AT ROW 9.5 COL 21 COLON-ALIGNED
     Liefertermin_max AT ROW 9.5 COL 53 COLON-ALIGNED NO-LABEL
     uCI_Warenausgangstermin_min AT ROW 10.5 COL 21 COLON-ALIGNED
     uCI_Warenausgangstermin_max AT ROW 10.5 COL 53 COLON-ALIGNED NO-LABEL
     Versandtermin_min AT ROW 11.5 COL 21 COLON-ALIGNED
     Versandtermin_max AT ROW 11.5 COL 53 COLON-ALIGNED NO-LABEL
     lPastOrderLines_var AT ROW 12.5 COL 22
     iBezugsdatum_var AT ROW 12.5 COL 55 NO-LABEL
     lTodayOrderLines_var AT ROW 13.5 COL 22
     lFutureOrderLines_var AT ROW 14.5 COL 22
     iHorizont_var AT ROW 15.5 COL 21 COLON-ALIGNED
     cTimeUnit AT ROW 15.5 COL 26 COLON-ALIGNED NO-LABEL
     iMRPRelease_var AT ROW 16.5 COL 23 NO-LABEL
     BelegNummer_min AT ROW 17.5 COL 21 COLON-ALIGNED
     BelegNummer_max AT ROW 17.5 COL 53 COLON-ALIGNED NO-LABEL
     Sachbearbeiter_min AT ROW 18.5 COL 21 COLON-ALIGNED
     Sachbearbeiter_max AT ROW 18.5 COL 53 COLON-ALIGNED NO-LABEL
     AuftragsArt_min AT ROW 19.5 COL 21 COLON-ALIGNED
     AuftragsArt_max AT ROW 19.5 COL 53 COLON-ALIGNED NO-LABEL
     LieferAdresse_min AT ROW 20.5 COL 21 COLON-ALIGNED
     LieferAdresse_max AT ROW 20.5 COL 53 COLON-ALIGNED NO-LABEL
     AdressKennung_min AT ROW 21.5 COL 21 COLON-ALIGNED
     AdressKennung_max AT ROW 21.5 COL 53 COLON-ALIGNED NO-LABEL
     Abladestelle_min AT ROW 22.5 COL 21 COLON-ALIGNED
     Abladestelle_max AT ROW 22.5 COL 53 COLON-ALIGNED NO-LABEL
     uCI_LagerortKunde_min AT ROW 23.5 COL 21 COLON-ALIGNED
     uCI_LagerortKunde_max AT ROW 23.5 COL 53 COLON-ALIGNED NO-LABEL
     VersandArt_min AT ROW 24.5 COL 21 COLON-ALIGNED
     VersandArt_max AT ROW 24.5 COL 53 COLON-ALIGNED NO-LABEL
     LieferBedingung_min AT ROW 25.5 COL 21 COLON-ALIGNED
     LieferBedingung_max AT ROW 25.5 COL 53 COLON-ALIGNED NO-LABEL
     Lieferant_min AT ROW 26.5 COL 21 COLON-ALIGNED
     Lieferant_max AT ROW 26.5 COL 53 COLON-ALIGNED NO-LABEL
     LieferRestrikt_min AT ROW 27.5 COL 21 COLON-ALIGNED
     LieferRestrikt_max AT ROW 27.5 COL 53 COLON-ALIGNED NO-LABEL
     ZahlungsZiel_min AT ROW 28.5 COL 21 COLON-ALIGNED
     ZahlungsZiel_max AT ROW 28.5 COL 53 COLON-ALIGNED NO-LABEL
     Lagergruppe_min AT ROW 29.5 COL 21 COLON-ALIGNED
     Lagergruppe_max AT ROW 29.5 COL 53 COLON-ALIGNED NO-LABEL
     LagerOrt_min AT ROW 30.5 COL 21 COLON-ALIGNED
     LagerOrt_max AT ROW 30.5 COL 53 COLON-ALIGNED NO-LABEL
     Btn_Start AT ROW 32 COL 2
     Btn_Cancel AT ROW 32 COL 15
     Btn_Help AT ROW 32 COL 71.5
     SPACE(14.99) SKIP(31.49)
/* --> MO#HIDR-AH4-1123 thongdi_p 20.07.2026 Erweiterung Versandmonitor im Feld Best. Termin */

/* --> Original
/*     Konto_min AT ROW 2.5 COL 21 COLON-ALIGNED                           */
/*     Konto_max AT ROW 2.5 COL 53 COLON-ALIGNED NO-LABEL                  */
/*     Artikel_min AT ROW 3.5 COL 21 COLON-ALIGNED                         */
/*     Artikel_max AT ROW 3.5 COL 53 COLON-ALIGNED NO-LABEL                */
/*     ArtikelGruppe_min AT ROW 4.5 COL 21 COLON-ALIGNED                   */
/*     ArtikelGruppe_max AT ROW 4.5 COL 53 COLON-ALIGNED NO-LABEL          */
/*     Sparte_min AT ROW 5.5 COL 21 COLON-ALIGNED                          */
/*     Sparte_max AT ROW 5.5 COL 53 COLON-ALIGNED NO-LABEL                 */
/*     ArtikelArt_min AT ROW 6.5 COL 21 COLON-ALIGNED                      */
/*     ArtikelArt_max AT ROW 6.5 COL 53 COLON-ALIGNED NO-LABEL             */
/*     Wunschtermin_min AT ROW 7.5 COL 21 COLON-ALIGNED                    */
/*     Wunschtermin_max AT ROW 7.5 COL 53 COLON-ALIGNED NO-LABEL           */
/*     Liefertermin_min AT ROW 8.5 COL 21 COLON-ALIGNED                    */
/*     Liefertermin_max AT ROW 8.5 COL 53 COLON-ALIGNED NO-LABEL           */
/*     uCI_Warenausgangstermin_min AT ROW 9.5 COL 21 COLON-ALIGNED         */
/*     uCI_Warenausgangstermin_max AT ROW 9.5 COL 53 COLON-ALIGNED NO-LABEL*/
/*     Versandtermin_min AT ROW 10.5 COL 21 COLON-ALIGNED                  */
/*     Versandtermin_max AT ROW 10.5 COL 53 COLON-ALIGNED NO-LABEL         */
/*     lPastOrderLines_var AT ROW 11.5 COL 22                              */
/*     iBezugsdatum_var AT ROW 11.5 COL 55 NO-LABEL                        */
/*     lTodayOrderLines_var AT ROW 12.5 COL 22                             */
/*     lFutureOrderLines_var AT ROW 13.5 COL 22                            */
/*     iHorizont_var AT ROW 14.5 COL 21 COLON-ALIGNED                      */
/*     cTimeUnit AT ROW 14.5 COL 26 COLON-ALIGNED NO-LABEL                 */
/*     iMRPRelease_var AT ROW 15.5 COL 23 NO-LABEL                         */
/*     BelegNummer_min AT ROW 16.5 COL 21 COLON-ALIGNED                    */
/*     BelegNummer_max AT ROW 16.5 COL 53 COLON-ALIGNED NO-LABEL           */
/*     Sachbearbeiter_min AT ROW 17.5 COL 21 COLON-ALIGNED                 */
/*     Sachbearbeiter_max AT ROW 17.5 COL 53 COLON-ALIGNED NO-LABEL        */
/*     AuftragsArt_min AT ROW 18.5 COL 21 COLON-ALIGNED                    */
/*     AuftragsArt_max AT ROW 18.5 COL 53 COLON-ALIGNED NO-LABEL           */
/*     LieferAdresse_min AT ROW 19.5 COL 21 COLON-ALIGNED                  */
/*     LieferAdresse_max AT ROW 19.5 COL 53 COLON-ALIGNED NO-LABEL         */
/*     AdressKennung_min AT ROW 20.5 COL 21 COLON-ALIGNED                  */
/*     AdressKennung_max AT ROW 20.5 COL 53 COLON-ALIGNED NO-LABEL         */
/*     Abladestelle_min AT ROW 21.5 COL 21 COLON-ALIGNED                   */
/*     Abladestelle_max AT ROW 21.5 COL 53 COLON-ALIGNED NO-LABEL          */
/*     uCI_LagerortKunde_min AT ROW 22.5 COL 21 COLON-ALIGNED              */
/*     uCI_LagerortKunde_max AT ROW 22.5 COL 53 COLON-ALIGNED NO-LABEL     */
/*     VersandArt_min AT ROW 23.5 COL 21 COLON-ALIGNED                     */
/*     VersandArt_max AT ROW 23.5 COL 53 COLON-ALIGNED NO-LABEL            */
/*     LieferBedingung_min AT ROW 24.5 COL 21 COLON-ALIGNED                */
/*     LieferBedingung_max AT ROW 24.5 COL 53 COLON-ALIGNED NO-LABEL       */
/*     Lieferant_min AT ROW 25.5 COL 21 COLON-ALIGNED                      */
/*     Lieferant_max AT ROW 25.5 COL 53 COLON-ALIGNED NO-LABEL             */
/*     LieferRestrikt_min AT ROW 26.5 COL 21 COLON-ALIGNED                 */
/*     LieferRestrikt_max AT ROW 26.5 COL 53 COLON-ALIGNED NO-LABEL        */
/*     ZahlungsZiel_min AT ROW 27.5 COL 21 COLON-ALIGNED                   */
/*     ZahlungsZiel_max AT ROW 27.5 COL 53 COLON-ALIGNED NO-LABEL          */
/*     Lagergruppe_min AT ROW 28.5 COL 21 COLON-ALIGNED                    */
/*     Lagergruppe_max AT ROW 28.5 COL 53 COLON-ALIGNED NO-LABEL           */
/*     LagerOrt_min AT ROW 29.5 COL 21 COLON-ALIGNED                       */
/*     LagerOrt_max AT ROW 29.5 COL 53 COLON-ALIGNED NO-LABEL              */
/*     Btn_Start AT ROW 31 COL 2                                           */
/*     Btn_Cancel AT ROW 31 COL 15                                         */
/*     Btn_Help AT ROW 31 COL 71.5                                         */
/*     c_von AT ROW 1.5 COL 21 COLON-ALIGNED NO-LABEL                      */
/*     c_bis AT ROW 1.5 COL 53 COLON-ALIGNED NO-LABEL                      */
/*     SPACE(14.99) SKIP(30.49)                                            */
 <-- Original */
    WITH VIEW-AS DIALOG-BOX KEEP-TAB-ORDER 
         SIDE-LABELS NO-UNDERLINE THREE-D  SCROLLABLE 
         TITLE "Filter Versandmonitor":T60
         DEFAULT-BUTTON Btn_Start CANCEL-BUTTON Btn_Cancel.


/* *********************** Procedure Settings ************************ */

&ANALYZE-SUSPEND _PROCEDURE-SETTINGS
/* Settings for THIS-PROCEDURE
   Type: DIALOG-BOX
   Allow: Basic,DB-Fields
 */
&ANALYZE-RESUME _END-PROCEDURE-SETTINGS

&ANALYZE-SUSPEND _UIB-CODE-BLOCK _CUSTOM _INCLUDED-LIB Dialog-Frame 
/* ************************* Included-Libraries *********************** */

{adm/method/incl/dm_dlg00.lib}

/* _UIB-CODE-BLOCK-END */
&ANALYZE-RESUME




/* ***********  Runtime Attributes and AppBuilder Settings  *********** */

&ANALYZE-SUSPEND _RUN-TIME-ATTRIBUTES
/* SETTINGS FOR DIALOG-BOX Dialog-Frame
   FRAME-NAME L-To-R                                                    */
ASSIGN 
       FRAME Dialog-Frame:SCROLLABLE       = FALSE
       FRAME Dialog-Frame:HIDDEN           = TRUE.

/* SETTINGS FOR FILL-IN c_bis IN FRAME Dialog-Frame
   NO-ENABLE                                                            */
/* SETTINGS FOR FILL-IN c_von IN FRAME Dialog-Frame
   NO-ENABLE                                                            */
/* SETTINGS FOR FILL-IN cTimeUnit IN FRAME Dialog-Frame
   NO-ENABLE                                                            */
/* _RUN-TIME-ATTRIBUTES-END */
&ANALYZE-RESUME





/* ************************  Control Triggers  ************************ */

&Scoped-define SELF-NAME Dialog-Frame
&ANALYZE-SUSPEND _UIB-CODE-BLOCK _CONTROL Dialog-Frame Dialog-Frame
ON WINDOW-CLOSE OF FRAME Dialog-Frame /* Versandmonitor */
DO:
  {adm/template/incl/dt_uit00.if
     &UserExitName = "ON_WINDOW-CLOSE_OF_FRAME"}

  {adm/template/incl/dt_dlg09.if}

  {adm/template/incl/dt_uit01.if
     &UserExitName = "ON_WINDOW-CLOSE_OF_FRAME"}
END.

/* _UIB-CODE-BLOCK-END */
&ANALYZE-RESUME


&Scoped-define SELF-NAME Abladestelle_min
&ANALYZE-SUSPEND _UIB-CODE-BLOCK _CONTROL Abladestelle_min Dialog-Frame
ON LEAVE OF Abladestelle_min IN FRAME Dialog-Frame /* Abladestelle */
do:
  {adm/template/incl/dt_uit00.if
     &UserExitName = "ON_LEAVE_OF_Abladestelle_min"}

  {adm/template/incl/dt_dlg00.if &MAX-FELD = "Abladestelle_max"}

  {adm/template/incl/dt_uit01.if
     &UserExitName = "ON_LEAVE_OF_Abladestelle_min"}
end.

/* _UIB-CODE-BLOCK-END */
&ANALYZE-RESUME


&Scoped-define SELF-NAME AdressKennung_min
&ANALYZE-SUSPEND _UIB-CODE-BLOCK _CONTROL AdressKennung_min Dialog-Frame
ON LEAVE OF AdressKennung_min IN FRAME Dialog-Frame /* Werk des Kunden */
do:
  {adm/template/incl/dt_uit00.if
     &UserExitName = "ON_LEAVE_OF_AdressKennung_min"}

  {adm/template/incl/dt_dlg00.if &MAX-FELD = "AdressKennung_max"}

  {adm/template/incl/dt_uit01.if
     &UserExitName = "ON_LEAVE_OF_AdressKennung_min"}
end.

/* _UIB-CODE-BLOCK-END */
&ANALYZE-RESUME


&Scoped-define SELF-NAME Artikel_min
&ANALYZE-SUSPEND _UIB-CODE-BLOCK _CONTROL Artikel_min Dialog-Frame
ON LEAVE OF Artikel_min IN FRAME Dialog-Frame /* Teil */
do:
  {adm/template/incl/dt_uit00.if
     &UserExitName = "ON_LEAVE_OF_Artikel_min"}

  {adm/template/incl/dt_dlg00.if &MAX-FELD = "Artikel_max"}

  {adm/template/incl/dt_uit01.if
     &UserExitName = "ON_LEAVE_OF_Artikel_min"}
end.

/* _UIB-CODE-BLOCK-END */
&ANALYZE-RESUME


&Scoped-define SELF-NAME ArtikelArt_min
&ANALYZE-SUSPEND _UIB-CODE-BLOCK _CONTROL ArtikelArt_min Dialog-Frame
ON LEAVE OF ArtikelArt_min IN FRAME Dialog-Frame /* Teileart */
do:
  {adm/template/incl/dt_uit00.if
     &UserExitName = "ON_LEAVE_OF_ArtikelArt_min"}

  {adm/template/incl/dt_dlg00.if &MAX-FELD = "ArtikelArt_max"}

  {adm/template/incl/dt_uit01.if
     &UserExitName = "ON_LEAVE_OF_ArtikelArt_min"}
end.

/* _UIB-CODE-BLOCK-END */
&ANALYZE-RESUME


&Scoped-define SELF-NAME ArtikelGruppe_min
&ANALYZE-SUSPEND _UIB-CODE-BLOCK _CONTROL ArtikelGruppe_min Dialog-Frame
ON LEAVE OF ArtikelGruppe_min IN FRAME Dialog-Frame /* Teilegruppe */
do:
  {adm/template/incl/dt_uit00.if
     &UserExitName = "ON_LEAVE_OF_ArtikelGruppe_min"}

  {adm/template/incl/dt_dlg00.if &MAX-FELD = "ArtikelGruppe_max"}

  {adm/template/incl/dt_uit01.if
     &UserExitName = "ON_LEAVE_OF_ArtikelGruppe_min"}
end.

/* _UIB-CODE-BLOCK-END */
&ANALYZE-RESUME


&Scoped-define SELF-NAME AuftragsArt_min
&ANALYZE-SUSPEND _UIB-CODE-BLOCK _CONTROL AuftragsArt_min Dialog-Frame
ON LEAVE OF AuftragsArt_min IN FRAME Dialog-Frame /* Auftragsart */
do:
  {adm/template/incl/dt_uit00.if
     &UserExitName = "ON_LEAVE_OF_AuftragsArt_min"}

  {adm/template/incl/dt_dlg00.if &MAX-FELD = "AuftragsArt_max"}

  {adm/template/incl/dt_uit01.if
     &UserExitName = "ON_LEAVE_OF_AuftragsArt_min"}
end.

/* _UIB-CODE-BLOCK-END */
&ANALYZE-RESUME


&Scoped-define SELF-NAME BelegNummer_min
&ANALYZE-SUSPEND _UIB-CODE-BLOCK _CONTROL BelegNummer_min Dialog-Frame
ON LEAVE OF BelegNummer_min IN FRAME Dialog-Frame /* Belegnummer */
do:
  {adm/template/incl/dt_uit00.if
     &UserExitName = "ON_LEAVE_OF_BelegNummer_min"}

  {adm/template/incl/dt_dlg00.if &MAX-FELD = "BelegNummer_max"}

  {adm/template/incl/dt_uit01.if
     &UserExitName = "ON_LEAVE_OF_BelegNummer_min"}
end.

/* _UIB-CODE-BLOCK-END */
&ANALYZE-RESUME


&Scoped-define SELF-NAME Btn_Help
&ANALYZE-SUSPEND _UIB-CODE-BLOCK _CONTROL Btn_Help Dialog-Frame
ON CHOOSE OF Btn_Help IN FRAME Dialog-Frame /* Hilfe */
DO:
  {adm/template/incl/dt_uit00.if
     &UserExitName = "ON_CHOOSE_OF_Btn_Help"}

  {adm/template/incl/dt_btn00.if}

  {adm/template/incl/dt_uit01.if
     &UserExitName = "ON_CHOOSE_OF_Btn_Help"}
END.

/* _UIB-CODE-BLOCK-END */
&ANALYZE-RESUME


&Scoped-define SELF-NAME Btn_Start
&ANALYZE-SUSPEND _UIB-CODE-BLOCK _CONTROL Btn_Start Dialog-Frame
ON CHOOSE OF Btn_Start IN FRAME Dialog-Frame /* OK */
DO:
  {adm/template/incl/dt_uit00.if
     &UserExitName = "ON_CHOOSE_OF_Btn_Start"}

  {adm/template/incl/dt_btn02.if}

  {adm/template/incl/dt_uit01.if
     &UserExitName = "ON_CHOOSE_OF_Btn_Start"}
END.

/* _UIB-CODE-BLOCK-END */
&ANALYZE-RESUME


&Scoped-define SELF-NAME Konto_min
&ANALYZE-SUSPEND _UIB-CODE-BLOCK _CONTROL Konto_min Dialog-Frame
ON LEAVE OF Konto_min IN FRAME Dialog-Frame /* Kunde/Lieferant */
do:
  {adm/template/incl/dt_uit00.if
     &UserExitName = "ON_LEAVE_OF_Konto_min"}

  {adm/template/incl/dt_dlg00.if &MAX-FELD = "Konto_max"}

  {adm/template/incl/dt_uit01.if
     &UserExitName = "ON_LEAVE_OF_Konto_min"}
end.

/* _UIB-CODE-BLOCK-END */
&ANALYZE-RESUME


&Scoped-define SELF-NAME Lagergruppe_min
&ANALYZE-SUSPEND _UIB-CODE-BLOCK _CONTROL Lagergruppe_min Dialog-Frame
ON LEAVE OF Lagergruppe_min IN FRAME Dialog-Frame /* Dispobereich */
do:
  {adm/template/incl/dt_uit00.if
     &UserExitName = "ON_LEAVE_OF_Lagergruppe_min"}

  {adm/template/incl/dt_dlg00.if &MAX-FELD = "Lagergruppe_max"}

  {adm/template/incl/dt_uit01.if
     &UserExitName = "ON_LEAVE_OF_Lagergruppe_min"}
end.

/* _UIB-CODE-BLOCK-END */
&ANALYZE-RESUME


&Scoped-define SELF-NAME LagerOrt_min
&ANALYZE-SUSPEND _UIB-CODE-BLOCK _CONTROL LagerOrt_min Dialog-Frame
ON LEAVE OF LagerOrt_min IN FRAME Dialog-Frame /* Lagerort */
do:
  {adm/template/incl/dt_uit00.if
     &UserExitName = "ON_LEAVE_OF_LagerOrt_min"}

  {adm/template/incl/dt_dlg00.if &MAX-FELD = "LagerOrt_max"}

  {adm/template/incl/dt_uit01.if
     &UserExitName = "ON_LEAVE_OF_LagerOrt_min"}
end.

/* _UIB-CODE-BLOCK-END */
&ANALYZE-RESUME


&Scoped-define SELF-NAME lFutureOrderLines_var
&ANALYZE-SUSPEND _UIB-CODE-BLOCK _CONTROL lFutureOrderLines_var Dialog-Frame
ON VALUE-CHANGED OF lFutureOrderLines_var IN FRAME Dialog-Frame /* Zukunft */
DO:
   {adm/template/incl/dt_uit00.if
      &UserExitName = "ON_VALUE-CHANGED_OF_lFutureOrderLines_var"}

   {fnarg
    pa_lUISvcSetWidgetSensitiveState
    "iHorizont_var:handle in frame {&FRAME-NAME},
     lFutureOrderLines_var:checked in frame {&FRAME-NAME}"}.

   {adm/template/incl/dt_uit01.if
      &UserExitName = "ON_VALUE-CHANGED_OF_lFutureOrderLines_var"}
END.

/* _UIB-CODE-BLOCK-END */
&ANALYZE-RESUME


&Scoped-define SELF-NAME LieferAdresse_min
&ANALYZE-SUSPEND _UIB-CODE-BLOCK _CONTROL LieferAdresse_min Dialog-Frame
ON LEAVE OF LieferAdresse_min IN FRAME Dialog-Frame /* Lieferadresse */
do:
  {adm/template/incl/dt_uit00.if
     &UserExitName = "ON_LEAVE_OF_LieferAdresse_min"}

  {adm/template/incl/dt_dlg00.if &MAX-FELD = "LieferAdresse_max"}

  {adm/template/incl/dt_uit01.if
     &UserExitName = "ON_LEAVE_OF_LieferAdresse_min"}
end.

/* _UIB-CODE-BLOCK-END */
&ANALYZE-RESUME


&Scoped-define SELF-NAME Lieferant_min
&ANALYZE-SUSPEND _UIB-CODE-BLOCK _CONTROL Lieferant_min Dialog-Frame
ON LEAVE OF Lieferant_min IN FRAME Dialog-Frame /* Lieferant */
do:
  {adm/template/incl/dt_uit00.if
     &UserExitName = "ON_LEAVE_OF_Lieferant_min"}

  {adm/template/incl/dt_dlg00.if &MAX-FELD = "Lieferant_max"}

  {adm/template/incl/dt_uit01.if
     &UserExitName = "ON_LEAVE_OF_Lieferant_min"}
end.

/* _UIB-CODE-BLOCK-END */
&ANALYZE-RESUME


&Scoped-define SELF-NAME LieferBedingung_min
&ANALYZE-SUSPEND _UIB-CODE-BLOCK _CONTROL LieferBedingung_min Dialog-Frame
ON LEAVE OF LieferBedingung_min IN FRAME Dialog-Frame /* Lieferbedingung */
do:
  {adm/template/incl/dt_uit00.if
     &UserExitName = "ON_LEAVE_OF_LieferBedingung_min"}

  {adm/template/incl/dt_dlg00.if &MAX-FELD = "LieferBedingung_max"}

  {adm/template/incl/dt_uit01.if
     &UserExitName = "ON_LEAVE_OF_LieferBedingung_min"}
end.

/* _UIB-CODE-BLOCK-END */
&ANALYZE-RESUME


&Scoped-define SELF-NAME LieferRestrikt_min
&ANALYZE-SUSPEND _UIB-CODE-BLOCK _CONTROL LieferRestrikt_min Dialog-Frame
ON LEAVE OF LieferRestrikt_min IN FRAME Dialog-Frame /* Lieferrestriktion */
do:
  {adm/template/incl/dt_uit00.if
     &UserExitName = "ON_LEAVE_OF_LieferRestrikt_min"}

  {adm/template/incl/dt_dlg00.if &MAX-FELD = "LieferRestrikt_max"}

  {adm/template/incl/dt_uit01.if
     &UserExitName = "ON_LEAVE_OF_LieferRestrikt_min"}
end.

/* _UIB-CODE-BLOCK-END */
&ANALYZE-RESUME


&Scoped-define SELF-NAME Liefertermin_min
&ANALYZE-SUSPEND _UIB-CODE-BLOCK _CONTROL Liefertermin_min Dialog-Frame
ON LEAVE OF Liefertermin_min IN FRAME Dialog-Frame /* Liefertermin */
do:
  {adm/template/incl/dt_uit00.if
     &UserExitName = "ON_LEAVE_OF_Liefertermin_min"}

  {adm/template/incl/dt_dlg00.if &MAX-FELD = "Liefertermin_max"}

  {adm/template/incl/dt_uit01.if
     &UserExitName = "ON_LEAVE_OF_Liefertermin_min"}
end.

/* _UIB-CODE-BLOCK-END */
&ANALYZE-RESUME

/* --> MO#HIDR-AH4-1123 thongdi_p 20.07.2026 Erweiterung Versandmonitor im Feld Best. Termin */
&Scoped-define SELF-NAME xEbLiefertermin_min
&ANALYZE-SUSPEND _UIB-CODE-BLOCK _CONTROL xEbLiefertermin_min Dialog-Frame
ON LEAVE OF xEbLiefertermin_min IN FRAME Dialog-Frame /* 1.best.Liefertermin */
do:
  {adm/template/incl/dt_uit00.if
     &UserExitName = "ON_LEAVE_OF_xEbLiefertermin_min"}

  {adm/template/incl/dt_dlg00.if &MAX-FELD = "xEbLiefertermin_max"}

  {adm/template/incl/dt_uit01.if
     &UserExitName = "ON_LEAVE_OF_xEbLiefertermin_min"}
end.

/* _UIB-CODE-BLOCK-END */
&ANALYZE-RESUME
/* <-- MO#HIDR-AH4-1123 thongdi_p 20.07.2026 Erweiterung Versandmonitor im Feld Best. Termin */

&Scoped-define SELF-NAME Sachbearbeiter_min
&ANALYZE-SUSPEND _UIB-CODE-BLOCK _CONTROL Sachbearbeiter_min Dialog-Frame
ON LEAVE OF Sachbearbeiter_min IN FRAME Dialog-Frame /* Sachbearbeiter */
do:
  {adm/template/incl/dt_uit00.if
     &UserExitName = "ON_LEAVE_OF_Sachbearbeiter_min"}

  {adm/template/incl/dt_dlg00.if &MAX-FELD = "Sachbearbeiter_max"}

  {adm/template/incl/dt_uit01.if
     &UserExitName = "ON_LEAVE_OF_Sachbearbeiter_min"}
end.

/* _UIB-CODE-BLOCK-END */
&ANALYZE-RESUME


&Scoped-define SELF-NAME Sparte_min
&ANALYZE-SUSPEND _UIB-CODE-BLOCK _CONTROL Sparte_min Dialog-Frame
ON LEAVE OF Sparte_min IN FRAME Dialog-Frame /* Sparte */
do:
  {adm/template/incl/dt_uit00.if
     &UserExitName = "ON_LEAVE_OF_Sparte_min"}

  {adm/template/incl/dt_dlg00.if &MAX-FELD = "Sparte_max"}

  {adm/template/incl/dt_uit01.if
     &UserExitName = "ON_LEAVE_OF_Sparte_min"}
end.

/* _UIB-CODE-BLOCK-END */
&ANALYZE-RESUME


&Scoped-define SELF-NAME uCI_LagerortKunde_min
&ANALYZE-SUSPEND _UIB-CODE-BLOCK _CONTROL uCI_LagerortKunde_min Dialog-Frame
ON LEAVE OF uCI_LagerortKunde_min IN FRAME Dialog-Frame /* Lagerort Kunde */
do:
  {adm/template/incl/dt_uit00.if
     &UserExitName = "ON_LEAVE_OF_uCI_LagerortKunde_min"}

  {adm/template/incl/dt_dlg00.if &MAX-FELD = "uCI_LagerortKunde_max"}

  {adm/template/incl/dt_uit01.if
     &UserExitName = "ON_LEAVE_OF_uCI_LagerortKunde_min"}
end.

/* _UIB-CODE-BLOCK-END */
&ANALYZE-RESUME


&Scoped-define SELF-NAME uCI_Warenausgangstermin_min
&ANALYZE-SUSPEND _UIB-CODE-BLOCK _CONTROL uCI_Warenausgangstermin_min Dialog-Frame
ON LEAVE OF uCI_Warenausgangstermin_min IN FRAME Dialog-Frame /* Versandtermin */
do:
  {adm/template/incl/dt_uit00.if
     &UserExitName = "ON_LEAVE_OF_uCI_Warenausgangstermin_min"}

  {adm/template/incl/dt_dlg00.if &MAX-FELD = "uCI_Warenausgangstermin_max"}

  {adm/template/incl/dt_uit01.if
     &UserExitName = "ON_LEAVE_OF_uCI_Warenausgangstermin_min"}
end.

/* _UIB-CODE-BLOCK-END */
&ANALYZE-RESUME


&Scoped-define SELF-NAME VersandArt_min
&ANALYZE-SUSPEND _UIB-CODE-BLOCK _CONTROL VersandArt_min Dialog-Frame
ON LEAVE OF VersandArt_min IN FRAME Dialog-Frame /* Versandart */
do:
  {adm/template/incl/dt_uit00.if
     &UserExitName = "ON_LEAVE_OF_VersandArt_min"}

  {adm/template/incl/dt_dlg00.if &MAX-FELD = "VersandArt_max"}

  {adm/template/incl/dt_uit01.if
     &UserExitName = "ON_LEAVE_OF_VersandArt_min"}
end.

/* _UIB-CODE-BLOCK-END */
&ANALYZE-RESUME


&Scoped-define SELF-NAME Versandtermin_min
&ANALYZE-SUSPEND _UIB-CODE-BLOCK _CONTROL Versandtermin_min Dialog-Frame
ON LEAVE OF Versandtermin_min IN FRAME Dialog-Frame /* Bereitstelltermin */
do:
  {adm/template/incl/dt_uit00.if
     &UserExitName = "ON_LEAVE_OF_Versandtermin_min"}

  {adm/template/incl/dt_dlg00.if &MAX-FELD = "Versandtermin_max"}

  {adm/template/incl/dt_uit01.if
     &UserExitName = "ON_LEAVE_OF_Versandtermin_min"}
end.

/* _UIB-CODE-BLOCK-END */
&ANALYZE-RESUME


&Scoped-define SELF-NAME Wunschtermin_min
&ANALYZE-SUSPEND _UIB-CODE-BLOCK _CONTROL Wunschtermin_min Dialog-Frame
ON LEAVE OF Wunschtermin_min IN FRAME Dialog-Frame /* Wunschtermin */
do:
  {adm/template/incl/dt_uit00.if
     &UserExitName = "ON_LEAVE_OF_Wunschtermin_min"}

  {adm/template/incl/dt_dlg00.if &MAX-FELD = "Wunschtermin_max"}

  {adm/template/incl/dt_uit01.if
     &UserExitName = "ON_LEAVE_OF_Wunschtermin_min"}
end.

/* _UIB-CODE-BLOCK-END */
&ANALYZE-RESUME


&Scoped-define SELF-NAME ZahlungsZiel_min
&ANALYZE-SUSPEND _UIB-CODE-BLOCK _CONTROL ZahlungsZiel_min Dialog-Frame
ON LEAVE OF ZahlungsZiel_min IN FRAME Dialog-Frame /* Zahlungsziel */
do:
  {adm/template/incl/dt_uit00.if
     &UserExitName = "ON_LEAVE_OF_ZahlungsZiel_min"}

  {adm/template/incl/dt_dlg00.if &MAX-FELD = "ZahlungsZiel_max"}

  {adm/template/incl/dt_uit01.if
     &UserExitName = "ON_LEAVE_OF_ZahlungsZiel_min"}
end.

/* _UIB-CODE-BLOCK-END */
&ANALYZE-RESUME


&UNDEFINE SELF-NAME

&ANALYZE-SUSPEND _UIB-CODE-BLOCK _CUSTOM _MAIN-BLOCK Dialog-Frame 


/* ***************************  Main Block  *************************** */

{adm/template/incl/dt_dlg00.i}

run initialize in this-procedure.

/* Now enable the interface and wait for the exit condition.            */
/* (NOTE: handle ERROR and END-KEY so cleanup code will always fire.    */
MAIN-BLOCK:
DO ON ERROR   UNDO MAIN-BLOCK, LEAVE MAIN-BLOCK
   ON END-KEY UNDO MAIN-BLOCK, LEAVE MAIN-BLOCK:
  RUN enable_UI.

  /* widgets can only be disabled / enabled after calling enaable_UI          */

  {fnarg
    pa_lUISvcSetWidgetSensitiveState
    "iHorizont_var:handle in frame {&FRAME-NAME},
     lFutureOrderLines_var:checked in frame {&FRAME-NAME}"}.
  /* Wait-for go of frame                                                     */

  {adm/template/incl/dt_dlg11.if}

END.
RUN disable_UI.


if can-do('endkey,end-error,window-close':U,{getwidgetattr last-event function string}) then
  return error new adm.method.cls.DMCDialogCanceledErr().
else
  return.

/* _UIB-CODE-BLOCK-END */
&ANALYZE-RESUME


/* **********************  Internal Procedures  *********************** */

&ANALYZE-SUSPEND _UIB-CODE-BLOCK _PROCEDURE _help-begin Dialog-Frame 
PROCEDURE _help-begin :
/* Description ---------------------------------------------------------------*/
/*                                                                            */
/*                                                                            */
/*                                                                            */
/* Notes ---------------------------------------------------------------------*/
/*                                                                            */
/*                                                                            */
/*                                                                            */
/* Parameters ----------------------------------------------------------------*/
/*                                                                            */
/* <none>                                                                     */
/*                                                                            */
/* Examples ------------------------------------------------------------------*/
/*                                                                            */
/*                                                                            */
/*                                                                            */
/*----------------------------------------------------------------------------*/

/* Variables -----------------------------------------------------------------*/
/*----------------------------------------------------------------------------*/

/* Buffers -------------------------------------------------------------------*/

/*----------------------------------------------------------------------------*/
/* Processing                                                                 */
/*----------------------------------------------------------------------------*/

if {focus name} begins 'LieferAdresse':U then
  assign
    pa-hlp-string = adm.method.cls.DMCParameterStringSvc:cWriteValue(pa-hlp-string, 'Adresstyp':U, 'L':U)
    pa-hlp-string = adm.method.cls.DMCParameterStringSvc:cWriteValue(pa-hlp-string, 'Kunde':U,
                                                                     if Konto_min:screen-value in frame {&FRAME-NAME} = Konto_max:screen-value in frame {&FRAME-NAME} then
                                                                       Konto_min:screen-value in frame {&FRAME-NAME}
                                                                     else
                                                                       ?)
    .

if {focus name} begins 'Belegnummer':U then
  assign
    pa-hlp-string = adm.method.cls.DMCParameterStringSvc:cWriteValue(pa-hlp-string, 'Belegart':U,
                                                                     'U,VUA':U)
    .

end procedure. /* _help-begin */

/* _UIB-CODE-BLOCK-END */
&ANALYZE-RESUME

&ANALYZE-SUSPEND _UIB-CODE-BLOCK _PROCEDURE _initialize Dialog-Frame 
PROCEDURE _initialize :
/* Description ---------------------------------------------------------------*/
/*                                                                            */
/* Overwrite of Initialize                                                    */
/*                                                                            */
/* Notes ---------------------------------------------------------------------*/
/*                                                                            */
/* Special Initializations                                                    */
/*                                                                            */
/* Parameters ----------------------------------------------------------------*/
/*                                                                            */
/* <none>                                                                     */
/*                                                                            */
/*----------------------------------------------------------------------------*/

/* Variables -----------------------------------------------------------------*/
/*----------------------------------------------------------------------------*/
define variable lExternalValueAvailable as logical no-undo.

/* Buffers -------------------------------------------------------------------*/

/*----------------------------------------------------------------------------*/
/* Processing                                                                 */
/*----------------------------------------------------------------------------*/

assign
  {setwidgetattr
     "uCI_Warenausgangstermin_min"
     "label"
     "'Versandtermin':R18"
     "in frame {&FRAME-NAME}"}
  {setwidgetattr
     "Versandtermin_min"
     "label"
     "'Bereitstelltermin':R18"
     "in frame {&FRAME-NAME}"}
  .

  {fnarg
    pa_lUISvcCreateLabel
    "iMRPRelease_var:handle in frame {&FRAME-NAME},
     'Dispofreigabe':R18"}.

  {fnarg
    pa_lUISvcCreateLabel
    "lPastOrderLines_var:handle in frame {&FRAME-NAME},
     'Auftragspositionen':R18"}.

  {fnarg
    pa_lUISvcCreateLabel
    "iBezugsdatum_var:handle in frame {&FRAME-NAME},
     'Bezugsdatum':R18"}.

  /* set the Time unit for the Future Horizont */
  cTimeUnit = 'KTg':T4.

  /* Init with max value */
  {adm/incl/d__par01.if
    &ParameterListe = "pc_Options"
    &Parameter      = "Abladestelle"
    &Variable1      = "Abladestelle_min"
    &Variable2      = "Abladestelle_max"
    &Flag           = "lExternalValueAvailable"
  }

  if not lExternalValueAvailable then
  do:
    {adm/template/incl/dt_dlg04.if
      &Variable = "Abladestelle_min"
    }
    Abladestelle_max = {fnarg
                          pa_cFormatMaxCharValue
                          "Abladestelle_max:format in frame {&FRAME-NAME}"}.
  end. /* not lExternalValueAvailable */

  {adm/incl/d__par01.if
    &ParameterListe = "pc_Options"
    &Parameter      = "AdressKennung"
    &Variable1      = "AdressKennung_min"
    &Variable2      = "AdressKennung_max"
    &Flag           = "lExternalValueAvailable"
  }

  if not lExternalValueAvailable then
  do:
    {adm/template/incl/dt_dlg04.if
      &Variable = "AdressKennung_min"
    }
    AdressKennung_max = {fnarg
                          pa_cFormatMaxCharValue
                          "AdressKennung_max:format in frame {&FRAME-NAME}"}.
  end. /* not lExternalValueAvailable */

  {adm/incl/d__par01.if
    &ParameterListe = "pc_Options"
    &Parameter      = "Sachbearbeiter"
    &Variable1      = "Sachbearbeiter_min"
    &Variable2      = "Sachbearbeiter_max"
    &Flag           = "lExternalValueAvailable"
  }

  if not lExternalValueAvailable then
  do:
    {adm/template/incl/dt_dlg04.if
      &Variable = "Sachbearbeiter_min"
    }
    Sachbearbeiter_max = {fnarg
                          pa_cFormatMaxCharValue
                          "Sachbearbeiter_max:format in frame {&FRAME-NAME}"}.
  end. /* not lExternalValueAvailable */

  {adm/incl/d__par01.if
    &ParameterListe = "pc_Options"
    &Parameter      = "uCI_LagerortKunde"
    &Variable1      = "uCI_LagerortKunde_min"
    &Variable2      = "uCI_LagerortKunde_max"
    &Flag           = "lExternalValueAvailable"
  }

  if not lExternalValueAvailable then
  do:
    {adm/template/incl/dt_dlg04.if
      &Variable = "uCI_LagerortKunde_min"
    }
    uCI_LagerortKunde_max = {fnarg
                              pa_cFormatMaxCharValue
                              "uCI_LagerortKunde_max:format in frame {&FRAME-NAME}"}.
  end. /* not lExternalValueAvailable */

  {fnarg
    pa_lUISvcInitializeComboValuePairs
     "LieferRestrikt_min:handle in frame {&frame-name},
      'SB_ShipmentRestrictions_desc':U,
      'SB_ShipmentRestrictions_keys':U"}.

  {fnarg
    pa_lUISvcInitializeComboValuePairs
     "LieferRestrikt_max:handle in frame {&frame-name},
      'SB_ShipmentRestrictions_desc':U,
      'SB_ShipmentRestrictions_keys':U"}.

  LieferRestrikt_max = 10.  /* by default maxvalue is 10 */

end procedure. /* _initialize */

/* _UIB-CODE-BLOCK-END */
&ANALYZE-RESUME

&ANALYZE-SUSPEND _UIB-CODE-BLOCK _PROCEDURE assignData Dialog-Frame  adm/support/proc/ds_dlg10.p
PROCEDURE assignData :
/* Description ---------------------------------------------------------------*/
/*                                                                            */
/* Assign screen values to parameter string                                   */
/*                                                                            */
/* Parameters ----------------------------------------------------------------*/
/*                                                                            */
/* pcParamListe  List with data in Proalpha String format                     */
/*                                                                            */
/*----------------------------------------------------------------------------*/

define       output parameter pcParamListe as character     no-undo.

/* Variables -----------------------------------------------------------------*/
/*----------------------------------------------------------------------------*/

/* Buffers -------------------------------------------------------------------*/

/*----------------------------------------------------------------------------*/
/* Processing                                                                 */
/*----------------------------------------------------------------------------*/

/* Assign Screen Buffer                                                       */

{adm/template/incl/dt_dlg12.if}

/* Assign Default Values                                                      */
/* --> MO#HIDR-AH4-1123 thongdi_p 20.07.2026 Erweiterung Versandmonitor im Feld Best. Termin */
{adm/incl/d__par00.if
  &ParameterListe = "pcParamListe"
  &Parameter      = "xEbLiefertermin"
  &Variable1      = "xEbLiefertermin_min"
  &Variable2      = "xEbLiefertermin_max"
}
message xEbLiefertermin_min xEbLiefertermin_max.
/* <-- MO#HIDR-AH4-1123 thongdi_p 20.07.2026 Erweiterung Versandmonitor im Feld Best. Termin */

{adm/incl/d__par00.if
  &ParameterListe = "pcParamListe"
  &Parameter      = "Konto"
  &Variable1      = "Konto_min"
  &Variable2      = "Konto_max"
}

{adm/incl/d__par00.if
  &ParameterListe = "pcParamListe"
  &Parameter      = "Artikel"
  &Variable1      = "Artikel_min"
  &Variable2      = "Artikel_max"
}

{adm/incl/d__par00.if
  &ParameterListe = "pcParamListe"
  &Parameter      = "ArtikelGruppe"
  &Variable1      = "ArtikelGruppe_min"
  &Variable2      = "ArtikelGruppe_max"
}

{adm/incl/d__par00.if
  &ParameterListe = "pcParamListe"
  &Parameter      = "ArtikelArt"
  &Variable1      = "ArtikelArt_min"
  &Variable2      = "ArtikelArt_max"
}

{adm/incl/d__par00.if
  &ParameterListe = "pcParamListe"
  &Parameter      = "Wunschtermin"
  &Variable1      = "Wunschtermin_min"
  &Variable2      = "Wunschtermin_max"
}

{adm/incl/d__par00.if
  &ParameterListe = "pcParamListe"
  &Parameter      = "Liefertermin"
  &Variable1      = "Liefertermin_min"
  &Variable2      = "Liefertermin_max"
}

{adm/incl/d__par00.if
  &ParameterListe = "pcParamListe"
  &Parameter      = "uCI_Warenausgangstermin"
  &Variable1      = "uCI_Warenausgangstermin_min"
  &Variable2      = "uCI_Warenausgangstermin_max"
}

{adm/incl/d__par00.if
  &ParameterListe = "pcParamListe"
  &Parameter      = "Versandtermin"
  &Variable1      = "Versandtermin_min"
  &Variable2      = "Versandtermin_max"
}

{adm/incl/d__par00.if
  &ParameterListe = "pcParamListe"
  &Parameter      = "AdressKennung"
  &Variable1      = "AdressKennung_min"
  &Variable2      = "AdressKennung_max"
}

{adm/incl/d__par00.if
  &ParameterListe = "pcParamListe"
  &Parameter      = "Abladestelle"
  &Variable1      = "Abladestelle_min"
  &Variable2      = "Abladestelle_max"
}

{adm/incl/d__par00.if
  &ParameterListe = "pcParamListe"
  &Parameter      = "uCI_LagerortKunde"
  &Variable1      = "uCI_LagerortKunde_min"
  &Variable2      = "uCI_LagerortKunde_max"
}

{adm/incl/d__par00.if
  &ParameterListe = "pcParamListe"
  &Parameter      = "VersandArt"
  &Variable1      = "VersandArt_min"
  &Variable2      = "VersandArt_max"
}

{adm/incl/d__par00.if
  &ParameterListe = "pcParamListe"
  &Parameter      = "LieferBedingung"
  &Variable1      = "LieferBedingung_min"
  &Variable2      = "LieferBedingung_max"
}

{adm/incl/d__par00.if
  &ParameterListe = "pcParamListe"
  &Parameter      = "Lieferant"
  &Variable1      = "Lieferant_min"
  &Variable2      = "Lieferant_max"
}

{adm/incl/d__par00.if
  &ParameterListe = "pcParamListe"
  &Parameter      = "BelegNummer"
  &Variable1      = "BelegNummer_min"
  &Variable2      = "BelegNummer_max"
}

{adm/incl/d__par00.if
  &ParameterListe = "pcParamListe"
  &Parameter      = "Sachbearbeiter"
  &Variable1      = "Sachbearbeiter_min"
  &Variable2      = "Sachbearbeiter_max"
}

{adm/incl/d__par00.if
  &ParameterListe = "pcParamListe"
  &Parameter      = "AuftragsArt"
  &Variable1      = "AuftragsArt_min"
  &Variable2      = "AuftragsArt_max"
}

{adm/incl/d__par00.if
  &ParameterListe = "pcParamListe"
  &Parameter      = "LieferAdresse"
  &Variable1      = "LieferAdresse_min"
  &Variable2      = "LieferAdresse_max"
}

{adm/incl/d__par00.if
  &ParameterListe = "pcParamListe"
  &Parameter      = "iHorizont"
  &Variable1      = "iHorizont_var"
}

{adm/incl/d__par00.if
  &ParameterListe = "pcParamListe"
  &Parameter      = "iMRPRelease"
  &Variable1      = "iMRPRelease_var"
}

{adm/incl/d__par00.if
  &ParameterListe = "pcParamListe"
  &Parameter      = "iBezugsdatum"
  &Variable1      = "iBezugsdatum_var"
}

{adm/incl/d__par00.if
  &ParameterListe = "pcParamListe"
  &Parameter      = "Sparte"
  &Variable1      = "Sparte_min"
  &Variable2      = "Sparte_max"
}

{adm/incl/d__par00.if
  &ParameterListe = "pcParamListe"
  &Parameter      = "LagerOrt"
  &Variable1      = "LagerOrt_min"
  &Variable2      = "LagerOrt_max"
}

{adm/incl/d__par00.if
  &ParameterListe = "pcParamListe"
  &Parameter      = "LieferRestrikt"
  &Variable1      = "LieferRestrikt_min"
  &Variable2      = "LieferRestrikt_max"
}

{adm/incl/d__par00.if
  &ParameterListe = "pcParamListe"
  &Parameter      = "ZahlungsZiel"
  &Variable1      = "ZahlungsZiel_min"
  &Variable2      = "ZahlungsZiel_max"
}

{adm/incl/d__par00.if
  &ParameterListe = "pcParamListe"
  &Parameter      = "Lagergruppe"
  &Variable1      = "Lagergruppe_min"
  &Variable2      = "Lagergruppe_max"
}

{adm/incl/d__par00.if
  &ParameterListe = "pcParamListe"
  &Parameter      = "lTodayOrderLines"
  &Variable1      = "lTodayOrderLines_var"
}

{adm/incl/d__par00.if
  &ParameterListe = "pcParamListe"
  &Parameter      = "lFutureOrderLines"
  &Variable1      = "lFutureOrderLines_var"
}

{adm/incl/d__par00.if
  &ParameterListe = "pcParamListe"
  &Parameter      = "lPastOrderLines"
  &Variable1      = "lPastOrderLines_var"
}

/* Default Code                                                               */

{adm/template/incl/dt_dlg07.if}

return.

end procedure. /* assignData */

/* _UIB-CODE-BLOCK-END */
&ANALYZE-RESUME

&ANALYZE-SUSPEND _UIB-CODE-BLOCK _PROCEDURE disable_UI Dialog-Frame 
PROCEDURE disable_UI :
/*------------------------------------------------------------------------------
  Purpose:     DISABLE the User Interface
  Parameters:  <none>
  Notes:       Here we clean-up the user-interface by deleting
               dynamic widgets we have created and/or hide
               frames.  This procedure is usually called when
               we are ready to "clean-up" after running.
------------------------------------------------------------------------------*/

  {adm/template/incl/dt_dlg06.if}

end procedure.

/* _UIB-CODE-BLOCK-END */
&ANALYZE-RESUME

&ANALYZE-SUSPEND _UIB-CODE-BLOCK _PROCEDURE enable_UI Dialog-Frame 
PROCEDURE enable_UI :
/* Description ---------------------------------------------------------------*/
/*                                                                            */
/* ENABLE the User Interface                                                  */
/*                                                                            */
/* Notes ---------------------------------------------------------------------*/
/*                                                                            */
/* Here we display/view/enable the widgets in the user-interface.             */
/* In addition, OPEN all queries associated with each FRAME and BROWSE.       */
/* These statements here are based on the "Other Settings" section of the     */
/* widget Property Sheets.                                                    */
/*                                                                            */
/* Parameters ----------------------------------------------------------------*/
/*                                                                            */
/* <none>                                                                     */
/*                                                                            */
/*----------------------------------------------------------------------------*/

/* Variables -----------------------------------------------------------------*/
/*----------------------------------------------------------------------------*/

/* Buffers -------------------------------------------------------------------*/

/*----------------------------------------------------------------------------*/
/* Processing                                                                 */
/*----------------------------------------------------------------------------*/

{adm/template/incl/dt_dlg03.if}

end procedure. /* enable_UI */

/* _UIB-CODE-BLOCK-END */
&ANALYZE-RESUME

&ANALYZE-SUSPEND _UIB-CODE-BLOCK _PROCEDURE initialize Dialog-Frame  adm/support/proc/ds_dlg02.p
PROCEDURE initialize :
/* Description ---------------------------------------------------------------*/
/*                                                                            */
/* Initialization                                                             */
/*                                                                            */
/* Notes ---------------------------------------------------------------------*/
/*                                                                            */
/* - Initialization of variables                                              */
/* - Assign format                                                            */
/*                                                                            */
/* Parameters ----------------------------------------------------------------*/
/*                                                                            */
/* <none>                                                                     */
/*                                                                            */
/*----------------------------------------------------------------------------*/

/* Variables -----------------------------------------------------------------*/
/* lExternalValueAvailable     Flag                                           */
/*----------------------------------------------------------------------------*/

define variable lExternalValueAvailable as logical       no-undo.

/*----------------------------------------------------------------------------*/
/* Processing                                                                 */
/*----------------------------------------------------------------------------*/

/* Initialize maximum values (use external data, if available)                */
/* --> MO#HIDR-AH4-1123 thongdi_p 20.07.2026 Erweiterung Versandmonitor im Feld Best. Termin */
{adm/incl/d__par01.if
  &ParameterListe = "pc_Options"
  &Parameter      = "xEbLiefertermin"
  &Variable1      = "xEbLiefertermin_min"
  &Variable2      = "xEbLiefertermin_max"
  &cc_Date        = "yes"
  &Flag           = "lExternalValueAvailable"
}
if not lExternalValueAvailable then
do:
  {adm/template/incl/dt_dlg04.if
    &Variable = "xEbLiefertermin_min"
    &Datentyp = "date"
  }
  {adm/template/incl/dt_dlg04.if
    &Variable = "xEbLiefertermin_max"
    &Datentyp = "date"
  }
end. /* not lExternalValueAvailable */
/* <-- MO#HIDR-AH4-1123 thongdi_p 20.07.2026 Erweiterung Versandmonitor im Feld Best. Termin */

{adm/incl/d__par01.if
  &ParameterListe = "pc_Options"
  &Parameter      = "Konto"
  &Variable1      = "Konto_min"
  &Variable2      = "Konto_max"
  &Datentyp       = "integer"
  &Flag           = "lExternalValueAvailable"
}

if not lExternalValueAvailable then
do:
  {adm/template/incl/dt_dlg04.if
    &Variable = "Konto_min"
    &Datentyp = "integer"
  }
  {adm/template/incl/dt_dlg04.if
    &Variable = "Konto_max"
    &Datentyp = "integer"
  }
end. /* not lExternalValueAvailable */

{adm/incl/d__par01.if
  &ParameterListe = "pc_Options"
  &Parameter      = "Artikel"
  &Variable1      = "Artikel_min"
  &Variable2      = "Artikel_max"
  &Flag           = "lExternalValueAvailable"
}

if not lExternalValueAvailable then
do:
  {adm/template/incl/dt_dlg04.if
    &Variable = "Artikel_min"
  }
  find last S_Artikel
    where S_Artikel.Firma = {firma/sartikel.fir pa-Firma}
    use-index Main
    no-lock no-error.
  if available S_Artikel then 
    Artikel_max = S_Artikel.Artikel.
end. /* not lExternalValueAvailable */

{adm/incl/d__par01.if
  &ParameterListe = "pc_Options"
  &Parameter      = "ArtikelGruppe"
  &Variable1      = "ArtikelGruppe_min"
  &Variable2      = "ArtikelGruppe_max"
  &Flag           = "lExternalValueAvailable"
}

if not lExternalValueAvailable then
do:
  {adm/template/incl/dt_dlg04.if
    &Variable = "ArtikelGruppe_min"
  }
  find last S_ArtGruppe
    where S_ArtGruppe.Firma = {firma/sartgrp.fir pa-Firma}
    use-index Main
    no-lock no-error.
  if available S_ArtGruppe then 
    ArtikelGruppe_max = S_ArtGruppe.ArtikelGruppe.
end. /* not lExternalValueAvailable */

{adm/incl/d__par01.if
  &ParameterListe = "pc_Options"
  &Parameter      = "ArtikelArt"
  &Variable1      = "ArtikelArt_min"
  &Variable2      = "ArtikelArt_max"
  &Datentyp       = "integer"
  &Flag           = "lExternalValueAvailable"
}

if not lExternalValueAvailable then
do:
  {adm/template/incl/dt_dlg04.if
    &Variable = "ArtikelArt_min"
    &Datentyp = "integer"
  }
  find last S_ArtikelArt
    use-index Main
    no-lock no-error.
  if available S_ArtikelArt then 
    ArtikelArt_max = S_ArtikelArt.ArtikelArt.
end. /* not lExternalValueAvailable */

{adm/incl/d__par01.if
  &ParameterListe = "pc_Options"
  &Parameter      = "Wunschtermin"
  &Variable1      = "Wunschtermin_min"
  &Variable2      = "Wunschtermin_max"
  &cc_Date        = "yes"
  &Flag           = "lExternalValueAvailable"
}

if not lExternalValueAvailable then
do:
  {adm/template/incl/dt_dlg04.if
    &Variable = "Wunschtermin_min"
    &Datentyp = "date"
  }
  {adm/template/incl/dt_dlg04.if
    &Variable = "Wunschtermin_max"
    &Datentyp = "date"
  }
end. /* not lExternalValueAvailable */

{adm/incl/d__par01.if
  &ParameterListe = "pc_Options"
  &Parameter      = "Liefertermin"
  &Variable1      = "Liefertermin_min"
  &Variable2      = "Liefertermin_max"
  &cc_Date        = "yes"
  &Flag           = "lExternalValueAvailable"
}

if not lExternalValueAvailable then
do:
  {adm/template/incl/dt_dlg04.if
    &Variable = "Liefertermin_min"
    &Datentyp = "date"
  }
  {adm/template/incl/dt_dlg04.if
    &Variable = "Liefertermin_max"
    &Datentyp = "date"
  }
end. /* not lExternalValueAvailable */

{adm/incl/d__par01.if
  &ParameterListe = "pc_Options"
  &Parameter      = "uCI_Warenausgangstermin"
  &Variable1      = "uCI_Warenausgangstermin_min"
  &Variable2      = "uCI_Warenausgangstermin_max"
  &cc_Date        = "yes"
  &Flag           = "lExternalValueAvailable"
}

if not lExternalValueAvailable then
do:
  {adm/template/incl/dt_dlg04.if
    &Variable = "uCI_Warenausgangstermin_min"
    &Datentyp = "date"
  }
  {adm/template/incl/dt_dlg04.if
    &Variable = "uCI_Warenausgangstermin_max"
    &Datentyp = "date"
  }
end. /* not lExternalValueAvailable */

{adm/incl/d__par01.if
  &ParameterListe = "pc_Options"
  &Parameter      = "Versandtermin"
  &Variable1      = "Versandtermin_min"
  &Variable2      = "Versandtermin_max"
  &cc_Date        = "yes"
  &Flag           = "lExternalValueAvailable"
}

if not lExternalValueAvailable then
do:
  {adm/template/incl/dt_dlg04.if
    &Variable = "Versandtermin_min"
    &Datentyp = "date"
  }
  {adm/template/incl/dt_dlg04.if
    &Variable = "Versandtermin_max"
    &Datentyp = "date"
  }
end. /* not lExternalValueAvailable */

{adm/incl/d__par01.if
  &ParameterListe = "pc_Options"
  &Parameter      = "AdressKennung"
  &Variable1      = "AdressKennung_min"
  &Variable2      = "AdressKennung_max"
  &Flag           = "lExternalValueAvailable"
}

if not lExternalValueAvailable then
do:
  {adm/template/incl/dt_dlg04.if
    &Variable = "AdressKennung_min"
  }
  {adm/template/incl/dt_dlg04.if
    &Variable = "AdressKennung_max"
  }
end. /* not lExternalValueAvailable */

{adm/incl/d__par01.if
  &ParameterListe = "pc_Options"
  &Parameter      = "Abladestelle"
  &Variable1      = "Abladestelle_min"
  &Variable2      = "Abladestelle_max"
  &Flag           = "lExternalValueAvailable"
}

if not lExternalValueAvailable then
do:
  {adm/template/incl/dt_dlg04.if
    &Variable = "Abladestelle_min"
  }
  {adm/template/incl/dt_dlg04.if
    &Variable = "Abladestelle_max"
  }
end. /* not lExternalValueAvailable */

{adm/incl/d__par01.if
  &ParameterListe = "pc_Options"
  &Parameter      = "uCI_LagerortKunde"
  &Variable1      = "uCI_LagerortKunde_min"
  &Variable2      = "uCI_LagerortKunde_max"
  &Flag           = "lExternalValueAvailable"
}

if not lExternalValueAvailable then
do:
  {adm/template/incl/dt_dlg04.if
    &Variable = "uCI_LagerortKunde_min"
  }
  {adm/template/incl/dt_dlg04.if
    &Variable = "uCI_LagerortKunde_max"
  }
end. /* not lExternalValueAvailable */

{adm/incl/d__par01.if
  &ParameterListe = "pc_Options"
  &Parameter      = "VersandArt"
  &Variable1      = "VersandArt_min"
  &Variable2      = "VersandArt_max"
  &Datentyp       = "integer"
  &Flag           = "lExternalValueAvailable"
}

if not lExternalValueAvailable then
do:
  {adm/template/incl/dt_dlg04.if
    &Variable = "VersandArt_min"
    &Datentyp = "integer"
  }
  find last S_VersandArt
    where S_VersandArt.Firma = {firma/sversart.fir pa-Firma}
    use-index Main
    no-lock no-error.
  if available S_VersandArt then 
    VersandArt_max = S_VersandArt.VersandArt.
end. /* not lExternalValueAvailable */

{adm/incl/d__par01.if
  &ParameterListe = "pc_Options"
  &Parameter      = "LieferBedingung"
  &Variable1      = "LieferBedingung_min"
  &Variable2      = "LieferBedingung_max"
  &Datentyp       = "integer"
  &Flag           = "lExternalValueAvailable"
}

if not lExternalValueAvailable then
do:
  {adm/template/incl/dt_dlg04.if
    &Variable = "LieferBedingung_min"
    &Datentyp = "integer"
  }
  find last S_LieferBed
    where S_LieferBed.Firma = {firma/sliefbed.fir pa-Firma}
    use-index Main
    no-lock no-error.
  if available S_LieferBed then 
    LieferBedingung_max = S_LieferBed.LieferBedingung.
end. /* not lExternalValueAvailable */

{adm/incl/d__par01.if
  &ParameterListe = "pc_Options"
  &Parameter      = "Lieferant"
  &Variable1      = "Lieferant_min"
  &Variable2      = "Lieferant_max"
  &Datentyp       = "integer"
  &Flag           = "lExternalValueAvailable"
}

if not lExternalValueAvailable then
do:
  {adm/template/incl/dt_dlg04.if
    &Variable = "Lieferant_min"
    &Datentyp = "integer"
  }
  find last S_Lieferant
    where S_Lieferant.Firma = {firma/sliefera.fir pa-Firma}
    use-index Main
    no-lock no-error.
  if available S_Lieferant then 
    Lieferant_max = S_Lieferant.Lieferant.
end. /* not lExternalValueAvailable */

{adm/incl/d__par01.if
  &ParameterListe = "pc_Options"
  &Parameter      = "BelegNummer"
  &Variable1      = "BelegNummer_min"
  &Variable2      = "BelegNummer_max"
  &Datentyp       = "integer"
  &Flag           = "lExternalValueAvailable"
}

if not lExternalValueAvailable then
do:
  {adm/template/incl/dt_dlg04.if
    &Variable = "BelegNummer_min"
    &Datentyp = "integer"
  }
  {adm/template/incl/dt_dlg04.if
    &Variable = "BelegNummer_max"
    &Datentyp = "integer"
  }
end. /* not lExternalValueAvailable */

{adm/incl/d__par01.if
  &ParameterListe = "pc_Options"
  &Parameter      = "Sachbearbeiter"
  &Variable1      = "Sachbearbeiter_min"
  &Variable2      = "Sachbearbeiter_max"
  &Flag           = "lExternalValueAvailable"
}

if not lExternalValueAvailable then
do:
  {adm/template/incl/dt_dlg04.if
    &Variable = "Sachbearbeiter_min"
  }
  {adm/template/incl/dt_dlg04.if
    &Variable = "Sachbearbeiter_max"
  }
end. /* not lExternalValueAvailable */

{adm/incl/d__par01.if
  &ParameterListe = "pc_Options"
  &Parameter      = "AuftragsArt"
  &Variable1      = "AuftragsArt_min"
  &Variable2      = "AuftragsArt_max"
  &Flag           = "lExternalValueAvailable"
}

if not lExternalValueAvailable then
do:
  {adm/template/incl/dt_dlg04.if
    &Variable = "AuftragsArt_min"
  }
  find last S_AuftragsArt
    where S_AuftragsArt.Firma = {firma/saufart.fir pa-Firma}
    use-index Main
    no-lock no-error.
  if available S_AuftragsArt then 
    AuftragsArt_max = S_AuftragsArt.AuftragsArt.
end. /* not lExternalValueAvailable */

{adm/incl/d__par01.if
  &ParameterListe = "pc_Options"
  &Parameter      = "LieferAdresse"
  &Variable1      = "LieferAdresse_min"
  &Variable2      = "LieferAdresse_max"
  &Datentyp       = "integer"
  &Flag           = "lExternalValueAvailable"
}

if not lExternalValueAvailable then
do:
  {adm/template/incl/dt_dlg04.if
    &Variable = "LieferAdresse_min"
    &Datentyp = "integer"
  }
  {adm/template/incl/dt_dlg04.if
    &Variable = "LieferAdresse_max"
    &Datentyp = "integer"
  }
end. /* not lExternalValueAvailable */

{adm/incl/d__par01.if
  &ParameterListe = "pc_Options"
  &Parameter      = "iHorizont"
  &Variable1      = "iHorizont_var"
  &Datentyp       = "INTEGER"
  &Flag           = "lExternalValueAvailable"
}

if not lExternalValueAvailable then
do:
  {adm/template/incl/dt_dlg04.if
    &Variable = "iHorizont_var"
    &Datentyp = "INTEGER"
  }
end. /* not lExternalValueAvailable */

{adm/incl/d__par01.if
  &ParameterListe = "pc_Options"
  &Parameter      = "iMRPRelease"
  &Variable1      = "iMRPRelease_var"
  &Datentyp       = "integer"
  &Flag           = "lExternalValueAvailable"
}

if not lExternalValueAvailable then
do:
  {adm/template/incl/dt_dlg04.if
    &Variable = "iMRPRelease_var"
    &Datentyp = "integer"
  }
end. /* not lExternalValueAvailable */

{adm/incl/d__par01.if
  &ParameterListe = "pc_Options"
  &Parameter      = "iBezugsdatum"
  &Variable1      = "iBezugsdatum_var"
  &Datentyp       = "integer"
  &Flag           = "lExternalValueAvailable"
}

if not lExternalValueAvailable then
do:
  {adm/template/incl/dt_dlg04.if
    &Variable = "iBezugsdatum_var"
    &Datentyp = "integer"
  }
end. /* not lExternalValueAvailable */

{adm/incl/d__par01.if
  &ParameterListe = "pc_Options"
  &Parameter      = "Sparte"
  &Variable1      = "Sparte_min"
  &Variable2      = "Sparte_max"
  &Flag           = "lExternalValueAvailable"
}

if not lExternalValueAvailable then
do:
  {adm/template/incl/dt_dlg04.if
    &Variable = "Sparte_min"
  }
  find last S_Sparte
    where S_Sparte.Firma = {firma/ssparte.fir pa-Firma}
    use-index Main
    no-lock no-error.
  if available S_Sparte then 
    Sparte_max = S_Sparte.Sparte.
end. /* not lExternalValueAvailable */

{adm/incl/d__par01.if
  &ParameterListe = "pc_Options"
  &Parameter      = "LagerOrt"
  &Variable1      = "LagerOrt_min"
  &Variable2      = "LagerOrt_max"
  &Datentyp       = "integer"
  &Flag           = "lExternalValueAvailable"
}

if not lExternalValueAvailable then
do:
  {adm/template/incl/dt_dlg04.if
    &Variable = "LagerOrt_min"
    &Datentyp = "integer"
  }
  find last ML_Ort
    where ML_Ort.Firma = {firma/mlort.fir pa-Firma}
    use-index Main
    no-lock no-error.
  if available ML_Ort then 
    LagerOrt_max = ML_Ort.LagerOrt.
end. /* not lExternalValueAvailable */

{adm/incl/d__par01.if
  &ParameterListe = "pc_Options"
  &Parameter      = "LieferRestrikt"
  &Variable1      = "LieferRestrikt_min"
  &Variable2      = "LieferRestrikt_max"
  &Datentyp       = "integer"
  &Flag           = "lExternalValueAvailable"
}

if not lExternalValueAvailable then
do:
  {adm/template/incl/dt_dlg04.if
    &Variable = "LieferRestrikt_min"
    &Datentyp = "integer"
  }
  {adm/template/incl/dt_dlg04.if
    &Variable = "LieferRestrikt_max"
    &Datentyp = "integer"
  }
end. /* not lExternalValueAvailable */

{adm/incl/d__par01.if
  &ParameterListe = "pc_Options"
  &Parameter      = "ZahlungsZiel"
  &Variable1      = "ZahlungsZiel_min"
  &Variable2      = "ZahlungsZiel_max"
  &Datentyp       = "integer"
  &Flag           = "lExternalValueAvailable"
}

if not lExternalValueAvailable then
do:
  {adm/template/incl/dt_dlg04.if
    &Variable = "ZahlungsZiel_min"
    &Datentyp = "integer"
  }
  find last S_ZahlZiel
    where S_ZahlZiel.Firma = {firma/szahlzie.fir pa-Firma}
    use-index Main
    no-lock no-error.
  if available S_ZahlZiel then 
    ZahlungsZiel_max = S_ZahlZiel.ZahlungsZiel.
end. /* not lExternalValueAvailable */

{adm/incl/d__par01.if
  &ParameterListe = "pc_Options"
  &Parameter      = "Lagergruppe"
  &Variable1      = "Lagergruppe_min"
  &Variable2      = "Lagergruppe_max"
  &Datentyp       = "integer"
  &Flag           = "lExternalValueAvailable"
}

if not lExternalValueAvailable then
do:
  {adm/template/incl/dt_dlg04.if
    &Variable = "Lagergruppe_min"
    &Datentyp = "integer"
  }
  find last ML_Lagergruppe
    where ML_Lagergruppe.Firma = {firma/mlort.fir pa-Firma}
    use-index Main
    no-lock no-error.
  if available ML_Lagergruppe then 
    Lagergruppe_max = ML_Lagergruppe.Lagergruppe.
end. /* not lExternalValueAvailable */

{adm/incl/d__par01.if
  &ParameterListe = "pc_Options"
  &Parameter      = "lTodayOrderLines"
  &Variable1      = "lTodayOrderLines_var"
  &cc_Log         = "yes"
  &Flag           = "lExternalValueAvailable"
}

if not lExternalValueAvailable then
do:
  {adm/template/incl/dt_dlg04.if
    &Variable = "lTodayOrderLines_var"
    &Datentyp = "LOGICAL"
  }
end. /* not lExternalValueAvailable */

{adm/incl/d__par01.if
  &ParameterListe = "pc_Options"
  &Parameter      = "lFutureOrderLines"
  &Variable1      = "lFutureOrderLines_var"
  &cc_Log         = "yes"
  &Flag           = "lExternalValueAvailable"
}

if not lExternalValueAvailable then
do:
  {adm/template/incl/dt_dlg04.if
    &Variable = "lFutureOrderLines_var"
    &Datentyp = "LOGICAL"
  }
end. /* not lExternalValueAvailable */

{adm/incl/d__par01.if
  &ParameterListe = "pc_Options"
  &Parameter      = "lPastOrderLines"
  &Variable1      = "lPastOrderLines_var"
  &cc_Log         = "yes"
  &Flag           = "lExternalValueAvailable"
}

if not lExternalValueAvailable then
do:
  {adm/template/incl/dt_dlg04.if
    &Variable = "lPastOrderLines_var"
    &Datentyp = "LOGICAL"
  }
end. /* not lExternalValueAvailable */

/* Copy setup from dummy frame                                                */

if frame {&FRAME-NAME}:hidden then
do:

  /* Here are single statements used because a assign would exceed the limits.*/

  {setwidgetattr
    Konto_min
    format
    "S_BelegParam.Konto:format in frame f_dummy"
    "in frame {&FRAME-NAME}"} no-error.
  {setwidgetattr
    Konto_min
    label
    "S_BelegParam.Konto:label in frame f_dummy"
    "in frame {&FRAME-NAME}"} no-error.

  {setwidgetattr
    Konto_max
    format
    "S_BelegParam.Konto:format in frame f_dummy"
    "in frame {&FRAME-NAME}"} no-error.

  {setwidgetattr
    Artikel_min
    format
    "S_Artikel.Artikel:format in frame f_dummy"
    "in frame {&FRAME-NAME}"} no-error.
  {setwidgetattr
    Artikel_min
    label
    "S_Artikel.Artikel:label in frame f_dummy"
    "in frame {&FRAME-NAME}"} no-error.

  {setwidgetattr
    Artikel_max
    format
    "S_Artikel.Artikel:format in frame f_dummy"
    "in frame {&FRAME-NAME}"} no-error.

  {setwidgetattr
    ArtikelGruppe_min
    format
    "S_ArtGruppe.ArtikelGruppe:format in frame f_dummy"
    "in frame {&FRAME-NAME}"} no-error.
  {setwidgetattr
    ArtikelGruppe_min
    label
    "S_ArtGruppe.ArtikelGruppe:label in frame f_dummy"
    "in frame {&FRAME-NAME}"} no-error.

  {setwidgetattr
    ArtikelGruppe_max
    format
    "S_ArtGruppe.ArtikelGruppe:format in frame f_dummy"
    "in frame {&FRAME-NAME}"} no-error.

  {setwidgetattr
    ArtikelArt_min
    format
    "S_ArtikelArt.ArtikelArt:format in frame f_dummy"
    "in frame {&FRAME-NAME}"} no-error.
  {setwidgetattr
    ArtikelArt_min
    label
    "S_ArtikelArt.ArtikelArt:label in frame f_dummy"
    "in frame {&FRAME-NAME}"} no-error.

  {setwidgetattr
    ArtikelArt_max
    format
    "S_ArtikelArt.ArtikelArt:format in frame f_dummy"
    "in frame {&FRAME-NAME}"} no-error.

  {setwidgetattr
    Wunschtermin_min
    format
    "V_BelegPos.Wunschtermin:format in frame f_dummy"
    "in frame {&FRAME-NAME}"} no-error.
  {setwidgetattr
    Wunschtermin_min
    label
    "V_BelegPos.Wunschtermin:label in frame f_dummy"
    "in frame {&FRAME-NAME}"} no-error.

  {setwidgetattr
    Wunschtermin_max
    format
    "V_BelegPos.Wunschtermin:format in frame f_dummy"
    "in frame {&FRAME-NAME}"} no-error.

  {setwidgetattr
    Liefertermin_min
    format
    "V_BelegPos.Liefertermin:format in frame f_dummy"
    "in frame {&FRAME-NAME}"} no-error.
  {setwidgetattr
    Liefertermin_min
    label
    "V_BelegPos.Liefertermin:label in frame f_dummy"
    "in frame {&FRAME-NAME}"} no-error.

  {setwidgetattr
    Liefertermin_max
    format
    "V_BelegPos.Liefertermin:format in frame f_dummy"
    "in frame {&FRAME-NAME}"} no-error.

  {setwidgetattr
    uCI_Warenausgangstermin_min
    format
    "V_BelegPos.uCI_Warenausgangstermin:format in frame f_dummy"
    "in frame {&FRAME-NAME}"} no-error.
  {setwidgetattr
    uCI_Warenausgangstermin_min
    label
    "V_BelegPos.uCI_Warenausgangstermin:label in frame f_dummy"
    "in frame {&FRAME-NAME}"} no-error.

  {setwidgetattr
    uCI_Warenausgangstermin_max
    format
    "V_BelegPos.uCI_Warenausgangstermin:format in frame f_dummy"
    "in frame {&FRAME-NAME}"} no-error.

  {setwidgetattr
    Versandtermin_min
    format
    "V_BelegPos.Versandtermin:format in frame f_dummy"
    "in frame {&FRAME-NAME}"} no-error.
  {setwidgetattr
    Versandtermin_min
    label
    "V_BelegPos.Versandtermin:label in frame f_dummy"
    "in frame {&FRAME-NAME}"} no-error.

  {setwidgetattr
    Versandtermin_max
    format
    "V_BelegPos.Versandtermin:format in frame f_dummy"
    "in frame {&FRAME-NAME}"} no-error.

  {setwidgetattr
    AdressKennung_min
    format
    "S_LieferAdresse.AdressKennung:format in frame f_dummy"
    "in frame {&FRAME-NAME}"} no-error.
  {setwidgetattr
    AdressKennung_min
    label
    "S_LieferAdresse.AdressKennung:label in frame f_dummy"
    "in frame {&FRAME-NAME}"} no-error.

  {setwidgetattr
    AdressKennung_max
    format
    "S_LieferAdresse.AdressKennung:format in frame f_dummy"
    "in frame {&FRAME-NAME}"} no-error.

  {setwidgetattr
    Abladestelle_min
    format
    "VU_RA_Pos.Abladestelle:format in frame f_dummy"
    "in frame {&FRAME-NAME}"} no-error.
  {setwidgetattr
    Abladestelle_min
    label
    "VU_RA_Pos.Abladestelle:label in frame f_dummy"
    "in frame {&FRAME-NAME}"} no-error.

  {setwidgetattr
    Abladestelle_max
    format
    "VU_RA_Pos.Abladestelle:format in frame f_dummy"
    "in frame {&FRAME-NAME}"} no-error.

  {setwidgetattr
    uCI_LagerortKunde_min
    format
    "VU_RA_Abruf.uCI_LagerortKunde:format in frame f_dummy"
    "in frame {&FRAME-NAME}"} no-error.
  {setwidgetattr
    uCI_LagerortKunde_min
    label
    "VU_RA_Abruf.uCI_LagerortKunde:label in frame f_dummy"
    "in frame {&FRAME-NAME}"} no-error.

  {setwidgetattr
    uCI_LagerortKunde_max
    format
    "VU_RA_Abruf.uCI_LagerortKunde:format in frame f_dummy"
    "in frame {&FRAME-NAME}"} no-error.

  {setwidgetattr
    VersandArt_min
    format
    "S_VersandArt.VersandArt:format in frame f_dummy"
    "in frame {&FRAME-NAME}"} no-error.
  {setwidgetattr
    VersandArt_min
    label
    "S_VersandArt.VersandArt:label in frame f_dummy"
    "in frame {&FRAME-NAME}"} no-error.

  {setwidgetattr
    VersandArt_max
    format
    "S_VersandArt.VersandArt:format in frame f_dummy"
    "in frame {&FRAME-NAME}"} no-error.

  {setwidgetattr
    LieferBedingung_min
    format
    "S_LieferBed.LieferBedingung:format in frame f_dummy"
    "in frame {&FRAME-NAME}"} no-error.
  {setwidgetattr
    LieferBedingung_min
    label
    "S_LieferBed.LieferBedingung:label in frame f_dummy"
    "in frame {&FRAME-NAME}"} no-error.

  {setwidgetattr
    LieferBedingung_max
    format
    "S_LieferBed.LieferBedingung:format in frame f_dummy"
    "in frame {&FRAME-NAME}"} no-error.

  {setwidgetattr
    Lieferant_min
    format
    "S_Lieferant.Lieferant:format in frame f_dummy"
    "in frame {&FRAME-NAME}"} no-error.
  {setwidgetattr
    Lieferant_min
    label
    "S_Lieferant.Lieferant:label in frame f_dummy"
    "in frame {&FRAME-NAME}"} no-error.

  {setwidgetattr
    Lieferant_max
    format
    "S_Lieferant.Lieferant:format in frame f_dummy"
    "in frame {&FRAME-NAME}"} no-error.

  {setwidgetattr
    BelegNummer_min
    format
    "V_BelegKopf.BelegNummer:format in frame f_dummy"
    "in frame {&FRAME-NAME}"} no-error.
  {setwidgetattr
    BelegNummer_min
    label
    "V_BelegKopf.BelegNummer:label in frame f_dummy"
    "in frame {&FRAME-NAME}"} no-error.

  {setwidgetattr
    BelegNummer_max
    format
    "V_BelegKopf.BelegNummer:format in frame f_dummy"
    "in frame {&FRAME-NAME}"} no-error.

  {setwidgetattr
    Sachbearbeiter_min
    format
    "V_BelegKopf.Sachbearbeiter:format in frame f_dummy"
    "in frame {&FRAME-NAME}"} no-error.
  {setwidgetattr
    Sachbearbeiter_min
    label
    "V_BelegKopf.Sachbearbeiter:label in frame f_dummy"
    "in frame {&FRAME-NAME}"} no-error.

  {setwidgetattr
    Sachbearbeiter_max
    format
    "V_BelegKopf.Sachbearbeiter:format in frame f_dummy"
    "in frame {&FRAME-NAME}"} no-error.

  {setwidgetattr
    AuftragsArt_min
    format
    "S_AuftragsArt.AuftragsArt:format in frame f_dummy"
    "in frame {&FRAME-NAME}"} no-error.
  {setwidgetattr
    AuftragsArt_min
    label
    "S_AuftragsArt.AuftragsArt:label in frame f_dummy"
    "in frame {&FRAME-NAME}"} no-error.

  {setwidgetattr
    AuftragsArt_max
    format
    "S_AuftragsArt.AuftragsArt:format in frame f_dummy"
    "in frame {&FRAME-NAME}"} no-error.

  {setwidgetattr
    LieferAdresse_min
    format
    "S_LieferAdresse.LieferAdresse:format in frame f_dummy"
    "in frame {&FRAME-NAME}"} no-error.
  {setwidgetattr
    LieferAdresse_min
    label
    "S_LieferAdresse.LieferAdresse:label in frame f_dummy"
    "in frame {&FRAME-NAME}"} no-error.

  {setwidgetattr
    LieferAdresse_max
    format
    "S_LieferAdresse.LieferAdresse:format in frame f_dummy"
    "in frame {&FRAME-NAME}"} no-error.

  {setwidgetattr
    Sparte_min
    format
    "S_Sparte.Sparte:format in frame f_dummy"
    "in frame {&FRAME-NAME}"} no-error.
  {setwidgetattr
    Sparte_min
    label
    "S_Sparte.Sparte:label in frame f_dummy"
    "in frame {&FRAME-NAME}"} no-error.

  {setwidgetattr
    Sparte_max
    format
    "S_Sparte.Sparte:format in frame f_dummy"
    "in frame {&FRAME-NAME}"} no-error.

  {setwidgetattr
    LagerOrt_min
    format
    "ML_Ort.LagerOrt:format in frame f_dummy"
    "in frame {&FRAME-NAME}"} no-error.
  {setwidgetattr
    LagerOrt_min
    label
    "ML_Ort.LagerOrt:label in frame f_dummy"
    "in frame {&FRAME-NAME}"} no-error.

  {setwidgetattr
    LagerOrt_max
    format
    "ML_Ort.LagerOrt:format in frame f_dummy"
    "in frame {&FRAME-NAME}"} no-error.

  {setwidgetattr
    LieferRestrikt_min
    format
    "V_BelegKopf.LieferRestrikt:format in frame f_dummy"
    "in frame {&FRAME-NAME}"} no-error.
  {setwidgetattr
    LieferRestrikt_min
    label
    "V_BelegKopf.LieferRestrikt:label in frame f_dummy"
    "in frame {&FRAME-NAME}"} no-error.

  {setwidgetattr
    LieferRestrikt_max
    format
    "V_BelegKopf.LieferRestrikt:format in frame f_dummy"
    "in frame {&FRAME-NAME}"} no-error.

  {setwidgetattr
    ZahlungsZiel_min
    format
    "S_ZahlZiel.ZahlungsZiel:format in frame f_dummy"
    "in frame {&FRAME-NAME}"} no-error.
  {setwidgetattr
    ZahlungsZiel_min
    label
    "S_ZahlZiel.ZahlungsZiel:label in frame f_dummy"
    "in frame {&FRAME-NAME}"} no-error.

  {setwidgetattr
    ZahlungsZiel_max
    format
    "S_ZahlZiel.ZahlungsZiel:format in frame f_dummy"
    "in frame {&FRAME-NAME}"} no-error.

  {setwidgetattr
    Lagergruppe_min
    format
    "ML_Lagergruppe.Lagergruppe:format in frame f_dummy"
    "in frame {&FRAME-NAME}"} no-error.
  {setwidgetattr
    Lagergruppe_min
    label
    "ML_Lagergruppe.Lagergruppe:label in frame f_dummy"
    "in frame {&FRAME-NAME}"} no-error.

  {setwidgetattr
    Lagergruppe_max
    format
    "ML_Lagergruppe.Lagergruppe:format in frame f_dummy"
    "in frame {&FRAME-NAME}"} no-error.
end. /* if frame {&FRAME-NAME}:hidden */

/* Default Code                                                               */

{adm/template/incl/dt_dlg01.if}

end procedure. /* initialize */

/* _UIB-CODE-BLOCK-END */
&ANALYZE-RESUME

