&ANALYZE-SUSPEND _VERSION-NUMBER UIB_v8r12 GUI
&ANALYZE-RESUME
/* Connected Databases 
          temp-db          PROGRESS
          basis            PROGRESS
*/
&Scoped-define WINDOW-NAME CURRENT-WINDOW

&ANALYZE-SUSPEND _UIB-CODE-BLOCK _CUSTOM _DECLARATIONS B-table-Win 
using vert.fakt.cls.VFCAtlasSvc.
/* _UIB-CODE-BLOCK-END */
&ANALYZE-RESUME


&ANALYZE-SUSPEND _UIB-CODE-BLOCK _XFTR "Update Information" B-table-Win _INLINE
/* Actions: ? ? ? ? adm/support/proc/ds_pa_01.w */

/* _UIB-CODE-BLOCK-END */
&ANALYZE-RESUME


&ANALYZE-SUSPEND _UIB-CODE-BLOCK _CUSTOM _DEFINITIONS B-table-Win 
/******************************************************************************/
/* @COPYRIGHT@                                                                */
/* Project: Proalpha                                                          */
/*                                                                            */
/* Name   : uvbvmo00.w                                                        */
/* Product: BRANCHE      - Branchentemplates                                  */
/* Module : VERT         - Vertrieb                                           */
/*                                                                            */
/* Created: 61e as of 16.11.2016/Claas Kuehnlenz                              */
/* Current: @PAVERSION@ as of @PADATE@/@PALASTAUTHOR@                         */
/*                                                                            */
/*----------------------------------------------------------------------------*/
/* DESCRIPTION                                                                */
/*----------------------------------------------------------------------------*/
/*                                                                            */
/* Versandmonitor (SmartBrowser)                                              */
/*                                                                            */
/*----------------------------------------------------------------------------*/
/* PARAMETERS                                                                 */
/*----------------------------------------------------------------------------*/
/* Name                      Description                                      */
/*----------------------------------------------------------------------------*/
/*                                                                            */
/*----------------------------------------------------------------------------*/
/* HISTORY                                                                    */
/*----------------------------------------------------------------------------*/
/* @FILEHISTORY@                                                              */
/******************************************************************************/

create widget-pool.

/* Procedure Information -----------------------------------------------------*/

&GLOBAL-DEFINE pa-Autor             Claas Kuehnlenz
&GLOBAL-DEFINE pa-Version           @PAVERSION@
&GLOBAL-DEFINE pa-Datum             @PADATE@
&GLOBAL-DEFINE pa-Letzter           @PALASTAUTHOR@

&GLOBAL-DEFINE pa-GenVersion       UIB
&GLOBAL-DEFINE pa-ProgrammTyp      SmartBrowser
&GLOBAL-DEFINE pa-Template         adm/template/proc/dt_brw02.w
&GLOBAL-DEFINE pa-TemplateVersion  4.03
&GLOBAL-DEFINE pa-XBasisName       uvbvmo00_w
&GLOBAL-DEFINE pa-NameSpace        2.00

/* Parameters ----------------------------------------------------------------*/

/* Globals -------------------------------------------------------------------*/

{adm/template/incl/dt_brw00.df}

/* SCOPEDs -------------------------------------------------------------------*/
&SCOP PA-HLP-FIELDNAMES giKonto,giLieferadresse,gcAdressKennung,gcAbladestelle,gcuCI_LagerortKunde,giLieferant,giVersandArt,gcArtikel
&SCOP PA-HLP-KEYNAMES   Kunde,Adresse,AdressKennung,Abladestelle,uCI_LagerortKunde,Lieferant,VersandArt,Artikel

&SCOP uMaxKommPos 100

/* Variables -----------------------------------------------------------------*/
/*----------------------------------------------------------------------------*/

define variable ghDocumentHeader              as handle        no-undo.
define variable ghDocumentHeaderInfo          as handle        no-undo.
define variable ghDocumentLine                as handle        no-undo.
define variable ghDocumentLineInfo            as handle        no-undo.
define variable gcProgramDocumentHeader       as character     no-undo.
define variable gcProgramDocumentHeaderInfo   as character     no-undo.
define variable gcProgramDocumentLine         as character     no-undo.
define variable gcProgramDocumentLineInfo     as character     no-undo.
define variable gcMenuItemDocumentHeader      as character     no-undo.
define variable gcMenuItemDocumentHeaderInfo  as character     no-undo.
define variable gcMenuItemDocumentLine        as character     no-undo.
define variable gcMenuItemDocumentLineInfo    as character     no-undo.
define variable giSuchFeld                    as integer       no-undo.
define variable glMarked                      as logical       no-undo.

define variable gcTransTimeUnitDesc   as character no-undo column-label 'ZEtt':T4.
define variable gcKommTimeUnitDesc    as character no-undo column-label 'ZEKO':T6.

define variable gcCoverageStatus      as character no-undo format 'x(15)':UR column-label 'Status':T18.

define variable glTriggerError        as logical       no-undo.

define variable gcWindowTitle         as character     no-undo.
define variable giHits                as integer       no-undo.

define variable gcKontoName           as character     no-undo format 'x(107)':U column-label 'Name Kd/Lief':L30.
define variable gcAbladestelleBez     as character     no-undo format 'x(107)':U column-label 'Bezeichnung Abladestelle':L30.
define variable gcArtikelBez          as character     no-undo format 'x(123)':U column-label 'Teilebezeichnung':L30.
define variable gcArtikelNrBez        as character     no-undo format 'x(123)':U column-label 'Kunden-Teilebezeichnung':L30.
define variable gcLieferantName       as character     no-undo format 'x(107)':U column-label 'Name Lieferant':L30.
define variable gcLiefAdr_Name        as character     no-undo format 'x(107)':U column-label 'Name Lieferadresse':L30.
define variable glADM-Cancel          as logical       no-undo.
define variable gcMarkedLines         as longchar      no-undo.
define variable gcOffset-value        as character     no-undo.

define variable gcUCI_CoverageStatus_ColorBG as character     no-undo.
define variable gcUCI_CoverageStatus_ColorFG as character     no-undo.
define variable gcUCI_CoverageStatus_Keys    as character     no-undo.
define variable gcUCI_CoverageStatus_Desc    as character     no-undo.
define variable gcSB_TimeUnits_keys          as character     no-undo.
define variable gcSB_TimeUnits_desc          as character     no-undo.

define variable giDecimals            like  S_Mengeneinheit.Nachkomma   no-undo.

define variable pa-filter-iMRPRelease_var           as integer                                    no-undo init ?.
define variable pa-filter-lPastOrderLines_var       as logical                                    no-undo init no.
define variable pa-filter-lTodayOrderLines_var      as logical                                    no-undo init yes.
define variable pa-filter-lFutureOrderLines_var     as logical                                    no-undo init yes.
define variable pa-filter-iBezugsdatum_var          as integer                                    no-undo init ?.
define variable pa-filter-iHorizont_var             as integer                                    no-undo init ?.

/* --> MO#HIDR-AH4-1123 thongdi_p 20.07.2026 Erweiterung Versandmonitor im Feld Best. Termin */
define variable pa-filter-xEbLiefertermin_min  as date  no-undo init ?.
define variable pa-filter-xEbLiefertermin_max  as date  no-undo init ?.
/* <-- MO#HIDR-AH4-1123 thongdi_p 20.07.2026 Erweiterung Versandmonitor im Feld Best. Termin */

define variable oSelectedObject as  stamm.cls.S_CSelectedObjectsSvo no-undo.

&IF LOOKUP("VS","{&PA-MODULE}") > 0 &THEN
  define variable giCurrentIndex      as integer   no-undo.
  define variable ghCalledProc        as handle    no-undo.

  subscribe to "handleBrowserClose":U in this-procedure.
&ENDIF
/* Datasets ------------------------------------------------------------------*/

{branche/vert/incl/uv_vmo00.pds
  &ippNoReferenceOnlySwitch = "YES"}

/* Buffers -------------------------------------------------------------------*/

define buffer gbS_ArtKunde for S_ArtKunde.
define buffer gbS_EAN      for S_EAN.

/* Temp-Tables ---------------------------------------------------------------*/

{branche/vert/incl/uv_pos00.tdf}
{branche/vert/incl/uv_pos01.tdf}
{branche/vert/incl/uv_pos02.tdf}

/* _UIB-CODE-BLOCK-END */
&ANALYZE-RESUME


&ANALYZE-SUSPEND _UIB-PREPROCESSOR-BLOCK 

/* ********************  Preprocessor Definitions  ******************** */

&Scoped-define PROCEDURE-TYPE Proalpha-SmartBrowser
&Scoped-define DB-AWARE no

&Scoped-define ADM-SUPPORTED-LINKS Record-Source,Record-Target,TableIO-Target,Navigation-Target

/* Name of designated FRAME-NAME and/or first browse and/or first query */
&Scoped-define FRAME-NAME F-Main
&Scoped-define BROWSE-NAME br_table

/* Internal Tables (found by Frame, Query & Browse Queries)             */
&Scoped-define INTERNAL-TABLES ttUV_VersandBeleg

/* Define KEY-PHRASE in case it is used by any query. */
&Scoped-define KEY-PHRASE TRUE

/* --> MO#HIDR-AH4-1123 thongdi_p 20.07.2026 Erweiterung Versandmonitor im Feld Best. Termin */
/* Definitions for BROWSE br_table                                      */
&Scoped-define FIELDS-IN-QUERY-br_table find-additional-records() @ gcCoverageStatus ttUV_VersandBeleg.xEbLiefertermin ttUV_VersandBeleg.Markiert ttUV_VersandBeleg.Konto ttUV_VersandBeleg.Konto_Name1 ttUV_VersandBeleg.Konto_Name2 ttUV_VersandBeleg.Konto_Name3 gcKontoName ttUV_VersandBeleg.Konto_Suchbegriff ttUV_VersandBeleg.Konto_Selektion ttUV_VersandBeleg.Konto_Branche ttUV_VersandBeleg.Konto_BrancheBez ttUV_VersandBeleg.Konto_Region ttUV_VersandBeleg.Konto_RegionBez ttUV_VersandBeleg.Belegart ttUV_VersandBeleg.BelegartBez ttUV_VersandBeleg.BelegNummer ttUV_VersandBeleg.PositionsNr ttUV_VersandBeleg.BelegInfo ttUV_VersandBeleg.Abruf ttUV_VersandBeleg.AbrufNr ttUV_VersandBeleg.Abladestelle ttUV_VersandBeleg.AbladestelleBez[1] ttUV_VersandBeleg.AbladestelleBez[2] ttUV_VersandBeleg.AbladestelleBez[3] ttUV_VersandBeleg.AbladestelleBez[4] gcAbladestelleBez ttUV_VersandBeleg.LocklevelOriginLSLSL ttUV_VersandBeleg.LocklevelOriginMMP ttUV_VersandBeleg.LocklevelPartLSLSL ttUV_VersandBeleg.LocklevelPartMMP ttUV_VersandBeleg.LocklevelCustomerLSLSL ttUV_VersandBeleg.LocklevelCustomerMMP ttUV_VersandBeleg.LocklevelCarrierLSL ttUV_VersandBeleg.LocklevelCarrierVSD ttUV_VersandBeleg.Mahnstufe ttUV_VersandBeleg.uCI_ZeichenKunde ttUV_VersandBeleg.uCI_LagerortKunde ttUV_VersandBeleg.uCI_Hinweis1 ttUV_VersandBeleg.uCI_Hinweis2 ttUV_VersandBeleg.uCI_Hinweis3 ttUV_VersandBeleg.uCI_Hinweis4 ttUV_VersandBeleg.Auftrag ttUV_VersandBeleg.uCI_Sammellieferschein ttUV_VersandBeleg.Artikel ttUV_VersandBeleg.ArtikelBez[1] ttUV_VersandBeleg.ArtikelBez[2] ttUV_VersandBeleg.ArtikelBez[3] ttUV_VersandBeleg.ArtikelBez[4] gcArtikelBez ttUV_VersandBeleg.Artikelgruppe ttUV_VersandBeleg.ArtikelgruppeBez ttUV_VersandBeleg.Sparte ttUV_VersandBeleg.SparteBez ttUV_VersandBeleg.Artikel_Selektion ttUV_VersandBeleg.Artikel_Suchbegriff ttUV_VersandBeleg.ArtikelArt ttUV_VersandBeleg.ArtikelArtBez ttUV_VersandBeleg.ArtikelNr ttUV_VersandBeleg.ArtikelNrBez[1] ttUV_VersandBeleg.ArtikelNrBez[2] ttUV_VersandBeleg.ArtikelNrBez[3] ttUV_VersandBeleg.ArtikelNrBez[4] gcArtikelNrBez ttUV_VersandBeleg.Wunschtermin ttUV_VersandBeleg.Liefertermin ttUV_VersandBeleg.Transportzeit gcTransTimeUnitDesc ttUV_VersandBeleg.uCI_Warenausgangstermin ttUV_VersandBeleg.uCI_KommZeit gcKommTimeUnitDesc ttUV_VersandBeleg.Versandtermin ttUV_VersandBeleg.AuftragsArt ttUV_VersandBeleg.AuftragsArtBez ttUV_VersandBeleg.Versandart ttUV_VersandBeleg.VersandarBez ttUV_VersandBeleg.LieferBedingung ttUV_VersandBeleg.LieferBedingungBez ttUV_VersandBeleg.LieferRestrikt ttUV_VersandBeleg.LieferRestriktBez ttUV_VersandBeleg.Sachbearbeiter ttUV_VersandBeleg.SachbearbeiterName ttUV_VersandBeleg.Lieferant ttUV_VersandBeleg.Lieferant_Name1 ttUV_VersandBeleg.Lieferant_Name2 ttUV_VersandBeleg.Lieferant_Name3 gcLieferantName ttUV_VersandBeleg.Lieferant_Suchbegriff ttUV_VersandBeleg.Lieferant_Selektion ttUV_VersandBeleg.LieferAdresse ttUV_VersandBeleg.AdressKennung ttUV_VersandBeleg.LiefAdr_Name1 gcLiefAdr_Name ttUV_VersandBeleg.LiefAdr_Staat ttUV_VersandBeleg.LiefAdr_PLZ ttUV_VersandBeleg.LiefAdr_Ort ttUV_VersandBeleg.LiefAdr_Bundesland ttUV_VersandBeleg.LiefAdr_Name2 ttUV_VersandBeleg.LiefAdr_Name3 ttUV_VersandBeleg.LiefAdr_Strasse ttUV_VersandBeleg.LiefAdr_HausNummer ttUV_VersandBeleg.KO_LagerOrt ttUV_VersandBeleg.KO_LagerOrtBez ttUV_VersandBeleg.Menge ttUV_VersandBeleg.gelieferte_Menge ttUV_VersandBeleg.KommMenge ttUV_VersandBeleg.OffeneMenge ttUV_VersandBeleg.uCI_DispatchQty ttUV_VersandBeleg.uCI_DispatchQtyRemark ttUV_VersandBeleg.Bestand ttUV_VersandBeleg.MengenEinheitKurzBezLME ttUV_VersandBeleg.MengenEinheitKurzBez ttUV_VersandBeleg.VME_Faktor ttUV_VersandBeleg.MRPRelease ttUV_VersandBeleg.GesamtwertOffen ttUV_VersandBeleg.GesamtwertVerfuegbar ttUV_VersandBeleg.Fehlermeldung ttUV_VersandBeleg.StorageArea ttUV_VersandBeleg.StorageArea_Desc ttUV_VersandBeleg.CreditTerms ttUV_VersandBeleg.CreditTerms_Desc ttUV_VersandBeleg.MRPArea ttUV_VersandBeleg.MRPArea_desc {&{&PA-XBASISNAME}_C_BROWSEDISPLAY} {&{&PA-XBASISNAME}_U_BROWSEDISPLAY} {&{&PA-XBASISNAME}_BROWSEDISPLAY} {&{&PA-XBASISNAME}_Y_BROWSEDISPLAY}
&Scoped-define ENABLED-FIELDS-IN-QUERY-br_table ttUV_VersandBeleg.uCI_DispatchQty ~
ttUV_VersandBeleg.uCI_DispatchQtyRemark   
&Scoped-define ENABLED-TABLES-IN-QUERY-br_table ttUV_VersandBeleg
&Scoped-define FIRST-ENABLED-TABLE-IN-QUERY-br_table ttUV_VersandBeleg
&Scoped-define SELF-NAME br_table
&Scoped-define QUERY-STRING-br_table ~{&PA-VIRTUAL-INDEX-PHRASE} EACH ttUV_VersandBeleg WHERE ~{&KEY-PHRASE} NO-LOCK ~{&SORTBY-PHRASE}
&Scoped-define OPEN-QUERY-br_table OPEN QUERY {&SELF-NAME} ~{&PA-VIRTUAL-INDEX-PHRASE} EACH ttUV_VersandBeleg WHERE ~{&KEY-PHRASE} NO-LOCK ~{&SORTBY-PHRASE}.
&Scoped-define TABLES-IN-QUERY-br_table ttUV_VersandBeleg
&Scoped-define FIRST-TABLE-IN-QUERY-br_table ttUV_VersandBeleg
/* <-- MO#HIDR-AH4-1123 thongdi_p 20.07.2026 Erweiterung Versandmonitor im Feld Best. Termin */

/* Definitions for FRAME F-Main                                         */

/* Standard List Definitions                                            */
&Scoped-Define ENABLED-OBJECTS br_table giKonto giLieferadresse ~
gcAdressKennung gcAbladestelle gcuCI_LagerortKunde giLieferant giVersandArt ~
gtuCI_Warenausgangstermin_min gtuCI_Warenausgangstermin_max ~
gtVersandtermin_min gtVersandtermin_max gcArtikel gcSuche glBelegartU ~
glBelegartVUA glDocTypeServiceOrder glDocTypeRepairOrder glBelegartPPF glCoverageStatus_Without ~
glCoverageStatus_Available glCoverageStatus_PAvailable ~
glCoverageStatus_Covered glCoverageStatus_Open 
&Scoped-Define DISPLAYED-OBJECTS giKonto giLieferadresse gcAdressKennung ~
gcAbladestelle gcuCI_LagerortKunde gcKonto_Name1 gcKonto_Name2 ~
gcKonto_Strasse gcKonto_Ort giLieferant giVersandArt ~
gtuCI_Warenausgangstermin_min gtuCI_Warenausgangstermin_max ~
gtVersandtermin_min gtVersandtermin_max gcArtikel gcSuche gcLieferant_Name1 ~
gcLieferant_Name2 gcLieferant_Strasse gcLieferant_Ort gcGesamtwert ~
gcGesamtwert_offen gdGesamtwert_Markiert gdGesamtwert_offen_Markiert ~
gdGesamtwert_Alle gdGesamtwert_offen_alle glBelegartU glBelegartVUA ~
glDocTypeServiceOrder glDocTypeRepairOrder glBelegartPPF glCoverageStatus_Without glCoverageStatus_Available ~
glCoverageStatus_PAvailable glCoverageStatus_Covered glCoverageStatus_Open 

/* Custom List Definitions                                              */
/* List-1,List-2,List-3,List-4,List-5,List-6                            */

/* _UIB-PREPROCESSOR-BLOCK-END */
&ANALYZE-RESUME


&ANALYZE-SUSPEND _UIB-CODE-BLOCK _XFTR "Foreign Keys" B-table-Win _INLINE
/* Actions: ? adm/support/proc/keyedit.w ? ? ? */
/* STRUCTURED-DATA
<KEY-OBJECT>
&BROWSE-NAME
</KEY-OBJECT>
<FOREIGN-KEYS>
Konto||y|temp-db.ttUV_VersandBeleg.Konto|||y|||
Artikel||y|temp-db.ttUV_VersandBeleg.Artikel|||y|||
ArtVar||y|temp-db.ttUV_VersandBeleg.ArtVar||||||
ArtikelGruppe||y|temp-db.ttUV_VersandBeleg.ArtikelGruppe|||y|||
Sparte||y|temp-db.ttUV_VersandBeleg.Sparte|||y|||
ArtikelArt||y|temp-db.ttUV_VersandBeleg.ArtikelArt|||y|||
Wunschtermin||y|temp-db.ttUV_VersandBeleg.Wunschtermin|||y|||
Liefertermin||y|temp-db.ttUV_VersandBeleg.Liefertermin|||y|||
/* --> MO#HIDR-AH4-1123 thongdi_p 20.07.2026 Erweiterung Versandmonitor im Feld Best. Termin */
xEbLiefertermin||y|temp-db.ttUV_VersandBeleg.xEbLiefertermin|||y|||
/* <-- MO#HIDR-AH4-1123 thongdi_p 20.07.2026 Erweiterung Versandmonitor im Feld Best. Termin */
uCI_Warenausgangstermin||y|temp-db.ttUV_VersandBeleg.uCI_Warenausgangstermin|||y|||
Versandtermin||y|temp-db.ttUV_VersandBeleg.Versandtermin|||y|||
BelegNummer||y|temp-db.ttUV_VersandBeleg.BelegNummer|||y|||
Sachbearbeiter||y|temp-db.ttUV_VersandBeleg.Sachbearbeiter|||y|||
AuftragsArt||y|temp-db.ttUV_VersandBeleg.AuftragsArt|||y|||
LieferAdresse||y|temp-db.ttUV_VersandBeleg.LieferAdresse|||y|||
AdressKennung||y|temp-db.ttUV_VersandBeleg.AdressKennung|||y|||
Abladestelle||y|temp-db.ttUV_VersandBeleg.Abladestelle|||y|||
uCI_LagerortKunde||y|temp-db.ttUV_VersandBeleg.uCI_LagerortKunde|||y|||
VersandArt||y|temp-db.ttUV_VersandBeleg.VersandArt|||y|||
LieferBedingung||y|temp-db.ttUV_VersandBeleg.LieferBedingung|||y|||
Lieferant||y|temp-db.ttUV_VersandBeleg.Lieferant|||y|||
Owning_Obj||y|temp-db.ttUV_VersandBeleg.Owning_Obj||||||
Kunde||y|temp-db.ttUV_VersandBeleg.Konto||||||
PosObj||y|temp-db.ttUV_VersandBeleg.Owning_Obj||||||
ReferenzNr||y|temp-db.ttUV_VersandBeleg.ReferenzNr||||||
V_BelegPos_Obj||y|temp-db.ttUV_VersandBeleg.V_BelegPos_Obj||||||
PositionsNr||y|temp-db.ttUV_VersandBeleg.PositionsNr||||||
BelegArt||y|temp-db.ttUV_VersandBeleg.BelegArt||||||
Lagergruppe||y|temp-db.ttUV_VersandBeleg.Lagergruppe||||||
</FOREIGN-KEYS>
<EXECUTING-CODE>
**************************
* Set attributes related to FOREIGN KEYS
*/
run set-attribute-list (
    'Keys-Accepted = ,
     Keys-External = ,
     Keys-Supplied = "Konto,Artikel,ArtVar,ArtikelGruppe,Sparte,ArtikelArt,Wunschtermin,Liefertermin,uCI_Warenausgangstermin,Versandtermin,BelegNummer,Sachbearbeiter,AuftragsArt,LieferAdresse,AdressKennung,Abladestelle,uCI_LagerortKunde,VersandArt,LieferBedingung,Lieferant,Owning_Obj,Kunde,PosObj,ReferenzNr,V_BelegPos_Obj,PositionsNr,Belegart,Lagergruppe"':U).

/* Tell the ADM to use the OPEN-QUERY-CASES. */
&Scoped-define OPEN-QUERY-CASES run dispatch ('open-query-cases':U).

/* Define FilterDialog */
&Scoped-define PA-FilterDialog branche/vert/proc/uv_vmo00.w
/**************************
</EXECUTING-CODE> */
/* _UIB-CODE-BLOCK-END */
&ANALYZE-RESUME

&ANALYZE-SUSPEND _UIB-CODE-BLOCK _XFTR "Advanced Query Options" B-table-Win _INLINE
/* Actions: ? adm/support/proc/advqedit.w ? ? ? */
/* STRUCTURED-DATA
<KEY-OBJECT>
&BROWSE-NAME
</KEY-OBJECT>
<SORTBY-OPTIONS>
Konto|y||Temp-Tables.ttUV_VersandBeleg.Konto|yes
Konto_Suchbegriff|||Temp-Tables.ttUV_VersandBeleg.Konto_Suchbegriff|yes
Konto_Selektion|||Temp-Tables.ttUV_VersandBeleg.Konto_Selektion|yes
Konto_Branche|||Temp-Tables.ttUV_VersandBeleg.Konto_Branche|yes
Konto_Region|||Temp-Tables.ttUV_VersandBeleg.Konto_Region|yes
Belegart|||Temp-Tables.ttUV_VersandBeleg.Belegart|yes
BelegartBez|||Temp-Tables.ttUV_VersandBeleg.BelegartBez|yes
BelegNummer|||Temp-Tables.ttUV_VersandBeleg.BelegNummer|yes
BelegInfo|||Temp-Tables.ttUV_VersandBeleg.BelegInfo|yes
Auftrag|||Temp-Tables.ttUV_VersandBeleg.Auftrag|yes
Artikelgruppe|||Temp-Tables.ttUV_VersandBeleg.Artikelgruppe|yes
Artikel|||Temp-Tables.ttUV_VersandBeleg.Artikel|yes
Sparte|||Temp-Tables.ttUV_VersandBeleg.Sparte|yes
Artikel_Selektion|||Temp-Tables.ttUV_VersandBeleg.Artikel_Selektion|yes
Artikel_Suchbegriff|||Temp-Tables.ttUV_VersandBeleg.Artikel_Suchbegriff|yes
ArtikelArt|||temp-db.ttUV_VersandBeleg.ArtikelArt|yes
ArtikelNr|||temp-db.ttUV_VersandBeleg.ArtikelNr|yes
Wunschtermin|||temp-db.ttUV_VersandBeleg.Wunschtermin|yes
Liefertermin|||temp-db.ttUV_VersandBeleg.Liefertermin|yes
uCI_Warenausgangstermin|||temp-db.ttUV_VersandBeleg.uCI_Warenausgangstermin|yes
Versandtermin|||temp-db.ttUV_VersandBeleg.Versandtermin|yes
AuftragsArt|||temp-db.ttUV_VersandBeleg.AuftragsArt|yes
Versandart|||temp-db.ttUV_VersandBeleg.Versandart|yes
LieferBedingung|||temp-db.ttUV_VersandBeleg.LieferBedingung|yes
LieferRestrikt|||temp-db.ttUV_VersandBeleg.LieferRestrikt|yes
Sachbearbeiter|||temp-db.ttUV_VersandBeleg.Sachbearbeiter|yes
Lieferant|||temp-db.ttUV_VersandBeleg.Lieferant|yes
Lieferant_Suchbegriff|||temp-db.ttUV_VersandBeleg.Lieferant_Suchbegriff|yes
Lieferant_Selektion|||temp-db.ttUV_VersandBeleg.Lieferant_Selektion|yes
LieferAdresse|||temp-db.ttUV_VersandBeleg.LieferAdresse|yes
AdressKennung|||temp-db.ttUV_VersandBeleg.AdressKennung|yes
LiefAdr_Name1|||temp-db.ttUV_VersandBeleg.LiefAdr_Name1|yes
LiefAdr_PLZ|||temp-db.ttUV_VersandBeleg.LiefAdr_PLZ|yes
LiefAdr_Ort|||temp-db.ttUV_VersandBeleg.LiefAdr_Ort|yes
Abladestelle|||temp-db.ttUV_VersandBeleg.Abladestelle|yes
KO_LagerOrt|||temp-db.ttUV_VersandBeleg.KO_LagerOrt|yes
Markiert|||temp-db.ttUV_VersandBeleg.Markiert|yes
</SORTBY-OPTIONS>
<SORTBY-RUN-CODE>
************************
* Set attributes related to SORTBY-OPTIONS */
/* --> MO#HIDR-AH4-1123 thongdi_p 20.07.2026 Erweiterung Versandmonitor im Feld Best. Termin */
run set-attribute-list (
    'SortBy-Options = "xEbLiefertermin,Konto,Konto_Suchbegriff,Konto_Selektion,Konto_Branche,Konto_Region,Belegart,BelegartBez,BelegNummer,BelegInfo,Auftrag,Artikelgruppe,Artikel,Sparte,Artikel_Selektion,Artikel_Suchbegriff,ArtikelArt,ArtikelNr,Wunschtermin,Liefertermin,uCI_Warenausgangstermin,Versandtermin,AuftragsArt,Versandart,LieferBedingung,LieferRestrikt,Sachbearbeiter,Lieferant,Lieferant_Suchbegriff,Lieferant_Selektion,LieferAdresse,AdressKennung,LiefAdr_Name1,LiefAdr_PLZ,LiefAdr_Ort,Abladestelle,KO_LagerOrt,Markiert,StorageArea,CreditTerms,MRPArea",
     SortBy-Case = Konto':U).
/* <-- MO#HIDR-AH4-1123 thongdi_p 20.07.2026 Erweiterung Versandmonitor im Feld Best. Termin */
/* Tell the ADM to use the OPEN-QUERY-CASES. */
&Scoped-define OPEN-QUERY-CASES run dispatch ('open-query-cases':U).

/* set up order-direction */
&Scoped-define PA-DESCENDING-SORT NO
run set-attribute-list ('pa-SortDirectionChangeEnabled=yes':U).

/* This SmartObject is a valid SortBy-Target. */
&IF '{&USER-SUPPORTED-LINKS}':U NE '':U &THEN
  &SCOPED-DEFINE user-supported-links {&USER-SUPPORTED-LINKS},SortBy-Target
&ELSE
  &SCOPED-DEFINE user-supported-links SortBy-Target
&ENDIF

/************************
</SORTBY-RUN-CODE>
<FILTER-ATTRIBUTES>
</FILTER-ATTRIBUTES> */

/* _UIB-CODE-BLOCK-END */
&ANALYZE-RESUME

&ANALYZE-SUSPEND _UIB-CODE-BLOCK _XFTR "Find Builder" B-table-Win _INLINE
/* Actions: ? adm/support/proc/ds_sma00.w ? ? adm/support/proc/ds_fin00.p */
/* STRUCTURED-DATA
<ADDITIONAL-INFORMATION EDITABLE></ADDITIONAL-INFORMATION EDITABLE>

<GET-OFFSET-INFO>
ttUV_VersandBeleg.Konto,string(ttUV_VersandBeleg.Konto)|Konto
ttUV_VersandBeleg.Konto_Suchbegriff,ttUV_VersandBeleg.Konto_Suchbegriff|Konto_Suchbegriff
ttUV_VersandBeleg.Konto_Selektion,ttUV_VersandBeleg.Konto_Selektion|Konto_Selektion
ttUV_VersandBeleg.Konto_Branche,ttUV_VersandBeleg.Konto_Branche|Konto_Branche
ttUV_VersandBeleg.Konto_Region,ttUV_VersandBeleg.Konto_Region|Konto_Region
ttUV_VersandBeleg.Belegart,ttUV_VersandBeleg.Belegart|Belegart
ttUV_VersandBeleg.BelegartBez,ttUV_VersandBeleg.BelegartBez|BelegartBez
ttUV_VersandBeleg.BelegNummer,string(ttUV_VersandBeleg.BelegNummer)|BelegNummer
ttUV_VersandBeleg.BelegInfo,ttUV_VersandBeleg.BelegInfo|BelegInfo
ttUV_VersandBeleg.Auftrag,ttUV_VersandBeleg.Auftrag|Auftrag
ttUV_VersandBeleg.Artikelgruppe,ttUV_VersandBeleg.Artikelgruppe|Artikelgruppe
ttUV_VersandBeleg.Artikel,ttUV_VersandBeleg.Artikel|Artikel
ttUV_VersandBeleg.Sparte,ttUV_VersandBeleg.Sparte|Sparte
ttUV_VersandBeleg.Artikel_Selektion,ttUV_VersandBeleg.Artikel_Selektion|Artikel_Selektion
ttUV_VersandBeleg.Artikel_Suchbegriff,ttUV_VersandBeleg.Artikel_Suchbegriff|Artikel_Suchbegriff
ttUV_VersandBeleg.ArtikelArt,string(ttUV_VersandBeleg.ArtikelArt)|ArtikelArt
ttUV_VersandBeleg.ArtikelNr,ttUV_VersandBeleg.ArtikelNr|ArtikelNr
ttUV_VersandBeleg.Wunschtermin,string(ttUV_VersandBeleg.Wunschtermin)|Wunschtermin
ttUV_VersandBeleg.Liefertermin,string(ttUV_VersandBeleg.Liefertermin)|Liefertermin
ttUV_VersandBeleg.uCI_Warenausgangstermin,string(ttUV_VersandBeleg.uCI_Warenausgangstermin)|uCI_Warenausgangstermin
ttUV_VersandBeleg.Versandtermin,string(ttUV_VersandBeleg.Versandtermin)|Versandtermin
ttUV_VersandBeleg.AuftragsArt,ttUV_VersandBeleg.AuftragsArt|AuftragsArt
ttUV_VersandBeleg.Versandart,string(ttUV_VersandBeleg.Versandart)|Versandart
ttUV_VersandBeleg.LieferBedingung,string(ttUV_VersandBeleg.LieferBedingung)|LieferBedingung
ttUV_VersandBeleg.LieferRestrikt,string(ttUV_VersandBeleg.LieferRestrikt)|LieferRestrikt
ttUV_VersandBeleg.Sachbearbeiter,ttUV_VersandBeleg.Sachbearbeiter|Sachbearbeiter
ttUV_VersandBeleg.Lieferant,string(ttUV_VersandBeleg.Lieferant)|Lieferant
ttUV_VersandBeleg.Lieferant_Suchbegriff,ttUV_VersandBeleg.Lieferant_Suchbegriff|Lieferant_Suchbegriff
ttUV_VersandBeleg.Lieferant_Selektion,ttUV_VersandBeleg.Lieferant_Selektion|Lieferant_Selektion
ttUV_VersandBeleg.LieferAdresse,string(ttUV_VersandBeleg.LieferAdresse)|LieferAdresse
ttUV_VersandBeleg.AdressKennung,ttUV_VersandBeleg.AdressKennung|AdressKennung
ttUV_VersandBeleg.LiefAdr_Name1,ttUV_VersandBeleg.LiefAdr_Name1|LiefAdr_Name1
ttUV_VersandBeleg.LiefAdr_PLZ,ttUV_VersandBeleg.LiefAdr_PLZ|LiefAdr_PLZ
ttUV_VersandBeleg.LiefAdr_Ort,ttUV_VersandBeleg.LiefAdr_Ort|LiefAdr_Ort
ttUV_VersandBeleg.Abladestelle,ttUV_VersandBeleg.Abladestelle|Abladestelle
ttUV_VersandBeleg.KO_LagerOrt,string(ttUV_VersandBeleg.KO_LagerOrt)|KO_LagerOrt
ttUV_VersandBeleg.Markiert,string(ttUV_VersandBeleg.Markiert = true,'yes/no':U)|Markiert
ttUV_VersandBeleg.StorageArea,string(ttUV_VersandBeleg.StorageArea)|StorageArea
ttUV_VersandBeleg.CreditTerms,string(ttUV_VersandBeleg.CreditTerms)|CreditTerms
ttUV_VersandBeleg.LieferRestrikt,string(ttUV_VersandBeleg.LieferRestrikt)|Lieferrestrikt
ttUV_VersandBeleg.MRPArea,string(ttUV_VersandBeleg.MRPArea)|MRPArea
</GET-OFFSET-INFO>
<FIND-STATEMENT>
********/
/* --> MO#HIDR-AH4-1123 thongdi_p 20.07.2026 Erweiterung Versandmonitor im Feld Best. Termin */
/* add  when 'xEbLiefertermin':U then ~ */
&GLOBAL-DEFINE FIND-STATEMENT ~
case pa-sortby-case: ~
  when 'Konto':U then ~
    find ~{&FIND-OPTION} ttUV_VersandBeleg ~
      where yes  ~
      &IF DEFINED(OFFSET-VALUE) > 0 &THEN ~
        and ttUV_VersandBeleg.Konto ~{&OFFSET-COMPARE} integer(~{&OFFSET-VALUE}) ~
      &ENDIF ~
      ~{&PA-FILTER-PHRASE} ~
      use-index Konto ~
      no-lock no-error. ~
  when 'Konto_Suchbegriff':U then ~
    find ~{&FIND-OPTION} ttUV_VersandBeleg ~
      where yes  ~
      &IF DEFINED(OFFSET-VALUE) > 0 &THEN ~
        and ttUV_VersandBeleg.Konto_Suchbegriff ~{&OFFSET-COMPARE} ~{&OFFSET-VALUE} ~
      &ENDIF ~
      ~{&PA-FILTER-PHRASE} ~
      use-index Konto_Suchbegriff ~
      no-lock no-error. ~
  when 'Konto_Selektion':U then ~
    find ~{&FIND-OPTION} ttUV_VersandBeleg ~
      where yes  ~
      &IF DEFINED(OFFSET-VALUE) > 0 &THEN ~
        and ttUV_VersandBeleg.Konto_Selektion ~{&OFFSET-COMPARE} ~{&OFFSET-VALUE} ~
      &ENDIF ~
      ~{&PA-FILTER-PHRASE} ~
      use-index Konto_Selektion ~
      no-lock no-error. ~
  when 'Konto_Branche':U then ~
    find ~{&FIND-OPTION} ttUV_VersandBeleg ~
      where yes  ~
      &IF DEFINED(OFFSET-VALUE) > 0 &THEN ~
        and ttUV_VersandBeleg.Konto_Branche ~{&OFFSET-COMPARE} ~{&OFFSET-VALUE} ~
      &ENDIF ~
      ~{&PA-FILTER-PHRASE} ~
      use-index Konto_Branche ~
      no-lock no-error. ~
  when 'Konto_Region':U then ~
    find ~{&FIND-OPTION} ttUV_VersandBeleg ~
      where yes  ~
      &IF DEFINED(OFFSET-VALUE) > 0 &THEN ~
        and ttUV_VersandBeleg.Konto_Region ~{&OFFSET-COMPARE} ~{&OFFSET-VALUE} ~
      &ENDIF ~
      ~{&PA-FILTER-PHRASE} ~
      use-index Konto_Region ~
      no-lock no-error. ~
  when 'Belegart':U then ~
    find ~{&FIND-OPTION} ttUV_VersandBeleg ~
      where yes  ~
      &IF DEFINED(OFFSET-VALUE) > 0 &THEN ~
        and ttUV_VersandBeleg.Belegart ~{&OFFSET-COMPARE} ~{&OFFSET-VALUE} ~
      &ENDIF ~
      ~{&PA-FILTER-PHRASE} ~
      use-index Belegart ~
      no-lock no-error. ~
  when 'BelegartBez':U then ~
    find ~{&FIND-OPTION} ttUV_VersandBeleg ~
      where yes  ~
      &IF DEFINED(OFFSET-VALUE) > 0 &THEN ~
        and ttUV_VersandBeleg.BelegartBez ~{&OFFSET-COMPARE} ~{&OFFSET-VALUE} ~
      &ENDIF ~
      ~{&PA-FILTER-PHRASE} ~
      use-index BelegartBez ~
      no-lock no-error. ~
  when 'BelegNummer':U then ~
    find ~{&FIND-OPTION} ttUV_VersandBeleg ~
      where yes  ~
      &IF DEFINED(OFFSET-VALUE) > 0 &THEN ~
        and ttUV_VersandBeleg.BelegNummer ~{&OFFSET-COMPARE} integer(~{&OFFSET-VALUE}) ~
      &ENDIF ~
      ~{&PA-FILTER-PHRASE} ~
      use-index BelegNummer ~
      no-lock no-error. ~
  when 'BelegInfo':U then ~
    find ~{&FIND-OPTION} ttUV_VersandBeleg ~
      where yes  ~
      &IF DEFINED(OFFSET-VALUE) > 0 &THEN ~
        and ttUV_VersandBeleg.BelegInfo ~{&OFFSET-COMPARE} ~{&OFFSET-VALUE} ~
      &ENDIF ~
      ~{&PA-FILTER-PHRASE} ~
      use-index BelegInfo ~
      no-lock no-error. ~
  when 'Auftrag':U then ~
    find ~{&FIND-OPTION} ttUV_VersandBeleg ~
      where yes  ~
      &IF DEFINED(OFFSET-VALUE) > 0 &THEN ~
        and ttUV_VersandBeleg.Auftrag ~{&OFFSET-COMPARE} ~{&OFFSET-VALUE} ~
      &ENDIF ~
      ~{&PA-FILTER-PHRASE} ~
      use-index Auftrag ~
      no-lock no-error. ~
  when 'Artikelgruppe':U then ~
    find ~{&FIND-OPTION} ttUV_VersandBeleg ~
      where yes  ~
      &IF DEFINED(OFFSET-VALUE) > 0 &THEN ~
        and ttUV_VersandBeleg.Artikelgruppe ~{&OFFSET-COMPARE} ~{&OFFSET-VALUE} ~
      &ENDIF ~
      ~{&PA-FILTER-PHRASE} ~
      use-index Artikelgruppe ~
      no-lock no-error. ~
  when 'Artikel':U then ~
    find ~{&FIND-OPTION} ttUV_VersandBeleg ~
      where yes  ~
      &IF DEFINED(OFFSET-VALUE) > 0 &THEN ~
        and ttUV_VersandBeleg.Artikel ~{&OFFSET-COMPARE} ~{&OFFSET-VALUE} ~
      &ENDIF ~
      ~{&PA-FILTER-PHRASE} ~
      use-index Artikel ~
      no-lock no-error. ~
  when 'Sparte':U then ~
    find ~{&FIND-OPTION} ttUV_VersandBeleg ~
      where yes  ~
      &IF DEFINED(OFFSET-VALUE) > 0 &THEN ~
        and ttUV_VersandBeleg.Sparte ~{&OFFSET-COMPARE} ~{&OFFSET-VALUE} ~
      &ENDIF ~
      ~{&PA-FILTER-PHRASE} ~
      use-index Sparte ~
      no-lock no-error. ~
  when 'Artikel_Selektion':U then ~
    find ~{&FIND-OPTION} ttUV_VersandBeleg ~
      where yes  ~
      &IF DEFINED(OFFSET-VALUE) > 0 &THEN ~
        and ttUV_VersandBeleg.Artikel_Selektion ~{&OFFSET-COMPARE} ~{&OFFSET-VALUE} ~
      &ENDIF ~
      ~{&PA-FILTER-PHRASE} ~
      use-index Artikel_Selektion ~
      no-lock no-error. ~
  when 'Artikel_Suchbegriff':U then ~
    find ~{&FIND-OPTION} ttUV_VersandBeleg ~
      where yes  ~
      &IF DEFINED(OFFSET-VALUE) > 0 &THEN ~
        and ttUV_VersandBeleg.Artikel_Suchbegriff ~{&OFFSET-COMPARE} ~{&OFFSET-VALUE} ~
      &ENDIF ~
      ~{&PA-FILTER-PHRASE} ~
      use-index Artikel_Suchbegriff ~
      no-lock no-error. ~
  when 'ArtikelArt':U then ~
    find ~{&FIND-OPTION} ttUV_VersandBeleg ~
      where yes  ~
      &IF DEFINED(OFFSET-VALUE) > 0 &THEN ~
        and ttUV_VersandBeleg.ArtikelArt ~{&OFFSET-COMPARE} integer(~{&OFFSET-VALUE}) ~
      &ENDIF ~
      ~{&PA-FILTER-PHRASE} ~
      use-index ArtikelArt ~
      no-lock no-error. ~
  when 'ArtikelNr':U then ~
    find ~{&FIND-OPTION} ttUV_VersandBeleg ~
      where yes  ~
      &IF DEFINED(OFFSET-VALUE) > 0 &THEN ~
        and ttUV_VersandBeleg.ArtikelNr ~{&OFFSET-COMPARE} ~{&OFFSET-VALUE} ~
      &ENDIF ~
      ~{&PA-FILTER-PHRASE} ~
      use-index ArtikelNr ~
      no-lock no-error. ~
  when 'Wunschtermin':U then ~
    find ~{&FIND-OPTION} ttUV_VersandBeleg ~
      where yes  ~
      &IF DEFINED(OFFSET-VALUE) > 0 &THEN ~
        and ttUV_VersandBeleg.Wunschtermin ~{&OFFSET-COMPARE} date(~{&OFFSET-VALUE}) ~
      &ENDIF ~
      ~{&PA-FILTER-PHRASE} ~
      use-index Wunschtermin ~
      no-lock no-error. ~
  when 'Liefertermin':U then ~
    find ~{&FIND-OPTION} ttUV_VersandBeleg ~
      where yes  ~
      &IF DEFINED(OFFSET-VALUE) > 0 &THEN ~
        and ttUV_VersandBeleg.Liefertermin ~{&OFFSET-COMPARE} date(~{&OFFSET-VALUE}) ~
      &ENDIF ~
      ~{&PA-FILTER-PHRASE} ~
      use-index Liefertermin ~
      no-lock no-error. ~
  when 'xEbLiefertermin':U then ~
    find ~{&FIND-OPTION} ttUV_VersandBeleg ~
      where yes  ~
      &IF DEFINED(OFFSET-VALUE) > 0 &THEN ~
        and ttUV_VersandBeleg.xEbLiefertermin ~{&OFFSET-COMPARE} date(~{&OFFSET-VALUE}) ~
      &ENDIF ~
      ~{&PA-FILTER-PHRASE} ~
      use-index xEbLiefertermin ~
      no-lock no-error. ~
  when 'uCI_Warenausgangstermin':U then ~
    find ~{&FIND-OPTION} ttUV_VersandBeleg ~
      where yes  ~
      &IF DEFINED(OFFSET-VALUE) > 0 &THEN ~
        and ttUV_VersandBeleg.uCI_Warenausgangstermin ~{&OFFSET-COMPARE} date(~{&OFFSET-VALUE}) ~
      &ENDIF ~
      ~{&PA-FILTER-PHRASE} ~
      use-index uCI_Warenausgangstermin ~
      no-lock no-error. ~
  when 'Versandtermin':U then ~
    find ~{&FIND-OPTION} ttUV_VersandBeleg ~
      where yes  ~
      &IF DEFINED(OFFSET-VALUE) > 0 &THEN ~
        and ttUV_VersandBeleg.Versandtermin ~{&OFFSET-COMPARE} date(~{&OFFSET-VALUE}) ~
      &ENDIF ~
      ~{&PA-FILTER-PHRASE} ~
      use-index Versandtermin ~
      no-lock no-error. ~
  when 'AuftragsArt':U then ~
    find ~{&FIND-OPTION} ttUV_VersandBeleg ~
      where yes  ~
      &IF DEFINED(OFFSET-VALUE) > 0 &THEN ~
        and ttUV_VersandBeleg.AuftragsArt ~{&OFFSET-COMPARE} ~{&OFFSET-VALUE} ~
      &ENDIF ~
      ~{&PA-FILTER-PHRASE} ~
      use-index AuftragsArt ~
      no-lock no-error. ~
  when 'Versandart':U then ~
    find ~{&FIND-OPTION} ttUV_VersandBeleg ~
      where yes  ~
      &IF DEFINED(OFFSET-VALUE) > 0 &THEN ~
        and ttUV_VersandBeleg.Versandart ~{&OFFSET-COMPARE} integer(~{&OFFSET-VALUE}) ~
      &ENDIF ~
      ~{&PA-FILTER-PHRASE} ~
      use-index Versandart ~
      no-lock no-error. ~
  when 'LieferBedingung':U then ~
    find ~{&FIND-OPTION} ttUV_VersandBeleg ~
      where yes  ~
      &IF DEFINED(OFFSET-VALUE) > 0 &THEN ~
        and ttUV_VersandBeleg.LieferBedingung ~{&OFFSET-COMPARE} integer(~{&OFFSET-VALUE}) ~
      &ENDIF ~
      ~{&PA-FILTER-PHRASE} ~
      use-index LieferBedingung ~
      no-lock no-error. ~
  when 'LieferRestrikt':U then ~
    find ~{&FIND-OPTION} ttUV_VersandBeleg ~
      where yes  ~
      &IF DEFINED(OFFSET-VALUE) > 0 &THEN ~
        and ttUV_VersandBeleg.LieferRestrikt ~{&OFFSET-COMPARE} integer(~{&OFFSET-VALUE}) ~
      &ENDIF ~
      ~{&PA-FILTER-PHRASE} ~
      use-index LieferRestrikt ~
      no-lock no-error. ~
  when 'Sachbearbeiter':U then ~
    find ~{&FIND-OPTION} ttUV_VersandBeleg ~
      where yes  ~
      &IF DEFINED(OFFSET-VALUE) > 0 &THEN ~
        and ttUV_VersandBeleg.Sachbearbeiter ~{&OFFSET-COMPARE} ~{&OFFSET-VALUE} ~
      &ENDIF ~
      ~{&PA-FILTER-PHRASE} ~
      use-index Sachbearbeiter ~
      no-lock no-error. ~
  when 'Lieferant':U then ~
    find ~{&FIND-OPTION} ttUV_VersandBeleg ~
      where yes  ~
      &IF DEFINED(OFFSET-VALUE) > 0 &THEN ~
        and ttUV_VersandBeleg.Lieferant ~{&OFFSET-COMPARE} integer(~{&OFFSET-VALUE}) ~
      &ENDIF ~
      ~{&PA-FILTER-PHRASE} ~
      use-index Lieferant ~
      no-lock no-error. ~
  when 'Lieferant_Suchbegriff':U then ~
    find ~{&FIND-OPTION} ttUV_VersandBeleg ~
      where yes  ~
      &IF DEFINED(OFFSET-VALUE) > 0 &THEN ~
        and ttUV_VersandBeleg.Lieferant_Suchbegriff ~{&OFFSET-COMPARE} ~{&OFFSET-VALUE} ~
      &ENDIF ~
      ~{&PA-FILTER-PHRASE} ~
      use-index Lieferant_Suchbegriff ~
      no-lock no-error. ~
  when 'Lieferant_Selektion':U then ~
    find ~{&FIND-OPTION} ttUV_VersandBeleg ~
      where yes  ~
      &IF DEFINED(OFFSET-VALUE) > 0 &THEN ~
        and ttUV_VersandBeleg.Lieferant_Selektion ~{&OFFSET-COMPARE} ~{&OFFSET-VALUE} ~
      &ENDIF ~
      ~{&PA-FILTER-PHRASE} ~
      use-index Lieferant_Selektion ~
      no-lock no-error. ~
  when 'LieferAdresse':U then ~
    find ~{&FIND-OPTION} ttUV_VersandBeleg ~
      where yes  ~
      &IF DEFINED(OFFSET-VALUE) > 0 &THEN ~
        and ttUV_VersandBeleg.LieferAdresse ~{&OFFSET-COMPARE} integer(~{&OFFSET-VALUE}) ~
      &ENDIF ~
      ~{&PA-FILTER-PHRASE} ~
      use-index LieferAdresse ~
      no-lock no-error. ~
  when 'AdressKennung':U then ~
    find ~{&FIND-OPTION} ttUV_VersandBeleg ~
      where yes  ~
      &IF DEFINED(OFFSET-VALUE) > 0 &THEN ~
        and ttUV_VersandBeleg.AdressKennung ~{&OFFSET-COMPARE} ~{&OFFSET-VALUE} ~
      &ENDIF ~
      ~{&PA-FILTER-PHRASE} ~
      use-index AdressKennung ~
      no-lock no-error. ~
  when 'LiefAdr_Name1':U then ~
    find ~{&FIND-OPTION} ttUV_VersandBeleg ~
      where yes  ~
      &IF DEFINED(OFFSET-VALUE) > 0 &THEN ~
        and ttUV_VersandBeleg.LiefAdr_Name1 ~{&OFFSET-COMPARE} ~{&OFFSET-VALUE} ~
      &ENDIF ~
      ~{&PA-FILTER-PHRASE} ~
      use-index LiefAdr_Name1 ~
      no-lock no-error. ~
  when 'LiefAdr_PLZ':U then ~
    find ~{&FIND-OPTION} ttUV_VersandBeleg ~
      where yes  ~
      &IF DEFINED(OFFSET-VALUE) > 0 &THEN ~
        and ttUV_VersandBeleg.LiefAdr_PLZ ~{&OFFSET-COMPARE} ~{&OFFSET-VALUE} ~
      &ENDIF ~
      ~{&PA-FILTER-PHRASE} ~
      use-index LiefAdr_PLZ ~
      no-lock no-error. ~
  when 'LiefAdr_Ort':U then ~
    find ~{&FIND-OPTION} ttUV_VersandBeleg ~
      where yes  ~
      &IF DEFINED(OFFSET-VALUE) > 0 &THEN ~
        and ttUV_VersandBeleg.LiefAdr_Ort ~{&OFFSET-COMPARE} ~{&OFFSET-VALUE} ~
      &ENDIF ~
      ~{&PA-FILTER-PHRASE} ~
      use-index LiefAdr_Ort ~
      no-lock no-error. ~
  when 'Abladestelle':U then ~
    find ~{&FIND-OPTION} ttUV_VersandBeleg ~
      where yes  ~
      &IF DEFINED(OFFSET-VALUE) > 0 &THEN ~
        and ttUV_VersandBeleg.Abladestelle ~{&OFFSET-COMPARE} ~{&OFFSET-VALUE} ~
      &ENDIF ~
      ~{&PA-FILTER-PHRASE} ~
      use-index Abladestelle ~
      no-lock no-error. ~
  when 'KO_LagerOrt':U then ~
    find ~{&FIND-OPTION} ttUV_VersandBeleg ~
      where yes  ~
      &IF DEFINED(OFFSET-VALUE) > 0 &THEN ~
        and ttUV_VersandBeleg.KO_LagerOrt ~{&OFFSET-COMPARE} integer(~{&OFFSET-VALUE}) ~
      &ENDIF ~
      ~{&PA-FILTER-PHRASE} ~
      use-index KO_LagerOrt ~
      no-lock no-error. ~
  when 'Markiert':U then ~
    find ~{&FIND-OPTION} ttUV_VersandBeleg ~
      where yes  ~
      &IF DEFINED(OFFSET-VALUE) > 0 &THEN ~
        and ttUV_VersandBeleg.Markiert ~{&OFFSET-COMPARE} can-do('true,yes':U,~{&OFFSET-VALUE}) ~
      &ENDIF ~
      ~{&PA-FILTER-PHRASE} ~
      use-index Markiert ~
      no-lock no-error. ~
  when 'StorageArea':U then ~
    find ~{&FIND-OPTION} ttUV_VersandBeleg ~
      where yes  ~
      &IF DEFINED(OFFSET-VALUE) > 0 &THEN ~
        and ttUV_VersandBeleg.StorageArea ~{&OFFSET-COMPARE} integer(~{&OFFSET-VALUE}) ~
      &ENDIF ~
      ~{&PA-FILTER-PHRASE} ~
      use-index StorageArea ~
      no-lock no-error. ~
  when 'CreditTerms':U then ~
    find ~{&FIND-OPTION} ttUV_VersandBeleg ~
      where yes  ~
      &IF DEFINED(OFFSET-VALUE) > 0 &THEN ~
        and ttUV_VersandBeleg.CreditTerms ~{&OFFSET-COMPARE} integer(~{&OFFSET-VALUE}) ~
      &ENDIF ~
      ~{&PA-FILTER-PHRASE} ~
      use-index CreditTerms ~
      no-lock no-error. ~
  when 'MRPArea':U then ~
    find ~{&FIND-OPTION} ttUV_VersandBeleg ~
      where yes  ~
      &IF DEFINED(OFFSET-VALUE) > 0 &THEN ~
        and ttUV_VersandBeleg.MRPArea ~{&OFFSET-COMPARE} integer(~{&OFFSET-VALUE}) ~
      &ENDIF ~
      ~{&PA-FILTER-PHRASE} ~
      use-index MRPArea ~
      no-lock no-error. ~
  {&{&PA-XBASISNAME}_C_FindStatement} ~
  {&{&PA-XBASISNAME}_U_FindStatement} ~
  {&{&PA-XBASISNAME}_Q_FindStatement} ~
  {&{&PA-XBASISNAME}_FindStatement} ~
  {&{&PA-XBASISNAME}_Y_FindStatement} ~
  ~{adm/template/incl/dt_vbs13.if &ippSortCaseName = "pa-sortby-case"}~
  end case.
/* <-- MO#HIDR-AH4-1123 thongdi_p 20.07.2026 Erweiterung Versandmonitor im Feld Best. Termin */

define variable pa-FilterValues as char no-undo.
define variable pa-filter-Konto_min like ttUV_VersandBeleg.Konto no-undo init ?.
define variable pa-filter-Konto_max like ttUV_VersandBeleg.Konto no-undo init ?.
define variable pa-filter-Artikel_min like ttUV_VersandBeleg.Artikel no-undo init ?.
define variable pa-filter-Artikel_max like ttUV_VersandBeleg.Artikel no-undo init ?.
define variable pa-filter-ArtikelGruppe_min like ttUV_VersandBeleg.ArtikelGruppe no-undo init ?.
define variable pa-filter-ArtikelGruppe_max like ttUV_VersandBeleg.ArtikelGruppe no-undo init ?.
define variable pa-filter-Sparte_min like ttUV_VersandBeleg.Sparte no-undo init ?.
define variable pa-filter-Sparte_max like ttUV_VersandBeleg.Sparte no-undo init ?.
define variable pa-filter-ArtikelArt_min like ttUV_VersandBeleg.ArtikelArt no-undo init ?.
define variable pa-filter-ArtikelArt_max like ttUV_VersandBeleg.ArtikelArt no-undo init ?.
define variable pa-filter-Wunschtermin_min like ttUV_VersandBeleg.Wunschtermin no-undo init ?.
define variable pa-filter-Wunschtermin_max like ttUV_VersandBeleg.Wunschtermin no-undo init ?.
define variable pa-filter-Liefertermin_min like ttUV_VersandBeleg.Liefertermin no-undo init ?.
define variable pa-filter-Liefertermin_max like ttUV_VersandBeleg.Liefertermin no-undo init ?.
define variable pa-filter-uCI_Warenausgangst_min like ttUV_VersandBeleg.uCI_Warenausgangstermin no-undo init ?.
define variable pa-filter-uCI_Warenausgangst_max like ttUV_VersandBeleg.uCI_Warenausgangstermin no-undo init ?.
define variable pa-filter-Versandtermin_min like ttUV_VersandBeleg.Versandtermin no-undo init ?.
define variable pa-filter-Versandtermin_max like ttUV_VersandBeleg.Versandtermin no-undo init ?.
define variable pa-filter-BelegNummer_min like ttUV_VersandBeleg.BelegNummer no-undo init ?.
define variable pa-filter-BelegNummer_max like ttUV_VersandBeleg.BelegNummer no-undo init ?.
define variable pa-filter-Sachbearbeiter_min like ttUV_VersandBeleg.Sachbearbeiter no-undo init ?.
define variable pa-filter-Sachbearbeiter_max like ttUV_VersandBeleg.Sachbearbeiter no-undo init ?.
define variable pa-filter-AuftragsArt_min like ttUV_VersandBeleg.AuftragsArt no-undo init ?.
define variable pa-filter-AuftragsArt_max like ttUV_VersandBeleg.AuftragsArt no-undo init ?.
define variable pa-filter-LieferAdresse_min like ttUV_VersandBeleg.LieferAdresse no-undo init ?.
define variable pa-filter-LieferAdresse_max like ttUV_VersandBeleg.LieferAdresse no-undo init ?.
define variable pa-filter-AdressKennung_min like ttUV_VersandBeleg.AdressKennung no-undo init ?.
define variable pa-filter-AdressKennung_max like ttUV_VersandBeleg.AdressKennung no-undo init ?.
define variable pa-filter-Abladestelle_min like ttUV_VersandBeleg.Abladestelle no-undo init ?.
define variable pa-filter-Abladestelle_max like ttUV_VersandBeleg.Abladestelle no-undo init ?.
define variable pa-filter-uCI_LagerortKunde_min like ttUV_VersandBeleg.uCI_LagerortKunde no-undo init ?.
define variable pa-filter-uCI_LagerortKunde_max like ttUV_VersandBeleg.uCI_LagerortKunde no-undo init ?.
define variable pa-filter-VersandArt_min like ttUV_VersandBeleg.VersandArt no-undo init ?.
define variable pa-filter-VersandArt_max like ttUV_VersandBeleg.VersandArt no-undo init ?.
define variable pa-filter-LieferBedingung_min like ttUV_VersandBeleg.LieferBedingung no-undo init ?.
define variable pa-filter-LieferBedingung_max like ttUV_VersandBeleg.LieferBedingung no-undo init ?.
define variable pa-filter-Lieferant_min like ttUV_VersandBeleg.Lieferant no-undo init ?.
define variable pa-filter-Lieferant_max like ttUV_VersandBeleg.Lieferant no-undo init ?.
define variable pa-filter-StorageArea_min         like ttUV_VersandBeleg.StorageArea    no-undo init ?.
define variable pa-filter-StorageArea_max         like ttUV_VersandBeleg.StorageArea    no-undo init ?.
define variable pa-filter-CreditTerms_min         like ttUV_VersandBeleg.CreditTerms    no-undo init ?.
define variable pa-filter-CreditTerms_max         like ttUV_VersandBeleg.CreditTerms    no-undo init ?.
define variable pa-Filter-DeliveryRestriction_min like ttUV_VersandBeleg.LieferRestrikt no-undo init ?.
define variable pa-Filter-DeliveryRestriction_max like ttUV_VersandBeleg.LieferRestrikt no-undo init ?.
define variable pa-filter-MRPArea_min             like ttUV_VersandBeleg.MRPArea        no-undo init ?.
define variable pa-filter-MRPArea_max             like ttUV_VersandBeleg.MRPArea        no-undo init ?.

&SCOP PA-FILTER-PHRASE ~
and ttUV_VersandBeleg.Konto >= pa-filter-Konto_min ~
and ttUV_VersandBeleg.Konto <= pa-filter-Konto_max ~
and ttUV_VersandBeleg.Artikel >= pa-filter-Artikel_min ~
and ttUV_VersandBeleg.Artikel <= pa-filter-Artikel_max ~
and ttUV_VersandBeleg.ArtikelGruppe >= pa-filter-ArtikelGruppe_min ~
and ttUV_VersandBeleg.ArtikelGruppe <= pa-filter-ArtikelGruppe_max ~
and ttUV_VersandBeleg.Sparte >= pa-filter-Sparte_min ~
and ttUV_VersandBeleg.Sparte <= pa-filter-Sparte_max ~
and ttUV_VersandBeleg.ArtikelArt >= pa-filter-ArtikelArt_min ~
and ttUV_VersandBeleg.ArtikelArt <= pa-filter-ArtikelArt_max ~
and ttUV_VersandBeleg.Wunschtermin >= pa-filter-Wunschtermin_min ~
and ttUV_VersandBeleg.Wunschtermin <= pa-filter-Wunschtermin_max ~
and ttUV_VersandBeleg.Liefertermin >= pa-filter-Liefertermin_min ~
and ttUV_VersandBeleg.Liefertermin <= pa-filter-Liefertermin_max ~
and ttUV_VersandBeleg.uCI_Warenausgangstermin >= pa-filter-uCI_Warenausgangst_min ~
and ttUV_VersandBeleg.uCI_Warenausgangstermin <= pa-filter-uCI_Warenausgangst_max ~
and ttUV_VersandBeleg.Versandtermin >= pa-filter-Versandtermin_min ~
and ttUV_VersandBeleg.Versandtermin <= pa-filter-Versandtermin_max ~
and ttUV_VersandBeleg.BelegNummer >= pa-filter-BelegNummer_min ~
and ttUV_VersandBeleg.BelegNummer <= pa-filter-BelegNummer_max ~
and ttUV_VersandBeleg.Sachbearbeiter >= pa-filter-Sachbearbeiter_min ~
and ttUV_VersandBeleg.Sachbearbeiter <= pa-filter-Sachbearbeiter_max ~
and ttUV_VersandBeleg.AuftragsArt >= pa-filter-AuftragsArt_min ~
and ttUV_VersandBeleg.AuftragsArt <= pa-filter-AuftragsArt_max ~
and ttUV_VersandBeleg.LieferAdresse >= pa-filter-LieferAdresse_min ~
and ttUV_VersandBeleg.LieferAdresse <= pa-filter-LieferAdresse_max ~
and ttUV_VersandBeleg.AdressKennung >= pa-filter-AdressKennung_min ~
and ttUV_VersandBeleg.AdressKennung <= pa-filter-AdressKennung_max ~
and ttUV_VersandBeleg.Abladestelle >= pa-filter-Abladestelle_min ~
and ttUV_VersandBeleg.Abladestelle <= pa-filter-Abladestelle_max ~
and ttUV_VersandBeleg.uCI_LagerortKunde >= pa-filter-uCI_LagerortKunde_min ~
and ttUV_VersandBeleg.uCI_LagerortKunde <= pa-filter-uCI_LagerortKunde_max ~
and ttUV_VersandBeleg.VersandArt >= pa-filter-VersandArt_min ~
and ttUV_VersandBeleg.VersandArt <= pa-filter-VersandArt_max ~
and ttUV_VersandBeleg.LieferBedingung >= pa-filter-LieferBedingung_min ~
and ttUV_VersandBeleg.LieferBedingung <= pa-filter-LieferBedingung_max ~
and ttUV_VersandBeleg.Lieferant >= pa-filter-Lieferant_min ~
and ttUV_VersandBeleg.Lieferant <= pa-filter-Lieferant_max ~
and ttUV_VersandBeleg.StorageArea >= pa-filter-StorageArea_min ~
and ttUV_VersandBeleg.StorageArea <= pa-filter-StorageArea_max ~
and ttUV_VersandBeleg.CreditTerms >= pa-filter-CreditTerms_min ~
and ttUV_VersandBeleg.CreditTerms <= pa-filter-CreditTerms_max ~
and ttUV_VersandBeleg.LieferRestrikt >= pa-filter-DeliveryRestriction_min ~
and ttUV_VersandBeleg.LieferRestrikt <= pa-filter-DeliveryRestriction_max ~
and ttUV_VersandBeleg.MRPArea >= pa-filter-MRPArea_min ~
and ttUV_VersandBeleg.MRPArea <= pa-filter-MRPArea_max ~
and ttUV_VersandBeleg.xEbLiefertermin >= pa-filter-xEbLiefertermin_min ~
and ttUV_VersandBeleg.xEbLiefertermin <= pa-filter-xEbLiefertermin_max        

&SCOP INTERNAL-TABLES {&INTERNAL-TABLES} V_BelegKopf VS_Auftrag
/********
</FIND-STATEMENT>  */
/* _UIB-CODE-BLOCK-END */
&ANALYZE-RESUME

&ANALYZE-SUSPEND _UIB-CODE-BLOCK _XFTR "Find-Trigger" B-table-Win _INLINE
/* Actions: ? adm/support/proc/ds_sma00.w ? ? ? */



/* ************************  Function Implementations ***************** */
FUNCTION find-additional-records returns CHARACTER ( ) :

assign
  gcTransTimeUnitDesc = '':U
  gcKommTimeUnitDesc  = '':U
  gcCoverageStatus    = '':U
  .

if available ttUV_VersandBeleg then do:

  find V_BelegKopf
    where V_BelegKopf.Firma      = {firma/vbelegko.fir pACConnectionSvc:prpcCompany}
      and V_BelegKopf.BelegArt   = ttUV_VersandBeleg.Belegart
      and V_BelegKopf.ReferenzNr = ttUV_VersandBeleg.ReferenzNr
    no-lock no-error.

  /* Variablen mit den Bezeichnungen gesondert behandeln. F�r den Fall, dass bei             */
  /* der Belegbearbeitung irgendetwas nicht stimmt oder stimmte. Z. Bsp. eine Zeiteinheit,   */
  /* die es nicht gibt. Damit wird erst einmal der Laufzeitfehler, der entstehen k�nnte,     */
  /* unterbunden. Den Rest muss man sich gesondert anschauen, wie es zu dieser Unstimmigkeit */
  /* kommen kann. Als Bezeichnungen wird dann <blank> angezeigt.                             */ 

  gcTransTimeUnitDesc = entry(lookup(ttUV_VersandBeleg.Zeiteinheit, gcSB_TimeUnits_keys), gcSB_TimeUnits_desc) no-error.

  if error-status:error then
    gcTransTimeUnitDesc = '':U.

  gcKommTimeUnitDesc = entry(lookup(ttUV_VersandBeleg.uCI_KommZeiteinheit, gcSB_TimeUnits_keys), gcSB_TimeUnits_desc) no-error.

  if error-status:error then
    gcKommTimeUnitDesc = '':U.

  gcCoverageStatus = entry(lookup(string(ttUV_VersandBeleg.CoverageStatus), gcUCI_CoverageStatus_Keys), gcUCI_CoverageStatus_Desc, '|':U) no-error.  

  if error-status:error then
    gcCoverageStatus = '':U.

  assign
    gcKontoName         = ttUV_VersandBeleg.Konto_Name1 + ' ':U + ttUV_VersandBeleg.Konto_Name2 + ' ':U + ttUV_VersandBeleg.Konto_Name3
    gcAbladestelleBez   = ttUV_VersandBeleg.AbladestelleBez[1] + ' ':U + ttUV_VersandBeleg.AbladestelleBez[2] + ' ':U + ttUV_VersandBeleg.AbladestelleBez[3] + ttUV_VersandBeleg.AbladestelleBez[4]
    gcArtikelBez        = ttUV_VersandBeleg.ArtikelBez[1] + ' ':U + ttUV_VersandBeleg.ArtikelBez[2] + ' ':U + ttUV_VersandBeleg.ArtikelBez[3] + ' ':U + ttUV_VersandBeleg.ArtikelBez[4]
    gcArtikelNrBez      = ttUV_VersandBeleg.ArtikelNrBez[1] + ' ':U + ttUV_VersandBeleg.ArtikelNrBez[2] + ' ':U + ttUV_VersandBeleg.ArtikelNrBez[3] + ' ':U + ttUV_VersandBeleg.ArtikelNrBez[4]
    gcLieferantName     = ttUV_VersandBeleg.Lieferant_Name1 + ' ':U + ttUV_VersandBeleg.Lieferant_Name2 + ' ':U + ttUV_VersandBeleg.Lieferant_Name3
    gcLiefAdr_Name      = ttUV_VersandBeleg.LiefAdr_Name1 + ' ':U + ttUV_VersandBeleg.LiefAdr_Name2 + ' ':U + ttUV_VersandBeleg.LiefAdr_Name3
    .

/* --> AJa Versandmonitor war nicht mehr AppBuilder-konform */
/* Saving in AppBuilder generates PA-FILTER-PHRASE. We don't want that, we    */
/* just want to use the pa-filter-*-variables to set the database properties. */
&undefine PA-FILTER-PHRASE

/* Saving in AppBuilder generates the line */
/* &SCOP INTERNAL-TABLES {&INTERNAL-TABLES} V_BelegKopf */
&undefine      INTERNAL-TABLES
&GLOBAL-DEFINE INTERNAL-TABLES ttUV_VersandBeleg
/* <-- AJa Versandmonitor war nicht mehr AppBuilder-konform */

  {&{&PA-XBASISNAME}_C_FIND-TRIGGER_FIND}
  {&{&PA-XBASISNAME}_U_FIND-TRIGGER_FIND}
  {&{&PA-XBASISNAME}_FIND-TRIGGER_FIND}
  {&{&PA-XBASISNAME}_Y_FIND-TRIGGER_FIND}

  return gcCoverageStatus.
end.

else do:

  release V_BelegKopf.

  {&{&PA-XBASISNAME}_C_FIND-TRIGGER_RELEASE}
  {&{&PA-XBASISNAME}_U_FIND-TRIGGER_RELEASE}
  {&{&PA-XBASISNAME}_FIND-TRIGGER_RELEASE}
  {&{&PA-XBASISNAME}_Y_FIND-TRIGGER_RELEASE}

  return ?.
end.
END FUNCTION.

&SCOP PA-FIND-DUMMY YES

/* _UIB-CODE-BLOCK-END */
&ANALYZE-RESUME

&ANALYZE-SUSPEND _UIB-CODE-BLOCK _XFTR "Window Title" B-table-Win _INLINE
/* Actions: ? adm/support/proc/ds_sma00.w ? ? adm/support/proc/ds_ttl00.p */
/* STRUCTURED-DATA
<TITLE-CODE EDITABLE>
' ':U ~
+ string(GCWINDOWTITLE) ~
+ ' ':U
</TITLE-CODE EDITABLE>
<CONSTANTS>
**/
&SCOP PA-TITLE-CODE ~
' ':U ~ ~
+ string(GCWINDOWTITLE) ~ ~
+ ' ':U
/**
</CONSTANTS>  */
/* _UIB-CODE-BLOCK-END */
&ANALYZE-RESUME

&ANALYZE-SUSPEND _UIB-CODE-BLOCK _XFTR "Skin Client Support" B-table-Win _INLINE
/* Actions: ? ? ? ? adm/support/proc/ds_skc00.p */
/* _UIB-CODE-BLOCK-END */
&ANALYZE-RESUME

/* ************************  Function Prototypes ********************** */

&ANALYZE-SUSPEND _UIB-CODE-BLOCK _FUNCTION-FORWARD pa_lUISvcObjectState B-table-Win 
FUNCTION pa_lUISvcObjectState returns logical
  ( pcStateCode as character ) FORWARD.

/* _UIB-CODE-BLOCK-END */
&ANALYZE-RESUME


/* ***********************  Control Definitions  ********************** */


/* Menu Definitions                                                     */
DEFINE MENU POPUP-MENU-gcSuche 
       MENU-ITEM mi_Suche_nach_Kunden-Teilenumme LABEL "Suche nach Kunden-&Teilenummer":T40
              TOGGLE-BOX
       MENU-ITEM mi_Suche_nach_EAN-Nummer LABEL "Suche nach GTIN":T40
              TOGGLE-BOX
       MENU-ITEM mi_Suche_nach_Suchbegriff LABEL "Suche nach &Suchbegriff":T40
              TOGGLE-BOX
       MENU-ITEM mi_Suche_nach_Selektion LABEL "Suche nach Sele&ktion":T40
              TOGGLE-BOX
       MENU-ITEM mi_Suche_nach_SortierBez LABEL "Suche nach S&ortierbezeichnung":T40
              TOGGLE-BOX.


/* Definitions of the field level widgets                               */
DEFINE VARIABLE gcAbladestelle LIKE ttUV_VersandBeleg.Abladestelle
     VIEW-AS FILL-IN 
     SIZE 18.67 BY 1 NO-UNDO.

DEFINE VARIABLE gcAdressKennung LIKE ttUV_VersandBeleg.AdressKennung
     VIEW-AS FILL-IN 
     SIZE 21.67 BY 1 NO-UNDO.

DEFINE VARIABLE gcArtikel LIKE ttUV_VersandBeleg.Artikel
     VIEW-AS FILL-IN 
     SIZE 24.5 BY 1 NO-UNDO.

DEFINE VARIABLE gcGesamtwert AS CHARACTER FORMAT "X(25)":U INITIAL "Gesamtwert verf�gbar":T50 
     VIEW-AS FILL-IN 
     SIZE 22 BY 1 NO-UNDO.

DEFINE VARIABLE gcGesamtwert_offen AS CHARACTER FORMAT "X(25)":U INITIAL "Gesamtwert offen":T50 
     VIEW-AS FILL-IN 
     SIZE 22 BY 1 NO-UNDO.

DEFINE VARIABLE gcKonto_Name1 LIKE S_Adresse.Name1
     VIEW-AS FILL-IN 
     SIZE 36.67 BY 1 NO-UNDO.

DEFINE VARIABLE gcKonto_Name2 LIKE S_Adresse.Name2
     VIEW-AS FILL-IN 
     SIZE 36.67 BY 1 NO-UNDO.

DEFINE VARIABLE gcKonto_Ort LIKE S_Adresse.Ort
     VIEW-AS FILL-IN 
     SIZE 31.67 BY 1 NO-UNDO.

DEFINE VARIABLE gcKonto_Strasse LIKE S_Adresse.Strasse
     VIEW-AS FILL-IN 
     SIZE 31.67 BY 1 NO-UNDO.

DEFINE VARIABLE gcLieferant_Name1 LIKE S_Adresse.Name1
     VIEW-AS FILL-IN 
     SIZE 36.67 BY 1 NO-UNDO.

DEFINE VARIABLE gcLieferant_Name2 LIKE S_Adresse.Name2
     VIEW-AS FILL-IN 
     SIZE 36.67 BY 1 NO-UNDO.

DEFINE VARIABLE gcLieferant_Ort LIKE S_Adresse.Ort
     VIEW-AS FILL-IN 
     SIZE 31.67 BY 1 NO-UNDO.

DEFINE VARIABLE gcLieferant_Strasse LIKE S_Adresse.Strasse
     VIEW-AS FILL-IN 
     SIZE 31.67 BY 1 NO-UNDO.

DEFINE VARIABLE gcSuche AS CHARACTER FORMAT "X(256)":U 
     VIEW-AS FILL-IN 
     SIZE 24.5 BY 1 NO-UNDO.

DEFINE VARIABLE gcuCI_LagerortKunde LIKE ttUV_VersandBeleg.uCI_LagerortKunde
     VIEW-AS FILL-IN 
     SIZE 13.17 BY 1 NO-UNDO.

DEFINE VARIABLE gdGesamtwert_Alle AS DECIMAL FORMAT "-zzz,zzz,zz9.999":U INITIAL 0 
     LABEL "alle":R18
     VIEW-AS FILL-IN 
     SIZE 22 BY 1 NO-UNDO.

DEFINE VARIABLE gdGesamtwert_Markiert AS DECIMAL FORMAT "-zzz,zzz,zz9.999":U INITIAL 0 
     LABEL "markiert":R18 
     VIEW-AS FILL-IN 
     SIZE 22 BY 1 NO-UNDO.

DEFINE VARIABLE gdGesamtwert_offen_alle AS DECIMAL FORMAT "-zzz,zzz,zz9.999":U INITIAL 0 
     VIEW-AS FILL-IN 
     SIZE 22 BY 1 NO-UNDO.

DEFINE VARIABLE gdGesamtwert_offen_Markiert AS DECIMAL FORMAT "-zzz,zzz,zz9.999":U INITIAL 0 
     VIEW-AS FILL-IN 
     SIZE 22 BY 1 NO-UNDO.

DEFINE VARIABLE giKonto LIKE ttUV_VersandBeleg.Konto
     VIEW-AS FILL-IN 
     SIZE 9.67 BY 1 NO-UNDO.

DEFINE VARIABLE giLieferadresse LIKE ttUV_VersandBeleg.LieferAdresse
     VIEW-AS FILL-IN 
     SIZE 4.67 BY 1 NO-UNDO.

DEFINE VARIABLE giLieferant LIKE ttUV_VersandBeleg.Lieferant
     VIEW-AS FILL-IN 
     SIZE 9.67 BY 1 NO-UNDO.

DEFINE VARIABLE giVersandArt LIKE ttUV_VersandBeleg.Versandart
     VIEW-AS FILL-IN 
     SIZE 4.67 BY 1 NO-UNDO.

DEFINE VARIABLE gtuCI_Warenausgangstermin_max AS DATE FORMAT "99.99.9999":U 
     VIEW-AS FILL-IN 
     SIZE 12 BY 1 NO-UNDO.

DEFINE VARIABLE gtuCI_Warenausgangstermin_min AS DATE FORMAT "99.99.9999":U 
     LABEL "Versandtermin":R18 
     VIEW-AS FILL-IN 
     SIZE 12 BY 1 NO-UNDO.

DEFINE VARIABLE gtVersandtermin_max AS DATE FORMAT "99.99.9999":U 
     VIEW-AS FILL-IN 
     SIZE 12 BY 1 NO-UNDO.

DEFINE VARIABLE gtVersandtermin_min AS DATE FORMAT "99.99.9999":U 
     LABEL "Bereitstelltermin":R18 
     VIEW-AS FILL-IN 
     SIZE 12 BY 1 NO-UNDO.

DEFINE VARIABLE glBelegartPPF AS LOGICAL INITIAL yes 
     LABEL "Fremdarbeit Produktion":L25 
     VIEW-AS TOGGLE-BOX
     SIZE 25 BY .79 NO-UNDO.

DEFINE VARIABLE glBelegartU AS LOGICAL INITIAL yes 
     LABEL "Auftrag":L18 
     VIEW-AS TOGGLE-BOX
     SIZE 20 BY .79 NO-UNDO.

DEFINE VARIABLE glBelegartVUA AS LOGICAL INITIAL yes 
     LABEL "Abrufauftrag":L18 
     VIEW-AS TOGGLE-BOX
     SIZE 20 BY .79 NO-UNDO.

DEFINE VARIABLE glDocTypeServiceOrder AS LOGICAL INITIAL yes 
     LABEL "Serviceauftrag":L18 
     VIEW-AS TOGGLE-BOX
     SIZE 20 BY .79 NO-UNDO.

DEFINE VARIABLE glDocTypeRepairOrder AS LOGICAL INITIAL yes 
     LABEL "Reparaturauftrag":L18 
     VIEW-AS TOGGLE-BOX
     SIZE 20 BY .79 NO-UNDO.

DEFINE VARIABLE glCoverageStatus_Available AS LOGICAL INITIAL yes 
     LABEL "verf�gbar":L18 
     VIEW-AS TOGGLE-BOX
     SIZE 20 BY .79 NO-UNDO.

DEFINE VARIABLE glCoverageStatus_Covered AS LOGICAL INITIAL yes 
     LABEL "gedeckt":L18 
     VIEW-AS TOGGLE-BOX
     SIZE 20 BY .79 NO-UNDO.

DEFINE VARIABLE glCoverageStatus_Open AS LOGICAL INITIAL yes 
     LABEL "offen":L18 
     VIEW-AS TOGGLE-BOX
     SIZE 20 BY .79 NO-UNDO.

DEFINE VARIABLE glCoverageStatus_PAvailable AS LOGICAL INITIAL yes 
     LABEL "tlw verf�gbar":L18 
     VIEW-AS TOGGLE-BOX
     SIZE 20 BY .79 NO-UNDO.

DEFINE VARIABLE glCoverageStatus_Without AS LOGICAL INITIAL yes 
     LABEL "ohne":L18 
     VIEW-AS TOGGLE-BOX
     SIZE 20 BY .79 NO-UNDO.

/* Query definitions                                                    */
&ANALYZE-SUSPEND
DEFINE QUERY br_table FOR 
      &IF defined(PA-CHECK-BROWSE-CONFIGURATION-SUPPORT) &THEN
        &IF {&PA-CHECK-BROWSE-CONFIGURATION-SUPPORT} &THEN
        DBT_VirtualIndex,
        &ENDIF
      &ENDIF
      ttUV_VersandBeleg SCROLLING.
&ANALYZE-RESUME

/* Browse definitions                                                   */
DEFINE BROWSE br_table
&ANALYZE-SUSPEND _UIB-CODE-BLOCK _DISPLAY-FIELDS br_table B-table-Win _FREEFORM
  QUERY br_table NO-LOCK DISPLAY
      find-additional-records() @ gcCoverageStatus
      ttUV_VersandBeleg.Markiert FORMAT "*/":U
      ttUV_VersandBeleg.Konto FORMAT "zzzzzzzz":U
      ttUV_VersandBeleg.Konto_Name1 FORMAT "x(35)":U
      ttUV_VersandBeleg.Konto_Name2 FORMAT "x(35)":U
      ttUV_VersandBeleg.Konto_Name3 FORMAT "x(35)":U
      gcKontoName
      ttUV_VersandBeleg.Konto_Suchbegriff FORMAT "x(12)":U
      ttUV_VersandBeleg.Konto_Selektion FORMAT "x(20)":U
      ttUV_VersandBeleg.Konto_Branche FORMAT "x(6)":U
      ttUV_VersandBeleg.Konto_BrancheBez FORMAT "x(70)":U
      ttUV_VersandBeleg.Konto_Region FORMAT "x(6)":U
      ttUV_VersandBeleg.Konto_RegionBez FORMAT "x(30)":U
      ttUV_VersandBeleg.Belegart FORMAT "x(3)":U
      ttUV_VersandBeleg.BelegartBez FORMAT "x(30)":U
      ttUV_VersandBeleg.BelegNummer FORMAT "zzzzzzz9":U
      ttUV_VersandBeleg.PositionsNr FORMAT "zz9.9":U
      ttUV_VersandBeleg.BelegInfo FORMAT "x(40)":U
      ttUV_VersandBeleg.Abruf FORMAT "x(17)":U
      ttUV_VersandBeleg.AbrufNr FORMAT "zzzzz9":U
      ttUV_VersandBeleg.Abladestelle FORMAT "x(17)":U
      ttUV_VersandBeleg.AbladestelleBez[1] FORMAT "x(35)":U
      ttUV_VersandBeleg.AbladestelleBez[2] FORMAT "x(35)":U
      ttUV_VersandBeleg.AbladestelleBez[3] FORMAT "x(35)":U
      ttUV_VersandBeleg.AbladestelleBez[4] FORMAT "x(35)":U
      gcAbladestelleBez

      ttUV_VersandBeleg.LocklevelOriginLSLSL format "x(10)":U
      ttUV_VersandBeleg.LocklevelOriginMMP format "x(8)":U
      ttUV_VersandBeleg.LocklevelPartLSLSL format "x(12)":U           
      ttUV_VersandBeleg.LocklevelPartMMP format "x(10)":U             
      ttUV_VersandBeleg.LocklevelCustomerLSLSL format "x(12)":U       
      ttUV_VersandBeleg.LocklevelCustomerMMP format "x(10)":U         
      ttUV_VersandBeleg.LocklevelCarrierLSL format "x(12)":U          
      ttUV_VersandBeleg.LocklevelCarrierVSD format "x(12)":U          
      ttUV_VersandBeleg.Mahnstufe                  

      ttUV_VersandBeleg.uCI_ZeichenKunde FORMAT "X(4)":U
      ttUV_VersandBeleg.uCI_LagerortKunde FORMAT "X(7)":U
      ttUV_VersandBeleg.uCI_Hinweis1 FORMAT "x(35)":U
      ttUV_VersandBeleg.uCI_Hinweis2 FORMAT "x(35)":U
      ttUV_VersandBeleg.uCI_Hinweis3 FORMAT "x(35)":U
      ttUV_VersandBeleg.uCI_Hinweis4 FORMAT "x(35)":U
      ttUV_VersandBeleg.Auftrag FORMAT "x(17)":U
      ttUV_VersandBeleg.uCI_Sammellieferschein FORMAT "SmLi/EzLi":U
      ttUV_VersandBeleg.Artikel FORMAT "x(20)":U
      ttUV_VersandBeleg.ArtikelBez[1] FORMAT "x(30)":U
      ttUV_VersandBeleg.ArtikelBez[2] FORMAT "x(30)":U
      ttUV_VersandBeleg.ArtikelBez[3] FORMAT "x(30)":U
      ttUV_VersandBeleg.ArtikelBez[4] FORMAT "x(30)":U
      gcArtikelBez
      ttUV_VersandBeleg.Artikelgruppe FORMAT "x(6)":U
      ttUV_VersandBeleg.ArtikelgruppeBez FORMAT "x(30)":U
      ttUV_VersandBeleg.Sparte FORMAT "x(6)":U
      ttUV_VersandBeleg.SparteBez FORMAT "x(30)":U
      ttUV_VersandBeleg.Artikel_Selektion FORMAT "x(20)":U
      ttUV_VersandBeleg.Artikel_Suchbegriff FORMAT "x(12)":U
      ttUV_VersandBeleg.ArtikelArt FORMAT "z9":U
      ttUV_VersandBeleg.ArtikelArtBez FORMAT "x(30)":U
      ttUV_VersandBeleg.ArtikelNr FORMAT "x(22)":U
      ttUV_VersandBeleg.ArtikelNrBez[1] FORMAT "x(30)":U
      ttUV_VersandBeleg.ArtikelNrBez[2] FORMAT "x(30)":U
      ttUV_VersandBeleg.ArtikelNrBez[3] FORMAT "x(30)":U
      ttUV_VersandBeleg.ArtikelNrBez[4] FORMAT "x(30)":U
      gcArtikelNrBez
      ttUV_VersandBeleg.Wunschtermin FORMAT "99.99.9999":U
      ttUV_VersandBeleg.Liefertermin FORMAT "99.99.9999":U
      /* --> MO#HIDR-AH4-1123 thongdi_p 20.07.2026 Erweiterung Versandmonitor im Feld Best. Termin */
      ttUV_VersandBeleg.xEbLiefertermin FORMAT "99.99.9999":U
      /* <-- MO#HIDR-AH4-1123 thongdi_p 20.07.2026 Erweiterung Versandmonitor im Feld Best. Termin */
      ttUV_VersandBeleg.Transportzeit FORMAT "zzzzz9":U
      gcTransTimeUnitDesc
      ttUV_VersandBeleg.uCI_Warenausgangstermin FORMAT "99.99.9999":U
      ttUV_VersandBeleg.uCI_KommZeit FORMAT "zzzzz9":U
      gcKommTimeUnitDesc
      ttUV_VersandBeleg.Versandtermin FORMAT "99.99.9999":U
      ttUV_VersandBeleg.AuftragsArt FORMAT "x(2)":U
      ttUV_VersandBeleg.AuftragsArtBez FORMAT "x(30)":U
      ttUV_VersandBeleg.Versandart FORMAT "zz9":U
      ttUV_VersandBeleg.VersandarBez FORMAT "x(70)":U
      ttUV_VersandBeleg.LieferBedingung FORMAT "zz9":U
      ttUV_VersandBeleg.LieferBedingungBez FORMAT "x(70)":U
      ttUV_VersandBeleg.LieferRestrikt FORMAT "z9":U
      ttUV_VersandBeleg.LieferRestriktBez
      ttUV_VersandBeleg.Sachbearbeiter FORMAT "x(12)":U
      ttUV_VersandBeleg.SachbearbeiterName FORMAT "x(35)":U
      ttUV_VersandBeleg.Lieferant FORMAT "zzzzzzzz":U
      ttUV_VersandBeleg.Lieferant_Name1 FORMAT "x(35)":U
      ttUV_VersandBeleg.Lieferant_Name2 FORMAT "x(35)":U
      ttUV_VersandBeleg.Lieferant_Name3 FORMAT "x(35)":U
      gcLieferantName
      ttUV_VersandBeleg.Lieferant_Suchbegriff FORMAT "x(12)":U
      ttUV_VersandBeleg.Lieferant_Selektion FORMAT "x(20)":U
      ttUV_VersandBeleg.LieferAdresse FORMAT "zz9":U
      ttUV_VersandBeleg.AdressKennung FORMAT "x(20)":U
      ttUV_VersandBeleg.LiefAdr_Name1 FORMAT "x(35)":U
      gcLiefAdr_Name
      ttUV_VersandBeleg.LiefAdr_Staat FORMAT "x(3)":U
      ttUV_VersandBeleg.LiefAdr_PLZ FORMAT "x(10)":U
      ttUV_VersandBeleg.LiefAdr_Ort FORMAT "x(30)":U
      ttUV_VersandBeleg.LiefAdr_Bundesland FORMAT "x(3)":U
      ttUV_VersandBeleg.LiefAdr_Name2 FORMAT "x(35)":U
      ttUV_VersandBeleg.LiefAdr_Name3 FORMAT "x(35)":U
      ttUV_VersandBeleg.LiefAdr_Strasse FORMAT "x(30)":U
      ttUV_VersandBeleg.LiefAdr_HausNummer FORMAT "x(12)":U
      ttUV_VersandBeleg.KO_LagerOrt FORMAT "zzzzzzz9":U
      ttUV_VersandBeleg.KO_LagerOrtBez FORMAT "x(30)":U
      ttUV_VersandBeleg.Menge FORMAT "-zzz,zzz,zz9.999":U
      ttUV_VersandBeleg.gelieferte_Menge FORMAT "-zzz,zzz,zz9.999":U
      ttUV_VersandBeleg.KommMenge FORMAT "-zzz,zzz,zz9.999":U
      ttUV_VersandBeleg.OffeneMenge FORMAT "-zzz,zzz,zz9.999":U
      ttUV_VersandBeleg.uCI_DispatchQty FORMAT "-zzz,zzz,zz9.999":U
      ttUV_VersandBeleg.uCI_DispatchQtyRemark FORMAT "x(100)":U
      ttUV_VersandBeleg.Bestand FORMAT "-zzz,zzz,zz9.999":U
      ttUV_VersandBeleg.MengenEinheitKurzBezLME FORMAT "x(3)":U
      ttUV_VersandBeleg.MengenEinheitKurzBez FORMAT "x(3)":U
      ttUV_VersandBeleg.VME_Faktor
      ttUV_VersandBeleg.MRPRelease FORMAT "ja/nein":U
      ttUV_VersandBeleg.GesamtwertOffen FORMAT "-zzz,zzz,zz9.999":U
      ttUV_VersandBeleg.GesamtwertVerfuegbar FORMAT "-zzz,zzz,zz9.999":U
      ttUV_VersandBeleg.Fehlermeldung
      ttUV_VersandBeleg.StorageArea      
      ttUV_VersandBeleg.StorageArea_Desc 
      ttUV_VersandBeleg.CreditTerms      
      ttUV_VersandBeleg.CreditTerms_Desc 
      ttUV_VersandBeleg.MRPArea          
      ttUV_VersandBeleg.MRPArea_desc     

      {&{&PA-XBASISNAME}_C_BROWSEDISPLAY}
      {&{&PA-XBASISNAME}_U_BROWSEDISPLAY}
      {&{&PA-XBASISNAME}_BROWSEDISPLAY}
      {&{&PA-XBASISNAME}_Y_BROWSEDISPLAY}
ENABLE
      ttUV_VersandBeleg.uCI_DispatchQty
      ttUV_VersandBeleg.uCI_DispatchQtyRemark
/* _UIB-CODE-BLOCK-END */
&ANALYZE-RESUME
    WITH NO-ASSIGN SEPARATORS SIZE 260.5 BY 16.5.


/* ************************  Frame Definitions  *********************** */

DEFINE FRAME F-Main
     br_table AT ROW 8 COL 1
     giKonto AT ROW 1.5 COL 21 COLON-ALIGNED HELP
          ""
     giLieferadresse AT ROW 2.5 COL 21 COLON-ALIGNED HELP
          ""
     gcAdressKennung AT ROW 3.5 COL 21 COLON-ALIGNED HELP
          ""
     gcAbladestelle AT ROW 4.5 COL 21 COLON-ALIGNED HELP
          ""
     gcuCI_LagerortKunde AT ROW 5.5 COL 21 COLON-ALIGNED HELP
          ""
     gcKonto_Name1 AT ROW 1.5 COL 60 COLON-ALIGNED HELP
          ""
     gcKonto_Name2 AT ROW 2.5 COL 60 COLON-ALIGNED HELP
          "" NO-LABEL
     gcKonto_Strasse AT ROW 3.5 COL 60 COLON-ALIGNED HELP
          ""
     gcKonto_Ort AT ROW 4.5 COL 60 COLON-ALIGNED HELP
          ""
     giLieferant AT ROW 1.5 COL 120 COLON-ALIGNED HELP
          ""
     giVersandArt AT ROW 2.5 COL 120 COLON-ALIGNED HELP
          ""
     gtuCI_Warenausgangstermin_min AT ROW 3.5 COL 120 COLON-ALIGNED
     gtuCI_Warenausgangstermin_max AT ROW 3.5 COL 132.5 COLON-ALIGNED NO-LABEL
     gtVersandtermin_min AT ROW 4.5 COL 120 COLON-ALIGNED
     gtVersandtermin_max AT ROW 4.5 COL 132.5 COLON-ALIGNED NO-LABEL
     gcArtikel AT ROW 5.5 COL 120 COLON-ALIGNED HELP
          ""
     gcSuche AT ROW 5.5 COL 144.5 COLON-ALIGNED NO-LABEL
     gcLieferant_Name1 AT ROW 1.5 COL 162 COLON-ALIGNED HELP
          ""
     gcLieferant_Name2 AT ROW 2.5 COL 162 COLON-ALIGNED HELP
          "" NO-LABEL
     gcLieferant_Strasse AT ROW 3.5 COL 162 COLON-ALIGNED HELP
          ""
     gcLieferant_Ort AT ROW 4.5 COL 162 COLON-ALIGNED HELP
          ""
     gcGesamtwert AT ROW 1.5 COL 212 COLON-ALIGNED NO-LABEL
     gcGesamtwert_offen AT ROW 1.5 COL 237 COLON-ALIGNED NO-LABEL
     gdGesamtwert_Markiert AT ROW 2.5 COL 212 COLON-ALIGNED
     gdGesamtwert_offen_Markiert AT ROW 2.5 COL 237 COLON-ALIGNED NO-LABEL
     gdGesamtwert_Alle AT ROW 3.5 COL 212 COLON-ALIGNED
     gdGesamtwert_offen_alle AT ROW 3.5 COL 237 COLON-ALIGNED NO-LABEL
     glBelegartU AT ROW 7 COL 2
     glBelegartVUA AT ROW 7 COL 23
     &IF LOOKUP("VS","{&PA-MODULE}") > 0 &THEN
       glDocTypeServiceOrder AT ROW 7 COL 48
       glDocTypeRepairOrder at  ROW 7 COL 73
     &ENDIF  
     glBelegartPPF AT ROW 7 COL 98
     glCoverageStatus_Without AT ROW 7 COL 150.5
     glCoverageStatus_Available AT ROW 7 COL 171.5
     glCoverageStatus_PAvailable AT ROW 7 COL 192.5
     glCoverageStatus_Covered AT ROW 7 COL 213.5
     glCoverageStatus_Open AT ROW 7 COL 235
    WITH 1 DOWN NO-BOX KEEP-TAB-ORDER OVERLAY 
         SIDE-LABELS NO-UNDERLINE THREE-D 
         AT COL 1 ROW 1 SCROLLABLE. 

/* *********************** Procedure Settings ************************ */

&ANALYZE-SUSPEND _PROCEDURE-SETTINGS
/* Settings for THIS-PROCEDURE
   Type: Proalpha-SmartBrowser
   Allow: Basic,Browse
   Frames: 1
   Add Fields to: External-Tables
   Other Settings: PERSISTENT-ONLY
   Temp-Tables and Buffers:
      TABLE: ttUV_VersandBeleg T "?" NO-UNDO temp-db ttUV_VersandBeleg
   END-TABLES.
 */

/* This procedure should always be RUN PERSISTENT.  Report the error,  */
/* then cleanup and return.                                            */
IF NOT THIS-PROCEDURE:PERSISTENT THEN DO:
  MESSAGE "{&FILE-NAME} should only be RUN PERSISTENT.":U
          VIEW-AS ALERT-BOX ERROR BUTTONS OK.
  RETURN.
END.

&ANALYZE-RESUME _END-PROCEDURE-SETTINGS

/* *************************  Create Window  ************************** */

&ANALYZE-SUSPEND _CREATE-WINDOW
/* DESIGN Window definition (used by the UIB) 
  CREATE WINDOW B-table-Win ASSIGN
         HEIGHT             = 24.25
         WIDTH              = 258.33.
/* END WINDOW DEFINITION */
                                                                        */
&ANALYZE-RESUME

&ANALYZE-SUSPEND _UIB-CODE-BLOCK _CUSTOM _INCLUDED-LIB B-table-Win 
/* ************************* Included-Libraries *********************** */

{adm/method/incl/dm_brw01.lib}

/* _UIB-CODE-BLOCK-END */
&ANALYZE-RESUME




/* ***********  Runtime Attributes and AppBuilder Settings  *********** */

&ANALYZE-SUSPEND _RUN-TIME-ATTRIBUTES
/* SETTINGS FOR WINDOW B-table-Win
  NOT-VISIBLE,,RUN-PERSISTENT                                           */
/* SETTINGS FOR FRAME F-Main
   NOT-VISIBLE FRAME-NAME Size-to-Fit Custom                            */
/* BROWSE-TAB br_table 1 F-Main */
ASSIGN 
       FRAME F-Main:SCROLLABLE       = FALSE
       FRAME F-Main:HIDDEN           = TRUE.

/* SETTINGS FOR FILL-IN gcAbladestelle IN FRAME F-Main
   LIKE = temp-db.ttUV_VersandBeleg.Abladestelle EXP-SIZE               */
/* SETTINGS FOR FILL-IN gcAdressKennung IN FRAME F-Main
   LIKE = temp-db.ttUV_VersandBeleg.AdressKennung EXP-SIZE              */
/* SETTINGS FOR FILL-IN gcArtikel IN FRAME F-Main
   LIKE = temp-db.ttUV_VersandBeleg.Artikel EXP-SIZE                    */
/* SETTINGS FOR FILL-IN gcGesamtwert IN FRAME F-Main
   NO-ENABLE                                                            */
/* SETTINGS FOR FILL-IN gcGesamtwert_offen IN FRAME F-Main
   NO-ENABLE                                                            */
/* SETTINGS FOR FILL-IN gcKonto_Name1 IN FRAME F-Main
   NO-ENABLE LIKE = basis.S_Adresse.Name1 EXP-SIZE                      */
/* SETTINGS FOR FILL-IN gcKonto_Name2 IN FRAME F-Main
   NO-ENABLE LIKE = basis.S_Adresse.Name2 EXP-SIZE                      */
/* SETTINGS FOR FILL-IN gcKonto_Ort IN FRAME F-Main
   NO-ENABLE LIKE = basis.S_Adresse.Ort EXP-SIZE                        */
/* SETTINGS FOR FILL-IN gcKonto_Strasse IN FRAME F-Main
   NO-ENABLE LIKE = basis.S_Adresse.Strasse EXP-SIZE                    */
/* SETTINGS FOR FILL-IN gcLieferant_Name1 IN FRAME F-Main
   NO-ENABLE LIKE = basis.S_Adresse.Name1 EXP-SIZE                      */
/* SETTINGS FOR FILL-IN gcLieferant_Name2 IN FRAME F-Main
   NO-ENABLE LIKE = basis.S_Adresse.Name2 EXP-SIZE                      */
/* SETTINGS FOR FILL-IN gcLieferant_Ort IN FRAME F-Main
   NO-ENABLE LIKE = basis.S_Adresse.Ort EXP-SIZE                        */
/* SETTINGS FOR FILL-IN gcLieferant_Strasse IN FRAME F-Main
   NO-ENABLE LIKE = basis.S_Adresse.Strasse EXP-SIZE                    */
ASSIGN 
       gcSuche:POPUP-MENU IN FRAME F-Main       = MENU POPUP-MENU-gcSuche:HANDLE.

/* SETTINGS FOR FILL-IN gcuCI_LagerortKunde IN FRAME F-Main
   LIKE = temp-db.ttUV_VersandBeleg.uCI_LagerortKunde EXP-SIZE          */
/* SETTINGS FOR FILL-IN gdGesamtwert_Alle IN FRAME F-Main
   NO-ENABLE                                                            */
/* SETTINGS FOR FILL-IN gdGesamtwert_Markiert IN FRAME F-Main
   NO-ENABLE                                                            */
/* SETTINGS FOR FILL-IN gdGesamtwert_offen_alle IN FRAME F-Main
   NO-ENABLE                                                            */
/* SETTINGS FOR FILL-IN gdGesamtwert_offen_Markiert IN FRAME F-Main
   NO-ENABLE                                                            */
/* SETTINGS FOR FILL-IN giKonto IN FRAME F-Main
   LIKE = temp-db.ttUV_VersandBeleg.Konto EXP-SIZE                      */
/* SETTINGS FOR FILL-IN giLieferadresse IN FRAME F-Main
   LIKE = temp-db.ttUV_VersandBeleg.LieferAdresse EXP-SIZE              */
/* SETTINGS FOR FILL-IN giLieferant IN FRAME F-Main
   LIKE = temp-db.ttUV_VersandBeleg.Lieferant EXP-SIZE                  */
/* SETTINGS FOR FILL-IN giVersandArt IN FRAME F-Main
   LIKE = temp-db.ttUV_VersandBeleg.Versandart EXP-SIZE                 */
ASSIGN 
       glBelegartPPF:HIDDEN IN FRAME F-Main           = TRUE.
       &IF LOOKUP("VS","{&PA-MODULE}") = 0 &THEN
         glDocTypeServiceOrder:HIDDEN in frame F-Main           = TRUE.
         glDocTypeRepairOrder:HIDDEN in frame F-Main            = TRUE. 
       &ENDIF  

/* _RUN-TIME-ATTRIBUTES-END */
&ANALYZE-RESUME


/* Setting information for Queries and Browse Widgets fields            */

&ANALYZE-SUSPEND _QUERY-BLOCK BROWSE br_table
/* Query rebuild information for BROWSE br_table
     _START_FREEFORM
OPEN QUERY {&SELF-NAME} FOR EACH ttUV_VersandBeleg WHERE ~{&KEY-PHRASE} NO-LOCK ~{&SORTBY-PHRASE}.
     _END_FREEFORM
     _Options          = "NO-LOCK KEY-PHRASE SORTBY-PHRASE"
     _Query            is NOT OPENED
*/  /* BROWSE br_table */
&ANALYZE-RESUME

&ANALYZE-SUSPEND _QUERY-BLOCK FRAME F-Main
/* Query rebuild information for FRAME F-Main
     _Options          = "NO-LOCK"
     _Query            is NOT OPENED
*/  /* FRAME F-Main */
&ANALYZE-RESUME





/* ************************  Control Triggers  ************************ */

&Scoped-define BROWSE-NAME br_table
&Scoped-define SELF-NAME br_table
&ANALYZE-SUSPEND _UIB-CODE-BLOCK _CONTROL br_table B-table-Win
ON {&pa_EntryEvent} OF br_table IN FRAME F-Main
DO: /* dieser Block wird vom UIB ben�tigt! */
/* ### */
END.

&Scoped-define SELF-NAME ttUV_VersandBeleg.uCI_DispatchQty
ON {&pa_EntryEvent} OF ttUV_VersandBeleg.uCI_DispatchQty IN BROWSE {&BROWSE-NAME}
DO:
  {adm/template/incl/dt_uit00.if
     &UserExitName = "ON_PA_ENTRYEVENT_OF_ttUV_VersandBeleg_uCI_DispatchQty"}

  if available ttUV_VersandBeleg then
  do:

    /* if the open quantity is available, init the dispatch quantity with the open quantity */
    if ttUV_VersandBeleg.CoverageStatus = {&uCI_CoverageStatus_Available}
      and {getwidgetattr ttUV_VersandBeleg.uCI_DispatchQty input-value decimal "in browse {&BROWSE-NAME}"} = 0 then

      {adm/incl/d__bcs00.if
         &BrowseCell  = "ttUV_VersandBeleg.uCI_DispatchQty"
         &ScreenValue = "string(ttUV_VersandBeleg.OffeneMenge)"
         &WithFrame   = "in browse {&BROWSE-NAME}"}.

  end. /* available ttUV_VersandBeleg */

  {adm/template/incl/dt_uit01.if
     &UserExitName = "ON_PA_ENTRYEVENT_OF_ttUV_VersandBeleg_uCI_DispatchQty"}
END.

ON LEAVE OF gtuCI_Warenausgangstermin_min IN FRAME {&FRAME-NAME} /* Versanddatum min */
DO:
  {adm/template/incl/dt_uit00.if
     &UserExitName = "ON_LEAVE_OF_gtuCI_Warenausgangstermin_min"}

  {adm/template/incl/dt_viw03.if}

  {adm/template/incl/dt_uit01.if
     &UserExitName = "ON_LEAVE_OF_gtuCI_Warenausgangstermin_min"}
END.

ON LEAVE OF gtuCI_Warenausgangstermin_max IN FRAME {&FRAME-NAME} /* Versanddatum max */
DO:
  {adm/template/incl/dt_uit00.if
     &UserExitName = "ON_LEAVE_OF_gtuCI_Warenausgangstermin_max"}

  {adm/template/incl/dt_viw03.if}

  {adm/template/incl/dt_uit01.if
     &UserExitName = "ON_LEAVE_OF_gtuCI_Warenausgangstermin_max"}
END.

ON LEAVE OF gtVersandtermin_min IN FRAME {&FRAME-NAME} /* Bereitstelltermin min */
DO:
  {adm/template/incl/dt_uit00.if
     &UserExitName = "ON_LEAVE_OF_gtVersandtermin_min"}

  {adm/template/incl/dt_viw03.if}

  {adm/template/incl/dt_uit01.if
     &UserExitName = "ON_LEAVE_OF_gtVersandtermin_min"}
END.

ON LEAVE OF gtVersandtermin_max IN FRAME {&FRAME-NAME} /* Bereitstelltermin max */
DO:
  {adm/template/incl/dt_uit00.if
     &UserExitName = "ON_LEAVE_OF_gtVersandtermin_max"}

  {adm/template/incl/dt_viw03.if}

  {adm/template/incl/dt_uit01.if
     &UserExitName = "ON_LEAVE_OF_gtVersandtermin_max"}
END.

ON LEAVE OF ttUV_VersandBeleg.uCI_DispatchQty IN BROWSE {&BROWSE-NAME} /* Betrag */
DO:

  define variable lAnswer      as logical no-undo.
  define variable dDispatchQty as decimal    no-undo.

  /* Check multiples of the sales unit of measure (Verpackungsmengeneinheit) */

  {adm/template/incl/dt_uit00.if
     &UserExitName = "ON_LEAVE_OF_ttUV_VersandBeleg_uCI_DispatchQty"}

  if available ttUV_VersandBeleg
    and {getwidgetattr ttUV_VersandBeleg.uCI_DispatchQty input-value decimal "in browse {&BROWSE-NAME}"} / ttUV_VersandBeleg.VME_Faktor
          <> truncate({getwidgetattr ttUV_VersandBeleg.uCI_DispatchQty input-value decimal "in browse {&BROWSE-NAME}"} / ttUV_VersandBeleg.VME_Faktor,ttUV_VersandBeleg.Nachkomma) then
    do:

    assign
      glTriggerError = yes
      lAnswer        = adm.method.cls.DMCMessageSvc:prpoInstance:lShowMessage
                         ('uvvmo00003':U)
      dDispatchQty   = {getwidgetattr ttUV_VersandBeleg.uCI_DispatchQty input-value decimal "in browse {&BROWSE-NAME}"}
      .

    case lAnswer:

      when yes then
      do:

        {adm/incl/d__bcs00.if
           &BrowseCell  = "ttUV_VersandBeleg.uCI_DispatchQty"
           &ScreenValue = "string((truncate(dDispatchQty / ttUV_VersandBeleg.VME_Faktor,ttUV_VersandBeleg.Nachkomma) + 1) * ttUV_VersandBeleg.VME_Faktor)"
           &WithFrame   = "in browse {&BROWSE-NAME}"}.

        glTriggerError = no.

      end.

      when no then
      do:

        {adm/incl/d__bcs00.if
           &BrowseCell  = "ttUV_VersandBeleg.uCI_DispatchQty"
           &ScreenValue = "string(truncate(dDispatchQty / ttUV_VersandBeleg.VME_Faktor,ttUV_VersandBeleg.Nachkomma) * ttUV_VersandBeleg.VME_Faktor)"
           &WithFrame   = "in browse {&BROWSE-NAME}"}.

        glTriggerError = no.

      end.

      when ? then
      do:

        glTriggerError = yes.

        {returnnoapply}.

      end.

    end.

  end. /* Check multiples of sales unit of measure */

  glTriggerError = no.

  if available ttUV_VersandBeleg
    and ttUV_VersandBeleg.uCI_DispatchQty <> {getwidgetattr ttUV_VersandBeleg.uCI_DispatchQty input-value decimal "in browse {&BROWSE-NAME}"}
    and (   {getwidgetattr ttUV_VersandBeleg.uCI_DispatchQty input-value decimal "in browse {&BROWSE-NAME}"} > ttUV_VersandBeleg.OffeneMenge
         or {getwidgetattr ttUV_VersandBeleg.uCI_DispatchQty input-value decimal "in browse {&BROWSE-NAME}"} < 0 ) then
  do:

    adm.method.cls.DMCMessageSvc:prpoInstance:lShowMessage /* code checked by Kuehnlenz_C 16.02.2017 */
      ('uvvmo00001':U,
       string({getwidgetattr ttUV_VersandBeleg.uCI_DispatchQty input-value decimal "in browse {&BROWSE-NAME}"}),
       string(ttUV_VersandBeleg.OffeneMenge)).

    glTriggerError = yes.

    {returnnoapply}.

  end.

  {adm/template/incl/dt_uit01.if
     &UserExitName = "ON_LEAVE_OF_ttUV_VersandBeleg_uCI_DispatchQty"}
END.

/* _UIB-CODE-BLOCK-END */
&ANALYZE-RESUME


&ANALYZE-SUSPEND _UIB-CODE-BLOCK _CONTROL br_table B-table-Win
ON ROW-DISPLAY OF br_table IN FRAME F-Main
DO:
  {adm/template/incl/dt_uit00.if
     &UserExitName = "ON_ROW-DISPLAY_OF_br_table"}

  if available ttUV_VersandBeleg then
  do:

    {fnarg
      pa_lUISvcSetBrowseCellColor
      "gcCoverageStatus:HANDLE in browse {&BROWSE-NAME},
       entry(lookup(string(ttUV_VersandBeleg.CoverageStatus), gcUCI_CoverageStatus_Keys),
                                                              gcUCI_CoverageStatus_ColorBG)
       + ',':U +
       entry(lookup(string(ttUV_VersandBeleg.CoverageStatus), gcUCI_CoverageStatus_Keys),
                                                              gcUCI_CoverageStatus_ColorFG)"}.

    find S_Artikel
      where S_Artikel.Firma   = {firma/sartikel.fir pa-Firma}
        and S_Artikel.Artikel = ttUV_VersandBeleg.Artikel
      no-lock no-error.

    if available S_Artikel then

      /* Lagermengeneinheit                                                     */

      assign
        giDecimals = {fnarg
                        pa_iDyCchUnitOfMeasureDecimals
                        "pa-Firma,
                         S_Artikel.LagerME"}
        {adm/incl/d__bcf00.if
           &BrowseCellTable  = "ttUV_VersandBeleg"
           &BrowseCellColumn = "Menge"
           &ToFormat         = "entry(giDecimals + 1, {&pa_MengenAnzeigeFormat_Browse}, {&PA-DELIMITER4})"
           &WithFrame        = "in browse {&BROWSE-NAME}"}
        {adm/incl/d__bcf00.if
           &BrowseCellTable  = "ttUV_VersandBeleg"
           &BrowseCellColumn = "gelieferte_Menge"
           &ToFormat         = "entry(giDecimals + 1, {&pa_MengenAnzeigeFormat_Browse}, {&PA-DELIMITER4})"
           &WithFrame        = "in browse {&BROWSE-NAME}"}
        {adm/incl/d__bcf00.if
           &BrowseCellTable  = "ttUV_VersandBeleg"
           &BrowseCellColumn = "KommMenge"
           &ToFormat         = "entry(giDecimals + 1, {&pa_MengenAnzeigeFormat_Browse}, {&PA-DELIMITER4})"
           &WithFrame        = "in browse {&BROWSE-NAME}"}
        {adm/incl/d__bcf00.if
           &BrowseCellTable  = "ttUV_VersandBeleg"
           &BrowseCellColumn = "OffeneMenge"
           &ToFormat         = "entry(giDecimals + 1, {&pa_MengenAnzeigeFormat_Browse}, {&PA-DELIMITER4})"
           &WithFrame        = "in browse {&BROWSE-NAME}"}
        {adm/incl/d__bcf00.if
           &BrowseCellTable  = "ttUV_VersandBeleg"
           &BrowseCellColumn = "uCI_DispatchQty"
           &ToFormat         = "entry(giDecimals + 1, {&pa_MengenAnzeigeFormat_Browse}, {&PA-DELIMITER4})"
           &WithFrame        = "in browse {&BROWSE-NAME}"}
        {adm/incl/d__bcf00.if
           &BrowseCellTable  = "ttUV_VersandBeleg"
           &BrowseCellColumn = "Bestand"
           &ToFormat         = "entry(giDecimals + 1, {&pa_MengenAnzeigeFormat_Browse}, {&PA-DELIMITER4})"
           &WithFrame        = "in browse {&BROWSE-NAME}"}
        .

    assign
      {adm/incl/d__bcf00.if
         &BrowseCellTable  = "ttUV_VersandBeleg"
         &BrowseCellColumn = "GesamtwertOffen"
         &ToFormat         = "dynamic-function('pa_cCurValTotalFormat':U in target-procedure, pACConnectionSvc:prpcCompany, 0)"
         &WithFrame        = "in browse {&BROWSE-NAME}"}
      {adm/incl/d__bcf00.if
         &BrowseCellTable  = "ttUV_VersandBeleg"
         &BrowseCellColumn = "GesamtwertVerfuegbar"
         &ToFormat         = "dynamic-function('pa_cCurValTotalFormat':U in target-procedure, pACConnectionSvc:prpcCompany, 0)"
         &WithFrame        = "in browse {&BROWSE-NAME}"}
      .

  end. /* available ttUV_VersandBeleg */

  {adm/template/incl/dt_uit01.if
     &UserExitName = "ON_ROW-DISPLAY_OF_br_table"}
END.

/* _UIB-CODE-BLOCK-END */
&ANALYZE-RESUME


&ANALYZE-SUSPEND _UIB-CODE-BLOCK _CONTROL br_table B-table-Win
ON VALUE-CHANGED OF br_table IN FRAME F-Main
DO:
  {adm/template/incl/dt_uit00.if
     &UserExitName = "ON_VALUE-CHANGED_OF_br_table"}

  if valid-handle (ghDocumentHeader) then

    run ShowDocumentHeader('update':U).

  if valid-handle (ghDocumentHeaderInfo) then

    run ShowDocumentHeader('info':U).

  if valid-handle (ghDocumentLine) then

    run ShowDocumentLine('update':U).

  if valid-handle (ghDocumentLineInfo) then

    run ShowDocumentLine('info':U).

  /* This ADM trigger code must be preserved in order to notify other
     objects when the browser's current row changes. */
  {adm/template/incl/dt_brw04.if}

  {adm/template/incl/dt_uit01.if
     &UserExitName = "ON_VALUE-CHANGED_OF_br_table"}
END.

/* _UIB-CODE-BLOCK-END */
&ANALYZE-RESUME


&Scoped-define SELF-NAME gcArtikel
&ANALYZE-SUSPEND _UIB-CODE-BLOCK _CONTROL gcArtikel B-table-Win
ON LEAVE OF gcArtikel IN FRAME F-Main /* Teil */
DO:

  define buffer bS_Artikel for S_Artikel.

  {adm/template/incl/dt_uit00.if
     &UserExitName = "ON_LEAVE_OF_gcArtikel"}

  if input frame {&frame-name} gcArtikel > '':U then

    find bS_Artikel
      where bS_Artikel.Firma   = {firma/sartikel.fir pa-firma}
        and bS_Artikel.Artikel = input frame {&frame-name} gcArtikel
      no-lock no-error.

  case giSuchfeld:

    when 1 then

      run Kunde-Teil.

    when 2 then

      run EAN-Teil.

    otherwise
    do:

      if input frame {&frame-name} gcArtikel > '':U then
      do:

        if available bS_Artikel then

          gcSuche = (if giSuchfeld = 3 then
                       bS_Artikel.Suchbegriff
                     else if giSuchfeld = 4 then
                       bS_Artikel.Selektion
                     else
                       bS_Artikel.SortBezeichnung).

        else

          gcSuche = '':U.

        {adm/incl/d__duh00.if
           &Var1     = "gcSuche"
           &WithFrame = "frame {&frame-name}"}

      end.

    end.

  end case.

  run set-link-attribute in adm-broker-hdl
    (this-procedure,
     'record-target':U,
     'Artikel=':U + quoter(input frame {&frame-name} gcArtikel)).

  {adm/template/incl/dt_uit01.if
     &UserExitName = "ON_LEAVE_OF_gcArtikel"}
END.

/* _UIB-CODE-BLOCK-END */
&ANALYZE-RESUME


&Scoped-define SELF-NAME gcSuche
&ANALYZE-SUSPEND _UIB-CODE-BLOCK _CONTROL gcSuche B-table-Win
ON LEAVE OF gcSuche IN FRAME F-Main
DO:

  define buffer bS_Artikel for S_Artikel.

  {adm/template/incl/dt_uit00.if
     &UserExitName = "ON_LEAVE_OF_gcSuche"}

  case giSuchfeld:

    when 1 then

      run Teil-Kunde.

    when 2 then

      run Teil-EAN.

    when 3 then
    do:

      if    input frame {&frame-name} gcSuche  > '':U
        and input frame {&frame-name} gcSuche <> gcSuche then
      do:

        if    gcArtikel:screen-value in frame {&frame-name}  > '':U
          and gcArtikel:screen-value in frame {&frame-name} <> ? then

          find bS_Artikel
            where bS_Artikel.Firma   = {firma/sartikel.fir pa-firma}
              and bS_Artikel.Artikel = input frame {&frame-name} gcArtikel
            no-lock no-error.

        if   not available bS_Artikel
          or bS_Artikel.Suchbegriff <> input frame {&frame-name} gcSuche then
        do:

          find first bS_Artikel
            where bS_Artikel.Firma       = {firma/sartikel.fir pa-firma}
              and bS_Artikel.archiviert  = no
              and bS_Artikel.Suchbegriff begins input frame {&frame-name} gcSuche
            use-index ArchSuch
            no-lock no-error.

          if not available bS_Artikel then

            find first bS_Artikel
              where bS_Artikel.Firma       = {firma/sartikel.fir pa-firma}
                and bS_Artikel.archiviert  = yes
                and bS_Artikel.Suchbegriff begins input frame {&frame-name} gcSuche
              use-index ArchSuch
              no-lock no-error.

          if available bS_Artikel then

            {setwidgetattr
               "gcArtikel"
               "screen-value"
               "bS_Artikel.Artikel"
               "in frame {&frame-name}"}.

        end.  /* if not available S_Artikel */

      end.  /* if input frame {&frame-name} gcSuche */

    end.  /* when 3 then do */

    when 4 then
    do:

      if input frame {&frame-name} gcSuche > '':U then
      do:

        if    gcArtikel:screen-value in frame {&frame-name}  > '':U
          and gcArtikel:screen-value in frame {&frame-name} <> ? then

          find bS_Artikel
            where bS_Artikel.Firma   = {firma/sartikel.fir pa-firma}
              and bS_Artikel.Artikel = input frame {&frame-name} gcArtikel
            no-lock no-error.

        if   not available bS_Artikel
          or bS_Artikel.Selektion <> input frame {&frame-name} gcSuche then
        do:

          find first bS_Artikel
            where bS_Artikel.Firma       = {firma/sartikel.fir pa-firma}
              and bS_Artikel.archiviert  = no
              and bS_Artikel.Selektion   begins input frame {&frame-name} gcSuche
            use-index ArchSelekt
            no-lock no-error.

          if not available bS_Artikel then

            find first bS_Artikel
              where bS_Artikel.Firma      = {firma/sartikel.fir pa-firma}
                and bS_Artikel.archiviert = yes
                and bS_Artikel.Selektion  begins input frame {&frame-name} gcSuche
              use-index ArchSelekt
              no-lock no-error.

          if available bS_Artikel then

            {setwidgetattr
               "gcArtikel"
               "screen-value"
               "bS_Artikel.Artikel"
               "in frame {&frame-name}"}.

        end.  /* if not available S_Artikel */

        else

          if bS_Artikel.Selektion begins input frame {&frame-name} gcSuche then
          do:

            find first bS_Artikel
              where bS_Artikel.Firma       = {firma/sartikel.fir pa-firma}
                and bS_Artikel.archiviert  = no
                and bS_Artikel.Selektion  begins input frame {&frame-name} gcSuche
                and bS_Artikel.Artikel    <> gcArtikel
              use-index ArchSelekt
              no-lock no-error.

            if available bS_Artikel then

              {setwidgetattr
                 "gcArtikel"
                 "screen-value"
                 "bS_Artikel.Artikel"
                 "in frame {&frame-name}"}.

          end. /* if S_Artikel.Selektion begins input frame {&frame-name} gcSuche then */

      end.  /* if input frame {&frame-name} gcSuche */

    end.  /* when 4 then do */

    when 5 then
    do:

      if input frame {&frame-name} gcSuche > '':U then
      do:

        if    gcArtikel:screen-value in frame {&frame-name}  > '':U
          and gcArtikel:screen-value in frame {&frame-name} <> ? then

          find bS_Artikel
            where bS_Artikel.Firma   = {firma/sartikel.fir pa-firma}
              and bS_Artikel.Artikel = input frame {&frame-name} gcArtikel
            no-lock no-error.

        if   not available bS_Artikel
          or bS_Artikel.SortBezeichnung <> input frame {&frame-name} gcSuche then
        do:

          find first bS_Artikel
            where bS_Artikel.Firma           = {firma/sartikel.fir pa-firma}
              and bS_Artikel.archiviert      = no
              and bS_Artikel.SortBezeichnung begins input frame {&frame-name} gcSuche
            use-index SuchBez
            no-lock no-error.

          if not available bS_Artikel then

            find first bS_Artikel
              where bS_Artikel.Firma           = {firma/sartikel.fir pa-firma}
                and bS_Artikel.archiviert      = yes
                and bS_Artikel.SortBezeichnung begins input frame {&frame-name} gcSuche
              use-index SuchBez
              no-lock no-error.

          if available bS_Artikel then

            {setwidgetattr
               "gcArtikel"
               "screen-value"
               "bS_Artikel.Artikel"
               "in frame {&frame-name}"}.

        end.  /* if not available S_Artikel */

      end.  /* if input frame {&frame-name} gcSuche */

    end.  /* when 5 then do */

  end case.

  run set-link-attribute in adm-broker-hdl
    (this-procedure,
     'record-target':U,
     'Artikel=':U + quoter(input frame {&frame-name} gcArtikel)).

  {adm/template/incl/dt_uit01.if
     &UserExitName = "ON_LEAVE_OF_gcSuche"}
END.

/* _UIB-CODE-BLOCK-END */
&ANALYZE-RESUME


&Scoped-define SELF-NAME mi_Suche_nach_EAN-Nummer
&ANALYZE-SUSPEND _UIB-CODE-BLOCK _CONTROL mi_Suche_nach_EAN-Nummer B-table-Win
ON VALUE-CHANGED OF MENU-ITEM mi_Suche_nach_EAN-Nummer /* Suche nach EAN-Nummer */
DO:
  {adm/template/incl/dt_uit00.if
     &UserExitName = "ON_VALUE-CHANGED_OF_mi_Suche_nach_EAN-Nummer"}

  if self:checked = yes then
  do:

    assign
      {setwidgetattr
         "menu-item mi_Suche_nach_Kunden-Teilenumme"
         "checked"
         "no"
         "in menu POPUP-MENU-gcSuche"}
      {setwidgetattr
         "menu-item mi_Suche_nach_Selektion"
         "checked"
         "no"
         "in menu POPUP-MENU-gcSuche"}
      {setwidgetattr
         "menu-item mi_Suche_nach_SortierBez"
         "checked"
         "no"
         "in menu POPUP-MENU-gcSuche"}
      {setwidgetattr
         "menu-item mi_Suche_nach_Suchbegriff"
         "checked"
         "no"
         "in menu POPUP-MENU-gcSuche"}
      .

  end.
  else
  do:

    {setwidgetattr
       "self"
       "checked"
       "yes"}.

  end.

  giSuchfeld = 2.

  adm.config.cls.DCCAppConfigSvc:prpoInstance:setParameterValue
    ('VB_SalesDocLineSearchField':U,
     giSuchfeld).

  {adm/template/incl/dt_uit01.if
     &UserExitName = "ON_VALUE-CHANGED_OF_mi_Suche_nach_EAN-Nummer"}
END.

/* _UIB-CODE-BLOCK-END */
&ANALYZE-RESUME


&Scoped-define SELF-NAME mi_Suche_nach_Kunden-Teilenumme
&ANALYZE-SUSPEND _UIB-CODE-BLOCK _CONTROL mi_Suche_nach_Kunden-Teilenumme B-table-Win
ON VALUE-CHANGED OF MENU-ITEM mi_Suche_nach_Kunden-Teilenumme /* Suche nach Kunden-Teilenummer */
DO:
  {adm/template/incl/dt_uit00.if
     &UserExitName = "ON_VALUE-CHANGED_OF_mi_Suche_nach_Kunden-Teilenumme"}

  if self:checked = yes then
  do:

    assign
      {setwidgetattr
         "menu-item mi_Suche_nach_EAN-Nummer"
         "checked"
         "no"
         "in menu POPUP-MENU-gcSuche"}
      {setwidgetattr
         "menu-item mi_Suche_nach_Selektion"
         "checked"
         "no"
         "in menu POPUP-MENU-gcSuche"}
      {setwidgetattr
         "menu-item mi_Suche_nach_SortierBez"
         "checked"
         "no"
         "in menu POPUP-MENU-gcSuche"}
      {setwidgetattr
         "menu-item mi_Suche_nach_Suchbegriff"
         "checked"
         "no"
         "in menu POPUP-MENU-gcSuche"}
      .

  end.
  else
  do:

    {setwidgetattr
       "self"
       "checked"
       "yes"}.

  end.

  giSuchfeld = 1.

  adm.config.cls.DCCAppConfigSvc:prpoInstance:setParameterValue
    ('VB_SalesDocLineSearchField':U,
     giSuchfeld).

  {adm/template/incl/dt_uit01.if
     &UserExitName = "ON_VALUE-CHANGED_OF_mi_Suche_nach_Kunden-Teilenumme"}
END.

/* _UIB-CODE-BLOCK-END */
&ANALYZE-RESUME


&Scoped-define SELF-NAME mi_Suche_nach_Selektion
&ANALYZE-SUSPEND _UIB-CODE-BLOCK _CONTROL mi_Suche_nach_Selektion B-table-Win
ON VALUE-CHANGED OF MENU-ITEM mi_Suche_nach_Selektion /* Suche nach Selektion */
DO:
  {adm/template/incl/dt_uit00.if
     &UserExitName = "ON_VALUE-CHANGED_OF_mi_Suche_nach_Selektion"}

  if self:checked = yes then
  do:

    assign
      {setwidgetattr
         "menu-item mi_Suche_nach_EAN-Nummer"
         "checked"
         "no"
         "in menu POPUP-MENU-gcSuche"}
      {setwidgetattr
         "menu-item mi_Suche_nach_Kunden-Teilenumme"
         "checked"
         "no"
         "in menu POPUP-MENU-gcSuche"}
      {setwidgetattr
         "menu-item mi_Suche_nach_SortierBez"
         "checked"
         "no"
         "in menu POPUP-MENU-gcSuche"}
      {setwidgetattr
         "menu-item mi_Suche_nach_Suchbegriff"
         "checked"
         "no"
         "in menu POPUP-MENU-gcSuche"}
      .

  end.
  else
  do:

    {setwidgetattr
       "self"
       "checked"
       "yes"}.

  end.

  giSuchfeld = 4.

  adm.config.cls.DCCAppConfigSvc:prpoInstance:setParameterValue
    ('VB_SalesDocLineSearchField':U,
     giSuchfeld).

  {adm/template/incl/dt_uit01.if
     &UserExitName = "ON_VALUE-CHANGED_OF_mi_Suche_nach_Selektion"}
END.

/* _UIB-CODE-BLOCK-END */
&ANALYZE-RESUME


&Scoped-define SELF-NAME mi_Suche_nach_SortierBez
&ANALYZE-SUSPEND _UIB-CODE-BLOCK _CONTROL mi_Suche_nach_SortierBez B-table-Win
ON VALUE-CHANGED OF MENU-ITEM mi_Suche_nach_SortierBez /* Suche nach Sortierbezeichnung */
DO:
  {adm/template/incl/dt_uit00.if
     &UserExitName = "ON_VALUE-CHANGED_OF_mi_Suche_nach_SortierBez"}

  if self:checked = yes then
  do:

    assign
      {setwidgetattr
         "menu-item mi_Suche_nach_EAN-Nummer"
         "checked"
         "no"
         "in menu POPUP-MENU-gcSuche"}
      {setwidgetattr
         "menu-item mi_Suche_nach_Selektion"
         "checked"
         "no"
         "in menu POPUP-MENU-gcSuche"}
      {setwidgetattr
         "menu-item mi_Suche_nach_Kunden-Teilenumme"
         "checked"
         "no"
         "in menu POPUP-MENU-gcSuche"}
      {setwidgetattr
         "menu-item mi_Suche_nach_Suchbegriff"
         "checked"
         "no"
         "in menu POPUP-MENU-gcSuche"}
      .

  end.
  else
  do:

    {setwidgetattr
       "self"
       "checked"
       "yes"}.

  end.

  giSuchfeld = 5.

  adm.config.cls.DCCAppConfigSvc:prpoInstance:setParameterValue
    ('VB_SalesDocLineSearchField':U,
     giSuchfeld).

  {adm/template/incl/dt_uit01.if
     &UserExitName = "ON_VALUE-CHANGED_OF_mi_Suche_nach_SortierBez"}
END.

/* _UIB-CODE-BLOCK-END */
&ANALYZE-RESUME


&Scoped-define SELF-NAME mi_Suche_nach_Suchbegriff
&ANALYZE-SUSPEND _UIB-CODE-BLOCK _CONTROL mi_Suche_nach_Suchbegriff B-table-Win
ON VALUE-CHANGED OF MENU-ITEM mi_Suche_nach_Suchbegriff /* Suche nach Suchbegriff */
DO:
  {adm/template/incl/dt_uit00.if
     &UserExitName = "ON_VALUE-CHANGED_OF_mi_Suche_nach_Suchbegriff"}

  if self:checked = yes then
  do:

    assign
      {setwidgetattr
         "menu-item mi_Suche_nach_EAN-Nummer"
         "checked"
         "no"
         "in menu POPUP-MENU-gcSuche"}
      {setwidgetattr
         "menu-item mi_Suche_nach_Selektion"
         "checked"
         "no"
         "in menu POPUP-MENU-gcSuche"}
      {setwidgetattr
         "menu-item mi_Suche_nach_SortierBez"
         "checked"
         "no"
         "in menu POPUP-MENU-gcSuche"}
      {setwidgetattr
         "menu-item mi_Suche_nach_Kunden-Teilenumme"
         "checked"
         "no"
         "in menu POPUP-MENU-gcSuche"}
      .

  end.
  else
  do:

    {setwidgetattr
       "self"
       "checked"
       "yes"}.

  end.

  giSuchfeld = 3.

  adm.config.cls.DCCAppConfigSvc:prpoInstance:setParameterValue
    ('VB_SalesDocLineSearchField':U,
     giSuchfeld).

  {adm/template/incl/dt_uit01.if
     &UserExitName = "ON_VALUE-CHANGED_OF_mi_Suche_nach_Suchbegriff"}
END.

/* _UIB-CODE-BLOCK-END */
&ANALYZE-RESUME


&UNDEFINE SELF-NAME

&ANALYZE-SUSPEND _UIB-CODE-BLOCK _CUSTOM _MAIN-BLOCK B-table-Win 


/* ***************************  Main Block  *************************** */

{adm/template/incl/dt_brw00.i}

/* _UIB-CODE-BLOCK-END */
&ANALYZE-RESUME


/* **********************  Internal Procedures  *********************** */

&ANALYZE-SUSPEND _UIB-CODE-BLOCK _PROCEDURE adm-open-query-cases B-table-Win  adm/support/proc/ds_opn00.p
PROCEDURE adm-open-query-cases :
/* Description ---------------------------------------------------------------*/
/*                                                                            */
/* Opens different cases of the query based on attributes such as the         */
/* 'Key-Name', or 'SortBy-Case'                                               */
/*                                                                            */
/* Parameters ----------------------------------------------------------------*/
/*                                                                            */
/* <none>                                                                     */
/*                                                                            */
/*----------------------------------------------------------------------------*/

/*----------------------------------------------------------------------------*/
/* Processing                                                                 */
/*----------------------------------------------------------------------------*/

/* Initialize                                                                 */

{adm/template/incl/dt_opn00.if}

/* no "keys-accepted" supported by this procedure                             */

/* Open Query                                                                 */

case pa-sortby-case:
  /* --> MO#HIDR-AH4-1123 thongdi_p 20.07.2026 Erweiterung Versandmonitor im Feld Best. Termin */
  when 'xEbLiefertermin':U then
    if pa-DescendingSortOrder then
      &IF "{&PA-USE-INDEX-IN-QUERY}":U = "1":U &THEN
        &SCOP SORTBY-PHRASE use-index xEbLiefertermin ~{&PA-VIRTUAL-INDEX-DUMMY-SORTBY-PHRASE-DESC} BY ttUV_VersandBeleg.xEbLiefertermin DESCENDING BY ttUV_VersandBeleg.BelegNummer DESCENDING BY ttUV_VersandBeleg.PositionsNr DESCENDING
      &ELSE
        &SCOP SORTBY-PHRASE ~{&PA-VIRTUAL-INDEX-DUMMY-SORTBY-PHRASE-DESC} BY ttUV_VersandBeleg.xEbLiefertermin DESCENDING BY ttUV_VersandBeleg.BelegNummer DESCENDING BY ttUV_VersandBeleg.PositionsNr DESCENDING
      &ENDIF
    &SCOP KEY-PHRASE ttUV_VersandBeleg.xEbLiefertermin {&PA-OFFSET-COMPARE-GE-DESC} date(c_offset-value) {&PA-FILTER-PHRASE}
    if c_offset-value <> ? then
      {&OPEN-QUERY-{&BROWSE-NAME}}
    &SCOP KEY-PHRASE true {&PA-FILTER-PHRASE}
      else
        {&OPEN-QUERY-{&BROWSE-NAME}}

    else
      &IF "{&PA-USE-INDEX-IN-QUERY}":U = "1":U &THEN
        &SCOP SORTBY-PHRASE use-index xEbLiefertermin ~{&PA-VIRTUAL-INDEX-DUMMY-SORTBY-PHRASE} BY ttUV_VersandBeleg.xEbLiefertermin BY ttUV_VersandBeleg.BelegNummer BY ttUV_VersandBeleg.PositionsNr
      &ELSE
        &SCOP SORTBY-PHRASE ~{&PA-VIRTUAL-INDEX-DUMMY-SORTBY-PHRASE} BY ttUV_VersandBeleg.xEbLiefertermin BY ttUV_VersandBeleg.BelegNummer BY ttUV_VersandBeleg.PositionsNr
      &ENDIF
      &SCOP KEY-PHRASE ttUV_VersandBeleg.xEbLiefertermin {&PA-OFFSET-COMPARE-GE-ASC} date(c_offset-value) {&PA-FILTER-PHRASE}
      if c_offset-value <> ? then
        {&OPEN-QUERY-{&BROWSE-NAME}}
      &SCOP KEY-PHRASE true {&PA-FILTER-PHRASE}
      else
        {&OPEN-QUERY-{&BROWSE-NAME}}
  /* <-- MO#HIDR-AH4-1123 thongdi_p 20.07.2026 Erweiterung Versandmonitor im Feld Best. Termin */ 
      
  when 'Konto':U then
    if pa-DescendingSortOrder then
      &IF "{&PA-USE-INDEX-IN-QUERY}":U = "1":U &THEN
        &SCOP SORTBY-PHRASE use-index Konto ~{&PA-VIRTUAL-INDEX-DUMMY-SORTBY-PHRASE-DESC} BY ttUV_VersandBeleg.Konto DESCENDING BY ttUV_VersandBeleg.BelegNummer DESCENDING BY ttUV_VersandBeleg.PositionsNr DESCENDING
      &ELSE
        &SCOP SORTBY-PHRASE ~{&PA-VIRTUAL-INDEX-DUMMY-SORTBY-PHRASE-DESC} BY ttUV_VersandBeleg.Konto DESCENDING BY ttUV_VersandBeleg.BelegNummer DESCENDING BY ttUV_VersandBeleg.PositionsNr DESCENDING
      &ENDIF
    &SCOP KEY-PHRASE ttUV_VersandBeleg.Konto {&PA-OFFSET-COMPARE-GE-DESC} integer(c_offset-value) {&PA-FILTER-PHRASE}
    if c_offset-value <> ? then
      {&OPEN-QUERY-{&BROWSE-NAME}}
    &SCOP KEY-PHRASE true {&PA-FILTER-PHRASE}
      else
        {&OPEN-QUERY-{&BROWSE-NAME}}

    else
      &IF "{&PA-USE-INDEX-IN-QUERY}":U = "1":U &THEN
        &SCOP SORTBY-PHRASE use-index Konto ~{&PA-VIRTUAL-INDEX-DUMMY-SORTBY-PHRASE} BY ttUV_VersandBeleg.Konto BY ttUV_VersandBeleg.BelegNummer BY ttUV_VersandBeleg.PositionsNr
      &ELSE
        &SCOP SORTBY-PHRASE ~{&PA-VIRTUAL-INDEX-DUMMY-SORTBY-PHRASE} BY ttUV_VersandBeleg.Konto BY ttUV_VersandBeleg.BelegNummer BY ttUV_VersandBeleg.PositionsNr
      &ENDIF
      &SCOP KEY-PHRASE ttUV_VersandBeleg.Konto {&PA-OFFSET-COMPARE-GE-ASC} integer(c_offset-value) {&PA-FILTER-PHRASE}
      if c_offset-value <> ? then
        {&OPEN-QUERY-{&BROWSE-NAME}}
      &SCOP KEY-PHRASE true {&PA-FILTER-PHRASE}
      else
        {&OPEN-QUERY-{&BROWSE-NAME}}

  when 'Konto_Suchbegriff':U then
    if pa-DescendingSortOrder then
      &IF "{&PA-USE-INDEX-IN-QUERY}":U = "1":U &THEN
        &SCOP SORTBY-PHRASE use-index Konto_Suchbegriff ~{&PA-VIRTUAL-INDEX-DUMMY-SORTBY-PHRASE-DESC} BY ttUV_VersandBeleg.Konto_Suchbegriff DESCENDING BY ttUV_VersandBeleg.Konto DESCENDING BY ttUV_VersandBeleg.BelegNummer DESCENDING BY ttUV_VersandBeleg.PositionsNr DESCENDING
      &ELSE
        &SCOP SORTBY-PHRASE ~{&PA-VIRTUAL-INDEX-DUMMY-SORTBY-PHRASE-DESC} BY ttUV_VersandBeleg.Konto_Suchbegriff DESCENDING BY ttUV_VersandBeleg.Konto DESCENDING BY ttUV_VersandBeleg.BelegNummer DESCENDING BY ttUV_VersandBeleg.PositionsNr DESCENDING
      &ENDIF
    &SCOP KEY-PHRASE ttUV_VersandBeleg.Konto_Suchbegriff {&PA-OFFSET-COMPARE-GE-DESC} c_offset-value {&PA-FILTER-PHRASE}
    if c_offset-value <> ? then
      {&OPEN-QUERY-{&BROWSE-NAME}}
    &SCOP KEY-PHRASE true {&PA-FILTER-PHRASE}
      else
        {&OPEN-QUERY-{&BROWSE-NAME}}

    else
      &IF "{&PA-USE-INDEX-IN-QUERY}":U = "1":U &THEN
        &SCOP SORTBY-PHRASE use-index Konto_Suchbegriff ~{&PA-VIRTUAL-INDEX-DUMMY-SORTBY-PHRASE} BY ttUV_VersandBeleg.Konto_Suchbegriff BY ttUV_VersandBeleg.Konto BY ttUV_VersandBeleg.BelegNummer BY ttUV_VersandBeleg.PositionsNr
      &ELSE
        &SCOP SORTBY-PHRASE ~{&PA-VIRTUAL-INDEX-DUMMY-SORTBY-PHRASE} BY ttUV_VersandBeleg.Konto_Suchbegriff BY ttUV_VersandBeleg.Konto BY ttUV_VersandBeleg.BelegNummer BY ttUV_VersandBeleg.PositionsNr
      &ENDIF
      &SCOP KEY-PHRASE ttUV_VersandBeleg.Konto_Suchbegriff {&PA-OFFSET-COMPARE-GE-ASC} c_offset-value {&PA-FILTER-PHRASE}
      if c_offset-value <> ? then
        {&OPEN-QUERY-{&BROWSE-NAME}}
      &SCOP KEY-PHRASE true {&PA-FILTER-PHRASE}
      else
        {&OPEN-QUERY-{&BROWSE-NAME}}

  when 'Konto_Selektion':U then
    if pa-DescendingSortOrder then
      &IF "{&PA-USE-INDEX-IN-QUERY}":U = "1":U &THEN
        &SCOP SORTBY-PHRASE use-index Konto_Selektion ~{&PA-VIRTUAL-INDEX-DUMMY-SORTBY-PHRASE-DESC} BY ttUV_VersandBeleg.Konto_Selektion DESCENDING BY ttUV_VersandBeleg.Konto DESCENDING BY ttUV_VersandBeleg.BelegNummer DESCENDING BY ttUV_VersandBeleg.PositionsNr DESCENDING
      &ELSE
        &SCOP SORTBY-PHRASE ~{&PA-VIRTUAL-INDEX-DUMMY-SORTBY-PHRASE-DESC} BY ttUV_VersandBeleg.Konto_Selektion DESCENDING BY ttUV_VersandBeleg.Konto DESCENDING BY ttUV_VersandBeleg.BelegNummer DESCENDING BY ttUV_VersandBeleg.PositionsNr DESCENDING
      &ENDIF
    &SCOP KEY-PHRASE ttUV_VersandBeleg.Konto_Selektion {&PA-OFFSET-COMPARE-GE-DESC} c_offset-value {&PA-FILTER-PHRASE}
    if c_offset-value <> ? then
      {&OPEN-QUERY-{&BROWSE-NAME}}
    &SCOP KEY-PHRASE true {&PA-FILTER-PHRASE}
      else
        {&OPEN-QUERY-{&BROWSE-NAME}}

    else
      &IF "{&PA-USE-INDEX-IN-QUERY}":U = "1":U &THEN
        &SCOP SORTBY-PHRASE use-index Konto_Selektion ~{&PA-VIRTUAL-INDEX-DUMMY-SORTBY-PHRASE} BY ttUV_VersandBeleg.Konto_Selektion BY ttUV_VersandBeleg.Konto BY ttUV_VersandBeleg.BelegNummer BY ttUV_VersandBeleg.PositionsNr
      &ELSE
        &SCOP SORTBY-PHRASE ~{&PA-VIRTUAL-INDEX-DUMMY-SORTBY-PHRASE} BY ttUV_VersandBeleg.Konto_Selektion BY ttUV_VersandBeleg.Konto BY ttUV_VersandBeleg.BelegNummer BY ttUV_VersandBeleg.PositionsNr
      &ENDIF
      &SCOP KEY-PHRASE ttUV_VersandBeleg.Konto_Selektion {&PA-OFFSET-COMPARE-GE-ASC} c_offset-value {&PA-FILTER-PHRASE}
      if c_offset-value <> ? then
        {&OPEN-QUERY-{&BROWSE-NAME}}
      &SCOP KEY-PHRASE true {&PA-FILTER-PHRASE}
      else
        {&OPEN-QUERY-{&BROWSE-NAME}}

  when 'Konto_Branche':U then
    if pa-DescendingSortOrder then
      &IF "{&PA-USE-INDEX-IN-QUERY}":U = "1":U &THEN
        &SCOP SORTBY-PHRASE use-index Konto_Branche ~{&PA-VIRTUAL-INDEX-DUMMY-SORTBY-PHRASE-DESC} BY ttUV_VersandBeleg.Konto_Branche DESCENDING BY ttUV_VersandBeleg.Konto DESCENDING BY ttUV_VersandBeleg.BelegNummer DESCENDING BY ttUV_VersandBeleg.PositionsNr DESCENDING
      &ELSE
        &SCOP SORTBY-PHRASE ~{&PA-VIRTUAL-INDEX-DUMMY-SORTBY-PHRASE-DESC} BY ttUV_VersandBeleg.Konto_Branche DESCENDING BY ttUV_VersandBeleg.Konto DESCENDING BY ttUV_VersandBeleg.BelegNummer DESCENDING BY ttUV_VersandBeleg.PositionsNr DESCENDING
      &ENDIF
    &SCOP KEY-PHRASE ttUV_VersandBeleg.Konto_Branche {&PA-OFFSET-COMPARE-GE-DESC} c_offset-value {&PA-FILTER-PHRASE}
    if c_offset-value <> ? then
      {&OPEN-QUERY-{&BROWSE-NAME}}
    &SCOP KEY-PHRASE true {&PA-FILTER-PHRASE}
      else
        {&OPEN-QUERY-{&BROWSE-NAME}}

    else
      &IF "{&PA-USE-INDEX-IN-QUERY}":U = "1":U &THEN
        &SCOP SORTBY-PHRASE use-index Konto_Branche ~{&PA-VIRTUAL-INDEX-DUMMY-SORTBY-PHRASE} BY ttUV_VersandBeleg.Konto_Branche BY ttUV_VersandBeleg.Konto BY ttUV_VersandBeleg.BelegNummer BY ttUV_VersandBeleg.PositionsNr
      &ELSE
        &SCOP SORTBY-PHRASE ~{&PA-VIRTUAL-INDEX-DUMMY-SORTBY-PHRASE} BY ttUV_VersandBeleg.Konto_Branche BY ttUV_VersandBeleg.Konto BY ttUV_VersandBeleg.BelegNummer BY ttUV_VersandBeleg.PositionsNr
      &ENDIF
      &SCOP KEY-PHRASE ttUV_VersandBeleg.Konto_Branche {&PA-OFFSET-COMPARE-GE-ASC} c_offset-value {&PA-FILTER-PHRASE}
      if c_offset-value <> ? then
        {&OPEN-QUERY-{&BROWSE-NAME}}
      &SCOP KEY-PHRASE true {&PA-FILTER-PHRASE}
      else
        {&OPEN-QUERY-{&BROWSE-NAME}}

  when 'Konto_Region':U then
    if pa-DescendingSortOrder then
      &IF "{&PA-USE-INDEX-IN-QUERY}":U = "1":U &THEN
        &SCOP SORTBY-PHRASE use-index Konto_Region ~{&PA-VIRTUAL-INDEX-DUMMY-SORTBY-PHRASE-DESC} BY ttUV_VersandBeleg.Konto_Region DESCENDING BY ttUV_VersandBeleg.Konto DESCENDING BY ttUV_VersandBeleg.BelegNummer DESCENDING BY ttUV_VersandBeleg.PositionsNr DESCENDING
      &ELSE
        &SCOP SORTBY-PHRASE ~{&PA-VIRTUAL-INDEX-DUMMY-SORTBY-PHRASE-DESC} BY ttUV_VersandBeleg.Konto_Region DESCENDING BY ttUV_VersandBeleg.Konto DESCENDING BY ttUV_VersandBeleg.BelegNummer DESCENDING BY ttUV_VersandBeleg.PositionsNr DESCENDING
      &ENDIF
    &SCOP KEY-PHRASE ttUV_VersandBeleg.Konto_Region {&PA-OFFSET-COMPARE-GE-DESC} c_offset-value {&PA-FILTER-PHRASE}
    if c_offset-value <> ? then
      {&OPEN-QUERY-{&BROWSE-NAME}}
    &SCOP KEY-PHRASE true {&PA-FILTER-PHRASE}
      else
        {&OPEN-QUERY-{&BROWSE-NAME}}

    else
      &IF "{&PA-USE-INDEX-IN-QUERY}":U = "1":U &THEN
        &SCOP SORTBY-PHRASE use-index Konto_Region ~{&PA-VIRTUAL-INDEX-DUMMY-SORTBY-PHRASE} BY ttUV_VersandBeleg.Konto_Region BY ttUV_VersandBeleg.Konto BY ttUV_VersandBeleg.BelegNummer BY ttUV_VersandBeleg.PositionsNr
      &ELSE
        &SCOP SORTBY-PHRASE ~{&PA-VIRTUAL-INDEX-DUMMY-SORTBY-PHRASE} BY ttUV_VersandBeleg.Konto_Region BY ttUV_VersandBeleg.Konto BY ttUV_VersandBeleg.BelegNummer BY ttUV_VersandBeleg.PositionsNr
      &ENDIF
      &SCOP KEY-PHRASE ttUV_VersandBeleg.Konto_Region {&PA-OFFSET-COMPARE-GE-ASC} c_offset-value {&PA-FILTER-PHRASE}
      if c_offset-value <> ? then
        {&OPEN-QUERY-{&BROWSE-NAME}}
      &SCOP KEY-PHRASE true {&PA-FILTER-PHRASE}
      else
        {&OPEN-QUERY-{&BROWSE-NAME}}

  when 'Belegart':U then
    if pa-DescendingSortOrder then
      &IF "{&PA-USE-INDEX-IN-QUERY}":U = "1":U &THEN
        &SCOP SORTBY-PHRASE use-index Belegart ~{&PA-VIRTUAL-INDEX-DUMMY-SORTBY-PHRASE-DESC} BY ttUV_VersandBeleg.Belegart DESCENDING BY ttUV_VersandBeleg.BelegNummer DESCENDING BY ttUV_VersandBeleg.PositionsNr DESCENDING
      &ELSE
        &SCOP SORTBY-PHRASE ~{&PA-VIRTUAL-INDEX-DUMMY-SORTBY-PHRASE-DESC} BY ttUV_VersandBeleg.Belegart DESCENDING BY ttUV_VersandBeleg.BelegNummer DESCENDING BY ttUV_VersandBeleg.PositionsNr DESCENDING
      &ENDIF
    &SCOP KEY-PHRASE ttUV_VersandBeleg.Belegart {&PA-OFFSET-COMPARE-GE-DESC} c_offset-value {&PA-FILTER-PHRASE}
    if c_offset-value <> ? then
      {&OPEN-QUERY-{&BROWSE-NAME}}
    &SCOP KEY-PHRASE true {&PA-FILTER-PHRASE}
      else
        {&OPEN-QUERY-{&BROWSE-NAME}}

    else
      &IF "{&PA-USE-INDEX-IN-QUERY}":U = "1":U &THEN
        &SCOP SORTBY-PHRASE use-index Belegart ~{&PA-VIRTUAL-INDEX-DUMMY-SORTBY-PHRASE} BY ttUV_VersandBeleg.Belegart BY ttUV_VersandBeleg.BelegNummer BY ttUV_VersandBeleg.PositionsNr
      &ELSE
        &SCOP SORTBY-PHRASE ~{&PA-VIRTUAL-INDEX-DUMMY-SORTBY-PHRASE} BY ttUV_VersandBeleg.Belegart BY ttUV_VersandBeleg.BelegNummer BY ttUV_VersandBeleg.PositionsNr
      &ENDIF
      &SCOP KEY-PHRASE ttUV_VersandBeleg.Belegart {&PA-OFFSET-COMPARE-GE-ASC} c_offset-value {&PA-FILTER-PHRASE}
      if c_offset-value <> ? then
        {&OPEN-QUERY-{&BROWSE-NAME}}
      &SCOP KEY-PHRASE true {&PA-FILTER-PHRASE}
      else
        {&OPEN-QUERY-{&BROWSE-NAME}}

  when 'BelegartBez':U then
    if pa-DescendingSortOrder then
      &IF "{&PA-USE-INDEX-IN-QUERY}":U = "1":U &THEN
        &SCOP SORTBY-PHRASE use-index BelegartBez ~{&PA-VIRTUAL-INDEX-DUMMY-SORTBY-PHRASE-DESC} BY ttUV_VersandBeleg.BelegartBez DESCENDING BY ttUV_VersandBeleg.Belegart DESCENDING BY ttUV_VersandBeleg.BelegNummer DESCENDING BY ttUV_VersandBeleg.PositionsNr DESCENDING
      &ELSE
        &SCOP SORTBY-PHRASE ~{&PA-VIRTUAL-INDEX-DUMMY-SORTBY-PHRASE-DESC} BY ttUV_VersandBeleg.BelegartBez DESCENDING BY ttUV_VersandBeleg.Belegart DESCENDING BY ttUV_VersandBeleg.BelegNummer DESCENDING BY ttUV_VersandBeleg.PositionsNr DESCENDING
      &ENDIF
    &SCOP KEY-PHRASE ttUV_VersandBeleg.BelegartBez {&PA-OFFSET-COMPARE-GE-DESC} c_offset-value {&PA-FILTER-PHRASE}
    if c_offset-value <> ? then
      {&OPEN-QUERY-{&BROWSE-NAME}}
    &SCOP KEY-PHRASE true {&PA-FILTER-PHRASE}
      else
        {&OPEN-QUERY-{&BROWSE-NAME}}

    else
      &IF "{&PA-USE-INDEX-IN-QUERY}":U = "1":U &THEN
        &SCOP SORTBY-PHRASE use-index BelegartBez ~{&PA-VIRTUAL-INDEX-DUMMY-SORTBY-PHRASE} BY ttUV_VersandBeleg.BelegartBez BY ttUV_VersandBeleg.Belegart BY ttUV_VersandBeleg.BelegNummer BY ttUV_VersandBeleg.PositionsNr
      &ELSE
        &SCOP SORTBY-PHRASE ~{&PA-VIRTUAL-INDEX-DUMMY-SORTBY-PHRASE} BY ttUV_VersandBeleg.BelegartBez BY ttUV_VersandBeleg.Belegart BY ttUV_VersandBeleg.BelegNummer BY ttUV_VersandBeleg.PositionsNr
      &ENDIF
      &SCOP KEY-PHRASE ttUV_VersandBeleg.BelegartBez {&PA-OFFSET-COMPARE-GE-ASC} c_offset-value {&PA-FILTER-PHRASE}
      if c_offset-value <> ? then
        {&OPEN-QUERY-{&BROWSE-NAME}}
      &SCOP KEY-PHRASE true {&PA-FILTER-PHRASE}
      else
        {&OPEN-QUERY-{&BROWSE-NAME}}

  when 'BelegNummer':U then
    if pa-DescendingSortOrder then
      &IF "{&PA-USE-INDEX-IN-QUERY}":U = "1":U &THEN
        &SCOP SORTBY-PHRASE use-index BelegNummer ~{&PA-VIRTUAL-INDEX-DUMMY-SORTBY-PHRASE-DESC} BY ttUV_VersandBeleg.BelegNummer DESCENDING BY ttUV_VersandBeleg.PositionsNr DESCENDING
      &ELSE
        &SCOP SORTBY-PHRASE ~{&PA-VIRTUAL-INDEX-DUMMY-SORTBY-PHRASE-DESC} BY ttUV_VersandBeleg.BelegNummer DESCENDING BY ttUV_VersandBeleg.PositionsNr DESCENDING
      &ENDIF
    &SCOP KEY-PHRASE ttUV_VersandBeleg.BelegNummer {&PA-OFFSET-COMPARE-GE-DESC} integer(c_offset-value) {&PA-FILTER-PHRASE}
    if c_offset-value <> ? then
      {&OPEN-QUERY-{&BROWSE-NAME}}
    &SCOP KEY-PHRASE true {&PA-FILTER-PHRASE}
      else
        {&OPEN-QUERY-{&BROWSE-NAME}}

    else
      &IF "{&PA-USE-INDEX-IN-QUERY}":U = "1":U &THEN
        &SCOP SORTBY-PHRASE use-index BelegNummer ~{&PA-VIRTUAL-INDEX-DUMMY-SORTBY-PHRASE} BY ttUV_VersandBeleg.BelegNummer BY ttUV_VersandBeleg.PositionsNr
      &ELSE
        &SCOP SORTBY-PHRASE ~{&PA-VIRTUAL-INDEX-DUMMY-SORTBY-PHRASE} BY ttUV_VersandBeleg.BelegNummer BY ttUV_VersandBeleg.PositionsNr
      &ENDIF
      &SCOP KEY-PHRASE ttUV_VersandBeleg.BelegNummer {&PA-OFFSET-COMPARE-GE-ASC} integer(c_offset-value) {&PA-FILTER-PHRASE}
      if c_offset-value <> ? then
        {&OPEN-QUERY-{&BROWSE-NAME}}
      &SCOP KEY-PHRASE true {&PA-FILTER-PHRASE}
      else
        {&OPEN-QUERY-{&BROWSE-NAME}}

  when 'BelegInfo':U then
    if pa-DescendingSortOrder then
      &IF "{&PA-USE-INDEX-IN-QUERY}":U = "1":U &THEN
        &SCOP SORTBY-PHRASE use-index BelegInfo ~{&PA-VIRTUAL-INDEX-DUMMY-SORTBY-PHRASE-DESC} BY ttUV_VersandBeleg.BelegInfo DESCENDING BY ttUV_VersandBeleg.BelegNummer DESCENDING BY ttUV_VersandBeleg.PositionsNr DESCENDING
      &ELSE
        &SCOP SORTBY-PHRASE ~{&PA-VIRTUAL-INDEX-DUMMY-SORTBY-PHRASE-DESC} BY ttUV_VersandBeleg.BelegInfo DESCENDING BY ttUV_VersandBeleg.BelegNummer DESCENDING BY ttUV_VersandBeleg.PositionsNr DESCENDING
      &ENDIF
    &SCOP KEY-PHRASE ttUV_VersandBeleg.BelegInfo {&PA-OFFSET-COMPARE-GE-DESC} c_offset-value {&PA-FILTER-PHRASE}
    if c_offset-value <> ? then
      {&OPEN-QUERY-{&BROWSE-NAME}}
    &SCOP KEY-PHRASE true {&PA-FILTER-PHRASE}
      else
        {&OPEN-QUERY-{&BROWSE-NAME}}

    else
      &IF "{&PA-USE-INDEX-IN-QUERY}":U = "1":U &THEN
        &SCOP SORTBY-PHRASE use-index BelegInfo ~{&PA-VIRTUAL-INDEX-DUMMY-SORTBY-PHRASE} BY ttUV_VersandBeleg.BelegInfo BY ttUV_VersandBeleg.BelegNummer BY ttUV_VersandBeleg.PositionsNr
      &ELSE
        &SCOP SORTBY-PHRASE ~{&PA-VIRTUAL-INDEX-DUMMY-SORTBY-PHRASE} BY ttUV_VersandBeleg.BelegInfo BY ttUV_VersandBeleg.BelegNummer BY ttUV_VersandBeleg.PositionsNr
      &ENDIF
      &SCOP KEY-PHRASE ttUV_VersandBeleg.BelegInfo {&PA-OFFSET-COMPARE-GE-ASC} c_offset-value {&PA-FILTER-PHRASE}
      if c_offset-value <> ? then
        {&OPEN-QUERY-{&BROWSE-NAME}}
      &SCOP KEY-PHRASE true {&PA-FILTER-PHRASE}
      else
        {&OPEN-QUERY-{&BROWSE-NAME}}

  when 'Auftrag':U then
    if pa-DescendingSortOrder then
      &IF "{&PA-USE-INDEX-IN-QUERY}":U = "1":U &THEN
        &SCOP SORTBY-PHRASE use-index Auftrag ~{&PA-VIRTUAL-INDEX-DUMMY-SORTBY-PHRASE-DESC} BY ttUV_VersandBeleg.Auftrag DESCENDING BY ttUV_VersandBeleg.BelegNummer DESCENDING BY ttUV_VersandBeleg.PositionsNr DESCENDING
      &ELSE
        &SCOP SORTBY-PHRASE ~{&PA-VIRTUAL-INDEX-DUMMY-SORTBY-PHRASE-DESC} BY ttUV_VersandBeleg.Auftrag DESCENDING BY ttUV_VersandBeleg.BelegNummer DESCENDING BY ttUV_VersandBeleg.PositionsNr DESCENDING
      &ENDIF
    &SCOP KEY-PHRASE ttUV_VersandBeleg.Auftrag {&PA-OFFSET-COMPARE-GE-DESC} c_offset-value {&PA-FILTER-PHRASE}
    if c_offset-value <> ? then
      {&OPEN-QUERY-{&BROWSE-NAME}}
    &SCOP KEY-PHRASE true {&PA-FILTER-PHRASE}
      else
        {&OPEN-QUERY-{&BROWSE-NAME}}

    else
      &IF "{&PA-USE-INDEX-IN-QUERY}":U = "1":U &THEN
        &SCOP SORTBY-PHRASE use-index Auftrag ~{&PA-VIRTUAL-INDEX-DUMMY-SORTBY-PHRASE} BY ttUV_VersandBeleg.Auftrag BY ttUV_VersandBeleg.BelegNummer BY ttUV_VersandBeleg.PositionsNr
      &ELSE
        &SCOP SORTBY-PHRASE ~{&PA-VIRTUAL-INDEX-DUMMY-SORTBY-PHRASE} BY ttUV_VersandBeleg.Auftrag BY ttUV_VersandBeleg.BelegNummer BY ttUV_VersandBeleg.PositionsNr
      &ENDIF
      &SCOP KEY-PHRASE ttUV_VersandBeleg.Auftrag {&PA-OFFSET-COMPARE-GE-ASC} c_offset-value {&PA-FILTER-PHRASE}
      if c_offset-value <> ? then
        {&OPEN-QUERY-{&BROWSE-NAME}}
      &SCOP KEY-PHRASE true {&PA-FILTER-PHRASE}
      else
        {&OPEN-QUERY-{&BROWSE-NAME}}

  when 'Artikelgruppe':U then
    if pa-DescendingSortOrder then
      &IF "{&PA-USE-INDEX-IN-QUERY}":U = "1":U &THEN
        &SCOP SORTBY-PHRASE use-index Artikelgruppe ~{&PA-VIRTUAL-INDEX-DUMMY-SORTBY-PHRASE-DESC} BY ttUV_VersandBeleg.Artikelgruppe DESCENDING BY ttUV_VersandBeleg.Artikel DESCENDING BY ttUV_VersandBeleg.BelegNummer DESCENDING BY ttUV_VersandBeleg.PositionsNr DESCENDING
      &ELSE
        &SCOP SORTBY-PHRASE ~{&PA-VIRTUAL-INDEX-DUMMY-SORTBY-PHRASE-DESC} BY ttUV_VersandBeleg.Artikelgruppe DESCENDING BY ttUV_VersandBeleg.Artikel DESCENDING BY ttUV_VersandBeleg.BelegNummer DESCENDING BY ttUV_VersandBeleg.PositionsNr DESCENDING
      &ENDIF
    &SCOP KEY-PHRASE ttUV_VersandBeleg.Artikelgruppe {&PA-OFFSET-COMPARE-GE-DESC} c_offset-value {&PA-FILTER-PHRASE}
    if c_offset-value <> ? then
      {&OPEN-QUERY-{&BROWSE-NAME}}
    &SCOP KEY-PHRASE true {&PA-FILTER-PHRASE}
      else
        {&OPEN-QUERY-{&BROWSE-NAME}}

    else
      &IF "{&PA-USE-INDEX-IN-QUERY}":U = "1":U &THEN
        &SCOP SORTBY-PHRASE use-index Artikelgruppe ~{&PA-VIRTUAL-INDEX-DUMMY-SORTBY-PHRASE} BY ttUV_VersandBeleg.Artikelgruppe BY ttUV_VersandBeleg.Artikel BY ttUV_VersandBeleg.BelegNummer BY ttUV_VersandBeleg.PositionsNr
      &ELSE
        &SCOP SORTBY-PHRASE ~{&PA-VIRTUAL-INDEX-DUMMY-SORTBY-PHRASE} BY ttUV_VersandBeleg.Artikelgruppe BY ttUV_VersandBeleg.Artikel BY ttUV_VersandBeleg.BelegNummer BY ttUV_VersandBeleg.PositionsNr
      &ENDIF
      &SCOP KEY-PHRASE ttUV_VersandBeleg.Artikelgruppe {&PA-OFFSET-COMPARE-GE-ASC} c_offset-value {&PA-FILTER-PHRASE}
      if c_offset-value <> ? then
        {&OPEN-QUERY-{&BROWSE-NAME}}
      &SCOP KEY-PHRASE true {&PA-FILTER-PHRASE}
      else
        {&OPEN-QUERY-{&BROWSE-NAME}}

  when 'Artikel':U then
    if pa-DescendingSortOrder then
      &IF "{&PA-USE-INDEX-IN-QUERY}":U = "1":U &THEN
        &SCOP SORTBY-PHRASE use-index Artikel ~{&PA-VIRTUAL-INDEX-DUMMY-SORTBY-PHRASE-DESC} BY ttUV_VersandBeleg.Artikel DESCENDING BY ttUV_VersandBeleg.BelegNummer DESCENDING BY ttUV_VersandBeleg.PositionsNr DESCENDING
      &ELSE
        &SCOP SORTBY-PHRASE ~{&PA-VIRTUAL-INDEX-DUMMY-SORTBY-PHRASE-DESC} BY ttUV_VersandBeleg.Artikel DESCENDING BY ttUV_VersandBeleg.BelegNummer DESCENDING BY ttUV_VersandBeleg.PositionsNr DESCENDING
      &ENDIF
    &SCOP KEY-PHRASE ttUV_VersandBeleg.Artikel {&PA-OFFSET-COMPARE-GE-DESC} c_offset-value {&PA-FILTER-PHRASE}
    if c_offset-value <> ? then
      {&OPEN-QUERY-{&BROWSE-NAME}}
    &SCOP KEY-PHRASE true {&PA-FILTER-PHRASE}
      else
        {&OPEN-QUERY-{&BROWSE-NAME}}

    else
      &IF "{&PA-USE-INDEX-IN-QUERY}":U = "1":U &THEN
        &SCOP SORTBY-PHRASE use-index Artikel ~{&PA-VIRTUAL-INDEX-DUMMY-SORTBY-PHRASE} BY ttUV_VersandBeleg.Artikel BY ttUV_VersandBeleg.BelegNummer BY ttUV_VersandBeleg.PositionsNr
      &ELSE
        &SCOP SORTBY-PHRASE ~{&PA-VIRTUAL-INDEX-DUMMY-SORTBY-PHRASE} BY ttUV_VersandBeleg.Artikel BY ttUV_VersandBeleg.BelegNummer BY ttUV_VersandBeleg.PositionsNr
      &ENDIF
      &SCOP KEY-PHRASE ttUV_VersandBeleg.Artikel {&PA-OFFSET-COMPARE-GE-ASC} c_offset-value {&PA-FILTER-PHRASE}
      if c_offset-value <> ? then
        {&OPEN-QUERY-{&BROWSE-NAME}}
      &SCOP KEY-PHRASE true {&PA-FILTER-PHRASE}
      else
        {&OPEN-QUERY-{&BROWSE-NAME}}

  when 'Sparte':U then
    if pa-DescendingSortOrder then
      &IF "{&PA-USE-INDEX-IN-QUERY}":U = "1":U &THEN
        &SCOP SORTBY-PHRASE use-index Sparte ~{&PA-VIRTUAL-INDEX-DUMMY-SORTBY-PHRASE-DESC} BY ttUV_VersandBeleg.Sparte DESCENDING BY ttUV_VersandBeleg.Artikel DESCENDING BY ttUV_VersandBeleg.BelegNummer DESCENDING BY ttUV_VersandBeleg.PositionsNr DESCENDING
      &ELSE
        &SCOP SORTBY-PHRASE ~{&PA-VIRTUAL-INDEX-DUMMY-SORTBY-PHRASE-DESC} BY ttUV_VersandBeleg.Sparte DESCENDING BY ttUV_VersandBeleg.Artikel DESCENDING BY ttUV_VersandBeleg.BelegNummer DESCENDING BY ttUV_VersandBeleg.PositionsNr DESCENDING
      &ENDIF
    &SCOP KEY-PHRASE ttUV_VersandBeleg.Sparte {&PA-OFFSET-COMPARE-GE-DESC} c_offset-value {&PA-FILTER-PHRASE}
    if c_offset-value <> ? then
      {&OPEN-QUERY-{&BROWSE-NAME}}
    &SCOP KEY-PHRASE true {&PA-FILTER-PHRASE}
      else
        {&OPEN-QUERY-{&BROWSE-NAME}}

    else
      &IF "{&PA-USE-INDEX-IN-QUERY}":U = "1":U &THEN
        &SCOP SORTBY-PHRASE use-index Sparte ~{&PA-VIRTUAL-INDEX-DUMMY-SORTBY-PHRASE} BY ttUV_VersandBeleg.Sparte BY ttUV_VersandBeleg.Artikel BY ttUV_VersandBeleg.BelegNummer BY ttUV_VersandBeleg.PositionsNr
      &ELSE
        &SCOP SORTBY-PHRASE ~{&PA-VIRTUAL-INDEX-DUMMY-SORTBY-PHRASE} BY ttUV_VersandBeleg.Sparte BY ttUV_VersandBeleg.Artikel BY ttUV_VersandBeleg.BelegNummer BY ttUV_VersandBeleg.PositionsNr
      &ENDIF
      &SCOP KEY-PHRASE ttUV_VersandBeleg.Sparte {&PA-OFFSET-COMPARE-GE-ASC} c_offset-value {&PA-FILTER-PHRASE}
      if c_offset-value <> ? then
        {&OPEN-QUERY-{&BROWSE-NAME}}
      &SCOP KEY-PHRASE true {&PA-FILTER-PHRASE}
      else
        {&OPEN-QUERY-{&BROWSE-NAME}}

  when 'Artikel_Selektion':U then
    if pa-DescendingSortOrder then
      &IF "{&PA-USE-INDEX-IN-QUERY}":U = "1":U &THEN
        &SCOP SORTBY-PHRASE use-index Artikel_Selektion ~{&PA-VIRTUAL-INDEX-DUMMY-SORTBY-PHRASE-DESC} BY ttUV_VersandBeleg.Artikel_Selektion DESCENDING BY ttUV_VersandBeleg.Artikel DESCENDING BY ttUV_VersandBeleg.BelegNummer DESCENDING BY ttUV_VersandBeleg.PositionsNr DESCENDING
      &ELSE
        &SCOP SORTBY-PHRASE ~{&PA-VIRTUAL-INDEX-DUMMY-SORTBY-PHRASE-DESC} BY ttUV_VersandBeleg.Artikel_Selektion DESCENDING BY ttUV_VersandBeleg.Artikel DESCENDING BY ttUV_VersandBeleg.BelegNummer DESCENDING BY ttUV_VersandBeleg.PositionsNr DESCENDING
      &ENDIF
    &SCOP KEY-PHRASE ttUV_VersandBeleg.Artikel_Selektion {&PA-OFFSET-COMPARE-GE-DESC} c_offset-value {&PA-FILTER-PHRASE}
    if c_offset-value <> ? then
      {&OPEN-QUERY-{&BROWSE-NAME}}
    &SCOP KEY-PHRASE true {&PA-FILTER-PHRASE}
      else
        {&OPEN-QUERY-{&BROWSE-NAME}}

    else
      &IF "{&PA-USE-INDEX-IN-QUERY}":U = "1":U &THEN
        &SCOP SORTBY-PHRASE use-index Artikel_Selektion ~{&PA-VIRTUAL-INDEX-DUMMY-SORTBY-PHRASE} BY ttUV_VersandBeleg.Artikel_Selektion BY ttUV_VersandBeleg.Artikel BY ttUV_VersandBeleg.BelegNummer BY ttUV_VersandBeleg.PositionsNr
      &ELSE
        &SCOP SORTBY-PHRASE ~{&PA-VIRTUAL-INDEX-DUMMY-SORTBY-PHRASE} BY ttUV_VersandBeleg.Artikel_Selektion BY ttUV_VersandBeleg.Artikel BY ttUV_VersandBeleg.BelegNummer BY ttUV_VersandBeleg.PositionsNr
      &ENDIF
      &SCOP KEY-PHRASE ttUV_VersandBeleg.Artikel_Selektion {&PA-OFFSET-COMPARE-GE-ASC} c_offset-value {&PA-FILTER-PHRASE}
      if c_offset-value <> ? then
        {&OPEN-QUERY-{&BROWSE-NAME}}
      &SCOP KEY-PHRASE true {&PA-FILTER-PHRASE}
      else
        {&OPEN-QUERY-{&BROWSE-NAME}}

  when 'Artikel_Suchbegriff':U then
    if pa-DescendingSortOrder then
      &IF "{&PA-USE-INDEX-IN-QUERY}":U = "1":U &THEN
        &SCOP SORTBY-PHRASE use-index Artikel_Suchbegriff ~{&PA-VIRTUAL-INDEX-DUMMY-SORTBY-PHRASE-DESC} BY ttUV_VersandBeleg.Artikel_Suchbegriff DESCENDING BY ttUV_VersandBeleg.Artikel DESCENDING BY ttUV_VersandBeleg.BelegNummer DESCENDING BY ttUV_VersandBeleg.PositionsNr DESCENDING
      &ELSE
        &SCOP SORTBY-PHRASE ~{&PA-VIRTUAL-INDEX-DUMMY-SORTBY-PHRASE-DESC} BY ttUV_VersandBeleg.Artikel_Suchbegriff DESCENDING BY ttUV_VersandBeleg.Artikel DESCENDING BY ttUV_VersandBeleg.BelegNummer DESCENDING BY ttUV_VersandBeleg.PositionsNr DESCENDING
      &ENDIF
    &SCOP KEY-PHRASE ttUV_VersandBeleg.Artikel_Suchbegriff {&PA-OFFSET-COMPARE-GE-DESC} c_offset-value {&PA-FILTER-PHRASE}
    if c_offset-value <> ? then
      {&OPEN-QUERY-{&BROWSE-NAME}}
    &SCOP KEY-PHRASE true {&PA-FILTER-PHRASE}
      else
        {&OPEN-QUERY-{&BROWSE-NAME}}

    else
      &IF "{&PA-USE-INDEX-IN-QUERY}":U = "1":U &THEN
        &SCOP SORTBY-PHRASE use-index Artikel_Suchbegriff ~{&PA-VIRTUAL-INDEX-DUMMY-SORTBY-PHRASE} BY ttUV_VersandBeleg.Artikel_Suchbegriff BY ttUV_VersandBeleg.Artikel BY ttUV_VersandBeleg.BelegNummer BY ttUV_VersandBeleg.PositionsNr
      &ELSE
        &SCOP SORTBY-PHRASE ~{&PA-VIRTUAL-INDEX-DUMMY-SORTBY-PHRASE} BY ttUV_VersandBeleg.Artikel_Suchbegriff BY ttUV_VersandBeleg.Artikel BY ttUV_VersandBeleg.BelegNummer BY ttUV_VersandBeleg.PositionsNr
      &ENDIF
      &SCOP KEY-PHRASE ttUV_VersandBeleg.Artikel_Suchbegriff {&PA-OFFSET-COMPARE-GE-ASC} c_offset-value {&PA-FILTER-PHRASE}
      if c_offset-value <> ? then
        {&OPEN-QUERY-{&BROWSE-NAME}}
      &SCOP KEY-PHRASE true {&PA-FILTER-PHRASE}
      else
        {&OPEN-QUERY-{&BROWSE-NAME}}

  when 'ArtikelArt':U then
    if pa-DescendingSortOrder then
      &IF "{&PA-USE-INDEX-IN-QUERY}":U = "1":U &THEN
        &SCOP SORTBY-PHRASE use-index ArtikelArt ~{&PA-VIRTUAL-INDEX-DUMMY-SORTBY-PHRASE-DESC} BY ttUV_VersandBeleg.ArtikelArt DESCENDING BY ttUV_VersandBeleg.Artikel DESCENDING BY ttUV_VersandBeleg.BelegNummer DESCENDING BY ttUV_VersandBeleg.PositionsNr DESCENDING
      &ELSE
        &SCOP SORTBY-PHRASE ~{&PA-VIRTUAL-INDEX-DUMMY-SORTBY-PHRASE-DESC} BY ttUV_VersandBeleg.ArtikelArt DESCENDING BY ttUV_VersandBeleg.Artikel DESCENDING BY ttUV_VersandBeleg.BelegNummer DESCENDING BY ttUV_VersandBeleg.PositionsNr DESCENDING
      &ENDIF
    &SCOP KEY-PHRASE ttUV_VersandBeleg.ArtikelArt {&PA-OFFSET-COMPARE-GE-DESC} integer(c_offset-value) {&PA-FILTER-PHRASE}
    if c_offset-value <> ? then
      {&OPEN-QUERY-{&BROWSE-NAME}}
    &SCOP KEY-PHRASE true {&PA-FILTER-PHRASE}
      else
        {&OPEN-QUERY-{&BROWSE-NAME}}

    else
      &IF "{&PA-USE-INDEX-IN-QUERY}":U = "1":U &THEN
        &SCOP SORTBY-PHRASE use-index ArtikelArt ~{&PA-VIRTUAL-INDEX-DUMMY-SORTBY-PHRASE} BY ttUV_VersandBeleg.ArtikelArt BY ttUV_VersandBeleg.Artikel BY ttUV_VersandBeleg.BelegNummer BY ttUV_VersandBeleg.PositionsNr
      &ELSE
        &SCOP SORTBY-PHRASE ~{&PA-VIRTUAL-INDEX-DUMMY-SORTBY-PHRASE} BY ttUV_VersandBeleg.ArtikelArt BY ttUV_VersandBeleg.Artikel BY ttUV_VersandBeleg.BelegNummer BY ttUV_VersandBeleg.PositionsNr
      &ENDIF
      &SCOP KEY-PHRASE ttUV_VersandBeleg.ArtikelArt {&PA-OFFSET-COMPARE-GE-ASC} integer(c_offset-value) {&PA-FILTER-PHRASE}
      if c_offset-value <> ? then
        {&OPEN-QUERY-{&BROWSE-NAME}}
      &SCOP KEY-PHRASE true {&PA-FILTER-PHRASE}
      else
        {&OPEN-QUERY-{&BROWSE-NAME}}

  when 'ArtikelNr':U then
    if pa-DescendingSortOrder then
      &IF "{&PA-USE-INDEX-IN-QUERY}":U = "1":U &THEN
        &SCOP SORTBY-PHRASE use-index ArtikelNr ~{&PA-VIRTUAL-INDEX-DUMMY-SORTBY-PHRASE-DESC} BY ttUV_VersandBeleg.ArtikelNr DESCENDING BY ttUV_VersandBeleg.Artikel DESCENDING BY ttUV_VersandBeleg.BelegNummer DESCENDING BY ttUV_VersandBeleg.PositionsNr DESCENDING
      &ELSE
        &SCOP SORTBY-PHRASE ~{&PA-VIRTUAL-INDEX-DUMMY-SORTBY-PHRASE-DESC} BY ttUV_VersandBeleg.ArtikelNr DESCENDING BY ttUV_VersandBeleg.Artikel DESCENDING BY ttUV_VersandBeleg.BelegNummer DESCENDING BY ttUV_VersandBeleg.PositionsNr DESCENDING
      &ENDIF
    &SCOP KEY-PHRASE ttUV_VersandBeleg.ArtikelNr {&PA-OFFSET-COMPARE-GE-DESC} c_offset-value {&PA-FILTER-PHRASE}
    if c_offset-value <> ? then
      {&OPEN-QUERY-{&BROWSE-NAME}}
    &SCOP KEY-PHRASE true {&PA-FILTER-PHRASE}
      else
        {&OPEN-QUERY-{&BROWSE-NAME}}

    else
      &IF "{&PA-USE-INDEX-IN-QUERY}":U = "1":U &THEN
        &SCOP SORTBY-PHRASE use-index ArtikelNr ~{&PA-VIRTUAL-INDEX-DUMMY-SORTBY-PHRASE} BY ttUV_VersandBeleg.ArtikelNr BY ttUV_VersandBeleg.Artikel BY ttUV_VersandBeleg.BelegNummer BY ttUV_VersandBeleg.PositionsNr
      &ELSE
        &SCOP SORTBY-PHRASE ~{&PA-VIRTUAL-INDEX-DUMMY-SORTBY-PHRASE} BY ttUV_VersandBeleg.ArtikelNr BY ttUV_VersandBeleg.Artikel BY ttUV_VersandBeleg.BelegNummer BY ttUV_VersandBeleg.PositionsNr
      &ENDIF
      &SCOP KEY-PHRASE ttUV_VersandBeleg.ArtikelNr {&PA-OFFSET-COMPARE-GE-ASC} c_offset-value {&PA-FILTER-PHRASE}
      if c_offset-value <> ? then
        {&OPEN-QUERY-{&BROWSE-NAME}}
      &SCOP KEY-PHRASE true {&PA-FILTER-PHRASE}
      else
        {&OPEN-QUERY-{&BROWSE-NAME}}

  when 'Wunschtermin':U then
    if pa-DescendingSortOrder then
      &IF "{&PA-USE-INDEX-IN-QUERY}":U = "1":U &THEN
        &SCOP SORTBY-PHRASE use-index Wunschtermin ~{&PA-VIRTUAL-INDEX-DUMMY-SORTBY-PHRASE-DESC} BY ttUV_VersandBeleg.Wunschtermin DESCENDING BY ttUV_VersandBeleg.BelegNummer DESCENDING BY ttUV_VersandBeleg.PositionsNr DESCENDING
      &ELSE
        &SCOP SORTBY-PHRASE ~{&PA-VIRTUAL-INDEX-DUMMY-SORTBY-PHRASE-DESC} BY ttUV_VersandBeleg.Wunschtermin DESCENDING BY ttUV_VersandBeleg.BelegNummer DESCENDING BY ttUV_VersandBeleg.PositionsNr DESCENDING
      &ENDIF
    &SCOP KEY-PHRASE ttUV_VersandBeleg.Wunschtermin {&PA-OFFSET-COMPARE-GE-DESC} date(c_offset-value) {&PA-FILTER-PHRASE}
    if c_offset-value <> ? then
      {&OPEN-QUERY-{&BROWSE-NAME}}
    &SCOP KEY-PHRASE true {&PA-FILTER-PHRASE}
      else
        {&OPEN-QUERY-{&BROWSE-NAME}}

    else
      &IF "{&PA-USE-INDEX-IN-QUERY}":U = "1":U &THEN
        &SCOP SORTBY-PHRASE use-index Wunschtermin ~{&PA-VIRTUAL-INDEX-DUMMY-SORTBY-PHRASE} BY ttUV_VersandBeleg.Wunschtermin BY ttUV_VersandBeleg.BelegNummer BY ttUV_VersandBeleg.PositionsNr
      &ELSE
        &SCOP SORTBY-PHRASE ~{&PA-VIRTUAL-INDEX-DUMMY-SORTBY-PHRASE} BY ttUV_VersandBeleg.Wunschtermin BY ttUV_VersandBeleg.BelegNummer BY ttUV_VersandBeleg.PositionsNr
      &ENDIF
      &SCOP KEY-PHRASE ttUV_VersandBeleg.Wunschtermin {&PA-OFFSET-COMPARE-GE-ASC} date(c_offset-value) {&PA-FILTER-PHRASE}
      if c_offset-value <> ? then
        {&OPEN-QUERY-{&BROWSE-NAME}}
      &SCOP KEY-PHRASE true {&PA-FILTER-PHRASE}
      else
        {&OPEN-QUERY-{&BROWSE-NAME}}

  when 'Liefertermin':U then
    if pa-DescendingSortOrder then
      &IF "{&PA-USE-INDEX-IN-QUERY}":U = "1":U &THEN
        &SCOP SORTBY-PHRASE use-index Liefertermin ~{&PA-VIRTUAL-INDEX-DUMMY-SORTBY-PHRASE-DESC} BY ttUV_VersandBeleg.Liefertermin DESCENDING BY ttUV_VersandBeleg.BelegNummer DESCENDING BY ttUV_VersandBeleg.PositionsNr DESCENDING
      &ELSE
        &SCOP SORTBY-PHRASE ~{&PA-VIRTUAL-INDEX-DUMMY-SORTBY-PHRASE-DESC} BY ttUV_VersandBeleg.Liefertermin DESCENDING BY ttUV_VersandBeleg.BelegNummer DESCENDING BY ttUV_VersandBeleg.PositionsNr DESCENDING
      &ENDIF
    &SCOP KEY-PHRASE ttUV_VersandBeleg.Liefertermin {&PA-OFFSET-COMPARE-GE-DESC} date(c_offset-value) {&PA-FILTER-PHRASE}
    if c_offset-value <> ? then
      {&OPEN-QUERY-{&BROWSE-NAME}}
    &SCOP KEY-PHRASE true {&PA-FILTER-PHRASE}
      else
        {&OPEN-QUERY-{&BROWSE-NAME}}

    else
      &IF "{&PA-USE-INDEX-IN-QUERY}":U = "1":U &THEN
        &SCOP SORTBY-PHRASE use-index Liefertermin ~{&PA-VIRTUAL-INDEX-DUMMY-SORTBY-PHRASE} BY ttUV_VersandBeleg.Liefertermin BY ttUV_VersandBeleg.BelegNummer BY ttUV_VersandBeleg.PositionsNr
      &ELSE
        &SCOP SORTBY-PHRASE ~{&PA-VIRTUAL-INDEX-DUMMY-SORTBY-PHRASE} BY ttUV_VersandBeleg.Liefertermin BY ttUV_VersandBeleg.BelegNummer BY ttUV_VersandBeleg.PositionsNr
      &ENDIF
      &SCOP KEY-PHRASE ttUV_VersandBeleg.Liefertermin {&PA-OFFSET-COMPARE-GE-ASC} date(c_offset-value) {&PA-FILTER-PHRASE}
      if c_offset-value <> ? then
        {&OPEN-QUERY-{&BROWSE-NAME}}
      &SCOP KEY-PHRASE true {&PA-FILTER-PHRASE}
      else
        {&OPEN-QUERY-{&BROWSE-NAME}}
    
  when 'uCI_Warenausgangstermin':U then
    if pa-DescendingSortOrder then
      &IF "{&PA-USE-INDEX-IN-QUERY}":U = "1":U &THEN
        &SCOP SORTBY-PHRASE use-index uCI_Warenausgangstermin ~{&PA-VIRTUAL-INDEX-DUMMY-SORTBY-PHRASE-DESC} BY ttUV_VersandBeleg.uCI_Warenausgangstermin DESCENDING BY ttUV_VersandBeleg.BelegNummer DESCENDING BY ttUV_VersandBeleg.PositionsNr DESCENDING
      &ELSE
        &SCOP SORTBY-PHRASE ~{&PA-VIRTUAL-INDEX-DUMMY-SORTBY-PHRASE-DESC} BY ttUV_VersandBeleg.uCI_Warenausgangstermin DESCENDING BY ttUV_VersandBeleg.BelegNummer DESCENDING BY ttUV_VersandBeleg.PositionsNr DESCENDING
      &ENDIF
    &SCOP KEY-PHRASE ttUV_VersandBeleg.uCI_Warenausgangstermin {&PA-OFFSET-COMPARE-GE-DESC} date(c_offset-value) {&PA-FILTER-PHRASE}
    if c_offset-value <> ? then
      {&OPEN-QUERY-{&BROWSE-NAME}}
    &SCOP KEY-PHRASE true {&PA-FILTER-PHRASE}
      else
        {&OPEN-QUERY-{&BROWSE-NAME}}

    else
      &IF "{&PA-USE-INDEX-IN-QUERY}":U = "1":U &THEN
        &SCOP SORTBY-PHRASE use-index uCI_Warenausgangstermin ~{&PA-VIRTUAL-INDEX-DUMMY-SORTBY-PHRASE} BY ttUV_VersandBeleg.uCI_Warenausgangstermin BY ttUV_VersandBeleg.BelegNummer BY ttUV_VersandBeleg.PositionsNr
      &ELSE
        &SCOP SORTBY-PHRASE ~{&PA-VIRTUAL-INDEX-DUMMY-SORTBY-PHRASE} BY ttUV_VersandBeleg.uCI_Warenausgangstermin BY ttUV_VersandBeleg.BelegNummer BY ttUV_VersandBeleg.PositionsNr
      &ENDIF
      &SCOP KEY-PHRASE ttUV_VersandBeleg.uCI_Warenausgangstermin {&PA-OFFSET-COMPARE-GE-ASC} date(c_offset-value) {&PA-FILTER-PHRASE}
      if c_offset-value <> ? then
        {&OPEN-QUERY-{&BROWSE-NAME}}
      &SCOP KEY-PHRASE true {&PA-FILTER-PHRASE}
      else
        {&OPEN-QUERY-{&BROWSE-NAME}}

  when 'Versandtermin':U then
    if pa-DescendingSortOrder then
      &IF "{&PA-USE-INDEX-IN-QUERY}":U = "1":U &THEN
        &SCOP SORTBY-PHRASE use-index Versandtermin ~{&PA-VIRTUAL-INDEX-DUMMY-SORTBY-PHRASE-DESC} BY ttUV_VersandBeleg.Versandtermin DESCENDING BY ttUV_VersandBeleg.BelegNummer DESCENDING BY ttUV_VersandBeleg.PositionsNr DESCENDING
      &ELSE
        &SCOP SORTBY-PHRASE ~{&PA-VIRTUAL-INDEX-DUMMY-SORTBY-PHRASE-DESC} BY ttUV_VersandBeleg.Versandtermin DESCENDING BY ttUV_VersandBeleg.BelegNummer DESCENDING BY ttUV_VersandBeleg.PositionsNr DESCENDING
      &ENDIF
    &SCOP KEY-PHRASE ttUV_VersandBeleg.Versandtermin {&PA-OFFSET-COMPARE-GE-DESC} date(c_offset-value) {&PA-FILTER-PHRASE}
    if c_offset-value <> ? then
      {&OPEN-QUERY-{&BROWSE-NAME}}
    &SCOP KEY-PHRASE true {&PA-FILTER-PHRASE}
      else
        {&OPEN-QUERY-{&BROWSE-NAME}}

    else
      &IF "{&PA-USE-INDEX-IN-QUERY}":U = "1":U &THEN
        &SCOP SORTBY-PHRASE use-index Versandtermin ~{&PA-VIRTUAL-INDEX-DUMMY-SORTBY-PHRASE} BY ttUV_VersandBeleg.Versandtermin BY ttUV_VersandBeleg.BelegNummer BY ttUV_VersandBeleg.PositionsNr
      &ELSE
        &SCOP SORTBY-PHRASE ~{&PA-VIRTUAL-INDEX-DUMMY-SORTBY-PHRASE} BY ttUV_VersandBeleg.Versandtermin BY ttUV_VersandBeleg.BelegNummer BY ttUV_VersandBeleg.PositionsNr
      &ENDIF
      &SCOP KEY-PHRASE ttUV_VersandBeleg.Versandtermin {&PA-OFFSET-COMPARE-GE-ASC} date(c_offset-value) {&PA-FILTER-PHRASE}
      if c_offset-value <> ? then
        {&OPEN-QUERY-{&BROWSE-NAME}}
      &SCOP KEY-PHRASE true {&PA-FILTER-PHRASE}
      else
        {&OPEN-QUERY-{&BROWSE-NAME}}

  when 'AuftragsArt':U then
    if pa-DescendingSortOrder then
      &IF "{&PA-USE-INDEX-IN-QUERY}":U = "1":U &THEN
        &SCOP SORTBY-PHRASE use-index AuftragsArt ~{&PA-VIRTUAL-INDEX-DUMMY-SORTBY-PHRASE-DESC} BY ttUV_VersandBeleg.AuftragsArt DESCENDING BY ttUV_VersandBeleg.BelegNummer DESCENDING BY ttUV_VersandBeleg.PositionsNr DESCENDING
      &ELSE
        &SCOP SORTBY-PHRASE ~{&PA-VIRTUAL-INDEX-DUMMY-SORTBY-PHRASE-DESC} BY ttUV_VersandBeleg.AuftragsArt DESCENDING BY ttUV_VersandBeleg.BelegNummer DESCENDING BY ttUV_VersandBeleg.PositionsNr DESCENDING
      &ENDIF
    &SCOP KEY-PHRASE ttUV_VersandBeleg.AuftragsArt {&PA-OFFSET-COMPARE-GE-DESC} c_offset-value {&PA-FILTER-PHRASE}
    if c_offset-value <> ? then
      {&OPEN-QUERY-{&BROWSE-NAME}}
    &SCOP KEY-PHRASE true {&PA-FILTER-PHRASE}
      else
        {&OPEN-QUERY-{&BROWSE-NAME}}

    else
      &IF "{&PA-USE-INDEX-IN-QUERY}":U = "1":U &THEN
        &SCOP SORTBY-PHRASE use-index AuftragsArt ~{&PA-VIRTUAL-INDEX-DUMMY-SORTBY-PHRASE} BY ttUV_VersandBeleg.AuftragsArt BY ttUV_VersandBeleg.BelegNummer BY ttUV_VersandBeleg.PositionsNr
      &ELSE
        &SCOP SORTBY-PHRASE ~{&PA-VIRTUAL-INDEX-DUMMY-SORTBY-PHRASE} BY ttUV_VersandBeleg.AuftragsArt BY ttUV_VersandBeleg.BelegNummer BY ttUV_VersandBeleg.PositionsNr
      &ENDIF
      &SCOP KEY-PHRASE ttUV_VersandBeleg.AuftragsArt {&PA-OFFSET-COMPARE-GE-ASC} c_offset-value {&PA-FILTER-PHRASE}
      if c_offset-value <> ? then
        {&OPEN-QUERY-{&BROWSE-NAME}}
      &SCOP KEY-PHRASE true {&PA-FILTER-PHRASE}
      else
        {&OPEN-QUERY-{&BROWSE-NAME}}

  when 'Versandart':U then
    if pa-DescendingSortOrder then
      &IF "{&PA-USE-INDEX-IN-QUERY}":U = "1":U &THEN
        &SCOP SORTBY-PHRASE use-index Versandart ~{&PA-VIRTUAL-INDEX-DUMMY-SORTBY-PHRASE-DESC} BY ttUV_VersandBeleg.Versandart DESCENDING BY ttUV_VersandBeleg.BelegNummer DESCENDING BY ttUV_VersandBeleg.PositionsNr DESCENDING
      &ELSE
        &SCOP SORTBY-PHRASE ~{&PA-VIRTUAL-INDEX-DUMMY-SORTBY-PHRASE-DESC} BY ttUV_VersandBeleg.Versandart DESCENDING BY ttUV_VersandBeleg.BelegNummer DESCENDING BY ttUV_VersandBeleg.PositionsNr DESCENDING
      &ENDIF
    &SCOP KEY-PHRASE ttUV_VersandBeleg.Versandart {&PA-OFFSET-COMPARE-GE-DESC} integer(c_offset-value) {&PA-FILTER-PHRASE}
    if c_offset-value <> ? then
      {&OPEN-QUERY-{&BROWSE-NAME}}
    &SCOP KEY-PHRASE true {&PA-FILTER-PHRASE}
      else
        {&OPEN-QUERY-{&BROWSE-NAME}}

    else
      &IF "{&PA-USE-INDEX-IN-QUERY}":U = "1":U &THEN
        &SCOP SORTBY-PHRASE use-index Versandart ~{&PA-VIRTUAL-INDEX-DUMMY-SORTBY-PHRASE} BY ttUV_VersandBeleg.Versandart BY ttUV_VersandBeleg.BelegNummer BY ttUV_VersandBeleg.PositionsNr
      &ELSE
        &SCOP SORTBY-PHRASE ~{&PA-VIRTUAL-INDEX-DUMMY-SORTBY-PHRASE} BY ttUV_VersandBeleg.Versandart BY ttUV_VersandBeleg.BelegNummer BY ttUV_VersandBeleg.PositionsNr
      &ENDIF
      &SCOP KEY-PHRASE ttUV_VersandBeleg.Versandart {&PA-OFFSET-COMPARE-GE-ASC} integer(c_offset-value) {&PA-FILTER-PHRASE}
      if c_offset-value <> ? then
        {&OPEN-QUERY-{&BROWSE-NAME}}
      &SCOP KEY-PHRASE true {&PA-FILTER-PHRASE}
      else
        {&OPEN-QUERY-{&BROWSE-NAME}}

  when 'LieferBedingung':U then
    if pa-DescendingSortOrder then
      &IF "{&PA-USE-INDEX-IN-QUERY}":U = "1":U &THEN
        &SCOP SORTBY-PHRASE use-index LieferBedingung ~{&PA-VIRTUAL-INDEX-DUMMY-SORTBY-PHRASE-DESC} BY ttUV_VersandBeleg.LieferBedingung DESCENDING BY ttUV_VersandBeleg.BelegNummer DESCENDING BY ttUV_VersandBeleg.PositionsNr DESCENDING
      &ELSE
        &SCOP SORTBY-PHRASE ~{&PA-VIRTUAL-INDEX-DUMMY-SORTBY-PHRASE-DESC} BY ttUV_VersandBeleg.LieferBedingung DESCENDING BY ttUV_VersandBeleg.BelegNummer DESCENDING BY ttUV_VersandBeleg.PositionsNr DESCENDING
      &ENDIF
    &SCOP KEY-PHRASE ttUV_VersandBeleg.LieferBedingung {&PA-OFFSET-COMPARE-GE-DESC} integer(c_offset-value) {&PA-FILTER-PHRASE}
    if c_offset-value <> ? then
      {&OPEN-QUERY-{&BROWSE-NAME}}
    &SCOP KEY-PHRASE true {&PA-FILTER-PHRASE}
      else
        {&OPEN-QUERY-{&BROWSE-NAME}}

    else
      &IF "{&PA-USE-INDEX-IN-QUERY}":U = "1":U &THEN
        &SCOP SORTBY-PHRASE use-index LieferBedingung ~{&PA-VIRTUAL-INDEX-DUMMY-SORTBY-PHRASE} BY ttUV_VersandBeleg.LieferBedingung BY ttUV_VersandBeleg.BelegNummer BY ttUV_VersandBeleg.PositionsNr
      &ELSE
        &SCOP SORTBY-PHRASE ~{&PA-VIRTUAL-INDEX-DUMMY-SORTBY-PHRASE} BY ttUV_VersandBeleg.LieferBedingung BY ttUV_VersandBeleg.BelegNummer BY ttUV_VersandBeleg.PositionsNr
      &ENDIF
      &SCOP KEY-PHRASE ttUV_VersandBeleg.LieferBedingung {&PA-OFFSET-COMPARE-GE-ASC} integer(c_offset-value) {&PA-FILTER-PHRASE}
      if c_offset-value <> ? then
        {&OPEN-QUERY-{&BROWSE-NAME}}
      &SCOP KEY-PHRASE true {&PA-FILTER-PHRASE}
      else
        {&OPEN-QUERY-{&BROWSE-NAME}}

  when 'LieferRestrikt':U then
    if pa-DescendingSortOrder then
      &IF "{&PA-USE-INDEX-IN-QUERY}":U = "1":U &THEN
        &SCOP SORTBY-PHRASE use-index LieferRestrikt ~{&PA-VIRTUAL-INDEX-DUMMY-SORTBY-PHRASE-DESC} BY ttUV_VersandBeleg.LieferRestrikt DESCENDING BY ttUV_VersandBeleg.BelegNummer DESCENDING BY ttUV_VersandBeleg.PositionsNr DESCENDING
      &ELSE
        &SCOP SORTBY-PHRASE ~{&PA-VIRTUAL-INDEX-DUMMY-SORTBY-PHRASE-DESC} BY ttUV_VersandBeleg.LieferRestrikt DESCENDING BY ttUV_VersandBeleg.BelegNummer DESCENDING BY ttUV_VersandBeleg.PositionsNr DESCENDING
      &ENDIF
    &SCOP KEY-PHRASE ttUV_VersandBeleg.LieferRestrikt {&PA-OFFSET-COMPARE-GE-DESC} integer(c_offset-value) {&PA-FILTER-PHRASE}
    if c_offset-value <> ? then
      {&OPEN-QUERY-{&BROWSE-NAME}}
    &SCOP KEY-PHRASE true {&PA-FILTER-PHRASE}
      else
        {&OPEN-QUERY-{&BROWSE-NAME}}

    else
      &IF "{&PA-USE-INDEX-IN-QUERY}":U = "1":U &THEN
        &SCOP SORTBY-PHRASE use-index LieferRestrikt ~{&PA-VIRTUAL-INDEX-DUMMY-SORTBY-PHRASE} BY ttUV_VersandBeleg.LieferRestrikt BY ttUV_VersandBeleg.BelegNummer BY ttUV_VersandBeleg.PositionsNr
      &ELSE
        &SCOP SORTBY-PHRASE ~{&PA-VIRTUAL-INDEX-DUMMY-SORTBY-PHRASE} BY ttUV_VersandBeleg.LieferRestrikt BY ttUV_VersandBeleg.BelegNummer BY ttUV_VersandBeleg.PositionsNr
      &ENDIF
      &SCOP KEY-PHRASE ttUV_VersandBeleg.LieferRestrikt {&PA-OFFSET-COMPARE-GE-ASC} integer(c_offset-value) {&PA-FILTER-PHRASE}
      if c_offset-value <> ? then
        {&OPEN-QUERY-{&BROWSE-NAME}}
      &SCOP KEY-PHRASE true {&PA-FILTER-PHRASE}
      else
        {&OPEN-QUERY-{&BROWSE-NAME}}

  when 'Sachbearbeiter':U then
    if pa-DescendingSortOrder then
      &IF "{&PA-USE-INDEX-IN-QUERY}":U = "1":U &THEN
        &SCOP SORTBY-PHRASE use-index Sachbearbeiter ~{&PA-VIRTUAL-INDEX-DUMMY-SORTBY-PHRASE-DESC} BY ttUV_VersandBeleg.Sachbearbeiter DESCENDING BY ttUV_VersandBeleg.BelegNummer DESCENDING BY ttUV_VersandBeleg.PositionsNr DESCENDING
      &ELSE
        &SCOP SORTBY-PHRASE ~{&PA-VIRTUAL-INDEX-DUMMY-SORTBY-PHRASE-DESC} BY ttUV_VersandBeleg.Sachbearbeiter DESCENDING BY ttUV_VersandBeleg.BelegNummer DESCENDING BY ttUV_VersandBeleg.PositionsNr DESCENDING
      &ENDIF
    &SCOP KEY-PHRASE ttUV_VersandBeleg.Sachbearbeiter {&PA-OFFSET-COMPARE-GE-DESC} c_offset-value {&PA-FILTER-PHRASE}
    if c_offset-value <> ? then
      {&OPEN-QUERY-{&BROWSE-NAME}}
    &SCOP KEY-PHRASE true {&PA-FILTER-PHRASE}
      else
        {&OPEN-QUERY-{&BROWSE-NAME}}

    else
      &IF "{&PA-USE-INDEX-IN-QUERY}":U = "1":U &THEN
        &SCOP SORTBY-PHRASE use-index Sachbearbeiter ~{&PA-VIRTUAL-INDEX-DUMMY-SORTBY-PHRASE} BY ttUV_VersandBeleg.Sachbearbeiter BY ttUV_VersandBeleg.BelegNummer BY ttUV_VersandBeleg.PositionsNr
      &ELSE
        &SCOP SORTBY-PHRASE ~{&PA-VIRTUAL-INDEX-DUMMY-SORTBY-PHRASE} BY ttUV_VersandBeleg.Sachbearbeiter BY ttUV_VersandBeleg.BelegNummer BY ttUV_VersandBeleg.PositionsNr
      &ENDIF
      &SCOP KEY-PHRASE ttUV_VersandBeleg.Sachbearbeiter {&PA-OFFSET-COMPARE-GE-ASC} c_offset-value {&PA-FILTER-PHRASE}
      if c_offset-value <> ? then
        {&OPEN-QUERY-{&BROWSE-NAME}}
      &SCOP KEY-PHRASE true {&PA-FILTER-PHRASE}
      else
        {&OPEN-QUERY-{&BROWSE-NAME}}

  when 'Lieferant':U then
    if pa-DescendingSortOrder then
      &IF "{&PA-USE-INDEX-IN-QUERY}":U = "1":U &THEN
        &SCOP SORTBY-PHRASE use-index Lieferant ~{&PA-VIRTUAL-INDEX-DUMMY-SORTBY-PHRASE-DESC} BY ttUV_VersandBeleg.Lieferant DESCENDING BY ttUV_VersandBeleg.BelegNummer DESCENDING BY ttUV_VersandBeleg.PositionsNr DESCENDING
      &ELSE
        &SCOP SORTBY-PHRASE ~{&PA-VIRTUAL-INDEX-DUMMY-SORTBY-PHRASE-DESC} BY ttUV_VersandBeleg.Lieferant DESCENDING BY ttUV_VersandBeleg.BelegNummer DESCENDING BY ttUV_VersandBeleg.PositionsNr DESCENDING
      &ENDIF
    &SCOP KEY-PHRASE ttUV_VersandBeleg.Lieferant {&PA-OFFSET-COMPARE-GE-DESC} integer(c_offset-value) {&PA-FILTER-PHRASE}
    if c_offset-value <> ? then
      {&OPEN-QUERY-{&BROWSE-NAME}}
    &SCOP KEY-PHRASE true {&PA-FILTER-PHRASE}
      else
        {&OPEN-QUERY-{&BROWSE-NAME}}

    else
      &IF "{&PA-USE-INDEX-IN-QUERY}":U = "1":U &THEN
        &SCOP SORTBY-PHRASE use-index Lieferant ~{&PA-VIRTUAL-INDEX-DUMMY-SORTBY-PHRASE} BY ttUV_VersandBeleg.Lieferant BY ttUV_VersandBeleg.BelegNummer BY ttUV_VersandBeleg.PositionsNr
      &ELSE
        &SCOP SORTBY-PHRASE ~{&PA-VIRTUAL-INDEX-DUMMY-SORTBY-PHRASE} BY ttUV_VersandBeleg.Lieferant BY ttUV_VersandBeleg.BelegNummer BY ttUV_VersandBeleg.PositionsNr
      &ENDIF
      &SCOP KEY-PHRASE ttUV_VersandBeleg.Lieferant {&PA-OFFSET-COMPARE-GE-ASC} integer(c_offset-value) {&PA-FILTER-PHRASE}
      if c_offset-value <> ? then
        {&OPEN-QUERY-{&BROWSE-NAME}}
      &SCOP KEY-PHRASE true {&PA-FILTER-PHRASE}
      else
        {&OPEN-QUERY-{&BROWSE-NAME}}

  when 'Lieferant_Suchbegriff':U then
    if pa-DescendingSortOrder then
      &IF "{&PA-USE-INDEX-IN-QUERY}":U = "1":U &THEN
        &SCOP SORTBY-PHRASE use-index Lieferant_Suchbegriff ~{&PA-VIRTUAL-INDEX-DUMMY-SORTBY-PHRASE-DESC} BY ttUV_VersandBeleg.Lieferant_Suchbegriff DESCENDING BY ttUV_VersandBeleg.Lieferant DESCENDING BY ttUV_VersandBeleg.BelegNummer DESCENDING BY ttUV_VersandBeleg.PositionsNr DESCENDING
      &ELSE
        &SCOP SORTBY-PHRASE ~{&PA-VIRTUAL-INDEX-DUMMY-SORTBY-PHRASE-DESC} BY ttUV_VersandBeleg.Lieferant_Suchbegriff DESCENDING BY ttUV_VersandBeleg.Lieferant DESCENDING BY ttUV_VersandBeleg.BelegNummer DESCENDING BY ttUV_VersandBeleg.PositionsNr DESCENDING
      &ENDIF
    &SCOP KEY-PHRASE ttUV_VersandBeleg.Lieferant_Suchbegriff {&PA-OFFSET-COMPARE-GE-DESC} c_offset-value {&PA-FILTER-PHRASE}
    if c_offset-value <> ? then
      {&OPEN-QUERY-{&BROWSE-NAME}}
    &SCOP KEY-PHRASE true {&PA-FILTER-PHRASE}
      else
        {&OPEN-QUERY-{&BROWSE-NAME}}

    else
      &IF "{&PA-USE-INDEX-IN-QUERY}":U = "1":U &THEN
        &SCOP SORTBY-PHRASE use-index Lieferant_Suchbegriff ~{&PA-VIRTUAL-INDEX-DUMMY-SORTBY-PHRASE} BY ttUV_VersandBeleg.Lieferant_Suchbegriff BY ttUV_VersandBeleg.Lieferant BY ttUV_VersandBeleg.BelegNummer BY ttUV_VersandBeleg.PositionsNr
      &ELSE
        &SCOP SORTBY-PHRASE ~{&PA-VIRTUAL-INDEX-DUMMY-SORTBY-PHRASE} BY ttUV_VersandBeleg.Lieferant_Suchbegriff BY ttUV_VersandBeleg.Lieferant BY ttUV_VersandBeleg.BelegNummer BY ttUV_VersandBeleg.PositionsNr
      &ENDIF
      &SCOP KEY-PHRASE ttUV_VersandBeleg.Lieferant_Suchbegriff {&PA-OFFSET-COMPARE-GE-ASC} c_offset-value {&PA-FILTER-PHRASE}
      if c_offset-value <> ? then
        {&OPEN-QUERY-{&BROWSE-NAME}}
      &SCOP KEY-PHRASE true {&PA-FILTER-PHRASE}
      else
        {&OPEN-QUERY-{&BROWSE-NAME}}

  when 'Lieferant_Selektion':U then
    if pa-DescendingSortOrder then
      &IF "{&PA-USE-INDEX-IN-QUERY}":U = "1":U &THEN
        &SCOP SORTBY-PHRASE use-index Lieferant_Selektion ~{&PA-VIRTUAL-INDEX-DUMMY-SORTBY-PHRASE-DESC} BY ttUV_VersandBeleg.Lieferant_Selektion DESCENDING BY ttUV_VersandBeleg.Lieferant DESCENDING BY ttUV_VersandBeleg.BelegNummer DESCENDING BY ttUV_VersandBeleg.PositionsNr DESCENDING
      &ELSE
        &SCOP SORTBY-PHRASE ~{&PA-VIRTUAL-INDEX-DUMMY-SORTBY-PHRASE-DESC} BY ttUV_VersandBeleg.Lieferant_Selektion DESCENDING BY ttUV_VersandBeleg.Lieferant DESCENDING BY ttUV_VersandBeleg.BelegNummer DESCENDING BY ttUV_VersandBeleg.PositionsNr DESCENDING
      &ENDIF
    &SCOP KEY-PHRASE ttUV_VersandBeleg.Lieferant_Selektion {&PA-OFFSET-COMPARE-GE-DESC} c_offset-value {&PA-FILTER-PHRASE}
    if c_offset-value <> ? then
      {&OPEN-QUERY-{&BROWSE-NAME}}
    &SCOP KEY-PHRASE true {&PA-FILTER-PHRASE}
      else
        {&OPEN-QUERY-{&BROWSE-NAME}}

    else
      &IF "{&PA-USE-INDEX-IN-QUERY}":U = "1":U &THEN
        &SCOP SORTBY-PHRASE use-index Lieferant_Selektion ~{&PA-VIRTUAL-INDEX-DUMMY-SORTBY-PHRASE} BY ttUV_VersandBeleg.Lieferant_Selektion BY ttUV_VersandBeleg.Lieferant BY ttUV_VersandBeleg.BelegNummer BY ttUV_VersandBeleg.PositionsNr
      &ELSE
        &SCOP SORTBY-PHRASE ~{&PA-VIRTUAL-INDEX-DUMMY-SORTBY-PHRASE} BY ttUV_VersandBeleg.Lieferant_Selektion BY ttUV_VersandBeleg.Lieferant BY ttUV_VersandBeleg.BelegNummer BY ttUV_VersandBeleg.PositionsNr
      &ENDIF
      &SCOP KEY-PHRASE ttUV_VersandBeleg.Lieferant_Selektion {&PA-OFFSET-COMPARE-GE-ASC} c_offset-value {&PA-FILTER-PHRASE}
      if c_offset-value <> ? then
        {&OPEN-QUERY-{&BROWSE-NAME}}
      &SCOP KEY-PHRASE true {&PA-FILTER-PHRASE}
      else
        {&OPEN-QUERY-{&BROWSE-NAME}}

  when 'LieferAdresse':U then
    if pa-DescendingSortOrder then
      &IF "{&PA-USE-INDEX-IN-QUERY}":U = "1":U &THEN
        &SCOP SORTBY-PHRASE use-index LieferAdresse ~{&PA-VIRTUAL-INDEX-DUMMY-SORTBY-PHRASE-DESC} BY ttUV_VersandBeleg.LieferAdresse DESCENDING BY ttUV_VersandBeleg.BelegNummer DESCENDING BY ttUV_VersandBeleg.PositionsNr DESCENDING
      &ELSE
        &SCOP SORTBY-PHRASE ~{&PA-VIRTUAL-INDEX-DUMMY-SORTBY-PHRASE-DESC} BY ttUV_VersandBeleg.LieferAdresse DESCENDING BY ttUV_VersandBeleg.BelegNummer DESCENDING BY ttUV_VersandBeleg.PositionsNr DESCENDING
      &ENDIF
    &SCOP KEY-PHRASE ttUV_VersandBeleg.LieferAdresse {&PA-OFFSET-COMPARE-GE-DESC} integer(c_offset-value) {&PA-FILTER-PHRASE}
    if c_offset-value <> ? then
      {&OPEN-QUERY-{&BROWSE-NAME}}
    &SCOP KEY-PHRASE true {&PA-FILTER-PHRASE}
      else
        {&OPEN-QUERY-{&BROWSE-NAME}}

    else
      &IF "{&PA-USE-INDEX-IN-QUERY}":U = "1":U &THEN
        &SCOP SORTBY-PHRASE use-index LieferAdresse ~{&PA-VIRTUAL-INDEX-DUMMY-SORTBY-PHRASE} BY ttUV_VersandBeleg.LieferAdresse BY ttUV_VersandBeleg.BelegNummer BY ttUV_VersandBeleg.PositionsNr
      &ELSE
        &SCOP SORTBY-PHRASE ~{&PA-VIRTUAL-INDEX-DUMMY-SORTBY-PHRASE} BY ttUV_VersandBeleg.LieferAdresse BY ttUV_VersandBeleg.BelegNummer BY ttUV_VersandBeleg.PositionsNr
      &ENDIF
      &SCOP KEY-PHRASE ttUV_VersandBeleg.LieferAdresse {&PA-OFFSET-COMPARE-GE-ASC} integer(c_offset-value) {&PA-FILTER-PHRASE}
      if c_offset-value <> ? then
        {&OPEN-QUERY-{&BROWSE-NAME}}
      &SCOP KEY-PHRASE true {&PA-FILTER-PHRASE}
      else
        {&OPEN-QUERY-{&BROWSE-NAME}}

  when 'AdressKennung':U then
    if pa-DescendingSortOrder then
      &IF "{&PA-USE-INDEX-IN-QUERY}":U = "1":U &THEN
        &SCOP SORTBY-PHRASE use-index AdressKennung ~{&PA-VIRTUAL-INDEX-DUMMY-SORTBY-PHRASE-DESC} BY ttUV_VersandBeleg.AdressKennung DESCENDING BY ttUV_VersandBeleg.LieferAdresse DESCENDING BY ttUV_VersandBeleg.BelegNummer DESCENDING BY ttUV_VersandBeleg.PositionsNr DESCENDING
      &ELSE
        &SCOP SORTBY-PHRASE ~{&PA-VIRTUAL-INDEX-DUMMY-SORTBY-PHRASE-DESC} BY ttUV_VersandBeleg.AdressKennung DESCENDING BY ttUV_VersandBeleg.LieferAdresse DESCENDING BY ttUV_VersandBeleg.BelegNummer DESCENDING BY ttUV_VersandBeleg.PositionsNr DESCENDING
      &ENDIF
    &SCOP KEY-PHRASE ttUV_VersandBeleg.AdressKennung {&PA-OFFSET-COMPARE-GE-DESC} c_offset-value {&PA-FILTER-PHRASE}
    if c_offset-value <> ? then
      {&OPEN-QUERY-{&BROWSE-NAME}}
    &SCOP KEY-PHRASE true {&PA-FILTER-PHRASE}
      else
        {&OPEN-QUERY-{&BROWSE-NAME}}

    else
      &IF "{&PA-USE-INDEX-IN-QUERY}":U = "1":U &THEN
        &SCOP SORTBY-PHRASE use-index AdressKennung ~{&PA-VIRTUAL-INDEX-DUMMY-SORTBY-PHRASE} BY ttUV_VersandBeleg.AdressKennung BY ttUV_VersandBeleg.LieferAdresse BY ttUV_VersandBeleg.BelegNummer BY ttUV_VersandBeleg.PositionsNr
      &ELSE
        &SCOP SORTBY-PHRASE ~{&PA-VIRTUAL-INDEX-DUMMY-SORTBY-PHRASE} BY ttUV_VersandBeleg.AdressKennung BY ttUV_VersandBeleg.LieferAdresse BY ttUV_VersandBeleg.BelegNummer BY ttUV_VersandBeleg.PositionsNr
      &ENDIF
      &SCOP KEY-PHRASE ttUV_VersandBeleg.AdressKennung {&PA-OFFSET-COMPARE-GE-ASC} c_offset-value {&PA-FILTER-PHRASE}
      if c_offset-value <> ? then
        {&OPEN-QUERY-{&BROWSE-NAME}}
      &SCOP KEY-PHRASE true {&PA-FILTER-PHRASE}
      else
        {&OPEN-QUERY-{&BROWSE-NAME}}

  when 'LiefAdr_Name1':U then
    if pa-DescendingSortOrder then
      &IF "{&PA-USE-INDEX-IN-QUERY}":U = "1":U &THEN
        &SCOP SORTBY-PHRASE use-index LiefAdr_Name1 ~{&PA-VIRTUAL-INDEX-DUMMY-SORTBY-PHRASE-DESC} BY ttUV_VersandBeleg.LiefAdr_Name1 DESCENDING BY ttUV_VersandBeleg.LieferAdresse DESCENDING BY ttUV_VersandBeleg.BelegNummer DESCENDING BY ttUV_VersandBeleg.PositionsNr DESCENDING
      &ELSE
        &SCOP SORTBY-PHRASE ~{&PA-VIRTUAL-INDEX-DUMMY-SORTBY-PHRASE-DESC} BY ttUV_VersandBeleg.LiefAdr_Name1 DESCENDING BY ttUV_VersandBeleg.LieferAdresse DESCENDING BY ttUV_VersandBeleg.BelegNummer DESCENDING BY ttUV_VersandBeleg.PositionsNr DESCENDING
      &ENDIF
    &SCOP KEY-PHRASE ttUV_VersandBeleg.LiefAdr_Name1 {&PA-OFFSET-COMPARE-GE-DESC} c_offset-value {&PA-FILTER-PHRASE}
    if c_offset-value <> ? then
      {&OPEN-QUERY-{&BROWSE-NAME}}
    &SCOP KEY-PHRASE true {&PA-FILTER-PHRASE}
      else
        {&OPEN-QUERY-{&BROWSE-NAME}}

    else
      &IF "{&PA-USE-INDEX-IN-QUERY}":U = "1":U &THEN
        &SCOP SORTBY-PHRASE use-index LiefAdr_Name1 ~{&PA-VIRTUAL-INDEX-DUMMY-SORTBY-PHRASE} BY ttUV_VersandBeleg.LiefAdr_Name1 BY ttUV_VersandBeleg.LieferAdresse BY ttUV_VersandBeleg.BelegNummer BY ttUV_VersandBeleg.PositionsNr
      &ELSE
        &SCOP SORTBY-PHRASE ~{&PA-VIRTUAL-INDEX-DUMMY-SORTBY-PHRASE} BY ttUV_VersandBeleg.LiefAdr_Name1 BY ttUV_VersandBeleg.LieferAdresse BY ttUV_VersandBeleg.BelegNummer BY ttUV_VersandBeleg.PositionsNr
      &ENDIF
      &SCOP KEY-PHRASE ttUV_VersandBeleg.LiefAdr_Name1 {&PA-OFFSET-COMPARE-GE-ASC} c_offset-value {&PA-FILTER-PHRASE}
      if c_offset-value <> ? then
        {&OPEN-QUERY-{&BROWSE-NAME}}
      &SCOP KEY-PHRASE true {&PA-FILTER-PHRASE}
      else
        {&OPEN-QUERY-{&BROWSE-NAME}}

  when 'LiefAdr_PLZ':U then
    if pa-DescendingSortOrder then
      &IF "{&PA-USE-INDEX-IN-QUERY}":U = "1":U &THEN
        &SCOP SORTBY-PHRASE use-index LiefAdr_PLZ ~{&PA-VIRTUAL-INDEX-DUMMY-SORTBY-PHRASE-DESC} BY ttUV_VersandBeleg.LiefAdr_PLZ DESCENDING BY ttUV_VersandBeleg.LieferAdresse DESCENDING BY ttUV_VersandBeleg.BelegNummer DESCENDING BY ttUV_VersandBeleg.PositionsNr DESCENDING
      &ELSE
        &SCOP SORTBY-PHRASE ~{&PA-VIRTUAL-INDEX-DUMMY-SORTBY-PHRASE-DESC} BY ttUV_VersandBeleg.LiefAdr_PLZ DESCENDING BY ttUV_VersandBeleg.LieferAdresse DESCENDING BY ttUV_VersandBeleg.BelegNummer DESCENDING BY ttUV_VersandBeleg.PositionsNr DESCENDING
      &ENDIF
    &SCOP KEY-PHRASE ttUV_VersandBeleg.LiefAdr_PLZ {&PA-OFFSET-COMPARE-GE-DESC} c_offset-value {&PA-FILTER-PHRASE}
    if c_offset-value <> ? then
      {&OPEN-QUERY-{&BROWSE-NAME}}
    &SCOP KEY-PHRASE true {&PA-FILTER-PHRASE}
      else
        {&OPEN-QUERY-{&BROWSE-NAME}}

    else
      &IF "{&PA-USE-INDEX-IN-QUERY}":U = "1":U &THEN
        &SCOP SORTBY-PHRASE use-index LiefAdr_PLZ ~{&PA-VIRTUAL-INDEX-DUMMY-SORTBY-PHRASE} BY ttUV_VersandBeleg.LiefAdr_PLZ BY ttUV_VersandBeleg.LieferAdresse BY ttUV_VersandBeleg.BelegNummer BY ttUV_VersandBeleg.PositionsNr
      &ELSE
        &SCOP SORTBY-PHRASE ~{&PA-VIRTUAL-INDEX-DUMMY-SORTBY-PHRASE} BY ttUV_VersandBeleg.LiefAdr_PLZ BY ttUV_VersandBeleg.LieferAdresse BY ttUV_VersandBeleg.BelegNummer BY ttUV_VersandBeleg.PositionsNr
      &ENDIF
      &SCOP KEY-PHRASE ttUV_VersandBeleg.LiefAdr_PLZ {&PA-OFFSET-COMPARE-GE-ASC} c_offset-value {&PA-FILTER-PHRASE}
      if c_offset-value <> ? then
        {&OPEN-QUERY-{&BROWSE-NAME}}
      &SCOP KEY-PHRASE true {&PA-FILTER-PHRASE}
      else
        {&OPEN-QUERY-{&BROWSE-NAME}}

  when 'LiefAdr_Ort':U then
    if pa-DescendingSortOrder then
      &IF "{&PA-USE-INDEX-IN-QUERY}":U = "1":U &THEN
        &SCOP SORTBY-PHRASE use-index LiefAdr_Ort ~{&PA-VIRTUAL-INDEX-DUMMY-SORTBY-PHRASE-DESC} BY ttUV_VersandBeleg.LiefAdr_Ort DESCENDING BY ttUV_VersandBeleg.LieferAdresse DESCENDING BY ttUV_VersandBeleg.BelegNummer DESCENDING BY ttUV_VersandBeleg.PositionsNr DESCENDING
      &ELSE
        &SCOP SORTBY-PHRASE ~{&PA-VIRTUAL-INDEX-DUMMY-SORTBY-PHRASE-DESC} BY ttUV_VersandBeleg.LiefAdr_Ort DESCENDING BY ttUV_VersandBeleg.LieferAdresse DESCENDING BY ttUV_VersandBeleg.BelegNummer DESCENDING BY ttUV_VersandBeleg.PositionsNr DESCENDING
      &ENDIF
    &SCOP KEY-PHRASE ttUV_VersandBeleg.LiefAdr_Ort {&PA-OFFSET-COMPARE-GE-DESC} c_offset-value {&PA-FILTER-PHRASE}
    if c_offset-value <> ? then
      {&OPEN-QUERY-{&BROWSE-NAME}}
    &SCOP KEY-PHRASE true {&PA-FILTER-PHRASE}
      else
        {&OPEN-QUERY-{&BROWSE-NAME}}

    else
      &IF "{&PA-USE-INDEX-IN-QUERY}":U = "1":U &THEN
        &SCOP SORTBY-PHRASE use-index LiefAdr_Ort ~{&PA-VIRTUAL-INDEX-DUMMY-SORTBY-PHRASE} BY ttUV_VersandBeleg.LiefAdr_Ort BY ttUV_VersandBeleg.LieferAdresse BY ttUV_VersandBeleg.BelegNummer BY ttUV_VersandBeleg.PositionsNr
      &ELSE
        &SCOP SORTBY-PHRASE ~{&PA-VIRTUAL-INDEX-DUMMY-SORTBY-PHRASE} BY ttUV_VersandBeleg.LiefAdr_Ort BY ttUV_VersandBeleg.LieferAdresse BY ttUV_VersandBeleg.BelegNummer BY ttUV_VersandBeleg.PositionsNr
      &ENDIF
      &SCOP KEY-PHRASE ttUV_VersandBeleg.LiefAdr_Ort {&PA-OFFSET-COMPARE-GE-ASC} c_offset-value {&PA-FILTER-PHRASE}
      if c_offset-value <> ? then
        {&OPEN-QUERY-{&BROWSE-NAME}}
      &SCOP KEY-PHRASE true {&PA-FILTER-PHRASE}
      else
        {&OPEN-QUERY-{&BROWSE-NAME}}

  when 'Abladestelle':U then
    if pa-DescendingSortOrder then
      &IF "{&PA-USE-INDEX-IN-QUERY}":U = "1":U &THEN
        &SCOP SORTBY-PHRASE use-index Abladestelle ~{&PA-VIRTUAL-INDEX-DUMMY-SORTBY-PHRASE-DESC} BY ttUV_VersandBeleg.Abladestelle DESCENDING BY ttUV_VersandBeleg.LieferAdresse DESCENDING BY ttUV_VersandBeleg.BelegNummer DESCENDING BY ttUV_VersandBeleg.PositionsNr DESCENDING
      &ELSE
        &SCOP SORTBY-PHRASE ~{&PA-VIRTUAL-INDEX-DUMMY-SORTBY-PHRASE-DESC} BY ttUV_VersandBeleg.Abladestelle DESCENDING BY ttUV_VersandBeleg.LieferAdresse DESCENDING BY ttUV_VersandBeleg.BelegNummer DESCENDING BY ttUV_VersandBeleg.PositionsNr DESCENDING
      &ENDIF
    &SCOP KEY-PHRASE ttUV_VersandBeleg.Abladestelle {&PA-OFFSET-COMPARE-GE-DESC} c_offset-value {&PA-FILTER-PHRASE}
    if c_offset-value <> ? then
      {&OPEN-QUERY-{&BROWSE-NAME}}
    &SCOP KEY-PHRASE true {&PA-FILTER-PHRASE}
      else
        {&OPEN-QUERY-{&BROWSE-NAME}}

    else
      &IF "{&PA-USE-INDEX-IN-QUERY}":U = "1":U &THEN
        &SCOP SORTBY-PHRASE use-index Abladestelle ~{&PA-VIRTUAL-INDEX-DUMMY-SORTBY-PHRASE} BY ttUV_VersandBeleg.Abladestelle BY ttUV_VersandBeleg.LieferAdresse BY ttUV_VersandBeleg.BelegNummer BY ttUV_VersandBeleg.PositionsNr
      &ELSE
        &SCOP SORTBY-PHRASE ~{&PA-VIRTUAL-INDEX-DUMMY-SORTBY-PHRASE} BY ttUV_VersandBeleg.Abladestelle BY ttUV_VersandBeleg.LieferAdresse BY ttUV_VersandBeleg.BelegNummer BY ttUV_VersandBeleg.PositionsNr
      &ENDIF
      &SCOP KEY-PHRASE ttUV_VersandBeleg.Abladestelle {&PA-OFFSET-COMPARE-GE-ASC} c_offset-value {&PA-FILTER-PHRASE}
      if c_offset-value <> ? then
        {&OPEN-QUERY-{&BROWSE-NAME}}
      &SCOP KEY-PHRASE true {&PA-FILTER-PHRASE}
      else
        {&OPEN-QUERY-{&BROWSE-NAME}}

  when 'KO_LagerOrt':U then
    if pa-DescendingSortOrder then
      &IF "{&PA-USE-INDEX-IN-QUERY}":U = "1":U &THEN
        &SCOP SORTBY-PHRASE use-index KO_LagerOrt ~{&PA-VIRTUAL-INDEX-DUMMY-SORTBY-PHRASE-DESC} BY ttUV_VersandBeleg.KO_LagerOrt DESCENDING BY ttUV_VersandBeleg.BelegNummer DESCENDING BY ttUV_VersandBeleg.PositionsNr DESCENDING
      &ELSE
        &SCOP SORTBY-PHRASE ~{&PA-VIRTUAL-INDEX-DUMMY-SORTBY-PHRASE-DESC} BY ttUV_VersandBeleg.KO_LagerOrt DESCENDING BY ttUV_VersandBeleg.BelegNummer DESCENDING BY ttUV_VersandBeleg.PositionsNr DESCENDING
      &ENDIF
    &SCOP KEY-PHRASE ttUV_VersandBeleg.KO_LagerOrt {&PA-OFFSET-COMPARE-GE-DESC} integer(c_offset-value) {&PA-FILTER-PHRASE}
    if c_offset-value <> ? then
      {&OPEN-QUERY-{&BROWSE-NAME}}
    &SCOP KEY-PHRASE true {&PA-FILTER-PHRASE}
      else
        {&OPEN-QUERY-{&BROWSE-NAME}}

    else
      &IF "{&PA-USE-INDEX-IN-QUERY}":U = "1":U &THEN
        &SCOP SORTBY-PHRASE use-index KO_LagerOrt ~{&PA-VIRTUAL-INDEX-DUMMY-SORTBY-PHRASE} BY ttUV_VersandBeleg.KO_LagerOrt BY ttUV_VersandBeleg.BelegNummer BY ttUV_VersandBeleg.PositionsNr
      &ELSE
        &SCOP SORTBY-PHRASE ~{&PA-VIRTUAL-INDEX-DUMMY-SORTBY-PHRASE} BY ttUV_VersandBeleg.KO_LagerOrt BY ttUV_VersandBeleg.BelegNummer BY ttUV_VersandBeleg.PositionsNr
      &ENDIF
      &SCOP KEY-PHRASE ttUV_VersandBeleg.KO_LagerOrt {&PA-OFFSET-COMPARE-GE-ASC} integer(c_offset-value) {&PA-FILTER-PHRASE}
      if c_offset-value <> ? then
        {&OPEN-QUERY-{&BROWSE-NAME}}
      &SCOP KEY-PHRASE true {&PA-FILTER-PHRASE}
      else
        {&OPEN-QUERY-{&BROWSE-NAME}}

  when 'Markiert':U then
    if pa-DescendingSortOrder then
      &IF "{&PA-USE-INDEX-IN-QUERY}":U = "1":U &THEN
        &SCOP SORTBY-PHRASE use-index Markiert ~{&PA-VIRTUAL-INDEX-DUMMY-SORTBY-PHRASE-DESC} BY ttUV_VersandBeleg.Markiert DESCENDING
      &ELSE
        &SCOP SORTBY-PHRASE ~{&PA-VIRTUAL-INDEX-DUMMY-SORTBY-PHRASE-DESC} BY ttUV_VersandBeleg.Markiert DESCENDING
      &ENDIF
    &SCOP KEY-PHRASE ttUV_VersandBeleg.Markiert {&PA-OFFSET-COMPARE-GE-DESC} (c_offset-value = 'yes':U) {&PA-FILTER-PHRASE}
    if c_offset-value <> ? then
      {&OPEN-QUERY-{&BROWSE-NAME}}
    &SCOP KEY-PHRASE true {&PA-FILTER-PHRASE}
      else
        {&OPEN-QUERY-{&BROWSE-NAME}}

    else
      &IF "{&PA-USE-INDEX-IN-QUERY}":U = "1":U &THEN
        &SCOP SORTBY-PHRASE use-index Markiert ~{&PA-VIRTUAL-INDEX-DUMMY-SORTBY-PHRASE} BY ttUV_VersandBeleg.Markiert
      &ELSE
        &SCOP SORTBY-PHRASE ~{&PA-VIRTUAL-INDEX-DUMMY-SORTBY-PHRASE} BY ttUV_VersandBeleg.Markiert
      &ENDIF
      &SCOP KEY-PHRASE ttUV_VersandBeleg.Markiert {&PA-OFFSET-COMPARE-GE-ASC} (c_offset-value = 'yes':U) {&PA-FILTER-PHRASE}
      if c_offset-value <> ? then
        {&OPEN-QUERY-{&BROWSE-NAME}}
      &SCOP KEY-PHRASE true {&PA-FILTER-PHRASE}
      else
        {&OPEN-QUERY-{&BROWSE-NAME}}

  when 'StorageArea':U then
    if pa-DescendingSortOrder then
      &IF "{&PA-USE-INDEX-IN-QUERY}":U = "1":U &THEN
        &SCOP SORTBY-PHRASE use-index StorageArea ~{&PA-VIRTUAL-INDEX-DUMMY-SORTBY-PHRASE-DESC} BY ttUV_VersandBeleg.StorageArea DESCENDING BY ttUV_VersandBeleg.BelegNummer DESCENDING BY ttUV_VersandBeleg.PositionsNr DESCENDING
      &ELSE
        &SCOP SORTBY-PHRASE ~{&PA-VIRTUAL-INDEX-DUMMY-SORTBY-PHRASE-DESC} BY ttUV_VersandBeleg.StorageArea DESCENDING BY ttUV_VersandBeleg.BelegNummer DESCENDING BY ttUV_VersandBeleg.PositionsNr DESCENDING
      &ENDIF
    &SCOP KEY-PHRASE ttUV_VersandBeleg.StorageArea {&PA-OFFSET-COMPARE-GE-DESC} integer(c_offset-value) {&PA-FILTER-PHRASE}
    if c_offset-value <> ? then
      {&OPEN-QUERY-{&BROWSE-NAME}}
    &SCOP KEY-PHRASE true {&PA-FILTER-PHRASE}
      else
        {&OPEN-QUERY-{&BROWSE-NAME}}

    else
      &IF "{&PA-USE-INDEX-IN-QUERY}":U = "1":U &THEN
        &SCOP SORTBY-PHRASE use-index StorageArea ~{&PA-VIRTUAL-INDEX-DUMMY-SORTBY-PHRASE} BY ttUV_VersandBeleg.StorageArea BY ttUV_VersandBeleg.BelegNummer BY ttUV_VersandBeleg.PositionsNr
      &ELSE
        &SCOP SORTBY-PHRASE ~{&PA-VIRTUAL-INDEX-DUMMY-SORTBY-PHRASE} BY ttUV_VersandBeleg.StorageArea BY ttUV_VersandBeleg.BelegNummer BY ttUV_VersandBeleg.PositionsNr
      &ENDIF
      &SCOP KEY-PHRASE ttUV_VersandBeleg.StorageArea {&PA-OFFSET-COMPARE-GE-ASC} integer(c_offset-value) {&PA-FILTER-PHRASE}
      if c_offset-value <> ? then
        {&OPEN-QUERY-{&BROWSE-NAME}}
      &SCOP KEY-PHRASE true {&PA-FILTER-PHRASE}
      else
        {&OPEN-QUERY-{&BROWSE-NAME}}

  when 'CreditTerms':U then
    if pa-DescendingSortOrder then
      &IF "{&PA-USE-INDEX-IN-QUERY}":U = "1":U &THEN
        &SCOP SORTBY-PHRASE use-index CreditTerms ~{&PA-VIRTUAL-INDEX-DUMMY-SORTBY-PHRASE-DESC} BY ttUV_VersandBeleg.CreditTerms DESCENDING BY ttUV_VersandBeleg.BelegNummer DESCENDING BY ttUV_VersandBeleg.PositionsNr DESCENDING
      &ELSE
        &SCOP SORTBY-PHRASE ~{&PA-VIRTUAL-INDEX-DUMMY-SORTBY-PHRASE-DESC} BY ttUV_VersandBeleg.CreditTerms DESCENDING BY ttUV_VersandBeleg.BelegNummer DESCENDING BY ttUV_VersandBeleg.PositionsNr DESCENDING
      &ENDIF
    &SCOP KEY-PHRASE ttUV_VersandBeleg.CreditTerms {&PA-OFFSET-COMPARE-GE-DESC} integer(c_offset-value) {&PA-FILTER-PHRASE}
    if c_offset-value <> ? then
      {&OPEN-QUERY-{&BROWSE-NAME}}
    &SCOP KEY-PHRASE true {&PA-FILTER-PHRASE}
      else
        {&OPEN-QUERY-{&BROWSE-NAME}}

    else
      &IF "{&PA-USE-INDEX-IN-QUERY}":U = "1":U &THEN
        &SCOP SORTBY-PHRASE use-index CreditTerms ~{&PA-VIRTUAL-INDEX-DUMMY-SORTBY-PHRASE} BY ttUV_VersandBeleg.CreditTerms BY ttUV_VersandBeleg.BelegNummer BY ttUV_VersandBeleg.PositionsNr
      &ELSE
        &SCOP SORTBY-PHRASE ~{&PA-VIRTUAL-INDEX-DUMMY-SORTBY-PHRASE} BY ttUV_VersandBeleg.CreditTerms BY ttUV_VersandBeleg.BelegNummer BY ttUV_VersandBeleg.PositionsNr
      &ENDIF
      &SCOP KEY-PHRASE ttUV_VersandBeleg.CreditTerms {&PA-OFFSET-COMPARE-GE-ASC} integer(c_offset-value) {&PA-FILTER-PHRASE}
      if c_offset-value <> ? then
        {&OPEN-QUERY-{&BROWSE-NAME}}
      &SCOP KEY-PHRASE true {&PA-FILTER-PHRASE}
      else
        {&OPEN-QUERY-{&BROWSE-NAME}}

  when 'MRPArea':U then
    if pa-DescendingSortOrder then
      &IF "{&PA-USE-INDEX-IN-QUERY}":U = "1":U &THEN
        &SCOP SORTBY-PHRASE use-index MRPAreas ~{&PA-VIRTUAL-INDEX-DUMMY-SORTBY-PHRASE-DESC} BY ttUV_VersandBeleg.MRPArea DESCENDING BY ttUV_VersandBeleg.BelegNummer DESCENDING BY ttUV_VersandBeleg.PositionsNr DESCENDING
      &ELSE
        &SCOP SORTBY-PHRASE ~{&PA-VIRTUAL-INDEX-DUMMY-SORTBY-PHRASE-DESC} BY ttUV_VersandBeleg.MRPArea DESCENDING BY ttUV_VersandBeleg.BelegNummer DESCENDING BY ttUV_VersandBeleg.PositionsNr DESCENDING
      &ENDIF
    &SCOP KEY-PHRASE ttUV_VersandBeleg.MRPArea {&PA-OFFSET-COMPARE-GE-DESC} integer(c_offset-value) {&PA-FILTER-PHRASE}
    if c_offset-value <> ? then
      {&OPEN-QUERY-{&BROWSE-NAME}}
    &SCOP KEY-PHRASE true {&PA-FILTER-PHRASE}
      else
        {&OPEN-QUERY-{&BROWSE-NAME}}

    else
      &IF "{&PA-USE-INDEX-IN-QUERY}":U = "1":U &THEN
        &SCOP SORTBY-PHRASE use-index MRPAreas ~{&PA-VIRTUAL-INDEX-DUMMY-SORTBY-PHRASE} BY ttUV_VersandBeleg.CreditTerms BY ttUV_VersandBeleg.BelegNummer BY ttUV_VersandBeleg.PositionsNr
      &ELSE
        &SCOP SORTBY-PHRASE ~{&PA-VIRTUAL-INDEX-DUMMY-SORTBY-PHRASE} BY ttUV_VersandBeleg.MRPArea BY ttUV_VersandBeleg.BelegNummer BY ttUV_VersandBeleg.PositionsNr
      &ENDIF
      &SCOP KEY-PHRASE ttUV_VersandBeleg.MRPArea {&PA-OFFSET-COMPARE-GE-ASC} integer(c_offset-value) {&PA-FILTER-PHRASE}
      if c_offset-value <> ? then
        {&OPEN-QUERY-{&BROWSE-NAME}}
      &SCOP KEY-PHRASE true {&PA-FILTER-PHRASE}
      else
        {&OPEN-QUERY-{&BROWSE-NAME}}


  {&{&PA-XBASISNAME}_C_OpenQueryCases}
  {&{&PA-XBASISNAME}_U_OpenQueryCases}
  {&{&PA-XBASISNAME}_Q_OpenQueryCases}
  {&{&PA-XBASISNAME}_OpenQueryCases}
  {&{&PA-XBASISNAME}_Y_OpenQueryCases}

  {&{&PA-XBASISNAME}_C_OpenQueryCases_Sort}
  {&{&PA-XBASISNAME}_U_OpenQueryCases_Sort}
  {&{&PA-XBASISNAME}_Q_OpenQueryCases_Sort}
  {&{&PA-XBASISNAME}_OpenQueryCases_Sort}
  {&{&PA-XBASISNAME}_Y_OpenQueryCases_Sort}

  otherwise
    {adm/template/incl/dt_vbs10.if
      &ippSortCaseName = "pa-sortby-case"
      &ippOffsetValue  = "c_offset-value"
    }

end case.

return.

end procedure. /* adm-open-query-cases */
/* _UIB-CODE-BLOCK-END */
&ANALYZE-RESUME

&ANALYZE-SUSPEND _UIB-CODE-BLOCK _PROCEDURE adm-row-available B-table-Win  adm/support/proc/ds_rec00.p
PROCEDURE adm-row-available :
/* Description ---------------------------------------------------------------*/
/*                                                                            */
/* Dispatched to this procedure when the Record-Source has a new row          */
/* available.  This procedure tries to get the new row (or foreign keys)      */
/* from the  Record-Source and process it.                                    */
/*                                                                            */
/* Parameters ----------------------------------------------------------------*/
/*                                                                            */
/* <none>                                                                     */
/*                                                                            */
/*----------------------------------------------------------------------------*/

/*----------------------------------------------------------------------------*/
/* Processing                                                                 */
/*----------------------------------------------------------------------------*/

/* Define variables needed by this internal procedure.                        */

{adm/template/incl/row-head.i}


/* Process the newly available records (i.e. display fields, open queries,    */
/* and/or pass records on to any RECORD-TARGETS).                             */

{adm/template/incl/row-end.i}

end procedure. /* adm-row-available */

/* _UIB-CODE-BLOCK-END */
&ANALYZE-RESUME

&ANALYZE-SUSPEND _UIB-CODE-BLOCK _PROCEDURE adm-set-filter B-table-Win  adm/support/proc/ds_fil00.p
PROCEDURE adm-set-filter :
/* Description ---------------------------------------------------------------*/
/*                                                                            */
/* Load Filter Variables and Open the Query                                   */
/*                                                                            */
/* Parameters ----------------------------------------------------------------*/
/*                                                                            */
/* <none>                                                                     */
/*                                                                            */
/*----------------------------------------------------------------------------*/

/*----------------------------------------------------------------------------*/
/* Processing                                                                 */
/*----------------------------------------------------------------------------*/

/* Start Filter Dialog                                                        */

{adm/template/incl/dt_fil02.if}

/* Load Filter Variables                                                      */

/* --> MO#HIDR-AH4-1123 thongdi_p 20.07.2026 Erweiterung Versandmonitor im Feld Best. Termin */
{adm/incl/d__par01.if
  &ParameterListe = "pa-FilterValues"
  &Parameter      = "xEbLiefertermin"
  &Variable1      = "pa-filter-xEbLiefertermin_min"
  &Variable2      = "pa-filter-xEbLiefertermin_max"
  &cc_Date        = "yes"
}

if pa-filter-xEbLiefertermin_min = pa-filter-xEbLiefertermin_max then
  cMinEqMax = cMinEqMax + ',':U + 'xEbLiefertermin':U.
/* <-- MO#HIDR-AH4-1123 thongdi_p 20.07.2026 Erweiterung Versandmonitor im Feld Best. Termin */

{adm/incl/d__par01.if
  &ParameterListe = "pa-FilterValues"
  &Parameter      = "Konto"
  &Variable1      = "pa-filter-Konto_min"
  &Variable2      = "pa-filter-Konto_max"
  &Datentyp       = "integer"
}

if pa-filter-Konto_min = pa-filter-Konto_max then
  cMinEqMax = cMinEqMax + ',':U + 'Konto':U.

{adm/incl/d__par01.if
  &ParameterListe = "pa-FilterValues"
  &Parameter      = "Artikel"
  &Variable1      = "pa-filter-Artikel_min"
  &Variable2      = "pa-filter-Artikel_max"
}

if pa-filter-Artikel_min = pa-filter-Artikel_max then
  cMinEqMax = cMinEqMax + ',':U + 'Artikel':U.

{adm/incl/d__par01.if
  &ParameterListe = "pa-FilterValues"
  &Parameter      = "ArtikelGruppe"
  &Variable1      = "pa-filter-ArtikelGruppe_min"
  &Variable2      = "pa-filter-ArtikelGruppe_max"
}

if pa-filter-ArtikelGruppe_min = pa-filter-ArtikelGruppe_max then
  cMinEqMax = cMinEqMax + ',':U + 'ArtikelGruppe':U.

{adm/incl/d__par01.if
  &ParameterListe = "pa-FilterValues"
  &Parameter      = "Sparte"
  &Variable1      = "pa-filter-Sparte_min"
  &Variable2      = "pa-filter-Sparte_max"
}

if pa-filter-Sparte_min = pa-filter-Sparte_max then
  cMinEqMax = cMinEqMax + ',':U + 'Sparte':U.

{adm/incl/d__par01.if
  &ParameterListe = "pa-FilterValues"
  &Parameter      = "ArtikelArt"
  &Variable1      = "pa-filter-ArtikelArt_min"
  &Variable2      = "pa-filter-ArtikelArt_max"
  &Datentyp       = "integer"
}

if pa-filter-ArtikelArt_min = pa-filter-ArtikelArt_max then
  cMinEqMax = cMinEqMax + ',':U + 'ArtikelArt':U.

{adm/incl/d__par01.if
  &ParameterListe = "pa-FilterValues"
  &Parameter      = "Wunschtermin"
  &Variable1      = "pa-filter-Wunschtermin_min"
  &Variable2      = "pa-filter-Wunschtermin_max"
  &cc_Date        = "yes"
}

if pa-filter-Wunschtermin_min = pa-filter-Wunschtermin_max then
  cMinEqMax = cMinEqMax + ',':U + 'Wunschtermin':U.

{adm/incl/d__par01.if
  &ParameterListe = "pa-FilterValues"
  &Parameter      = "Liefertermin"
  &Variable1      = "pa-filter-Liefertermin_min"
  &Variable2      = "pa-filter-Liefertermin_max"
  &cc_Date        = "yes"
}

if pa-filter-Liefertermin_min = pa-filter-Liefertermin_max then
  cMinEqMax = cMinEqMax + ',':U + 'Liefertermin':U.

{adm/incl/d__par01.if
  &ParameterListe = "pa-FilterValues"
  &Parameter      = "uCI_Warenausgangstermin"
  &Variable1      = "pa-filter-uCI_Warenausgangst_min"
  &Variable2      = "pa-filter-uCI_Warenausgangst_max"
  &cc_Date        = "yes"
}

if pa-filter-uCI_Warenausgangst_min = pa-filter-uCI_Warenausgangst_max then
  cMinEqMax = cMinEqMax + ',':U + 'uCI_Warenausgangstermin':U.

{adm/incl/d__par01.if
  &ParameterListe = "pa-FilterValues"
  &Parameter      = "Versandtermin"
  &Variable1      = "pa-filter-Versandtermin_min"
  &Variable2      = "pa-filter-Versandtermin_max"
  &cc_Date        = "yes"
}

if pa-filter-Versandtermin_min = pa-filter-Versandtermin_max then
  cMinEqMax = cMinEqMax + ',':U + 'Versandtermin':U.

{adm/incl/d__par01.if
  &ParameterListe = "pa-FilterValues"
  &Parameter      = "BelegNummer"
  &Variable1      = "pa-filter-BelegNummer_min"
  &Variable2      = "pa-filter-BelegNummer_max"
  &Datentyp       = "integer"
}

if pa-filter-BelegNummer_min = pa-filter-BelegNummer_max then
  cMinEqMax = cMinEqMax + ',':U + 'BelegNummer':U.

{adm/incl/d__par01.if
  &ParameterListe = "pa-FilterValues"
  &Parameter      = "Sachbearbeiter"
  &Variable1      = "pa-filter-Sachbearbeiter_min"
  &Variable2      = "pa-filter-Sachbearbeiter_max"
}

if pa-filter-Sachbearbeiter_min = pa-filter-Sachbearbeiter_max then
  cMinEqMax = cMinEqMax + ',':U + 'Sachbearbeiter':U.

{adm/incl/d__par01.if
  &ParameterListe = "pa-FilterValues"
  &Parameter      = "AuftragsArt"
  &Variable1      = "pa-filter-AuftragsArt_min"
  &Variable2      = "pa-filter-AuftragsArt_max"
}

if pa-filter-AuftragsArt_min = pa-filter-AuftragsArt_max then
  cMinEqMax = cMinEqMax + ',':U + 'AuftragsArt':U.

{adm/incl/d__par01.if
  &ParameterListe = "pa-FilterValues"
  &Parameter      = "LieferAdresse"
  &Variable1      = "pa-filter-LieferAdresse_min"
  &Variable2      = "pa-filter-LieferAdresse_max"
  &Datentyp       = "integer"
}

if pa-filter-LieferAdresse_min = pa-filter-LieferAdresse_max then
  cMinEqMax = cMinEqMax + ',':U + 'LieferAdresse':U.

{adm/incl/d__par01.if
  &ParameterListe = "pa-FilterValues"
  &Parameter      = "AdressKennung"
  &Variable1      = "pa-filter-AdressKennung_min"
  &Variable2      = "pa-filter-AdressKennung_max"
}

if pa-filter-AdressKennung_min = pa-filter-AdressKennung_max then
  cMinEqMax = cMinEqMax + ',':U + 'AdressKennung':U.

{adm/incl/d__par01.if
  &ParameterListe = "pa-FilterValues"
  &Parameter      = "Abladestelle"
  &Variable1      = "pa-filter-Abladestelle_min"
  &Variable2      = "pa-filter-Abladestelle_max"
}

if pa-filter-Abladestelle_min = pa-filter-Abladestelle_max then
  cMinEqMax = cMinEqMax + ',':U + 'Abladestelle':U.

{adm/incl/d__par01.if
  &ParameterListe = "pa-FilterValues"
  &Parameter      = "uCI_LagerortKunde"
  &Variable1      = "pa-filter-uCI_LagerortKunde_min"
  &Variable2      = "pa-filter-uCI_LagerortKunde_max"
}

if pa-filter-uCI_LagerortKunde_min = pa-filter-uCI_LagerortKunde_max then
  cMinEqMax = cMinEqMax + ',':U + 'uCI_LagerortKunde':U.

{adm/incl/d__par01.if
  &ParameterListe = "pa-FilterValues"
  &Parameter      = "VersandArt"
  &Variable1      = "pa-filter-VersandArt_min"
  &Variable2      = "pa-filter-VersandArt_max"
  &Datentyp       = "integer"
}

if pa-filter-VersandArt_min = pa-filter-VersandArt_max then
  cMinEqMax = cMinEqMax + ',':U + 'VersandArt':U.

{adm/incl/d__par01.if
  &ParameterListe = "pa-FilterValues"
  &Parameter      = "LieferBedingung"
  &Variable1      = "pa-filter-LieferBedingung_min"
  &Variable2      = "pa-filter-LieferBedingung_max"
  &Datentyp       = "integer"
}

if pa-filter-LieferBedingung_min = pa-filter-LieferBedingung_max then
  cMinEqMax = cMinEqMax + ',':U + 'LieferBedingung':U.

{adm/incl/d__par01.if
  &ParameterListe = "pa-FilterValues"
  &Parameter      = "Lieferant"
  &Variable1      = "pa-filter-Lieferant_min"
  &Variable2      = "pa-filter-Lieferant_max"
  &Datentyp       = "integer"
}

if pa-filter-Lieferant_min = pa-filter-Lieferant_max then
  cMinEqMax = cMinEqMax + ',':U + 'Lieferant':U.


{adm/incl/d__par01.if
  &ParameterListe = "pa-FilterValues"
  &Parameter      = "Lagerort"
  &Variable1      = "pa-filter-StorageArea_min"
  &Variable2      = "pa-filter-StorageArea_max"
  &Datentyp       = "integer"
}

if pa-filter-StorageArea_min = pa-filter-StorageArea_max then
  cMinEqMax = cMinEqMax + ',':U + 'Lagerort':U.

{adm/incl/d__par01.if
  &ParameterListe = "pa-FilterValues"
  &Parameter      = "Zahlungsziel"
  &Variable1      = "pa-filter-CreditTerms_min"
  &Variable2      = "pa-filter-CreditTerms_max"
  &Datentyp       = "integer"
}

if pa-filter-CreditTerms_max = pa-filter-CreditTerms_max then
  cMinEqMax = cMinEqMax + ',':U + 'Zahlungsziel':U.

{adm/incl/d__par01.if
  &ParameterListe = "pa-FilterValues"
  &Parameter      = "LieferRestrikt"
  &Variable1      = "pa-filter-DeliveryRestriction_min"
  &Variable2      = "pa-filter-DeliveryRestriction_max"
  &Datentyp       = "integer"
}

if pa-filter-DeliveryRestriction_min = pa-filter-DeliveryRestriction_max then
  cMinEqMax = cMinEqMax + ',':U + 'LieferRestrikt':U.


{adm/incl/d__par01.if
  &ParameterListe = "pa-FilterValues"
  &Parameter      = "Lagergruppe"
  &Variable1      = "pa-filter-MRPArea_min"
  &Variable2      = "pa-filter-MRPArea_max"
  &Datentyp       = "integer"
}

if pa-filter-MRPArea_min = pa-filter-MRPArea_max then
  cMinEqMax = cMinEqMax + ',':U + 'Lagergruppe':U.


/* Post Processing                                                            */

{adm/template/incl/dt_fil00.if}

return.

end procedure. /* adm-set-filter */

/* _UIB-CODE-BLOCK-END */
&ANALYZE-RESUME

&ANALYZE-SUSPEND _UIB-CODE-BLOCK _PROCEDURE EAN-Teil B-table-Win 
PROCEDURE EAN-Teil :
/* Description ---------------------------------------------------------------*/
/*                                                                            */
/* Search and display of the EAN for a part                                   */
/*                                                                            */
/* Notes ---------------------------------------------------------------------*/
/*                                                                            */
/*                                                                            */
/*                                                                            */
/* Parameters ----------------------------------------------------------------*/
/*                                                                            */
/* <none>                                                                     */
/*                                                                            */
/* Examples ------------------------------------------------------------------*/
/*                                                                            */
/*                                                                            */
/*                                                                            */
/*----------------------------------------------------------------------------*/

/* Variables -----------------------------------------------------------------*/
/*----------------------------------------------------------------------------*/

/* Buffers -------------------------------------------------------------------*/

define buffer bS_ArtMe for S_ArtMe.

/*----------------------------------------------------------------------------*/
/* Processing                                                                 */
/*----------------------------------------------------------------------------*/

if input frame {&frame-name} gcArtikel > '':U then
do:

  find bS_ArtMe                               /* Code checked by ek 04.06.2003 */
    where bS_ArtMe.Firma    = {firma/sartikel.fir pa-firma}
      and bS_ArtMe.Artikel  = input frame {&frame-name} gcArtikel
      and bS_ArtMe.HauptVME = yes
    no-lock no-error.

  if available bS_ArtMe then

    find first gbS_EAN
      where gbS_EAN.Firma   = {firma/sartikel.fir pa-firma}
        and gbS_EAN.Artikel = input frame {&frame-name} gcArtikel
      no-lock no-error.

  gcSuche = (if available gbS_EAN then
               gbS_EAN.EAN
             else
               '':U).

  {adm/incl/d__duh00.if
     &Var1     = "gcSuche"
     &WithFrame = "frame {&frame-name}"}

end.

end procedure. /* EAN-Teil */

/* _UIB-CODE-BLOCK-END */
&ANALYZE-RESUME

&ANALYZE-SUSPEND _UIB-CODE-BLOCK _PROCEDURE FillTT B-table-Win 
PROCEDURE FillTT :
/* Description ---------------------------------------------------------------*/
/*                                                                            */
/* Fills the Temp-Table                                                       */
/*                                                                            */
/* Notes ---------------------------------------------------------------------*/
/*                                                                            */
/*                                                                            */
/*                                                                            */
/* Parameters ----------------------------------------------------------------*/
/*                                                                            */
/* <none>                                                                     */
/*                                                                            */
/* Examples ------------------------------------------------------------------*/
/*                                                                            */
/*                                                                            */
/*                                                                            */
/*----------------------------------------------------------------------------*/

/* Variables -----------------------------------------------------------------*/
/*----------------------------------------------------------------------------*/

define variable rRowid         as rowid     no-undo.

/* Buffers -------------------------------------------------------------------*/

define buffer bS_Kunde      for S_Kunde.
define buffer bS_Lieferant  for S_Lieferant.
define buffer bS_Adresse    for S_Adresse.

define buffer bttUV_VersandBeleg for temp-table ttUV_VersandBeleg.

/*----------------------------------------------------------------------------*/
/* Processing                                                                 */
/*----------------------------------------------------------------------------*/

  assign input frame {&FRAME-NAME}
    giKonto
    giLieferadresse
    gcAdressKennung
    gcAbladestelle
    gcuCI_LagerortKunde
    giLieferant
    giVersandArt
    gtuCI_Warenausgangstermin_min
    gtuCI_Warenausgangstermin_max
    gtVersandtermin_min
    gtVersandtermin_max
    gcArtikel
    gcSuche
    glBelegartU
    glBelegartVUA
    &IF LOOKUP("VS","{&PA-MODULE}") > 0 &THEN
      glDocTypeServiceOrder
      glDocTypeRepairOrder
    &ENDIF
    glBelegartPPF
    glCoverageStatus_Without
    glCoverageStatus_Available
    glCoverageStatus_PAvailable
    glCoverageStatus_Covered
    glCoverageStatus_Open

    gcKonto_Name1       = '':U
    gcKonto_Name2       = '':U
    gcKonto_Ort         = '':U
    gcKonto_Strasse     = '':U
    gcLieferant_Name1   = '':U
    gcLieferant_Name2   = '':U
    gcLieferant_Ort     = '':U
    gcLieferant_Strasse = '':U
    giHits              = 0
    .

  if valid-object(oSelectedObject) then
    oSelectedObject:clearList().

  /* fill info fields */
  find bS_Kunde
    where bS_Kunde.Firma = {firma/s_kunde.fir pACConnectionSvc:prpcCompany}
      and bS_Kunde.Kunde = giKonto
    no-lock no-error.

  if available bS_Kunde then
    find bS_Adresse
      where bS_Adresse.Firma    = {firma/s_adres.fir pACConnectionSvc:prpcCompany}
        and bS_Adresse.AdressNr = bS_Kunde.AdressNr
      no-lock no-error.
  else
  do:

    find bS_Lieferant
      where bS_Lieferant.Firma     = {firma/sliefera.fir pACConnectionSvc:prpcCompany}
        and bS_Lieferant.Lieferant = giKonto
      no-lock no-error.

    if available bS_Lieferant then
      find bS_Adresse
        where bS_Adresse.Firma    = {firma/s_adres.fir pACConnectionSvc:prpcCompany}
          and bS_Adresse.AdressNr = bS_Lieferant.AdressNr
        no-lock no-error.

  end.

  if available bS_Adresse then
    assign
      gcKonto_Name1   = bS_Adresse.Name1
      gcKonto_Name2   = bS_Adresse.Name2
      gcKonto_Ort     = bS_Adresse.Ort
      gcKonto_Strasse = bS_Adresse.Strasse
      .

  find bS_Lieferant
    where bS_Lieferant.Firma     = {firma/sliefera.fir pACConnectionSvc:prpcCompany}
      and bS_Lieferant.Lieferant = giLieferant
    no-lock no-error.

  if available bS_Lieferant then
  do:

    find bS_Adresse
      where bS_Adresse.Firma    = {firma/s_adres.fir pACConnectionSvc:prpcCompany}
        and bS_Adresse.AdressNr = bS_Lieferant.AdressNr
      no-lock no-error.

    if available bS_Adresse then
      assign
        gcLieferant_Name1   = bS_Adresse.Name1
        gcLieferant_Name2   = bS_Adresse.Name2
        gcLieferant_Ort     = bS_Adresse.Ort
        gcLieferant_Strasse = bS_Adresse.Strasse
        .

  end.

  /* set properties for filter values (filter dialog) */
  adm.method.cls.DMCSessionSvc:setObjectProperty (dataset dsUVR_CIVersandBeleg:handle, 'Konto_min':U               , pa-filter-Konto_min              ).
  adm.method.cls.DMCSessionSvc:setObjectProperty (dataset dsUVR_CIVersandBeleg:handle, 'Konto_max':U               , pa-filter-Konto_max              ).
  adm.method.cls.DMCSessionSvc:setObjectProperty (dataset dsUVR_CIVersandBeleg:handle, 'Artikel_min':U             , pa-filter-Artikel_min            ).
  adm.method.cls.DMCSessionSvc:setObjectProperty (dataset dsUVR_CIVersandBeleg:handle, 'Artikel_max':U             , pa-filter-Artikel_max            ).
  adm.method.cls.DMCSessionSvc:setObjectProperty (dataset dsUVR_CIVersandBeleg:handle, 'ArtikelGruppe_min':U       , pa-filter-ArtikelGruppe_min      ).
  adm.method.cls.DMCSessionSvc:setObjectProperty (dataset dsUVR_CIVersandBeleg:handle, 'ArtikelGruppe_max':U       , pa-filter-ArtikelGruppe_max      ).
  adm.method.cls.DMCSessionSvc:setObjectProperty (dataset dsUVR_CIVersandBeleg:handle, 'Sparte_min':U              , pa-filter-Sparte_min             ).
  adm.method.cls.DMCSessionSvc:setObjectProperty (dataset dsUVR_CIVersandBeleg:handle, 'Sparte_max':U              , pa-filter-Sparte_max             ).
  adm.method.cls.DMCSessionSvc:setObjectProperty (dataset dsUVR_CIVersandBeleg:handle, 'ArtikelArt_min':U          , pa-filter-ArtikelArt_min         ).
  adm.method.cls.DMCSessionSvc:setObjectProperty (dataset dsUVR_CIVersandBeleg:handle, 'ArtikelArt_max':U          , pa-filter-ArtikelArt_max         ).
  adm.method.cls.DMCSessionSvc:setObjectProperty (dataset dsUVR_CIVersandBeleg:handle, 'Wunschtermin_min':U        , pa-filter-Wunschtermin_min       ).
  adm.method.cls.DMCSessionSvc:setObjectProperty (dataset dsUVR_CIVersandBeleg:handle, 'Wunschtermin_max':U        , pa-filter-Wunschtermin_max       ).
  adm.method.cls.DMCSessionSvc:setObjectProperty (dataset dsUVR_CIVersandBeleg:handle, 'Liefertermin_min':U        , pa-filter-Liefertermin_min       ).
  adm.method.cls.DMCSessionSvc:setObjectProperty (dataset dsUVR_CIVersandBeleg:handle, 'Liefertermin_max':U        , pa-filter-Liefertermin_max       ).
  adm.method.cls.DMCSessionSvc:setObjectProperty (dataset dsUVR_CIVersandBeleg:handle, 'uCI_Warenausgangst_min':U  , pa-filter-uCI_Warenausgangst_min ).
  adm.method.cls.DMCSessionSvc:setObjectProperty (dataset dsUVR_CIVersandBeleg:handle, 'uCI_Warenausgangst_max':U  , pa-filter-uCI_Warenausgangst_max ).
  adm.method.cls.DMCSessionSvc:setObjectProperty (dataset dsUVR_CIVersandBeleg:handle, 'Versandtermin_min':U       , pa-filter-Versandtermin_min      ).
  adm.method.cls.DMCSessionSvc:setObjectProperty (dataset dsUVR_CIVersandBeleg:handle, 'Versandtermin_max':U       , pa-filter-Versandtermin_max      ).
  adm.method.cls.DMCSessionSvc:setObjectProperty (dataset dsUVR_CIVersandBeleg:handle, 'BelegNummer_min':U         , pa-filter-BelegNummer_min        ).
  adm.method.cls.DMCSessionSvc:setObjectProperty (dataset dsUVR_CIVersandBeleg:handle, 'BelegNummer_max':U         , pa-filter-BelegNummer_max        ).
  adm.method.cls.DMCSessionSvc:setObjectProperty (dataset dsUVR_CIVersandBeleg:handle, 'Sachbearbeiter_min':U      , pa-filter-Sachbearbeiter_min     ).
  adm.method.cls.DMCSessionSvc:setObjectProperty (dataset dsUVR_CIVersandBeleg:handle, 'Sachbearbeiter_max':U      , pa-filter-Sachbearbeiter_max     ).
  adm.method.cls.DMCSessionSvc:setObjectProperty (dataset dsUVR_CIVersandBeleg:handle, 'AuftragsArt_min':U         , pa-filter-AuftragsArt_min        ).
  adm.method.cls.DMCSessionSvc:setObjectProperty (dataset dsUVR_CIVersandBeleg:handle, 'AuftragsArt_max':U         , pa-filter-AuftragsArt_max        ).
  adm.method.cls.DMCSessionSvc:setObjectProperty (dataset dsUVR_CIVersandBeleg:handle, 'LieferAdresse_min':U       , pa-filter-LieferAdresse_min      ).
  adm.method.cls.DMCSessionSvc:setObjectProperty (dataset dsUVR_CIVersandBeleg:handle, 'LieferAdresse_max':U       , pa-filter-LieferAdresse_max      ).
  adm.method.cls.DMCSessionSvc:setObjectProperty (dataset dsUVR_CIVersandBeleg:handle, 'AdressKennung_min':U       , pa-filter-AdressKennung_min      ).
  adm.method.cls.DMCSessionSvc:setObjectProperty (dataset dsUVR_CIVersandBeleg:handle, 'AdressKennung_max':U       , pa-filter-AdressKennung_max      ).
  adm.method.cls.DMCSessionSvc:setObjectProperty (dataset dsUVR_CIVersandBeleg:handle, 'Abladestelle_min':U        , pa-filter-Abladestelle_min       ).
  adm.method.cls.DMCSessionSvc:setObjectProperty (dataset dsUVR_CIVersandBeleg:handle, 'Abladestelle_max':U        , pa-filter-Abladestelle_max       ).
  adm.method.cls.DMCSessionSvc:setObjectProperty (dataset dsUVR_CIVersandBeleg:handle, 'uCI_LagerortKunde_min':U   , pa-filter-uCI_LagerortKunde_min  ).
  adm.method.cls.DMCSessionSvc:setObjectProperty (dataset dsUVR_CIVersandBeleg:handle, 'uCI_LagerortKunde_max':U   , pa-filter-uCI_LagerortKunde_max  ).
  adm.method.cls.DMCSessionSvc:setObjectProperty (dataset dsUVR_CIVersandBeleg:handle, 'VersandArt_min':U          , pa-filter-VersandArt_min         ).
  adm.method.cls.DMCSessionSvc:setObjectProperty (dataset dsUVR_CIVersandBeleg:handle, 'VersandArt_max':U          , pa-filter-VersandArt_max         ).
  adm.method.cls.DMCSessionSvc:setObjectProperty (dataset dsUVR_CIVersandBeleg:handle, 'LieferBedingung_min':U     , pa-filter-LieferBedingung_min    ).
  adm.method.cls.DMCSessionSvc:setObjectProperty (dataset dsUVR_CIVersandBeleg:handle, 'LieferBedingung_max':U     , pa-filter-LieferBedingung_max    ).
  adm.method.cls.DMCSessionSvc:setObjectProperty (dataset dsUVR_CIVersandBeleg:handle, 'Lieferant_min':U           , pa-filter-Lieferant_min          ).
  adm.method.cls.DMCSessionSvc:setObjectProperty (dataset dsUVR_CIVersandBeleg:handle, 'Lieferant_max':U           , pa-filter-Lieferant_max          ).
  adm.method.cls.DMCSessionSvc:setObjectProperty (dataset dsUVR_CIVersandBeleg:handle, 'iMRPRelease_var':U         , pa-filter-iMRPRelease_var        ).
  adm.method.cls.DMCSessionSvc:setObjectProperty (dataset dsUVR_CIVersandBeleg:handle, 'lPastOrderLines_var':U     , pa-filter-lPastOrderLines_var    ).
  adm.method.cls.DMCSessionSvc:setObjectProperty (dataset dsUVR_CIVersandBeleg:handle, 'lTodayOrderLines_var':U    , pa-filter-lTodayOrderLines_var   ).
  adm.method.cls.DMCSessionSvc:setObjectProperty (dataset dsUVR_CIVersandBeleg:handle, 'lFutureOrderLines_var':U   , pa-filter-lFutureOrderLines_var  ).
  adm.method.cls.DMCSessionSvc:setObjectProperty (dataset dsUVR_CIVersandBeleg:handle, 'iBezugsdatum_var':U        , pa-filter-iBezugsdatum_var       ).
  adm.method.cls.DMCSessionSvc:setObjectProperty (dataset dsUVR_CIVersandBeleg:handle, 'iHorizont_var':U           , pa-filter-iHorizont_var          ).
  adm.method.cls.DMCSessionSvc:setObjectProperty (dataset dsUVR_CIVersandBeleg:handle, 'StorageArea_min':U         , pa-filter-StorageArea_min        ).
  adm.method.cls.DMCSessionSvc:setObjectProperty (dataset dsUVR_CIVersandBeleg:handle, 'StorageArea_max':U         , pa-filter-StorageArea_max        ).
  adm.method.cls.DMCSessionSvc:setObjectProperty (dataset dsUVR_CIVersandBeleg:handle, 'CreditTerms_min':U         , pa-filter-CreditTerms_min        ).
  adm.method.cls.DMCSessionSvc:setObjectProperty (dataset dsUVR_CIVersandBeleg:handle, 'CreditTerms_max':U         , pa-filter-CreditTerms_max        ).
  adm.method.cls.DMCSessionSvc:setObjectProperty (dataset dsUVR_CIVersandBeleg:handle, 'DeliveryRestriction_min':U , pa-filter-DeliveryRestriction_min).
  adm.method.cls.DMCSessionSvc:setObjectProperty (dataset dsUVR_CIVersandBeleg:handle, 'DeliveryRestriction_max':U , pa-filter-DeliveryRestriction_max).
  adm.method.cls.DMCSessionSvc:setObjectProperty (dataset dsUVR_CIVersandBeleg:handle, 'MRPArea_min':U             , pa-filter-MRPArea_min            ).
  adm.method.cls.DMCSessionSvc:setObjectProperty (dataset dsUVR_CIVersandBeleg:handle, 'MRPArea_max':U             , pa-filter-MRPArea_max            ).
  /* --> MO#HIDR-AH4-1123 thongdi_p 20.07.2026 Erweiterung Versandmonitor im Feld Best. Termin */
  adm.method.cls.DMCSessionSvc:setObjectProperty (dataset dsUVR_CIVersandBeleg:handle, 'xEbLiefertermin_min':U, pa-filter-xEbLiefertermin_min).
  adm.method.cls.DMCSessionSvc:setObjectProperty (dataset dsUVR_CIVersandBeleg:handle, 'xEbLiefertermin_max':U, pa-filter-xEbLiefertermin_max).
  /* <-- MO#HIDR-AH4-1123 thongdi_p 20.07.2026 Erweiterung Versandmonitor im Feld Best. Termin */
  
  /* set properties for overriding filter values (browser) */
  if giKonto > 0 then
  do:
    adm.method.cls.DMCSessionSvc:setObjectProperty (dataset dsUVR_CIVersandBeleg:handle, 'Konto_min':U             , giKonto                      ).
    adm.method.cls.DMCSessionSvc:setObjectProperty (dataset dsUVR_CIVersandBeleg:handle, 'Konto_max':U             , giKonto                      ).
  end.

  if giLieferadresse > 0 then
  do:
    adm.method.cls.DMCSessionSvc:setObjectProperty (dataset dsUVR_CIVersandBeleg:handle, 'LieferAdresse_min':U     , giLieferadresse              ).
    adm.method.cls.DMCSessionSvc:setObjectProperty (dataset dsUVR_CIVersandBeleg:handle, 'LieferAdresse_max':U     , giLieferadresse              ).
  end.

  if gcAdressKennung > '':U then
  do:
    adm.method.cls.DMCSessionSvc:setObjectProperty (dataset dsUVR_CIVersandBeleg:handle, 'AdressKennung_min':U     , gcAdressKennung              ).
    adm.method.cls.DMCSessionSvc:setObjectProperty (dataset dsUVR_CIVersandBeleg:handle, 'AdressKennung_max':U     , gcAdressKennung              ).
  end.

  if gcAbladestelle > '':U then
  do:
    adm.method.cls.DMCSessionSvc:setObjectProperty (dataset dsUVR_CIVersandBeleg:handle, 'Abladestelle_min':U      , gcAbladestelle               ).
    adm.method.cls.DMCSessionSvc:setObjectProperty (dataset dsUVR_CIVersandBeleg:handle, 'Abladestelle_max':U      , gcAbladestelle               ).
  end.

  if gcuCI_LagerortKunde > '':U then
  do:
    adm.method.cls.DMCSessionSvc:setObjectProperty (dataset dsUVR_CIVersandBeleg:handle, 'uCI_LagerortKunde_min':U , gcuCI_LagerortKunde          ).
    adm.method.cls.DMCSessionSvc:setObjectProperty (dataset dsUVR_CIVersandBeleg:handle, 'uCI_LagerortKunde_max':U , gcuCI_LagerortKunde          ).
  end.

  if giLieferant > 0 then
  do:
    adm.method.cls.DMCSessionSvc:setObjectProperty (dataset dsUVR_CIVersandBeleg:handle, 'Lieferant_min':U         , giLieferant                  ).
    adm.method.cls.DMCSessionSvc:setObjectProperty (dataset dsUVR_CIVersandBeleg:handle, 'Lieferant_max':U         , giLieferant                  ).
  end.

  if giVersandArt <> ? then
  do:
    adm.method.cls.DMCSessionSvc:setObjectProperty (dataset dsUVR_CIVersandBeleg:handle, 'VersandArt_min':U        , giVersandArt                 ).
    adm.method.cls.DMCSessionSvc:setObjectProperty (dataset dsUVR_CIVersandBeleg:handle, 'VersandArt_max':U        , giVersandArt                 ).
  end.

  if gtuCI_Warenausgangstermin_min <> ? then

    adm.method.cls.DMCSessionSvc:setObjectProperty (dataset dsUVR_CIVersandBeleg:handle, 'uCI_Warenausgangst_min':U, gtuCI_Warenausgangstermin_min).

  if gtuCI_Warenausgangstermin_max <> ? then

    adm.method.cls.DMCSessionSvc:setObjectProperty (dataset dsUVR_CIVersandBeleg:handle, 'uCI_Warenausgangst_max':U, gtuCI_Warenausgangstermin_max).

  if gtVersandtermin_min <> ? then

    adm.method.cls.DMCSessionSvc:setObjectProperty (dataset dsUVR_CIVersandBeleg:handle, 'Versandtermin_min':U     , gtVersandtermin_min          ).

  if gtVersandtermin_max <> ? then

    adm.method.cls.DMCSessionSvc:setObjectProperty (dataset dsUVR_CIVersandBeleg:handle, 'Versandtermin_max':U     , gtVersandtermin_max          ).

  if gcArtikel > '':U then
  do:
    adm.method.cls.DMCSessionSvc:setObjectProperty (dataset dsUVR_CIVersandBeleg:handle, 'Artikel_min':U           , gcArtikel                    ).
    adm.method.cls.DMCSessionSvc:setObjectProperty (dataset dsUVR_CIVersandBeleg:handle, 'Artikel_max':U           , gcArtikel                    ).
  end.

  adm.method.cls.DMCSessionSvc:setObjectProperty (dataset dsUVR_CIVersandBeleg:handle, 'lBelegartU_var':U  , glBelegartU  ).
  adm.method.cls.DMCSessionSvc:setObjectProperty (dataset dsUVR_CIVersandBeleg:handle, 'lBelegartVUA_var':U, glBelegartVUA).
  &IF LOOKUP("VS","{&PA-MODULE}") > 0 &THEN
    adm.method.cls.DMCSessionSvc:setObjectProperty (dataset dsUVR_CIVersandBeleg:handle, 'lDocTypeServiceOrder_var':U  , glDocTypeServiceOrder).
    adm.method.cls.DMCSessionSvc:setObjectProperty (dataset dsUVR_CIVersandBeleg:handle, 'lDocTypeRepairOrder_var':U   , glDocTypeRepairOrder ).
  &ENDIF
  adm.method.cls.DMCSessionSvc:setObjectProperty (dataset dsUVR_CIVersandBeleg:handle, 'lBelegartPPF_var':U, glBelegartPPF).

  adm.method.cls.DMCSessionSvc:setObjectProperty (dataset dsUVR_CIVersandBeleg:handle, 'lCoverageStatus_Without_var':U   , glCoverageStatus_Without         ).
  adm.method.cls.DMCSessionSvc:setObjectProperty (dataset dsUVR_CIVersandBeleg:handle, 'lCoverageStatus_Available_var':U , glCoverageStatus_Available       ).
  adm.method.cls.DMCSessionSvc:setObjectProperty (dataset dsUVR_CIVersandBeleg:handle, 'lCoverageStatus_PAvailable_var':U, glCoverageStatus_PAvailable      ).
  adm.method.cls.DMCSessionSvc:setObjectProperty (dataset dsUVR_CIVersandBeleg:handle, 'lCoverageStatus_Covered_var':U   , glCoverageStatus_Covered         ).
  adm.method.cls.DMCSessionSvc:setObjectProperty (dataset dsUVR_CIVersandBeleg:handle, 'lCoverageStatus_Open_var':U      , glCoverageStatus_Open            ).

  /* fill the dataset */
  {call dsUVR_CIVersandBeleg emptyDataset}.
  {call dsUVR_CIVersandBeleg fillDataset}.

  for each bttUV_VersandBeleg
    exclusive-lock on error undo, throw:

    bttUV_VersandBeleg.Markiert = oSelectedObject:lIsSelected(bttUV_VersandBeleg.Owning_Obj).

  end.

  gcMarkedLines = '':U.  

  run UpdateTotalValues.

  run RefreshTitle.

  run dispatch('open-query':U).

  if gcOffset-value > '':U then
  do:

    &SCOP FIND-OPTION {&PA-FINDOPTION-FIRST}
    &SCOP OFFSET-VALUE gcOffset-value
    &SCOP OFFSET-COMPARE {&PA-OFFSET-COMPARE-GE}
    {&FIND-STATEMENT}
    &UNDEFINE OFFSET-COMPARE
    &UNDEFINE OFFSET-VALUE

    if not available ttUV_VersandBeleg then
    do:
      &SCOP FIND-OPTION {&PA-FINDOPTION-PREV}
      {&FIND-STATEMENT}
    end.

    if available ttUV_VersandBeleg then
    do:
      rRowid = rowid(ttUV_VersandBeleg).
      run RepositionBrowse(rRowid) no-error.
    end.

  end. /* if gcOffset-value > '':U */

  finally:

    gcOffset-value = ?.

  end finally.

end procedure. /* FillTT */

/* _UIB-CODE-BLOCK-END */
&ANALYZE-RESUME

&ANALYZE-SUSPEND _UIB-CODE-BLOCK _PROCEDURE Kunde-Teil B-table-Win 
PROCEDURE Kunde-Teil :
/* Description ---------------------------------------------------------------*/
/*                                                                            */
/* Search and display of the Kunde-Teil for a part                            */
/*                                                                            */
/* Notes ---------------------------------------------------------------------*/
/*                                                                            */
/*                                                                            */
/*                                                                            */
/* Parameters ----------------------------------------------------------------*/
/*                                                                            */
/* <none>                                                                     */
/*                                                                            */
/* Examples ------------------------------------------------------------------*/
/*                                                                            */
/*                                                                            */
/*                                                                            */
/*----------------------------------------------------------------------------*/

/* Variables -----------------------------------------------------------------*/
/*----------------------------------------------------------------------------*/

/* Buffers -------------------------------------------------------------------*/

/*----------------------------------------------------------------------------*/
/* Processing                                                                 */
/*----------------------------------------------------------------------------*/

if input frame {&frame-name} gcArtikel > '':U then
do:

  find first gbS_ArtKunde
    where gbS_ArtKunde.Firma   = {firma/sartkund.fir pa-firma}
      and gbS_ArtKunde.Artikel = input frame {&frame-name} gcArtikel
    no-lock no-error.

  gcSuche = (if available gbS_ArtKunde then
               gbS_ArtKunde.ArtikelNr
             else
               '':U).

  {adm/incl/d__duh00.if
     &Var1     = "gcSuche"
     &WithFrame = "frame {&frame-name}"}

end.

end procedure. /* Kunde-Teil */

/* _UIB-CODE-BLOCK-END */
&ANALYZE-RESUME

&ANALYZE-SUSPEND _UIB-CODE-BLOCK _PROCEDURE local-cancel-record B-table-Win 
PROCEDURE local-cancel-record :
/* Description ---------------------------------------------------------------*/
/*                                                                            */
/* Super Override                                                             */
/*                                                                            */
/* Notes ---------------------------------------------------------------------*/
/*                                                                            */
/*                                                                            */
/*                                                                            */
/* Parameters ----------------------------------------------------------------*/
/*                                                                            */
/* <none>                                                                     */
/*                                                                            */
/* Examples ------------------------------------------------------------------*/
/*                                                                            */
/*                                                                            */
/*                                                                            */
/*----------------------------------------------------------------------------*/

/* Variables -----------------------------------------------------------------*/
/*----------------------------------------------------------------------------*/

/* Buffers -------------------------------------------------------------------*/

/*----------------------------------------------------------------------------*/
/* Processing                                                                 */
/*----------------------------------------------------------------------------*/

glADM-Cancel = yes.

/* Execute standard behavior -------------------------------------------------*/

run dispatch('cancel-record':U).

end procedure. /* local-cancel-record */

/* _UIB-CODE-BLOCK-END */
&ANALYZE-RESUME

&ANALYZE-SUSPEND _UIB-CODE-BLOCK _PROCEDURE local-disable-fields B-table-Win 
PROCEDURE local-disable-fields :
/* Description ---------------------------------------------------------------*/
/*                                                                            */
/*                                                                            */
/*                                                                            */
/* Notes ---------------------------------------------------------------------*/
/*                                                                            */
/*                                                                            */
/*                                                                            */
/* Parameters ----------------------------------------------------------------*/
/*                                                                            */
/* <none>                                                                     */
/*                                                                            */
/* Examples ------------------------------------------------------------------*/
/*                                                                            */
/*                                                                            */
/*                                                                            */
/*----------------------------------------------------------------------------*/

/* Variables -----------------------------------------------------------------*/
/*----------------------------------------------------------------------------*/

/* Buffers -------------------------------------------------------------------*/

/*----------------------------------------------------------------------------*/
/* Processing                                                                 */
/*----------------------------------------------------------------------------*/

/* Execute standard behavior -------------------------------------------------*/

run dispatch('disable-fields':U).

if return-value <> 'adm-error':U then do:

  {fnarg pa_lUISvcSetWidgetSensitiveState
     "gcAbladestelle:handle in frame {&frame-name},
       yes"}.

  {fnarg pa_lUISvcSetWidgetSensitiveState
     "gcAdressKennung:handle in frame {&frame-name},
       yes"}.

  {fnarg pa_lUISvcSetWidgetSensitiveState
     "gcArtikel:handle in frame {&frame-name},
       yes"}.

  {fnarg pa_lUISvcSetWidgetSensitiveState
     "gcSuche:handle in frame {&frame-name},
       yes"}.

  {fnarg pa_lUISvcSetWidgetSensitiveState
     "gcuCI_LagerortKunde:handle in frame {&frame-name},
       yes"}.

  {fnarg pa_lUISvcSetWidgetSensitiveState
     "giKonto:handle in frame {&frame-name},
       yes"}.

  {fnarg pa_lUISvcSetWidgetSensitiveState
     "giLieferadresse:handle in frame {&frame-name},
       yes"}.

  {fnarg pa_lUISvcSetWidgetSensitiveState
     "giLieferant:handle in frame {&frame-name},
       yes"}.

  {fnarg pa_lUISvcSetWidgetSensitiveState
     "giVersandArt:handle in frame {&frame-name},
       yes"}.

  {fnarg pa_lUISvcSetWidgetSensitiveState
     "gtuCI_Warenausgangstermin_max:handle in frame {&frame-name},
       yes"}.

  {fnarg pa_lUISvcSetWidgetSensitiveState
     "gtuCI_Warenausgangstermin_min:handle in frame {&frame-name},
       yes"}.

  {fnarg pa_lUISvcSetWidgetSensitiveState
     "gtVersandtermin_max:handle in frame {&frame-name},
       yes"}.

  {fnarg pa_lUISvcSetWidgetSensitiveState
     "gtVersandtermin_min:handle in frame {&frame-name},
       yes"}.

  {fnarg pa_lUISvcSetWidgetSensitiveState
     "glBelegartPPF:handle in frame {&frame-name},
       yes"}.

  {fnarg pa_lUISvcSetWidgetSensitiveState
     "glBelegartU:handle in frame {&frame-name},
       yes"}.

  {fnarg pa_lUISvcSetWidgetSensitiveState
     "glBelegartVUA:handle in frame {&frame-name},
       yes"}.
   &IF LOOKUP("VS","{&PA-MODULE}") > 0 &THEN    
   {fnarg pa_lUISvcSetWidgetSensitiveState
     "glDocTypeServiceOrder:handle in frame {&frame-name},
       yes"}.
   {fnarg pa_lUISvcSetWidgetSensitiveState
     "glDocTypeRepairOrder:handle in frame {&frame-name},
       yes"}.    
   &ENDIF         

  {fnarg pa_lUISvcSetWidgetSensitiveState
     "glCoverageStatus_Without:handle in frame {&frame-name},
       yes"}.

  {fnarg pa_lUISvcSetWidgetSensitiveState
     "glCoverageStatus_Available:handle in frame {&frame-name},
       yes"}.

  {fnarg pa_lUISvcSetWidgetSensitiveState
     "glCoverageStatus_PAvailable:handle in frame {&frame-name},
       yes"}.

  {fnarg pa_lUISvcSetWidgetSensitiveState
     "glCoverageStatus_Covered:handle in frame {&frame-name},
       yes"}.

  {fnarg pa_lUISvcSetWidgetSensitiveState
     "glCoverageStatus_Open:handle in frame {&frame-name},
       yes"}.

end.

end procedure. /* local-disable-fields */

/* _UIB-CODE-BLOCK-END */
&ANALYZE-RESUME

&ANALYZE-SUSPEND _UIB-CODE-BLOCK _PROCEDURE local-enable-fields B-table-Win 
PROCEDURE local-enable-fields :
/* Description ---------------------------------------------------------------*/
/*                                                                            */
/*                                                                            */
/*                                                                            */
/* Notes ---------------------------------------------------------------------*/
/*                                                                            */
/*                                                                            */
/*                                                                            */
/* Parameters ----------------------------------------------------------------*/
/*                                                                            */
/* <none>                                                                     */
/*                                                                            */
/* Examples ------------------------------------------------------------------*/
/*                                                                            */
/*                                                                            */
/*                                                                            */
/*----------------------------------------------------------------------------*/

/* Variables -----------------------------------------------------------------*/
/*----------------------------------------------------------------------------*/

/* Buffers -------------------------------------------------------------------*/

/*----------------------------------------------------------------------------*/
/* Processing                                                                 */
/*----------------------------------------------------------------------------*/

/* Execute standard behavior -------------------------------------------------*/

run dispatch('enable-fields':U).

if return-value <> 'adm-error':U then do:

  {fnarg pa_lUISvcSetWidgetSensitiveState
     "gcAbladestelle:handle in frame {&frame-name},
       no"}.

  {fnarg pa_lUISvcSetWidgetSensitiveState
     "gcAdressKennung:handle in frame {&frame-name},
       no"}.

  {fnarg pa_lUISvcSetWidgetSensitiveState
     "gcArtikel:handle in frame {&frame-name},
       no"}.

  {fnarg pa_lUISvcSetWidgetSensitiveState
     "gcSuche:handle in frame {&frame-name},
       no"}.

  {fnarg pa_lUISvcSetWidgetSensitiveState
     "gcuCI_LagerortKunde:handle in frame {&frame-name},
       no"}.

  {fnarg pa_lUISvcSetWidgetSensitiveState
     "giKonto:handle in frame {&frame-name},
       no"}.

  {fnarg pa_lUISvcSetWidgetSensitiveState
     "giLieferadresse:handle in frame {&frame-name},
       no"}.

  {fnarg pa_lUISvcSetWidgetSensitiveState
     "giLieferant:handle in frame {&frame-name},
       no"}.

  {fnarg pa_lUISvcSetWidgetSensitiveState
     "giVersandArt:handle in frame {&frame-name},
       no"}.

  {fnarg pa_lUISvcSetWidgetSensitiveState
     "gtuCI_Warenausgangstermin_max:handle in frame {&frame-name},
       no"}.

  {fnarg pa_lUISvcSetWidgetSensitiveState
     "gtuCI_Warenausgangstermin_min:handle in frame {&frame-name},
       no"}.

  {fnarg pa_lUISvcSetWidgetSensitiveState
     "gtVersandtermin_max:handle in frame {&frame-name},
       no"}.

  {fnarg pa_lUISvcSetWidgetSensitiveState
     "gtVersandtermin_min:handle in frame {&frame-name},
       no"}.

  {fnarg pa_lUISvcSetWidgetSensitiveState
     "glBelegartPPF:handle in frame {&frame-name},
       no"}.

  {fnarg pa_lUISvcSetWidgetSensitiveState
     "glBelegartU:handle in frame {&frame-name},
       no"}.

  {fnarg pa_lUISvcSetWidgetSensitiveState
     "glBelegartVUA:handle in frame {&frame-name},
       no"}.
  &IF LOOKUP("VS","{&PA-MODULE}") > 0 &THEN
  {fnarg pa_lUISvcSetWidgetSensitiveState
     "glDocTypeServiceOrder:handle in frame {&frame-name},
       no"}.
  {fnarg pa_lUISvcSetWidgetSensitiveState
     "glDocTypeRepairOrder:handle in frame {&frame-name},
       no"}.     
  &ENDIF          

  {fnarg pa_lUISvcSetWidgetSensitiveState
     "glCoverageStatus_Without:handle in frame {&frame-name},
       no"}.

  {fnarg pa_lUISvcSetWidgetSensitiveState
     "glCoverageStatus_Available:handle in frame {&frame-name},
       no"}.

  {fnarg pa_lUISvcSetWidgetSensitiveState
     "glCoverageStatus_PAvailable:handle in frame {&frame-name},
       no"}.

  {fnarg pa_lUISvcSetWidgetSensitiveState
     "glCoverageStatus_Covered:handle in frame {&frame-name},
       no"}.

  {fnarg pa_lUISvcSetWidgetSensitiveState
     "glCoverageStatus_Open:handle in frame {&frame-name},
       no"}.

end.

end procedure. /* local-enable-fields */

/* _UIB-CODE-BLOCK-END */
&ANALYZE-RESUME

&ANALYZE-SUSPEND _UIB-CODE-BLOCK _PROCEDURE local-help-begin B-table-Win 
PROCEDURE local-help-begin :
/* Description ---------------------------------------------------------------*/
/*                                                                            */
/* Super Override                                                             */
/*                                                                            */
/* Notes ---------------------------------------------------------------------*/
/*                                                                            */
/*                                                                            */
/*                                                                            */
/* Parameters ----------------------------------------------------------------*/
/*                                                                            */
/* <none>                                                                     */
/*                                                                            */
/* Examples ------------------------------------------------------------------*/
/*                                                                            */
/*                                                                            */
/*                                                                            */
/*----------------------------------------------------------------------------*/

/* Variables -----------------------------------------------------------------*/
/*----------------------------------------------------------------------------*/

/* Buffers -------------------------------------------------------------------*/

/*----------------------------------------------------------------------------*/
/* Processing                                                                 */
/*----------------------------------------------------------------------------*/

assign
  pa-hlp-string = adm.method.cls.DMCParameterStringSvc:cWriteValue(pa-hlp-string, 'Kunde':U, giKonto:input-value in frame {&FRAME-NAME})
  pa-hlp-string = adm.method.cls.DMCParameterStringSvc:cWriteValue(pa-hlp-string, 'AdressTyp':U, 'L':U)
  pa-hlp-string = adm.method.cls.DMCParameterStringSvc:cWriteValue(pa-hlp-string, 'LiefAdrAbladestelle':U, giLieferadresse:input-value in frame {&FRAME-NAME})
  pa-hlp-string = adm.method.cls.DMCParameterStringSvc:cWriteValue(pa-hlp-string, 'Suchfeld':U, giSuchfeld)    
  .

 if {focus name} = 'gcSuche':U then

   pa-hlp-string = adm.method.cls.DMCParameterStringSvc:cWriteValue
                     (pa-hlp-string,
                      'key-name':U,
                      (if giSuchfeld      = 1 then
                         'ArtikelNr':U
                       else if giSuchfeld = 2 then
                         'EAN':U
                       else if giSuchfeld = 3 then
                         'Suchbegriff':U
                       else if giSuchfeld = 4 then
                         'Selektion':U
                       else
                         'SortBezeichnung':U)).

/* Execute standard behavior -------------------------------------------------*/

run dispatch('help-begin':U).

end procedure. /* local-help-begin */

/* _UIB-CODE-BLOCK-END */
&ANALYZE-RESUME

&ANALYZE-SUSPEND _UIB-CODE-BLOCK _PROCEDURE local-help-complete B-table-Win 
PROCEDURE local-help-complete :
/* Description ---------------------------------------------------------------*/
/*                                                                            */
/* Super Override                                                             */
/*                                                                            */
/* Notes ---------------------------------------------------------------------*/
/*                                                                            */
/*                                                                            */
/*                                                                            */
/* Parameters ----------------------------------------------------------------*/
/*                                                                            */
/* <none>                                                                     */
/*                                                                            */
/* Examples ------------------------------------------------------------------*/
/*                                                                            */
/*                                                                            */
/*                                                                            */
/*----------------------------------------------------------------------------*/

/* Variables -----------------------------------------------------------------*/
/*----------------------------------------------------------------------------*/

define variable c_value   as   character           no-undo.
define variable cPart     like S_Artikel.Artikel   no-undo.

/* Buffers -------------------------------------------------------------------*/

define buffer bS_LieferAdresse for S_LieferAdresse.

/*----------------------------------------------------------------------------*/
/* Processing                                                                 */
/*----------------------------------------------------------------------------*/

/* Execute standard behavior -------------------------------------------------*/

assign
  c_value = ?
  cPart   = gcArtikel:screen-value in frame {&frame-name}
  .

run dispatch('help-complete':U).

if return-value <> 'adm-error':U then
do:

  case adm.method.cls.DMCParameterStringSvc:cReadValue(pa-hlp-string,'key-name':U,1):

    when 'AdressKennung':U then
    do:

      find bS_LieferAdresse /* code checked by Warter 07.08.2018 */
        where bS_LieferAdresse.Firma          = {firma/s_kunde.fir pa-Firma}
          and bS_LieferAdresse.Kunde          = input frame {&frame-name} giKonto
          and bS_LieferAdresse.AdressKennung  = input frame {&frame-name} gcAdressKennung
        no-lock no-error.

      if available bS_LieferAdresse then
        {setwidgetattr
           "giLieferadresse"
           "screen-value"
           "string(bS_LieferAdresse.LieferAdresse)"
           "in frame {&FRAME-NAME}"}.
      else
        {setwidgetattr
           "giLieferadresse"
           "screen-value"
           "'0':U"
           "in frame {&frame-name}"}.

    end.

    when 'Adresse':U then
    do:

      find bS_LieferAdresse
        where bS_LieferAdresse.Firma          = {firma/s_kunde.fir pa-Firma}
          and bS_LieferAdresse.Kunde          = input frame {&frame-name} giKonto
          and bS_LieferAdresse.LieferAdresse  = input frame {&frame-name} giLieferadresse
        no-lock no-error.

      if available bS_LieferAdresse then
        {setwidgetattr
           "gcAdressKennung"
           "screen-value"
           "string(bS_LieferAdresse.AdressKennung)"
           "in frame {&frame-name}"}.

    end.

    when 'ArtikelNr':U then
    do:

      c_value = adm.method.cls.DMCParameterStringSvc:cReadValue(pa-hlp-string, 'S_ArtKunde:ROWID':U, 1).

      if c_value <> ? then
      do:

        find gbS_ArtKunde
          where rowid(gbS_ArtKunde) = to-rowid(c_value)
          no-lock no-error.

        if available gbS_ArtKunde then
        do:

          {setwidgetattr
             "gcArtikel"
             "screen-value"
             "gbS_ArtKunde.Artikel"
             "in frame {&frame-name}"}.
          gcSuche                                       = gbS_ArtKunde.ArtikelNr.

        end.
        else
          gcSuche = '':U.

      end.
      else
        gcSuche = '':U.

      {adm/incl/d__duh00.if
         &Var1     = "gcSuche"
         &WithFrame = "frame {&frame-name}"}

    end.

    when 'EAN':U then
    do:

      c_value = adm.method.cls.DMCParameterStringSvc:cReadValue(pa-hlp-string, 'S_EAN:ROWID':U, 1).

      if c_value <> ? then
      do:

        find gbS_EAN
          where rowid(gbS_EAN) = to-rowid(c_value)
          no-lock no-error.

        if available gbS_EAN then

          assign
            {setwidgetattr
               "gcArtikel"
               "screen-value"
               "gbS_EAN.Artikel"
               "in frame {&frame-name}"}
            gcSuche                                       = gbS_EAN.EAN
            .

        else
          gcSuche = '':U.

      end.
      else
        gcSuche = '':U.

      {adm/incl/d__duh00.if
         &Var1     = "gcSuche"
         &WithFrame = "frame {&frame-name}"}

    end.

    when      'Suchbegriff':U
      or when 'Selektion':U
      or when 'SortBezeichnung':U then
    do:

      c_value = adm.method.cls.DMCParameterStringSvc:cReadValue(pa-hlp-string, 'S_Artikel:ROWID':U, 1).

      if c_value <> ? then
      do:

        find S_Artikel
          where rowid(S_Artikel) = to-rowid(c_value)
          no-lock no-error.

        if available S_Artikel then
        do:

          {setwidgetattr
             "gcArtikel"
             "screen-value"
             "S_Artikel.Artikel"
             "in frame {&frame-name}"}.
          gcSuche                                       = (if giSuchfeld = 3 then
                                                             S_Artikel.Suchbegriff
                                                           else if giSuchfeld = 4 then
                                                             S_Artikel.Selektion
                                                           else
                                                             S_Artikel.SortBezeichnung).

        end.                                            
        else
          gcSuche = '':U.

      end.
      else
        gcSuche = '':U.

      {adm/incl/d__duh00.if
         &Var1     = "gcSuche"
         &WithFrame = "frame {&frame-name}"}

      if gcSuche > '':U then

        run set-link-attribute in adm-broker-hdl
          (this-procedure,
           'record-target':U,
           'Artikel=':U + quoter(input frame {&frame-name} gcArtikel)).

    end.

  end case.

end.

end procedure. /* local-help-complete */

/* _UIB-CODE-BLOCK-END */
&ANALYZE-RESUME

&ANALYZE-SUSPEND _UIB-CODE-BLOCK _PROCEDURE local-initialize B-table-Win 
PROCEDURE local-initialize :
/* Description ---------------------------------------------------------------*/
/*                                                                            */
/*                                                                            */
/*                                                                            */
/* Notes ---------------------------------------------------------------------*/
/*                                                                            */
/*                                                                            */
/*                                                                            */
/* Parameters ----------------------------------------------------------------*/
/*                                                                            */
/* <none>                                                                     */
/*                                                                            */
/* Examples ------------------------------------------------------------------*/
/*                                                                            */
/*                                                                            */
/*                                                                            */
/*----------------------------------------------------------------------------*/

/* Variables -----------------------------------------------------------------*/
/*----------------------------------------------------------------------------*/

/* Buffers -------------------------------------------------------------------*/

/*----------------------------------------------------------------------------*/
/* Processing                                                                 */
/*----------------------------------------------------------------------------*/

oSelectedObject = stamm.cls.S_CSelectedObjectsSvo:create().

assign
  {setwidgetattr
     "ttUV_VersandBeleg.uCI_Hinweis1"
     "label"
     "string(adm.config.cls.DCCAppConfigSvc:prpoInstance:cParameterValue('UCA_ReleaseLabelRemark1':U))"
     "in browse {&browse-name}"}
  {setwidgetattr
     "ttUV_VersandBeleg.uCI_Hinweis2"
     "label"
     "string(adm.config.cls.DCCAppConfigSvc:prpoInstance:cParameterValue('UCA_ReleaseLabelRemark2':U))"
     "in browse {&browse-name}"}
  {setwidgetattr
     "ttUV_VersandBeleg.uCI_Hinweis3"
     "label"
     "string(adm.config.cls.DCCAppConfigSvc:prpoInstance:cParameterValue('UCA_ReleaseLabelRemark3':U))"
     "in browse {&browse-name}"}
  {setwidgetattr
     "ttUV_VersandBeleg.uCI_Hinweis4"
     "label"
     "string(adm.config.cls.DCCAppConfigSvc:prpoInstance:cParameterValue('UCA_ReleaseLabelRemark4':U))"
     "in browse {&browse-name}"}
  gcUCI_CoverageStatus_ColorBG                                                 = adm.config.cls.DCCAppConfigSvc:prpoInstance:cParameterValue
                                                                                   ('UCI_CoverageStatus_ColorBG':U, ',':U)
  gcUCI_CoverageStatus_ColorFG                                                 = adm.config.cls.DCCAppConfigSvc:prpoInstance:cParameterValue
                                                                                   ('UCI_CoverageStatus_ColorFG':U, ',':U)
  gcUCI_CoverageStatus_Keys                                                    = adm.config.cls.DCCAppConfigSvc:prpoInstance:cParameterValue
                                                                                   ('UCI_CoverageStatus_Keys':U, ',':U)
  gcUCI_CoverageStatus_Desc                                                    = adm.config.cls.DCCAppConfigSvc:prpoInstance:cParameterValue
                                                                                   ('UCI_CoverageStatus_Desc':U, '|':U)
  gcSB_TimeUnits_keys                                                          = adm.config.cls.DCCAppConfigSvc:prpoInstance:cParameterValue
                                                                                   ('SB_TimeUnits_keys':U, ',':U)
  gcSB_TimeUnits_desc                                                          = adm.config.cls.DCCAppConfigSvc:prpoInstance:cParameterValue
                                                                                   ('SB_TimeUnits_desc':U, ',':U)
  giSuchfeld                                                                   = adm.config.cls.DCCAppConfigSvc:prpoInstance:iParameterValue
                                                                                   ('VB_SalesDocLineSearchField':U)
  {setwidgetattr
     "menu-item mi_Suche_nach_Kunden-Teilenumme"
     "checked"
     "(giSuchfeld = 1)"
     "in menu POPUP-MENU-gcSuche"}
  {setwidgetattr
     "menu-item mi_Suche_nach_EAN-Nummer"
     "checked"
     "(giSuchfeld = 2)"
     "in menu POPUP-MENU-gcSuche"}
  {setwidgetattr
     "menu-item mi_Suche_nach_Suchbegriff"
     "checked"
     "(giSuchfeld = 3)"
     "in menu POPUP-MENU-gcSuche"}
  {setwidgetattr
     "menu-item mi_Suche_nach_Selektion"
     "checked"
     "(giSuchfeld = 4)"
     "in menu POPUP-MENU-gcSuche"}
  {setwidgetattr
     "menu-item mi_Suche_nach_SortierBez"
     "checked"
     "(giSuchfeld = 5)"
     "in menu POPUP-MENU-gcSuche"}
  .

{fnarg
  pa_lUISvcSetLabel
  "glCoverageStatus_Without:handle in frame {&FRAME-NAME},
   adm.config.cls.DCCAppConfigSvc:prpoInstance:cParamValByRefParamVal('UCI_CoverageStatus_Desc':U, {&uCI_CoverageStatus_Without})"}.

{fnarg
  pa_lUISvcSetLabel
  "glCoverageStatus_Available:handle in frame {&FRAME-NAME},
   adm.config.cls.DCCAppConfigSvc:prpoInstance:cParamValByRefParamVal('UCI_CoverageStatus_Desc':U, {&uCI_CoverageStatus_Available})"}.

{fnarg
  pa_lUISvcSetLabel
  "glCoverageStatus_PAvailable:handle in frame {&FRAME-NAME},
   adm.config.cls.DCCAppConfigSvc:prpoInstance:cParamValByRefParamVal('UCI_CoverageStatus_Desc':U, {&uCI_CoverageStatus_PartiallyAvailable})"}.

{fnarg
  pa_lUISvcSetLabel
  "glCoverageStatus_Covered:handle in frame {&FRAME-NAME},
   adm.config.cls.DCCAppConfigSvc:prpoInstance:cParamValByRefParamVal('UCI_CoverageStatus_Desc':U, {&uCI_CoverageStatus_Covered})"}.

{fnarg
  pa_lUISvcSetLabel
  "glCoverageStatus_Open:handle in frame {&FRAME-NAME},
   adm.config.cls.DCCAppConfigSvc:prpoInstance:cParamValByRefParamVal('UCI_CoverageStatus_Desc':U, {&uCI_CoverageStatus_Open})"}.


/* Execute standard behavior -------------------------------------------------*/

run dispatch('initialize':U).

if return-value = 'adm-error':U then
  return return-value.

{fnarg
  pa_lUISvcSetWidgetColor
  "glCoverageStatus_Without:HANDLE in frame {&FRAME-NAME} ,
   adm.config.cls.DCCAppConfigSvc:prpoInstance:cParamValByRefParamVal('UCI_CoverageStatus_ColorBG':U, {&uCI_CoverageStatus_Without})
   + ',':U +
   adm.config.cls.DCCAppConfigSvc:prpoInstance:cParamValByRefParamVal('UCI_CoverageStatus_ColorFG':U, {&uCI_CoverageStatus_Without})"}.

{fnarg
  pa_lUISvcSetWidgetColor
  "glCoverageStatus_Available:HANDLE in frame {&FRAME-NAME} ,
   adm.config.cls.DCCAppConfigSvc:prpoInstance:cParamValByRefParamVal('UCI_CoverageStatus_ColorBG':U, {&uCI_CoverageStatus_Available})
   + ',':U +
   adm.config.cls.DCCAppConfigSvc:prpoInstance:cParamValByRefParamVal('UCI_CoverageStatus_ColorFG':U, {&uCI_CoverageStatus_Available})"}.

{fnarg
  pa_lUISvcSetWidgetColor
  "glCoverageStatus_PAvailable:HANDLE in frame {&FRAME-NAME} ,
   adm.config.cls.DCCAppConfigSvc:prpoInstance:cParamValByRefParamVal('UCI_CoverageStatus_ColorBG':U, {&uCI_CoverageStatus_PartiallyAvailable})
   + ',':U +
   adm.config.cls.DCCAppConfigSvc:prpoInstance:cParamValByRefParamVal('UCI_CoverageStatus_ColorFG':U, {&uCI_CoverageStatus_PartiallyAvailable})"}.

{fnarg
  pa_lUISvcSetWidgetColor
  "glCoverageStatus_Covered:HANDLE in frame {&FRAME-NAME} ,
   adm.config.cls.DCCAppConfigSvc:prpoInstance:cParamValByRefParamVal('UCI_CoverageStatus_ColorBG':U, {&uCI_CoverageStatus_Covered})
   + ',':U +
   adm.config.cls.DCCAppConfigSvc:prpoInstance:cParamValByRefParamVal('UCI_CoverageStatus_ColorFG':U, {&uCI_CoverageStatus_Covered})"}.

{fnarg
  pa_lUISvcSetWidgetColor
  "glCoverageStatus_Open:HANDLE in frame {&FRAME-NAME} ,
   adm.config.cls.DCCAppConfigSvc:prpoInstance:cParamValByRefParamVal('UCI_CoverageStatus_ColorBG':U, {&uCI_CoverageStatus_Open})
   + ',':U +
   adm.config.cls.DCCAppConfigSvc:prpoInstance:cParamValByRefParamVal('UCI_CoverageStatus_ColorFG':U, {&uCI_CoverageStatus_Open})"}.

end procedure. /* local-initialize */

/* _UIB-CODE-BLOCK-END */
&ANALYZE-RESUME

&ANALYZE-SUSPEND _UIB-CODE-BLOCK _PROCEDURE local-refresh-query B-table-Win 
PROCEDURE local-refresh-query :
/* Description ---------------------------------------------------------------*/
/*                                                                            */
/* Super Override                                                             */
/*                                                                            */
/* Notes ---------------------------------------------------------------------*/
/*                                                                            */
/*                                                                            */
/*                                                                            */
/* Parameters ----------------------------------------------------------------*/
/*                                                                            */
/* <none>                                                                     */
/*                                                                            */
/* Examples ------------------------------------------------------------------*/
/*                                                                            */
/*                                                                            */
/*                                                                            */
/*----------------------------------------------------------------------------*/

/* Variables -----------------------------------------------------------------*/
define variable cOLDSource_obj    as character          no-undo.
/*----------------------------------------------------------------------------*/

/* Buffers -------------------------------------------------------------------*/
define buffer bOLD_ttUV_Versandbeleg for temp-table ttUV_VersandBeleg.
/*----------------------------------------------------------------------------*/
/* Processing                                                                 */
/*----------------------------------------------------------------------------*/

if available ttUV_VersandBeleg then

  cOLDSource_obj = ttUV_VersandBeleg.V_BelegPos_Obj.

run FillTT.

run dispatch ('refresh-query':U).

if return-value <> 'ADM-ERROR':U then
do:

  find bOLD_ttUV_Versandbeleg
    where bOLD_ttUV_Versandbeleg.V_BelegPos_Obj = cOLDSource_obj
    no-lock no-error.

  if available bOLD_ttUV_Versandbeleg then
  do:

    run RepositionBrowse (rowid(bOLD_ttUV_Versandbeleg)).

    run notify('row-available':U).

  end.  /* if available bOLD_ttUV_Versandbeleg then */

end. /* if return-value <> 'ADM-ERROR':U */

end procedure. /* local-refresh-query */

/* _UIB-CODE-BLOCK-END */
&ANALYZE-RESUME

&ANALYZE-SUSPEND _UIB-CODE-BLOCK _PROCEDURE local-set-filter B-table-Win 
PROCEDURE local-set-filter :
/* Description ---------------------------------------------------------------*/
/*                                                                            */
/* super override                                                             */
/*                                                                            */
/* Notes ---------------------------------------------------------------------*/
/*                                                                            */
/*                                                                            */
/*                                                                            */
/* Parameters ----------------------------------------------------------------*/
/*                                                                            */
/* <none>                                                                     */
/*                                                                            */
/* Examples ------------------------------------------------------------------*/
/*                                                                            */
/*                                                                            */
/*                                                                            */
/*----------------------------------------------------------------------------*/

/* Variables -----------------------------------------------------------------*/
/*----------------------------------------------------------------------------*/

/* Buffers -------------------------------------------------------------------*/

/*----------------------------------------------------------------------------*/
/* Processing                                                                 */
/*----------------------------------------------------------------------------*/

  /* Code placed here will execute PRIOR to standard behavior ------------------*/

  run dispatch('set-filter':U).

  /* Code placed here will execute AFTER standard behavior ---------------------*/
  if return-value <> 'adm-error':U then 
  do:
    assign
      pa-filter-iMRPRelease_var       = adm.method.cls.DMCParameterStringSvc:iReadValue(pa-FilterValues, 'iMRPRelease':U      , 1)
      pa-filter-lPastOrderLines_var   = adm.method.cls.DMCParameterStringSvc:lReadValue(pa-FilterValues, 'lPastOrderLines':U  , 1)
      pa-filter-lTodayOrderLines_var  = adm.method.cls.DMCParameterStringSvc:lReadValue(pa-FilterValues, 'lTodayOrderLines':U , 1)
      pa-filter-lFutureOrderLines_var = adm.method.cls.DMCParameterStringSvc:lReadValue(pa-FilterValues, 'lFutureOrderLines':U, 1)
      pa-filter-iBezugsdatum_var      = adm.method.cls.DMCParameterStringSvc:iReadValue(pa-FilterValues, 'iBezugsdatum':U     , 1)
      pa-filter-iHorizont_var         = adm.method.cls.DMCParameterStringSvc:iReadValue(pa-FilterValues, 'iHorizont':U        , 1)
      .


    run FillTT.
  end.

end procedure. /* local-set-filter */

/* _UIB-CODE-BLOCK-END */
&ANALYZE-RESUME

&ANALYZE-SUSPEND _UIB-CODE-BLOCK _PROCEDURE local-update-record B-table-Win 
PROCEDURE local-update-record :
/* Description ---------------------------------------------------------------*/
/*                                                                            */
/* Super Override                                                             */
/*                                                                            */
/* Notes ---------------------------------------------------------------------*/
/*                                                                            */
/*                                                                            */
/*                                                                            */
/* Parameters ----------------------------------------------------------------*/
/*                                                                            */
/* <none>                                                                     */
/*                                                                            */
/* Examples ------------------------------------------------------------------*/
/*                                                                            */
/*                                                                            */
/*                                                                            */
/*----------------------------------------------------------------------------*/

/* Variables -----------------------------------------------------------------*/
/*----------------------------------------------------------------------------*/

/* Buffers -------------------------------------------------------------------*/

/*----------------------------------------------------------------------------*/
/* Processing                                                                 */
/*----------------------------------------------------------------------------*/

/* Code placed here will execute PRIOR to standard behavior ------------------*/

/* If the Button 'Save' was pressed in the toolbar and the DispatchQty was    */
/* not valid, then glTriggerError was set to yes in the leave trigger of the  */
/* field glTriggerError in order to return ADM-ERROR here.                    */
/* In the case of saving 'return no-apply' in the leave trigger does not      */
/* stop the program.                                                          */
if glTriggerError then
do:
  run pa_UISvcApplyEventToWidgetByHandle
        ('entry':U,
         ttUV_VersandBeleg.uCI_DispatchQty:handle in browse br_table).
  return 'ADM-ERROR':U.
end.

/* Dispatch standard ADM method.                             */

run dispatch ('update-record':U).

/* Code placed here will execute AFTER standard behavior ---------------------*/

end procedure. /* update-record */

/* _UIB-CODE-BLOCK-END */
&ANALYZE-RESUME

&ANALYZE-SUSPEND _UIB-CODE-BLOCK _PROCEDURE MarkRecord B-table-Win 
PROCEDURE MarkRecord :
/* Description ---------------------------------------------------------------*/
/*                                                                            */
/* Mark currently focussed record or all records, depending on provided       */
/* mark type.                                                                 */
/*                                                                            */
/* Notes ---------------------------------------------------------------------*/
/*                                                                            */
/*                                                                            */
/*                                                                            */
/* Parameters ----------------------------------------------------------------*/
/*                                                                            */
/* <none>                                                                     */
/*                                                                            */
/* Examples ------------------------------------------------------------------*/
/*                                                                            */
/*                                                                            */
/*                                                                            */
/*----------------------------------------------------------------------------*/
define input parameter pcMarkType as character no-undo.

/* Variables -----------------------------------------------------------------*/
/*----------------------------------------------------------------------------*/

/* Buffers -------------------------------------------------------------------*/
define buffer bttUV_VersandBeleg for temp-table ttUV_VersandBeleg.

/*----------------------------------------------------------------------------*/
/* Processing                                                                 */
/*----------------------------------------------------------------------------*/

  {call
    dsUVR_CIVersandBeleg
    modifyTrackingChanges
    yes}.

  if available ttUV_VersandBeleg then

    /* im Gegensatz zu refresh()-Methode flackert bei display-fields die        */
    /* Anzeige nicht, allerdings kann damit nur die Anzeige des aktuelle Satzes */
    /* aktualisiert werden                                                      */

    if pcMarkType = 'Single':U then
    do:

      ttUV_VersandBeleg.Markiert = not ttUV_VersandBeleg.Markiert.

      if ttUV_VersandBeleg.Markiert then 
        oSelectedObject:addSelectedObject(ttUV_VersandBeleg.Owning_Obj).
      else
        oSelectedObject:removeSelectedObject(ttUV_VersandBeleg.Owning_Obj).

      {adm/incl/d__duh00.if
         &Var1          = "ttUV_VersandBeleg.Markiert"
         &Unless-hidden = "no"
         &WithFrame     = "browse {&BROWSE-NAME}"}

    end.
    else
    do:

      if pcMarkType <> 'MarkAll':U then 
        oSelectedObject:clearList().

      for each bttUV_VersandBeleg
        on error undo, throw:

        bttUV_VersandBeleg.Markiert = (if pcMarkType = 'MarkAll':U then
                                         yes
                                       else
                                         no).
        if bttUV_VersandBeleg.Markiert then 
          oSelectedObject:addSelectedObject(bttUV_VersandBeleg.Owning_Obj).

        {adm/incl/d__duh00.if
           &Var1          = "ttUV_VersandBeleg.Markiert"
           &Unless-hidden = "no"
           &WithFrame     = "browse {&BROWSE-NAME}"}

      end.  /* for each bttUV_VersandBeleg */

      run pa_UISvcRefreshBrowse(browse {&BROWSE-NAME}:handle, no).

    end. /* else(if pcMarkType = 'Single':U) */

  if pa-fields-enabled = no then 

    run UpdateTotalValues.

  finally:

    {call
      dsUVR_CIVersandBeleg
      modifyTrackingChanges
      no}.

  end finally.

end procedure. /* MarkRecord */

/* _UIB-CODE-BLOCK-END */
&ANALYZE-RESUME

&ANALYZE-SUSPEND _UIB-CODE-BLOCK _PROCEDURE Picking B-table-Win 
PROCEDURE Picking :
/* Description ---------------------------------------------------------------*/
/*                                                                            */
/* Generate and print Staging Suggestion for all marked documents             */
/*                                                                            */
/* Notes ---------------------------------------------------------------------*/
/*                                                                            */
/*                                                                            */
/*                                                                            */
/* Parameters ----------------------------------------------------------------*/
/*                                                                            */
/* <none>                                                                     */
/*                                                                            */
/* Examples ------------------------------------------------------------------*/
/*                                                                            */
/*                                                                            */
/*                                                                            */
/*----------------------------------------------------------------------------*/

define input  parameter pcPrintMode      as  character   no-undo.

/* Variables -----------------------------------------------------------------*/
/*----------------------------------------------------------------------------*/
define variable cPickingParameters         as character no-undo.
define variable tMRPDate                   as date      no-undo.
define variable iCount                     as integer   no-undo.
define variable lIsNotMaterialLinePickable as logical no-undo.

/* Buffers -------------------------------------------------------------------*/
define buffer bttUV_VersandBeleg for temp-table ttUV_VersandBeleg.

/*----------------------------------------------------------------------------*/
/* Processing                                                                 */
/*----------------------------------------------------------------------------*/
for each bttUV_VersandBeleg
  where lookup(bttUV_VersandBeleg.Belegart, 'U,VUA,VSA':U) > 0
  on error undo, throw:

    if  bttUV_VersandBeleg.Markiert = no then
      next.

    &IF LOOKUP("VS","{&PA-MODULE}") > 0 &THEN

    if    adm.method.cls.DMCSessionSvc:cOwningTable(bttUV_VersandBeleg.Owning_Obj) = 'VS_AuftragMKT':U
      and not vert.serv.cls.VSCFillShippingMonitorSvc:prpoInstance:lIsPickableMatLineFromShipMonitor(bttUV_VersandBeleg.Owning_Obj) then
    do:

      assign
        bttUV_VersandBeleg.Markiert = no
        lIsNotMaterialLinePickable  = yes
        .

      oSelectedObject:removeSelectedObject(bttUV_VersandBeleg.Owning_Obj).
      run pa_UISvcRefreshBrowse(browse {&BROWSE-NAME}:handle, no).  

      next.

    end. /* if    adm.method.cls.DMCSessionSvc:cOwningTable(pcOriginObj) = 'VS_AuftragMKT':U */

    &ENDIF

    assign
      cPickingParameters   = adm.method.cls.DMCParameterStringSvc:cInsertValue
                               (cPickingParameters,
                                'uObjToPick':U,
                                bttUV_VersandBeleg.Owning_Obj)
      &IF LOOKUP("VS","{&PA-MODULE}") > 0 &THEN
        cPickingParameters = adm.method.cls.DMCParameterStringSvc:cInsertValue
                               (cPickingParameters,
                                'dTargetQty':U,
                                bttUV_VersandBeleg.uCI_DispatchQty)
      &ENDIF
      .

    if tMRPDate = ?
      or tMRPDate < bttUV_VersandBeleg.Versandtermin then

      tMRPDate = bttUV_VersandBeleg.Versandtermin.

    iCount = iCount + 1.

    if iCount > {&uMaxKommPos} then
      adm.method.cls.DMCMessageSvc:prpoInstance:showError
        ('uvvmo00002':U,
         string({&uMaxKommPos})).

    next.

end. /* for each bttUV_VersandBeleg */   

if lIsNotMaterialLinePickable then
  adm.method.cls.DMCMessageSvc:prpoInstance:lShowMessage
    ('uvvmo00006':U).  

assign
  cPickingParameters
    = adm.method.cls.DMCParameterStringSvc:cWriteValue
        (cPickingParameters,
         'uCallFromVersandmonitor':U,
         yes)
  cPickingParameters
    = adm.method.cls.DMCParameterStringSvc:cWriteValue
        (cPickingParameters,
         'tMRPDate':U,
         tMRPDate)
  cPickingParameters
    = adm.method.cls.DMCParameterStringSvc:cWriteValue
        (cPickingParameters,
         'KommZone':U,
         '':U)
  cPickingParameters
    = adm.method.cls.DMCParameterStringSvc:cWriteValue
        (cPickingParameters,
         'DocTypesToPick':U,
         'U,VUA,VSA':U)
  cPickingParameters
    = adm.method.cls.DMCParameterStringSvc:cWriteValue
        (cPickingParameters,
         'Kunde':U,
         adm.method.cls.DMCSessionSvc:iGetObjectProperty(dataset dsUVR_CIVersandBeleg:handle, 'Konto_min':U),
         adm.method.cls.DMCSessionSvc:iGetObjectProperty(dataset dsUVR_CIVersandBeleg:handle, 'Konto_max':U))
  cPickingParameters
    = adm.method.cls.DMCParameterStringSvc:cWriteValue
        (cPickingParameters,
         'Artikel':U,
         adm.method.cls.DMCSessionSvc:cGetObjectProperty(dataset dsUVR_CIVersandBeleg:handle, 'Artikel_min':U),
         adm.method.cls.DMCSessionSvc:cGetObjectProperty(dataset dsUVR_CIVersandBeleg:handle, 'Artikel_max':U))
  cPickingParameters
    = adm.method.cls.DMCParameterStringSvc:cWriteValue
        (cPickingParameters,
         'AuftragsArt':U,
         adm.method.cls.DMCSessionSvc:cGetObjectProperty(dataset dsUVR_CIVersandBeleg:handle, 'AuftragsArt_min':U),
         adm.method.cls.DMCSessionSvc:cGetObjectProperty(dataset dsUVR_CIVersandBeleg:handle, 'AuftragsArt_max':U))
  cPickingParameters
    = adm.method.cls.DMCParameterStringSvc:cWriteValue
        (cPickingParameters,
         'Versandart':U,
         adm.method.cls.DMCSessionSvc:iGetObjectProperty(dataset dsUVR_CIVersandBeleg:handle, 'VersandArt_min':U),
         adm.method.cls.DMCSessionSvc:iGetObjectProperty(dataset dsUVR_CIVersandBeleg:handle, 'VersandArt_max':U))

  /* --> CA2016-07-002 MOu Versand - Nullmengen */
  /* uPickingArt :
       - 1 : werden nur Best�nde Kommissioniert
       - 2 : werden nur Nullmengen erzeugt
       - 3 : Beide                         */
  cPickingParameters
    = adm.method.cls.DMCParameterStringSvc:cInsertValue
        (cPickingParameters,
         'uPickingArt':U,
         3)
  /* <-- CA2016-07-002 MOu Versand - Nullmengen */
  /* --> CA2016-07-002a MOu Versand - Druckausgabe */
  /*   uPrintArt :                                          */
  /*           - 1 : Alle nicht gedruckten drucken          */
  /*           - 2 : Nur neu erzeugte drucken               */
  /*           - 3 : Nur komplett kommissionierte drucken   */
  /*           - 4 : kein Druck                             */
  cPickingParameters
    = adm.method.cls.DMCParameterStringSvc:cInsertValue
        (cPickingParameters,
         'uPrintArt':U,
         pcPrintMode)
  /* <-- CA2016-07-002a MOu Versand - Druckausgabe */
  .

run basis/job/proc/bjvjob00.w ('':U,
                               cPickingParameters,
                               if pcPrintMode = '4':U then
                                 'mmvpic02.p':U
                               else
                                 'mmdpic02.p':U).

run read-current-offset(pa-sortby-case).
gcOffset-value = return-value.

run FillTT.

run notify('row-available':U).

end procedure. /* Picking */

/* _UIB-CODE-BLOCK-END */
&ANALYZE-RESUME

&IF LOOKUP("VS","{&PA-MODULE}") > 0 &THEN
&ANALYZE-SUSPEND _UIB-CODE-BLOCK _PROCEDURE processingNextRecord Method-Library
procedure processingNextRecord :
/* Description ---------------------------------------------------------------*/
/*                                                                            */
/* This procedure is responsible for prepairing the data for the next         */
/* Repair Order. It reads the entry from the temp-table                       */
/* ttRepairOrderCallIteration                                                 */
/* using the current index (giCurrentIndex) and finds                         */
/* the associated VS_Auftrag.                                                 */
/* The goal is to collect the relevant data for the next call of vsphan02.w   */
/* based on the current entry in ttAuftrag                                    */
/*                                                                            */
/* Parameters ----------------------------------------------------------------*/
/*                                                                            */
/* <none>                                                                     */
/*                                                                            */
/*----------------------------------------------------------------------------*/
define variable cObjWithQty as character no-undo.  
define variable cKey        as character no-undo.
define variable cPKS        as character no-undo.
define variable cObj        as character no-undo.
define variable iCounter    as integer   no-undo.

define buffer bttUV_VersandBeleg   for temp-table ttUV_VersandBeleg.

define buffer bVS_Auftrag          for VS_Auftrag.

find first ttRepairOrderCallIteration
  where ttRepairOrderCallIteration.seqNumber = giCurrentIndex
  no-lock no-error.

if not available ttRepairOrderCallIteration then

  return.

find bttUV_Versandbeleg
  where bttUV_Versandbeleg.Owning_Obj = ttRepairOrderCallIteration.VS_AuftragPos_Obj
  no-lock no-error.

if not available bttUV_Versandbeleg then

 return.

find bVS_Auftrag
  where bVS_Auftrag.Firma       = {firma/vbelegko.fir pACConnectionSvc:prpcCompany}
    and bVS_Auftrag.BelegArt    = 'VSA':U   
    and bVS_Auftrag.ReferenzNr  = bttUV_VersandBeleg.ReferenzNr
  no-lock.

cPKS = '':U.

for each ttUPositions-Service
  where ttUPositions-Service.DocumentNumber = bttUV_Versandbeleg.BelegNummer
  no-lock
  by ttUPositions-Service.LineNumber
  on error undo, throw:

  assign
    iCounter = iCounter + 1 
    cObjWithQty = ttUPositions-Service.Owning_Obj + '|':U + string(ttUPositions-Service.Quantity)
    cKey        = 'OrderObjQty':U + string(iCounter)
    cPKS        = adm.method.cls.DMCParameterStringSvc:cWriteValue(cPKS,cKey,cObjWithQty)
    .

end.

if bVS_Auftrag.VS_Auftrag_Obj <> adm.method.cls.DMCParameterStringSvc:cReadValue(cPKS, 'VS_Auftrag_Obj':U, 1) then

  cPKS = adm.method.cls.DMCParameterStringSvc:cWriteValue
           (cPKS,
            'VS_Auftrag_Obj':U,
            bVS_Auftrag.VS_Auftrag_Obj,
            'OrderObjQtyCount':U,
            string(iCounter)).

{adm/incl/d__run01.if
 &Programm      = "vert/serv/proc/vsphan02.w"
 &Link1         = "'record':U"
 &Source1       = "this-procedure"
 &PKS           = "cPKS"
 &Handle        = "ghCalledProc"
}

return.

end procedure. /* processingNextRecord */

/* _UIB-CODE-BLOCK-END */
&ANALYZE-RESUME
&ENDIF


&ANALYZE-SUSPEND _UIB-CODE-BLOCK _PROCEDURE read-current-offset B-table-Win  adm/support/proc/ds_fin02.p
PROCEDURE read-current-offset :
/* Description ---------------------------------------------------------------*/
/*                                                                            */
/* Get back current key-value                                                 */
/*                                                                            */
/* Parameters ----------------------------------------------------------------*/
/*                                                                            */
/* pcField: name of requested field                                           */
/*                                                                            */
/*----------------------------------------------------------------------------*/

define input parameter pcField as char no-undo.

/*----------------------------------------------------------------------------*/
/* Processing                                                                 */
/*----------------------------------------------------------------------------*/

if available ttUV_VersandBeleg then

  case pcField:

    when 'Konto':U then
      return string(ttUV_VersandBeleg.Konto).

    when 'Konto_Suchbegriff':U then
      return ttUV_VersandBeleg.Konto_Suchbegriff.

    when 'Konto_Selektion':U then
      return ttUV_VersandBeleg.Konto_Selektion.

    when 'Konto_Branche':U then
      return ttUV_VersandBeleg.Konto_Branche.

    when 'Konto_Region':U then
      return ttUV_VersandBeleg.Konto_Region.

    when 'Belegart':U then
      return ttUV_VersandBeleg.Belegart.

    when 'BelegartBez':U then
      return ttUV_VersandBeleg.BelegartBez.

    when 'BelegNummer':U then
      return string(ttUV_VersandBeleg.BelegNummer).

    when 'BelegInfo':U then
      return ttUV_VersandBeleg.BelegInfo.

    when 'Auftrag':U then
      return ttUV_VersandBeleg.Auftrag.

    when 'Artikelgruppe':U then
      return ttUV_VersandBeleg.Artikelgruppe.

    when 'Artikel':U then
      return ttUV_VersandBeleg.Artikel.

    when 'Sparte':U then
      return ttUV_VersandBeleg.Sparte.

    when 'Artikel_Selektion':U then
      return ttUV_VersandBeleg.Artikel_Selektion.

    when 'Artikel_Suchbegriff':U then
      return ttUV_VersandBeleg.Artikel_Suchbegriff.

    when 'ArtikelArt':U then
      return string(ttUV_VersandBeleg.ArtikelArt).

    when 'ArtikelNr':U then
      return ttUV_VersandBeleg.ArtikelNr.

    when 'Wunschtermin':U then
      return string(ttUV_VersandBeleg.Wunschtermin).

    when 'Liefertermin':U then
      return string(ttUV_VersandBeleg.Liefertermin).

    when 'uCI_Warenausgangstermin':U then
      return string(ttUV_VersandBeleg.uCI_Warenausgangstermin).

    when 'Versandtermin':U then
      return string(ttUV_VersandBeleg.Versandtermin).

    when 'AuftragsArt':U then
      return ttUV_VersandBeleg.AuftragsArt.

    when 'Versandart':U then
      return string(ttUV_VersandBeleg.Versandart).

    when 'LieferBedingung':U then
      return string(ttUV_VersandBeleg.LieferBedingung).

    when 'LieferRestrikt':U then
      return string(ttUV_VersandBeleg.LieferRestrikt).

    when 'Sachbearbeiter':U then
      return ttUV_VersandBeleg.Sachbearbeiter.

    when 'Lieferant':U then
      return string(ttUV_VersandBeleg.Lieferant).

    when 'Lieferant_Suchbegriff':U then
      return ttUV_VersandBeleg.Lieferant_Suchbegriff.

    when 'Lieferant_Selektion':U then
      return ttUV_VersandBeleg.Lieferant_Selektion.

    when 'LieferAdresse':U then
      return string(ttUV_VersandBeleg.LieferAdresse).

    when 'AdressKennung':U then
      return ttUV_VersandBeleg.AdressKennung.

    when 'LiefAdr_Name1':U then
      return ttUV_VersandBeleg.LiefAdr_Name1.

    when 'LiefAdr_PLZ':U then
      return ttUV_VersandBeleg.LiefAdr_PLZ.

    when 'LiefAdr_Ort':U then
      return ttUV_VersandBeleg.LiefAdr_Ort.

    when 'Abladestelle':U then
      return ttUV_VersandBeleg.Abladestelle.

    when 'KO_LagerOrt':U then
      return string(ttUV_VersandBeleg.KO_LagerOrt).

    when 'Markiert':U then
      return string(ttUV_VersandBeleg.Markiert = true,'yes/no':U).
    
    /* --> MO#HIDR-AH4-1123 thongdi_p 20.07.2026 Erweiterung Versandmonitor im Feld Best. Termin */
    when 'xEbLiefertermin':U then
      return string(ttUV_VersandBeleg.xEbLiefertermin).
    /* <-- MO#HIDR-AH4-1123 thongdi_p 20.07.2026 Erweiterung Versandmonitor im Feld Best. Termin */
    
    
    {&{&PA-XBASISNAME}_C_CurrentOffset}
    {&{&PA-XBASISNAME}_U_CurrentOffset}
    {&{&PA-XBASISNAME}_Q_CurrentOffset}
    {&{&PA-XBASISNAME}_CurrentOffset}
    {&{&PA-XBASISNAME}_Y_CurrentOffset}

    otherwise
      {adm/template/incl/dt_vbs12.if &ippSortCaseName = "pcField"}

  end case.

return ?.
end procedure. /* read-current-offset */

/* _UIB-CODE-BLOCK-END */
&ANALYZE-RESUME

&ANALYZE-SUSPEND _UIB-CODE-BLOCK _PROCEDURE RefreshTitle B-table-Win 
PROCEDURE RefreshTitle :
/* Description ---------------------------------------------------------------*/
/*                                                                            */
/* Refreshes the browser title with the number of rows                        */
/*                                                                            */
/* Notes ---------------------------------------------------------------------*/
/*                                                                            */
/*                                                                            */
/*                                                                            */
/* Parameters ----------------------------------------------------------------*/
/*                                                                            */
/* <none>                                                                     */
/*                                                                            */
/* Examples ------------------------------------------------------------------*/
/*                                                                            */
/*                                                                            */
/*                                                                            */
/*----------------------------------------------------------------------------*/

/* Variables -----------------------------------------------------------------*/
/*----------------------------------------------------------------------------*/

/* Buffers -------------------------------------------------------------------*/

/*----------------------------------------------------------------------------*/
/* Processing                                                                 */
/*----------------------------------------------------------------------------*/

gcWindowTitle =  string(giHits)
               + ' ':U
               + 'Treffer':T7.

run request in adm-broker-hdl (this-procedure,
                               'container-source':U,
                               'set-window-title':U).

end procedure. /* RefreshTitle */

/* _UIB-CODE-BLOCK-END */
&ANALYZE-RESUME

&ANALYZE-SUSPEND _UIB-CODE-BLOCK _PROCEDURE send-key B-table-Win  adm/support/proc/_key-snd.p
PROCEDURE send-key :
/* Description ---------------------------------------------------------------*/
/*                                                                            */
/* Sends a requested KEY value back to the calling SmartObject                */
/*                                                                            */
/* Parameters ----------------------------------------------------------------*/
/*                                                                            */
/* see adm/template/sndkytop.i                                                */
/*                                                                            */
/*----------------------------------------------------------------------------*/

/*----------------------------------------------------------------------------*/
/* Processing                                                                 */
/*----------------------------------------------------------------------------*/

/* Define variables needed by this internal procedure.                        */

{adm/template/incl/sndkytop.i}

/* Return the key value associated with each key case.                        */

{adm/template/incl/sndkycas.i "Konto" "ttUV_VersandBeleg" "Konto" " "}
{adm/template/incl/sndkycas.i "Artikel" "ttUV_VersandBeleg" "Artikel" " "}
{adm/template/incl/sndkycas.i "ArtVar" "ttUV_VersandBeleg" "ArtVar" " "}
{adm/template/incl/sndkycas.i "ArtikelGruppe" "ttUV_VersandBeleg" "ArtikelGruppe" " "}
{adm/template/incl/sndkycas.i "Sparte" "ttUV_VersandBeleg" "Sparte" " "}
{adm/template/incl/sndkycas.i "ArtikelArt" "ttUV_VersandBeleg" "ArtikelArt" " "}
{adm/template/incl/sndkycas.i "Wunschtermin" "ttUV_VersandBeleg" "Wunschtermin" " "}
{adm/template/incl/sndkycas.i "Liefertermin" "ttUV_VersandBeleg" "Liefertermin" " "}
{adm/template/incl/sndkycas.i "uCI_Warenausgangstermin" "ttUV_VersandBeleg" "uCI_Warenausgangstermin" " "}
{adm/template/incl/sndkycas.i "Versandtermin" "ttUV_VersandBeleg" "Versandtermin" " "}
{adm/template/incl/sndkycas.i "BelegNummer" "ttUV_VersandBeleg" "BelegNummer" " "}
{adm/template/incl/sndkycas.i "Sachbearbeiter" "ttUV_VersandBeleg" "Sachbearbeiter" " "}
{adm/template/incl/sndkycas.i "AuftragsArt" "ttUV_VersandBeleg" "AuftragsArt" " "}
{adm/template/incl/sndkycas.i "LieferAdresse" "ttUV_VersandBeleg" "LieferAdresse" " "}
{adm/template/incl/sndkycas.i "AdressKennung" "ttUV_VersandBeleg" "AdressKennung" " "}
{adm/template/incl/sndkycas.i "Abladestelle" "ttUV_VersandBeleg" "Abladestelle" " "}
{adm/template/incl/sndkycas.i "uCI_LagerortKunde" "ttUV_VersandBeleg" "uCI_LagerortKunde" " "}
{adm/template/incl/sndkycas.i "VersandArt" "ttUV_VersandBeleg" "VersandArt" " "}
{adm/template/incl/sndkycas.i "LieferBedingung" "ttUV_VersandBeleg" "LieferBedingung" " "}
{adm/template/incl/sndkycas.i "Lieferant" "ttUV_VersandBeleg" "Lieferant" " "}
{adm/template/incl/sndkycas.i "Owning_Obj" "ttUV_VersandBeleg" "Owning_Obj" " "}
{adm/template/incl/sndkycas.i "Kunde" "ttUV_VersandBeleg" "Konto" " "}
{adm/template/incl/sndkycas.i "PosObj" "ttUV_VersandBeleg" "Owning_Obj" " "}
{adm/template/incl/sndkycas.i "ReferenzNr" "ttUV_VersandBeleg" "ReferenzNr" " "}
{adm/template/incl/sndkycas.i "V_BelegPos_Obj" "ttUV_VersandBeleg" "V_BelegPos_Obj" " "}
{adm/template/incl/sndkycas.i "PositionsNr" "ttUV_VersandBeleg" "PositionsNr" " "}
{adm/template/incl/sndkycas.i "BelegArt" "ttUV_VersandBeleg" "BelegArt" " "}
{adm/template/incl/sndkycas.i "Lagergruppe" "ttUV_VersandBeleg" "Lagergruppe" " "}

/* Close the CASE statement and end the procedure.                            */

{adm/template/incl/sndkyend.i}

end procedure. /* send-key */

/* _UIB-CODE-BLOCK-END */
&ANALYZE-RESUME

&ANALYZE-SUSPEND _UIB-CODE-BLOCK _PROCEDURE send-records B-table-Win  adm/support/proc/ds_rec01.p
PROCEDURE send-records :
/* Description ---------------------------------------------------------------*/
/*                                                                            */
/* Send record ROWID's for all tables used by this file.                      */
/*                                                                            */
/* Parameters ----------------------------------------------------------------*/
/*                                                                            */
/* see template/incl/snd-head.i                                               */
/*                                                                            */
/*----------------------------------------------------------------------------*/

/*----------------------------------------------------------------------------*/
/* Processing                                                                 */
/*----------------------------------------------------------------------------*/

/* Define variables needed by this internal procedure.                        */

{adm/template/incl/snd-head.i}

/* For each requested table, put it's ROWID in the output list.               */

{adm/template/incl/snd-list.i "ttUV_VersandBeleg"}
{adm/template/incl/snd-list.i "V_BelegKopf"}
{adm/template/incl/snd-list.i "VS_Auftrag"}

/* Deal with any unexpected table requests before closing.                    */

{adm/template/incl/snd-end.i}

end procedure. /* send-records */

/* _UIB-CODE-BLOCK-END */
&ANALYZE-RESUME

&ANALYZE-SUSPEND _UIB-CODE-BLOCK _PROCEDURE SendttUPositions B-table-Win 
PROCEDURE SendttUPositions :
/* Description ---------------------------------------------------------------*/
/*                                                                            */
/* Return ttUPositions                                                        */
/*                                                                            */
/* Notes ---------------------------------------------------------------------*/
/* Parameters ----------------------------------------------------------------*/
/*                                                                            */
/* output table ttUPositions                                                  */
/*                                                                            */
/* Examples ------------------------------------------------------------------*/
/*----------------------------------------------------------------------------*/

define output parameter table for ttUPositions.

/* Variables -----------------------------------------------------------------*/
/*----------------------------------------------------------------------------*/

/* Buffers -------------------------------------------------------------------*/

/*----------------------------------------------------------------------------*/
/* Processing                                                                 */
/*----------------------------------------------------------------------------*/

end procedure. /* SendttUPositions */

/* _UIB-CODE-BLOCK-END */
&ANALYZE-RESUME

&IF LOOKUP("VS","{&PA-MODULE}") > 0 &THEN
&ANALYZE-SUSPEND _UIB-CODE-BLOCK _PROCEDURE SendttUPositions B-table-Win 
PROCEDURE SendttUPositionsForService :
/* Description ---------------------------------------------------------------*/
/*                                                                            */
/* Return ttUPositions-Service                                                */
/*                                                                            */
/* Parameters ----------------------------------------------------------------*/
/*                                                                            */
/* output table ttUPositions-Service                                          */
/*----------------------------------------------------------------------------*/

define output parameter table for ttUPositions-Service.

end procedure. /* SendttUPositionsForService */

/* _UIB-CODE-BLOCK-END */
&ANALYZE-RESUME
&ENDIF

&ANALYZE-SUSPEND _UIB-CODE-BLOCK _PROCEDURE ShippingDoc B-table-Win 
PROCEDURE ShippingDoc :
/* Description ---------------------------------------------------------------*/
/*                                                                            */
/* Generates shipping documents for the marked positions                      */
/*                                                                            */
/* Notes ---------------------------------------------------------------------*/
/*                                                                            */
/*                                                                            */
/*                                                                            */
/* Parameters ----------------------------------------------------------------*/
/*                                                                            */
/* <none>                                                                     */
/*                                                                            */
/* Examples ------------------------------------------------------------------*/
/*                                                                            */
/*                                                                            */
/*                                                                            */
/*----------------------------------------------------------------------------*/

/* Variables -----------------------------------------------------------------*/
/*----------------------------------------------------------------------------*/

define variable cSatzID_neu         as character no-undo.
&IF LOOKUP("VS","{&PA-MODULE}") > 0 &THEN
  define variable seqNumber         as integer   no-undo.
&ENDIF
&IF lookup("M_ATLAS":U,"{&PA-OPTIONEN}":U) > 0 &THEN
  define variable iCustDeclState    as integer   no-undo.
&ENDIF
/* Buffers -------------------------------------------------------------------*/

define buffer bttUV_VersandBeleg   for temp-table ttUV_VersandBeleg.
define buffer bttUV_VersandBeleg-2 for temp-table ttUV_VersandBeleg.
define buffer bV_BelegKopf         for            V_BelegKopf.
define buffer bV_BelegPos          for            V_BelegPos.
&IF LOOKUP("VS","{&PA-MODULE}") > 0 &THEN
  define buffer bVS_Auftrag        for VS_Auftrag.
  define buffer bVS_AuftragPos     for VS_AuftragPos.
  define buffer bVS_AuftragMKT     for VS_AuftragMKT.
&ENDIF
&IF lookup("M_ATLAS":U,"{&PA-OPTIONEN}":U) > 0 &THEN
  define buffer bV_BelegKopf-new for V_BelegKopf.
&ENDIF

/*----------------------------------------------------------------------------*/
/* Processing                                                                 */
/*----------------------------------------------------------------------------*/

for each bttUV_VersandBeleg
  where bttUV_VersandBeleg.Markiert     = yes
    and (   bttUV_VersandBeleg.Belegart = 'U':U
         or bttUV_VersandBeleg.Belegart = 'VSA':U)
    and bttUV_VersandBeleg.KO_LagerOrt = ?
  break by bttUV_VersandBeleg.ReferenzNr
        by bttUV_VersandBeleg.PositionsNr
  on error undo, next:

  glMarked = yes.

  if first-of(bttUV_VersandBeleg.ReferenzNr) then
    empty temp-table ttUPositions.

  if first-of(bttUV_VersandBeleg.PositionsNr)
    and not bttUV_VersandBeleg.Belegart = 'VSA':U then
  do:
    create ttUPositions.
    ttUPositions.PositionsNr = bttUV_VersandBeleg.PositionsNr.
    validate ttUPositions.
  end.

  &IF LOOKUP("VS","{&PA-MODULE}") > 0 &THEN
  else if bttUV_VersandBeleg.Belegart = 'VSA':U then
  do:

    find bVS_Auftrag
      where bVS_Auftrag.Firma       = {firma/vbelegko.fir pACConnectionSvc:prpcCompany}
        and bVS_Auftrag.BelegArt    = 'VSA':U
        and bVS_Auftrag.ReferenzNr  = bttUV_VersandBeleg.ReferenzNr
      no-lock.

    if vert.serv.cls.VSCRepairOrderSvc:prpoInstance:lIsRepairOrderType(bVS_Auftrag.Auftragstyp) then
    do:

      find first bVS_AuftragPos
        where bVS_AuftragPos.VS_AuftragPos_Obj = bttUV_VersandBeleg.Owning_Obj
        no-lock.

      create ttUPositions-Service.

      assign
        ttUPositions-Service.DocumentNumber = bVS_AuftragPos.BelegNummer
        ttUPositions-Service.Owning_Obj     = bVS_AuftragPos.VS_AuftragPos_Obj
        ttUPositions-Service.LineNumber     = bVS_AuftragPos.PositionsNr
        ttUPositions-Service.Quantity       = ttUPositions-Service.Quantity + bttUV_VersandBeleg.uCI_DispatchQty
        .

      validate ttUPositions-Service.

    end. /* if vert.serv.cls.VSCRepairOrderSvc:prpoInstance:lIsRepairOrderType(bVS_Auftrag.Auftragstyp) then */
    else
    do:

      find bVS_Auftrag
        where bVS_Auftrag.Firma       = {firma/vbelegko.fir pACConnectionSvc:prpcCompany}
          and bVS_Auftrag.BelegArt    = 'VSA':U
          and bVS_Auftrag.ReferenzNr  = bttUV_VersandBeleg.ReferenzNr
        no-lock.

      find bVS_AuftragMKT
        where bVS_AuftragMKT.VS_AuftragMKT_Obj = bttUV_VersandBeleg.Owning_Obj
        no-lock.

      create ttUPositions-Service.         

      assign
        ttUPositions-Service.LineNumber = bttUV_VersandBeleg.PositionsNr
        ttUPositions-Service.Owning_Obj = bVS_AuftragMKT.VS_AuftragMKT_Obj
        ttUPositions-Service.Quantity   = ttUPositions-Service.Quantity + bttUV_VersandBeleg.uCI_DispatchQty
        .

      validate ttUPositions-Service.

    end.  

  end. /* else if bttUV_VersandBeleg.Belegart = 'VSA' then */
  else
  &ENDIF

  ttUPositions.Menge = ttUPositions.Menge + bttUV_VersandBeleg.uCI_DispatchQty.

  if last-of(bttUV_VersandBeleg.ReferenzNr) then
  do:

    find bV_BelegKopf
      where bV_BelegKopf.Firma      = {firma/vbelegko.fir pACConnectionSvc:prpcCompany}
        and bV_BelegKopf.BelegArt   = bttUV_VersandBeleg.Belegart
        and bV_BelegKopf.ReferenzNr = bttUV_VersandBeleg.ReferenzNr
      no-lock no-error.

    if available bV_BelegKopf then
    do transaction
      on error undo, next:

      /* if the Delivery Restriction = 'No Partial Deliveries' then alle Position */
      /*  of the same Order have to be shown in the Document Adoption Browser     */
      /* but with empty Adoption Code (siehe v_bbel20.w )                         */
      for each bV_BelegPos
        where bV_BelegPos.Firma                      = {firma/vbelegko.fir pACConnectionSvc:prpcCompany}
          and bV_BelegPos.BelegArt                   = 'U':U
          and bV_BelegPos.ReferenzNr                 = bttUV_VersandBeleg.ReferenzNr
          and bV_BelegPos.offen                      = yes
          and bV_BelegPos.Satzart                    = 'A':U
          and bV_BelegPos.WertPosition               = no
          and not can-find( ttUPositions
                      where ttUPositions.PositionsNr = bV_BelegPos.PositionsNr) 
        no-lock
        on error undo, throw:

        create ttUPositions.
        assign
          ttUPositions.PositionsNr = bV_BelegPos.PositionsNr
          ttUPositions.Menge       = -1
          .
        validate ttUPositions.
      end.

      cSatzID_neu = branche.vert.cls.UVC_CISalesDocumentSvc:prpoInstance:cPushAdoption
        (bV_BelegKopf.V_BelegKopf_Obj,  /* ipcSourceObj */
         'L':U,                         /* ipcTargetDocType */
         {&uCW_RemoteAdoptionByLine},   /* ipiTypeOfAdopt */
         ?,                             /* ipiZielLager */
         ?,                             /* ipiTransport */
         no,                            /* iplSilent */
         string(this-procedure)).

      /* No proper error handling, we need to check if a document has been */
      /* created. */
      if cSatzID_neu > '':U
        and can-find(V_BelegKopf
           where rowid(V_BelegKopf) = to-rowid(cSatzID_neu)) then
      do for bV_BelegPos:
        for each bttUV_VersandBeleg-2
          where bttUV_VersandBeleg-2.Markiert    = yes
            and bttUV_VersandBeleg-2.Belegart    = 'U':U
            and bttUV_VersandBeleg-2.KO_LagerOrt = ?
            and bttUV_VersandBeleg-2.ReferenzNr  = bttUV_VersandBeleg.ReferenzNr
          on error undo, next:

          find bV_BelegPos
            where bV_BelegPos.V_BelegPos_Obj = bttUV_VersandBeleg-2.V_BelegPos_Obj
            exclusive-lock no-wait no-error.

          if available bV_BelegPos then
            assign
              bV_BelegPos.uCI_DispatchQty       = 0
              bV_BelegPos.uCI_DispatchQtyRemark = '':U
              .

        end. /* for each bttUV_VersandBeleg-2 */
      end. /* A document has been created. */

      &IF lookup("M_ATLAS":U,"{&PA-OPTIONEN}":U) > 0 &THEN
        if cSatzID_neu > '':U then
        do:

          find bV_BelegKopf-new
            where rowid(bV_BelegKopf-new) = to-rowid(cSatzID_neu)
            no-lock no-error.

          if available bV_BelegKopf-new then
          do:

            iCustDeclState = VFCAtlasSvc:prpoInstance:iCurrentCustomsDeclarationState
                               (bV_BelegKopf.Firma,
                                'V_BelegKopf':U,
                                {vert/incl/v_belko.sl &Tabelle = "bV_BelegKopf"}).

            if iCustDeclState > 0 then

              VFCAtlasSvc:prpoInstance:lCustDeclWriteDeclaration
                (bV_BelegKopf-new.Firma,
                 'V_BelegKopf':U,
                 {vert/incl/v_belko.sl &Tabelle = "bV_BelegKopf-new"},
                 iCustDeclState).

          end. /* if available bV_BelegKopf-new  */

        end. /* if cSatzID_neu > '':U */
      &ENDIF

    end. /* if available bV_BelegKopf */
    &IF LOOKUP("VS","{&PA-MODULE}") > 0 &THEN
      if bttUV_VersandBeleg.Belegart = 'VSA':U then
      do:

        if vert.serv.cls.VSCRepairOrderSvc:prpoInstance:lIsRepairOrderType(bVS_Auftrag.Auftragstyp) then
        do:

          /* Assign a sequential number to each entry in                      */
          /* ttRepairOrderCallIteration.                                      */
          /* This ensures each VS_Auftrag is processed in the correct order   */
          /* and only once, by referencing this lfdNr durring iteration       */

          seqNumber = seqNumber + 1.

          if not can-find (ttRepairOrderCallIteration
                             where ttRepairOrderCallIteration.VS_AuftragPos_Obj = bttUV_VersandBeleg.Owning_Obj) then
          do:

            create ttRepairOrderCallIteration.  

            assign
              ttRepairOrderCallIteration.seqNumber         = seqNumber
              ttRepairOrderCallIteration.VS_AuftragPos_Obj = bVS_AuftragPos.VS_AuftragPos_Obj
              .

            if can-find (first ttRepairOrderCallIteration) then
            do:

              giCurrentIndex = 1.

              run processingNextRecord.

            end. /* if can-find (first ttRepairOrderCallIteration) then */

          end. /* if not can-find (ttRepairOrderCallIteration */

        end. /* if vert.serv.cls.VSCRepairOrderSvc:prpoInstance:lIsRepairOrderType(bVS_Auftrag.Auftragstyp) then */
        else
        do:

          run vert/serv/proc/vspauf30.w (string(rowid(bVS_Auftrag)),
                                         'L':U,
                                         handle (string(this-procedure)),
                                         input-output cSatzID_neu).

          empty temp-table ttUPositions-Service.        

        end. /* else */

      end. /* f bttUV_VersandBeleg.Belegart = 'VSA':U then */
    &ENDIF
  end. /* if last-of(bttUV_VersandBeleg.ReferenzNr) */

end. /* for each bttUV_VersandBeleg */

if not glMarked then
  adm.method.cls.DMCMessageSvc:prpoInstance:showError
    ('uvvmo00005':U).

finally:

  if glMarked
  &IF LOOKUP("VS","{&PA-MODULE}") > 0 &THEN
    and valid-handle (ghCalledProc)
    and not ghCalledProc:name matches '*vsphan02.w':U
  &ENDIF then
  do:
    run read-current-offset(pa-sortby-case).
    gcOffset-value = return-value.

    run FillTT.
  end.
end.

end procedure. /* ShippingDoc */

/* _UIB-CODE-BLOCK-END */
&ANALYZE-RESUME


&ANALYZE-SUSPEND _UIB-CODE-BLOCK _PROCEDURE ShowDocumentHeader B-table-Win 
PROCEDURE ShowDocumentHeader :
/* Description ---------------------------------------------------------------*/
/*                                                                            */
/* show document header                                                       */
/*                                                                            */
/* Notes ---------------------------------------------------------------------*/
/*                                                                            */
/*                                                                            */
/*                                                                            */
/* Parameters ----------------------------------------------------------------*/
/*                                                                            */
/* <none>                                                                     */
/*                                                                            */
/* Examples ------------------------------------------------------------------*/
/*                                                                            */
/*                                                                            */
/*                                                                            */
/*----------------------------------------------------------------------------*/
define input  parameter pcMode      as  character   no-undo.

/* Variables -----------------------------------------------------------------*/
/*----------------------------------------------------------------------------*/
define variable cProgram as character     no-undo.

/* Buffers -------------------------------------------------------------------*/
&IF LOOKUP("VS","{&PA-MODULE}") > 0 &THEN
  define buffer bVS_Auftrag        for VS_Auftrag.
&ENDIF

/*----------------------------------------------------------------------------*/
/* Processing                                                                 */
/*----------------------------------------------------------------------------*/

  if available ttUV_VersandBeleg then
  do:

    if pcMode = 'update':U then
    do:

      if gcMenuItemDocumentHeader = '':U then
        gcMenuItemDocumentHeader = adm.method.cls.DMCMenuSvc:prpoInstance:prpcCurrentMenuItemObj.

      if not valid-handle (ghDocumentHeader) then
        gcProgramDocumentHeader = '':U.

      case ttUV_VersandBeleg.Belegart:

        when 'U':U then
          cProgram = 'vert/auf/proc/vupauf00.w':U.

        when 'VUA':U then
          cProgram = 'vert/auf/proc/vupabr00.w':U.

        &IF LOOKUP("VS","{&PA-MODULE}") > 0 &THEN
          when 'VSA':U then
          do:

            find bVS_Auftrag
              where bVS_Auftrag.Firma       = {firma/vbelegko.fir pACConnectionSvc:prpcCompany}
                and bVS_Auftrag.BelegArt    = 'VSA':U
                and bVS_Auftrag.ReferenzNr  = ttUV_VersandBeleg.ReferenzNr
              no-lock.

            if vert.serv.cls.VSCRepairOrderSvc:prpoInstance:lIsRepairOrderType(bVS_Auftrag.Auftragstyp) then
            do:

              cProgram = 'vert/serv/proc/vspreo00.w':U.

            end. /* if vert.serv.cls.VSCRepairOrderSvc:prpoInstance:lIsRepairOrderType */
            else

              cProgram = 'vert/serv/proc/vspauf00.w':U.

          end. /* when 'VSA':U then */  
        &ENDIF  

      end case.

      if cProgram <> gcProgramDocumentHeader then
      do:

        if valid-handle (ghDocumentHeader) then
          run dispatch in ghDocumentHeader ('exit':U).

        {adm/incl/d__run01.if
          &Programm     = "cProgram"
          &Link1        = "'record':U"
          &Source1      = "this-procedure"
          &runMode      = "'slaveupdate':U"
          &Handle       = "ghDocumentHeader"
          &CallerObject = "gcMenuItemDocumentHeader"
        }

        gcProgramDocumentHeader = cProgram.

      end. /* cProgram <> gcProgramDocumentHeader */


    end. /* pcMode = 'update':U */
    else
    do:

      if gcMenuItemDocumentHeaderInfo = '':U then
        gcMenuItemDocumentHeaderInfo = adm.method.cls.DMCMenuSvc:prpoInstance:prpcCurrentMenuItemObj.

      if not valid-handle (ghDocumentHeaderInfo) then
        gcProgramDocumentHeaderInfo = '':U.

      case ttUV_VersandBeleg.Belegart:

        when 'U':U then
          cProgram = 'vert/auf/proc/vupauf00.w':U.

        when 'VUA':U then
          cProgram = 'vert/auf/proc/vupabr00.w':U.

        &IF LOOKUP("VS","{&PA-MODULE}") > 0 &THEN  
          when 'VSA':U then
          do:

            find bVS_Auftrag
             where bVS_Auftrag.Firma       = {firma/vbelegko.fir pACConnectionSvc:prpcCompany}
               and bVS_Auftrag.BelegArt    = 'VSA':U
               and bVS_Auftrag.ReferenzNr  = ttUV_VersandBeleg.ReferenzNr
             no-lock.

            if vert.serv.cls.VSCRepairOrderSvc:prpoInstance:lIsRepairOrderType(bVS_Auftrag.Auftragstyp) then
            do:

              cProgram = 'vert/serv/proc/vspreo00.w':U.

            end. /* if vert.serv.cls.VSCRepairOrderSvc:prpoInstance:lIsRepairOrderType */
            else

              cProgram = 'vert/serv/proc/vspauf00.w':U.

          end. /* when 'VSA':U then */
        &ENDIF  

      end case.

      if cProgram <> gcProgramDocumentHeaderInfo then
      do:

        if valid-handle (ghDocumentHeaderInfo) then
          run dispatch in ghDocumentHeaderInfo ('exit':U).

        {adm/incl/d__run01.if
          &Programm     = "cProgram"
          &Link1        = "'record':U"
          &Source1      = "this-procedure"
          &runMode      = "'slaveinfo':U"
          &Handle       = "ghDocumentHeaderInfo"
          &CallerObject = "gcMenuItemDocumentHeaderInfo"
        }

        gcProgramDocumentHeaderInfo = cProgram.

      end. /* cProgram <> gcProgramDocumentHeaderInfo */

    end. /* pcMode = 'info':U */

  end. /* available ttUV_VersandBeleg */

end procedure. /* ShowDocumentHeader */

/* _UIB-CODE-BLOCK-END */
&ANALYZE-RESUME

&ANALYZE-SUSPEND _UIB-CODE-BLOCK _PROCEDURE ShowDocumentLine B-table-Win 
PROCEDURE ShowDocumentLine :
/* Description ---------------------------------------------------------------*/
/*                                                                            */
/* show document line                                                         */
/*                                                                            */
/* Notes ---------------------------------------------------------------------*/
/*                                                                            */
/*                                                                            */
/*                                                                            */
/* Parameters ----------------------------------------------------------------*/
/*                                                                            */
/* <none>                                                                     */
/*                                                                            */
/* Examples ------------------------------------------------------------------*/
/*                                                                            */
/*                                                                            */
/*                                                                            */
/*----------------------------------------------------------------------------*/
define input  parameter pcMode      as  character   no-undo.

/* Variables -----------------------------------------------------------------*/
/*----------------------------------------------------------------------------*/
define variable cProgram  as character     no-undo.

/* Buffers -------------------------------------------------------------------*/

/*----------------------------------------------------------------------------*/
/* Processing                                                                 */
/*----------------------------------------------------------------------------*/

  if available ttUV_VersandBeleg then
  do:

    if pcMode = 'update':U then
    do:

      if gcMenuItemDocumentLine = '':U then
        gcMenuItemDocumentLine = adm.method.cls.DMCMenuSvc:prpoInstance:prpcCurrentMenuItemObj.

      if not valid-handle (ghDocumentLine) then
        gcProgramDocumentLine = '':U.

      case ttUV_VersandBeleg.Belegart:

        when 'U':U then
          cProgram = 'vert/auf/proc/vupauf02.w':U.

        when 'VUA':U then
          cProgram = 'vert/auf/proc/vupabr02.w':U.

      end case.

      if      cProgram <> gcProgramDocumentLine then
      do:

        if valid-handle (ghDocumentLine) then
          run dispatch in ghDocumentLine ('exit':U).

        {adm/incl/d__run01.if
          &Programm     = "cProgram"
          &Link1        = "'record':U"
          &Source1      = "this-procedure"
          &runMode      = "'update':U"
          &Handle       = "ghDocumentLine"
          &PKS            = "'AbrufArt=LAB':U"
          &ATTRIBUTE-LIST = "'uPosition=':U + string(ttUV_VersandBeleg.Positionsnr * 10) + ',uCustomerCenter=yes':U"
          &CallerObject = "gcMenuItemDocumentLine"
        }

        gcProgramDocumentLine = cProgram.

      end. /* cProgram <> gcProgramDocumentLine */
      else if valid-handle(ghDocumentLine)  then
        run set-attribute-list in ghDocumentLine ('uPosition=':U + string(ttUV_VersandBeleg.Positionsnr * 10)).

    end. /* pcMode = 'update':U */
    else
    do:

      if gcMenuItemDocumentLineInfo = '':U then
        gcMenuItemDocumentLineInfo = adm.method.cls.DMCMenuSvc:prpoInstance:prpcCurrentMenuItemObj.

      if not valid-handle (ghDocumentLineInfo) then
        gcProgramDocumentLineInfo = '':U.

      case ttUV_VersandBeleg.Belegart:

        when 'U':U then
          cProgram = 'info/vert/proc/iviauf00.w':U.

        when 'VUA':U then
          cProgram = 'vert/auf/proc/iviabr00.w':U.
      end case.

      if        cProgram <> gcProgramDocumentLineInfo then
      do:

        if valid-handle (ghDocumentLineInfo) then
          run dispatch in ghDocumentLineInfo ('exit':U).

        {adm/incl/d__run01.if
          &Programm     = "cProgram"
          &Link1        = "'record':U"
          &Source1      = "this-procedure"
          &runMode      = "'info':U"
          &Handle       = "ghDocumentLineInfo"
          &PKS            = "'AbrufArt=LAB':U"
          &CallerObject = "gcMenuItemDocumentLineInfo"
        }

        gcProgramDocumentLineInfo = cProgram.

      end. /* cProgram <> gcProgramDocumentLineInfo */

    end. /* pcMode = 'info':U */

  end. /* available ttUV_VersandBeleg */

end procedure. /* ShowDocumentLine */

/* _UIB-CODE-BLOCK-END */
&ANALYZE-RESUME

&ANALYZE-SUSPEND _UIB-CODE-BLOCK _PROCEDURE state-changed B-table-Win 
PROCEDURE state-changed :
/* Description ---------------------------------------------------------------*/
/*                                                                            */
/* Handle state-changed messages                                              */
/*                                                                            */
/* Notes ---------------------------------------------------------------------*/
/*                                                                            */
/*                                                                            */
/*                                                                            */
/* Parameters ----------------------------------------------------------------*/
/*                                                                            */
/* phIssuer     Handle of calling object                                      */
/* pcState      new state                                                     */
/*                                                                            */
/*----------------------------------------------------------------------------*/

define input        parameter phIssuer as handle        no-undo.
define input        parameter pcState  as character     no-undo.

/* Variables -----------------------------------------------------------------*/

/*----------------------------------------------------------------------------*/

/* Buffers -------------------------------------------------------------------*/

/*----------------------------------------------------------------------------*/
/* Processing                                                                 */
/*----------------------------------------------------------------------------*/

case pcState:

  when 'child-update-complete':U then
  do:

    /* save changes */
    {call
      dsUVR_CIVersandBeleg
      modifyTrackingChanges
      no}.

    if glADM-Cancel = no then
    do:
      {call
        dsUVR_CIVersandBeleg
        saveChanges}.

    end.
    else
    do:
      dataset dsUVR_CIVersandBeleg:reject-changes().
      run pa_UISvcRefreshBrowse(browse {&BROWSE-NAME}:handle, no).
    end.

    glADM-Cancel = no.

  end.

  when 'child-update-begin':U then
    {call
      dsUVR_CIVersandBeleg
      modifyTrackingChanges
      yes}.

  /* Object instance CASEs can go here to replace standard behavior or add    */
  /* new cases.                                                               */

  {adm/template/incl/dt_brw00.if}

end case. /* pcState */

end procedure. /* state-changed */

/* _UIB-CODE-BLOCK-END */
&ANALYZE-RESUME

&ANALYZE-SUSPEND _UIB-CODE-BLOCK _PROCEDURE Teil-EAN B-table-Win 
PROCEDURE Teil-EAN :
/* Description ---------------------------------------------------------------*/
/*                                                                            */
/* Search and display of the part number                                      */
/*                                                                            */
/* Notes ---------------------------------------------------------------------*/
/*                                                                            */
/*                                                                            */
/*                                                                            */
/* Parameters ----------------------------------------------------------------*/
/*                                                                            */
/* <none>                                                                     */
/*                                                                            */
/* Examples ------------------------------------------------------------------*/
/*                                                                            */
/*                                                                            */
/*                                                                            */
/*----------------------------------------------------------------------------*/

/* Variables -----------------------------------------------------------------*/
/*----------------------------------------------------------------------------*/

/* Buffers -------------------------------------------------------------------*/

/*----------------------------------------------------------------------------*/
/* Processing                                                                 */
/*----------------------------------------------------------------------------*/

if input frame {&frame-name} gcSuche > '':U then
do:

  find first gbS_EAN
    where gbS_EAN.Firma   = {firma/sartikel.fir pa-firma}
      and gbS_EAN.Artikel = input frame {&frame-name} gcArtikel
      and gbS_EAN.EAN     = input frame {&frame-name} gcSuche
    no-lock no-error.

  if not available gbS_EAN then

    find first gbS_EAN
      where gbS_EAN.Firma = {firma/sartikel.fir pa-firma}
        and gbS_EAN.EAN   = input frame {&frame-name} gcSuche
      no-lock no-error.

  if available gbS_EAN then

    {setwidgetattr
       "gcArtikel"
       "screen-value"
       "gbS_EAN.Artikel"
       "in frame {&frame-name}"}.

end.

end procedure. /* Teil-EAN */

/* _UIB-CODE-BLOCK-END */
&ANALYZE-RESUME

&ANALYZE-SUSPEND _UIB-CODE-BLOCK _PROCEDURE Teil-Kunde B-table-Win 
PROCEDURE Teil-Kunde :
/* Description ---------------------------------------------------------------*/
/*                                                                            */
/* Search and display of the part number                                      */
/*                                                                            */
/* Notes ---------------------------------------------------------------------*/
/*                                                                            */
/*                                                                            */
/*                                                                            */
/* Parameters ----------------------------------------------------------------*/
/*                                                                            */
/* <none>                                                                     */
/*                                                                            */
/* Examples ------------------------------------------------------------------*/
/*                                                                            */
/*                                                                            */
/*                                                                            */
/*----------------------------------------------------------------------------*/

/* Variables -----------------------------------------------------------------*/
/*----------------------------------------------------------------------------*/

/* Buffers -------------------------------------------------------------------*/

define buffer bS_Artikel  for S_Artikel.

/*----------------------------------------------------------------------------*/
/* Processing                                                                 */
/*----------------------------------------------------------------------------*/


if    input frame {&frame-name} gcSuche > '':U then
do:

  find first gbS_ArtKunde
    where gbS_ArtKunde.Firma     = {firma/sartkund.fir pa-firma}
      and gbS_ArtKunde.ArtikelNr = input frame {&frame-name} gcSuche
      and gbS_ArtKunde.Artikel   = input frame {&frame-name} gcArtikel
    no-lock no-error.

  if not available gbS_ArtKunde then
  do:

    PartSearch:
    for each gbS_ArtKunde
      where gbS_ArtKunde.Firma     = {firma/sartkund.fir pa-firma}
        and gbS_ArtKunde.ArtikelNr = input frame {&frame-name} gcSuche
      no-lock on error undo, throw:

      if can-find(bS_Artikel
                    where bS_Artikel.Firma   = {firma/sartikel.fir pa-firma}
                      and bS_Artikel.Artikel = gbS_ArtKunde.Artikel 
                      and bS_Artikel.archiviert = no) then
      do:

        {setwidgetattr
           "gcArtikel"
           "screen-value"
           "gbS_ArtKunde.Artikel"
           "in frame {&frame-name}"}.
        leave PartSearch.

      end. /* if can-find(S_Artikel */

    end. /* for each S_ArtKunde */

    if gcArtikel:screen-value in frame {&frame-name} = '':U then
      find first gbS_ArtKunde
        where gbS_ArtKunde.Firma     = {firma/sartkund.fir pa-firma}
          and gbS_ArtKunde.ArtikelNr = input frame {&frame-name} gcSuche
        no-lock no-error.

  end. /* if not available S_ArtKunde then */

  if available gbS_ArtKunde then

    {setwidgetattr
       "gcArtikel"
       "screen-value"
       "gbS_ArtKunde.Artikel"
       "in frame {&frame-name}"}.

end.

end procedure. /* Teil-Kunde */

/* _UIB-CODE-BLOCK-END */
&ANALYZE-RESUME

&ANALYZE-SUSPEND _UIB-CODE-BLOCK _PROCEDURE UpdateTotalValues B-table-Win 
PROCEDURE UpdateTotalValues :
/* Description ---------------------------------------------------------------*/
/*                                                                            */
/* Update Gesamtwert and Gesamtwert offen column values                       */
/*                                                                            */
/* Notes ---------------------------------------------------------------------*/
/*                                                                            */
/*                                                                            */
/*                                                                            */
/* Parameters ----------------------------------------------------------------*/
/*                                                                            */
/* <none>                                                                     */
/*                                                                            */
/* Examples ------------------------------------------------------------------*/
/*                                                                            */
/*                                                                            */
/*                                                                            */
/*----------------------------------------------------------------------------*/

/* Variables -----------------------------------------------------------------*/
/*----------------------------------------------------------------------------*/

define variable dGesamtwert_Markiert       as decimal no-undo initial 0.
define variable dGesamtwert_Offen_Markiert as decimal no-undo initial 0.
define variable dGesamtwert_Alle           as decimal no-undo initial 0.
define variable dGesamtwert_offen_alle     as decimal no-undo initial 0.

/* Buffers -------------------------------------------------------------------*/
define buffer bttUV_VersandBeleg for temp-table ttUV_VersandBeleg.

/*----------------------------------------------------------------------------*/
/* Processing                                                                 */
/*----------------------------------------------------------------------------*/

  giHits = 0.

  for each bttUV_VersandBeleg
    no-lock:

    if bttUV_VersandBeleg.Markiert = yes then
      assign
        dGesamtwert_Markiert       = dGesamtwert_Markiert + bttUV_VersandBeleg.GesamtwertVerfuegbar
        dGesamtwert_Offen_Markiert = dGesamtwert_Offen_Markiert + bttUV_VersandBeleg.GesamtwertOffen
        .

    assign
      dGesamtwert_Alle       = dGesamtwert_Alle + bttUV_VersandBeleg.GesamtwertVerfuegbar
      dGesamtwert_offen_alle = dGesamtwert_offen_alle + bttUV_VersandBeleg.GesamtwertOffen
      giHits                 = giHits + 1
      .

  end.

  do with frame {&FRAME-NAME}:

    assign
      gdGesamtwert_Markiert              = dGesamtwert_Markiert
      gdGesamtwert_Offen_Markiert        = dGesamtwert_Offen_Markiert
      gdGesamtwert_Alle                  = dGesamtwert_Alle
      gdGesamtwert_offen_alle            = dGesamtwert_offen_alle
      {setwidgetattr
         "gdGesamtwert_Markiert"
         "format"
         "dynamic-function('pa_cCurValTotalFormat':U in target-procedure, pACConnectionSvc:prpcCompany, 0)"}
      {setwidgetattr
         "gdGesamtwert_Offen_Markiert"
         "format"
         "dynamic-function('pa_cCurValTotalFormat':U in target-procedure, pACConnectionSvc:prpcCompany, 0)"}
      {setwidgetattr
         "gdGesamtwert_Alle"
         "format"
         "dynamic-function('pa_cCurValTotalFormat':U in target-procedure, pACConnectionSvc:prpcCompany, 0)"}
      {setwidgetattr
         "gdGesamtwert_offen_alle"
         "format"
         "dynamic-function('pa_cCurValTotalFormat':U in target-procedure, pACConnectionSvc:prpcCompany, 0)"}
      .

    {adm/incl/d__duh00.if
       &Var1     = "gdGesamtwert_Markiert"
       &Var2     = "gdGesamtwert_Offen_Markiert"
       &Var3     = "gdGesamtwert_Alle"
       &Var4     = "gdGesamtwert_offen_alle"
       &WithFrame = "frame {&FRAME-NAME}"}

  end.

end procedure. /* UpdateTotalValues */

/* _UIB-CODE-BLOCK-END */
&ANALYZE-RESUME

&IF LOOKUP("VS","{&PA-MODULE}") > 0 &THEN

&ANALYZE-SUSPEND _UIB-CODE-BLOCK _PROCEDURE getQueryAttribute B-table-Win  adm/support/proc/ds_qat00.p
procedure getQueryAttribute :
/* Description ---------------------------------------------------------------*/
/*                                                                            */
/* return query attribute as requested by parameter                           */
/*                                                                            */
/* Notes ---------------------------------------------------------------------*/
/*                                                                            */
/* This procedure is generated by the app builder.                            */
/*                                                                            */
/* Parameters ----------------------------------------------------------------*/
/*                                                                            */
/* pcAttribute          name of requested attribute                           */
/*                                                                            */
/*----------------------------------------------------------------------------*/

define input  parameter pcAttribute as character no-undo.

/* Variables -----------------------------------------------------------------*/
/*----------------------------------------------------------------------------*/

/* Buffers -------------------------------------------------------------------*/

/*----------------------------------------------------------------------------*/
/* Processing                                                                 */
/*----------------------------------------------------------------------------*/

case pcAttribute:

  when 'pa-filter-Abladestelle_max':U then
    return string(pa-filter-Abladestelle_max).

  when 'pa-filter-Abladestelle_min':U then
    return string(pa-filter-Abladestelle_min).

  when 'pa-filter-AdressKennung_max':U then
    return string(pa-filter-AdressKennung_max).

  when 'pa-filter-AdressKennung_min':U then
    return string(pa-filter-AdressKennung_min).

  when 'pa-filter-Artikel_max':U then
    return string(pa-filter-Artikel_max).

  when 'pa-filter-Artikel_min':U then
    return string(pa-filter-Artikel_min).

  when 'pa-filter-ArtikelArt_max':U then
    return string(pa-filter-ArtikelArt_max).

  when 'pa-filter-ArtikelArt_min':U then
    return string(pa-filter-ArtikelArt_min).

  when 'pa-filter-ArtikelGruppe_max':U then
    return string(pa-filter-ArtikelGruppe_max).

  when 'pa-filter-ArtikelGruppe_min':U then
    return string(pa-filter-ArtikelGruppe_min).

  when 'pa-filter-AuftragsArt_max':U then
    return string(pa-filter-AuftragsArt_max).

  when 'pa-filter-AuftragsArt_min':U then
    return string(pa-filter-AuftragsArt_min).

  when 'pa-filter-BelegNummer_max':U then
    return string(pa-filter-BelegNummer_max).

  when 'pa-filter-BelegNummer_min':U then
    return string(pa-filter-BelegNummer_min).

  when 'pa-filter-CreditTerms_max':U then
    return string(pa-filter-CreditTerms_max).

  when 'pa-filter-CreditTerms_min':U then
    return string(pa-filter-CreditTerms_min).

  when 'pa-Filter-DeliveryRestriction_max':U then
    return string(pa-Filter-DeliveryRestriction_max).

  when 'pa-Filter-DeliveryRestriction_min':U then
    return string(pa-Filter-DeliveryRestriction_min).

  when 'pa-filter-iBezugsdatum_var':U then
    return string(pa-filter-iBezugsdatum_var).

  when 'pa-filter-iHorizont_var':U then
    return string(pa-filter-iHorizont_var).

  when 'pa-filter-iMRPRelease_var':U then
    return string(pa-filter-iMRPRelease_var).

  when 'pa-filter-Konto_max':U then
    return string(pa-filter-Konto_max).

  when 'pa-filter-Konto_min':U then
    return string(pa-filter-Konto_min).

  when 'pa-filter-lFutureOrderLines_var':U then
    return string(pa-filter-lFutureOrderLines_var).

  when 'pa-filter-LieferAdresse_max':U then
    return string(pa-filter-LieferAdresse_max).

  when 'pa-filter-LieferAdresse_min':U then
    return string(pa-filter-LieferAdresse_min).

  when 'pa-filter-Lieferant_max':U then
    return string(pa-filter-Lieferant_max).

  when 'pa-filter-Lieferant_min':U then
    return string(pa-filter-Lieferant_min).

  when 'pa-filter-LieferBedingung_max':U then
    return string(pa-filter-LieferBedingung_max).

  when 'pa-filter-LieferBedingung_min':U then
    return string(pa-filter-LieferBedingung_min).

  when 'pa-filter-Liefertermin_max':U then
    return string(pa-filter-Liefertermin_max).

  when 'pa-filter-Liefertermin_min':U then
    return string(pa-filter-Liefertermin_min).

  when 'pa-filter-lPastOrderLines_var':U then
    return string(pa-filter-lPastOrderLines_var).

  when 'pa-filter-lTodayOrderLines_var':U then
    return string(pa-filter-lTodayOrderLines_var).

  when 'pa-filter-MRPArea_max':U then
    return string(pa-filter-MRPArea_max).

  when 'pa-filter-MRPArea_min':U then
    return string(pa-filter-MRPArea_min).

  when 'pa-filter-Sachbearbeiter_max':U then
    return string(pa-filter-Sachbearbeiter_max).

  when 'pa-filter-Sachbearbeiter_min':U then
    return string(pa-filter-Sachbearbeiter_min).

  when 'pa-filter-Sparte_max':U then
    return string(pa-filter-Sparte_max).

  when 'pa-filter-Sparte_min':U then
    return string(pa-filter-Sparte_min).

  when 'pa-filter-StorageArea_max':U then
    return string(pa-filter-StorageArea_max).

  when 'pa-filter-StorageArea_min':U then
    return string(pa-filter-StorageArea_min).

  when 'pa-filter-uCI_LagerortKunde_max':U then
    return string(pa-filter-uCI_LagerortKunde_max).

  when 'pa-filter-uCI_LagerortKunde_min':U then
    return string(pa-filter-uCI_LagerortKunde_min).

  when 'pa-filter-uCI_Warenausgangst_max':U then
    return string(pa-filter-uCI_Warenausgangst_max).

  when 'pa-filter-uCI_Warenausgangst_min':U then
    return string(pa-filter-uCI_Warenausgangst_min).

  when 'pa-filter-VersandArt_max':U then
    return string(pa-filter-VersandArt_max).

  when 'pa-filter-VersandArt_min':U then
    return string(pa-filter-VersandArt_min).

  when 'pa-filter-Versandtermin_max':U then
    return string(pa-filter-Versandtermin_max).

  when 'pa-filter-Versandtermin_min':U then
    return string(pa-filter-Versandtermin_min).

  when 'pa-filter-Wunschtermin_max':U then
    return string(pa-filter-Wunschtermin_max).

  when 'pa-filter-Wunschtermin_min':U then
    return string(pa-filter-Wunschtermin_min).
  
  /* --> MO#HIDR-AH4-1123 thongdi_p 20.07.2026 Erweiterung Versandmonitor im Feld Best. Termin */
  when 'pa-filter-xEbLiefertermin_max':U then
    return string(pa-filter-xEbLiefertermin_max).

  when 'pa-filter-xEbLiefertermin_min':U then
    return string(pa-filter-xEbLiefertermin_min).
  /* <-- MO#HIDR-AH4-1123 thongdi_p 20.07.2026 Erweiterung Versandmonitor im Feld Best. Termin */
  
  otherwise
    undo, throw new adm.method.cls.DMCNotExistingErr
      ('Get browse query attribute':U,'Query attribute':U,pcAttribute).

end case.

end procedure. /* getQueryAttribute */

/* _UIB-CODE-BLOCK-END */
&ANALYZE-RESUME

&ANALYZE-SUSPEND _UIB-CODE-BLOCK _PROCEDURE handleBrowserClose Method-Library
procedure handleBrowserClose :
/* Description ---------------------------------------------------------------*/
/*                                                                            */
/* Handles the closing event of the Serviceorder Browser vsbhan02.w.          */
/* This is triggerd when the user finsihes editing and closes the Browser     */
/*                                                                            */
/* Parameters ----------------------------------------------------------------*/
/*                                                                            */
/* <none>                                                                     */
/*                                                                            */
/*----------------------------------------------------------------------------*/
assign giCurrentIndex = giCurrentIndex + 1.

if not can-find (ttRepairOrderCallIteration 
                   where ttRepairOrderCallIteration.seqNumber = giCurrentIndex) then
do:

  empty temp-table ttRepairOrderCallIteration.
  empty temp-table ttUPositions-Service.

  if glMarked then
  do:
    run read-current-offset(pa-sortby-case).
    gcOffset-value = return-value.

    run FillTT.

  end.

  return.                 

end. /* if not can-find (ttRepairOrderCallIteration */

run processingNextRecord.

end procedure. /* procedure handleBrowserClose */

/* _UIB-CODE-BLOCK-END */
&ANALYZE-RESUME
&ENDIF
/* ************************  Function Implementations ***************** */

&ANALYZE-SUSPEND _UIB-CODE-BLOCK _FUNCTION pa_lUISvcObjectState B-table-Win 
FUNCTION pa_lUISvcObjectState returns logical
  ( pcStateCode as character ):
/* Description ---------------------------------------------------------------*/
/*                                                                            */
/* Extend implementation in dmcuis00.p                                        */
/*                                                                            */
/* Notes ---------------------------------------------------------------------*/
/*                                                                            */
/*                                                                            */
/*                                                                            */
/* Parameters ----------------------------------------------------------------*/
/*                                                                            */
/* pcStateCode State-Code to check                                            */
/*                                                                            */
/* Examples ------------------------------------------------------------------*/
/*                                                                            */
/*                                                                            */
/*                                                                            */
/*----------------------------------------------------------------------------*/

/* Variables -----------------------------------------------------------------*/
/*----------------------------------------------------------------------------*/

/* Buffers -------------------------------------------------------------------*/

/*----------------------------------------------------------------------------*/
/* Processing                                                                 */
/*----------------------------------------------------------------------------*/


case pcStateCode:

  when 'paSCIsRecordAvailable':U then
    return num-results('{&BROWSE-NAME}':U) > 0.

  when 'paSCisPickingAvailable':U then
    return can-find(first ttUV_VersandBeleg
                    where ttUV_VersandBeleg.Markiert = yes
                      and lookup(ttUV_VersandBeleg.Belegart, 'U,VUA,VSA':U) > 0).


  when 'paSCisMaterialLine':U then

    &IF LOOKUP("VS","{&PA-MODULE}") > 0 &THEN
      return not (   adm.method.cls.DMCSessionSvc:cOwningTable(ttUV_Versandbeleg.Owning_obj) = 'VS_AuftragMKT':U
                  or adm.method.cls.DMCSessionSvc:cOwningTable(ttUV_Versandbeleg.Owning_obj) = 'VS_AuftragPos':U).
    &ELSE
      return yes.
    &ENDIF

  {&{&PA-XBasisName}_C_UISvcObjectState}
  {&{&PA-XBasisName}_U_UISvcObjectState}
  {&{&PA-XBasisName}_UISvcObjectState}
  {&{&PA-XBasisName}_Y_UISvcObjectState}

  otherwise /* pass other states to super-procedure */
    return super(pcStateCode).

end case. /* case pcStateCode: */

end function. /* pa_lUISvcObjectState */

/* _UIB-CODE-BLOCK-END */
&ANALYZE-RESUME

