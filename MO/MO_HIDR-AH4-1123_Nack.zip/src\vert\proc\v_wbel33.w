&ANALYZE-SUSPEND _VERSION-NUMBER UIB_v8r12 GUI ADM1
&ANALYZE-RESUME
/* Connected Databases 
          temp-db          PROGRESS
          basis            PROGRESS
*/
&Scoped-define WINDOW-NAME CURRENT-WINDOW

&ANALYZE-SUSPEND _UIB-CODE-BLOCK _CUSTOM _DECLARATIONS V-table-Win 
using stamm.base.cls.*.
using adm.method.cls.DMCMessageSvc.
using adm.method.cls.DMCSessionSvc.

/* _UIB-CODE-BLOCK-END */
&ANALYZE-RESUME


&ANALYZE-SUSPEND _UIB-CODE-BLOCK _XFTR "Update Information" V-table-Win _INLINE
/* Actions: ? ? ? ? adm/support/proc/ds_pa_01.w */

/* _UIB-CODE-BLOCK-END */
&ANALYZE-RESUME



/* Temp-Table and Buffer definitions                                    */
define temp-table TT_MC_Lot no-undo like TD_MC_Lot.



&ANALYZE-SUSPEND _UIB-CODE-BLOCK _CUSTOM _DEFINITIONS V-table-Win 
/******************************************************************************/
/* @COPYRIGHT@                                                                */
/* Project: Proalpha                                                          */
/*                                                                            */
/* Name   : v_wbel33.w                                                        */
/* Product: VERT         - Vertrieb                                           */
/* Module : KERN         - VT-Basis                                           */
/*                                                                            */
/* Created: 4.2 as of 15.01.2003/Elmar Kiefer                                 */
/* Current: @PAVERSION@ as of @PADATE@/@PALASTAUTHOR@                         */
/*                                                                            */
/*----------------------------------------------------------------------------*/
/* DESCRIPTION                                                                */
/*----------------------------------------------------------------------------*/
/*                                                                            */
/* Viewer V_BelegPos for documenttype U                                       */
/*                                                                            */
/*----------------------------------------------------------------------------*/
/* PARAMETERS                                                                 */
/*----------------------------------------------------------------------------*/
/* Name                      Description                                      */
/*----------------------------------------------------------------------------*/
/*                                                                            */
/*----------------------------------------------------------------------------*/
/* HISTORY                                                                    */
/*----------------------------------------------------------------------------*/
/* @FILEHISTORY@                                                              */
/******************************************************************************/

create widget-pool.

/* Procedure Information -----------------------------------------------------*/

&GLOBAL-DEFINE pa-Autor             Elmar Kiefer
&GLOBAL-DEFINE pa-Version           @PAVERSION@
&GLOBAL-DEFINE pa-Datum             @PADATE@
&GLOBAL-DEFINE pa-Letzter           @PALASTAUTHOR@

&GLOBAL-DEFINE pa-GenVersion       UIB
&GLOBAL-DEFINE pa-ProgrammTyp      SmartViewer
&GLOBAL-DEFINE pa-Template         adm/template/proc/dt_viw00.w
&GLOBAL-DEFINE pa-TemplateVersion  4.00
&GLOBAL-DEFINE pa-XBasisName       v_wbel33_w
&GLOBAL-DEFINE pa-NameSpace        2.00

/* Parameters ----------------------------------------------------------------*/



/* Globals -------------------------------------------------------------------*/

/* Library (Procedure - Auswahl) --------------------------------------------*/

/* v__pfi00.lib  */

&GLOBAL-DEFINE EXCLUDE-initialisiere-Belegzeile      yes
&GLOBAL-DEFINE EXCLUDE-d_rabattf-ZeilenGesamtWert    yes
&GLOBAL-DEFINE EXCLUDE-d_ZeilenEinzelPreis           yes
&GLOBAL-DEFINE EXCLUDE-d_ZeilenGesamtpreis_EW        yes
&GLOBAL-DEFINE EXCLUDE-d_ZeilenGesamtWert            yes

/* Deaktivierungen vu_bel00.lib */

&GLOBAL-DEFINE EXCLUDE-Abruflieferung                yes
&GLOBAL-DEFINE EXCLUDE-Lieferadresse                 yes
&GLOBAL-DEFINE EXCLUDE-Rahmenauftrag                 yes

/* Deaktivierungen v_wbel01.lib */

/* Deaktivierungen v_wbel02.lib */

/* Deaktivierungen v_wbel03.lib */

&GLOBAL-DEFINE EXCLUDE-LagerortAendern               yes
&GLOBAL-DEFINE EXCLUDE-pruefeLager                   yes

/* Deaktivierungen v_wbel05.lib */

/* Deaktivierungen v_wbel06.lib */

&GLOBAL-DEFINE EXCLUDE-PruefePackmittel              yes

/* Deaktivierungen v_wbel07.lib */

/* Deaktivierungen v_wbel08.lib */

/* Deaktivierungen v_wbel09.lib */

&GLOBAL-DEFINE EXCLUDE-pruefeAbrufauftrag            yes
&GLOBAL-DEFINE EXCLUDE-Abrufmenge                    yes

/* Deaktivierungen v_wbel00.lib */

&GLOBAL-DEFINE EXCLUDE-Herkunft                      yes

{adm/template/incl/dt_viw00.df}

/* SCOPEDs -------------------------------------------------------------------*/

&Scop pa-hlp-fieldnames Lagerort,KO_Lagerort,Wert_RZ_Art_1,Wert_RZ_Art_2,proz_RZ_Art_1,proz_RZ_Art_2,proz_RZ_Art_3,MMM_CusRefOrder_ID,uCI_VersandArt,gcZollNummer
&scop pa-hlp-keynames   Storagearea,Lagerort,RZ_Art,RZ_Art,RZ_Art,RZ_Art,RZ_Art,MMM_CusRefOrder_ID,VersandArt,SBM_CustomsTariffNo_ID
&scop pa-hlp-VirtualFieldNames ,,,,,,,,,SBM_CustomsTariffNo_ID

&Scoped-define pa-FieldEnableStateCode V_BelegPos.Liefertermin:!paSCisDeliveryDateSensitive ~
V_BelegPos.Transportzeit:!paSCisDeliveryDateSensitive ~
V_BelegPos.Zeiteinheit:!paSCisDeliveryDateSensitive ~
V_BelegPos.MMM_CusRefOrder_ID:paSCisCRONumberSensitive



/* Variables -----------------------------------------------------------------*/
/*   Name               Funktion                                              */
/*   ------------------ ----------------------------------------------------- */
/*   gdVME_Faktor       factor for packaging                                  */
/*   giNachkomma        decimal places                                        */
/*   giMengeneinheit    quantity unit                                         */
/*   l_PFI_noetig       Indicator, pricing necessary                          */
/*   gcBelegart         document type                                         */
/*   gdEinstandspreis   base price                                            */
/*   glEinstandspreis   price of once only part                               */
/*   gdStatistikwert    statistical value                                     */
/*   gdbesondere_Menge  special amount                                        */
/*   glIntra            handling intradata or not                             */
/*   glauto_Intra       enter intradata ot not                                */
/*   gdMerke_Menge      perceive amount                                       */
/*   gdMerke_resMenge   perceive reserved amount                              */
/*   dReserviertVME     reserved amount                                       */
/*   giMerke_Lagerort   perceive storage                                      */
/*   gcSMLeiste         class list of characteristics                         */
/*   glNewPosition      is a new position                                     */
/*   glPP_Auftrag       generate work order                                   */
/*                      (parameter 'PP_WorkOrderFromSales')                   */
/*   giRueckmeldeNr     data entry number                                     */
/*   gcAuftrag          combined key for order                                */
/*   glCancel           type of amount for set-part                           */
/*   giAktion           pricing                                               */
/*   glSpanne           margin                                                */
/*   glVerfuegbarkeit   automatic check of availability                       */
/*                      (parameter 'VU_AutoAvailableToPromiseCheck')          */
/*   gcBereich          area                                                  */
/*   glAenderungBuchung posting                                               */
/*   glV_IntraErf       intradata (parameter 'VB_NoIntraDataInSales')         */
/*   gcAnsicht          view                                                  */
/*   glFolgeteile       additional parts                                      */
/*   glPreisFindSet     pricing for set parts                                 */
/*   gdMerkeMengeSet    perceive amount for set parts                         */
/*   glVariantenStart   treatment of variants                                 */
/*   glConfigError      handing over of parameter                             */
/*   glSNrVFP           enter serialnumbers when Pro Forma Invoices           */
/*                      parameter 'MS_EntrySerialNoInProFormaInvoice'         */
/*   glProd             work order available                                  */
/*   gdPPAMenge         amount for CTP                                        */
/*   gtSEndtermin       end date CTP                                          */
/*   gcSteuer           tax treatment                                         */
/*   gcSteuer_Keys      tax treatment                                         */
/*   gcSteuersatzListe  tax treatment                                         */
/*   gcTaxOID           Object-ID from S_Steuer                               */
/*   gcTaxOIDList       Tax List with S_Steuer_Obj                            */
/*   iTransportzeit1    transport time                                        */
/*   iTransportzeit2    transport time                                        */
/*   giLagergruppe      warehouse                                             */
/*   glDeliveryDateChange  change of delivery date                            */
/*   glCreatePurchaseOrder create purchase order by option VU_BEST?           */
/*   glMessage          show the Message Window (v_wbel06.lib)                */
/*   glNettableStorageArea yes, if the storage area is nettable               */
/*   gdGrossProfitAmt   gross profit amount (v_wbel00.lib)                    */
/*   gdGrossMargin      gross profit (percentage) (v_wbel00.lib)              */
/*   gdAverageCosts     extent of average costs                               */
/*   glArchive          line is just being archived (info by v_wbel10.w)      */
/*   glMess00405        yes if message v_-bel-00405 has been shown            */
/*   gdTotalPriceMax    possible total price in current number format         */
/*   glFlagTotalPriceMax flag if total price exceeds max number format        */
/*   gcConfigPriceHandling handling strategy for the configurator if manual   */
/*                      prices are allowed.                                   */
/*   gdTaxBase          tax base                                              */
/*   gdTaxableAmount    taxable amount (extent 6)                             */
/*   gdTaxAmount        tax amount (extent 6)                                 */
/*   gdTaxRate          tax rate (extent 6)                                   */
/*   glFIgnoreITS       ignore ITS flag  (used in french localization)        */
/*   giFRegime          regime           (used in french localization)        */
/*   gcFSBM_BusinessCategory_Obj   business cat OID                           */
/*                                 (used in french localization)              */
/*   gdFEcoTaxAmount    eco tax amount (used in french localization)          */
/*   gdFEcoTaxCalc      eco tax calc   (used in french localization)          */
/*----------------------------------------------------------------------------*/

define variable gdVME_Faktor           like V_BelegPos.VME_Faktor                  no-undo.
define variable gdVME_Faktor_Sales     like V_BelegPos.VME_Faktor                  no-undo.
define variable giNachkomma            like V_BelegPos.Nachkomma                   no-undo.
define variable giMengeneinheit        like V_BelegPos.Mengeneinheit               no-undo.
define variable l_PFI_noetig           as   logical                                no-undo.
define variable gcBelegart             like V_Belegkopf.Belegart                   no-undo.
define variable gdEinstandspreis       like V_BelegPos.Einstandspreis              no-undo.
define variable glEinstandspreis       as   logical init no                        no-undo.
define variable gdStatistikwert        like S_IntraHandel.Statistikwert            no-undo.
define variable gdbesondere_Menge      like S_IntraHandel.BesondereMenge           no-undo.
define variable glIntra                as   logical init no                        no-undo.
define variable glauto_Intra           as   logical init no                        no-undo.
define variable gdMerke_Menge          like V_BelegPos.Menge                       no-undo.
define variable gdMerke_resMenge       like V_BelegPos.Menge                       no-undo.
define variable dReserviertVME         like V_BelegPos.Menge                       no-undo.
define variable giMerke_Lagerort       like ML_Ort.Lagerort                        no-undo.
define variable gcSMLeiste             like MMM_CusRefOrder.ClassSystem            no-undo.  /* Code checked by ws 05.06.2008 */
define variable glNewPosition          as   logical                                no-undo.
define variable glPP_Auftrag           as   logical init no                        no-undo.
define variable giRueckmeldeNr         like PP_Auftrag.RueckMeldeNr init ?         no-undo.
define variable gcAuftrag              as   character                              no-undo.
define variable glCancel               as   logical init no                        no-undo.
define variable giAktion               like V_BelegPos.Aktion                      no-undo.
define variable glSpanne               as   logical init no                        no-undo.
define variable glVerfuegbarkeit       as   logical init no                        no-undo.
define variable gcBereich              like BB_Bereich.Bereich                     no-undo.
define variable glAenderungBuchung     as   logical init yes                       no-undo.
define variable glV_IntraErf           as   logical init no                        no-undo.
define variable gcAnsicht              as   character                              no-undo.
define variable glFolgeteile           as   logical init no                        no-undo.
define variable glPreisFindSet         as   logical                                no-undo.
define variable gdMerkeMengeSet        like V_BelegPos.Menge                       no-undo.
define variable glVariantenStart       as   logical init yes                       no-undo.
define variable glConfigError          as   logical init no                        no-undo.  /* Code checked by ws 05.06.2008 */
define variable glSNrVFP               as   logical init no                        no-undo.
&IF lookup("V_PKF":U,"{&PA-OPTIONEN}":U) > 0 &THEN
  &IF lookup("MU":U,"{&PA-MODULE}":U) > 0 &THEN
    define variable glProd             as   logical init no                      no-undo.  /* Code checked by ws 05.06.2008 */
  &ENDIF
&ENDIF
define variable gdPPAMenge             like V_BelegPos.Menge                       no-undo.  /* Code checked by ws 05.06.2008 */
define variable iTransportzeit1        like V_BelegPos.Transportzeit               no-undo.  /* Code checked by ws 05.06.2008 */
define variable iTransportzeit2        like V_BelegPos.Transportzeit               no-undo.  /* Code checked by ws 05.06.2008 */
define variable gtSEndtermin           like V_BelegPos.Liefertermin                no-undo.  /* Code checked by ws 05.06.2008 */
define variable gcSteuer               as   character                              no-undo.
define variable gcSteuer_Keys          as   character                              no-undo.  /* code checked by Stefan_I Jul 7, 2020 used in v_wbel35.if */
define variable gcSteuersatzListe      as   character                              no-undo.
define variable gcTaxOID               like S_Steuer.S_Steuer_Obj                  no-undo.
define variable gcTaxOIDList           as   character                              no-undo.
define variable giLagergruppe          like V_BelegKopf.Lagergruppe                no-undo.
define variable glDeliveryDateChanged  as   logical                                no-undo.  /* code checked by tts 01.04.2019 */
define variable glCreatePurchaseOrder  as   logical init no                        no-undo.
define variable glMessage              as   logical init yes                       no-undo.  /* Code checked by tf 08.12.2009 */
define variable glNettableStorageArea  as   logical init yes                       no-undo.
define variable glMRPRelease           as   logical init yes                       no-undo.
define variable gdGrossProfitAmt       like V_BelegPos.Gesamtpreis                 no-undo.  /* code checked by Matheis_U 18.01.2012 */
define variable gdGrossMargin          like S_ArtGruppe.Spanne                     no-undo.  /* code checked by Matheis_U 18.01.2012 */
define variable gdAverageCosts         as   decimal extent {&pa_MM_Fraction_Count} no-undo.
define variable glArchive              like V_BelegPos.offen init no               no-undo.
define variable glSetCalledByMenu      as   logical                                no-undo.
define variable glMess00405            as logical                                  no-undo.
define variable giStorageArea          as integer                                  no-undo.
define variable glInUpdate             as logical                                  no-undo.
define variable glCheckAdditionalParts as logical                                  no-undo.
define variable gdTotalPriceMax        as decimal                                  no-undo.
define variable glFlagTotalPriceMax    as logical                                  no-undo.
&IF lookup("MU":U,"{&PA-MODULE}":U) > 0 &THEN
  define variable gcConfigPriceHandling as character init 'ManPricePossible':U  no-undo.
&ENDIF
define variable gdTaxBase             like V_BelegPos.USTax_TaxBase               no-undo.
define variable gdTaxableAmount       like V_BelegPos.USTax_TaxableAmount         no-undo.
define variable gdTaxAmount           like V_BelegPos.USTax_TaxAmount             no-undo.
define variable gdTaxRate             like V_BelegPos.USTax_TaxRate               no-undo.

define variable glFIgnoreITS                as logical                            no-undo.   /* Code checked by ako 02.02.2009 used in .w */
define variable giFRegime                   as integer                            no-undo.   /* Code checked by ako 04.02.2009 used in .w */
define variable gcFSBM_BusinessCategory_Obj as character                          no-undo.   /* Code checked by ako 04.02.2009 used in .w */
define variable gdFEcoTaxAmount             like V_BelegPos.Wert_RZ_5             no-undo.   /* code checked by sy 25.05.2011 used in v__ecaf0.if */
define variable gdFEcoTaxCalc               like V_BelegPos.Wert_RZ_5             no-undo.

&IF LOOKUP("U_CI":U,"{&PA-OPTIONEN}":U) > 0 &THEN
  define variable guiVertriebsweg like V_BelegPos.uCI_Vertriebsweg  no-undo.
  define variable gulVersendung   like V_BelegKopf.Versendung       no-undo.
  &ENDIF

&IF LOOKUP("U_CW":U,"{&PA-OPTIONEN}":U) > 0 &THEN
  define variable gcuDestinationStaat like S_Adresse.Staat no-undo.
  define variable gcuDestinationPlz   like S_Adresse.PLZ   no-undo.
  define variable gluSAChanged        as logical           no-undo.

&ENDIF /* U_CW */

&IF LOOKUP("U_CE":U,"{&PA-OPTIONEN}":U) > 0 &THEN
  define variable ghuLastVisibleWidget  as handle no-undo. /* code checked by Stefan_I Jul 7, 2020 used in v_wbel35.if */
  define variable ghuCurrentWidget      as handle no-undo.
  define variable ghuCurrentWidgetSLH   as handle no-undo. /* code checked by Stefan_I Jul 7, 2020 used in v_wbel35.if */
&ENDIF /* U_CE */

&IF LOOKUP("U_CA":U,"{&PA-OPTIONEN}":U) > 0 &THEN
  define variable giuTransportTime      like V_BelegKopf.Transportzeit       no-undo.
  define variable gcuTransportTimeUnit  like V_BelegKopf.Zeiteinheit         no-undo.
  define variable giuPickTime           like V_BelegKopf.uCI_KommZeit        no-undo.
  define variable gcuPickTimeUnit       like V_BelegKopf.uCI_KommZeiteinheit no-undo.
&ENDIF

define variable glToRecalculateQty     as logical          no-undo.

/* Buffers -------------------------------------------------------------------*/

define buffer S_Artikel       for S_Artikel.

define buffer BufF_V_BelegPos for V_BelegPos. /* code checked by sy 26.05.2011 used in v__ecaf0.if */

&IF LOOKUP("U_CI":U,"{&PA-OPTIONEN}":U) > 0 &THEN
  define buffer gbuS_VersandArt for S_VersandArt.
&ENDIF
&IF LOOKUP("U_CA":U,"{&PA-OPTIONEN}":U) > 0 &THEN
  define buffer gbuV_BelegKopfAdr for V_BelegKopfAdr.
&ENDIF

{&{&PA-XBasisName}_C_Buffer}
{&{&PA-XBasisName}_U_Buffer}
{&{&PA-XBasisName}_Q_Buffer}
{&{&PA-XBasisName}_Buffer}
{&{&PA-XBasisName}_Y_Buffer}

/* _UIB-CODE-BLOCK-END */
&ANALYZE-RESUME


&ANALYZE-SUSPEND _UIB-PREPROCESSOR-BLOCK 

/* ********************  Preprocessor Definitions  ******************** */

&Scoped-define PROCEDURE-TYPE SmartViewer
&Scoped-define DB-AWARE no

&Scoped-define LAYOUT-VARIABLE CURRENT-WINDOW-layout

&Scoped-define ADM-SUPPORTED-LINKS Record-Source,Record-Target,TableIO-Target

/* Name of designated FRAME-NAME and/or first browse and/or first query */
&Scoped-define FRAME-NAME F-Main

/* External Tables                                                      */
&Scoped-define EXTERNAL-TABLES V_BelegKopf V_BelegPos
&Scoped-define FIRST-EXTERNAL-TABLE V_BelegKopf


/* Need to scope the external tables to this procedure                  */
define query external_tables for V_BelegKopf, V_BelegPos.
/* Standard List Definitions                                            */
&Scoped-Define ENABLED-FIELDS V_BelegPos.LagerOrt V_BelegPos.Abladestelle ~
V_BelegPos.MMM_CusRefOrder_ID V_BelegPos.LieferBedingung V_BelegPos.Gewicht ~
V_BelegPos.GewichtVerp V_BelegPos.Wunschtermin V_BelegPos.Liefertermin ~
V_BelegPos.Lieferzeit V_BelegPos.Transportzeit V_BelegPos.uCI_KommZeit ~
V_BelegPos.uCI_KommZeiteinheit V_BelegPos.uCI_Versandart ~
V_BelegPos.Lieferzeit_Einheit V_BelegPos.Ursprungszeugnis ~
V_BelegPos.Wareneinsatz V_BelegPos.Einzelpreis V_BelegPos.Wert_RZ_1 ~
V_BelegPos.Wert_RZ_Art_1 V_BelegPos.Wert_RZ_2 V_BelegPos.Wert_RZ_Art_2 ~
V_BelegPos.proz_RZ_1 V_BelegPos.proz_RZ_Art_1 V_BelegPos.proz_RZ_2 ~
V_BelegPos.proz_RZ_Art_2 V_BelegPos.proz_RZ_3 V_BelegPos.proz_RZ_Art_3 ~
V_BelegPos.Bezeichnung[1] V_BelegPos.Bezeichnung[2] ~
V_BelegPos.Bezeichnung[3] V_BelegPos.Bezeichnung[4] ~
V_BelegPos.USTax_TaxFree V_BelegPos.USTax_Override V_BelegPos.Wert_RZ_5 
&Scoped-define ENABLED-TABLES V_BelegPos
&Scoped-define FIRST-ENABLED-TABLE V_BelegPos
&Scoped-Define DISPLAYED-FIELDS S_ArtikelSpr.Bezeichnung[1] ~
S_ArtikelSpr.Bezeichnung[2] S_ArtikelSpr.Bezeichnung[3] ~
S_ArtikelSpr.Bezeichnung[4] V_BelegPos.LagerOrt V_BelegPos.Abladestelle ~
V_BelegPos.MMM_CusRefOrder_ID V_BelegPos.LieferBedingung V_BelegPos.Gewicht ~
V_BelegPos.GewichtVerp V_BelegPos.Wunschtermin V_BelegPos.Liefertermin ~
V_BelegPos.Lieferzeit V_BelegPos.Transportzeit V_BelegPos.uCI_KommZeit ~
V_BelegPos.uCI_KommZeiteinheit V_BelegPos.uCI_Warenausgangstermin ~
V_BelegPos.uCI_Versandart V_BelegPos.uCW_Tour V_BelegPos.uCW_TransportNr ~
V_BelegPos.IncoTerm V_BelegPos.Lieferzeit_Einheit V_BelegPos.Zeiteinheit ~
V_BelegPos.Versandtermin V_BelegPos.Ursprungszeugnis ~
V_BelegPos.Wareneinsatz V_BelegPos.Einzelpreis V_BelegPos.Wert_RZ_1 ~
V_BelegPos.Wert_RZ_Art_1 V_BelegPos.Wert_RZ_2 V_BelegPos.Wert_RZ_Art_2 ~
V_BelegPos.proz_RZ_1 V_BelegPos.proz_RZ_Art_1 V_BelegPos.proz_RZ_2 ~
V_BelegPos.proz_RZ_Art_2 V_BelegPos.proz_RZ_3 V_BelegPos.proz_RZ_Art_3 ~
V_BelegPos.Bezeichnung[1] V_BelegPos.Bezeichnung[2] ~
V_BelegPos.Bezeichnung[3] V_BelegPos.Bezeichnung[4] ~
V_BelegPos.USTax_TaxFree V_BelegPos.USTax_Override V_BelegPos.Wert_RZ_5 ~
V_BelegPos.uCE_ReferenceDocItemPos V_BelegPos.uCI_Lot ~
V_BelegPos.Metalsurcharge 
&Scoped-define DISPLAYED-TABLES S_ArtikelSpr V_BelegPos
&Scoped-define FIRST-DISPLAYED-TABLE S_ArtikelSpr
&Scoped-define SECOND-DISPLAYED-TABLE V_BelegPos
&Scoped-Define DISPLAYED-OBJECTS V_BeleI_Warenausgangstermin_Info gdTaxSum ~
d_Menge c_text-VME gdAkzeptierte_Menge d_geliefert d_beauftragt ~
d_Mindestmenge d_Storno d_reserviert giKO_LagerOrt gcTimeUnitCombo ~
V_BelegPos_uCI_Versandart_Info gtuAbfahrtsdatum gtuAbfahrtsdatum_Info ~
gcuAbfahrtszeit V_BelegPos_LieferBedingung_Info gcCROInfo ~
V_BelegPos_Wunschtermin_Info V_BelegPos_Liefertermin_Info c_Mengeneinheit-1 ~
c_Mengeneinheit-2 c_Mengeneinheit-4 c_Mengeneinheit-5 c_Mengeneinheit-3 ~
c_text-1 c_text-14 c_Gew-Mengeneinheit gcPartTypeDesc ~
V_BelegPos_Versandtermin_Info gcZollNummer d_Verkaufspreis c_Rabatt-1 ~
c_Rabatt-2 c_Rabatt-3 d_Gesamtpreis gcEAN gcPriceUnitDesc c_wBez-1 c_LME ~
V_BelegPos_Steuer_Bez gdSteuersatz c_Preisherkunft-1 c_Preisherkunft-5 ~
c_Preisherkunft-6 c_Preisherkunft-2 c_Preisherkunft-3 c_Preisherkunft-4 ~
gcFEcoTaxOrigin gc_Preisbezug-Rabattart-1 gc_Preisbezug-Rabattart-2 

/* Custom List Definitions                                              */
/* PA-CREATE-FIELDS,ADM-ASSIGN-FIELDS,PA-PROTECTED-FIELDS,PA-UPDATE-VARS,PA-PROMPT-FIELDS,PA-SEARCH-FIELDS */
&Scoped-define PA-UPDATE-VARS btnTax btnVME d_Menge gdAkzeptierte_Menge ~
d_geliefert d_Mindestmenge d_reserviert gcTimeUnitCombo gcZollNummer gcEAN ~
V_BelegPos_Steuer_Bez gdSteuersatz 

/* _UIB-PREPROCESSOR-BLOCK-END */
&ANALYZE-RESUME


&ANALYZE-SUSPEND _UIB-CODE-BLOCK _XFTR "Konfiguration" V-table-Win _INLINE
/* Actions: ? adm/support/proc/ds_viw06.w ? ? ? */

/* _UIB-CODE-BLOCK-END */
&ANALYZE-RESUME

&ANALYZE-SUSPEND _UIB-CODE-BLOCK _XFTR "InfoFields" V-table-Win _INLINE
/* Actions: ? adm/support/proc/ds_sma00.w ? ? adm/support/proc/ds_inf01.p */
/* STRUCTURED-DATA
<Build-Information>
1.02
</Build-Information>
<Constants>
***/
/***
</Constants>
<InfoFields>
V_BelegPos.LieferBedingung|Text|basis.S_LieferBedSpr.Bezeichnung|S_LieferBedSpr.Firma = {firma/sliefbed.fir pa-Firma};S_LieferBedSpr.LieferBedingung = input frame {&Frame-Name} V_BelegPos.LieferBedingung|V_BelegPos_LieferBedingung_Info
V_BelegPos.Wunschtermin|day|||V_BelegPos_Wunschtermin_Info
V_BelegPos.Liefertermin|day|||V_BelegPos_Liefertermin_Info
V_BelegPos.Versandtermin|day|||V_BelegPos_Versandtermin_Info
gtuAbfahrtsdatum|day|||gtuAbfahrtsdatum_Info
V_BelegPos.uCI_VersandArt|Text|basis.S_VersandArtSpr.Bezeichnung|S_VersandArtSpr.Firma = {firma/sversart.fir pa-Firma};S_VersandArtSpr.VersandArt = input frame {&Frame-Name} V_BelegPos.uCI_VersandArt|V_BelegPos_uCI_VersandArt_Info
V_BelegPos.uCI_Warenausgangstermin|day|||V_BeleI_Warenausgangstermin_Info
</InfoFields>*/
/* _UIB-CODE-BLOCK-END */
&ANALYZE-RESUME

&ANALYZE-SUSPEND _UIB-CODE-BLOCK _XFTR "Dynamic InfoFields" V-table-Win _INLINE
/* Actions: ? ? ? ? adm/support/proc/ds_viw09.p */

&SCOPED-DEFINE pa-UpdateHiddenScreenvalues ~
  assign~
    V_BelegPos.uCI_KommZeiteinheit:screen-value in frame {&FRAME-NAME} = (if available V_BelegPos then string(V_BelegPos.uCI_KommZeiteinheit, '9':U) else '':U)~
    V_BelegPos.Zeiteinheit:screen-value in frame {&FRAME-NAME} = (if available V_BelegPos then string(V_BelegPos.Zeiteinheit, '9':U) else '':U)~
    .
/* _UIB-CODE-BLOCK-END */
&ANALYZE-RESUME

&ANALYZE-SUSPEND _UIB-CODE-BLOCK _XFTR "Update Support" V-table-Win _INLINE
/* Actions: ? adm/support/proc/ds_sma00.w ? ? adm/support/proc/ds_viw00.p */
/* STRUCTURED-DATA
<ADDITIONAL-INFORMATION EDITABLE></ADDITIONAL-INFORMATION EDITABLE>

<CONSTANTS>
*****/
&SCOP ENABLED-TABLES V_BelegPos
&SCOP FIRST-ENABLED-TABLE V_BelegPos
&SCOP PA-FIRST-INITIAL-VALUES~
  V_BelegPos.Firma = ~{firma/vbelegko.fir pa-Firma}~
  V_BelegPos.BelegArt = V_BelegKopf.BelegArt~
  V_BelegPos.ReferenzNr = V_BelegKopf.ReferenzNr~
  V_BelegPos.LfdNr_SR = integer(entry( 1,pa-external-keys,~{&pa-EOL}))~
  V_BelegPos.PositionsNr = decimal(entry( 2,pa-external-keys,~{&pa-EOL}))
&SCOP PA-EXTERNAL-KEYS LfdNr_SR,PositionsNr
&SCOP PA-FIRST-COMPARE~
  V_BelegPos.Firma = ~{firma/vbelegko.fir pa-Firma}~
  and V_BelegPos.BelegArt = V_BelegKopf.BelegArt~
  and V_BelegPos.ReferenzNr = V_BelegKopf.ReferenzNr~
  and V_BelegPos.LfdNr_SR = integer(entry( 1,pa-external-keys,~{&pa-EOL}))~
  and V_BelegPos.PositionsNr = decimal(entry( 2,pa-external-keys,~{&pa-EOL}))
&SCOP PA-FIRST-EXCEPT-FIELDS {&PA-FIRST-EXCEPT-FIELDS} Firma BelegArt ReferenzNr LfdNr_SR PositionsNr AnlageBenutzer AnlageDatum AnlageZeit AenderungBenutzer AenderungDatum AenderungZeit V_BelegPos_Obj

/*****
</CONSTANTS> */
/* _UIB-CODE-BLOCK-END */
&ANALYZE-RESUME

&ANALYZE-SUSPEND _UIB-CODE-BLOCK _XFTR "Search Support" V-table-Win _INLINE
/* Actions: ? adm/support/proc/ds_sma00.w ? ? adm/support/proc/ds_viw03.p */
/* STRUCTURED-DATA
<BUILD-INFORMATION>
1.09
</BUILD-INFORMATION>
<STATEMENTS>
*****/

&SCOP PA-FIELDS-ENABLE-STATEMENT~
  enable unless-hidden~
    V_BelegPos.LagerOrt~
      when not can-do(pa-disabled-fields,'V_BelegPos.LagerOrt':U)~
    V_BelegPos.Abladestelle~
      when not can-do(pa-disabled-fields,'V_BelegPos.Abladestelle':U)~
    V_BelegPos.MMM_CusRefOrder_ID~
      when not can-do(pa-disabled-fields,'V_BelegPos.MMM_CusRefOrder_ID':U)~
    V_BelegPos.LieferBedingung~
      when not can-do(pa-disabled-fields,'V_BelegPos.LieferBedingung':U)~
    V_BelegPos.Gewicht~
      when not can-do(pa-disabled-fields,'V_BelegPos.Gewicht':U)~
    V_BelegPos.GewichtVerp~
      when not can-do(pa-disabled-fields,'V_BelegPos.GewichtVerp':U)~
    V_BelegPos.Wunschtermin~
      when not can-do(pa-disabled-fields,'V_BelegPos.Wunschtermin':U)~
    V_BelegPos.Liefertermin~
      when not can-do(pa-disabled-fields,'V_BelegPos.Liefertermin':U)~
    V_BelegPos.Lieferzeit~
      when not can-do(pa-disabled-fields,'V_BelegPos.Lieferzeit':U)~
    V_BelegPos.Transportzeit~
      when not can-do(pa-disabled-fields,'V_BelegPos.Transportzeit':U)~
    V_BelegPos.uCI_KommZeit~
      when not can-do(pa-disabled-fields,'V_BelegPos.uCI_KommZeit':U)~
    V_BelegPos.uCI_KommZeiteinheit~
      when not can-do(pa-disabled-fields,'V_BelegPos.uCI_KommZeiteinheit':U)~
    V_BelegPos.uCI_Versandart~
      when not can-do(pa-disabled-fields,'V_BelegPos.uCI_Versandart':U)~
    V_BelegPos.Lieferzeit_Einheit~
      when not can-do(pa-disabled-fields,'V_BelegPos.Lieferzeit_Einheit':U)~
    V_BelegPos.Ursprungszeugnis~
      when not can-do(pa-disabled-fields,'V_BelegPos.Ursprungszeugnis':U)~
    V_BelegPos.Wareneinsatz~
      when not can-do(pa-disabled-fields,'V_BelegPos.Wareneinsatz':U)~
    V_BelegPos.Einzelpreis~
      when not can-do(pa-disabled-fields,'V_BelegPos.Einzelpreis':U)~
    V_BelegPos.Wert_RZ_1~
      when not can-do(pa-disabled-fields,'V_BelegPos.Wert_RZ_1':U)~
    V_BelegPos.Wert_RZ_Art_1~
      when not can-do(pa-disabled-fields,'V_BelegPos.Wert_RZ_Art_1':U)~
    V_BelegPos.Wert_RZ_2~
      when not can-do(pa-disabled-fields,'V_BelegPos.Wert_RZ_2':U)~
    V_BelegPos.Wert_RZ_Art_2~
      when not can-do(pa-disabled-fields,'V_BelegPos.Wert_RZ_Art_2':U)~
    V_BelegPos.proz_RZ_1~
      when not can-do(pa-disabled-fields,'V_BelegPos.proz_RZ_1':U)~
    V_BelegPos.proz_RZ_Art_1~
      when not can-do(pa-disabled-fields,'V_BelegPos.proz_RZ_Art_1':U)~
    V_BelegPos.proz_RZ_2~
      when not can-do(pa-disabled-fields,'V_BelegPos.proz_RZ_2':U)~
    V_BelegPos.proz_RZ_Art_2~
      when not can-do(pa-disabled-fields,'V_BelegPos.proz_RZ_Art_2':U)~
    V_BelegPos.proz_RZ_3~
      when not can-do(pa-disabled-fields,'V_BelegPos.proz_RZ_3':U)~
    V_BelegPos.proz_RZ_Art_3~
      when not can-do(pa-disabled-fields,'V_BelegPos.proz_RZ_Art_3':U)~
    V_BelegPos.Bezeichnung[1]~
      when not can-do(pa-disabled-fields,'V_BelegPos.Bezeichnung':U)~
    V_BelegPos.Bezeichnung[2]~
      when not can-do(pa-disabled-fields,'V_BelegPos.Bezeichnung':U)~
    V_BelegPos.Bezeichnung[3]~
      when not can-do(pa-disabled-fields,'V_BelegPos.Bezeichnung':U)~
    V_BelegPos.Bezeichnung[4]~
      when not can-do(pa-disabled-fields,'V_BelegPos.Bezeichnung':U)~
    V_BelegPos.USTax_TaxFree~
      when not can-do(pa-disabled-fields,'V_BelegPos.USTax_TaxFree':U)~
    V_BelegPos.USTax_Override~
      when not can-do(pa-disabled-fields,'V_BelegPos.USTax_Override':U)~
    V_BelegPos.Wert_RZ_5~
      when not can-do(pa-disabled-fields,'V_BelegPos.Wert_RZ_5':U)~
    btnTax~
      when not can-do(pa-disabled-fields,'v_wbel33_w.btnTax':U)~
    btnVME~
      when not can-do(pa-disabled-fields,'v_wbel33_w.btnVME':U)~
    d_Menge~
      when not can-do(pa-disabled-fields,'v_wbel33_w.d_Menge':U)~
    gdAkzeptierte_Menge~
      when not can-do(pa-disabled-fields,'v_wbel33_w.gdAkzeptierte_Menge':U)~
    d_geliefert~
      when not can-do(pa-disabled-fields,'v_wbel33_w.d_geliefert':U)~
    d_Mindestmenge~
      when not can-do(pa-disabled-fields,'v_wbel33_w.d_Mindestmenge':U)~
    d_reserviert~
      when not can-do(pa-disabled-fields,'v_wbel33_w.d_reserviert':U)~
    gcTimeUnitCombo~
      when not can-do(pa-disabled-fields,'v_wbel33_w.gcTimeUnitCombo':U)~
    gcZollNummer~
      when not can-do(pa-disabled-fields,'v_wbel33_w.gcZollNummer':U)~
    gcEAN~
      when not can-do(pa-disabled-fields,'v_wbel33_w.gcEAN':U)~
    V_BelegPos_Steuer_Bez~
      when not can-do(pa-disabled-fields,'v_wbel33_w.V_BelegPos_Steuer_Bez':U)~
    gdSteuersatz~
      when not can-do(pa-disabled-fields,'v_wbel33_w.gdSteuersatz':U)~
    with frame {&Frame-Name}.
&SCOP PA-FIELDS-DISABLE-STATEMENT~
  disable unless-hidden~
    V_BelegPos.LagerOrt~
    V_BelegPos.Abladestelle~
    V_BelegPos.MMM_CusRefOrder_ID~
    V_BelegPos.LieferBedingung~
    V_BelegPos.Gewicht~
    V_BelegPos.GewichtVerp~
    V_BelegPos.Wunschtermin~
    V_BelegPos.Liefertermin~
    V_BelegPos.Lieferzeit~
    V_BelegPos.Transportzeit~
    V_BelegPos.uCI_KommZeit~
    V_BelegPos.uCI_KommZeiteinheit~
    V_BelegPos.uCI_Versandart~
    V_BelegPos.Lieferzeit_Einheit~
    V_BelegPos.Ursprungszeugnis~
    V_BelegPos.Wareneinsatz~
    V_BelegPos.Einzelpreis~
    V_BelegPos.Wert_RZ_1~
    V_BelegPos.Wert_RZ_Art_1~
    V_BelegPos.Wert_RZ_2~
    V_BelegPos.Wert_RZ_Art_2~
    V_BelegPos.proz_RZ_1~
    V_BelegPos.proz_RZ_Art_1~
    V_BelegPos.proz_RZ_2~
    V_BelegPos.proz_RZ_Art_2~
    V_BelegPos.proz_RZ_3~
    V_BelegPos.proz_RZ_Art_3~
    V_BelegPos.Bezeichnung[1]~
    V_BelegPos.Bezeichnung[2]~
    V_BelegPos.Bezeichnung[3]~
    V_BelegPos.Bezeichnung[4]~
    V_BelegPos.USTax_TaxFree~
    V_BelegPos.USTax_Override~
    V_BelegPos.Wert_RZ_5~
    btnTax~
    btnVME~
    d_Menge~
    gdAkzeptierte_Menge~
    d_geliefert~
    d_Mindestmenge~
    d_reserviert~
    gcTimeUnitCombo~
    gcZollNummer~
    gcEAN~
    V_BelegPos_Steuer_Bez~
    gdSteuersatz~
    with frame {&Frame-Name}.
/*****
</STATEMENTS> */
/* _UIB-CODE-BLOCK-END */
&ANALYZE-RESUME

&ANALYZE-SUSPEND _UIB-CODE-BLOCK _XFTR "Foreign Keys" V-table-Win _INLINE
/* Actions: ? adm/support/proc/keyedit.w ? ? ? */
/* STRUCTURED-DATA
<KEY-OBJECT>
THIS-PROCEDURE
</KEY-OBJECT>
<FOREIGN-KEYS>
RueckmeldeNr||y|giRueckmeldeNr||||||
Lagergruppe||y|giLagergruppe||||||
BelegArt||y|mawi.V_BelegKopf.BelegArt||||||
Coverage_MRPDocType||y|mawi.V_BelegKopf.BelegArt||||||
ReferenzNr||y|mawi.V_BelegKopf.ReferenzNr||||||
LfdNr_SR||y|Mawi.V_BelegPos.LfdNr_SR||||||
PositionsNr||y|Mawi.V_BelegPos.PositionsNr||||||
PosObj||y|basis.V_BelegPos.V_BelegPos_Obj||||||
Artikel||y|Mawi.V_BelegPos.Artikel||||||
ArtVar||y|Mawi.V_BelegPos.ArtVar||||||
Menge||y|input frame {&frame-name} d_Menge||||||
Position||y|V_BelegPos.PositionsNr||||||
SetPosition||y|0||||||
Coverage_Obj||y|V_BelegPos.V_BelegPos_Obj|||||
V_BelegKopf_Obj||y|mawi.V_BelegKopf.V_BelegKopf_Obj||||||
Origin_Obj||y|mawi.V_BelegKopf.Origin_Obj||||||
JBT_Project_Obj||y|mawi.V_BelegKopf.JBT_Project_Obj||||||
SBM_BankDataAcc_Obj||y|mawi.V_BelegKopf.SBM_BankDataAcc_Obj||||||
V_BelegPos_Obj||y|Mawi.V_BelegPos.V_BelegPos_Obj||||||
Origin_Obj||y|mawi.V_BelegKopf.Origin_Obj||||||
Origin_Obj||y|Mawi.V_BelegPos.Origin_Obj||||||
PosObj||y|basis.V_BelegPos.V_BelegPos_Obj||||||
Owning_Obj||y|basis.DBM_ShortDescription.Owning_Obj||||||
MMM_CusRefOrder_Obj||y|mawi.V_BelegKopf.MMM_CusRefOrder_Obj||||||
MMM_CusRefOrder_Obj||y|Mawi.V_BelegPos.MMM_CusRefOrder_Obj||||||
Driver_Obj||y|mawi.V_BelegKopf.Driver_Obj||||||
SBM_BusinessCategory_Obj||y|mawi.V_BelegKopf.SBM_BusinessCategory_Obj||||||
SBM_ProfitCenter_Obj||y|mawi.V_BelegKopf.SBM_ProfitCenter_Obj||||||
SBM_FiscalText_Obj||y|mawi.V_BelegKopf.SBM_FiscalText_Obj||||||
SBM_TaxCase_Obj||y|mawi.V_BelegKopf.SBM_TaxCase_Obj||||||
S_Steuer_Obj||y|mawi.V_BelegKopf.S_Steuer_Obj||||||
S_Steuer_Obj||y|Mawi.V_BelegPos.S_Steuer_Obj||||||
Driver_Obj||y|Mawi.V_BelegPos.Driver_Obj||||||
SBM_BusinessCategory_Obj||y|Mawi.V_BelegPos.SBM_BusinessCategory_Obj||||||
SBM_CustomsTariffNo_Obj||y|Mawi.V_BelegPos.SBM_CustomsTariffNo_Obj||||||
Sys_S_Steuer_Obj||y|Mawi.V_BelegPos.Sys_S_Steuer_Obj||||||
S_F_Journal_Obj||y|mawi.V_BelegKopf.S_F_Journal_Obj||||||
uCM_PP_StkZeile_Obj||y|Mawi.V_BelegPos.uCM_PP_StkZeile_Obj||||||
S_I_TaxExemption_Obj||y|mawi.V_BelegKopf.S_I_TaxExemption_Obj||||||
S_BankVerb_Obj||y|mawi.V_BelegKopf.S_BankVerb_Obj||||||
MMT_Picking_Obj||y|Mawi.V_BelegPos.MMT_Picking_Obj||||||
JBT_PartsPlan_Obj||y|Mawi.V_BelegPos.JBT_PartsPlan_Obj||||||
VBM_PreConfigVariant_Obj||y|mawi.V_BelegKopf.VBM_PreConfigVariant_Obj||||||
</FOREIGN-KEYS>
<EXECUTING-CODE>
**************************
* Set attributes related to FOREIGN KEYS
*/
run set-attribute-list (
    'Keys-Accepted = ,
     Keys-External = ,
     Keys-Supplied = "RueckmeldeNr,Lagergruppe,BelegArt,Coverage_MRPDocType,ReferenzNr,LfdNr_SR,PositionsNr,PosObj,Artikel,ArtVar,Menge,Position,SetPosition,Coverage_Obj,V_BelegKopf_Obj,JBT_Project_Obj,SBM_BankDataAcc_Obj,V_BelegPos_Obj,Origin_Obj,Origin_Obj,Owning_Obj,MMM_CusRefOrder_Obj,MMM_CusRefOrder_Obj,Driver_Obj,SBM_BusinessCategory_Obj,SBM_ProfitCenter_Obj,SBM_FiscalText_Obj,SBM_TaxCase_Obj,S_Steuer_Obj,S_Steuer_Obj,Driver_Obj,SBM_BusinessCategory_Obj,SBM_CustomsTariffNo_Obj,Sys_S_Steuer_Obj,S_F_Journal_Obj,uCM_PP_StkZeile_Obj,S_I_TaxExemption_Obj,S_BankVerb_Obj,MMT_Picking_Obj,JBT_PartsPlan_Obj,VBM_PreConfigVariant_Obj"':U).
/**************************
</EXECUTING-CODE> */
/* _UIB-CODE-BLOCK-END */
&ANALYZE-RESUME

&ANALYZE-SUSPEND _UIB-CODE-BLOCK _XFTR "InfoTables" V-table-Win _INLINE
/* Actions: ? adm/support/proc/ds_sma00.w ? ? adm/support/proc/ds_tbl01.p */
/* STRUCTURED-DATA
<CONSTANTS></CONSTANTS>
<BUILD-INFORMATION>
1.01
</BUILD-INFORMATION>
<TABLES></TABLES>
<ADDITIONAL-INFORMATION EDITABLE></ADDITIONAL-INFORMATION EDITABLE> */

/* _UIB-CODE-BLOCK-END */
&ANALYZE-RESUME

&ANALYZE-SUSPEND _UIB-CODE-BLOCK _XFTR "Window Title" V-table-Win _INLINE
/* Actions: ? adm/support/proc/ds_sma00.w ? ? adm/support/proc/ds_ttl00.p */
/* STRUCTURED-DATA
<TITLE-CODE EDITABLE>
</TITLE-CODE EDITABLE>
<CONSTANTS></CONSTANTS>  */
/* _UIB-CODE-BLOCK-END */
&ANALYZE-RESUME

&ANALYZE-SUSPEND _UIB-CODE-BLOCK _XFTR "Skin Client Support" V-table-Win _INLINE
/* Actions: ? ? ? ? adm/support/proc/ds_skc00.p */

&SCOPED-DEFINE pa-DisplaySkinClientWidgets ~
  if not gcTimeUnitCombo:hidden in frame ~{&FRAME-NAME~} then dynamic-function('pa_cUISvcSetWidgetAttribute':U in target-procedure, gcTimeUnitCombo:handle, 'screen-value':U, gcTimeUnitCombo). ~
  if not V_BelegPos_Steuer_Bez:hidden in frame ~{&FRAME-NAME~} then dynamic-function('pa_cUISvcSetWidgetAttribute':U in target-procedure, V_BelegPos_Steuer_Bez:handle, 'screen-value':U, V_BelegPos_Steuer_Bez).
/* _UIB-CODE-BLOCK-END */
&ANALYZE-RESUME

/* ************************  Function Prototypes ********************** */



&ANALYZE-SUSPEND _UIB-CODE-BLOCK _FUNCTION-FORWARD cUCIKommZeiteinheit V-table-Win
function cUCIKommZeiteinheit returns character 
  (  ) forward.

/* _UIB-CODE-BLOCK-END */
&ANALYZE-RESUME



&ANALYZE-SUSPEND _UIB-CODE-BLOCK _FUNCTION-FORWARD iUCIKommZeit V-table-Win
function iUCIKommZeit returns integer 
  (  ) forward.

/* _UIB-CODE-BLOCK-END */
&ANALYZE-RESUME



&ANALYZE-SUSPEND _UIB-CODE-BLOCK _FUNCTION-FORWARD pa_lUISvcACMReplacementUpdate V-table-Win 
function pa_lUISvcACMReplacementUpdate returns logical
  ( phFrame as handle ) forward.

/* _UIB-CODE-BLOCK-END */
&ANALYZE-RESUME

&ANALYZE-SUSPEND _UIB-CODE-BLOCK _FUNCTION-FORWARD pa_lUISvcObjectState V-table-Win 
function pa_lUISvcObjectState returns logical
  ( pcStateCode as character )  forward.

/* _UIB-CODE-BLOCK-END */
&ANALYZE-RESUME

&ANALYZE-SUSPEND _UIB-CODE-BLOCK _FUNCTION-FORWARD uUpdateDateFields V-table-Win 
function uUpdateDateFields returns logical
  ( phField as handle ) forward.

/* _UIB-CODE-BLOCK-END */
&ANALYZE-RESUME


/* Define a variable to store the name of the active layout.            */
define variable CURRENT-WINDOW-layout as char initial "Master Layout":U no-undo.

/* ***********************  Control Definitions  ********************** */


/* Definitions of the field level widgets                               */
define button btnTax  no-focus flat-button
     label "" 
     size 4 by 1.

define button btnVME  no-focus flat-button
     label "" 
     size 4 by 1.

define variable gcTimeUnitCombo as character format "x(256)":U 
     view-as combo-box inner-lines 5
     list-item-pairs "Item 1","Item 1"
     drop-down-list
     size 12 by 1 no-undo.

define variable V_BelegPos_Steuer_Bez as character format "X(256)":U 
     label "Steuersatz":R18 
     view-as combo-box inner-lines 5
     list-items "Item 1" 
     drop-down-list
     size 25 by 1 no-undo.

define variable c_Gew-Mengeneinheit as character format "X(256)":U 
     view-as fill-in 
     size 8 by 1 no-undo.

define variable c_LME as character format "X(256)":U 
     view-as fill-in 
     size 6 by 1 tooltip "Mengeneinheit auf die sich der Einzelpreis bezieht":T60 no-undo.

define variable c_Mengeneinheit-1 as character format "X(6)":U 
     view-as fill-in 
     size 8 by 1 no-undo.

define variable c_Mengeneinheit-2 as character format "X(256)":U 
     view-as fill-in 
     size 8 by 1 no-undo.

define variable c_Mengeneinheit-3 as character format "X(256)":U 
     view-as fill-in 
     size 8 by 1 no-undo.

define variable c_Mengeneinheit-4 as character format "X(6)":U 
     view-as fill-in 
     size 8 by 1 no-undo.

define variable c_Mengeneinheit-5 as character format "X(6)":U 
     view-as fill-in 
     size 8 by 1 no-undo.

define variable c_Preisherkunft-1 as character format "x(1)":U 
     view-as fill-in 
     size 3 by 1 tooltip "Preisfindungskennzeichen":T60 no-undo.

define variable c_Preisherkunft-2 as character format "x(1)":U 
     view-as fill-in 
     size 3 by 1 tooltip "Preisfindungskennzeichen":T60 no-undo.

define variable c_Preisherkunft-3 as character format "x(1)":U 
     view-as fill-in 
     size 3 by 1 tooltip "Preisfindungskennzeichen":T60 no-undo.

define variable c_Preisherkunft-4 as character format "x(1)":U 
     view-as fill-in 
     size 3 by 1 tooltip "Preisfindungskennzeichen":T60 no-undo.

define variable c_Preisherkunft-5 as character format "x(1)":U 
     view-as fill-in 
     size 3 by 1 tooltip "Preisfindungskennzeichen":T60 no-undo.

define variable c_Preisherkunft-6 as character format "x(1)":U 
     view-as fill-in 
     size 3 by 1 tooltip "Preisfindungskennzeichen":T60 no-undo.

define variable c_Rabatt-1 as character format "X(1)":U 
     view-as fill-in 
     size .33 by 1 no-undo.

define variable c_Rabatt-2 as character format "X(1)":U 
     view-as fill-in 
     size .33 by 1 no-undo.

define variable c_Rabatt-3 as character format "X(1)":U 
     view-as fill-in 
     size .33 by 1 no-undo.

define variable c_text-1 as character format "X(256)":U 
     view-as fill-in 
     size 4 by 1 no-undo.

define variable c_text-14 as character format "X(256)":U 
     view-as fill-in 
     size 4 by 1 no-undo.

define variable c_text-VME as character format "X(256)":U 
     view-as fill-in 
     size 8 by 1 no-undo.

define variable c_wBez-1 as character format "X(256)":U 
     view-as fill-in 
     size 12 by 1 tooltip "W�hrung des Beleges":T60 no-undo.

define variable d_beauftragt as decimal format "zzzz,zz9.999-":U initial 0 
     label "beauftragte Menge":R18 
     view-as fill-in 
     size 16 by 1 no-undo.

define variable d_geliefert as decimal format "zzzz,zz9.999-":U initial 0 
     label "gelieferte Menge":R18 
     view-as fill-in 
     size 16 by 1 no-undo.

define variable d_Gesamtpreis as decimal format "zzz,zzz,zz9.99-":U initial 0 
     label "Gesamtpreis":R18 
     view-as fill-in 
     size 20 by 1 no-undo.

define variable d_Menge as decimal format "zzzz,zz9.999-":U initial 0 
     label "Menge":R18 
     view-as fill-in 
     size 16 by 1 no-undo.

define variable d_Mindestmenge as decimal format "zzzz,zz9.999-":U initial 0 
     label "Mindestmenge":R18 
     view-as fill-in 
     size 16 by 1 no-undo.

define variable d_reserviert as decimal format "zzzz,zz9.999-":U initial 0 
     label "reservierte Menge":R18 
     view-as fill-in 
     size 16 by 1 no-undo.

define variable d_Storno as decimal format "zzzz,zz9.999-":U initial 0 
     label "stornierte Menge":R18 
     view-as fill-in 
     size 16 by 1 no-undo.

define variable d_Verkaufspreis as decimal format "zz,zzz,zz9.99-":U initial 0 
     label "Verkaufspreis":R18 
     view-as fill-in 
     size 20 by 1 no-undo.

define variable gc_Preisbezug-Rabattart-1 as character format "X(1)":U 
     view-as fill-in 
     size 4 by 1 tooltip "Rabattbezug auf Einzel- oder Gesamtpreis":T40 no-undo.

define variable gc_Preisbezug-Rabattart-2 as character format "X(1)":U 
     view-as fill-in 
     size 4 by 1 tooltip "Rabattbezug auf Einzel- oder Gesamtpreis":T40 no-undo.

define variable gcCROInfo like DBM_ShortDescription.ShortDesc1
     view-as fill-in 
     size 16 by 1 no-undo.

define variable gcEAN as character format "X(14)":U 
     label "GTIN":R18 
     view-as fill-in 
     size 24 by 1 no-undo.

define variable gcFEcoTaxOrigin as character format "X(1)":U 
     view-as fill-in 
     size 4 by 1 no-undo.

define variable gcPartTypeDesc as character format "x(30)":U 
     view-as fill-in 
     size 20 by 1 no-undo.

define variable gcPriceUnitDesc as character format "x(3)":U 
     view-as fill-in 
     size 6 by 1 tooltip "Preiseinheit":T60 no-undo.

define variable gcuAbfahrtszeit as character format "99:99":U 
     view-as fill-in 
     size 11 by 1 no-undo.

define variable gcZollNummer as character format "x(20)":U 
     label "stat Warennummer":R18 
     view-as fill-in 
     size 16 by 1 no-undo.

define variable gdAkzeptierte_Menge as decimal format "zzzz,zz9.999-":U initial 0 
     label "akzeptierte Menge":R18 
     view-as fill-in 
     size 16 by 1 no-undo.

define variable gdSteuersatz as decimal format "z9.99%":U initial 0 
     view-as fill-in 
     size 11 by 1 no-undo.

define variable gdTaxSum as decimal format "zz,zzz,zz9.99-":U initial 0 
     label "Steuerbetrag":R18 
     view-as fill-in 
     size 20 by 1 no-undo.

define variable giKO_LagerOrt as integer format "zzzzzzz9":U initial ? 
     view-as fill-in 
     size 12 by 1 tooltip "Konsignationslager":T60 no-undo.

define variable gtuAbfahrtsdatum as date format "99.99.9999":U 
     view-as fill-in 
     size 11.5 by 1 no-undo.

define variable gtuAbfahrtsdatum_Info as character format "X(4)":U 
     view-as fill-in 
     size 4 by 1 no-undo.

define variable V_BelegPos_LieferBedingung_Info as character format "x(40)":U 
     view-as fill-in 
     size 24 by 1 no-undo.

define variable V_BelegPos_Liefertermin_Info as character format "x(256)":U 
     view-as fill-in 
     size 4 by 1 no-undo.

define variable V_BelegPos_uCI_Versandart_Info as character format "X(40)":U 
     view-as fill-in 
     size 32 by 1 no-undo.

define variable V_BelegPos_Versandtermin_Info as character format "x(3)":U 
     view-as fill-in 
     size 4 by 1 no-undo.

define variable V_BelegPos_Wunschtermin_Info as character format "x(256)":U 
     view-as fill-in 
     size 4 by 1 no-undo.

define variable V_BeleI_Warenausgangstermin_Info as character format "X(4)":U 
     view-as fill-in 
     size 4 by 1 no-undo.


/* ************************  Frame Definitions  *********************** */

define frame F-Main
     btnTax at row 19 col 104
     V_BeleI_Warenausgangstermin_Info at row 17 col 53 colon-aligned no-label
     gdTaxSum at row 19 col 81 colon-aligned
     btnVME at row 5.5 col 48
     S_ArtikelSpr.Bezeichnung[1] at row 1 col 21 colon-aligned
          label "Bezeichnung":R18
          view-as fill-in 
          size 32 by 1
     S_ArtikelSpr.Bezeichnung[2] at row 2 col 21 colon-aligned no-label
          view-as fill-in 
          size 32 by 1
     S_ArtikelSpr.Bezeichnung[3] at row 3 col 21 colon-aligned no-label
          view-as fill-in 
          size 32 by 1
     S_ArtikelSpr.Bezeichnung[4] at row 4 col 21 colon-aligned no-label
          view-as fill-in 
          size 32 by 1
     d_Menge at row 5.5 col 21 colon-aligned
     c_text-VME at row 12.5 col 41 colon-aligned no-label
     gdAkzeptierte_Menge at row 6.5 col 21 colon-aligned
     d_geliefert at row 6.5 col 21 colon-aligned
     d_beauftragt at row 7.5 col 21 colon-aligned
     d_Mindestmenge at row 7.5 col 21 colon-aligned
     d_Storno at row 7.5 col 21 colon-aligned
     d_reserviert at row 8.5 col 21 colon-aligned
     V_BelegPos.LagerOrt at row 9.5 col 21 colon-aligned
          view-as fill-in 
          size 12 by 1
     giKO_LagerOrt at row 9.5 col 34 colon-aligned no-label
     V_BelegPos.Abladestelle at row 10.5 col 21 colon-aligned
          view-as fill-in 
          size 20 by 1
     V_BelegPos.MMM_CusRefOrder_ID at row 10.5 col 21 colon-aligned
          view-as fill-in 
          size 20 by 1
     V_BelegPos.LieferBedingung at row 10.5 col 21 colon-aligned
          view-as fill-in 
          size 4 by 1
     V_BelegPos.Gewicht at row 11.5 col 21 colon-aligned
          view-as fill-in 
          size 16 by 1
     V_BelegPos.GewichtVerp at row 12.5 col 21 colon-aligned
          view-as fill-in 
          size 16 by 1
     V_BelegPos.Wunschtermin at row 14 col 21 colon-aligned
          view-as fill-in 
          size 12 by 1
     V_BelegPos.Liefertermin at row 15 col 21 colon-aligned
          view-as fill-in 
          size 12 by 1
     V_BelegPos.Lieferzeit at row 15 col 21 colon-aligned
          view-as fill-in 
          size 4 by 1
     V_BelegPos.Transportzeit at row 17 col 21 colon-aligned
          view-as fill-in 
          size 8 by 1
     gcTimeUnitCombo at row 17 col 29 colon-aligned no-label
     V_BelegPos.uCI_KommZeit at row 18 col 21 colon-aligned
          view-as fill-in 
          size 8 by 1
     V_BelegPos.uCI_KommZeiteinheit at row 18 col 29 colon-aligned no-label
          view-as fill-in 
          size 12 by 1
     V_BelegPos.uCI_Warenausgangstermin at row 17 col 41 colon-aligned no-label
          view-as fill-in 
          size 12 by 1
     V_BelegPos.uCI_Versandart at row 19 col 21 colon-aligned
          view-as fill-in 
          size 4.5 by 1
     V_BelegPos_uCI_Versandart_Info at row 19 col 25.5 colon-aligned no-label
     V_BelegPos.uCW_Tour at row 20 col 21 colon-aligned
          view-as fill-in 
          size 18 by 1
     V_BelegPos.uCW_TransportNr at row 21 col 21 colon-aligned
          view-as fill-in 
          size 10.5 by 1
     gtuAbfahrtsdatum at row 21 col 31.5 colon-aligned no-label
     gtuAbfahrtsdatum_Info at row 21 col 43 colon-aligned no-label
    with 1 down no-box keep-tab-order overlay 
         side-labels no-underline three-d 
         at column 1 row 1 scrollable .

/* DEFINE FRAME statement is approaching 4K Bytes.  Breaking it up   */
define frame F-Main
     gcuAbfahrtszeit at row 21 col 47 colon-aligned no-label
     V_BelegPos.IncoTerm at row 10.5 col 25 colon-aligned no-label
          view-as fill-in 
          size 8 by 1
     V_BelegPos.Lieferzeit_Einheit at row 15 col 25 colon-aligned no-label
          view-as fill-in 
          size 12 by 1
     V_BelegPos_LieferBedingung_Info at row 10.5 col 33 colon-aligned no-label
     gcCROInfo at row 10.5 col 41 colon-aligned help
          "" no-label
     V_BelegPos_Wunschtermin_Info at row 14 col 33 colon-aligned no-label
     V_BelegPos_Liefertermin_Info at row 15 col 33 colon-aligned no-label
     V_BelegPos.Zeiteinheit at row 17 col 29 colon-aligned no-label
          view-as fill-in 
          size 8 by 1
     c_Mengeneinheit-1 at row 5.5 col 37 colon-aligned no-label
     c_Mengeneinheit-2 at row 6.5 col 37 colon-aligned no-label
     c_Mengeneinheit-4 at row 7.5 col 37 colon-aligned no-label
     c_Mengeneinheit-5 at row 7.5 col 37 colon-aligned no-label
     c_Mengeneinheit-3 at row 8.5 col 37 colon-aligned no-label
     c_text-1 at row 11.5 col 37 colon-aligned no-label
     c_text-14 at row 12.5 col 37 colon-aligned no-label
     c_Gew-Mengeneinheit at row 11.5 col 41 colon-aligned no-label
     V_BelegPos.Versandtermin at row 18 col 41 colon-aligned no-label
          view-as fill-in 
          size 12 by 1
     gcPartTypeDesc at row 1 col 53 colon-aligned no-label
     V_BelegPos_Versandtermin_Info at row 18 col 53 colon-aligned no-label
     gcZollNummer at row 5 col 81 colon-aligned
     V_BelegPos.Ursprungszeugnis at row 5 col 100
          view-as toggle-box
          size 18 by 1
     V_BelegPos.Wareneinsatz at row 6 col 83
          view-as toggle-box
          size 20 by 1
     V_BelegPos.Einzelpreis at row 7 col 81 colon-aligned format "zz,zzz,zz9.99":U
          view-as fill-in 
          size 20 by 1
     V_BelegPos.Wert_RZ_1 at row 9 col 81 colon-aligned no-label format "zz,zzz,zz9.99-":U
          view-as fill-in 
          size 20 by 1
     V_BelegPos.Wert_RZ_Art_1 at row 9 col 101 colon-aligned no-label
          view-as fill-in 
          size 6 by 1
     V_BelegPos.Wert_RZ_2 at row 10 col 81 colon-aligned no-label format "zz,zzz,zz9.99-":U
          view-as fill-in 
          size 20 by 1
     V_BelegPos.Wert_RZ_Art_2 at row 10 col 101 colon-aligned no-label
          view-as fill-in 
          size 6 by 1
     d_Verkaufspreis at row 11 col 81 colon-aligned
     V_BelegPos.proz_RZ_1 at row 12 col 89 colon-aligned no-label
          view-as fill-in 
          size 12 by 1
     V_BelegPos.proz_RZ_Art_1 at row 12 col 101 colon-aligned no-label
          view-as fill-in 
          size 6 by 1
     V_BelegPos.proz_RZ_2 at row 13 col 89 colon-aligned no-label
          view-as fill-in 
          size 12 by 1
     V_BelegPos.proz_RZ_Art_2 at row 13 col 101 colon-aligned no-label
          view-as fill-in 
          size 6 by 1
     V_BelegPos.proz_RZ_3 at row 14 col 89 colon-aligned no-label
          view-as fill-in 
          size 12 by 1
    with 1 down no-box keep-tab-order overlay 
         side-labels no-underline three-d 
         at column 1 row 1 scrollable .

/* DEFINE FRAME statement is approaching 4K Bytes.  Breaking it up   */
define frame F-Main
     V_BelegPos.proz_RZ_Art_3 at row 14 col 101 colon-aligned no-label
          view-as fill-in 
          size 6 by 1
     c_Rabatt-1 at row 12 col 81 colon-aligned no-label
     c_Rabatt-2 at row 13 col 81 colon-aligned no-label
     c_Rabatt-3 at row 14 col 81 colon-aligned no-label
     d_Gesamtpreis at row 16 col 81 colon-aligned
     gcEAN at row 17 col 81 colon-aligned
     gcPriceUnitDesc at row 7 col 101 colon-aligned no-label
     c_wBez-1 at row 16 col 101 colon-aligned no-label
     c_LME at row 7 col 107 colon-aligned no-label
     V_BelegPos_Steuer_Bez at row 19 col 81 colon-aligned
     gdSteuersatz at row 19 col 106 colon-aligned no-label
     c_Preisherkunft-1 at row 7 col 113 colon-aligned no-label
     c_Preisherkunft-5 at row 9 col 113 colon-aligned no-label
     c_Preisherkunft-6 at row 10 col 113 colon-aligned no-label
     c_Preisherkunft-2 at row 12 col 113 colon-aligned no-label
     c_Preisherkunft-3 at row 13 col 113 colon-aligned no-label
     c_Preisherkunft-4 at row 14 col 113 colon-aligned no-label
     V_BelegPos.Bezeichnung[1] at row 1 col 81 colon-aligned no-label
          view-as fill-in 
          size 35 by 1
     V_BelegPos.Bezeichnung[2] at row 2 col 81 colon-aligned no-label
          view-as fill-in 
          size 35 by 1
     V_BelegPos.Bezeichnung[3] at row 3 col 81 colon-aligned no-label
          view-as fill-in 
          size 35 by 1
     V_BelegPos.Bezeichnung[4] at row 4 col 81 colon-aligned no-label
          view-as fill-in 
          size 35 by 1
     V_BelegPos.USTax_TaxFree at row 18 col 83
          view-as toggle-box
          size 16.33 by 1
     V_BelegPos.USTax_Override at row 19 col 83
          view-as toggle-box
          size 19.5 by .96
     gcFEcoTaxOrigin at row 8 col 113 colon-aligned no-label
     V_BelegPos.Wert_RZ_5 at row 8 col 81 colon-aligned no-label format "zz,zzz,zz9.99-":U
          view-as fill-in 
          size 20 by 1
     V_BelegPos.uCE_ReferenceDocItemPos at row 20 col 81 colon-aligned
          view-as fill-in 
          size 8 by 1
     V_BelegPos.uCI_Lot at row 22 col 21 colon-aligned
          view-as fill-in 
          size 21.67 by 1
     gc_Preisbezug-Rabattart-1 at row 9 col 109 colon-aligned no-label
     gc_Preisbezug-Rabattart-2 at row 10 col 109 colon-aligned no-label
     V_BelegPos.Metalsurcharge at row 15 col 81 colon-aligned
          view-as fill-in 
          size 20 by 1
    with 1 down no-box keep-tab-order overlay 
         side-labels no-underline three-d 
         at column 1 row 1 scrollable .


/* *********************** Procedure Settings ************************ */

&ANALYZE-SUSPEND _PROCEDURE-SETTINGS
/* Settings for THIS-PROCEDURE
   Type: SmartViewer
   External Tables: mawi.V_BelegKopf,Mawi.V_BelegPos
   Allow: Basic,DB-Fields
   Frames: 1
   Add Fields to: EXTERNAL-TABLES
   Other Settings: PERSISTENT-ONLY
   Temp-Tables and Buffers:
      TABLE: TT_MC_Lot T "?" NO-UNDO Temp-db TD_MC_Lot
   END-TABLES.
 */

/* This procedure should always be RUN PERSISTENT.  Report the error,  */
/* then cleanup and return.                                            */
if not this-procedure:persistent then do:
  message "{&FILE-NAME} should only be RUN PERSISTENT.":U
          view-as alert-box error buttons ok.
  return.
end.

&ANALYZE-RESUME _END-PROCEDURE-SETTINGS

/* *************************  Create Window  ************************** */

&ANALYZE-SUSPEND _CREATE-WINDOW
/* DESIGN Window definition (used by the UIB) 
  CREATE WINDOW V-table-Win ASSIGN
         HEIGHT             = 22
         WIDTH              = 119.83.
/* END WINDOW DEFINITION */
                                                                        */
&ANALYZE-RESUME

&ANALYZE-SUSPEND _UIB-CODE-BLOCK _CUSTOM _INCLUDED-LIB V-table-Win 
/* ************************* Included-Libraries *********************** */


{vert/incl/v__pfi00.lib}
{adm/method/incl/dm_viw01.lib}
{vert/incl/v__bel01.lib}
{vert/incl/v__bel10.lib}
{vert/auf/incl/vu_bel00.lib}
{vert/incl/v_wbel04.lib}
{vert/incl/v_wbel00.lib}
{vert/incl/v_wbel01.lib}
{vert/incl/v_wbel02.lib}
{vert/incl/v_wbel03.lib}
{vert/incl/v_wbel05.lib}
{vert/incl/v_wbel06.lib}
{vert/incl/v_wbel07.lib}
{vert/incl/v_wbel08.lib}
{vert/incl/v_wbel09.lib}

/* _UIB-CODE-BLOCK-END */
&ANALYZE-RESUME




/* ***********  Runtime Attributes and AppBuilder Settings  *********** */

&ANALYZE-SUSPEND _RUN-TIME-ATTRIBUTES
/* SETTINGS FOR WINDOW V-table-Win
  VISIBLE,,RUN-PERSISTENT                                               */
/* SETTINGS FOR FRAME F-Main
   NOT-VISIBLE FRAME-NAME Size-to-Fit Custom                            */
assign 
       frame F-Main:SCROLLABLE       = false
       frame F-Main:HIDDEN           = true.

/* SETTINGS FOR FILL-IN S_ArtikelSpr.Bezeichnung[1] IN FRAME F-Main
   NO-ENABLE EXP-LABEL                                                  */
/* SETTINGS FOR FILL-IN S_ArtikelSpr.Bezeichnung[2] IN FRAME F-Main
   NO-ENABLE                                                            */
/* SETTINGS FOR FILL-IN S_ArtikelSpr.Bezeichnung[3] IN FRAME F-Main
   NO-ENABLE                                                            */
/* SETTINGS FOR FILL-IN S_ArtikelSpr.Bezeichnung[4] IN FRAME F-Main
   NO-ENABLE                                                            */
/* SETTINGS FOR BUTTON btnTax IN FRAME F-Main
   NO-ENABLE 4                                                          */
/* SETTINGS FOR BUTTON btnVME IN FRAME F-Main
   NO-ENABLE 4                                                          */
/* SETTINGS FOR FILL-IN c_Gew-Mengeneinheit IN FRAME F-Main
   NO-ENABLE                                                            */
/* SETTINGS FOR FILL-IN c_LME IN FRAME F-Main
   NO-ENABLE                                                            */
/* SETTINGS FOR FILL-IN c_Mengeneinheit-1 IN FRAME F-Main
   NO-ENABLE                                                            */
/* SETTINGS FOR FILL-IN c_Mengeneinheit-2 IN FRAME F-Main
   NO-ENABLE                                                            */
/* SETTINGS FOR FILL-IN c_Mengeneinheit-3 IN FRAME F-Main
   NO-ENABLE                                                            */
/* SETTINGS FOR FILL-IN c_Mengeneinheit-4 IN FRAME F-Main
   NO-ENABLE                                                            */
/* SETTINGS FOR FILL-IN c_Mengeneinheit-5 IN FRAME F-Main
   NO-ENABLE                                                            */
/* SETTINGS FOR FILL-IN c_Preisherkunft-1 IN FRAME F-Main
   NO-ENABLE                                                            */
/* SETTINGS FOR FILL-IN c_Preisherkunft-2 IN FRAME F-Main
   NO-ENABLE                                                            */
/* SETTINGS FOR FILL-IN c_Preisherkunft-3 IN FRAME F-Main
   NO-ENABLE                                                            */
/* SETTINGS FOR FILL-IN c_Preisherkunft-4 IN FRAME F-Main
   NO-ENABLE                                                            */
/* SETTINGS FOR FILL-IN c_Preisherkunft-5 IN FRAME F-Main
   NO-ENABLE                                                            */
/* SETTINGS FOR FILL-IN c_Preisherkunft-6 IN FRAME F-Main
   NO-ENABLE                                                            */
/* SETTINGS FOR FILL-IN c_Rabatt-1 IN FRAME F-Main
   NO-ENABLE                                                            */
/* SETTINGS FOR FILL-IN c_Rabatt-2 IN FRAME F-Main
   NO-ENABLE                                                            */
/* SETTINGS FOR FILL-IN c_Rabatt-3 IN FRAME F-Main
   NO-ENABLE                                                            */
/* SETTINGS FOR FILL-IN c_text-1 IN FRAME F-Main
   NO-ENABLE                                                            */
/* SETTINGS FOR FILL-IN c_text-14 IN FRAME F-Main
   NO-ENABLE                                                            */
/* SETTINGS FOR FILL-IN c_text-VME IN FRAME F-Main
   NO-ENABLE                                                            */
/* SETTINGS FOR FILL-IN c_wBez-1 IN FRAME F-Main
   NO-ENABLE                                                            */
/* SETTINGS FOR FILL-IN d_beauftragt IN FRAME F-Main
   NO-ENABLE                                                            */
assign 
       d_beauftragt:HIDDEN in frame F-Main           = true.

/* SETTINGS FOR FILL-IN d_geliefert IN FRAME F-Main
   NO-ENABLE 4                                                          */
/* SETTINGS FOR FILL-IN d_Gesamtpreis IN FRAME F-Main
   NO-ENABLE                                                            */
/* SETTINGS FOR FILL-IN d_Menge IN FRAME F-Main
   NO-ENABLE 4                                                          */
/* SETTINGS FOR FILL-IN d_Mindestmenge IN FRAME F-Main
   NO-ENABLE 4                                                          */
/* SETTINGS FOR FILL-IN d_reserviert IN FRAME F-Main
   NO-ENABLE 4                                                          */
/* SETTINGS FOR FILL-IN d_Storno IN FRAME F-Main
   NO-ENABLE                                                            */
/* SETTINGS FOR FILL-IN d_Verkaufspreis IN FRAME F-Main
   NO-ENABLE                                                            */
/* SETTINGS FOR FILL-IN V_BelegPos.Einzelpreis IN FRAME F-Main
   EXP-FORMAT                                                           */
/* SETTINGS FOR FILL-IN gc_Preisbezug-Rabattart-1 IN FRAME F-Main
   NO-ENABLE                                                            */
/* SETTINGS FOR FILL-IN gc_Preisbezug-Rabattart-2 IN FRAME F-Main
   NO-ENABLE                                                            */
/* SETTINGS FOR FILL-IN gcCROInfo IN FRAME F-Main
   NO-ENABLE LIKE = basis.DBM_ShortDescription.ShortDesc1 EXP-LABEL EXP-SIZE */
/* SETTINGS FOR FILL-IN gcEAN IN FRAME F-Main
   NO-ENABLE 4                                                          */
/* SETTINGS FOR FILL-IN gcFEcoTaxOrigin IN FRAME F-Main
   NO-ENABLE                                                            */
/* SETTINGS FOR FILL-IN gcPartTypeDesc IN FRAME F-Main
   NO-ENABLE                                                            */
/* SETTINGS FOR FILL-IN gcPriceUnitDesc IN FRAME F-Main
   NO-ENABLE                                                            */
/* SETTINGS FOR COMBO-BOX gcTimeUnitCombo IN FRAME F-Main
   NO-ENABLE 4                                                          */
/* SETTINGS FOR FILL-IN gcuAbfahrtszeit IN FRAME F-Main
   NO-ENABLE                                                            */
/* SETTINGS FOR FILL-IN gcZollNummer IN FRAME F-Main
   NO-ENABLE 4                                                          */
/* SETTINGS FOR FILL-IN gdAkzeptierte_Menge IN FRAME F-Main
   NO-ENABLE 4                                                          */
/* SETTINGS FOR FILL-IN gdSteuersatz IN FRAME F-Main
   NO-ENABLE 4                                                          */
/* SETTINGS FOR FILL-IN gdTaxSum IN FRAME F-Main
   NO-ENABLE                                                            */
/* SETTINGS FOR FILL-IN giKO_LagerOrt IN FRAME F-Main
   NO-ENABLE                                                            */
/* SETTINGS FOR FILL-IN gtuAbfahrtsdatum IN FRAME F-Main
   NO-ENABLE                                                            */
/* SETTINGS FOR FILL-IN gtuAbfahrtsdatum_Info IN FRAME F-Main
   NO-ENABLE                                                            */
/* SETTINGS FOR FILL-IN V_BelegPos.IncoTerm IN FRAME F-Main
   NO-ENABLE                                                            */
/* SETTINGS FOR FILL-IN V_BelegPos.Metalsurcharge IN FRAME F-Main
   NO-ENABLE                                                            */
/* SETTINGS FOR FILL-IN V_BelegPos.proz_RZ_1 IN FRAME F-Main
   EXP-LABEL                                                            */
/* SETTINGS FOR FILL-IN V_BelegPos.proz_RZ_2 IN FRAME F-Main
   EXP-LABEL                                                            */
/* SETTINGS FOR FILL-IN V_BelegPos.proz_RZ_3 IN FRAME F-Main
   EXP-LABEL                                                            */
/* SETTINGS FOR FILL-IN V_BelegPos.uCE_ReferenceDocItemPos IN FRAME F-Main
   NO-ENABLE                                                            */
/* SETTINGS FOR FILL-IN V_BelegPos.uCI_Lot IN FRAME F-Main
   NO-ENABLE                                                            */
assign 
       V_BelegPos.uCI_Lot:READ-ONLY in frame F-Main        = true.

/* SETTINGS FOR FILL-IN V_BelegPos.uCI_Warenausgangstermin IN FRAME F-Main
   NO-ENABLE                                                            */
/* SETTINGS FOR FILL-IN V_BelegPos.uCW_Tour IN FRAME F-Main
   NO-ENABLE                                                            */
/* SETTINGS FOR FILL-IN V_BelegPos.uCW_TransportNr IN FRAME F-Main
   NO-ENABLE                                                            */
/* SETTINGS FOR FILL-IN V_BelegPos_LieferBedingung_Info IN FRAME F-Main
   NO-ENABLE                                                            */
/* SETTINGS FOR FILL-IN V_BelegPos_Liefertermin_Info IN FRAME F-Main
   NO-ENABLE                                                            */
/* SETTINGS FOR COMBO-BOX V_BelegPos_Steuer_Bez IN FRAME F-Main
   NO-ENABLE 4                                                          */
/* SETTINGS FOR FILL-IN V_BelegPos_uCI_Versandart_Info IN FRAME F-Main
   NO-ENABLE                                                            */
/* SETTINGS FOR FILL-IN V_BelegPos_Versandtermin_Info IN FRAME F-Main
   NO-ENABLE                                                            */
/* SETTINGS FOR FILL-IN V_BelegPos_Wunschtermin_Info IN FRAME F-Main
   NO-ENABLE                                                            */
/* SETTINGS FOR FILL-IN V_BeleI_Warenausgangstermin_Info IN FRAME F-Main
   NO-ENABLE                                                            */
/* SETTINGS FOR FILL-IN V_BelegPos.Versandtermin IN FRAME F-Main
   NO-ENABLE                                                            */
/* SETTINGS FOR FILL-IN V_BelegPos.Wert_RZ_1 IN FRAME F-Main
   EXP-LABEL EXP-FORMAT                                                 */
/* SETTINGS FOR FILL-IN V_BelegPos.Wert_RZ_2 IN FRAME F-Main
   EXP-FORMAT                                                           */
/* SETTINGS FOR FILL-IN V_BelegPos.Wert_RZ_5 IN FRAME F-Main
   EXP-FORMAT                                                           */
/* SETTINGS FOR FILL-IN V_BelegPos.Zeiteinheit IN FRAME F-Main
   NO-ENABLE                                                            */
assign 
       V_BelegPos.Zeiteinheit:HIDDEN in frame F-Main           = true.


/* _MULTI-LAYOUT-RUN-TIME-ADJUSTMENTS */

/* LAYOUT-NAME: "BaseEntry"
   LAYOUT-TYPE: GUI
   EXPRESSION:  
   COMMENT:     
                                                                        */
/* LAYOUT-NAME: "QuickEntry"
   LAYOUT-TYPE: GUI
   EXPRESSION:  
   COMMENT:     
                                                                        */
run set-attribute-list ('Layout-Options="Master Layout,BaseEntry,QuickEntry"':U).

/* END-OF-LAYOUT-DEFINITIONS */

/* _RUN-TIME-ATTRIBUTES-END */
&ANALYZE-RESUME


/* Setting information for Queries and Browse Widgets fields            */

&ANALYZE-SUSPEND _QUERY-BLOCK FRAME F-Main
/* Query rebuild information for FRAME F-Main
     _Options          = "NO-LOCK"
     _Query            is NOT OPENED
*/  /* FRAME F-Main */
&ANALYZE-RESUME





/* ************************  Control Triggers  ************************ */

&Scoped-define SELF-NAME btnTax
&ANALYZE-SUSPEND _UIB-CODE-BLOCK _CONTROL btnTax V-table-Win
on choose of btnTax in frame F-Main
do:
  {adm/template/incl/dt_uit00.if
     &UserExitName = "ON_CHOOSE_OF_btnTax"}

  run OverrideUSTaxData no-error.

  if error-status:error then
    {returnnoapply}.

  {adm/template/incl/dt_uit01.if
     &UserExitName = "ON_CHOOSE_OF_btnTax"}
end. /* ON CHOOSE OF btnTax */

/* _UIB-CODE-BLOCK-END */
&ANALYZE-RESUME


&Scoped-define SELF-NAME btnVME
&ANALYZE-SUSPEND _UIB-CODE-BLOCK _CONTROL btnVME V-table-Win
on choose of btnVME in frame F-Main
do:

  define variable iNewUnitOfMeasure as integer        initial ?          no-undo.
  define variable cPKSDummy         as character                         no-undo.

  define variable oOldUnitOfMeasure as SBCPackagingUnitOfMeasure         no-undo.
  define variable oOldQty           as SBCQuantity                       no-undo.

  define variable oNewUnitOfMeasure as SBCPackagingUnitOfMeasure         no-undo.
  define variable oNewQty           as SBCQuantity                       no-undo.

  /* if we have already reservations then abort ----------------------------- */

  {adm/template/incl/dt_uit00.if
     &UserExitName = "ON_CHOOSE_OF_btnVME"}

  if   (    d_reserviert:hidden in frame {&frame-name} = no
        and input frame {&frame-name} d_reserviert    <> 0)
    or d_reserviert                                   <> 0 then

    {returnnoapply}.

  /* find the packaging unit ------------------------------------------------ */

  run stamm/proc/s_pame10.w (input-output cPKSDummy,
                                          pACConnectionSvc:prpcCompany,
                                          V_BelegPos.Artikel,
                                   output iNewUnitOfMeasure).

  if iNewUnitOfMeasure = ? then

    {returnnoapply}.

  /* succeed when unit has changed ------------------------------------------ */

  if    iNewUnitOfMeasure <> giMengeneinheit then
  do:

    assign
      oOldUnitOfMeasure = SBCPackagingUnitOfMeasureRpo:prpoInstance:oGetByPrimaryKey(giMengeneinheit,V_BelegPos.Artikel)
      oOldQty           = stamm.base.cls.SBCQuantity:create(input frame {&FRAME-NAME} d_Menge, oOldUnitOfMeasure)
      .

    assign
      oNewUnitOfMeasure = SBCPackagingUnitOfMeasureRpo:prpoInstance:oGetByPrimaryKey(iNewUnitOfMeasure, V_BelegPos.Artikel)
      oNewQty           = stamm.base.cls.SBCQuantity:create(oOldQty,oNewUnitOfMeasure,yes)
      .

    assign
      giMengeneinheit        = oNewUnitOfMeasure:prpiUnitOfMEasure
      gdVME_Faktor           = oNewUnitOfMeasure:prpdPackagingFactor
      giNachkomma            = oNewUnitOfMeasure:prpiDecimals
      d_Menge                = oNewQty:prpdValue
      V_BelegPos.GewichtVerp = oNewUnitOfMeasure:prpdWeight
      .

    glToRecalculateQty = yes.

    /* set format for entry of amount --------------------------------------- */

    assign
      {setwidgetattr
         "d_Menge"
         "format"
         "string(entry(giNachkomma + 1,{&pa_MengenEingabeFormat},{&pa-Delimiter4}))"
         "in frame {&FRAME-NAME}"}
      {setwidgetattr
         "d_reserviert"
         "format"
         "string(entry(giNachkomma + 1,{&pa_MengenEingabeFormat},{&pa-Delimiter4}))"
         "in frame {&FRAME-NAME}"}
      {setwidgetattr
         "d_geliefert"
         "format"
         "string(entry(giNachkomma + 1,{&pa_MengenEingabeFormat},{&pa-Delimiter4}))"
         "in frame {&FRAME-NAME}"}
      {setwidgetattr
         "d_Storno"
         "format"
         "string(entry(giNachkomma + 1,{&pa_MengenEingabeFormat},{&pa-Delimiter4}))"
         "in frame {&FRAME-NAME}"}
      .

    find first S_EAN
      where S_EAN.Firma         = S_Artikel.Firma
        and S_EAN.Mengeneinheit = giMengeneinheit
        and S_EAN.Artikel       = V_BelegPos.Artikel
      use-index EANME
      no-lock no-error.

    gcEAN = (if available S_EAN then
               S_EAN.EAN
             else
               '':U).

    {adm/incl/d__duh00.if
       &Var1     = "gcEAN"
       &WithFrame = "frame {&FRAME-NAME}"}

    if    not available S_EAN
      and not can-do({&pa_V_PTList_WithoutEAN},string(S_Artikel.Artikelart)) then

      {fnarg
        pa_lUISvcEnableWidget
          "gcEAN:handle in frame {&frame-name}"}.

    else

      {fnarg
        pa_lUISvcDisableWidget
          "gcEAN:handle in frame {&frame-name}"}.

    assign
      c_text-14         = '/':U
      c_text-VME        = oNewUnitOfMeasure:prpcShortDesc
      c_Mengeneinheit-1 = c_text-VME
      c_Mengeneinheit-2 = c_Mengeneinheit-1
      c_Mengeneinheit-3 = c_Mengeneinheit-1
      c_Mengeneinheit-4 = c_Mengeneinheit-1
      .

    {adm/incl/d__duh00.if
       &Var1     = "d_Menge"
       &Var2     = "d_reserviert"
       &Var3     = "d_geliefert"
       &Var4     = "d_Storno"
       &Var5     = "c_text-14"
       &Var6     = "c_text-VME"
       &Var7     = "c_Mengeneinheit-1"
       &Var8     = "c_Mengeneinheit-2"
       &Var9     = "c_Mengeneinheit-3"
       &Var10    = "c_Mengeneinheit-4"
       &WithFrame = "frame {&frame-name}"}

    if V_BelegPos.Wertposition = no then

      {setwidgetattr
         "V_BelegPos.GewichtVerp"
         "screen-value"
         "string(oNewUnitOfMeasure:prpdWeight, V_BelegPos.GewichtVerp:format in frame {&frame-name})"
         "in frame {&frame-name}"}.

    apply 'leave':U to d_Menge in frame {&frame-name}.

  end. /* if iNewUnitOfMeasure <> giMengeneinheit */

  {adm/template/incl/dt_uit01.if
     &UserExitName = "ON_CHOOSE_OF_btnVME"}
end. /* ON CHOOSE OF btnVME */

/* _UIB-CODE-BLOCK-END */
&ANALYZE-RESUME


&Scoped-define SELF-NAME d_Menge
&ANALYZE-SUSPEND _UIB-CODE-BLOCK _CONTROL d_Menge V-table-Win
on leave of d_Menge in frame F-Main /* Menge */
do:
  {adm/template/incl/dt_uit00.if
     &UserExitName = "ON_LEAVE_OF_d_Menge"}

  if   string(input frame {&Frame-name} d_Menge,   string(entry(giNachkomma + 1,{&pa_MengenEingabeFormat},{&pa-Delimiter4}))) <> 
       string(TT_V_PreisFind.Menge / gdVME_Faktor, string(entry(giNachkomma + 1,{&pa_MengenEingabeFormat},{&pa-Delimiter4})))
    or glFlagTotalPriceMax then
  do:

    glToRecalculateQty = yes.

    assign
      TT_V_PreisFind.Menge      = (if  (input frame {&frame-name} d_Menge * gdVME_Faktor)
                                       - truncate ((input frame {&frame-name} d_Menge * gdVME_Faktor),giNachkomma) <> 0 then                            
                                     round((input frame {&frame-name} d_Menge * gdVME_Faktor) + (5 / exp(10,giNachkomma + 1)),
                                          giNachkomma)                                  
                                   else
                                     input frame {&FRAME-NAME} d_Menge * gdVME_Faktor)
      TT_V_PreisFind.VME_Faktor = gdVME_Faktor
      l_PFI_noetig              = yes
      .

    run bestimme-Staffelkonditionen (buffer TT_V_PreisFind).

    run Preis_anzeigen (self:name) no-error.

    if error-status:error then
      {returnnoapply}.

    run set-link-attribute in adm-broker-hdl
        (this-procedure,
         'record-target':U,
         'SETMenge=':U + string(input frame {&Frame-name} d_Menge * gdVME_Faktor * 1000)).

  end. /* if input frame {&Frame-name} d_Menge <>  TT_V_PreisFind.Menge / gdVME_Faktor then */

  &IF lookup ("VF_INTRA","{&PA-OPTIONEN}") > 0 &THEN
    run pruefe-Intra.
  &ENDIF

  {adm/template/incl/dt_uit01.if
     &UserExitName = "ON_LEAVE_OF_d_Menge"}
end. /* ON LEAVE OF d_Menge */

/* _UIB-CODE-BLOCK-END */
&ANALYZE-RESUME


&ANALYZE-SUSPEND _UIB-CODE-BLOCK _CONTROL d_Menge V-table-Win
on value-changed of d_Menge in frame F-Main /* Menge */
do:

  /* switch menu availibility sensitive/insensitive ------------------------- */
  /* This function has been moved from the leave-trigger because the          */
  /* leave-trigger doesn't fire if you directly choose a menu point.          */

  {adm/template/incl/dt_uit00.if
     &UserExitName = "ON_VALUE-CHANGED_OF_d_Menge"}

  &IF lookup("M_","{&pa-Module}") > 0 &THEN

    if (   input frame {&frame-name} V_BelegPos.Lagerort <> ?
        or (    available S_Artikel
            and can-do({&pa_S_PTList_Set}, string(S_Artikel.ArtikelArt))))
      and V_BelegPos.Wertposition            = no
      and input frame {&frame-name} d_Menge <> 0
      and V_BelegPos.Satzart                 = 'A':U then

      run set-attribute-list ('CheckAvailability=yes':U).

    else
      if    (    input frame {&frame-name} V_BelegPos.Lagerort <> ?
             or  (    available S_Artikel
                  and can-do({&pa_S_PTList_Set}, string(S_Artikel.ArtikelArt))))
        and input frame {&frame-name} d_Menge = 0 then

      run set-attribute-list ('CheckAvailability=no':U).

  &ENDIF

  {adm/template/incl/dt_uit01.if
     &UserExitName = "ON_VALUE-CHANGED_OF_d_Menge"}
end. /* ON VALUE-CHANGED OF d_Menge */

/* _UIB-CODE-BLOCK-END */
&ANALYZE-RESUME


&Scoped-define SELF-NAME d_reserviert
&ANALYZE-SUSPEND _UIB-CODE-BLOCK _CONTROL d_reserviert V-table-Win
on leave of d_reserviert in frame F-Main /* reservierte Menge */
do:
  
  {adm/template/incl/dt_uit00.if
     &UserExitName = "ON_LEAVE_OF_d_reserviert"}

  if d_reserviert:screen-value = '0' then

    run new-state('zeroReserved,record-source':U).

  else

    run new-state('reserved,record-source':U).

  {adm/template/incl/dt_uit01.if
     &UserExitName = "ON_LEAVE_OF_d_reserviert"}
end.

/* _UIB-CODE-BLOCK-END */
&ANALYZE-RESUME


&Scoped-define SELF-NAME V_BelegPos.Einzelpreis
&ANALYZE-SUSPEND _UIB-CODE-BLOCK _CONTROL V_BelegPos.Einzelpreis V-table-Win
on leave of V_BelegPos.Einzelpreis in frame F-Main /* Einzelpreis */
do:
  {adm/template/incl/dt_uit00.if
     &UserExitName = "ON_LEAVE_OF_V_BelegPos_Einzelpreis"}

  run Preis_anzeigen (self:name) no-error.

  if error-status:error then
    {returnnoapply}.

  &IF lookup ("VF_INTRA","{&PA-OPTIONEN}") > 0 &THEN
    run pruefe-Intra.
  &ENDIF

  {adm/template/incl/dt_uit01.if
     &UserExitName = "ON_LEAVE_OF_V_BelegPos_Einzelpreis"}
end. /* ON LEAVE OF V_BelegPos.Einzelpreis */

/* _UIB-CODE-BLOCK-END */
&ANALYZE-RESUME


&Scoped-define SELF-NAME gcTimeUnitCombo
&ANALYZE-SUSPEND _UIB-CODE-BLOCK _CONTROL gcTimeUnitCombo V-table-Win
on value-changed of gcTimeUnitCombo in frame F-Main
do:
  define variable cScreenValue as character     no-undo.

  {adm/template/incl/dt_uit00.if
     &UserExitName = "ON_VALUE-CHANGED_OF_gcTimeUnitCombo"}

  cScreenValue = {getwidgetattr gcTimeUnitCombo screen-value string}.

  {setwidgetattr
     "V_BelegPos.Zeiteinheit"
     "screen-value"
     "cScreenValue "
     "in frame {&FRAME-NAME}"}.

  if available V_BelegPos then
  do:

    &IF LOOKUP("U_CI":U,"{&PA-OPTIONEN}":U) > 0 &THEN
    uUpdateDateFields(V_BelegPos.Zeiteinheit:handle in frame {&FRAME-NAME}).
    &ELSE

    if date(V_BelegPos.Liefertermin:screen-value in frame {&frame-name}) <> ? then

      {setwidgetattr
         "V_BelegPos.Versandtermin"
         "screen-value"
         "string(date(V_BelegPos.Liefertermin:screen-value in frame {&frame-name}) - dynamic-function('pa_iCalendTransportTime':U in target-procedure, V_BelegPos.Firma, V_BelegKopf.Lagergruppe, input frame {&frame-name} V_BelegPos.Lagerort, integer(V_BelegPos.Transportzeit:screen-value in frame {&frame-name}), V_BelegPos.Zeiteinheit:screen-value in frame {&frame-name}, date(V_BelegPos.Liefertermin:screen-value in frame {&frame-name}), no), V_BelegPos.Versandtermin:format in frame {&frame-name})"
         "in frame {&frame-name}"}.

    else

      {setwidgetattr
         "V_BelegPos.Versandtermin"
         "screen-value"
         "string(date(V_BelegPos.Wunschtermin:screen-value in frame {&frame-name}) - dynamic-function('pa_iCalendTransportTime':U in target-procedure, V_BelegPos.Firma, V_BelegKopf.Lagergruppe, input frame {&frame-name} V_BelegPos.Lagerort, integer(V_BelegPos.Transportzeit:screen-value in frame {&frame-name}), V_BelegPos.Zeiteinheit:screen-value in frame {&frame-name}, date(V_BelegPos.Wunschtermin:screen-value in frame {&frame-name}), no), V_BelegPos.Versandtermin:format in frame {&frame-name})"
         "in frame {&frame-name}"}.
    &ENDIF

    apply 'leave':U to V_BelegPos.Versandtermin in frame {&frame-name}.

    {fnarg
      pa_lUISvcDisplayInfoFieldOfWidget
      "V_BelegPos.Versandtermin:handle in frame {&frame-name}"}.

  end.  /* if available V_BelegPos  */

  {adm/template/incl/dt_uit01.if
     &UserExitName = "ON_VALUE-CHANGED_OF_gcTimeUnitCombo"}
end. /* ON VALUE-CHANGED OF gcTimeUnitCombo */

/* _UIB-CODE-BLOCK-END */
&ANALYZE-RESUME


&Scoped-define SELF-NAME gcZollNummer
&ANALYZE-SUSPEND _UIB-CODE-BLOCK _CONTROL gcZollNummer V-table-Win
on leave of gcZollNummer in frame F-Main /* stat Warennummer */
do:
  {adm/template/incl/dt_uit00.if
     &UserExitName = "ON_LEAVE_OF_gcZollNummer"}

  assign
    gcZollNummer
    .

  {adm/template/incl/dt_uit01.if
     &UserExitName = "ON_LEAVE_OF_gcZollNummer"}
end.

/* _UIB-CODE-BLOCK-END */
&ANALYZE-RESUME


&Scoped-define SELF-NAME V_BelegPos.Gewicht
&ANALYZE-SUSPEND _UIB-CODE-BLOCK _CONTROL V_BelegPos.Gewicht V-table-Win
on leave of V_BelegPos.Gewicht in frame F-Main /* Gewicht */
do:
  {adm/template/incl/dt_uit00.if
     &UserExitName = "ON_LEAVE_OF_V_BelegPos_Gewicht"}

  run Preis_anzeigen (self:name) no-error.

  if error-status:error then
    {returnnoapply}.

  {adm/template/incl/dt_uit01.if
     &UserExitName = "ON_LEAVE_OF_V_BelegPos_Gewicht"}
end.

/* _UIB-CODE-BLOCK-END */
&ANALYZE-RESUME


&Scoped-define SELF-NAME gtuAbfahrtsdatum
&ANALYZE-SUSPEND _UIB-CODE-BLOCK _CONTROL gtuAbfahrtsdatum V-table-Win
on leave of gtuAbfahrtsdatum in frame F-Main
do:
  {adm/template/incl/dt_uit00.if
     &UserExitName = "ON_LEAVE_OF_gtuAbfahrtsdatum"}

  {adm/template/incl/dt_viw03.if}

  {adm/template/incl/dt_uit01.if
     &UserExitName = "ON_LEAVE_OF_gtuAbfahrtsdatum"}
end.

/* _UIB-CODE-BLOCK-END */
&ANALYZE-RESUME


&Scoped-define SELF-NAME V_BelegPos.LagerOrt
&ANALYZE-SUSPEND _UIB-CODE-BLOCK _CONTROL V_BelegPos.LagerOrt V-table-Win
on leave of V_BelegPos.LagerOrt in frame F-Main /* Lagerort */
do:

  define variable lSensitiveStateCRONo as logical       no-undo.

  {adm/template/incl/dt_uit00.if
     &UserExitName = "ON_LEAVE_OF_V_BelegPos_LagerOrt"}

  &IF LOOKUP("U_CW":U,"{&PA-OPTIONEN}":U) > 0 &THEN
  gluSAChanged = no.
  &ENDIF

  if input frame {&frame-name} V_BelegPos.Lagerort <> ? then
  do:

    /* if the storage area changed a second time while this line is opened for an update */

    if giStorageArea <> input frame {&frame-name} V_BelegPos.LagerOrt then

      assign
        giStorageArea = input frame {&frame-name} V_BelegPos.LagerOrt
        glMess00405   = ?

        &IF LOOKUP("U_CW":U,"{&PA-OPTIONEN}":U) > 0 &THEN
        gluSAChanged   = yes
        &ENDIF

        .

    /* check last-event:function, otherwise choose of button save would       */
    /* show the error message twice                                           */

    if {getwidgetattr last-event function string} = 'leave':U
      and mawi.lager.cls.MLCPartStAreaSvc:prpoInstance:lIsPartAvailableInStArea
            (V_BelegPos.Artikel,
             input frame {&frame-name} V_BelegPos.Lagerort) = no then

      adm.method.cls.DMCMessageSvc:prpoInstance:showError
        (V_BelegPos.LagerOrt:handle in frame {&frame-name},
         'mltrg00023':U,
         string(input frame {&frame-name} V_BelegPos.Lagerort),
         V_BelegPos.Artikel).

    else
    do:

      /* if we have entered a non-existing storage-area and have pressed return */
      /* afterwards without leaving the field then last-event:function is not   */
      /* 'leave' and we will pass this way                                      */

      &IF lookup ("VF_INTRA","{&PA-OPTIONEN}") > 0 &THEN
        run pruefe-Intra.
      &ENDIF

      /* switch menu availibility sensitive/insensitive --------------------- */

      if    V_BelegPos.Wertposition = no
        and V_BelegPos.Satzart      = 'A':U then
      do:

        find ML_Ort
          where ML_Ort.Firma    = {firma/mlort.fir pACConnectionSvc:prpcCompany}
            and ML_Ort.Lagerort = input frame {&frame-name} V_BelegPos.Lagerort
          no-lock no-error.

        /* if the storage area of the part is not nettable the dynamic  */
        /* available-to-promise check should not be sensitive.          */

        glNettableStorageArea = (if available ML_Ort then
                                   ML_Ort.Disponibel
                                 else
                                   no).

        /* if it is allowed to modify the CRO number */

        &IF "{&pa_M_KommissionsNrEingabe}":U = "1":U &THEN

          lSensitiveStateCRONo = V_BelegPos.MMM_CusRefOrder_ID:sensitive in frame {&FRAME-NAME}.

          /* calling this function causes calling the Object state function (pa_lUISvcObjectState) */
          /* that can change the sensitive state of the field                                      */

            {fnarg
              pa_lUISvcEnableWidget
            "V_BelegPos.MMM_CusRefOrder_ID:handle in frame {&frame-name}"}.

          if    lSensitiveStateCRONo <> V_BelegPos.MMM_CusRefOrder_ID:sensitive in frame {&FRAME-NAME}
            and lSensitiveStateCRONo  = no /* the field has been enabled */
            and S_Artikel.KommLager   = 0
            and V_BelegPos.MMM_CusRefOrder_ID:screen-value in frame {&FRAME-NAME} = '':U then

            /* this procedures can only return 'yes' if S_Artikel.KommLager = 1 */

            run QuestionAdoptCRONoOfHead.

          else if    lSensitiveStateCRONo <> V_BelegPos.MMM_CusRefOrder_ID:sensitive in frame {&FRAME-NAME}
                 and lSensitiveStateCRONo  = yes     /* the field has been disabled and      */
                 and not can-find(first MMR_MRPLink  /* no production order has been created */
                                    where MMR_MRPLink.Company              = pACConnectionSvc:prpcCompany
                                      and MMR_MRPLink.Demand_MRPDocType    = V_BelegPos.Belegart
                                      and MMR_MRPLink.Demand_Origin_Obj    = V_BelegPos.V_BelegPos_Obj
                                      and MMR_MRPLink.Coverage_MRPDocType  = 'PPA':U
                                      and MMR_MRPLink.Coverage_Origin_Obj >  '':U
                                      and MMR_MRPLink.ResStatus           >= {&pa_MM_ResStat_Res})
                 and not can-find(first MMR_MRPLink  /* or no mrp suggestion has been created */
                                    where MMR_MRPLink.Company              = pACConnectionSvc:prpcCompany
                                      and MMR_MRPLink.Demand_MRPDocType    = V_BelegPos.Belegart
                                      and MMR_MRPLink.Demand_Origin_Obj    = V_BelegPos.V_BelegPos_Obj
                                      and MMR_MRPLink.Coverage_MRPDocType  = 'MDD':U
                                      and MMR_MRPLink.Coverage_Origin_Obj >  '':U
                                      and MMR_MRPLink.ResStatus           >= {&pa_MM_ResStat_Res}) then

            {setwidgetattr
               "V_BelegPos.MMM_CusRefOrder_ID"
               "screen-value"
               "'':U"
               "in frame {&FRAME-NAME}"}.

        &ENDIF

      end. /* if V_BelegPos.Wertposition = no and V_BelegPos.Satzart = 'A':U */

    end. /* else: {getwidgetattr last-event function string} = 'leave':U and lIsPartAvailableInStArea = no */

  end. /* if input frame {&frame-name} V_BelegPos.Lagerort <> ? */

  &IF LOOKUP("U_CW":U,"{&PA-OPTIONEN}":U) > 0 &THEN
  if gluSAChanged
    and date(input frame {&frame-name} V_BelegPos.Liefertermin) <> ? then
    uUpdateDateFields(V_BelegPos.Liefertermin:handle in frame {&FRAME-NAME}).
  else if gluSAChanged then
    uUpdateDateFields(V_BelegPos.Wunschtermin:handle in frame {&FRAME-NAME}).
  &ENDIF

  /* the average price might have changed due to changing the storage area to */
  /* one of another stock value group                                         */

  if    not can-do({&pa_S_PTList_Set}, string(S_Artikel.ArtikelArt))
    and V_BelegPos.Wertposition = no then
  do:

    gdAverageCosts = vert.base.cls.VBCSalesDocSvc:prpoInstance:dCalcBasePrice(V_BelegPos.Artikel,
                                                                              input frame {&frame-name} V_BelegPos.Lagerort,
                                                                              V_BelegKopf.Belegdatum,
                                                                              S_Artikel.ArtikelArt,
                                                                              V_BelegKopf.Belegart,
                                                                              S_Artikel.KommLager,
                                                                              S_Artikel.ChargenArt,
                                                                              input frame {&frame-name} V_BelegPos.MMM_CusRefOrder_ID).

    run Preis_anzeigen('':U).

  end.

  &IF LOOKUP("U_CW":U,"{&PA-OPTIONEN}":U) > 0 &THEN
  gluSAChanged = no.
  &ENDIF

  {adm/template/incl/dt_uit01.if
     &UserExitName = "ON_LEAVE_OF_V_BelegPos_LagerOrt"}
end. /* ON LEAVE OF V_BelegPos.LagerOrt */

/* _UIB-CODE-BLOCK-END */
&ANALYZE-RESUME


&Scoped-define SELF-NAME V_BelegPos.LieferBedingung
&ANALYZE-SUSPEND _UIB-CODE-BLOCK _CONTROL V_BelegPos.LieferBedingung V-table-Win
on leave of V_BelegPos.LieferBedingung in frame F-Main /* Lieferbedingung */
do:
  {adm/template/incl/dt_uit00.if
     &UserExitName = "ON_LEAVE_OF_V_BelegPos_LieferBedingung"}

  {adm/template/incl/dt_viw03.if}

  /* Buffers ---------------------------------------------------------------- */

  define buffer S_LieferBed for S_LieferBed.

  find S_LieferBed
    where S_LieferBed.Firma           = {firma/sliefbed.fir pACConnectionSvc:prpcCompany}
      and S_LieferBed.Lieferbedingung = input frame {&frame-name} V_BelegPos.Lieferbedingung
    no-lock no-error.

  {setwidgetattr
     "V_BelegPos.IncoTerm"
     "screen-value"
     "string(if available S_LieferBed then string(S_LieferBed.IncoTerm) else '':U)"
     "in frame {&frame-name}"}.

  &IF LOOKUP("U_CA":U,"{&PA-OPTIONEN}":U) > 0 &THEN
  /* Transport- und Kommissinierzeit aktualisieren? */
  if    can-do('U':U,V_BelegKopf.Belegart)
    and V_BelegPos.LieferBedingung:private-data <>  V_BelegPos.LieferBedingung:input-value
    and can-find(first USM_Versandparameter
                 where USM_Versandparameter.Company         = {firma/usmvers.fir pACConnectionSvc:prpcCompany})
    and adm.method.cls.DMCMessageSvc:prpoInstance:lShowMessage
          ('usvep000001':U) then
  do:

    find gbuV_BelegKopfAdr
      where gbuV_BelegKopfAdr.Firma      = V_BelegKopf.Firma
        and gbuV_BelegKopfAdr.Belegart   = V_BelegKopf.Belegart
        and gbuV_BelegKopfAdr.ReferenzNr = V_BelegKopf.ReferenzNr
        and gbuV_BelegKopfAdr.Typ        = 'L':U
      no-lock no-error.

    branche.vert.cls.UVC_CISalesDocumentSvc:prpoInstance:GetTransportTime
      (       V_BelegKopf.Kunde,
              V_BelegPos.uCI_VersandArt:input-value,
              V_BelegKopf.Lieferant,
              V_BelegPos.LieferBedingung:input-value,
              (if available gbuV_BelegKopfAdr then
                 gbuV_BelegKopfAdr.Staat
               else
                 ?),
              (if available gbuV_BelegKopfAdr then
                 gbuV_BelegKopfAdr.PLZ
               else
                 ?),
       output giuTransportTime,
       output gcuTransportTimeUnit,
       output giuPickTime,
       output gcuPickTimeUnit).

    if giuTransportTime <> ? then
      assign
        {setwidgetattr
           "V_BelegPos.Transportzeit"
           "screen-value"
           "string(giuTransportTime)"}
        {setwidgetattr
           "V_BelegPos.Zeiteinheit"
           "screen-value"
           "string(gcuTransportTimeUnit)"}
        {setwidgetattr
           "gcTimeUnitCombo"
           "screen-value"
           "V_BelegPos.Zeiteinheit:screen-value"}
        {setwidgetattr
           "V_BelegPos.uCI_KommZeit"
           "screen-value"
           "string(giuPickTime)"}
        {setwidgetattr
           "V_BelegPos.uCI_KommZeiteinheit"
           "screen-value"
           "string(gcuPickTimeUnit)"}
        .

    {fnarg
      pa_lUISvcACMReplacementDisplay
      "frame {&frame-name}:handle"}.

  end.
  {setwidgetattr
     "V_BelegPos.LieferBedingung"
     "private-data"
     "string(V_BelegPos.LieferBedingung:input-value)"}.
  &ENDIF

  {adm/template/incl/dt_uit01.if
     &UserExitName = "ON_LEAVE_OF_V_BelegPos_LieferBedingung"}
end. /* ON LEAVE OF V_BelegPos.LieferBedingung */

/* _UIB-CODE-BLOCK-END */
&ANALYZE-RESUME


&Scoped-define SELF-NAME V_BelegPos.Liefertermin
&ANALYZE-SUSPEND _UIB-CODE-BLOCK _CONTROL V_BelegPos.Liefertermin V-table-Win
on leave of V_BelegPos.Liefertermin in frame F-Main /* Liefertermin */
do:
  {adm/template/incl/dt_uit00.if
     &UserExitName = "ON_LEAVE_OF_V_BelegPos_Liefertermin"}

  {adm/template/incl/dt_viw03.if}

  &IF LOOKUP("U_CI":U,"{&PA-OPTIONEN}":U) > 0 &THEN
  uUpdateDateFields(V_BelegPos.Liefertermin:handle in frame {&FRAME-NAME}).
  &ELSE

  if date(input frame {&frame-name} V_BelegPos.Liefertermin) <> ? then
  do:

    {setwidgetattr
       "V_BelegPos.Versandtermin"
       "screen-value"
       "string(input frame {&frame-name} V_BelegPos.Liefertermin - dynamic-function('pa_iCalendTransportTime':U in target-procedure, V_BelegPos.Firma, V_BelegKopf.Lagergruppe, input frame {&frame-name} V_BelegPos.Lagerort, integer(V_BelegPos.Transportzeit:screen-value in frame {&frame-name}), V_BelegPos.Zeiteinheit:screen-value in frame {&frame-name}, input frame {&frame-name} V_BelegPos.Liefertermin, no), V_BelegPos.Versandtermin:format in frame {&frame-name})"
       "in frame {&frame-name}"}.

    if date(input frame {&frame-name} V_BelegPos.Versandtermin) < today then

      adm.method.cls.DMCMessageSvc:prpoInstance:lShowMessage(
        'v_bel00188':U,
        string(input frame {&frame-name} V_BelegPos.Versandtermin,'{&PA_DATEFORMAT}':U)).

  end. /* if date(input frame {&frame-name} V_BelegPos.Liefertermin) <> ? */

  {fnarg
    pa_lUISvcDisplayInfoFieldOfWidget
    "V_BelegPos.Versandtermin:handle in frame {&frame-name}"}.

  &ENDIF

  {adm/template/incl/dt_uit01.if
     &UserExitName = "ON_LEAVE_OF_V_BelegPos_Liefertermin"}
end. /* ON LEAVE OF V_BelegPos.Liefertermin */

/* _UIB-CODE-BLOCK-END */
&ANALYZE-RESUME


&Scoped-define SELF-NAME V_BelegPos.proz_RZ_1
&ANALYZE-SUSPEND _UIB-CODE-BLOCK _CONTROL V_BelegPos.proz_RZ_1 V-table-Win
on leave of V_BelegPos.proz_RZ_1 in frame F-Main /* % R/Z */
do:
  {adm/template/incl/dt_uit00.if
     &UserExitName = "ON_LEAVE_OF_V_BelegPos_proz_RZ_1"}

  if    V_BelegPos.proz_RZ_1 <> input frame {&Frame-name} V_BelegPos.proz_RZ_1
    and not c_Preisherkunft-2 = 'M':U then
  do:

    {adm/incl/d__msg00.if
      &Meldung = "'v_bel00005':U"
    }

    /* Meldung: Bei manueller Eingabe eines prozentualen Rabatts findet keine */
    /*          weitere Preis- und Rabattfindung statt.                       */

  end. /* if V_BelegPos.proz_RZ_1 <> input frame {&Frame-name} V_BelegPos.proz_RZ_1 */

  run Preis_anzeigen (self:name) no-error.

  if error-status:error then
    {returnnoapply}.

  {adm/template/incl/dt_uit01.if
     &UserExitName = "ON_LEAVE_OF_V_BelegPos_proz_RZ_1"}
end. /* ON LEAVE OF V_BelegPos.proz_RZ_1 */

/* _UIB-CODE-BLOCK-END */
&ANALYZE-RESUME


&Scoped-define SELF-NAME V_BelegPos.proz_RZ_2
&ANALYZE-SUSPEND _UIB-CODE-BLOCK _CONTROL V_BelegPos.proz_RZ_2 V-table-Win
on leave of V_BelegPos.proz_RZ_2 in frame F-Main /* % R/Z 2 */
do:
  {adm/template/incl/dt_uit00.if
     &UserExitName = "ON_LEAVE_OF_V_BelegPos_proz_RZ_2"}

  if    V_BelegPos.proz_RZ_2 <> input frame {&Frame-name} V_BelegPos.proz_RZ_2
    and not c_Preisherkunft-3 = 'M':U then
  do:

    {adm/incl/d__msg00.if
      &Meldung = "'v_bel00005':U"
    }

    /* Meldung: Bei manueller Eingabe eines prozentualen Rabatts findet keine */
    /*          weitere Preis- und Rabattfindung statt.                       */

  end. /* if V_BelegPos.proz_RZ_2 <> input frame {&Frame-name} V_BelegPos.proz_RZ_2 */

  run Preis_anzeigen (self:name) no-error.

  if error-status:error then
    {returnnoapply}.

  {adm/template/incl/dt_uit01.if
     &UserExitName = "ON_LEAVE_OF_V_BelegPos_proz_RZ_2"}
end. /* ON LEAVE OF V_BelegPos.proz_RZ_2 */

/* _UIB-CODE-BLOCK-END */
&ANALYZE-RESUME


&Scoped-define SELF-NAME V_BelegPos.proz_RZ_3
&ANALYZE-SUSPEND _UIB-CODE-BLOCK _CONTROL V_BelegPos.proz_RZ_3 V-table-Win
on leave of V_BelegPos.proz_RZ_3 in frame F-Main /* % R/Z 3 */
do:
  {adm/template/incl/dt_uit00.if
     &UserExitName = "ON_LEAVE_OF_V_BelegPos_proz_RZ_3"}

  if    V_BelegPos.proz_RZ_3 <> input frame {&Frame-name} V_BelegPos.proz_RZ_3
    and not c_Preisherkunft-4 = 'M':U then
  do:

    {adm/incl/d__msg00.if
      &Meldung = "'v_bel00005':U"
    }

    /* Meldung: Bei manueller Eingabe eines prozentualen Rabatts findet keine */
    /*          weitere Preis- und Rabattfindung statt.                       */

  end. /* if V_BelegPos.proz_RZ_3 <> input frame {&Frame-name} V_BelegPos.proz_RZ_3 */

  run Preis_anzeigen (self:name) no-error.

  if error-status:error then
    {returnnoapply}.

  {adm/template/incl/dt_uit01.if
     &UserExitName = "ON_LEAVE_OF_V_BelegPos_proz_RZ_3"}
end. /* ON LEAVE OF V_BelegPos.proz_RZ_3 */

/* _UIB-CODE-BLOCK-END */
&ANALYZE-RESUME


&Scoped-define SELF-NAME V_BelegPos.Transportzeit
&ANALYZE-SUSPEND _UIB-CODE-BLOCK _CONTROL V_BelegPos.Transportzeit V-table-Win
on leave of V_BelegPos.Transportzeit in frame F-Main /* Transportzeit */
do:

  {adm/template/incl/dt_uit00.if
     &UserExitName = "ON_LEAVE_OF_V_BelegPos_Transportzeit"}

  &IF LOOKUP("U_CI":U,"{&PA-OPTIONEN}":U) > 0 &THEN
  uUpdateDateFields(V_BelegPos.Transportzeit:handle in frame {&FRAME-NAME}).
  &ELSE
  if date(V_BelegPos.Liefertermin:screen-value in frame {&frame-name}) <> ? then

    {setwidgetattr
       "V_BelegPos.Versandtermin"
       "screen-value"
       "string(date(V_BelegPos.Liefertermin:screen-value in frame {&frame-name}) - dynamic-function('pa_iCalendTransportTime':U in target-procedure, V_BelegPos.Firma, V_BelegKopf.Lagergruppe, input frame {&frame-name} V_BelegPos.Lagerort, input frame {&frame-name} V_BelegPos.Transportzeit, V_BelegPos.Zeiteinheit:screen-value in frame {&frame-name}, date(V_BelegPos.Liefertermin:screen-value in frame {&frame-name}), no), V_BelegPos.Versandtermin:format in frame {&frame-name})"
       "in frame {&frame-name}"}.

  else

    {setwidgetattr
       "V_BelegPos.Versandtermin"
       "screen-value"
       "string(date(V_BelegPos.Wunschtermin:screen-value in frame {&frame-name}) - dynamic-function('pa_iCalendTransportTime':U in target-procedure, V_BelegPos.Firma, V_BelegKopf.Lagergruppe, input frame {&frame-name} V_BelegPos.Lagerort, input frame {&frame-name} V_BelegPos.Transportzeit, V_BelegPos.Zeiteinheit:screen-value in frame {&frame-name}, date(V_BelegPos.Wunschtermin:screen-value in frame {&frame-name}), no), V_BelegPos.Versandtermin:format in frame {&frame-name})"
       "in frame {&frame-name}"}.

  if date(input frame {&frame-name} V_BelegPos.Versandtermin) < today then

    adm.method.cls.DMCMessageSvc:prpoInstance:lShowMessage(
      'v_bel00188':U,
      string(input frame {&frame-name} V_BelegPos.Versandtermin,'{&PA_DATEFORMAT}':U)).

  {fnarg
    pa_lUISvcDisplayInfoFieldOfWidget
    "V_BelegPos.Versandtermin:handle in frame {&frame-name}"}.
  &ENDIF

  {adm/template/incl/dt_uit01.if
     &UserExitName = "ON_LEAVE_OF_V_BelegPos_Transportzeit"}
end. /* ON LEAVE OF V_BelegPos.Transportzeit */

/* _UIB-CODE-BLOCK-END */
&ANALYZE-RESUME


&Scoped-define SELF-NAME V_BelegPos.uCI_KommZeit
&ANALYZE-SUSPEND _UIB-CODE-BLOCK _CONTROL V_BelegPos.uCI_KommZeit V-table-Win
on leave of V_BelegPos.uCI_KommZeit in frame F-Main /* Kommissionierzeit */
do:

  {adm/template/incl/dt_uit00.if
     &UserExitName = "ON_LEAVE_OF_V_BelegPos_uCI_KommZeit"}

  &IF LOOKUP("U_CI":U,"{&PA-OPTIONEN}":U) > 0 &THEN
    uUpdateDateFields(V_BelegPos.uCI_KommZeit:handle in frame {&FRAME-NAME}).
  &ENDIF

  {adm/template/incl/dt_uit01.if
     &UserExitName = "ON_LEAVE_OF_V_BelegPos_uCI_KommZeit"}
end.

/* _UIB-CODE-BLOCK-END */
&ANALYZE-RESUME


&Scoped-define SELF-NAME V_BelegPos.uCI_Versandart
&ANALYZE-SUSPEND _UIB-CODE-BLOCK _CONTROL V_BelegPos.uCI_Versandart V-table-Win
on leave of V_BelegPos.uCI_Versandart in frame F-Main /* Versandart */
do:
  {adm/template/incl/dt_uit00.if
     &UserExitName = "ON_LEAVE_OF_V_BelegPos_uCI_Versandart"}

  {adm/template/incl/dt_viw03.if}

&IF LOOKUP("U_CI":U,"{&PA-OPTIONEN}":U) > 0 &THEN
    define variable uiStoragearea as integer       no-undo.
    define variable uiMRPArea     as integer       no-undo.

    /* changed shipping type? Then handle storage area */
    if input frame {&frame-name} V_BelegPos.uCI_Versandart <> V_BelegPos.uCI_Versandart:private-data then
    do:
      find gbuS_VersandArt
        where gbuS_Versandart.Firma      = {firma/sversart.fir V_BelegPos.Firma}
          and gbuS_Versandart.Versandart = input frame {&frame-name} V_BelegPos.uCI_VersandArt
        no-lock no-error.

      if not available gbuS_VersandArt then
      do:
        adm.method.cls.DMCMessageSvc:prpoInstance:lShowMessage
        ('s_trg00125':U,
         string(input frame {&FRAME-NAME} V_BelegPos.uCI_VersandArt)).

       run pa_UISvcApplyEventToWidgetByHandle
             ('entry':U,
              V_BelegPos.uCI_VersandArt:handle in frame {&FRAME-NAME}).

       {returnnoapply}.
      end.
      /* for Intrastat we need this, the information in V_BelegKopf is not corect in every case */
      gulVersendung = gbuS_VersandArt.Versendung.

      /* change to drop shipment? */
      if gbuS_VersandArt.Strecke
        and guiVertriebsweg <> {&uCI_VertriebswegStrecke} then
      do:
        {setwidgetattr
           "V_BelegPos.Lagerort"
           "screen-value"
           "string(?)"
           "in frame {&frame-name}"}.

        {fnarg
          pa_lUISvcDisableWidget
          "V_BelegPos.Lagerort:handle in frame {&frame-name}"}.

        guiVertriebsweg = {&uCI_VertriebswegStrecke}.

        /* Beim Wechsel der Versandart auf Streckengesch�ft soll der Kommissioniertzeit auf 0 gesetzt werden */

        {setwidgetattr
           "V_BelegPos.uCI_KommZeit"
           "screen-value"
           "'0'"
           "in frame {&FRAME-NAME}"}.

        apply 'leave':U to V_BelegPos.uCI_KommZeit in frame {&frame-name}.

        {fnarg
            pa_lUISvcDisableWidget
            "V_BelegPos.uCI_KommZeit:handle in frame {&frame-name}"}.
        {fnarg
          pa_lUISvcDisableWidget
          "V_BelegPos.uCI_KommZeiteinheit:handle in frame {&frame-name}"}.
      end.
      /* change to storage? */
      else if not gbuS_VersandArt.Strecke
        and guiVertriebsweg <> {&uCI_VertriebswegLager} then
      do:
        {fnarg
          pa_lUISvcEnableWidget
          "V_BelegPos.Lagerort:handle in frame {&frame-name}"}.

        /* Initialize the storage area */
        uiMRPArea = mawi.dispo.cls.MDCMRPAreaSvc:prpoInstance:iGetMRPAreaPart
                  (V_BelegPos.Artikel,
                   input frame {&frame-name} V_BelegPos.LagerOrt,
                   (if input frame {&frame-name} V_BelegPos.LagerOrt = ? then
                      V_BelegKopf.Lagergruppe
                    else
                      ?)).

        if V_BelegKopf.Lagerort <> ?
          and can-do('A,U,VUA,VUR,VFP':U,V_BelegPos.Belegart)
          and not V_BelegPos.Wertposition
          and not can-do({&pa_S_PTList_Set},string(S_Artikel.Artikelart))
          and mawi.lager.cls.MLCPartStAreaSvc:prpoInstance:lIsPartAvailableInStArea(V_BelegPos.Artikel,
                                                                                    V_BelegKopf.Lagerort) = yes then
          uiStoragearea = V_BelegKopf.LagerOrt.

        else if V_BelegKopf.Lagerort <> ?
          and vert.base.cls.VBCSalesDocSvc:prpoInstance:lMakesDocumentInventoryPostings(V_BelegPos.Belegart) = yes
          and not V_BelegPos.Wertposition
          and not can-do({&pa_S_PTList_Set},string(S_Artikel.Artikelart))
          and mawi.lager.cls.MLCPartStAreaSvc:prpoInstance:lCanPartBePostedInStArea(V_BelegPos.Artikel,
                                                                                    V_BelegKopf.Lagerort) = yes then
          uiStoragearea = V_BelegKopf.LagerOrt.

        else if V_BelegKopf.Lagerort = ?
          and not V_BelegPos.Wertposition
          and not can-do({&pa_S_PTList_Set},string(S_Artikel.Artikelart)) then
          uiStoragearea = mawi.dispo.cls.MDCMRPAreaSvc:prpoInstance:iGetMainStArea(V_BelegPos.Artikel, uiMRPArea).
        else
          uiStoragearea = ?.

        {setwidgetattr
           "V_BelegPos.LagerOrt"
           "screen-value"
           "string(uiStoragearea)"
           "in frame {&FRAME-NAME}"}.

        giLagergruppe = mawi.dispo.cls.MDCMRPAreaSvc:prpoInstance:iGetMRPAreaPart
                        (V_BelegPos.Artikel,
                         input frame {&frame-name} V_BelegPos.Lagerort).

        guiVertriebsweg = {&uCI_VertriebswegLager}.

        /* Beim Wechsel der Versandart auf Lager soll der Kommissioniertzeit wieder mit V_BelegKopf.uCI_KommZeit intialisiert werden */

        {setwidgetattr
           "V_BelegPos.uCI_KommZeit"
           "screen-value"
           "string(V_BelegKopf.uCI_KommZeit)"
           "in frame {&FRAME-NAME}"}.

        apply 'leave':U to V_BelegPos.uCI_KommZeit in frame {&frame-name}.

        {fnarg
            pa_lUISvcEnableWidget
            "V_BelegPos.uCI_KommZeit:handle in frame {&frame-name}"}.
        {fnarg
          pa_lUISvcEnableWidget
          "V_BelegPos.uCI_KommZeiteinheit:handle in frame {&frame-name}"}.
      end.

      {setwidgetattr
         "V_BelegPos.uCI_Versandart"
         "private-data"
         "string(input frame {&frame-name} V_BelegPos.uCI_Versandart)"}.

      &IF lookup ("VF_INTRA":U,"{&PA-OPTIONEN}":U) > 0 &THEN
        run set-attribute-list ('ChangeIntraStat=no':U).
        run pruefe-Intra.

        if guiVertriebsweg = {&uCI_VertriebswegStrecke} then
          assign
            gdStatistikwert   = 0
            gdbesondere_Menge = 0
            .
      &ENDIF

      &IF LOOKUP("U_CW":U,"{&PA-OPTIONEN}":U) > 0 &THEN
      if not gbuS_VersandArt.uCW_TourenPlanung then
        assign
          {setwidgetattr
             "V_BelegPos.uCW_Tour"
             "screen-value"
             "'':U"
             "in frame {&FRAME-NAME}"}
          {setwidgetattr
             "V_BelegPos.uCW_TransportNr"
             "screen-value"
             "'0':U"
             "in frame {&FRAME-NAME}"}
          .
      else
        uUpdateDateFields(V_BelegPos.uCI_Versandart:handle in frame {&FRAME-NAME}).
      &ENDIF

      &IF LOOKUP("U_CA":U,"{&PA-OPTIONEN}":U) > 0 &THEN
      /* Transport- und Kommissinierzeit aktualisieren? */
      if    can-do('U':U,V_BelegKopf.Belegart)
        and can-find(first USM_Versandparameter
                     where USM_Versandparameter.Company         = {firma/usmvers.fir pACConnectionSvc:prpcCompany})
        and adm.method.cls.DMCMessageSvc:prpoInstance:lShowMessage
              ('usvep000001':U) then
      do:

        find gbuV_BelegKopfAdr
          where gbuV_BelegKopfAdr.Firma      = V_BelegKopf.Firma
            and gbuV_BelegKopfAdr.Belegart   = V_BelegKopf.Belegart
            and gbuV_BelegKopfAdr.ReferenzNr = V_BelegKopf.ReferenzNr
            and gbuV_BelegKopfAdr.Typ        = 'L':U
          no-lock no-error.

        branche.vert.cls.UVC_CISalesDocumentSvc:prpoInstance:GetTransportTime
          (       V_BelegKopf.Kunde,
                  V_BelegPos.uCI_VersandArt:input-value,
                  V_BelegKopf.Lieferant,
                  V_BelegPos.LieferBedingung:input-value,
                  (if available gbuV_BelegKopfAdr then
                     gbuV_BelegKopfAdr.Staat
                   else
                     ?),
                  (if available gbuV_BelegKopfAdr then
                     gbuV_BelegKopfAdr.PLZ
                   else
                     ?),
           output giuTransportTime,
           output gcuTransportTimeUnit,
           output giuPickTime,
           output gcuPickTimeUnit).

        if giuTransportTime <> ? then
          assign
            {setwidgetattr
               "V_BelegPos.Transportzeit"
               "screen-value"
               "string(giuTransportTime)"}
            {setwidgetattr
               "V_BelegPos.Zeiteinheit"
               "screen-value"
               "string(gcuTransportTimeUnit)"}
            {setwidgetattr
               "gcTimeUnitCombo"
               "screen-value"
               "V_BelegPos.Zeiteinheit:screen-value"}
            {setwidgetattr
               "V_BelegPos.uCI_KommZeit"
               "screen-value"
               "string(giuPickTime)"}
            {setwidgetattr
               "V_BelegPos.uCI_KommZeiteinheit"
               "screen-value"
               "string(gcuPickTimeUnit)"}
            .

        {fnarg
          pa_lUISvcACMReplacementDisplay
          "frame {&frame-name}:handle"}.

      end.
      &ENDIF

    end.
&ENDIF

  {adm/template/incl/dt_uit01.if
     &UserExitName = "ON_LEAVE_OF_V_BelegPos_uCI_Versandart"}
end.

/* _UIB-CODE-BLOCK-END */
&ANALYZE-RESUME


&Scoped-define SELF-NAME V_BelegPos.uCI_Warenausgangstermin
&ANALYZE-SUSPEND _UIB-CODE-BLOCK _CONTROL V_BelegPos.uCI_Warenausgangstermin V-table-Win
on leave of V_BelegPos.uCI_Warenausgangstermin in frame F-Main /* Versandtermin */
do:
  {adm/template/incl/dt_uit00.if
     &UserExitName = "ON_LEAVE_OF_V_BelegPos_uCI_Warenausgangstermin"}

  {adm/template/incl/dt_viw03.if}

  {adm/template/incl/dt_uit01.if
     &UserExitName = "ON_LEAVE_OF_V_BelegPos_uCI_Warenausgangstermin"}
end.

/* _UIB-CODE-BLOCK-END */
&ANALYZE-RESUME


&Scoped-define SELF-NAME V_BelegPos.USTax_Override
&ANALYZE-SUSPEND _UIB-CODE-BLOCK _CONTROL V_BelegPos.USTax_Override V-table-Win
on value-changed of V_BelegPos.USTax_Override in frame F-Main /* abw Besteuerung */
do:
  {adm/template/incl/dt_uit00.if
     &UserExitName = "ON_VALUE-CHANGED_OF_V_BelegPos_USTax_Override"}

  run OnValue-ChangedOfUSTax_Override no-error.

  if error-status:error then
    {returnnoapply}.

  {adm/template/incl/dt_uit01.if
     &UserExitName = "ON_VALUE-CHANGED_OF_V_BelegPos_USTax_Override"}
end.

/* _UIB-CODE-BLOCK-END */
&ANALYZE-RESUME


&Scoped-define SELF-NAME V_BelegPos.USTax_TaxFree
&ANALYZE-SUSPEND _UIB-CODE-BLOCK _CONTROL V_BelegPos.USTax_TaxFree V-table-Win
on value-changed of V_BelegPos.USTax_TaxFree in frame F-Main /* steuerfrei */
do:
  {adm/template/incl/dt_uit00.if
     &UserExitName = "ON_VALUE-CHANGED_OF_V_BelegPos_USTax_TaxFree"}

  run OnValue-ChangedOfUSTax_TaxFree no-error.

  if error-status:error then
    {returnnoapply}.

  {adm/template/incl/dt_uit01.if
     &UserExitName = "ON_VALUE-CHANGED_OF_V_BelegPos_USTax_TaxFree"}
end.

/* _UIB-CODE-BLOCK-END */
&ANALYZE-RESUME


&Scoped-define SELF-NAME V_BelegPos_Steuer_Bez
&ANALYZE-SUSPEND _UIB-CODE-BLOCK _CONTROL V_BelegPos_Steuer_Bez V-table-Win
on value-changed of V_BelegPos_Steuer_Bez in frame F-Main /* Steuersatz */
do:

  define variable iTax as integer no-undo.

  {adm/template/incl/dt_uit00.if
     &UserExitName = "ON_VALUE-CHANGED_OF_V_BelegPos_Steuer_Bez"}

  if adm.config.cls.DCCAppConfigSvc:prpoInstance:lParameterValue ('VB_VATChangeable':U) then
  do:

    iTax = lookup(trim({getwidgetattr V_BelegPos_Steuer_Bez screen-value string}),gcSteuer).

    if iTax > 1 then
      assign
        gdSteuersatz = integer(entry(iTax,gcSteuersatzListe,',':U)) / {&pa_SB_TaxRateToListFactor}
        gcTaxOID     = entry(iTax,gcTaxOIDList,',':U)
        .

    else
      assign
        gdSteuersatz = 0
        gcTaxOID     = '':U
        .

    {adm/incl/d__duh00.if
       &Var1     = "gdSteuersatz"
       &WithFrame = "frame {&frame-name}"}

  end. /* if adm.config.cls.DCCAppConfigSvc:prpoInstance:lParameterValue ('VB_VATChangeable':U) then */

  {adm/template/incl/dt_uit01.if
     &UserExitName = "ON_VALUE-CHANGED_OF_V_BelegPos_Steuer_Bez"}
end. /* ON VALUE-CHANGED OF V_BelegPos_Steuer_Bez */

/* _UIB-CODE-BLOCK-END */
&ANALYZE-RESUME


&Scoped-define SELF-NAME V_BelegPos.Versandtermin
&ANALYZE-SUSPEND _UIB-CODE-BLOCK _CONTROL V_BelegPos.Versandtermin V-table-Win
on leave of V_BelegPos.Versandtermin in frame F-Main /* VersTermin */
do:
  {adm/template/incl/dt_uit00.if
     &UserExitName = "ON_LEAVE_OF_V_BelegPos_Versandtermin"}

  {adm/template/incl/dt_viw03.if}

  {adm/template/incl/dt_uit01.if
     &UserExitName = "ON_LEAVE_OF_V_BelegPos_Versandtermin"}
end.

/* _UIB-CODE-BLOCK-END */
&ANALYZE-RESUME


&Scoped-define SELF-NAME V_BelegPos.Wert_RZ_1
&ANALYZE-SUSPEND _UIB-CODE-BLOCK _CONTROL V_BelegPos.Wert_RZ_1 V-table-Win
on leave of V_BelegPos.Wert_RZ_1 in frame F-Main /* wertm R/Z */
do:
  {adm/template/incl/dt_uit00.if
     &UserExitName = "ON_LEAVE_OF_V_BelegPos_Wert_RZ_1"}

  run Preis_anzeigen (self:name) no-error.

  if error-status:error then
    {returnnoapply}.

  {adm/template/incl/dt_uit01.if
     &UserExitName = "ON_LEAVE_OF_V_BelegPos_Wert_RZ_1"}
end.

/* _UIB-CODE-BLOCK-END */
&ANALYZE-RESUME


&Scoped-define SELF-NAME V_BelegPos.Wert_RZ_2
&ANALYZE-SUSPEND _UIB-CODE-BLOCK _CONTROL V_BelegPos.Wert_RZ_2 V-table-Win
on leave of V_BelegPos.Wert_RZ_2 in frame F-Main /* wertm R/Z 2 */
do:
  {adm/template/incl/dt_uit00.if
     &UserExitName = "ON_LEAVE_OF_V_BelegPos_Wert_RZ_2"}

  run Preis_anzeigen (self:name) no-error.

  if error-status:error then
    {returnnoapply}.

  {adm/template/incl/dt_uit01.if
     &UserExitName = "ON_LEAVE_OF_V_BelegPos_Wert_RZ_2"}
end.

/* _UIB-CODE-BLOCK-END */
&ANALYZE-RESUME


&Scoped-define SELF-NAME V_BelegPos.Wert_RZ_5
&ANALYZE-SUSPEND _UIB-CODE-BLOCK _CONTROL V_BelegPos.Wert_RZ_5 V-table-Win
on leave of V_BelegPos.Wert_RZ_5 in frame F-Main /* wertm R/Z 5 */
do:
  {adm/template/incl/dt_uit00.if
     &UserExitName = "ON_LEAVE_OF_V_BelegPos_Wert_RZ_5"}

  run Preis_anzeigen (self:name) no-error.

  if error-status:error then
    {returnnoapply}.

  {adm/template/incl/dt_uit01.if
     &UserExitName = "ON_LEAVE_OF_V_BelegPos_Wert_RZ_5"}
end.

/* _UIB-CODE-BLOCK-END */
&ANALYZE-RESUME


&Scoped-define SELF-NAME V_BelegPos.Wert_RZ_Art_1
&ANALYZE-SUSPEND _UIB-CODE-BLOCK _CONTROL V_BelegPos.Wert_RZ_Art_1 V-table-Win
on leave of V_BelegPos.Wert_RZ_Art_1 in frame F-Main /* wRZ */
do:
  {adm/template/incl/dt_uit00.if
     &UserExitName = "ON_LEAVE_OF_V_BelegPos_Wert_RZ_Art_1"}

  if V_BelegPos.Wert_RZ_Art_1 <> V_BelegPos.Wert_RZ_Art_1:screen-value in frame {&FRAME-NAME} then
    {setwidgetattr
       "gc_Preisbezug-Rabattart-1"
       "screen-value"
       "vert.base.cls.VBCSalesDocSvc:prpoInstance:cSurchargeOnTotalPriceFlag(V_BelegPos.Wert_RZ_Art_1:screen-value in frame {&FRAME-NAME})"
       "in frame {&FRAME-NAME}"}.
  else
    {setwidgetattr
       "gc_Preisbezug-Rabattart-1"
       "screen-value"
       "gc_Preisbezug-Rabattart-1"
       "in frame {&FRAME-NAME}"}.

  run Preis_anzeigen (self:name) no-error.

  if error-status:error then
    {returnnoapply}.

  {adm/template/incl/dt_uit01.if
     &UserExitName = "ON_LEAVE_OF_V_BelegPos_Wert_RZ_Art_1"}
end.

/* _UIB-CODE-BLOCK-END */
&ANALYZE-RESUME


&Scoped-define SELF-NAME V_BelegPos.Wert_RZ_Art_2
&ANALYZE-SUSPEND _UIB-CODE-BLOCK _CONTROL V_BelegPos.Wert_RZ_Art_2 V-table-Win
on leave of V_BelegPos.Wert_RZ_Art_2 in frame F-Main /* wRZ2 */
do:
  {adm/template/incl/dt_uit00.if
     &UserExitName = "ON_LEAVE_OF_V_BelegPos_Wert_RZ_Art_2"}

  if V_BelegPos.Wert_RZ_Art_2 <> V_BelegPos.Wert_RZ_Art_2:screen-value in frame {&FRAME-NAME} then
    {setwidgetattr
       "gc_Preisbezug-Rabattart-2"
       "screen-value"
       "vert.base.cls.VBCSalesDocSvc:prpoInstance:cSurchargeOnTotalPriceFlag(V_BelegPos.Wert_RZ_Art_2:screen-value in frame {&FRAME-NAME})"
       "in frame {&FRAME-NAME}"}.
  else
    {setwidgetattr
       "gc_Preisbezug-Rabattart-2"
       "screen-value"
       "gc_Preisbezug-Rabattart-2"
       "in frame {&FRAME-NAME}"}.

  run Preis_anzeigen (self:name) no-error.

  if error-status:error then
    {returnnoapply}.

  {adm/template/incl/dt_uit01.if
     &UserExitName = "ON_LEAVE_OF_V_BelegPos_Wert_RZ_Art_2"}
end.

/* _UIB-CODE-BLOCK-END */
&ANALYZE-RESUME


&Scoped-define SELF-NAME V_BelegPos.Wunschtermin
&ANALYZE-SUSPEND _UIB-CODE-BLOCK _CONTROL V_BelegPos.Wunschtermin V-table-Win
on leave of V_BelegPos.Wunschtermin in frame F-Main /* Wunschtermin */
do:
  {adm/template/incl/dt_uit00.if
     &UserExitName = "ON_LEAVE_OF_V_BelegPos_Wunschtermin"}

  {adm/template/incl/dt_viw03.if}

  &IF LOOKUP("U_CI":U,"{&PA-OPTIONEN}":U) > 0 &THEN
  uUpdateDateFields(V_BelegPos.Wunschtermin:handle in frame {&FRAME-NAME}).
  &ELSE
  if date(V_BelegPos.Liefertermin:screen-value in frame {&frame-name}) = ? then
  do:

    {setwidgetattr
       "V_BelegPos.Versandtermin"
       "screen-value"
       "string(input frame {&frame-name} V_BelegPos.Wunschtermin - dynamic-function('pa_iCalendTransportTime':U in target-procedure, V_BelegPos.Firma, V_BelegKopf.Lagergruppe, input frame {&frame-name} V_BelegPos.Lagerort, integer(V_BelegPos.Transportzeit:screen-value in frame {&frame-name}), V_BelegPos.Zeiteinheit:screen-value in frame {&frame-name}, input frame {&frame-name} V_BelegPos.Wunschtermin, no), V_BelegPos.Versandtermin:format in frame {&frame-name})"
       "in frame {&frame-name}"}.

    if date(input frame {&frame-name} V_BelegPos.Versandtermin) < today then

      adm.method.cls.DMCMessageSvc:prpoInstance:lShowMessage(
        'v_bel00188':U,
        string(input frame {&frame-name} V_BelegPos.Versandtermin,'{&PA_DATEFORMAT}':U)).

  end.

  {fnarg
    pa_lUISvcDisplayInfoFieldOfWidget
    "V_BelegPos.Versandtermin:handle in frame {&frame-name}"}.
  &ENDIF

  {adm/template/incl/dt_uit01.if
     &UserExitName = "ON_LEAVE_OF_V_BelegPos_Wunschtermin"}
end. /* ON LEAVE OF V_BelegPos.Wunschtermin */

/* _UIB-CODE-BLOCK-END */
&ANALYZE-RESUME


&UNDEFINE SELF-NAME

&ANALYZE-SUSPEND _UIB-CODE-BLOCK _CUSTOM _MAIN-BLOCK V-table-Win 


/* ***************************  Main Block  *************************** */

&IF DEFINED(UIB_IS_RUNNING) <> 0 &THEN
  run dispatch in THIS-PROCEDURE ('initialize':U).
&ENDIF

  /************************ INTERNAL PROCEDURES ********************/

/* _UIB-CODE-BLOCK-END */
&ANALYZE-RESUME


/* **********************  Internal Procedures  *********************** */

&ANALYZE-SUSPEND _UIB-CODE-BLOCK _PROCEDURE adm-row-available V-table-Win  adm/support/proc/ds_rec00.p
procedure adm-row-available :
/* Description ---------------------------------------------------------------*/
/*                                                                            */
/* Dispatched to this procedure when the Record-Source has a new row          */
/* available.  This procedure tries to get the new row (or foreign keys)      */
/* from the  Record-Source and process it.                                    */
/*                                                                            */
/* Parameters ----------------------------------------------------------------*/
/*                                                                            */
/* <none>                                                                     */
/*                                                                            */
/*----------------------------------------------------------------------------*/

/*----------------------------------------------------------------------------*/
/* Processing                                                                 */
/*----------------------------------------------------------------------------*/

/* Define variables needed by this internal procedure.                        */

{adm/template/incl/row-head.i}

/* Create a list of all the tables that we need to get.                       */

{adm/template/incl/row-list.i "V_BelegKopf"}
{adm/template/incl/row-list.i "V_BelegPos"}

/* Get the record ROWID's from the RECORD-SOURCE.                             */

{adm/template/incl/row-get.i}

/* FIND each record specified by the RECORD-SOURCE.                           */

{adm/template/incl/row-find.i "V_BelegKopf"}
{adm/template/incl/row-find.i "V_BelegPos"}

/* Process the newly available records (i.e. display fields, open queries,    */
/* and/or pass records on to any RECORD-TARGETS).                             */

{adm/template/incl/row-end.i}

end procedure. /* adm-row-available */

/* _UIB-CODE-BLOCK-END */
&ANALYZE-RESUME

&ANALYZE-SUSPEND _UIB-CODE-BLOCK _PROCEDURE AssigningFieldValues V-table-Win 
procedure AssigningFieldValues :
/* Description ---------------------------------------------------------------*/
/*                                                                            */
/*  Assigning the field values                                                */
/*                                                                            */
/* Notes ---------------------------------------------------------------------*/
/*                                                                            */
/*  called by local-assign-statement, had been separated because procedure    */
/*  local-assign-statement grew too large                                     */
/*                                                                            */
/* Variables -----------------------------------------------------------------*/
/* cTimeUnitCombo     screen-value of combo-box                               */
/* lStorAreaChanged   flag if storage area has been changed                   */
/* lMRPRelease        MRP Release                                             */
/* iDecimalPlaces     decimal places from storage unit of measure             */
/* dQuantity          quantiy with correct decimal places                     */
/* dCalcQuotePrice    the new calculation quote price of V_BelegKalk records  */
/*----------------------------------------------------------------------------*/

define variable cTimeUnitCombo    as   character                 no-undo.
define variable lStorAreaChanged  as   logical                   no-undo.
define variable lMRPRelease       as   logical                   no-undo.
define variable iDecimalPlaces    like S_MengenEinheit.Nachkomma no-undo.
define variable dQuantity         like V_BelegPos.Menge          no-undo.
&IF lookup("VN_KALK","{&PA-OPTIONEN}") > 0 &THEN
  define variable dCalcQuotePrice like V_BelegKalk.Angebotspreis no-undo.
&ENDIF

if V_BelegPos.Satzart = 'A':U then
do:

  /* note if the storage area has been changed */

  if    V_BelegPos.Lagerort:hidden in frame {&frame-name} = no
    and input frame {&frame-name} V_BelegPos.LagerOrt    <> V_BelegPos.LagerOrt then

    lStorAreaChanged = yes.

  assign
    V_BelegPos.VME_Faktor                   = gdVME_Faktor
    V_BelegPos.Mengeneinheit                = giMengeneinheit
    V_BelegPos.Nachkomma                    = giNachkomma
    substring(V_BelegPos.Preisherkunft,1,1) = c_Preisherkunft-1
    substring(V_BelegPos.Preisherkunft,2,1) = c_Preisherkunft-2
    substring(V_BelegPos.Preisherkunft,3,1) = c_Preisherkunft-3
    substring(V_BelegPos.Preisherkunft,4,1) = c_Preisherkunft-4
    substring(V_BelegPos.Preisherkunft,5,1) = c_Preisherkunft-5
    substring(V_BelegPos.Preisherkunft,6,1) = c_Preisherkunft-6
    V_BelegPos.Einzelpreis_Zuschl           = TT_V_Preisfind.Einzelpreis_Zuschl
    V_BelegPos.Aktion                       = giAktion
    .

  /* Check whether discount / surcharge should be added on total price */

  if V_BelegPos.Wert_RZ_Art_1 <> V_BelegPos.Wert_RZ_Art_1:screen-value in frame {&FRAME-NAME} then
    V_BelegPos.isDiscSurOnTotalPrice_1 = TT_V_Preisfind.isDiscSurOnTotalPrice_1.

  if V_BelegPos.Wert_RZ_Art_2 <> V_BelegPos.Wert_RZ_Art_2:screen-value in frame {&FRAME-NAME} then
    V_BelegPos.isDiscSurOnTotalPrice_2 = TT_V_Preisfind.isDiscSurOnTotalPrice_2.

  if d_reserviert:hidden in frame {&frame-name} = no then

    dReserviertVME = input frame {&FRAME-NAME} d_reserviert.

  V_BelegPos.KO_Lagerort = giKO_Lagerort.

  if V_BelegPos.Lagerort:hidden in frame {&frame-name} = no then

    V_BelegPos.Lagerort = input frame {&frame-name} V_BelegPos.Lagerort.

  if V_BelegPos.MMM_CusRefOrder_ID:hidden in frame {&frame-name} = no then

    assign
      V_BelegPos.MMM_CusRefOrder_ID  = input frame {&frame-name} V_BelegPos.MMM_CusRefOrder_ID
      V_BelegPos.MMM_CusRefOrder_Obj = mawi.base.cls.MMCCROSvc:prpoInstance:cCroObj(V_BelegPos.MMM_CusRefOrder_ID)
      .

  if gcEAN:hidden in frame {&frame-name} = no then

    V_BelegPos.EAN = input frame {&frame-name} gcEAN.

  else

    V_BelegPos.EAN = gcEAN.

  if d_Menge:hidden in frame {&frame-name} = no then
  do:

    /* save the quantity with the right decimal places. Otherwise, round up   */

    if glToRecalculateQty = yes then
    do:

      if    available S_Artikel
        and V_BelegPos.Wertposition   = no
        and V_BelegPos.Satzart        = 'A':U
        and V_BelegPos.Mengeneinheit <> S_Artikel.LagerME then
      do:

        /* to determine the decimal places from LME --------------------------- */

        assign
          iDecimalPlaces = {fnarg
                             pa_iDyCchUnitOfMeasureDecimals
                             "pACConnectionSvc:prpcCompany,
                              S_Artikel.LagerME"}
          dQuantity      = (if  (input frame {&frame-name} d_Menge * gdVME_Faktor)
                              - truncate ((input frame {&frame-name} d_Menge * gdVME_Faktor),iDecimalPlaces) <> 0 then

                              round((input frame {&frame-name} d_Menge * gdVME_Faktor) + (5 / exp(10,iDecimalPlaces + 1)),
                                    iDecimalPlaces)

                            else
                              input frame {&FRAME-NAME} d_Menge * gdVME_Faktor)
          .

      end. /* if available S_Artikel ... */
      else

        dQuantity = input frame {&FRAME-NAME} d_Menge * gdVME_Faktor.

    end. /* if glToRecalculateQty.. */
    else
      dQuantity = V_BelegPos.Menge.

    V_BelegPos.Menge = dQuantity.

  end. /* if d_Menge:hidden in frame {&frame-name} = no then */

  if (    can-do({&pa_S_PTList_Set}, string(S_Artikel.ArtikelArt))
      and S_Artikel.fixSetPreis               = no
      and adm.config.cls.DCCAppConfigSvc:prpoInstance:lParameterValue
            ('VB_UseSetComponentsForPrice':U) = yes)
    or can-do({&pa_S_PTList_VariantPartTypes},string(S_Artikel.Artikelart)) then

    V_BelegPos.NormalPreis = TT_V_Preisfind.NormalPreis.

  /* generate Universal Product Code (UPC) respectively EAN ----------------- */

  if    not can-do(pa-disabled-fields,'{&PA-XBasisName}.gcEAN':U)
    and gcEAN:hidden in frame {&frame-name}    = no
    and can-do({&pa_M_PTList_StorageArea},string(S_Artikel.ArtikelArt))
    and gcEAN:sensitive in frame {&frame-name} = yes
    and input frame {&frame-name} gcEAN        > '':U then
  do:

    run erzeugeEAN no-error.

    if error-status:error then
      return 'adm-error':U.

  end. /* if available S_Artikel and not can-do ... */

  /* assign the changed tax code -------------------------------------------- */

  if adm.config.cls.DCCAppConfigSvc:prpoInstance:lParameterValue ('VB_VATChangeable':U) then
    assign
      V_BelegPos.Steuersatz   = gdSteuersatz
      V_BelegPos.S_Steuer_Obj = gcTaxOID
      .

  if gdTaxSum = ? then
    adm.method.cls.DMCMessageSvc:prpoInstance:showError
      ('v_ust00003':U,
       string(V_BelegPos.Belegnummer),
       string(V_BelegPos.PositionsNr),
       {fnarg
         pa_cReposFieldInformationByName
         "'V_BelegPos':U,
          'USTax_TaxAmount':U,
          'LABEL':U"}).

  assign
    V_BelegPos.USTax_TaxBase       = gdTaxBase
    V_BelegPos.USTax_TaxableAmount = gdTaxableAmount
    V_BelegPos.USTax_TaxAmount     = gdTaxAmount
    V_BelegPos.USTax_TaxRate       = gdTaxRate
    .

  /* TASK V_-F-CALL-120 wegen Progress-Meldung (275)                          */
  /* Die folgende Zuweisung nicht l�schen / don't delete the assignment       */

  if (   V_BelegPos.Wunschtermin:screen-value in frame {&FRAME-NAME} begins '.':U
      or V_BelegPos.Wunschtermin:screen-value in frame {&FRAME-NAME} = ' ':U) then

    {setwidgetattr
       "V_BelegPos.Wunschtermin"
       "screen-value"
       "string(V_BelegPos.Wunschtermin)"
       "in frame {&FRAME-NAME}"}.

  assign
    cTimeUnitCombo = {getwidgetattr gcTimeUnitCombo screen-value string}
    {setwidgetattr
       "V_BelegPos.Zeiteinheit"
       "screen-value"
       "cTimeUnitCombo"
       "in frame {&FRAME-NAME}"}
    V_BelegPos.Zeiteinheit   = input frame {&FRAME-NAME} V_BelegPos.Zeiteinheit
    V_BelegPos.Transportzeit = input frame {&FRAME-NAME} V_BelegPos.Transportzeit
    .

  if V_BelegPos.Menge = 0 then

    adm.method.cls.DMCMessageSvc:prpoInstance:lShowMessage
      ('v_bel00129':U,
       string(V_BelegPos.Belegnummer),
       string(V_BelegPos.PositionsNr)).

  &IF lookup("M_STUELI","{&PA-OPTIONEN}") > 0 &THEN

    if    available S_Artikel
      and can-do({&pa_S_PTList_Set}, string(S_Artikel.ArtikelArt))
      and glSetCalledByMenu = no then
    do:

      if    V_BelegPos.Wertposition = no
        and V_BelegPos.offen        = yes then

        run PruefeSetBestandteile.

      /* this viewer ist used for orders and here the MRPRelease is important */
      /* the field for reservating a quantity for a member of a set must be   */
      /* opened and closed depending on the screen-value of the toggle        */

      run request-attribute( this-procedure,
                            'record-source':U,
                            'MRPRelease':U).


      lMRPRelease = (    V_BelegPos.Satzart      = 'A':U
                     and V_BelegPos.Wertposition = no
                     and return-value            = 'yes':U).

      run ProcessSET(lMRPRelease) no-error. /* screen-value is tranfered to v_pstu00.w */

      if error-status:error then
        return 'adm-error':U.

      /* in case that the storage area of a set component has been changed to */
      /* one of another stockvalue group we have to update the average price  */

      gdAverageCosts = vert.base.cls.VBCSalesDocSvc:prpoInstance:dGetOriginAverageCosts(V_BelegPos.V_BelegPos_Obj).

    end. /* if available S_Artikel and ... */

  &ENDIF

  &IF lookup("VN_KALK","{&PA-OPTIONEN}") > 0 &THEN

    /* if we can find a quotation costing for the current doc. line that has at     */
    /* least one record with valuation rate 'average price' then it is possible     */
    /* that the average price will change due to a changed stock value group of     */
    /* the new mrp area's...                                                        */
    /* - main storage area (for quotation costing purchased parts)                  */
    /* - production st. area warehouse out (for quotation costing production parts) */
    /* ask user if he wants to recalculate the quotation costing                    */
    /* automatic adoption of calc quote price (via v_wbel00.lib) only if the        */
    /* price has been adopted before                                                */

    if    lStorAreaChanged   = yes
      and V_BelegKopf.Brutto = no
      and c_Preisherkunft-1  = 'A':U
      and can-find(first V_BelegKalk
                     where V_BelegKalk.Firma       = V_BelegPos.Firma
                       and V_BelegKalk.Belegart    = V_BelegPos.BelegArt
                       and V_BelegKalk.ReferenzNr  = V_BelegPos.ReferenzNr
                       and V_BelegKalk.LfdNr_SR    = V_BelegPos.LfdNr_SR
                       and V_BelegKalk.PositionsNr = V_BelegPos.PositionsNr
                       and V_BelegKalk.Wertansatz  = 1)
      and adm.method.cls.DMCMessageSvc:prpoInstance:lShowMessage('v_ang00020':U) = yes then
    do:

      dCalcQuotePrice = vert.base.cls.VBCSalesDocSvc:prpoInstance:dRecalcQuotationCosting
                          (V_BelegPos.V_BelegPos_Obj).

      run use-Angebotspreis(string(round((dCalcQuotePrice / V_BelegKopf.Kurs),
                                         V_BelegKopf.WaehrungNK)
                                   * 100)).

    end. /* if ... and can-find(first V_BelegKalk... */

  &ENDIF

  /* auto-check of minimum margin --------------------------------------------- */
  /* Procedure ProcessSET must have been passed at this place because the       */
  /* storage area of a set component and with that the average price could have */
  /* been changed due to another stock value group.                             */

  if    glSpanne                           =  yes
    and V_BelegPos.Wertposition            =  no
    and (   V_BelegPos.Herk_Belegart       =  ?
         or V_BelegPos.Herk_Belegart       =  '':U)
    and input frame {&frame-name} d_Menge <> 0 then

    run Mindestspanne('yes':U).

end. /* if V_BelegPos.Satzart = 'A':U */

end procedure. /* AssigningFieldValues */

/* _UIB-CODE-BLOCK-END */
&ANALYZE-RESUME

&ANALYZE-SUSPEND _UIB-CODE-BLOCK _PROCEDURE CheckBaseAndMinimumQuantity V-table-Win 
procedure CheckBaseAndMinimumQuantity private :
/* Description ---------------------------------------------------------------*/
/*                                                                            */
/* check base- and minimum quantity of customer-part relation                 */
/*                                                                            */
/* Notes ---------------------------------------------------------------------*/
/*                                                                            */
/* had to be outsourced because local-assign-statement became too large       */
/*                                                                            */
/* Variables -----------------------------------------------------------------*/
/* cUnitShortBez      short description of quantity unit                      */
/* iUnitOfMeasureDec  number of decimals of a quantity unit                   */
/*----------------------------------------------------------------------------*/

define variable cUnitShortBez     like S_MengeneinheitSpr.KurzBez no-undo.
define variable iUnitOfMeasureDec as   integer                    no-undo.

define buffer bS_ArtKunde for S_ArtKunde.

if    V_BelegPos.Satzart                     = 'A':U
  and V_BelegPos.Wertposition                = no
  and d_Menge:hidden in frame {&frame-name}  = no
  and input frame {&frame-name} d_Menge     <> 0 then
do:

  assign
    iUnitOfMeasureDec = {fnarg
                          pa_iDyCchUnitOfMeasureDecimals
                          "pACConnectionSvc:prpcCompany,
                           S_Artikel.LagerME"}
    cUnitShortBez     = {fnarg
                          pa_cDyCchUnitOfMeasureDesc
                          "pACConnectionSvc:prpcCompany,
                           S_Artikel.LagerME,
                           pACConnectionSvc:prpcLanguage,
                           {&pa_CchShortCut}"}
    .

  find bS_ArtKunde
    where bS_ArtKunde.Firma   = {firma/sartkund.fir pACConnectionSvc:prpcCompany}
      and bS_ArtKunde.Kunde   = V_BelegKopf.Kunde
      and bS_ArtKunde.Artikel = V_BelegPos.Artikel
    no-lock no-error.

  if available bS_ArtKunde then
  do:

    if    bS_ArtKunde.Grundmenge                  <> 0
      and bS_ArtKunde.GrundmengeBeachten           = yes
      and d_Menge:sensitive in frame {&frame-name} = yes
      and (  input frame {&frame-name} d_Menge * gdVME_Faktor / bS_ArtKunde.Grundmenge)
           - truncate(input frame {&frame-name} d_Menge * gdVME_Faktor / bS_ArtKunde.Grundmenge,0) <> 0
      and adm.method.cls.DMCMessageSvc:prpoInstance:lShowMessage
            ('v_bel00025':U,
             string(bS_ArtKunde.Grundmenge,
                    entry(iUnitOfMeasureDec + 1,
                          {&pa_Mengeneingabeformat},{&pa-Delimiter4})),
             cUnitShortBez,
             string(bS_ArtKunde.Grundmenge / gdVME_Faktor,
                    entry(giNachkomma + 1,
                          {&pa_Mengeneingabeformat},{&pa-Delimiter4})),
             c_text-VME) = yes then
    do:

      {setwidgetattr
         "d_Menge"
         "screen-value"
         "string(bS_ArtKunde.Grundmenge / gdVME_Faktor * (truncate(input frame {&frame-name} d_Menge * gdVME_Faktor / bS_ArtKunde.Grundmenge, 0) + 1))"
         "in frame {&FRAME-NAME}"}.

      return error.

    end. /* if bS_ArtKunde.Grundmenge <> 0 */

    if    bS_ArtKunde.Mindestmenge                         <> 0
      and d_Menge:sensitive in frame {&frame-name}          = yes
      and round((input frame {&frame-name} d_Menge * gdVME_Faktor) + (5 / exp(10,giNachkomma + 1)),
                giNachkomma) < bS_ArtKunde.Mindestmenge
      and adm.method.cls.DMCMessageSvc:prpoInstance:lShowMessage
            ('v_bel00026':U,
             string(bS_ArtKunde.Mindestmenge,
                    entry(iUnitOfMeasureDec + 1,
                          {&pa_MengenEingabeFormat},{&pa-Delimiter4})),
             cUnitShortBez,
             string(bS_ArtKunde.Mindestmenge / gdVME_Faktor,
                    entry(giNachkomma + 1,
                          {&pa_Mengeneingabeformat},{&pa-Delimiter4})),
             c_text-VME) = yes then

      return error.

  end. /* if available bS_ArtKunde then */

end. /* if V_BelegPos.Satzart = 'A':U and ... */

end procedure. /* CheckBaseAndMinimumQuantity */

/* _UIB-CODE-BLOCK-END */
&ANALYZE-RESUME

&ANALYZE-SUSPEND _UIB-CODE-BLOCK _PROCEDURE display-InfoFields V-table-Win  adm/support/proc/ds_inf02.p
procedure display-InfoFields :
/* Description ---------------------------------------------------------------*/
/*                                                                            */
/* Display Infofields                                                         */
/*                                                                            */
/* Parameters ----------------------------------------------------------------*/
/*                                                                            */
/* pcFields    list of fields to display                                      */
/*                                                                            */
/*----------------------------------------------------------------------------*/

define input parameter pcFields as character no-undo.

do with frame {&Frame-Name}:

  if can-do(pcFields,'V_BelegPos.LieferBedingung':U) then
    if V_BelegPos_LieferBedingung_Info:private-data <> V_BelegPos.LieferBedingung:screen-value then
    do:

      if input frame {&Frame-Name} V_BelegPos.LieferBedingung = '':U then

        assign
          {setwidgetattr
             "V_BelegPos_LieferBedingung_Info"
             "private-data"
             "'':U"}
          {setwidgetattr
             "V_BelegPos_LieferBedingung_Info"
             "screen-value"
             "'':U"}
          V_BelegPos_LieferBedingung_Info
          .

      else
      do:

        V_BelegPos_LieferBedingung_Info
          = {fnarg
              pa_cDyCchTermsOfDeliveryDesc
              "pa-Firma,
               input frame {&Frame-Name} V_BelegPos.LieferBedingung,
               pa-Sprache"}.

        if V_BelegPos_LieferBedingung_Info <> ? then
          {setwidgetattr
             "V_BelegPos_LieferBedingung_Info"
             "private-data"
             "V_BelegPos.LieferBedingung:screen-value"}.

        else
          assign
            {setwidgetattr
               "V_BelegPos_LieferBedingung_Info"
               "private-data"
               "string(?)"}

            V_BelegPos_LieferBedingung_Info = '':U
            .

        {setwidgetattr
           "V_BelegPos_LieferBedingung_Info"
           "screen-value"
           "V_BelegPos_LieferBedingung_Info"}.

      end.

    end.

  if can-do(pcFields,'V_BelegPos.uCI_VersandArt':U) then
    if V_BelegPos_uCI_VersandArt_Info:private-data <> V_BelegPos.uCI_VersandArt:screen-value then
    do:

      if input frame {&Frame-Name} V_BelegPos.uCI_VersandArt = '':U then

        assign
          {setwidgetattr
             "V_BelegPos_uCI_VersandArt_Info"
             "private-data"
             "'':U"}
          {setwidgetattr
             "V_BelegPos_uCI_VersandArt_Info"
             "screen-value"
             "'':U"}
          V_BelegPos_uCI_VersandArt_Info
          .

      else
      do:

        V_BelegPos_uCI_VersandArt_Info
          = {fnarg
              pa_cDyCchShippingTypeDesc
              "pa-Firma,
               input frame {&Frame-Name} V_BelegPos.uCI_VersandArt,
               pa-Sprache"}.

        if V_BelegPos_uCI_VersandArt_Info <> ? then
          {setwidgetattr
             "V_BelegPos_uCI_VersandArt_Info"
             "private-data"
             "V_BelegPos.uCI_VersandArt:screen-value"}.

        else
          assign
            {setwidgetattr
               "V_BelegPos_uCI_VersandArt_Info"
               "private-data"
               "string(?)"}

            V_BelegPos_uCI_VersandArt_Info = '':U
            .

        {setwidgetattr
           "V_BelegPos_uCI_VersandArt_Info"
           "screen-value"
           "V_BelegPos_uCI_VersandArt_Info"}.

      end.

    end.

end. /* do with frame */

/* User Exits */

{&{&PA-XBasisName}_C_Display-InfoFields}
{&{&PA-XBasisName}_U_Display-InfoFields}
{&{&PA-XBasisName}_Q_Display-InfoFields}
{&{&PA-XBasisName}_Display-InfoFields}
{&{&PA-XBasisName}_Y_Display-InfoFields}

return.

end procedure. /* display-InfoFields */

/* _UIB-CODE-BLOCK-END */
&ANALYZE-RESUME

&ANALYZE-SUSPEND _UIB-CODE-BLOCK _PROCEDURE get-Belegnummer V-table-Win 
procedure get-Belegnummer :
/* Description ---------------------------------------------------------------*/
/*                                                                            */
/* retrieve document number of position                                       */
/*                                                                            */
/*----------------------------------------------------------------------------*/

if available V_BelegKopf then
  return string(V_BelegKopf.Belegnummer).
else
  return ?.

end procedure.

/* _UIB-CODE-BLOCK-END */
&ANALYZE-RESUME

&ANALYZE-SUSPEND _UIB-CODE-BLOCK _PROCEDURE get-DynamicAvailableCheck V-table-Win 
procedure get-DynamicAvailableCheck :
/* Description ---------------------------------------------------------------*/
/*                                                                            */
/*                                                                            */
/*                                                                            */
/*----------------------------------------------------------------------------*/

if glNettableStorageArea = yes then

  return 'yes':U.

else

  return 'no':U.

end procedure. /* get-DynamicAvailableCheck */

/* _UIB-CODE-BLOCK-END */
&ANALYZE-RESUME

&ANALYZE-SUSPEND _UIB-CODE-BLOCK _PROCEDURE local-add-record V-table-Win 
procedure local-add-record :
/* Description ---------------------------------------------------------------*/
/*                                                                            */
/* Super Override                                                             */
/*                                                                            */
/*----------------------------------------------------------------------------*/

  run dispatch('add-record':U).

  if return-value <> 'adm-error':U then
  do:

    /* If the consignment storage area of the doc. header couldn't be assigned    */
    /* to the line, ask the user whether it is still desired to create a line     */
    /* without consignment storage area or not.                                   */

    if    available V_BelegPos
      and V_BelegKopf.Belegart      = 'U':U
      and V_BelegKopf.ConsigStorAr <> ?
      and V_BelegPos.LagerOrt      <> ?
      and V_BelegPos.KO_LagerOrt    = ? then

      adm.method.cls.DMCMessageSvc:prpoInstance:lShowMessage
        ('v_bel00139':U,
         string(V_BelegPos.PositionsNr),
         V_BelegPos.Artikel,
         string(V_BelegKopf.ConsigStorAr)).

  end.

end procedure. /* local-add-record */

/* _UIB-CODE-BLOCK-END */
&ANALYZE-RESUME

&ANALYZE-SUSPEND _UIB-CODE-BLOCK _PROCEDURE local-apply-layout V-table-Win 
procedure local-apply-layout :
/* Description ---------------------------------------------------------------*/
/*                                                                            */
/* Super Override                                                             */
/*                                                                            */
/*----------------------------------------------------------------------------*/

/* Code placed here will execute PRIOR to standard behavior ------------------*/

/* Execute standard behavior -------------------------------------------------*/

run dispatch('apply-layout':U).

/* Code placed here will execute AFTER standard behavior ---------------------*/

if return-value <> 'adm-error':U then do:

  {&{&PA-XBasisName}_C_local-apply-layout}
  {&{&PA-XBasisName}_U_local-apply-layout}
  {&{&PA-XBasisName}_Q_local-apply-layout}
  {&{&PA-XBasisName}_local-apply-layout}
  {&{&PA-XBasisName}_Y_local-apply-layout}

end.

end procedure. /* local-apply-layout */

/* _UIB-CODE-BLOCK-END */
&ANALYZE-RESUME

&ANALYZE-SUSPEND _UIB-CODE-BLOCK _PROCEDURE local-assign-record V-table-Win 
procedure local-assign-record :
/* Description ---------------------------------------------------------------*/
/*                                                                            */
/* Super Override                                                             */
/*                                                                            */
/*----------------------------------------------------------------------------*/

define variable hFocus      as handle    no-undo.
define variable cMRPRelease as character no-undo.

&IF "{&pa_S_F_EcoTax}":U = "1":U &THEN

  if pACConnectionSvc:prpcLocalization = 'F':U then
  do:

    if input frame {&FRAME-NAME} V_BelegPos.Wert_RZ_5 <> TT_V_Preisfind.Wert_RZ_5 then
      apply 'leave':U to V_BelegPos.Wert_RZ_5 in frame {&FRAME-NAME}.

    if    V_BelegKopf.F_EcoTax                                 = yes
      and gcFEcoTaxOrigin:screen-value in frame {&FRAME-NAME} <> 'M':U
      and S_Artikel.F_EcoTax                                   = yes
      and S_Artikel.SBM_F_EcoCode_Obj                          = '':U
      and not can-do({&pa_S_PTList_Set}, string(S_Artikel.ArtikelArt,'99':U))
      and not can-find(first SBT_F_EcoComponent
                         where SBT_F_EcoComponent.Owning_Obj = V_BelegPos.V_BelegPos_Obj) then
    do:

      adm.method.cls.DMCMessageSvc:prpoInstance:lShowMessage
        ('v_ecof0001':U,
         V_BelegPos.Artikel,
         string(V_BelegPos.Belegnummer)).

      run pa_UISvcApplyEventToWidgetByHandle
            ('entry':U,
             V_BelegPos.Wert_RZ_5:handle in frame {&FRAME-NAME}).

      return 'adm-error':U.

    end. /* if V_BelegKopf.F_EcoTax = yes */

  end. /* if pACConnectionSvc:prpcLocalization = 'F':U */

&ENDIF

glVariantenStart = no.

if    can-do('A,U':U,V_BelegPos.BelegArt)
  and V_BelegPos.WertPosition = yes
  and input frame {&frame-name} V_BelegPos.Wunschtermin < today
  and adm.method.cls.DMCMessageSvc:prpoInstance:lShowMessage('v_bel00305':U) = no then
do:

  run pa_UISvcApplyEventToWidgetByHandle
        ('entry':U,
         V_BelegPos.Wunschtermin:handle in frame {&frame-name}).
  return 'adm-error':U.

end. /* if can-do('A,U':U,V_BelegPos.BelegArt) */

/* start pricing unconditionally -------------------------------------------- */

if V_BelegPos.Satzart = 'A':U then
do:

  hFocus = {focus}.

  if valid-handle (hFocus) then

    if can-do('d_Menge,Gewicht,Einzelpreis,Wert_RZ_1,Wert_RZ_2,Proz_RZ_1,Proz_RZ_2,Proz_RZ_3':U,{focus name}) then

      apply 'leave':U to hFocus.

    else

      apply 'leave':U to d_Menge in frame {&frame-name}.

  /* check if total price fits into the format */

  if abs(d_Gesamtpreis) > abs(gdTotalPriceMax) then

    return 'adm-error':U.

  if V_BelegPos.Einzelpreis:hidden in frame {&frame-name} = yes then

    {setwidgetattr
       "V_BelegPos.Einzelpreis"
       "screen-value"
       "string(V_BelegPos.Einzelpreis, entry(V_BelegKopf.WaehrungNK + 1,{&pa_WertGesamtFormat},{&pa-Delimiter4}))"
       "in frame {&frame-name}"}.

  if input frame {&frame-name} V_BelegPos.Einzelpreis <> TT_V_Preisfind.Einzelpreis then

    apply 'leave':U to V_BelegPos.Einzelpreis in frame {&frame-name}.

  if V_BelegPos.Wert_RZ_1:hidden in frame {&frame-name} = yes then

    {setwidgetattr
       "V_BelegPos.Wert_RZ_1"
       "screen-value"
       "string(V_BelegPos.Wert_RZ_1, entry(V_BelegKopf.WaehrungNK + 1,{&pa_WertGesamtFormat},{&pa-Delimiter4}))"
       "in frame {&frame-name}"}.

  if input frame {&frame-name} V_BelegPos.wert_RZ_1 <> TT_V_Preisfind.Wert_RZ_1 then

    apply 'leave':U to V_BelegPos.wert_RZ_1 in frame {&frame-name}.

  if V_BelegPos.Wert_RZ_2:hidden in frame {&frame-name} = yes then

    {setwidgetattr
       "V_BelegPos.Wert_RZ_2"
       "screen-value"
       "string(V_BelegPos.Wert_RZ_2, entry(V_BelegKopf.WaehrungNK + 1,{&pa_WertGesamtFormat},{&pa-Delimiter4}))"
       "in frame {&frame-name}"}.

  if input frame {&frame-name} V_BelegPos.wert_RZ_2 <> TT_V_Preisfind.Wert_RZ_2 then

    apply 'leave':U to V_BelegPos.wert_RZ_2 in frame {&frame-name}.

  if V_BelegPos.proz_RZ_1:hidden in frame {&frame-name} = yes then

    {setwidgetattr
       "V_BelegPos.proz_RZ_1"
       "screen-value"
       "string(V_BelegPos.proz_RZ_1, V_BelegPos.proz_RZ_1:format in frame {&frame-name})"
       "in frame {&frame-name}"}.

  if V_BelegPos.Satzart                                 = 'A':U
    and input frame {&frame-name} V_BelegPos.proz_RZ_1 <> TT_V_Preisfind.proz_RZ_1 then

    apply 'leave':U to V_BelegPos.proz_RZ_1 in frame {&frame-name}.

  if V_BelegPos.proz_RZ_2:hidden in frame {&frame-name} = yes then

    {setwidgetattr
       "V_BelegPos.proz_RZ_2"
       "screen-value"
       "string(V_BelegPos.proz_RZ_2, V_BelegPos.proz_RZ_2:format in frame {&frame-name})"
       "in frame {&frame-name}"}.

  if input frame {&frame-name} V_BelegPos.proz_RZ_2 <> TT_V_Preisfind.proz_RZ_2 then

    apply 'leave':U to V_BelegPos.proz_RZ_2 in frame {&frame-name}.

  if V_BelegPos.proz_RZ_3:hidden in frame {&frame-name} = yes then

    {setwidgetattr
       "V_BelegPos.proz_RZ_3"
       "screen-value"
       "string(V_BelegPos.proz_RZ_3, V_BelegPos.proz_RZ_3:format in frame {&frame-name})"
       "in frame {&frame-name}"}.

  if input frame {&frame-name} V_BelegPos.proz_RZ_3 <> TT_V_Preisfind.proz_RZ_3 then

    apply 'leave':U to V_BelegPos.proz_RZ_3 in frame {&frame-name}.

end. /* if V_BelegPos.Satzart = 'A':U */

glVariantenStart = yes.

run request-attribute( this-procedure,
                    'record-source':U,
                    'MRPRelease':U).

cMRPRelease = return-value.

glMRPRelease = (if cMRPRelease = ? then
                  V_BelegPos.MRPRelease
                else 
                  cMRPRelease = 'yes':U).

if (not glMRPRelease) then
  {setwidgetattr
     "d_reserviert"
     "screen-value"
     "'0'"}.

&IF LOOKUP("U_WMS":U,"{&PA-OPTIONEN}":U) > 0 &THEN
if V_BelegKopf.uCI_Nullmenge
  and branche.gateway.cls.UGC_CIWarehouseManagementSystem:prpoInstance:lIsWMSSA(input frame {&frame-name} V_BelegPos.LagerOrt) then
do:

  {adm/incl/d__spr00.if
   &Tabelle = "S_BelegartSpr"
   &Selekt  = "where  S_BelegartSpr.Belegart = V_BelegKopf.Belegart"
   &Sprache = "pACConnectionSvc:prpcLanguage"
  }

  adm.method.cls.DMCMessageSvc:prpoInstance:showError
    ('ugwms00072':U,
     S_BelegartSpr.Bezeichnung,
     string(V_BelegKopf.BelegNummer),
     string(V_BelegPos.PositionsNr)).

end. /* if V_BelegKopf.uCI_Nullmenge */
&ENDIF

run dispatch in this-procedure ('assign-record':U).

if return-value <> 'adm-error':U then
do:

  if V_BelegPos.Satzart = 'A':U then

    assign
      V_BelegPos.wert_RZ_1               = TT_V_Preisfind.wert_RZ_1
      V_BelegPos.wert_RZ_2               = TT_V_Preisfind.wert_RZ_2
      .

  &IF "{&pa_S_F_EcoTax}":U = "1":U &THEN

    if pACConnectionSvc:prpcLocalization = 'F':U then
      V_BelegPos.Wert_RZ_5 = TT_V_Preisfind.Wert_RZ_5.

  &ENDIF

end. /* if return-value <> 'adm-error':U then */

end procedure.

/* _UIB-CODE-BLOCK-END */
&ANALYZE-RESUME

&ANALYZE-SUSPEND _UIB-CODE-BLOCK _PROCEDURE local-assign-statement V-table-Win 
procedure local-assign-statement :
/* Description ---------------------------------------------------------------*/
/*                                                                            */
/* Super Override                                                             */
/*                                                                            */
/*----------------------------------------------------------------------------*/

/* code had to be transfered to an include due to 32K-limit if AppBuilder     */
{vert/incl/v_wbel33.if}

end procedure.

/* _UIB-CODE-BLOCK-END */
&ANALYZE-RESUME

&ANALYZE-SUSPEND _UIB-CODE-BLOCK _PROCEDURE local-cancel-record V-table-Win 
procedure local-cancel-record :
/* Description ---------------------------------------------------------------*/
/*                                                                            */
/* Super Override                                                             */
/*                                                                            */
/*----------------------------------------------------------------------------*/

/* If the serial numbers were changed, but you cancel, they were anyhow       */
/* created an Context, which must be unlocked                                 */

if    available V_BelegPos
  and pACConnectionSvc:lIsLockContextAvailable(V_BelegPos.V_BelegPos_Obj)
  and V_BelegPos.AenderungZeit <> '.':U then

  pACConnectionSvc:UnlockContext(V_BelegPos.V_BelegPos_Obj).

run dispatch in this-procedure ('cancel-record':U).

if return-value <> 'ADM-ERROR':U then
do:

  run get-attribute ('auto-exit':U).

  if return-value = 'yes':U then

    run dispatch ('exit':U).

  glToRecalculateQty = no.

end. /* if return-value <> 'ADM-ERROR':U then */

end procedure.

/* _UIB-CODE-BLOCK-END */
&ANALYZE-RESUME

&ANALYZE-SUSPEND _UIB-CODE-BLOCK _PROCEDURE local-disable-fields V-table-Win 
procedure local-disable-fields :
/* Description ---------------------------------------------------------------*/
/*                                                                            */
/* Super Override                                                             */
/*                                                                            */
/*----------------------------------------------------------------------------*/

run dispatch in this-procedure ('disable-fields':U).

if return-value <> 'adm-error':U then
do:

  assign
    glNewPosition          = no
    glFolgeteile           = no
    glSetCalledByMenu      = no
    glInUpdate             = no
    glCheckAdditionalParts = no
    .

  {adm/incl/d__dab00.if
     &Var1      = "V_BelegPos.Lagerort"
     &Var2      = "giKO_Lagerort"
     &Var3      = "d_Menge"
     &Var4      = "gcEAN"
     &WithFrame = "frame {&FRAME-NAME}"}

  {fnarg
    pa_lUISvcDisableWidget
      "btnVME:handle in frame {&frame-name}"}.

  run set-attribute-list ('ChangeSalesUnit=no':U).
  run set-attribute-list ('ChangeSerialnumber=no':U).
  run set-attribute-list ('ChangePackaging=no':U).
  run set-attribute-list ('ChangeCostUnit=no':U).
  run set-attribute-list ('ChangeIntraStat=no':U).
  run set-attribute-list ('ChangeLandedPrice=no':U).
  run set-attribute-list ('AdditionalPart=no':U).
  run set-attribute-list ('CheckMargin=no':U).
  run set-attribute-list ('ProdOrderSim=no':U).
  run set-attribute-list ('ConsignmentStock=no':U).
  run set-attribute-list ('ChangeProdConfig=no':U).
  run set-attribute-list ('CheckAvailability=no':U).
  run set-attribute-list ('ChangeStock=no':U).

  run set-link-attribute in adm-broker-hdl (this-procedure,
                                            'container-source':U,
                                            'Calculation=no':U).

  run notify('open-query,record-target':U).

  {fnarg
    pa_lUISvcDisableWidget
      "V_BelegPos.Transportzeit:handle in frame {&frame-name}"}.

  {fnarg
    pa_lUISvcDisableWidget
      "gcTimeUnitCombo:handle in frame {&frame-name}"}.

end. /* if return-value <> 'ADM-ERROR':U then */

end procedure.

/* _UIB-CODE-BLOCK-END */
&ANALYZE-RESUME

&ANALYZE-SUSPEND _UIB-CODE-BLOCK _PROCEDURE local-display-fields V-table-Win 
procedure local-display-fields :
/* Description ---------------------------------------------------------------*/
/*                                                                            */
/* Super Override                                                             */
/*                                                                            */
/*----------------------------------------------------------------------------*/

/* code had to be transfered to an include due to 32K-limit if AppBuilder     */
  {vert/incl/v_wbel35.if}

end procedure.

/* _UIB-CODE-BLOCK-END */
&ANALYZE-RESUME

&ANALYZE-SUSPEND _UIB-CODE-BLOCK _PROCEDURE local-enable-fields V-table-Win 
procedure local-enable-fields :
/* Description ---------------------------------------------------------------*/
/*                                                                            */
/* Super Override                                                             */
/*                                                                            */
/*----------------------------------------------------------------------------*/

define variable lAlreadyEnabled as logical no-undo.

/* check if the tax territories of the tax relevant country are valid on the  */
/* reference date, otherwise the combo with the tax codes could not be created*/

stamm.base.cls.SBCTaxMasterFilesSvc:prpoInstance:CheckTerritoryStructureIsValid
  (vert.base.cls.VBCSalesDocSvc:prpoInstance:tGetReferenceDate(buffer V_BelegKopf),
   V_BelegKopf.Tax_SBM_TaxTerritory_Obj).

/* Save if fields are already enabled. This procedure will be called two times*/
/* during the add of a new line. We only want to get the average costs when   */
/* this procedure will be called first. So we save the current value of       */
/* pa-fields-enabled. Only when this value is no, we later call the method    */
/* dGetOriginAverageCosts.                                                    */

assign
  lAlreadyEnabled = pa-fields-enabled
  glMess00405     = ? /* the message v_bel00405 can only appear once after enabling */
  glInUpdate      = yes
  .

run dispatch in this-procedure ('enable-fields':U).

if return-value <> 'adm-error':U then
do:

  if available V_BelegPos then
  do:

      if V_BelegKopf.LieferRestrikt = 1 then
        {fnarg
          pa_lUISvcDisableWidget
          "V_BelegPos.Liefertermin:handle in frame {&frame-name}"}.

    &IF LOOKUP("U_CI":U,"{&PA-OPTIONEN}":U) > 0 &THEN

      /* Change of shipping type is only allowed if the docline is new           */
      /* and no MRPLinks etc are created yet.                                    */
      /* If the position is once saved, you have to change via Extras menu       */
      /* because if we woulfchange here the MRP Account would be updated to late */
      /* and things like the availability check would went wrong                 */
      if V_BelegPos.AenderungDatum <> ?
        or V_BelegPos.WertPosition then
        {fnarg
          pa_lUISvcDisableWidget
          "V_BelegPos.uCI_Versandart:handle in frame {&frame-name}"}.

      if  V_BelegPos.uCI_Vertriebsweg = {&uCI_VertriebswegStrecke} then
      do:
        {fnarg
            pa_lUISvcDisableWidget
            "V_BelegPos.uCI_KommZeit:handle in frame {&frame-name}"}.
        {fnarg
          pa_lUISvcDisableWidget
          "V_BelegPos.uCI_KommZeiteinheit:handle in frame {&frame-name}"}.
      end.

      /* f�r �nderungen aktuellen Stand in private data speichern */
        assign
          {setwidgetattr
             "V_BelegPos.Wunschtermin"
             "private-data"
             "string(date(input frame {&frame-name} V_BelegPos.Wunschtermin),'{&PA_DATEFORMAT}':U)"
             "in frame {&FRAME-NAME}"}
          {setwidgetattr
             "V_BelegPos.Liefertermin"
             "private-data"
             "string(date(input frame {&frame-name} V_BelegPos.Liefertermin),'{&PA_DATEFORMAT}':U)"
             "in frame {&FRAME-NAME}"}
          {setwidgetattr
             "V_BelegPos.Transportzeit"
             "private-data"
             "string(input frame {&frame-name} V_BelegPos.Transportzeit)"
             "in frame {&FRAME-NAME}"}
          {setwidgetattr
             "V_BelegPos.Zeiteinheit"
             "private-data"
             "string(input frame {&frame-name} V_BelegPos.Zeiteinheit)"
             "in frame {&FRAME-NAME}"}
          {setwidgetattr
             "V_BelegPos.uci_Kommzeit"
             "private-data"
             "string(input frame {&frame-name} V_BelegPos.uci_Kommzeit)"
             "in frame {&FRAME-NAME}"}
          {setwidgetattr
             "V_BelegPos.uCI_Kommzeiteinheit"
             "private-data"
             "string(input frame {&frame-name} V_BelegPos.uCI_Kommzeiteinheit)"
             "in frame {&FRAME-NAME}"}
          .

    &ENDIF /* U_CI */

    &IF LOOKUP("U_CI":U,"{&PA-OPTIONEN}":U) > 0 &THEN
      V_BelegPos.uCI_Warenausgangstermin:screen-value in frame {&frame-name}
    &ELSE
    V_BelegPos.Versandtermin:screen-value in frame {&frame-name}
    &ENDIF

    = string((if date(V_BelegPos.Liefertermin:screen-value in frame {&frame-name}) <> ? then
                date(V_BelegPos.Liefertermin:screen-value in frame {&frame-name})
              else
                date(V_BelegPos.Wunschtermin:screen-value in frame {&frame-name}))
              - {fnarg
                   pa_iCalendTransportTime
                   "V_BelegPos.Firma,
                     V_BelegKopf.Lagergruppe,
                     input frame {&frame-name} V_BelegPos.Lagerort,
                     integer(V_BelegPos.Transportzeit:screen-value in frame {&frame-name}),
                     V_BelegPos.Zeiteinheit:screen-value in frame {&frame-name},
                    if date(V_BelegPos.Liefertermin:screen-value in frame {&frame-name}) <> ? then
                      date(V_BelegPos.Liefertermin:screen-value in frame {&frame-name})
                    else
                      date(V_BelegPos.Wunschtermin:screen-value in frame {&frame-name}),
                     no"},
             V_BelegPos.Versandtermin:format in frame {&frame-name}).

    apply 'leave':U to V_BelegPos.Versandtermin in frame {&frame-name}.

    &IF LOOKUP("U_CI":U,"{&PA-OPTIONEN}":U) > 0 &THEN
      apply 'leave':U to V_BelegPos.uCI_KommZeit in frame {&frame-name}.
    &ENDIF

    if    V_BelegPos.Satzart = 'A':U
      and lAlreadyEnabled    = no then

      /* procedure Preis_anzeigen (v_wbel00.lib) needs the average costs      */
      /* for the newly entered part                                           */

      gdAverageCosts = vert.base.cls.VBCSalesDocSvc:prpoInstance:dGetOriginAverageCosts
                         (V_BelegPos.V_BelegPos_Obj).

  end.  /* if available V_BelegPos  */

  run set-attribute-list ('CreatePurchaseOrder=no':U).

  if    V_BelegPos.Wareneinsatz:hidden in frame {&FRAME-NAME} = no
    and V_BelegPos.Satzart                                    = 'A':U
    and not can-find(JBT_Project
                       where JBT_Project.JBT_Project_Obj = V_BelegKopf.JBT_Project_Obj) then

    {fnarg
      pa_lUISvcSetWidgetSensitiveState
      "V_BelegPos.Wareneinsatz:handle in frame {&FRAME-NAME},
       no"}.

  run LocalEnableFields-1 no-error.

  if error-status:error then
    return 'adm-error':U.

  if    V_BelegPos.Satzart      = 'A':U
    and V_BelegPos.Wertposition = no then
  do:

    run pruefeVariantenteil no-error.

    if error-status:error then
    do:

      if glNewPosition = yes then
      do:

        run notify ('cancel-record,record-source':U).

        glNewPosition = no.

        return 'adm-error':U.

      end. /* if glNewPosition = yes */

      else

        return 'adm-error':U.

    end. /* if error-status:error */

    {fnarg
      pa_lUISvcSetWidgetSensitiveState
      "V_BelegPos.Transportzeit:handle in frame {&FRAME-NAME},
       yes"}.

    {fnarg
      pa_lUISvcSetWidgetSensitiveState
      "gcTimeUnitCombo:handle in frame {&FRAME-NAME},
       yes"}.

  end. /* if available V_BelegPos and ... */

  run LocalEnableFields-2 no-error.

  if error-status:error then
    return 'adm-error':U.

  &IF "{&pa_S_F_EcoTax}":U = "1":U &THEN

    if pACConnectionSvc:prpcLocalization = 'F':U then
    do:

      {fnarg
        pa_lUISvcSetWidgetSensitiveState
        "V_BelegPos.Wert_RZ_5:handle in frame {&FRAME-NAME},
         can-find(S_Artikel
                    where S_Artikel.Firma    = {firma/sartikel.fir pa-Firma}
                      and S_Artikel.Artikel  = V_BelegPos.Artikel
                      and S_Artikel.F_EcoTax = yes)"}.

      gcFEcoTaxOrigin = substring(V_BelegPos.Preisherkunft,9,1).

      /* Calculate the eco tax amount regarding eco components. It is necessary */
      /* to catch changes in order to update the eco tax amount correctly.      */

      {adm/incl/d__run03.if
        &Procedure = "vert/proc/v_neccf0.p"
        &Arguments = "       V_BelegPos.V_BelegPos_Obj,
                      output gdFEcoTaxCalc"
      }

    end. /* if pACConnectionSvc:prpcLocalization = 'F':U */

  &ENDIF

  /* Exit */

  {fnarg
     pa_lUISvcSetWidgetSensitiveState
     "V_BelegPos.Ursprungszeugnis:handle in frame {&FRAME-NAME},
      (    available S_Artikel
       and S_Artikel.Ursprungszeugnis)"}.

  {&{&PA-XBasisName}_C_local-enable-fields}
  {&{&PA-XBasisName}_U_local-enable-fields}
  {&{&PA-XBasisName}_Q_local-enable-fields}
  {&{&PA-XBasisName}_local-enable-fields}
  {&{&PA-XBasisName}_Y_local-enable-fields}

end. /* if return-value <> 'adm-error':U */

end procedure.

/* _UIB-CODE-BLOCK-END */
&ANALYZE-RESUME

&ANALYZE-SUSPEND _UIB-CODE-BLOCK _PROCEDURE local-end-update V-table-Win 
procedure local-end-update :
/* Description ---------------------------------------------------------------*/
/*                                                                            */
/* Super Override                                                             */
/*                                                                            */
/* Variables -----------------------------------------------------------------*/
/*                                                                            */
/* iDecimalPlaces              Decimal Places from LME                        */
/* dTemp1                      Round up quantity                              */
/*                                                                            */
/*----------------------------------------------------------------------------*/

define variable iDecimalPlaces like S_MengenEinheit.Nachkomma no-undo.
define variable dTemp1         as   decimal                   no-undo.

/* make the reservation in this Procedure, because we have the MRP Account -- */

if    V_BelegPos.Satzart = 'A':U
  and not can-do({&pa_S_PTList_Set}, string(S_Artikel.Artikelart)) then
do:

  run Reservation.

  /* auto-generate work order for MRP category 03 and ordering method 01    */
  /* but not for drop-shipments                                             */
  
  &IF "{&PA_V_PP_AutomProduktion}":U = "1":U &THEN
  
    run request-attribute( this-procedure,
                          'record-source':U,
                          'MRPRelease':U).
  
    if    glArchive               = no
      and V_BelegPos.Wertposition = no
      and return-value            = 'yes':U /* Is MRPRelease in main viewer set */
      and V_BelegPos.LagerOrt    <> ? then
      
        vert.base.cls.VBCSalesDocSvc:prpoInstance:CreateWorkOrderToOrderLine
          (buffer V_BelegPos,
           V_BelegKopf.Lagergruppe,
           giRueckMeldeNr,
           gcAuftrag).
  
  &ENDIF

  if glToRecalculateQty = yes then
  do:
    iDecimalPlaces = {fnarg
                       pa_iDyCchUnitOfMeasureDecimals
                       "pACConnectionSvc:prpcCompany,
                        S_Artikel.LagerME"}.

    if  (input frame {&frame-name} d_Menge * gdVME_Faktor)
      - truncate ((input frame {&frame-name} d_Menge * gdVME_Faktor),iDecimalPlaces) <> 0 then
    do:

      dTemp1 = round((input frame {&frame-name} d_Menge * gdVME_Faktor) + (5 / exp(10,iDecimalPlaces + 1)), iDecimalPlaces).                                             

      adm.method.cls.DMCMessageSvc:prpoInstance:lShowMessage
                  ('m_pac00223':U,
                   string(input frame {&frame-name} d_Menge),
                   string(gdVME_Faktor),
                   string(dTemp1)).

    end. 
  end. /* if glToRecalculateQty = yes */

end. /* if V_BelegPos.Satzart = 'A':U ... */

run dispatch in this-procedure ('end-update':U).

if return-value <> 'ADM-ERROR':U then
  glToRecalculateQty = no.

end procedure.

/* _UIB-CODE-BLOCK-END */
&ANALYZE-RESUME

&ANALYZE-SUSPEND _UIB-CODE-BLOCK _PROCEDURE local-help-begin V-table-Win 
procedure local-help-begin :
/* Description ---------------------------------------------------------------*/
/*                                                                            */
/* Super Override                                                             */
/*                                                                            */
/*----------------------------------------------------------------------------*/

define buffer bV_BelegKopfAdr for V_BelegKopfAdr.
define buffer bS_Kunde        for S_Kunde.

if    available V_BelegKopf
  and available V_BelegPos
  and available S_Firma then
do:

  assign
    pa-hlp-string = adm.method.cls.DMCParameterStringSvc:cWriteValue(pa-hlp-string,'Artikel':U,V_BelegPos.Artikel)
    pa-hlp-string = adm.method.cls.DMCParameterStringSvc:cWriteValue(pa-hlp-string,'Kunde':U,V_BelegKopf.Kunde)
    pa-hlp-string = adm.method.cls.DMCParameterStringSvc:cWriteValue(pa-hlp-string,'QtyUnit':U,giMengeneinheit)
    .

  if can-do(pa-hlp-function,'MMM_CusRefOrder_ID':U) then
  do:

    find bS_Kunde
      where bS_Kunde.Firma = {firma/s_kunde.fir pACConnectionSvc:prpcCompany}
        and bS_Kunde.Kunde = V_BelegKopf.Kunde
      no-lock no-error.

    if available bS_Kunde then

      pa-hlp-string = adm.method.cls.DMCParameterStringSvc:cWriteValue
                        (pa-hlp-string,
                         'Owning_Obj':U,
                         bS_Kunde.S_Kunde_Obj).

  end.  /* if can-do(pa-hlp-function,'E':U) */

  find first bV_BelegKopfAdr
    where bV_BelegKopfAdr.Firma      = V_BelegKopf.Firma
      and bV_BelegKopfAdr.Belegart   = V_BelegKopf.Belegart
      and bV_BelegKopfAdr.ReferenzNr = V_BelegKopf.ReferenzNr
      and bV_BelegKopfAdr.Typ        = 'L':U
    no-lock no-error.

  if    available bV_BelegKopfAdr
    and bV_BelegKopfAdr.AdressNr <> ? then

    pa-hlp-string = adm.method.cls.DMCParameterStringSvc:cWriteValue(pa-hlp-string,'Adresse':U,bV_BelegKopfAdr.AdressNr).

  else

    pa-hlp-string = adm.method.cls.DMCParameterStringSvc:cWriteValue(pa-hlp-string,'Adresse':U,'':U).

  if    available bV_BelegKopfAdr
    and bV_BelegKopfAdr.Lieferadresse <> ? then

    pa-hlp-string = adm.method.cls.DMCParameterStringSvc:cWriteValue(pa-hlp-string,'LieferAdresse':U,bV_BelegKopfAdr.Lieferadresse).

  else

    pa-hlp-string = adm.method.cls.DMCParameterStringSvc:cWriteValue(pa-hlp-string,'LieferAdresse':U,'':U).

  &IF "{&pa_MD_LGrp_Wechsel}" = "0" &THEN

    assign
      pa-hlp-string = adm.method.cls.DMCParameterStringSvc:cWriteValue(pa-hlp-string, 'Lagergruppe':U, V_BelegKopf.Lagergruppe)
      pa-hlp-string = adm.method.cls.DMCParameterStringSvc:cWriteValue(pa-hlp-string, 'pa_MD_LGrp_Wechsel':U, 0)
      . 

  &ENDIF  

  /* Strg-A for field Lagerort needs 'Storagearea' as key-name                */
  /* but Strg-Y must get 'Lagerort' as key-name                               */

  if    can-do(pa-hlp-function,'E':U)
    and can-do(pa-hlp-function,'LagerOrt':U) then

    pa-hlp-string = adm.method.cls.DMCParameterStringSvc:cWriteValue
                      (pa-hlp-string,
                       'key-name':U,
                       'Lagerort':U).

  /* show only non-archived cro numbers                                       */

  pa-hlp-string = adm.method.cls.DMCParameterStringSvc:cWriteValue
                    (pa-hlp-string,
                     'Archived':U,
                     'no':U).

end.  /* if available V_BelegKopf */

run dispatch in this-procedure ('help-begin':U).

end procedure.

/* _UIB-CODE-BLOCK-END */
&ANALYZE-RESUME

&ANALYZE-SUSPEND _UIB-CODE-BLOCK _PROCEDURE local-initialize V-table-Win 
procedure local-initialize :
/* Description ---------------------------------------------------------------*/
/*                                                                            */
/* Super Override                                                             */
/*                                                                            */
/*----------------------------------------------------------------------------*/

&IF "{&pa_S_F_EcoTax}":U = "1":U &THEN
  define variable lbl-hndl as widget-handle no-undo.
&ENDIF
define variable dRowToUseForMovement as decimal no-undo.

define buffer S_EAN for S_EAN.

&IF "{&pa_S_F_EcoTax}":U = "1":U &THEN

  if pACConnectionSvc:prpcLocalization = 'F':U then
  {fnarg
    pa_lUISvcCreateLabel
    "V_BelegPos.Wert_RZ_5:handle in frame {&FRAME-NAME},
    {&pa_V_WRZ5_Label}"}.

&ENDIF

/* load bitmaps */

adm.method.cls.DMCUISvc:lLoadIconImage(btnVME:handle in frame {&FRAME-NAME},
                                       'icon_choose':U).

adm.method.cls.DMCUISvc:lLoadIconImage(btnTax:handle in frame {&FRAME-NAME},
                                       'icon_choose':U).

/*----------------------------------------------------------------------------*/
/* Initialisierung der Sonderzeichen '/' f�r die Oberfl�che, da               */
/* im UIB keine �bersetzungsattribute angegeben werden k�nnen                 */
/*----------------------------------------------------------------------------*/

run get-attribute ('Ansicht':U).

assign
  gcAnsicht          = return-value
  gcBelegart         = 'U':U
  c_text-1           = '/':U
  gdVME_Faktor       = 1
  gdVME_Faktor_Sales = 1
  .

/* select layout ------------------------------------------------------------ */

run current-window-layouts (input gcAnsicht) no-error.

if error-status:error then
  return 'adm-error':U.

&IF "{&pa_S_F_EcoTax}":U = "1":U &THEN

  if    pACConnectionSvc:prpcLocalization = 'F':U
    and current-window-layout             = "BaseEntry":U then

    assign         
      lbl-hndl     = V_BelegPos.Wert_RZ_5:side-label-handle in frame F-Main 
      {setwidgetattr
         "lbl-hndl"
         "row"
         "decimal(V_BelegPos.Wert_RZ_5:row in frame F-Main)"}
      .

  if    pACConnectionSvc:prpcLocalization = 'F':U
    and CURRENT-WINDOW-layout             = "QuickEntry":U then

    assign
      {setwidgetattr
         "V_BelegPos.Wert_RZ_5"
         "row"
         "4.5"
         "in frame F-Main"}
      lbl-hndl                                 = V_BelegPos.Wert_RZ_5:side-label-handle in frame F-Main 
      {setwidgetattr
         "lbl-hndl"
         "row"
         "decimal(V_BelegPos.Wert_RZ_5:row in frame F-Main)"}
      {setwidgetattr
         "c_Rabatt-1"
         "row"
         "5.5"
         "in frame F-Main"}
      .

&ENDIF       

{fnarg
   pa_lUISvcInitializeComboValuePairs
   "gcTimeUnitCombo:handle in frame {&frame-name},
    'MM_TimeUnits_desc':U,
    'MM_TimeUnits_keys':U"}.

{setwidgetattr
   "gcZollNummer"
   "format"
   "stamm.base.cls.SBCCustomsTariffNoSvc:prpoInstance:cFormatCommodityCodeID()"
   "in frame {&FRAME-NAME}"}.

run dispatch('initialize':U).

if return-value <> 'adm-error':U then
do:

  /* bind the following "info"-fields to their base widgets                   */

  {fnarg
    pa_lUISvcAttachWidget
    "d_Menge:handle in frame {&frame-name},
     c_Mengeneinheit-1:handle in frame {&frame-name}"}.

  {fnarg
    pa_lUISvcAttachWidget
    "d_reserviert:handle in frame {&frame-name},
     c_Mengeneinheit-3:handle in frame {&frame-name}"}.

  {fnarg
    pa_lUISvcAttachWidget
    "d_geliefert:handle in frame {&frame-name},
     c_Mengeneinheit-2:handle in frame {&frame-name}"}.

  {fnarg
    pa_lUISvcAttachWidget
    "d_Storno:handle in frame {&frame-name},
     c_Mengeneinheit-4:handle in frame {&frame-name}"}.

  {fnarg
    pa_lUISvcAttachWidget
    "V_BelegPos.MMM_CusRefOrder_ID:handle in frame {&frame-name},
     gcCROInfo:handle in frame {&frame-name}"}.

  {fnarg
    pa_lUISvcAttachWidget
    "V_BelegPos.Einzelpreis:handle in frame {&frame-name},
     c_Preisherkunft-1:handle in frame {&frame-name}"}.

  {fnarg
    pa_lUISvcAttachWidget
    "V_BelegPos.proz_RZ_1:handle in frame {&frame-name},
     c_Preisherkunft-2:handle in frame {&frame-name}"}.

  {fnarg
    pa_lUISvcAttachWidget
    "V_BelegPos.proz_RZ_2:handle in frame {&frame-name},
     c_Preisherkunft-3:handle in frame {&frame-name}"}.

  {fnarg
    pa_lUISvcAttachWidget
    "V_BelegPos.proz_RZ_3:handle in frame {&frame-name},
     c_Preisherkunft-4:handle in frame {&frame-name}"}.

  {fnarg
    pa_lUISvcAttachWidget
    "V_BelegPos.Wert_RZ_1:handle in frame {&frame-name},
     c_Preisherkunft-5:handle in frame {&frame-name}"}.

  {fnarg
    pa_lUISvcAttachWidget
    "V_BelegPos.Wert_RZ_2:handle in frame {&frame-name},
     c_Preisherkunft-6:handle in frame {&frame-name}"}.

  {fnarg
    pa_lUISvcAttachWidget
    "V_BelegPos.Gewicht:handle in frame {&frame-name},
     c_text-1:handle in frame {&frame-name}"}.

  {fnarg
    pa_lUISvcAttachWidget
    "V_BelegPos.GewichtVerp:handle in frame {&frame-name},
     c_text-14:handle in frame {&frame-name}"}.

  {fnarg
    pa_lUISvcAttachWidget
    "V_BelegPos.GewichtVerp:handle in frame {&frame-name},
     c_text-VME:handle in frame {&frame-name}"}.

  {fnarg
    pa_lUISvcAttachWidget
    "d_Gesamtpreis:handle in frame {&frame-name},
     c_wBez-1:handle in frame {&frame-name}"}.

  {fnarg
    pa_lUISvcAttachWidget
    "V_BelegPos.Einzelpreis:handle in frame {&frame-name},
     gcPriceUnitDesc:handle in frame {&frame-name}"}.

  {fnarg
    pa_lUISvcAttachWidget
    "V_BelegPos.LieferBedingung:handle in frame {&frame-name},
     V_BelegPos.IncoTerm:handle in frame {&frame-name}"}.

  {fnarg
    pa_lUISvcAttachWidget
    "V_BelegPos_Steuer_Bez:handle in frame {&frame-name},
     gdSteuersatz:handle in frame {&frame-name}"}.

  {fnarg
    pa_lUISvcAttachWidget
    "V_BelegPos.USTax_Override:handle in frame {&frame-name},
     btnTax:handle in frame {&frame-name}"}.

  /*--------------------------------------------------------------------------*/
  /* labels                                                                   */
  /*--------------------------------------------------------------------------*/

  if gcAnsicht <> 'QuickEntry':U then
  do:

    {fnarg
      pa_lUISvcCreateLabel
      "V_BelegPos.Wert_RZ_1:handle in frame {&FRAME-NAME},
      adm.config.cls.DCCAppConfigSvc:prpoInstance:cParameterValue
        ('VB_DiscountSurchargeValueLabel1':U)"}.

    {fnarg
      pa_lUISvcCreateLabel
      "V_BelegPos.Wert_RZ_2:handle in frame {&FRAME-NAME},
      adm.config.cls.DCCAppConfigSvc:prpoInstance:cParameterValue
        ('VB_DiscountSurchargeValueLabel2':U)"}.

  end.

  {fnarg
    pa_lUISvcCreateLabel
    "c_Rabatt-1:handle in frame {&FRAME-NAME},
     adm.config.cls.DCCAppConfigSvc:prpoInstance:cParameterValue
       ('VB_DiscountSurchargePercLabel1':U)"}.

  {fnarg
    pa_lUISvcCreateLabel
    "c_Rabatt-2:handle in frame {&FRAME-NAME},
     adm.config.cls.DCCAppConfigSvc:prpoInstance:cParameterValue
       ('VB_DiscountSurchargePercLabel2':U)"}.

  {fnarg
    pa_lUISvcCreateLabel
    "c_Rabatt-3:handle in frame {&FRAME-NAME},
     adm.config.cls.DCCAppConfigSvc:prpoInstance:cParameterValue
       ('VB_DiscountSurchargePercLabel3':U)"}.

  assign
    gcBereich        = 'VU':U
    glSpanne         = adm.config.cls.DCCAppConfigSvc:prpoInstance:lParameterValue
                         ('VB_AutoMinMarginControl':U)
    glVerfuegbarkeit = adm.config.cls.DCCAppConfigSvc:prpoInstance:lParameterValue
                         ('VU_AutoAvailableToPromiseCheck':U)
    glV_IntraErf     = adm.config.cls.DCCAppConfigSvc:prpoInstance:lParameterValue
                         ('VB_NoIntraDataInSales':U)
    .

  &IF lookup("PP","{&pa-Module}") > 0 &THEN

    glPP_Auftrag = adm.config.cls.DCCAppConfigSvc:prpoInstance:lParameterValue
                     ('PP_WorkOrderFromSales':U).

  &ENDIF   /* Modul PP  */

  &IF lookup("MS","{&pa-Module}") > 0 &THEN

    glSNrVFP = adm.config.cls.DCCAppConfigSvc:prpoInstance:lParameterValue
                 ('MS_EntrySerialNoInProFormaInvoice':U).

  &ENDIF   /* Modul MS  */

  &IF lookup("E_","{&pa-Module}") > 0 &THEN

    glCreatePurchaseOrder = adm.config.cls.DCCAppConfigSvc:prpoInstance:lParameterValue
                              ('VU_CreatePOFromOrder':U).

  &ENDIF

  &IF LOOKUP("MU":U,"{&PA-MODULE}":U) > 0 &THEN
    gcConfigPriceHandling = adm.config.cls.DCCAppConfigSvc:prpoInstance:cParameterValue
                              ('MU_PricingManually ':U).
  &ENDIF

  if not can-find(first S_EAN
                    where S_EAN.Firma = {firma/sartikel.fir pACConnectionSvc:prpcCompany}) then

    {fnarg
      pa_lUISvcSetWidgetHiddenState
        "gcEAN:handle in frame {&frame-name},
        yes"}.

  {fnarg
    pa_lUISvcDisableWidget
      "gdSteuersatz:handle in frame {&frame-name}"}.

  {fnarg
    pa_lUISvcDisableWidget
      "V_BelegPos_Steuer_Bez:handle in frame {&frame-name}"}.

  {fnarg
    pa_lUISvcSetWidgetHiddenState
      "V_BelegPos.Zeiteinheit:handle in frame {&frame-name},
      yes"}.

  {fnarg
    pa_lUISvcSetWidgetHiddenState
      "gcTimeUnitCombo:handle in frame {&frame-name},
      no"}.

  {fnarg
    pa_lUISvcDisableWidget
      "gcTimeUnitCombo:handle in frame {&frame-name}"}.

  &IF lookup("JB","{&pa-Module}") = 0 &THEN

    {fnarg
      pa_lUISvcSetWidgetHiddenState
        "V_BelegPos.Wareneinsatz:handle in frame {&frame-name},
        yes"}.

  &ELSE

    /* show field 'Wareneinsatz' only in BaseEntry                            */

    {fnarg
      pa_lUISvcSetWidgetHiddenState
        "V_BelegPos.Wareneinsatz:handle in frame {&frame-name},
        gcAnsicht = 'QuickEntry':U"}.

  &ENDIF

  /* If it's US localization, then USTax_TaxFree, USTax_Override and gdTaxSum */
  /* are visisble, V_BelegPos_Steuer_Bez and gdSteuersatz are hidden          */

  {fnarg
    pa_lUISvcSetWidgetHiddenState
    "V_BelegPos.USTax_TaxFree:handle in frame {&frame-name},
     pACConnectionSvc:prpcLocalization <> 'USA':U"}.

  {fnarg
    pa_lUISvcSetWidgetHiddenState
    "V_BelegPos.USTax_Override:handle in frame {&frame-name},
     pACConnectionSvc:prpcLocalization <> 'USA':U"}.

  {fnarg
    pa_lUISvcSetWidgetHiddenState
    "gdTaxSum:handle in frame {&frame-name},
     pACConnectionSvc:prpcLocalization <> 'USA':U"}.

  {fnarg
    pa_lUISvcSetWidgetHiddenState
    "V_BelegPos_Steuer_Bez:handle in frame {&frame-name},
     pACConnectionSvc:prpcLocalization = 'USA':U"}.

  &IF LOOKUP("U_CI":U,"{&PA-OPTIONEN}":U) = 0 &THEN
  {fnarg
    pa_lUISvcSetWidgetHiddenState
    "V_BelegPos.uCI_KommZeit:handle in frame {&frame-name},
     yes"}.

  {fnarg
    pa_lUISvcSetWidgetHiddenState
    "V_BelegPos.uCI_KommZeitEinheit:handle in frame {&frame-name},
     yes"}.

  {fnarg
    pa_lUISvcSetWidgetHiddenState
    "V_BelegPos.uCI_Warenausgangstermin:handle in frame {&frame-name},
     yes"}.

  {fnarg
    pa_lUISvcSetWidgetHiddenState
    "V_BeleI_Warenausgangstermin_Info:handle in frame {&frame-name},
     yes"}.

  {fnarg
    pa_lUISvcSetWidgetHiddenState
    "V_BelegPos.uCI_Versandart:handle in frame {&frame-name},
     yes"}.

  {fnarg
    pa_lUISvcSetWidgetHiddenState
    "V_BelegPos_uCI_VersandArt_Info:handle in frame {&frame-name},
     yes"}.
  &ELSE
  if CURRENT-WINDOW-layout = "BaseEntry":U then
    assign
      {setwidgetattr
         "V_BelegPos.Versandtermin"
         "row"
         "18"
         "in frame F-Main"}
      {setwidgetattr
         "V_BelegPos_Versandtermin_Info"
         "row"
         "18"
         "in frame F-Main"}
      .

  if CURRENT-WINDOW-layout = "QuickEntry":U then
    assign
      {setwidgetattr
         "V_BelegPos.Versandtermin"
         "row"
         "11"
         "in frame F-Main"}
      {setwidgetattr
         "V_BelegPos_Versandtermin_Info"
         "row"
         "11"
         "in frame F-Main"}
      .
  &ENDIF

  &IF LOOKUP("U_CW":U,"{&PA-OPTIONEN}":U) = 0 &THEN
  {fnarg
    pa_lUISvcSetWidgetHiddenState
    "V_BelegPos.uCW_Tour:handle in frame {&frame-name},
     yes"}.

  {fnarg
    pa_lUISvcSetWidgetHiddenState
    "V_BelegPos.uCW_TransportNr:handle in frame {&frame-name},
     yes"}.

  {fnarg
    pa_lUISvcSetWidgetHiddenState
    "gtuAbfahrtsdatum:handle in frame {&frame-name},
     yes"}.

  {fnarg
    pa_lUISvcSetWidgetHiddenState
    "gcuAbfahrtszeit:handle in frame {&frame-name},
     yes"}.

  {fnarg
    pa_lUISvcSetWidgetHiddenState
    "gtuAbfahrtsdatum_Info:handle in frame {&frame-name},
     yes"}.
  &ENDIF

  &IF LOOKUP("U_CE":U,"{&PA-OPTIONEN}":U) = 0 &THEN
  {fnarg
    pa_lUISvcSetWidgetHiddenState
    "V_BelegPos.uCE_ReferenceDocItemPos:handle in frame {&frame-name},
     yes"}.
  &ENDIF

  &IF LOOKUP("U_CW":U,"{&PA-OPTIONEN}":U) = 0 &THEN
  {fnarg
    pa_lUISvcSetWidgetHiddenState
    "V_BelegPos.uCI_Lot:handle in frame {&frame-name},
     yes"}.
  &ENDIF

  &IF LOOKUP("Q_DEL":U,"{&PA-OPTIONEN}":U) = 0  &THEN

    {fnarg
      pa_lUISvcSetWidgetHiddenState
      "V_BelegPos.MetalSurcharge:handle in frame {&frame-name},
       yes" }.  

  &ENDIF   

  run set-attribute-list ('check-modified-all=yes':U).

  if   pACConnectionSvc:prpcLocalization <> 'F':U
    or {&pa_S_F_EcoTax} = 0 then
  do:

    {fnarg
      pa_lUISvcSetWidgetHiddenState
      "V_BelegPos.Wert_RZ_5:handle in frame {&frame-name},
      yes"}.

    {fnarg
      pa_lUISvcSetWidgetHiddenState
      "gcFEcoTaxOrigin:handle in frame {&frame-name},
      yes"}.

    adm.method.cls.DMCUISvc:moveFrameWidgets(frame {&FRAME-NAME}:handle,
                                             V_BelegPos.Wert_RZ_5:row in frame {&FRAME-NAME},
                                             V_BelegPos.Wert_RZ_5:col in frame {&FRAME-NAME},
                                             -1).

    adm.method.cls.DMCUISvc:moveFrameWidgets(frame {&FRAME-NAME}:handle,
                                             V_BelegPos.proz_RZ_1:row in frame {&FRAME-NAME},
                                             V_BelegPos.Proz_RZ_1:col in frame {&FRAME-NAME},
                                             -1).

    /* do this because in case of a first non-part position this viewer and   */
    /* its widgets are not visible - so the wrong widgets row is used as a    */
    /* reference row to move widgets. Seems only to work for views except the */
    /* QuickEntry...                                                          */

    run request-attribute (this-procedure, 'container-source':U, 'current-page':U).

    dRowToUseForMovement = (if    return-value = '1'
                              and {getwidgetattr V_BelegPos.Wert_RZ_Art_1 visible logical "in frame {&FRAME-NAME}"} = no then
                              V_BelegPos.proz_RZ_Art_1:row in frame {&FRAME-NAME}
                            else
                              V_BelegPos.Wert_RZ_Art_1:row in frame {&FRAME-NAME}).

    if gcAnsicht = 'QuickEntry':U then
      adm.method.cls.DMCUISvc:moveFrameWidgets(frame {&FRAME-NAME}:handle,
                                               (if {getwidgetattr V_BelegPos.Wert_RZ_Art_1 visible logical "in frame {&FRAME-NAME}"} then
                                                  V_BelegPos.Wert_RZ_Art_1:row in frame {&FRAME-NAME}
                                                else
                                                  V_BelegPos.proz_RZ_Art_1:row in frame {&FRAME-NAME}),
                                               V_BelegPos.Wert_RZ_Art_1:col in frame {&FRAME-NAME},
                                               -1).
    else
      adm.method.cls.DMCUISvc:moveFrameWidgets(frame {&FRAME-NAME}:handle,
                                               dRowToUseForMovement,
                                               V_BelegPos.Wert_RZ_Art_1:col in frame {&FRAME-NAME},
                                               -1).

    adm.method.cls.DMCUISvc:moveFrameWidgets(frame {&FRAME-NAME}:handle,
                                             btnTax:row in frame {&FRAME-NAME},
                                             btnTax:col in frame {&FRAME-NAME},
                                             -1).

    adm.method.cls.DMCUISvc:moveFrameWidgets(frame {&FRAME-NAME}:handle,
                                             gdSteuersatz:row in frame {&FRAME-NAME},
                                             gdSteuersatz:col in frame {&FRAME-NAME},
                                             -1).

    adm.method.cls.DMCUISvc:moveFrameWidgets(frame {&FRAME-NAME}:handle,
                                             gc_Preisbezug-Rabattart-1:row in frame {&FRAME-NAME},
                                             gc_Preisbezug-Rabattart-1:col in frame {&FRAME-NAME},
                                             -1).

    adm.method.cls.DMCUISvc:moveFrameWidgets(frame {&FRAME-NAME}:handle,
                                             (if {getwidgetattr c_Preisherkunft-5 visible logical "in frame {&FRAME-NAME}"} then
                                                c_Preisherkunft-5:row in frame {&FRAME-NAME}
                                              else
                                                c_Preisherkunft-2:row in frame {&FRAME-NAME}),
                                             c_Preisherkunft-5:col in frame {&FRAME-NAME},
                                             -1).

  end. /* if pACConnectionSvc:prpcLocalization <> 'F':U... */

  {&{&PA-XBasisName}_C_local-initialize}
  {&{&PA-XBasisName}_U_local-initialize}
  {&{&PA-XBasisName}_Q_local-initialize}
  {&{&PA-XBasisName}_local-initialize}
  {&{&PA-XBasisName}_Y_local-initialize}

end. /* if return-value <> 'adm-error':U */

end procedure.

/* _UIB-CODE-BLOCK-END */
&ANALYZE-RESUME

&ANALYZE-SUSPEND _UIB-CODE-BLOCK _PROCEDURE local-row-available V-table-Win 
procedure local-row-available :
/* Description ---------------------------------------------------------------*/
/*                                                                            */
/* Super Override                                                             */
/*                                                                            */
/*----------------------------------------------------------------------------*/

assign
  gcAuftrag      = '':U
  giRueckmeldeNr = ?
  .

run dispatch in this-procedure ('row-available':U).

if return-value <> 'adm-error':U then
do:

  assign
    glEinstandspreis = no
    glIntra          = no
    glauto_Intra     = no
    gdEinstandspreis = 0
    gdVME_Faktor     = 0
    .

  /* prepare pricing -------------------------------------------------------- */

  find first TT_V_PreisFind
    no-error.

  if    available V_BelegPos 
    and available TT_V_PreisFind then
  do:

    gdVME_Faktor_Sales = (if    available S_Artikel
                            and S_Artikel.IsPackagingUnitToStock = no
                            and V_BelegPos.Mengeneinheit <> S_Artikel.LagerME then
                            V_BelegPos.VME_Faktor
                          else
                            1).

    find V_BelegKopf
      where V_BelegKopf.Firma      = V_BelegPos.Firma
        and V_BelegKopf.Belegart   = V_BelegPos.Belegart
        and V_BelegKopf.ReferenzNr = V_BelegPos.ReferenzNr
      no-lock.

    {buffer-copy
       V_BelegKopf
       except "Steuersatz Herk_Belegart"
       to tt_V_PreisFind}

    assign
      gdMerke_Menge                 = V_BelegPos.Menge
      TT_V_Preisfind.RabattGrpKunde = V_BelegKopf.RabattGruppe
      TT_V_Preisfind.RabattGrpArt   = V_BelegPos.RabattGruppe
      gdVME_Faktor                  = V_BelegPos.VME_Faktor
      .

  end. /* if available V_BelegPos */

  else

    {fnarg
      pa_lUISvcClearFrame
      '':U}.

end. /* if return-value <> 'adm-error':U */

end procedure.

/* _UIB-CODE-BLOCK-END */
&ANALYZE-RESUME

&ANALYZE-SUSPEND _UIB-CODE-BLOCK _PROCEDURE local-update-record V-table-Win 
procedure local-update-record :
/* Description ---------------------------------------------------------------*/
/*                                                                            */
/* Super Override                                                             */
/*                                                                            */
/*----------------------------------------------------------------------------*/

run dispatch in this-procedure ('update-record':U).

if return-value <> 'ADM-ERROR':U then
do:

  run get-attribute ('auto-exit':U).

  if return-value = 'yes':U then

    run dispatch ('exit':U).

end. /* if return-value <> 'ADM-ERROR':U */

end procedure.

/* _UIB-CODE-BLOCK-END */
&ANALYZE-RESUME

&ANALYZE-SUSPEND _UIB-CODE-BLOCK _PROCEDURE LocalEnableFields-1 V-table-Win 
procedure LocalEnableFields-1 :
/* Description ---------------------------------------------------------------*/
/*                                                                            */
/* validation and enabling / disabling of input fields                        */
/*                                                                            */
/*----------------------------------------------------------------------------*/

define buffer V_BelegKopfAdr for V_BelegKopfAdr.

Main:
do on error undo, return error:

  assign
    gdVME_Faktor       = V_BelegPos.VME_Faktor
    giMengeneinheit    = V_BelegPos.Mengeneinheit
    giNachkomma        = V_BelegPos.Nachkomma
    c_Preisherkunft-1  = substring(V_BelegPos.Preisherkunft,1,1)
    c_Preisherkunft-2  = substring(V_BelegPos.Preisherkunft,2,1)
    c_Preisherkunft-3  = substring(V_BelegPos.Preisherkunft,3,1)
    c_Preisherkunft-4  = substring(V_BelegPos.Preisherkunft,4,1)
    c_Preisherkunft-5  = substring(V_BelegPos.Preisherkunft,5,1)
    c_Preisherkunft-6  = substring(V_BelegPos.Preisherkunft,6,1)
    d_Menge            = truncate((V_BelegPos.Menge / V_BelegPos.VME_Faktor), V_BelegPos.Nachkomma)
    gdMerke_resMenge   = input frame {&FRAME-NAME} d_reserviert * V_BelegPos.VME_Faktor
    d_reserviert       = input frame {&FRAME-NAME} d_reserviert
    giMerke_Lagerort   = V_BelegPos.Lagerort
    gdMerke_Menge      = V_BelegPos.Menge
    gdMerkeMengeSet    = d_Menge
    glCancel           = no
    glEinstandspreis   = no
    giAktion           = V_BelegPos.Aktion
    glAenderungBuchung = yes
    glPreisFindSet     = no
    glArchive          = no
    .

  {fnarg
    pa_lUISvcDisableWidget
      "V_BelegPos.Lagerort:handle in frame {&frame-name}"}.

  {fnarg
    pa_lUISvcDisableWidget
      "gdSteuersatz:handle in frame {&frame-name}"}.

  {fnarg
    pa_lUISvcDisableWidget
      "d_geliefert:handle in frame {&frame-name}"}.

  if V_BelegPos.Wertposition = yes then

    {fnarg
      pa_lUISvcDisableWidget
        "d_reserviert:handle in frame {&frame-name}"}.

  find S_Kunde
    where S_Kunde.Firma = {firma/s_kunde.fir pACConnectionSvc:prpcCompany}
      and S_Kunde.Kunde = V_BelegKopf.Kunde
    no-lock.

  if    S_Kunde.AdressNr = 0
    and not can-find(V_BelegKopfAdr
                       where V_BelegKopfAdr.Firma      = V_BelegKopf.Firma
                         and V_BelegKopfAdr.Belegart   = V_BelegKopf.Belegart
                         and V_BelegKopfAdr.ReferenzNr = V_BelegKopf.ReferenzNr
                         and V_BelegKopfAdr.Typ        = 'K':U) then

    adm.method.cls.DMCMessageSvc:prpoInstance:showError
      ('v_bel00062':U,
       string(V_BelegKopf.Kunde)).

  if V_BelegPos.Satzart = 'A':U then
  do:

    /* validation quantity, storage area, consignment area and quantity units */

    run pruefeMengeLOrt.

    /*------------------------------------------------------------------------*/
    /* PPS                                                                    */
    /*------------------------------------------------------------------------*/

    &IF lookup("PP","{&pa-Module}") > 0 &THEN

      if V_BelegPos.Wertposition = no then

        run pruefePPS.

    &ENDIF

    /* once-only parts ------------------------------------------------------ */

    if    can-do({&pa_S_PTList_OnceOnlyPartTypes}, string(S_Artikel.ArtikelArt))
      and V_BelegPos.Wertposition = no then

      run set-attribute-list ('ChangeLandedPrice=yes':U).

    run pa_UISvcApplyEventToWidgetByHandle
          ('entry':U,
           d_Menge:handle in frame {&FRAME-NAME}).

    /* intradata ------------------------------------------------------------ */

    glIntra = no.

    &IF lookup("VF_Intra","{&pa-Optionen}") > 0 &THEN
      if stamm.base.cls.SBCBusinessCategorySvc:prpoInstance:lHasCompanyIntraStatSales(V_BelegKopf.BelegDatum) then

        case pACConnectionSvc:prpcLocalization:

          {&{&PA-XBasisName}_C_Intra_Enable}
          {&{&PA-XBasisName}_U_Intra_Enable}
          {&{&PA-XBasisName}_Q_Intra_Enable}
          {&{&PA-XBasisName}_Intra_Enable}
          {&{&PA-XBasisName}_Y_Intra_Enable}

          otherwise
          do:

            if pACConnectionSvc:prpcLocalization = 'F':U then
              assign
                glFIgnoreITS                = V_BelegPos.F_IgnoreITS
                giFRegime                   = V_BelegPos.F_Regime
                gcFSBM_BusinessCategory_Obj = V_BelegPos.SBM_BusinessCategory_Obj
                .

            if    V_BelegPos.Satzart      = 'A':U
              and V_BelegPos.WertPosition = no then

              run pruefe-Intra.

          end.  /* otherwise */

        end case. /* pACConnectionSvc:prpcLocalization */
    &ENDIF  /* &IF lookup("VF_Intra":U,"{&PA-OPTIONEN}":U) > 0 */

    assign
      gdStatistikwert   = V_BelegPos.Statistikwert_offen
      gdbesondere_Menge = V_BelegPos.besondereMenge
      .

    /* with parttype 99, entry of base-price is a must only when new entry    */

    if    V_Belegpos.Aenderungzeit > '':U
      and can-do({&pa_S_PTList_OnceOnlyPartTypes}, string(S_Artikel.ArtikelArt)) then

      glEinstandspreis = yes.

  end. /* if V_BelegPos.Satzart = 'A':U */

  /* estimating ------------------------------------------------------------- */

  &IF lookup("VN_KALK","{&PA-OPTIONEN}") > 0 &THEN

    if    available V_BelegPos
      and V_BelegPos.Satzart  = 'A':U
      and V_BelegKopf.Brutto  = no then  /* nur Nettopreise */

      run set-link-attribute in adm-broker-hdl (this-procedure,
                                                'container-source':U,
                                                'Calculation=yes':U).

  &ENDIF

end. /* Main */

return.

end procedure.

/* _UIB-CODE-BLOCK-END */
&ANALYZE-RESUME

&ANALYZE-SUSPEND _UIB-CODE-BLOCK _PROCEDURE LocalEnableFields-2 V-table-Win 
procedure LocalEnableFields-2 :
/* Description ---------------------------------------------------------------*/
/*                                                                            */
/* validation and enabling / disabling of input fields                        */
/*                                                                            */
/*----------------------------------------------------------------------------*/

define buffer S_EAN          for S_EAN.
define buffer S_ArtME        for S_ArtME.
&IF lookup ("M_Pack","{&PA-OPTIONEN}") > 0 &THEN
  define buffer M_LTPos      for M_LTPos.
  define buffer V_SendungPos for V_SendungPos.
&ENDIF

Main:
do on error undo, return error:

  if V_BelegPos.Satzart = 'A':U then
  do:

    /* if part is not discountable then close discount fields --------------- */

    if V_BelegPos.rabattfaehig = no then
    do:

      {fnarg
        pa_lUISvcDisableWidget
          "V_BelegPos.proz_RZ_1:handle in frame {&frame-name}"}.

      {fnarg
        pa_lUISvcDisableWidget
          "V_BelegPos.proz_RZ_2:handle in frame {&frame-name}"}.

      {fnarg
        pa_lUISvcDisableWidget
          "V_BelegPos.proz_RZ_3:handle in frame {&frame-name}"}.

      {fnarg
        pa_lUISvcDisableWidget
          "V_BelegPos.proz_RZ_Art_1:handle in frame {&frame-name}"}.

      {fnarg
        pa_lUISvcDisableWidget
          "V_BelegPos.proz_RZ_Art_2:handle in frame {&frame-name}"}.

      {fnarg
        pa_lUISvcDisableWidget
          "V_BelegPos.proz_RZ_Art_3:handle in frame {&frame-name}"}.

    end. /* if V_BelegPos.rabattfaehig = no */

    if V_BelegPos.MRPRelease = no then

      {fnarg
        pa_lUISvcDisableWidget
          "d_reserviert:handle in frame {&frame-name}"}.

    /* hiding discount type, when constant pa_V_RZ_Art = 0 didn't not work in */
    /* local-apply-layout either. so we moved that part to local-initialize   */
    /* and disabled them, instead of setting them hidden                      */

    &IF "{&pa_V_RZ_Art}":U <> "1":U &THEN

      else
      do:

        {fnarg
          pa_lUISvcDisableWidget
            "V_BelegPos.proz_RZ_Art_1:handle in frame {&frame-name}"}.

        {fnarg
          pa_lUISvcDisableWidget
            "V_BelegPos.proz_RZ_Art_2:handle in frame {&frame-name}"}.

        {fnarg
          pa_lUISvcDisableWidget
            "V_BelegPos.proz_RZ_Art_3:handle in frame {&frame-name}"}.

      end.

    &ENDIF

    /*------------------------------------------------------------------------*/
    /* Mengen�nderungen und Lagerort�nderungen sind nicht erlaubt, wenn       */
    /* f�r Chargen oder chaotisches Lager noch ein Kommissionierschein        */
    /* auf dieser Position offen ist, da �ber Kommissionierscheine Reser-     */
    /* vierungen auf unterschiedlichen Lagerorten ausgel�st werden k�nnen,    */
    /* die an dieser Stelle nicht verbucht werden k�nnten!                    */
    /*------------------------------------------------------------------------*/

    &IF lookup("MC", "{&PA-MODULE}") > 0
      or lookup("MP","{&PA-MODULE}") > 0 &THEN

      if    available S_Artikel
        and (can-find(first MLM_StorPartData
                        where MLM_StorPartData.Company = {firma/mlartort.fir pACConnectionSvc:prpcCompany}
                          and MLM_StorPartData.Part    = S_Artikel.Artikel)
             &IF lookup("MC", "{&PA-MODULE}") > 0 &THEN
               or S_Artikel.Chargenart                 > '':U
             &ENDIF
            ) then
      do:

        if mawi.base.api.cls.MMCPickingApi:Instance:lDocLineIsInPicking(V_BelegPos.V_BelegPos_Obj) then
        do:

          {fnarg
            pa_lUISvcDisableWidget
              "V_BelegPos.Lagerort:handle in frame {&frame-name}"}.

          {fnarg
            pa_lUISvcDisableWidget
              "d_Menge:handle in frame {&frame-name}"}.

          {fnarg
            pa_lUISvcDisableWidget
              "d_reserviert:handle in frame {&frame-name}"}.

          {fnarg
            pa_lUISvcDisableWidget
              "btnVME:handle in frame {&frame-name}"}.

          run set-attribute-list ('ChangeSalesUnit=no':U).

          run set-attribute-list ('ChangeProdConfig=no':U).

        end. /* mawi.base.api.cls.MMCPickingApi:Instance:lDocLineIsInPicking */

      end.  /* if V_BelegPos.Belegart = 'U':U */

    &ENDIF

    /* serialnumbers                                                          */
    /* it must be in localenable-2 in case of configuration part              */

    &IF lookup("MS","{&pa-Module}") > 0 &THEN

      if    S_Artikel.SNRArt        > '':U
        and V_BelegPos.Wertposition = no

        &IF LOOKUP("U_CI":U,"{&PA-OPTIONEN}":U) > 0 &THEN
        and V_BelegPos.uCI_Vertriebsweg <> {&uCI_VertriebswegStrecke}
        &ELSE
        and V_BelegKopf.Strecke    <> yes
        &ENDIF

        and mawi.serie.cls.MSCSerialNoSvc:prpoInstance:lCheckSNoIsRequired({&pa_MS_SalesDoc},
                                                                           S_Artikel.Artikel)
        and pa-fields-enabled then

        run set-attribute-list ('ChangeSerialnumber=yes':U).

    &ENDIF   /* Modul MS  */


    /* close field EAN for special parttypes -------------------------------- */

    find first S_EAN
      where S_EAN.Firma         = S_Artikel.Firma
        and S_EAN.Mengeneinheit = giMengeneinheit
        and S_EAN.Artikel       = V_BelegPos.Artikel
        and S_EAN.EAN           = V_BelegPos.EAN
      use-index EANME
      no-lock no-error.

    if    not available S_EAN
      and not can-do({&pa_V_PTList_WithoutEAN},string(S_Artikel.ArtikelArt)) then

      {fnarg
        pa_lUISvcEnableWidget
          "gcEAN:handle in frame {&frame-name}"}.

    else

      {fnarg
        pa_lUISvcDisableWidget
          "gcEAN:handle in frame {&frame-name}"}.

    /* handle SET ----------------------------------------------------------- */

    &IF lookup("M_","{&PA-MODULE}") > 0 &THEN
      &IF lookup("M_STUELI","{&PA-OPTIONEN}") > 0 &THEN

        if can-do({&pa_S_PTList_Set}, string(S_Artikel.ArtikelArt)) then
        do:

          {fnarg
            pa_lUISvcDisableWidget
              "V_BelegPos.Lagerort:handle in frame {&frame-name}"}.

          {fnarg
            pa_lUISvcDisableWidget
              "d_reserviert:handle in frame {&frame-name}"}.

        end. /* if can-do({&pa_S_PTList_Set}, string(S_Artikel.ArtikelArt)) */

      &ENDIF
    &ENDIF

    /* in case of drop shipment storage area remains closed ----------------- */

    if    V_BelegPos.Lagerort:hidden in frame {&frame-name} = no

      &IF LOOKUP("U_CI":U,"{&PA-OPTIONEN}":U) > 0 &THEN
      and V_BelegPos.uCI_Vertriebsweg = {&uCI_VertriebswegStrecke} then
      &ELSE
      and V_BelegKopf.Strecke                               = yes then
      &ENDIF

      {fnarg
        pa_lUISvcDisableWidget
          "V_BelegPos.Lagerort:handle in frame {&frame-name}"}.

    if d_Menge:sensitive in frame {&frame-name} = no then
    do:

      {fnarg
        pa_lUISvcDisableWidget
          "btnVME:handle in frame {&frame-name}"}.

      run set-attribute-list ('ChangeSalesUnit=no':U).

    end.

    {adm/incl/d__duh00.if
       &Var1     = "d_Menge"
       &WithFrame = "frame {&frame-name}"}

    run pa_UISvcApplyEventToWidgetByHandle
          ('entry':U,
           d_Menge:handle in frame {&frame-name}).

    if V_BelegPos.Wertposition = no then
    do:

      /* check margin and switch menue -------------------------------------- */

      run set-attribute-list ('CheckMargin=yes':U).

      /* check availability and switch menue -------------------------------- */

      &IF lookup("M_":U,"{&pa-Module}":U) > 0 &THEN

        if (   V_BelegPos.Lagerort <> ?
            or (can-do({&pa_S_PTList_Set}, string(S_Artikel.ArtikelArt)))) then
        do:

          if input frame {&frame-name} d_Menge <> 0 then

            run set-attribute-list ('CheckAvailability=yes':U).

          /* if this part has been replaced by the product configurator       */
          /* the screen value of V_BelegPos.Lagerort is not the same as       */
          /* the value in the database field. The databasefield contains      */
          /* the correct storage area but shown is ?.                         */

          if    input frame {&frame-name} V_BelegPos.Lagerort <> V_BelegPos.LagerOrt
            and input frame {&frame-name} V_BelegPos.LagerOrt = ? then

            {setwidgetattr
               "V_BelegPos.LagerOrt"
               "screen-value"
               "string(V_BelegPos.LagerOrt)"
               "in frame {&frame-name}"}.

          if input frame {&frame-name} V_BelegPos.LagerOrt <> ? then
          do:

            find ML_Ort
              where ML_Ort.Firma    = {firma/mlort.fir pACConnectionSvc:prpcCompany}
                and ML_Ort.Lagerort = input frame {&frame-name} V_BelegPos.Lagerort
              no-lock.

            /* if the storage area of the part is not nettable the dynamic    */
            /* available-to-promise check should not be executed. This has    */
            /* to be tested here for all new or modified lines.               */

            glNettableStorageArea = ML_Ort.Disponibel.

          end. /* if V_BelegPos.LagerOrt <> ? */

        end. /*  if (V_BelegPos.Lagerort <> ? ... */

      &ENDIF

      /* cross selling item ------------------------------------------------- */

      run pruefeFolgeteile.

    end. /* if V_BelegPos.Wertposition = no */

    /* in case of manually finding object, menu may be activated ------------ */

    &IF "{&pa_V_Traeger_auto}":U = "2":U &THEN

      if (V_BelegPos.Herk_Belegart       = ?
        or can-do('A,U,VUR':U,V_BelegPos.Herk_Belegart))
        and V_BelegPos.gelieferte_Menge  = 0 then

        run set-attribute-list ('ChangeCostUnit=yes':U).

    &ENDIF

    /* disable tax code fields ---------------------------------------------- */

    run Umsatzsteuer.

    &IF lookup("VU_RAAUF","{&PA-OPTIONEN}") > 0 &THEN

      if V_BelegPos.Herk_Belegart = 'VUR':U then
      do:

        if V_BelegPos.MMM_CusRefOrder_ID:sensitive in frame {&frame-name} = yes then
        do:

          run get-attribute ('KommissionsNrRahmen':U).

          if return-value = 'yes':U then
          do:

            run get-attribute ('MMM_CusRefOrder_ID':U).

            {setwidgetattr
               "V_BelegPos.MMM_CusRefOrder_ID"
               "screen-value"
               "return-value"
               "in frame {&frame-name}"}.

          end. /* if return-value = 'yes':U */

        end. /* if V_BelegPos.MMM_CusRefOrder_ID:sensitive in frame {&frame-name} = yes */

        run get-attribute ('RahmenME':U).

        if return-value       <> ?
          and giMengeneinheit <> integer(return-value) then
        do:

          giMengeneinheit = integer(return-value).

          find S_ArtME
            where S_ArtME.Firma         = {firma/sartikel.fir pACConnectionSvc:prpcCompany}
              and S_ArtME.Artikel       = V_BelegPos.Artikel
              and S_ArtME.Mengeneinheit = giMengeneinheit
            no-lock no-error.

            assign
              gdVME_Faktor      = (if available S_ArtME then
                                     S_ArtME.VME_Faktor
                                   else
                                     1)
              giNachkomma       = {fnarg
                                    pa_iDyCchUnitOfMeasureDecimals
                                    "pACConnectionSvc:prpcCompany,
                                     (if available S_ArtME then
                                        giMengeneinheit
                                      else
                                        S_Artikel.LagerME)"}
              c_text-VME        = {fnarg
                                    pa_cDyCchUnitOfMeasureDesc
                                    "pACConnectionSvc:prpcCompany,
                                     (if available S_ArtME then
                                        giMengeneinheit
                                      else
                                        S_Artikel.LagerME),
                                     pACConnectionSvc:prpcLanguage,
                                     {&pa_CchShortCut}"}
              c_Mengeneinheit-1 = c_text-VME
              c_Mengeneinheit-2 = c_Mengeneinheit-1
              c_Mengeneinheit-3 = c_Mengeneinheit-1
              c_Mengeneinheit-4 = c_Mengeneinheit-1

              {setwidgetattr
                 "d_Menge"
                 "format"
                 "string(entry(giNachkomma + 1,{&pa_MengenEingabeFormat},{&pa-Delimiter4}))"
                 "in frame {&FRAME-NAME}"}
              {setwidgetattr
                 "d_reserviert"
                 "format"
                 "string(entry(giNachkomma + 1,{&pa_MengenEingabeFormat},{&pa-Delimiter4}))"
                 "in frame {&FRAME-NAME}"}
              {setwidgetattr
                 "d_geliefert"
                 "format"
                 "string(entry(giNachkomma + 1,{&pa_MengenEingabeFormat},{&pa-Delimiter4}))"
                 "in frame {&FRAME-NAME}"}
              {setwidgetattr
                 "d_Storno"
                 "format"
                 "string(entry(giNachkomma + 1,{&pa_MengenEingabeFormat},{&pa-Delimiter4}))"
                 "in frame {&FRAME-NAME}"}
              .

            {adm/incl/d__duh00.if
               &Var1     = "c_text-VME"
               &Var2     = "c_Mengeneinheit-1"
               &Var3     = "c_Mengeneinheit-2"
               &Var4     = "c_Mengeneinheit-3"
               &Var5     = "c_Mengeneinheit-4"
               &WithFrame = "frame {&frame-name}"}

            find first S_EAN
              where S_EAN.Firma         = S_Artikel.Firma
                and S_EAN.Mengeneinheit = giMengeneinheit
                and S_EAN.Artikel       = V_BelegPos.Artikel
              use-index EANME
              no-lock no-error.

            gcEAN = (if available S_EAN then
                       S_EAN.EAN
                     else
                       '':U).

            {adm/incl/d__duh00.if
               &Var1     = "gcEAN"
               &WithFrame = "frame {&FRAME-NAME}"}

            if not available S_EAN
              and not can-do({&pa_V_PTList_WithoutEAN},string(S_Artikel.Artikelart)) then

              {fnarg
                pa_lUISvcEnableWidget
                  "gcEAN:handle in frame {&frame-name}"}.

            else

              {fnarg
                pa_lUISvcDisableWidget
                  "gcEAN:handle in frame {&frame-name}"}.

            if available S_ArtME
              and V_BelegPos.Wertposition = no then

               {setwidgetattr
                  "V_BelegPos.GewichtVerp"
                  "screen-value"
                  "string(S_ArtME.Gewicht, V_BelegPos.GewichtVerp:format in frame {&frame-name})"
                  "in frame {&frame-name}"}.

        end.  /* if giMengeneinheit <> integer(return-value) */

      end.  /* if V_BelegPos.Herk_Belegart = 'VUR':U */

    &ENDIF

    /* check if assigning packages is allowed. if assignments are already     */
    /* existing, then the button for packageunit (VME) must not be enabled    */

    &IF lookup ("M_Pack","{&PA-OPTIONEN}") > 0 &THEN

      if    V_BelegPos.Wertposition  = no
        and (   V_Belegpos.Lagerort <> ?
             or can-do({&pa_S_PTList_Set}, string(S_Artikel.ArtikelArt)))
        /* Orders are already assign to a transport, so allow Packaging */
        &IF LOOKUP("U_CW":U,"{&PA-OPTIONEN}":U) > 0 &THEN
        and (V_BelegKopf.BelegArt = 'U':U
             or not can-find(first V_SendungPos
                             where V_SendungPos.Firma           = V_BelegPos.Firma
                               and V_SendungPos.Herk_Belegart   = V_BelegKopf.Belegart
                               and V_SendungPos.Herk_ReferenzNr = V_BelegKopf.ReferenzNr))
        &ELSE /* original */
        and not can-find(first V_SendungPos
                           where V_SendungPos.Firma           = V_BelegPos.Firma
                             and V_SendungPos.Herk_Belegart   = V_BelegKopf.Belegart
                             and V_SendungPos.Herk_ReferenzNr = V_BelegKopf.ReferenzNr)
        &ENDIF

        and (    V_BelegPos.Belegart                          = 'U':U
             and not mawi.base.api.cls.MMCPickingApi:Instance:lDocLineIsInPicking(V_BelegPos.V_BelegPos_Obj)) then

        run set-attribute-list ('ChangePackaging=yes':U).

      if can-find(first M_LTPos
                    where M_LTPos.Firma            = {firma/mlartort.fir pACConnectionSvc:prpcCompany}
                      and M_LTPos.Bereich          = {&pa_ML_PackagingArea_Sales}
                      and M_LTPos.Funktion         = {&pa_MM_PackagingInstruction}  /* 1 */
                      and M_LTPos.Herk_Belegart2   = V_BelegPos.Belegart
                      and M_LTPos.Herk_Schluessel2 = {vert/incl/v_belko.sl &Tabelle = "V_BelegKopf"}
                      and M_LTPos.Herk_Belegart3   = V_BelegPos.Belegart
                      and M_LTPos.Herk_Schluessel3 = {vert/incl/v_belpo.sl &Tabelle = "V_BelegPos"}) then
      do:

        {fnarg
          pa_lUISvcDisableWidget
            "btnVME:handle in frame {&frame-name}"}.

        run set-attribute-list ('ChangeSalesUnit=no':U).

      end.

    &ENDIF

    /* field terms of delivery remains closed in case of drop shipment and    */
    /* in case that a place of destination ist required                       */

    &IF "{&pa_S_IncoTerm}":U = "1":U &THEN

      &IF LOOKUP("U_CI":U,"{&PA-OPTIONEN}":U) > 0 &THEN
      if V_BelegPos.uCI_Vertriebsweg = {&uCI_VertriebswegStrecke}
      &ELSE
      if   V_BelegKopf.Strecke        = yes
      &ENDIF

        or V_BelegKopf.Bestimmungsort = 3 then

        {fnarg
          pa_lUISvcDisableWidget
            "V_BelegPos.Lieferbedingung:handle in frame {&frame-name}"}.

    &ENDIF

    &IF lookup("MU":U,"{&PA-MODULE}":U) > 0 &THEN

      if V_BelegPos.Konfiguration = yes then
      do:

        {fnarg
          pa_lUISvcDisableWidget
            "d_Menge:handle in frame {&frame-name}"}.

        {fnarg
          pa_lUISvcDisableWidget
            "btnVME:handle in frame {&frame-name}"}.

        run set-attribute-list ('ChangeSalesUnit=no':U).

      end. /* if V_BelegPos.Konfiguration = yes */

    &ENDIF

  end.  /* if V_BelegPos.Satzart = 'A':U */

end. /* Main */

return.

end procedure.

/* _UIB-CODE-BLOCK-END */
&ANALYZE-RESUME

&ANALYZE-SUSPEND _UIB-CODE-BLOCK _PROCEDURE pa_UIMenmi_PPS_Funktion V-table-Win 
procedure pa_UIMenmi_PPS_Funktion :
/* Description ---------------------------------------------------------------*/
/*                                                                            */
/* Load RueckMeldeNr and then launch WorkOrder                                */
/*                                                                            */
/*----------------------------------------------------------------------------*/

define input parameter pcRunMode as character no-undo.

define variable cProgramm as character no-undo.

define buffer bPP_Auftrag for PP_Auftrag.

if    glPP_Auftrag
  and available V_BelegPos
  and available V_BelegKopf
  and V_BelegPos.Satzart      = 'A':U
  and V_BelegPos.Wertposition = no then
do:

  /* First search for a work order with the same part.                    */

  find first bPP_Auftrag
    where bPP_Auftrag.Firma        = {firma/ppauftra.fir pACConnectionSvc:prpcCompany}
      and bPP_Auftrag.Belegnummer  = V_BelegKopf.Belegnummer
      and bPP_Auftrag.PositionsNr  = V_BelegPos.PositionsNr
      and bPP_Auftrag.nicht_erster = no
      and bPP_Auftrag.Coverage_Obj = V_BelegPos.V_BelegPos_Obj
      and bPP_Auftrag.Artikel      = V_BelegPos.Artikel
      and bPP_Auftrag.ArtVar       = V_BelegPos.ArtVar
    use-index Beleg
    no-lock no-error.

  if not available bPP_Auftrag then

    /* If not found search for the first work order and ignore the part   */

    find first bPP_Auftrag
      where bPP_Auftrag.Firma        = {firma/ppauftra.fir pACConnectionSvc:prpcCompany}
        and bPP_Auftrag.Belegnummer  = V_BelegKopf.Belegnummer
        and bPP_Auftrag.PositionsNr  = V_BelegPos.PositionsNr
        and bPP_Auftrag.nicht_erster = no
        and bPP_Auftrag.Coverage_Obj = V_BelegPos.V_BelegPos_Obj
      use-index Beleg
      no-lock no-error.

end. /* if glPP_Auftrag */

assign
  giRueckmeldeNr = (if available bPP_Auftrag then
                      bPP_Auftrag.RueckMeldeNr
                    else
                      ?)
  cProgramm      = (if pcRunMode matches '*Info*':U then
                      'info/pps/proc/ipiauf00.w':U
                    else
                      'pps/prod/proc/pppauf00.w':U)
  .

{adm/incl/d__run01.if
  &Programm = "cProgramm"
  &Link1    = "'record':U"
  &Source1  = "this-procedure"
  &RunMode  = "pcRunMode"
}

end procedure. /* pa_UIMenmi_PPS_Funktion */

/* _UIB-CODE-BLOCK-END */
&ANALYZE-RESUME

&ANALYZE-SUSPEND _UIB-CODE-BLOCK _PROCEDURE Reservation V-table-Win 
procedure Reservation :
/* Description ---------------------------------------------------------------*/
/*                                                                            */
/* Make the Reservation for the Document Line and refresh the                 */
/* Reservation-Field d_reserviert                                             */
/*                                                                            */
/* Variables -----------------------------------------------------------------*/
/*                                                                            */
/* dQtyReserved            quantiy reserved with correct decimal places       */
/* iDecimalPlaces          decimal places from storage unit of measure        */
/* lRoundQuantity          round the quantity to the right decimal places     */
/*                                                                            */
/*----------------------------------------------------------------------------*/

define variable dQtyReserved   like MMR_Reservation.QtyReserved no-undo.
define variable iDecimalPlaces like S_MengenEinheit.Nachkomma   no-undo.
define variable lRoundQuantity as   logical                     no-undo.

define buffer bV_BelegKopf for V_BelegKopf.
define buffer bV_BelegPos  for V_BelegPos.

Main:
do transaction
  on error  undo Main, leave
  on endkey undo Main, leave:

  /* If an error occurs then do not throw it but leave this procedure.        */
  /* Otherwise procedure end-update wouldn't be passed and the screen-value   */
  /* of the line fields wouldn't get reset                                    */

  if    available V_BelegPos
    and V_BelegPos.Satzart                                                = 'A':U
    and V_BelegPos.WertPosition                                           = no
    and V_BelegPos.Offen                                                  = yes
    and V_BelegPos.LagerOrt                                              <> ?
    and d_reserviert:hidden in frame {&frame-name}                        = no
    and V_BelegKopf.Belegart                                              = 'U':U
    and (   (    input frame {&frame-name} V_BelegPos.Lagerort           <> ?
             and input frame {&frame-name} d_reserviert * gdVME_Faktor   <> gdMerke_resMenge)
         or (    input frame {&frame-name} d_reserviert                   > 0
             and input frame {&frame-name} V_BelegPos.Lagerort           <> giMerke_Lagerort)
         or (    input frame {&frame-name} V_BelegPos.MMM_CusRefOrder_ID <> V_BelegPos.MMM_CusRefOrder_ID
             and (   input frame {&frame-name} d_reserviert               > 0
                  or gdMerke_resMenge                                    <> 0))) then
  do:

    /*------------------------------------------------------------------------*/
    /* We can make only Reservations, when we have the Document Line in       */
    /* exclusive-lock                                                         */
    /*------------------------------------------------------------------------*/

    validate bV_BelegPos.

    find bV_BelegPos
      where bV_BelegPos.V_BelegPos_Obj = V_BelegPos.V_BelegPos_Obj
      exclusive-lock.

    find bV_BelegKopf
      where bV_BelegKopf.Firma      = {firma/vbelegko.fir V_BelegPos.Firma}
        and bV_BelegKopf.BelegArt   = bV_BelegPos.BelegArt
        and bV_BelegKopf.ReferenzNr = bV_BelegPos.ReferenzNr
      no-lock.

    /* reserved with the right decimal places. Otherwise, round up the quantity */

    if    available S_Artikel
      and S_Artikel.IsPackagingUnitToStock = no
      and bV_BelegPos.Mengeneinheit       <> S_Artikel.LagerME
      and S_Artikel.Chargenart             = '':U then
    do:

      /* to determine the decimal places from LME --------------------------- */

      iDecimalPlaces = {fnarg
                         pa_iDyCchUnitOfMeasureDecimals
                         "pACConnectionSvc:prpcCompany,
                          S_Artikel.LagerME"}.

      if  (input frame {&frame-name} d_reserviert * gdVME_Faktor)
        - truncate ((input frame {&frame-name} d_reserviert * gdVME_Faktor),iDecimalPlaces) <> 0 then

        assign 
          lRoundQuantity = yes                  
          dQtyReserved   = round((input frame {&frame-name} d_reserviert * gdVME_Faktor) + (5 / exp(10,iDecimalPlaces + 1)),
                                 iDecimalPlaces)
          .

      else
        dQtyReserved = input frame {&frame-name} d_reserviert.

    end. /* if available S_Artikel ... */
    else

      dQtyReserved = input frame {&frame-name} d_reserviert.
     
    mawi.base.cls.MMCReservationSvc:prpoInstance:CreateReservation (bV_BelegPos.V_BelegPos_Obj,
                                                                    bV_BelegPos.Belegart,
                                                                    '':U,
                                                                    input frame {&frame-name} V_BelegPos.LagerOrt,
                                                                    bV_BelegPos.Artikel,
                                                                    bV_BelegPos.ArtVar,
                                                                    input frame {&frame-name} V_BelegPos.MMM_CusRefOrder_ID,
                                                                    V_BelegKopf.BelegDatum,
                                                                    dQtyReserved,
                                                                    (if lRoundQuantity = no then
                                                                      gdVME_Faktor
                                                                     else
                                                                       1),
                                                                    (if lRoundQuantity = no then
                                                                       bV_BelegPos.Mengeneinheit
                                                                     else
                                                                       S_Artikel.LagerME),
                                                                    'UR':U,
                                                                    '':U
                                                                    &IF LOOKUP("M_Pack-Plus","{&PA-OPTIONEN}") > 0 &THEN
                                                                      ,yes
                                                                    &ENDIF                                                                    
                                                                    ).

    d_reserviert = truncate(mawi.base.cls.MMCReservationSvc:prpoInstance:dReviewReservationQty
                              (bV_BelegPos.V_BelegPos_Obj,
                               bV_BelegPos.BelegArt,
                               input frame {&frame-name} V_BelegPos.Lagerort,
                               input frame {&frame-name} V_BelegPos.MMM_CusRefOrder_ID)
                            / gdVME_Faktor_Sales, bV_BelegPos.Nachkomma).

    {adm/incl/d__duh00.if
       &Var1     = "d_reserviert"
       &WithFrame = "frame {&frame-name}"}

  end. /* if available V_BelegPos */

end. /* Main */

return.

end procedure. /* Reservation */

/* _UIB-CODE-BLOCK-END */
&ANALYZE-RESUME

&ANALYZE-SUSPEND _UIB-CODE-BLOCK _PROCEDURE send-key V-table-Win  adm/support/proc/_key-snd.p
procedure send-key :
/* Description ---------------------------------------------------------------*/
/*                                                                            */
/* Sends a requested KEY value back to the calling SmartObject                */
/*                                                                            */
/* Parameters ----------------------------------------------------------------*/
/*                                                                            */
/* see adm/template/sndkytop.i                                                */
/*                                                                            */
/*----------------------------------------------------------------------------*/

/*----------------------------------------------------------------------------*/
/* Processing                                                                 */
/*----------------------------------------------------------------------------*/

/* Define variables needed by this internal procedure.                        */

{adm/template/incl/sndkytop.i}

/* Return the key value associated with each key case.                        */

{adm/template/incl/sndkycas.i "RueckmeldeNr" " " "giRueckmeldeNr" " "}
{adm/template/incl/sndkycas.i "Lagergruppe" " " "giLagergruppe" " "}
{adm/template/incl/sndkycas.i "BelegArt" "V_BelegKopf" "BelegArt" " "}
{adm/template/incl/sndkycas.i "Coverage_MRPDocType" "V_BelegKopf" "BelegArt" " "}
{adm/template/incl/sndkycas.i "ReferenzNr" "V_BelegKopf" "ReferenzNr" " "}
{adm/template/incl/sndkycas.i "LfdNr_SR" "V_BelegPos" "LfdNr_SR" " "}
{adm/template/incl/sndkycas.i "PositionsNr" "V_BelegPos" "PositionsNr" " "}
{adm/template/incl/sndkycas.i "PosObj" "V_BelegPos" "V_BelegPos_Obj" " "}
{adm/template/incl/sndkycas.i "Artikel" "V_BelegPos" "Artikel" " "}
{adm/template/incl/sndkycas.i "ArtVar" "V_BelegPos" "ArtVar" " "}
{adm/template/incl/sndkycas.i "Menge" " " "input frame {&frame-name} d_Menge" " "}
{adm/template/incl/sndkycas.i "Position" "V_BelegPos" "PositionsNr" " "}
{adm/template/incl/sndkycas.i "SetPosition" " " "0" " "}
{adm/template/incl/sndkycas.i "Coverage_Obj" "V_BelegPos" "V_BelegPos_Obj" " "}
{adm/template/incl/sndkycas.i "V_BelegKopf_Obj" "V_BelegKopf" "V_BelegKopf_Obj" " "}
{adm/template/incl/sndkycas.i "Origin_Obj" "V_BelegKopf" "Origin_Obj" " "}
{adm/template/incl/sndkycas.i "JBT_Project_Obj" "V_BelegKopf" "JBT_Project_Obj" " "}
{adm/template/incl/sndkycas.i "SBM_BankDataAcc_Obj" "V_BelegKopf" "SBM_BankDataAcc_Obj" " "}
{adm/template/incl/sndkycas.i "V_BelegPos_Obj" "V_BelegPos" "V_BelegPos_Obj" " "}
{adm/template/incl/sndkycas.i "Origin_Obj" "V_BelegKopf" "Origin_Obj" " "}
{adm/template/incl/sndkycas.i "Origin_Obj" "V_BelegPos" "Origin_Obj" " "}
{adm/template/incl/sndkycas.i "PosObj" "V_BelegPos" "V_BelegPos_Obj" " "}
{adm/template/incl/sndkycas.i "Owning_Obj" "DBM_ShortDescription" "Owning_Obj" " "}
{adm/template/incl/sndkycas.i "MMM_CusRefOrder_Obj" "V_BelegKopf" "MMM_CusRefOrder_Obj" " "}
{adm/template/incl/sndkycas.i "MMM_CusRefOrder_Obj" "V_BelegPos" "MMM_CusRefOrder_Obj" " "}
{adm/template/incl/sndkycas.i "Driver_Obj" "V_BelegKopf" "Driver_Obj" " "}
{adm/template/incl/sndkycas.i "SBM_BusinessCategory_Obj" "V_BelegKopf" "SBM_BusinessCategory_Obj" " "}
{adm/template/incl/sndkycas.i "SBM_ProfitCenter_Obj" "V_BelegKopf" "SBM_ProfitCenter_Obj" " "}
{adm/template/incl/sndkycas.i "SBM_FiscalText_Obj" "V_BelegKopf" "SBM_FiscalText_Obj" " "}
{adm/template/incl/sndkycas.i "SBM_TaxCase_Obj" "V_BelegKopf" "SBM_TaxCase_Obj" " "}
{adm/template/incl/sndkycas.i "S_Steuer_Obj" "V_BelegKopf" "S_Steuer_Obj" " "}
{adm/template/incl/sndkycas.i "S_Steuer_Obj" "V_BelegPos" "S_Steuer_Obj" " "}
{adm/template/incl/sndkycas.i "Driver_Obj" "V_BelegPos" "Driver_Obj" " "}
{adm/template/incl/sndkycas.i "SBM_BusinessCategory_Obj" "V_BelegPos" "SBM_BusinessCategory_Obj" " "}
{adm/template/incl/sndkycas.i "SBM_CustomsTariffNo_Obj" "V_BelegPos" "SBM_CustomsTariffNo_Obj" " "}
{adm/template/incl/sndkycas.i "Sys_S_Steuer_Obj" "V_BelegPos" "Sys_S_Steuer_Obj" " "}
{adm/template/incl/sndkycas.i "S_F_Journal_Obj" "V_BelegKopf" "S_F_Journal_Obj" " "}
{adm/template/incl/sndkycas.i "uCM_PP_StkZeile_Obj" "V_BelegPos" "uCM_PP_StkZeile_Obj" " "}
{adm/template/incl/sndkycas.i "S_I_TaxExemption_Obj" "V_BelegKopf" "S_I_TaxExemption_Obj" " "}
{adm/template/incl/sndkycas.i "S_BankVerb_Obj" "V_BelegKopf" "S_BankVerb_Obj" " "}
{adm/template/incl/sndkycas.i "MMT_Picking_Obj" "V_BelegPos" "MMT_Picking_Obj" " "}
{adm/template/incl/sndkycas.i "JBT_PartsPlan_Obj" "V_BelegPos" "JBT_PartsPlan_Obj" " "}
{adm/template/incl/sndkycas.i "VBM_PreConfigVariant_Obj" "V_BelegKopf" "VBM_PreConfigVariant_Obj" " "}

/* Close the CASE statement and end the procedure.                            */

{adm/template/incl/sndkyend.i}

end procedure. /* send-key */

/* _UIB-CODE-BLOCK-END */
&ANALYZE-RESUME

&ANALYZE-SUSPEND _UIB-CODE-BLOCK _PROCEDURE send-records V-table-Win  adm/support/proc/ds_rec01.p
procedure send-records :
/* Description ---------------------------------------------------------------*/
/*                                                                            */
/* Send record ROWID's for all tables used by this file.                      */
/*                                                                            */
/* Parameters ----------------------------------------------------------------*/
/*                                                                            */
/* see template/incl/snd-head.i                                               */
/*                                                                            */
/*----------------------------------------------------------------------------*/

/*----------------------------------------------------------------------------*/
/* Processing                                                                 */
/*----------------------------------------------------------------------------*/

/* Define variables needed by this internal procedure.                        */

{adm/template/incl/snd-head.i}

/* For each requested table, put it's ROWID in the output list.               */

{adm/template/incl/snd-list.i "V_BelegKopf"}
{adm/template/incl/snd-list.i "V_BelegPos"}

/* Deal with any unexpected table requests before closing.                    */

{adm/template/incl/snd-end.i}

end procedure. /* send-records */

/* _UIB-CODE-BLOCK-END */
&ANALYZE-RESUME

&ANALYZE-SUSPEND _UIB-CODE-BLOCK _PROCEDURE Seriennummern V-table-Win 
procedure Seriennummern :
/* Description ---------------------------------------------------------------*/
/*                                                                            */
/* Entry of serial numbers                                                    */
/*                                                                            */
/*----------------------------------------------------------------------------*/

define variable iQuantity        as integer   no-undo.
define variable cPKS             as character no-undo.
define variable cOriginObj       as character no-undo.
define variable lCRORelSalesProd as logical   no-undo.
define variable dProdQuantity    as decimal   no-undo.

define buffer bPP_Auftrag for PP_Auftrag.
define buffer bS_Kunde    for S_Kunde.

Main:
do on error undo Main, leave Main
  on endkey undo Main, leave Main:

  iQuantity = integer(((input frame {&frame-name} d_Menge * gdVME_Faktor)
                        - V_BelegPos.gelieferte_Menge
                        - V_BelegPos.stornierte_Menge)).

  &IF lookup("MS":U,"{&pa-Module}":U) > 0 &THEN

    /* ---------------------------------------------------------------------- */
    /* Check if a CRO-Relation to a work order exists                         */
    /* ---------------------------------------------------------------------- */

    if can-find (first PP_Auftrag
                    where PP_Auftrag.Firma               = {firma/ppauftra.fir pACConnectionSvc:prpcCompany}
                      and PP_Auftrag.Coverage_Obj        = V_BelegPos.V_BelegPos_Obj
                      and PP_Auftrag.Coverage_MRPDocType = 'U':U) then
    do:

      lCRORelSalesProd = yes.

      find first bPP_Auftrag
        where bPP_Auftrag.Firma        = {firma/ppauftra.fir pACConnectionSvc:prpcCompany}
          and bPP_Auftrag.Coverage_Obj = V_BelegPos.V_BelegPos_Obj
          and bPP_Auftrag.nicht_erster = no
        no-lock.

        assign
          cOriginObj     = bPP_Auftrag.PP_Auftrag_Obj
          dProdQuantity  = bPP_Auftrag.Produktionsmenge
          .

    end.

    if iQuantity > 0 then
    do:

      find bS_Kunde
        where bS_Kunde.Firma = {firma/s_kunde.fir pACConnectionSvc:prpcCompany}
          and bS_Kunde.Kunde = V_BelegKopf.Kunde
        no-lock no-error.

      assign
        cPks = adm.method.cls.DMCParameterStringSvc:cWriteValue('':U,'S_Artikel_Obj':U,S_Artikel.S_Artikel_Obj)
        cPks = adm.method.cls.DMCParameterStringSvc:cWriteValue(cPks,'DocType':U,V_BelegPos.Belegart)
        cPks = adm.method.cls.DMCParameterStringSvc:cWriteValue(cPks,'OrgDocType':U,'':U)
        cPks = adm.method.cls.DMCParameterStringSvc:cWriteValue(cPks,'DocPosObj':U,V_BelegPos.V_BelegPos_Obj)
        cPks = adm.method.cls.DMCParameterStringSvc:cWriteValue(cPks,'Quantity':U,iQuantity)
        cPks = adm.method.cls.DMCParameterStringSvc:cWriteValue(cPKS,'StorageArea':U,input frame {&frame-name} V_BelegPos.Lagerort)
        cPks = adm.method.cls.DMCParameterStringSvc:cWriteValue(cPks,'WarrantyFr':U,V_BelegKopf.Belegdatum)
        cPks = adm.method.cls.DMCParameterStringSvc:cWriteValue(cPks,'Cancel':U,no)
        cPks = adm.method.cls.DMCParameterStringSvc:cWriteValue(cPks,'OrgDocPosObj':U,cOriginObj)
        cPks = adm.method.cls.DMCParameterStringSvc:cWriteValue(cPks,'DoBau':U,no)
        cPks = adm.method.cls.DMCParameterStringSvc:cWriteValue(cPks,'CRORelSalesProd':U,lCRORelSalesProd)
        cPks = adm.method.cls.DMCParameterStringSvc:cWriteValue(cPks,'S_Kunde_Obj':U, (if available bS_Kunde then
                                                                                                       bS_Kunde.S_Kunde_Obj
                                                                                                     else
                                                                                                       '':U))
        .

      {adm/incl/d__run01.if
        &Programm = "mawi/serie/proc/mspsnr10.w"
        &Link1    = "'record':U"
        &Source1  = "this-procedure"
        &PKS      = "cPKS"
      }

    end.

    else
    do:

      {adm/incl/d__msg00.if
        &Meldung    = "'mssnr00012':U"
      }

      undo Main, leave Main.

    end.

  &ENDIF

end.

end procedure. /* Seriennummern */

/* _UIB-CODE-BLOCK-END */
&ANALYZE-RESUME

&ANALYZE-SUSPEND _UIB-CODE-BLOCK _PROCEDURE setPurchasePrice V-table-Win 
procedure setPurchasePrice :
/* Description ---------------------------------------------------------------*/
/*                                                                            */
/* set purchase price - called from menu or local assign statement            */
/*                                                                            */
/*----------------------------------------------------------------------------*/

run Einkaufspreis(input-output gdEinstandspreis).

glEinstandspreis = yes.

catch oError as Progress.Lang.Error:

  glEinstandspreis = no.

end catch.  /* Progress.Lang.Error */

end procedure.

/* _UIB-CODE-BLOCK-END */
&ANALYZE-RESUME

&ANALYZE-SUSPEND _UIB-CODE-BLOCK _PROCEDURE state-changed V-table-Win 
procedure state-changed :
/* Description ---------------------------------------------------------------*/
/*                                                                            */
/* Handle state-changed messages                                              */
/*                                                                            */
/* Notes ---------------------------------------------------------------------*/
/*                                                                            */
/*                                                                            */
/*                                                                            */
/* Parameters ----------------------------------------------------------------*/
/*                                                                            */
/* phIssuer     Handle of calling object                                      */
/* pcState      new state                                                     */
/*                                                                            */
/*----------------------------------------------------------------------------*/

define input parameter phIssuer as handle    no-undo.
define input parameter pcState  as character no-undo.

/* Variables -----------------------------------------------------------------*/
/*----------------------------------------------------------------------------*/

define variable hFocus as handle no-undo.

/* Buffers -------------------------------------------------------------------*/

/*----------------------------------------------------------------------------*/
/* Processing                                                                 */
/*----------------------------------------------------------------------------*/

case pcState:

  /* Object instance CASEs can go here to replace standard behavior or add    */
  /* new cases.                                                               */

  &IF LOOKUP("U_CI":U,"{&PA-OPTIONEN}":U) > 0 &THEN
  when 'uErfasseIntraStat':U then do:

    run new-state('update-begin,record-source':U).

    run erfasse-Intradaten (no) no-error.

    run new-state ('uTOOLBAR-SAVE,group-assign-source':U).

  end.

  when 'uOpenAndSave':U then do:

    run new-state('update-begin,record-source':U).

    run new-state ('uTOOLBAR-SAVE,group-assign-source':U).

  end.
  &ENDIF

  {adm/template/incl/dt_viw00.if}

  when 'Neuanlage':U then

    glNewPosition = yes.

  when 'keine-Neuanlage':U then

    glNewPosition = no.

  when 'Textbaustein':U then
  do:

    hFocus = {focus}.

    if valid-handle (hFocus)
      and can-do('d_Menge,Gewicht,Einzelpreis,Wert_RZ_1,Wert_RZ_2,Proz_RZ_1,Proz_RZ_2,Proz_RZ_3':U,{focus name}) then

      apply 'leave':U to hFocus.

  end. /* when 'Textbaustein':U */

  when 'MRPChanged':U then do:

    run request-attribute( this-procedure,
                      'record-source':U,
                      'MRPRelease':U).

    if (return-value = 'yes':U) then

      {fnarg
        pa_lUISvcEnableWidget
        "d_reserviert:handle in frame {&frame-name}"}.
    else

      {fnarg
        pa_lUISvcDisableWidget
        "d_reserviert:handle in frame {&frame-name}"}.

  end. /* when 'MRPChanged':U */

  /* Update eco tax amount of a part which is not sales BOM                   */
  /* do with transaction, otherwise the procedure 'state-changed' will get    */
  /* the transaction scope, which is not our intention.                       */

  &IF "{&pa_S_F_EcoTax}":U = "1":U &THEN

    when 'F_UpdateOldEcoTaxAmount':U then
      if    pACConnectionSvc:prpcLocalization = 'F':U
        and not can-do({&pa_S_PTList_Set}, string(S_Artikel.ArtikelArt,'99':U)) then
      do:

        {adm/incl/d__run03.if
          &Procedure = "vert/proc/v_neccf0.p"
          &Arguments = "       V_BelegPos.V_BelegPos_Obj,
                        output gdFEcoTaxCalc"
        }

      end. /* if pACConnectionSvc:prpcLocalization = 'F':U... */

    when 'F_UpdateEcoTaxAmount':U then
      if    pACConnectionSvc:prpcLocalization = 'F':U
        and not can-do({&pa_S_PTList_Set}, string(S_Artikel.ArtikelArt,'99':U)) then
      do transaction on error undo, throw:

        {vert/incl/v__ecaf0.if}

      end. /* if pACConnectionSvc:prpcLocalization = 'F':U... */

  &ENDIF

  when 'pruefeFolgeteile':U then
    run pruefeFolgeteile.

  &IF LOOKUP("Q_DEL":U,"{&PA-OPTIONEN}":U) > 0 &THEN

    when 'MetalSurchargeChanged':U then
    do:

      {setwidgetattr
        V_BelegPos.Metalsurcharge
        screen-value
        "string(stamm.base.cls.SBCMetalSvc:prpoInstance:dCalculateTotalMetalSurchargeOfDocumentPos
                  (V_BelegPos.V_BelegPos_Obj,
                   input frame {&FRAME-NAME} d_Menge))"
        "in frame {&frame-name}"}.

      run Preis_anzeigen('MetalSurcharge':U).

    end. /* when 'MetalSurchargeChanged':U */

  &ENDIF

end case. /* pcState */

end procedure. /* state-changed */

/* _UIB-CODE-BLOCK-END */
&ANALYZE-RESUME

&ANALYZE-SUSPEND _UIB-CODE-BLOCK _PROCEDURE use-Archive V-table-Win 
procedure use-Archive :
/* Description ---------------------------------------------------------------*/
/*                                                                            */
/* Sets variable glArchive.                                                   */
/*                                                                            */
/* Parameters ----------------------------------------------------------------*/
/*                                                                            */
/* pcArchive   the document-line is just being archived                       */
/*                                                                            */
/*----------------------------------------------------------------------------*/

define input parameter pcArchive as character no-undo.

glArchive = logical(pcArchive).

end procedure. /* use-Archive */

/* _UIB-CODE-BLOCK-END */
&ANALYZE-RESUME


&ANALYZE-SUSPEND _UIB-CODE-BLOCK  _PROCEDURE CURRENT-WINDOW-layouts _LAYOUT-CASES
procedure CURRENT-WINDOW-layouts:
  define input parameter layout as character                     no-undo.
  define variable lbl-hndl as widget-handle                      no-undo.
  define variable widg-pos as decimal                            no-undo.

  /* Copy the name of the active layout into a variable accessible to   */
  /* the rest of this file.                                             */
  CURRENT-WINDOW-layout = layout.

  case layout:
    when "Master Layout" then do:
      assign
         &IF '{&WINDOW-SYSTEM}' NE 'TTY':U &THEN
         frame F-Main:HIDDEN                               = yes &ENDIF
         frame F-Main:HEIGHT                               = 22.

      assign
         V_BelegPos.Abladestelle:HIDDEN in frame F-Main    = yes
         V_BelegPos.Abladestelle:WIDTH in frame F-Main     = 20
         V_BelegPos.Abladestelle:HIDDEN in frame F-Main    = no
         V_BelegPos.Abladestelle:HIDDEN in frame F-Main    = no.

      assign
         V_BelegPos.Bezeichnung[3]:HIDDEN in frame F-Main  = no.

      assign
         S_ArtikelSpr.Bezeichnung[3]:HIDDEN in frame F-Main = no.

      assign
         V_BelegPos.Bezeichnung[4]:HIDDEN in frame F-Main  = no.

      assign
         S_ArtikelSpr.Bezeichnung[4]:HIDDEN in frame F-Main = no.

      assign
         btnTax:HIDDEN in frame F-Main                     = yes
         btnTax:ROW in frame F-Main                        = 19
         btnTax:HIDDEN in frame F-Main                     = no.

      assign
         btnVME:HIDDEN in frame F-Main                     = yes
         btnVME:ROW in frame F-Main                        = 5.5
         btnVME:HIDDEN in frame F-Main                     = no.

      assign
         c_Gew-Mengeneinheit:HIDDEN in frame F-Main        = yes
         c_Gew-Mengeneinheit:ROW in frame F-Main           = 11.5
         c_Gew-Mengeneinheit:HIDDEN in frame F-Main        = no
         c_Gew-Mengeneinheit:HIDDEN in frame F-Main        = yes
         c_Gew-Mengeneinheit:WIDTH in frame F-Main         = 8
         c_Gew-Mengeneinheit:HIDDEN in frame F-Main        = no
         c_Gew-Mengeneinheit:HIDDEN in frame F-Main        = no.

      assign
         c_LME:HIDDEN in frame F-Main                      = yes
         c_LME:ROW in frame F-Main                         = 7
         c_LME:HIDDEN in frame F-Main                      = no.

      assign
         c_Mengeneinheit-1:HIDDEN in frame F-Main          = yes
         c_Mengeneinheit-1:ROW in frame F-Main             = 5.5
         c_Mengeneinheit-1:HIDDEN in frame F-Main          = no.

      assign
         c_Mengeneinheit-2:HIDDEN in frame F-Main          = yes
         c_Mengeneinheit-2:ROW in frame F-Main             = 6.5
         c_Mengeneinheit-2:HIDDEN in frame F-Main          = no
         c_Mengeneinheit-2:HIDDEN in frame F-Main          = no.

      assign
         c_Mengeneinheit-3:HIDDEN in frame F-Main          = yes
         c_Mengeneinheit-3:ROW in frame F-Main             = 8.5
         c_Mengeneinheit-3:HIDDEN in frame F-Main          = no.

      assign
         c_Mengeneinheit-4:HIDDEN in frame F-Main          = yes
         c_Mengeneinheit-4:ROW in frame F-Main             = 7.5
         c_Mengeneinheit-4:HIDDEN in frame F-Main          = no
         c_Mengeneinheit-4:HIDDEN in frame F-Main          = yes
         c_Mengeneinheit-4:WIDTH in frame F-Main           = 8
         c_Mengeneinheit-4:HIDDEN in frame F-Main          = no
         c_Mengeneinheit-4:HIDDEN in frame F-Main          = no.

      assign
         c_Mengeneinheit-5:HIDDEN in frame F-Main          = no.

      assign
         c_Preisherkunft-1:HIDDEN in frame F-Main          = yes
         c_Preisherkunft-1:ROW in frame F-Main             = 7
         c_Preisherkunft-1:HIDDEN in frame F-Main          = no.

      assign
         c_Preisherkunft-2:HIDDEN in frame F-Main          = yes
         c_Preisherkunft-2:ROW in frame F-Main             = 12
         c_Preisherkunft-2:HIDDEN in frame F-Main          = no.

      assign
         c_Preisherkunft-3:HIDDEN in frame F-Main          = yes
         c_Preisherkunft-3:ROW in frame F-Main             = 13
         c_Preisherkunft-3:HIDDEN in frame F-Main          = no.

      assign
         c_Preisherkunft-4:HIDDEN in frame F-Main          = yes
         c_Preisherkunft-4:ROW in frame F-Main             = 14
         c_Preisherkunft-4:HIDDEN in frame F-Main          = no.

      assign
         c_Preisherkunft-5:HIDDEN in frame F-Main          = yes
         c_Preisherkunft-5:ROW in frame F-Main             = 9
         c_Preisherkunft-5:HIDDEN in frame F-Main          = no
         c_Preisherkunft-5:HIDDEN in frame F-Main          = no.

      assign
         c_Preisherkunft-6:HIDDEN in frame F-Main          = yes
         c_Preisherkunft-6:ROW in frame F-Main             = 10
         c_Preisherkunft-6:HIDDEN in frame F-Main          = no
         c_Preisherkunft-6:HIDDEN in frame F-Main          = no.

      assign
         c_Rabatt-1:HIDDEN in frame F-Main                 = yes
         c_Rabatt-1:ROW in frame F-Main                    = 12
         c_Rabatt-1:HIDDEN in frame F-Main                 = no.

      assign
         c_Rabatt-2:HIDDEN in frame F-Main                 = yes
         c_Rabatt-2:ROW in frame F-Main                    = 13
         c_Rabatt-2:HIDDEN in frame F-Main                 = no.

      assign
         c_Rabatt-3:HIDDEN in frame F-Main                 = yes
         c_Rabatt-3:ROW in frame F-Main                    = 14
         c_Rabatt-3:HIDDEN in frame F-Main                 = no.

      assign
         c_text-1:HIDDEN in frame F-Main                   = yes
         c_text-1:ROW in frame F-Main                      = 11.5
         c_text-1:HIDDEN in frame F-Main                   = no
         c_text-1:HIDDEN in frame F-Main                   = yes
         c_text-1:WIDTH in frame F-Main                    = 4
         c_text-1:HIDDEN in frame F-Main                   = no
         c_text-1:HIDDEN in frame F-Main                   = no.

      assign
         c_text-14:HIDDEN in frame F-Main                  = yes
         c_text-14:ROW in frame F-Main                     = 12.5
         c_text-14:HIDDEN in frame F-Main                  = no
         c_text-14:HIDDEN in frame F-Main                  = no.

      assign
         c_text-VME:HIDDEN in frame F-Main                 = yes
         c_text-VME:ROW in frame F-Main                    = 12.5
         c_text-VME:HIDDEN in frame F-Main                 = no
         c_text-VME:HIDDEN in frame F-Main                 = yes
         c_text-VME:WIDTH in frame F-Main                  = 8
         c_text-VME:HIDDEN in frame F-Main                 = no
         c_text-VME:HIDDEN in frame F-Main                 = no.

      assign
         c_wBez-1:HIDDEN in frame F-Main                   = yes
         c_wBez-1:ROW in frame F-Main                      = 16
         c_wBez-1:HIDDEN in frame F-Main                   = no.

      assign
         d_beauftragt:HIDDEN in frame F-Main               = no.

      assign
         d_geliefert:HIDDEN in frame F-Main                = yes
         widg-pos = d_geliefert:ROW in frame F-Main 
         d_geliefert:ROW in frame F-Main                   = 6.5
         lbl-hndl = d_geliefert:SIDE-LABEL-HANDLE in frame F-Main 
         lbl-hndl:row = lbl-hndl:row + d_geliefert:ROW in frame F-Main  - widg-pos
         d_geliefert:HIDDEN in frame F-Main                = no
         d_geliefert:HIDDEN in frame F-Main                = no.

      assign
         d_Gesamtpreis:HIDDEN in frame F-Main              = yes
         widg-pos = d_Gesamtpreis:ROW in frame F-Main 
         d_Gesamtpreis:ROW in frame F-Main                 = 16
         lbl-hndl = d_Gesamtpreis:SIDE-LABEL-HANDLE in frame F-Main 
         lbl-hndl:row = lbl-hndl:row + d_Gesamtpreis:ROW in frame F-Main  - widg-pos
         d_Gesamtpreis:HIDDEN in frame F-Main              = no.

      assign
         d_Menge:HIDDEN in frame F-Main                    = yes
         widg-pos = d_Menge:ROW in frame F-Main 
         d_Menge:ROW in frame F-Main                       = 5.5
         lbl-hndl = d_Menge:SIDE-LABEL-HANDLE in frame F-Main 
         lbl-hndl:row = lbl-hndl:row + d_Menge:ROW in frame F-Main  - widg-pos
         d_Menge:HIDDEN in frame F-Main                    = no.

      assign
         d_Mindestmenge:HIDDEN in frame F-Main             = yes
         d_Mindestmenge:WIDTH in frame F-Main              = 16
         d_Mindestmenge:HIDDEN in frame F-Main             = no
         d_Mindestmenge:HIDDEN in frame F-Main             = no.

      assign
         d_reserviert:HIDDEN in frame F-Main               = yes
         widg-pos = d_reserviert:ROW in frame F-Main 
         d_reserviert:ROW in frame F-Main                  = 8.5
         lbl-hndl = d_reserviert:SIDE-LABEL-HANDLE in frame F-Main 
         lbl-hndl:row = lbl-hndl:row + d_reserviert:ROW in frame F-Main  - widg-pos
         d_reserviert:HIDDEN in frame F-Main               = no.

      assign
         d_Storno:HIDDEN in frame F-Main                   = yes
         widg-pos = d_Storno:ROW in frame F-Main 
         d_Storno:ROW in frame F-Main                      = 7.5
         lbl-hndl = d_Storno:SIDE-LABEL-HANDLE in frame F-Main 
         lbl-hndl:row = lbl-hndl:row + d_Storno:ROW in frame F-Main  - widg-pos
         d_Storno:HIDDEN in frame F-Main                   = no
         d_Storno:HIDDEN in frame F-Main                   = yes
         d_Storno:WIDTH in frame F-Main                    = 16
         d_Storno:HIDDEN in frame F-Main                   = no
         d_Storno:HIDDEN in frame F-Main                   = no.

      assign
         d_Verkaufspreis:HIDDEN in frame F-Main            = yes
         widg-pos = d_Verkaufspreis:ROW in frame F-Main 
         d_Verkaufspreis:ROW in frame F-Main               = 11
         lbl-hndl = d_Verkaufspreis:SIDE-LABEL-HANDLE in frame F-Main 
         lbl-hndl:row = lbl-hndl:row + d_Verkaufspreis:ROW in frame F-Main  - widg-pos
         d_Verkaufspreis:HIDDEN in frame F-Main            = no
         d_Verkaufspreis:HIDDEN in frame F-Main            = yes
         d_Verkaufspreis:WIDTH in frame F-Main             = 20
         d_Verkaufspreis:HIDDEN in frame F-Main            = no
         d_Verkaufspreis:HIDDEN in frame F-Main            = no.

      assign
         V_BelegPos.Einzelpreis:HIDDEN in frame F-Main     = yes
         widg-pos = V_BelegPos.Einzelpreis:ROW in frame F-Main 
         V_BelegPos.Einzelpreis:ROW in frame F-Main        = 7
         lbl-hndl = V_BelegPos.Einzelpreis:SIDE-LABEL-HANDLE in frame F-Main 
         lbl-hndl:row = lbl-hndl:row + V_BelegPos.Einzelpreis:ROW in frame F-Main  - widg-pos
         V_BelegPos.Einzelpreis:HIDDEN in frame F-Main     = no.

      assign
         gc_Preisbezug-Rabattart-1:HIDDEN in frame F-Main  = yes
         gc_Preisbezug-Rabattart-1:ROW in frame F-Main     = 9
         gc_Preisbezug-Rabattart-1:HIDDEN in frame F-Main  = no
         gc_Preisbezug-Rabattart-1:HIDDEN in frame F-Main  = no.

      assign
         gc_Preisbezug-Rabattart-2:HIDDEN in frame F-Main  = yes
         gc_Preisbezug-Rabattart-2:ROW in frame F-Main     = 10
         gc_Preisbezug-Rabattart-2:HIDDEN in frame F-Main  = no
         gc_Preisbezug-Rabattart-2:HIDDEN in frame F-Main  = no.

      assign
         gcCROInfo:HIDDEN in frame F-Main                  = yes
         gcCROInfo:ROW in frame F-Main                     = 10.5
         gcCROInfo:HIDDEN in frame F-Main                  = no.

      assign
         gcEAN:HIDDEN in frame F-Main                      = yes
         widg-pos = gcEAN:ROW in frame F-Main 
         gcEAN:ROW in frame F-Main                         = 17
         lbl-hndl = gcEAN:SIDE-LABEL-HANDLE in frame F-Main 
         lbl-hndl:row = lbl-hndl:row + gcEAN:ROW in frame F-Main  - widg-pos
         gcEAN:HIDDEN in frame F-Main                      = no
         gcEAN:HIDDEN in frame F-Main                      = no.

      assign
         gcFEcoTaxOrigin:HIDDEN in frame F-Main            = yes
         gcFEcoTaxOrigin:ROW in frame F-Main               = 8
         gcFEcoTaxOrigin:HIDDEN in frame F-Main            = no.

      assign
         gcPriceUnitDesc:HIDDEN in frame F-Main            = yes
         gcPriceUnitDesc:ROW in frame F-Main               = 7
         gcPriceUnitDesc:HIDDEN in frame F-Main            = no.

      assign
         gcTimeUnitCombo:HIDDEN in frame F-Main            = yes
         gcTimeUnitCombo:ROW in frame F-Main               = 17
         gcTimeUnitCombo:HIDDEN in frame F-Main            = no.

      assign
         gcuAbfahrtszeit:HIDDEN in frame F-Main            = yes
         gcuAbfahrtszeit:ROW in frame F-Main               = 21
         gcuAbfahrtszeit:HIDDEN in frame F-Main            = no.

      assign
         gcZollNummer:HIDDEN in frame F-Main               = yes
         widg-pos = gcZollNummer:ROW in frame F-Main 
         gcZollNummer:ROW in frame F-Main                  = 5
         lbl-hndl = gcZollNummer:SIDE-LABEL-HANDLE in frame F-Main 
         lbl-hndl:row = lbl-hndl:row + gcZollNummer:ROW in frame F-Main  - widg-pos
         gcZollNummer:HIDDEN in frame F-Main               = no
         gcZollNummer:HIDDEN in frame F-Main               = yes
         gcZollNummer:WIDTH in frame F-Main                = 16
         gcZollNummer:HIDDEN in frame F-Main               = no
         gcZollNummer:HIDDEN in frame F-Main               = no.

      assign
         gdAkzeptierte_Menge:HIDDEN in frame F-Main        = no
         gdAkzeptierte_Menge:HIDDEN in frame F-Main        = yes
         gdAkzeptierte_Menge:WIDTH in frame F-Main         = 16
         gdAkzeptierte_Menge:HIDDEN in frame F-Main        = no.

      assign
         gdSteuersatz:HIDDEN in frame F-Main               = yes
         gdSteuersatz:ROW in frame F-Main                  = 19
         gdSteuersatz:HIDDEN in frame F-Main               = no.

      assign
         gdTaxSum:HIDDEN in frame F-Main                   = yes
         widg-pos = gdTaxSum:ROW in frame F-Main 
         gdTaxSum:ROW in frame F-Main                      = 19
         lbl-hndl = gdTaxSum:SIDE-LABEL-HANDLE in frame F-Main 
         lbl-hndl:row = lbl-hndl:row + gdTaxSum:ROW in frame F-Main  - widg-pos
         gdTaxSum:HIDDEN in frame F-Main                   = no.

      assign
         V_BelegPos.Gewicht:HIDDEN in frame F-Main         = yes
         widg-pos = V_BelegPos.Gewicht:ROW in frame F-Main 
         V_BelegPos.Gewicht:ROW in frame F-Main            = 11.5
         lbl-hndl = V_BelegPos.Gewicht:SIDE-LABEL-HANDLE in frame F-Main 
         lbl-hndl:row = lbl-hndl:row + V_BelegPos.Gewicht:ROW in frame F-Main  - widg-pos
         V_BelegPos.Gewicht:HIDDEN in frame F-Main         = no
         V_BelegPos.Gewicht:HIDDEN in frame F-Main         = yes
         V_BelegPos.Gewicht:WIDTH in frame F-Main          = 16
         V_BelegPos.Gewicht:HIDDEN in frame F-Main         = no
         V_BelegPos.Gewicht:HIDDEN in frame F-Main         = no.

      assign
         V_BelegPos.GewichtVerp:HIDDEN in frame F-Main     = yes
         widg-pos = V_BelegPos.GewichtVerp:ROW in frame F-Main 
         V_BelegPos.GewichtVerp:ROW in frame F-Main        = 12.5
         lbl-hndl = V_BelegPos.GewichtVerp:SIDE-LABEL-HANDLE in frame F-Main 
         lbl-hndl:row = lbl-hndl:row + V_BelegPos.GewichtVerp:ROW in frame F-Main  - widg-pos
         V_BelegPos.GewichtVerp:HIDDEN in frame F-Main     = no
         V_BelegPos.GewichtVerp:HIDDEN in frame F-Main     = no.

      assign
         giKO_LagerOrt:HIDDEN in frame F-Main              = yes
         giKO_LagerOrt:ROW in frame F-Main                 = 9.5
         giKO_LagerOrt:HIDDEN in frame F-Main              = no.

      assign
         gtuAbfahrtsdatum:HIDDEN in frame F-Main           = yes
         gtuAbfahrtsdatum:ROW in frame F-Main              = 21
         gtuAbfahrtsdatum:HIDDEN in frame F-Main           = no.

      assign
         gtuAbfahrtsdatum_Info:HIDDEN in frame F-Main      = yes
         gtuAbfahrtsdatum_Info:ROW in frame F-Main         = 21
         gtuAbfahrtsdatum_Info:HIDDEN in frame F-Main      = no.

      assign
         V_BelegPos.IncoTerm:HIDDEN in frame F-Main        = yes
         V_BelegPos.IncoTerm:ROW in frame F-Main           = 10.5
         V_BelegPos.IncoTerm:HIDDEN in frame F-Main        = no
         V_BelegPos.IncoTerm:HIDDEN in frame F-Main        = no.

      assign
         V_BelegPos.LagerOrt:HIDDEN in frame F-Main        = yes
         widg-pos = V_BelegPos.LagerOrt:ROW in frame F-Main 
         V_BelegPos.LagerOrt:ROW in frame F-Main           = 9.5
         lbl-hndl = V_BelegPos.LagerOrt:SIDE-LABEL-HANDLE in frame F-Main 
         lbl-hndl:row = lbl-hndl:row + V_BelegPos.LagerOrt:ROW in frame F-Main  - widg-pos
         V_BelegPos.LagerOrt:HIDDEN in frame F-Main        = no.

      assign
         V_BelegPos.LieferBedingung:HIDDEN in frame F-Main = yes
         widg-pos = V_BelegPos.LieferBedingung:ROW in frame F-Main 
         V_BelegPos.LieferBedingung:ROW in frame F-Main    = 10.5
         lbl-hndl = V_BelegPos.LieferBedingung:SIDE-LABEL-HANDLE in frame F-Main 
         lbl-hndl:row = lbl-hndl:row + V_BelegPos.LieferBedingung:ROW in frame F-Main  - widg-pos
         V_BelegPos.LieferBedingung:HIDDEN in frame F-Main = no
         V_BelegPos.LieferBedingung:HIDDEN in frame F-Main = yes
         V_BelegPos.LieferBedingung:WIDTH in frame F-Main  = 4
         V_BelegPos.LieferBedingung:HIDDEN in frame F-Main = no
         V_BelegPos.LieferBedingung:HIDDEN in frame F-Main = no.

      assign
         V_BelegPos.Liefertermin:HIDDEN in frame F-Main    = yes
         widg-pos = V_BelegPos.Liefertermin:ROW in frame F-Main 
         V_BelegPos.Liefertermin:ROW in frame F-Main       = 15
         lbl-hndl = V_BelegPos.Liefertermin:SIDE-LABEL-HANDLE in frame F-Main 
         lbl-hndl:row = lbl-hndl:row + V_BelegPos.Liefertermin:ROW in frame F-Main  - widg-pos
         V_BelegPos.Liefertermin:HIDDEN in frame F-Main    = no.

      assign
         V_BelegPos.Lieferzeit:HIDDEN in frame F-Main      = yes
         V_BelegPos.Lieferzeit:WIDTH in frame F-Main       = 4
         V_BelegPos.Lieferzeit:HIDDEN in frame F-Main      = no
         V_BelegPos.Lieferzeit:HIDDEN in frame F-Main      = no.

      assign
         V_BelegPos.Lieferzeit_Einheit:HIDDEN in frame F-Main = yes
         V_BelegPos.Lieferzeit_Einheit:WIDTH in frame F-Main = 12
         V_BelegPos.Lieferzeit_Einheit:HIDDEN in frame F-Main = no
         V_BelegPos.Lieferzeit_Einheit:HIDDEN in frame F-Main = no.

      assign
         V_BelegPos.Metalsurcharge:HIDDEN in frame F-Main  = yes
         widg-pos = V_BelegPos.Metalsurcharge:ROW in frame F-Main 
         V_BelegPos.Metalsurcharge:ROW in frame F-Main     = 15
         lbl-hndl = V_BelegPos.Metalsurcharge:SIDE-LABEL-HANDLE in frame F-Main 
         lbl-hndl:row = lbl-hndl:row + V_BelegPos.Metalsurcharge:ROW in frame F-Main  - widg-pos
         V_BelegPos.Metalsurcharge:HIDDEN in frame F-Main  = no.

      assign
         V_BelegPos.MMM_CusRefOrder_ID:HIDDEN in frame F-Main = yes
         widg-pos = V_BelegPos.MMM_CusRefOrder_ID:ROW in frame F-Main 
         V_BelegPos.MMM_CusRefOrder_ID:ROW in frame F-Main = 10.5
         lbl-hndl = V_BelegPos.MMM_CusRefOrder_ID:SIDE-LABEL-HANDLE in frame F-Main 
         lbl-hndl:row = lbl-hndl:row + V_BelegPos.MMM_CusRefOrder_ID:ROW in frame F-Main  - widg-pos
         V_BelegPos.MMM_CusRefOrder_ID:HIDDEN in frame F-Main = no.

      assign
         V_BelegPos.proz_RZ_1:HIDDEN in frame F-Main       = yes
         V_BelegPos.proz_RZ_1:ROW in frame F-Main          = 12
         V_BelegPos.proz_RZ_1:HIDDEN in frame F-Main       = no.

      assign
         V_BelegPos.proz_RZ_2:HIDDEN in frame F-Main       = yes
         V_BelegPos.proz_RZ_2:ROW in frame F-Main          = 13
         V_BelegPos.proz_RZ_2:HIDDEN in frame F-Main       = no.

      assign
         V_BelegPos.proz_RZ_3:HIDDEN in frame F-Main       = yes
         V_BelegPos.proz_RZ_3:ROW in frame F-Main          = 14
         V_BelegPos.proz_RZ_3:HIDDEN in frame F-Main       = no.

      assign
         V_BelegPos.proz_RZ_Art_1:HIDDEN in frame F-Main   = yes
         V_BelegPos.proz_RZ_Art_1:ROW in frame F-Main      = 12
         V_BelegPos.proz_RZ_Art_1:HIDDEN in frame F-Main   = no.

      assign
         V_BelegPos.proz_RZ_Art_2:HIDDEN in frame F-Main   = yes
         V_BelegPos.proz_RZ_Art_2:ROW in frame F-Main      = 13
         V_BelegPos.proz_RZ_Art_2:HIDDEN in frame F-Main   = no.

      assign
         V_BelegPos.proz_RZ_Art_3:HIDDEN in frame F-Main   = yes
         V_BelegPos.proz_RZ_Art_3:ROW in frame F-Main      = 14
         V_BelegPos.proz_RZ_Art_3:HIDDEN in frame F-Main   = no.

      assign
         V_BelegPos.Transportzeit:HIDDEN in frame F-Main   = yes
         widg-pos = V_BelegPos.Transportzeit:ROW in frame F-Main 
         V_BelegPos.Transportzeit:ROW in frame F-Main      = 17
         lbl-hndl = V_BelegPos.Transportzeit:SIDE-LABEL-HANDLE in frame F-Main 
         lbl-hndl:row = lbl-hndl:row + V_BelegPos.Transportzeit:ROW in frame F-Main  - widg-pos
         V_BelegPos.Transportzeit:HIDDEN in frame F-Main   = no.

      assign
         V_BelegPos.uCE_ReferenceDocItemPos:HIDDEN in frame F-Main = yes
         widg-pos = V_BelegPos.uCE_ReferenceDocItemPos:ROW in frame F-Main 
         V_BelegPos.uCE_ReferenceDocItemPos:ROW in frame F-Main = 20
         lbl-hndl = V_BelegPos.uCE_ReferenceDocItemPos:SIDE-LABEL-HANDLE in frame F-Main 
         lbl-hndl:row = lbl-hndl:row + V_BelegPos.uCE_ReferenceDocItemPos:ROW in frame F-Main  - widg-pos
         V_BelegPos.uCE_ReferenceDocItemPos:HIDDEN in frame F-Main = no.

      assign
         V_BelegPos.uCI_KommZeit:HIDDEN in frame F-Main    = yes
         widg-pos = V_BelegPos.uCI_KommZeit:ROW in frame F-Main 
         V_BelegPos.uCI_KommZeit:ROW in frame F-Main       = 18
         lbl-hndl = V_BelegPos.uCI_KommZeit:SIDE-LABEL-HANDLE in frame F-Main 
         lbl-hndl:row = lbl-hndl:row + V_BelegPos.uCI_KommZeit:ROW in frame F-Main  - widg-pos
         V_BelegPos.uCI_KommZeit:HIDDEN in frame F-Main    = no.

      assign
         V_BelegPos.uCI_KommZeiteinheit:HIDDEN in frame F-Main = yes
         V_BelegPos.uCI_KommZeiteinheit:ROW in frame F-Main = 18
         V_BelegPos.uCI_KommZeiteinheit:HIDDEN in frame F-Main = no.

      assign
         V_BelegPos.uCI_Lot:HIDDEN in frame F-Main         = yes
         widg-pos = V_BelegPos.uCI_Lot:ROW in frame F-Main 
         V_BelegPos.uCI_Lot:ROW in frame F-Main            = 22
         lbl-hndl = V_BelegPos.uCI_Lot:SIDE-LABEL-HANDLE in frame F-Main 
         lbl-hndl:row = lbl-hndl:row + V_BelegPos.uCI_Lot:ROW in frame F-Main  - widg-pos
         V_BelegPos.uCI_Lot:HIDDEN in frame F-Main         = no.

      assign
         V_BelegPos.uCI_Versandart:HIDDEN in frame F-Main  = yes
         widg-pos = V_BelegPos.uCI_Versandart:ROW in frame F-Main 
         V_BelegPos.uCI_Versandart:ROW in frame F-Main     = 19
         lbl-hndl = V_BelegPos.uCI_Versandart:SIDE-LABEL-HANDLE in frame F-Main 
         lbl-hndl:row = lbl-hndl:row + V_BelegPos.uCI_Versandart:ROW in frame F-Main  - widg-pos
         V_BelegPos.uCI_Versandart:HIDDEN in frame F-Main  = no.

      assign
         V_BelegPos.uCI_Warenausgangstermin:HIDDEN in frame F-Main = yes
         V_BelegPos.uCI_Warenausgangstermin:ROW in frame F-Main = 17
         V_BelegPos.uCI_Warenausgangstermin:HIDDEN in frame F-Main = no.

      assign
         V_BelegPos.uCW_Tour:HIDDEN in frame F-Main        = yes
         widg-pos = V_BelegPos.uCW_Tour:ROW in frame F-Main 
         V_BelegPos.uCW_Tour:ROW in frame F-Main           = 20
         lbl-hndl = V_BelegPos.uCW_Tour:SIDE-LABEL-HANDLE in frame F-Main 
         lbl-hndl:row = lbl-hndl:row + V_BelegPos.uCW_Tour:ROW in frame F-Main  - widg-pos
         V_BelegPos.uCW_Tour:HIDDEN in frame F-Main        = no.

      assign
         V_BelegPos.uCW_TransportNr:HIDDEN in frame F-Main = yes
         widg-pos = V_BelegPos.uCW_TransportNr:ROW in frame F-Main 
         V_BelegPos.uCW_TransportNr:ROW in frame F-Main    = 21
         lbl-hndl = V_BelegPos.uCW_TransportNr:SIDE-LABEL-HANDLE in frame F-Main 
         lbl-hndl:row = lbl-hndl:row + V_BelegPos.uCW_TransportNr:ROW in frame F-Main  - widg-pos
         V_BelegPos.uCW_TransportNr:HIDDEN in frame F-Main = no.

      assign
         V_BelegPos.Ursprungszeugnis:HIDDEN in frame F-Main = yes
         V_BelegPos.Ursprungszeugnis:ROW in frame F-Main   = 5
         V_BelegPos.Ursprungszeugnis:HIDDEN in frame F-Main = no
         V_BelegPos.Ursprungszeugnis:HIDDEN in frame F-Main = no.

      assign
         V_BelegPos.USTax_Override:HIDDEN in frame F-Main  = yes
         V_BelegPos.USTax_Override:ROW in frame F-Main     = 19
         V_BelegPos.USTax_Override:HIDDEN in frame F-Main  = no.

      assign
         V_BelegPos.USTax_TaxFree:HIDDEN in frame F-Main   = yes
         V_BelegPos.USTax_TaxFree:ROW in frame F-Main      = 18
         V_BelegPos.USTax_TaxFree:HIDDEN in frame F-Main   = no.

      assign
         V_BelegPos_LieferBedingung_Info:HIDDEN in frame F-Main = yes
         V_BelegPos_LieferBedingung_Info:ROW in frame F-Main = 10.5
         V_BelegPos_LieferBedingung_Info:HIDDEN in frame F-Main = no
         V_BelegPos_LieferBedingung_Info:HIDDEN in frame F-Main = no.

      assign
         V_BelegPos_Liefertermin_Info:HIDDEN in frame F-Main = yes
         V_BelegPos_Liefertermin_Info:ROW in frame F-Main  = 15
         V_BelegPos_Liefertermin_Info:HIDDEN in frame F-Main = no.

      assign
         V_BelegPos_Steuer_Bez:HIDDEN in frame F-Main      = yes
         widg-pos = V_BelegPos_Steuer_Bez:ROW in frame F-Main 
         V_BelegPos_Steuer_Bez:ROW in frame F-Main         = 19
         lbl-hndl = V_BelegPos_Steuer_Bez:SIDE-LABEL-HANDLE in frame F-Main 
         lbl-hndl:row = lbl-hndl:row + V_BelegPos_Steuer_Bez:ROW in frame F-Main  - widg-pos
         V_BelegPos_Steuer_Bez:HIDDEN in frame F-Main      = no.

      assign
         V_BelegPos_uCI_Versandart_Info:HIDDEN in frame F-Main = yes
         V_BelegPos_uCI_Versandart_Info:ROW in frame F-Main = 19
         V_BelegPos_uCI_Versandart_Info:HIDDEN in frame F-Main = no.

      assign
         V_BelegPos_Versandtermin_Info:HIDDEN in frame F-Main = yes
         V_BelegPos_Versandtermin_Info:ROW in frame F-Main = 18
         V_BelegPos_Versandtermin_Info:HIDDEN in frame F-Main = no.

      assign
         V_BelegPos_Wunschtermin_Info:HIDDEN in frame F-Main = yes
         V_BelegPos_Wunschtermin_Info:ROW in frame F-Main  = 14
         V_BelegPos_Wunschtermin_Info:HIDDEN in frame F-Main = no.

      assign
         V_BeleI_Warenausgangstermin_Info:HIDDEN in frame F-Main = yes
         V_BeleI_Warenausgangstermin_Info:ROW in frame F-Main = 17
         V_BeleI_Warenausgangstermin_Info:HIDDEN in frame F-Main = no.

      assign
         V_BelegPos.Versandtermin:HIDDEN in frame F-Main   = yes
         V_BelegPos.Versandtermin:ROW in frame F-Main      = 18
         V_BelegPos.Versandtermin:HIDDEN in frame F-Main   = no.

      assign
         V_BelegPos.Wareneinsatz:HIDDEN in frame F-Main    = yes
         V_BelegPos.Wareneinsatz:ROW in frame F-Main       = 6
         V_BelegPos.Wareneinsatz:HIDDEN in frame F-Main    = no
         V_BelegPos.Wareneinsatz:HIDDEN in frame F-Main    = no.

      assign
         V_BelegPos.Wert_RZ_1:HIDDEN in frame F-Main       = yes
         V_BelegPos.Wert_RZ_1:ROW in frame F-Main          = 9
         V_BelegPos.Wert_RZ_1:HIDDEN in frame F-Main       = no
         V_BelegPos.Wert_RZ_1:HIDDEN in frame F-Main       = yes
         V_BelegPos.Wert_RZ_1:WIDTH in frame F-Main        = 20
         V_BelegPos.Wert_RZ_1:HIDDEN in frame F-Main       = no
         V_BelegPos.Wert_RZ_1:HIDDEN in frame F-Main       = no.

      assign
         V_BelegPos.Wert_RZ_2:HIDDEN in frame F-Main       = yes
         V_BelegPos.Wert_RZ_2:ROW in frame F-Main          = 10
         V_BelegPos.Wert_RZ_2:HIDDEN in frame F-Main       = no
         V_BelegPos.Wert_RZ_2:HIDDEN in frame F-Main       = yes
         V_BelegPos.Wert_RZ_2:WIDTH in frame F-Main        = 20
         V_BelegPos.Wert_RZ_2:HIDDEN in frame F-Main       = no
         V_BelegPos.Wert_RZ_2:HIDDEN in frame F-Main       = no.

      assign
         V_BelegPos.Wert_RZ_5:HIDDEN in frame F-Main       = yes
         V_BelegPos.Wert_RZ_5:ROW in frame F-Main          = 8
         V_BelegPos.Wert_RZ_5:HIDDEN in frame F-Main       = no.

      assign
         V_BelegPos.Wert_RZ_Art_1:HIDDEN in frame F-Main   = yes
         V_BelegPos.Wert_RZ_Art_1:ROW in frame F-Main      = 9
         V_BelegPos.Wert_RZ_Art_1:HIDDEN in frame F-Main   = no
         V_BelegPos.Wert_RZ_Art_1:HIDDEN in frame F-Main   = no.

      assign
         V_BelegPos.Wert_RZ_Art_2:HIDDEN in frame F-Main   = yes
         V_BelegPos.Wert_RZ_Art_2:ROW in frame F-Main      = 10
         V_BelegPos.Wert_RZ_Art_2:HIDDEN in frame F-Main   = no
         V_BelegPos.Wert_RZ_Art_2:HIDDEN in frame F-Main   = no.

      assign
         V_BelegPos.Wunschtermin:HIDDEN in frame F-Main    = yes
         widg-pos = V_BelegPos.Wunschtermin:ROW in frame F-Main 
         V_BelegPos.Wunschtermin:ROW in frame F-Main       = 14
         lbl-hndl = V_BelegPos.Wunschtermin:SIDE-LABEL-HANDLE in frame F-Main 
         lbl-hndl:row = lbl-hndl:row + V_BelegPos.Wunschtermin:ROW in frame F-Main  - widg-pos
         V_BelegPos.Wunschtermin:HIDDEN in frame F-Main    = no.

      assign
         V_BelegPos.Zeiteinheit:HIDDEN in frame F-Main     = yes
         V_BelegPos.Zeiteinheit:WIDTH in frame F-Main      = 8
         V_BelegPos.Zeiteinheit:HIDDEN in frame F-Main     = no
         V_BelegPos.Zeiteinheit:HIDDEN in frame F-Main     = yes
         V_BelegPos.Zeiteinheit:ROW in frame F-Main        = 17
         V_BelegPos.Zeiteinheit:HIDDEN in frame F-Main     = no.

      assign

         frame F-Main:VIRTUAL-HEIGHT                       = 22.00
                    when frame F-Main:SCROLLABLE
         &IF '{&WINDOW-SYSTEM}' NE 'TTY':U &THEN
         frame F-Main:HIDDEN                               = no &ENDIF.

    end.  /* Master Layout Layout Case */

    when "BaseEntry":U then do:
      assign
         V_BelegPos.Abladestelle:HIDDEN in frame F-Main    = yes
         V_BelegPos.Abladestelle:WIDTH in frame F-Main     = 19.

      assign
         btnTax:HIDDEN in frame F-Main                     = yes
         btnTax:ROW in frame F-Main                        = 21
         btnTax:HIDDEN in frame F-Main                     = no.

      assign
         c_Gew-Mengeneinheit:HIDDEN in frame F-Main        = yes
         c_Gew-Mengeneinheit:ROW in frame F-Main           = 12.5
         c_Gew-Mengeneinheit:HIDDEN in frame F-Main        = no.

      assign
         c_LME:HIDDEN in frame F-Main                      = yes
         c_LME:ROW in frame F-Main                         = 8
         c_LME:HIDDEN in frame F-Main                      = no.

      assign
         c_Mengeneinheit-2:HIDDEN in frame F-Main          = yes
         c_Mengeneinheit-2:ROW in frame F-Main             = 7.5
         c_Mengeneinheit-2:HIDDEN in frame F-Main          = no.

      assign
         c_Mengeneinheit-3:HIDDEN in frame F-Main          = yes
         c_Mengeneinheit-3:ROW in frame F-Main             = 6.5
         c_Mengeneinheit-3:HIDDEN in frame F-Main          = no.

      assign
         c_Mengeneinheit-4:HIDDEN in frame F-Main          = yes
         c_Mengeneinheit-4:ROW in frame F-Main             = 8.5
         c_Mengeneinheit-4:HIDDEN in frame F-Main          = no.

      assign
         c_Mengeneinheit-5:HIDDEN in frame F-Main          = yes.

      assign
         c_Preisherkunft-1:HIDDEN in frame F-Main          = yes
         c_Preisherkunft-1:ROW in frame F-Main             = 8
         c_Preisherkunft-1:HIDDEN in frame F-Main          = no.

      assign
         c_Preisherkunft-2:HIDDEN in frame F-Main          = yes
         c_Preisherkunft-2:ROW in frame F-Main             = 13
         c_Preisherkunft-2:HIDDEN in frame F-Main          = no.

      assign
         c_Preisherkunft-3:HIDDEN in frame F-Main          = yes
         c_Preisherkunft-3:ROW in frame F-Main             = 14
         c_Preisherkunft-3:HIDDEN in frame F-Main          = no.

      assign
         c_Preisherkunft-4:HIDDEN in frame F-Main          = yes
         c_Preisherkunft-4:ROW in frame F-Main             = 15
         c_Preisherkunft-4:HIDDEN in frame F-Main          = no.

      assign
         c_Preisherkunft-5:HIDDEN in frame F-Main          = yes
         c_Preisherkunft-5:ROW in frame F-Main             = 10
         c_Preisherkunft-5:HIDDEN in frame F-Main          = no.

      assign
         c_Preisherkunft-6:HIDDEN in frame F-Main          = yes
         c_Preisherkunft-6:ROW in frame F-Main             = 11
         c_Preisherkunft-6:HIDDEN in frame F-Main          = no.

      assign
         c_Rabatt-1:HIDDEN in frame F-Main                 = yes
         c_Rabatt-1:ROW in frame F-Main                    = 13
         c_Rabatt-1:HIDDEN in frame F-Main                 = no.

      assign
         c_Rabatt-2:HIDDEN in frame F-Main                 = yes
         c_Rabatt-2:ROW in frame F-Main                    = 14
         c_Rabatt-2:HIDDEN in frame F-Main                 = no.

      assign
         c_Rabatt-3:HIDDEN in frame F-Main                 = yes
         c_Rabatt-3:ROW in frame F-Main                    = 15
         c_Rabatt-3:HIDDEN in frame F-Main                 = no.

      assign
         c_text-1:HIDDEN in frame F-Main                   = yes
         c_text-1:ROW in frame F-Main                      = 12.5
         c_text-1:HIDDEN in frame F-Main                   = no.

      assign
         c_text-14:HIDDEN in frame F-Main                  = yes
         c_text-14:ROW in frame F-Main                     = 13.5
         c_text-14:HIDDEN in frame F-Main                  = no.

      assign
         c_text-VME:HIDDEN in frame F-Main                 = yes
         c_text-VME:ROW in frame F-Main                    = 13.5
         c_text-VME:HIDDEN in frame F-Main                 = no.

      assign
         c_wBez-1:HIDDEN in frame F-Main                   = yes
         c_wBez-1:ROW in frame F-Main                      = 17
         c_wBez-1:HIDDEN in frame F-Main                   = no.

      assign
         d_beauftragt:HIDDEN in frame F-Main               = yes.

      assign
         d_geliefert:HIDDEN in frame F-Main                = yes
         widg-pos = d_geliefert:ROW in frame F-Main 
         d_geliefert:ROW in frame F-Main                   = 7.5
         lbl-hndl = d_geliefert:SIDE-LABEL-HANDLE in frame F-Main 
         lbl-hndl:row = lbl-hndl:row + d_geliefert:ROW in frame F-Main  - widg-pos
         d_geliefert:HIDDEN in frame F-Main                = no.

      assign
         d_Gesamtpreis:HIDDEN in frame F-Main              = yes
         widg-pos = d_Gesamtpreis:ROW in frame F-Main 
         d_Gesamtpreis:ROW in frame F-Main                 = 17
         lbl-hndl = d_Gesamtpreis:SIDE-LABEL-HANDLE in frame F-Main 
         lbl-hndl:row = lbl-hndl:row + d_Gesamtpreis:ROW in frame F-Main  - widg-pos
         d_Gesamtpreis:HIDDEN in frame F-Main              = no.

      assign
         d_Mindestmenge:HIDDEN in frame F-Main             = yes
         d_Mindestmenge:WIDTH in frame F-Main              = 19.

      assign
         d_reserviert:HIDDEN in frame F-Main               = yes
         widg-pos = d_reserviert:ROW in frame F-Main 
         d_reserviert:ROW in frame F-Main                  = 6.5
         lbl-hndl = d_reserviert:SIDE-LABEL-HANDLE in frame F-Main 
         lbl-hndl:row = lbl-hndl:row + d_reserviert:ROW in frame F-Main  - widg-pos
         d_reserviert:HIDDEN in frame F-Main               = no.

      assign
         d_Storno:HIDDEN in frame F-Main                   = yes
         widg-pos = d_Storno:ROW in frame F-Main 
         d_Storno:ROW in frame F-Main                      = 8.5
         lbl-hndl = d_Storno:SIDE-LABEL-HANDLE in frame F-Main 
         lbl-hndl:row = lbl-hndl:row + d_Storno:ROW in frame F-Main  - widg-pos
         d_Storno:HIDDEN in frame F-Main                   = no.

      assign
         d_Verkaufspreis:HIDDEN in frame F-Main            = yes
         widg-pos = d_Verkaufspreis:ROW in frame F-Main 
         d_Verkaufspreis:ROW in frame F-Main               = 12
         lbl-hndl = d_Verkaufspreis:SIDE-LABEL-HANDLE in frame F-Main 
         lbl-hndl:row = lbl-hndl:row + d_Verkaufspreis:ROW in frame F-Main  - widg-pos
         d_Verkaufspreis:HIDDEN in frame F-Main            = no.

      assign
         V_BelegPos.Einzelpreis:HIDDEN in frame F-Main     = yes
         widg-pos = V_BelegPos.Einzelpreis:ROW in frame F-Main 
         V_BelegPos.Einzelpreis:ROW in frame F-Main        = 8
         lbl-hndl = V_BelegPos.Einzelpreis:SIDE-LABEL-HANDLE in frame F-Main 
         lbl-hndl:row = lbl-hndl:row + V_BelegPos.Einzelpreis:ROW in frame F-Main  - widg-pos
         V_BelegPos.Einzelpreis:HIDDEN in frame F-Main     = no.

      assign
         gc_Preisbezug-Rabattart-1:HIDDEN in frame F-Main  = yes
         gc_Preisbezug-Rabattart-1:ROW in frame F-Main     = 10
         gc_Preisbezug-Rabattart-1:HIDDEN in frame F-Main  = no.

      assign
         gc_Preisbezug-Rabattart-2:HIDDEN in frame F-Main  = yes
         gc_Preisbezug-Rabattart-2:ROW in frame F-Main     = 11
         gc_Preisbezug-Rabattart-2:HIDDEN in frame F-Main  = no.

      assign
         gcEAN:HIDDEN in frame F-Main                      = yes
         widg-pos = gcEAN:ROW in frame F-Main 
         gcEAN:ROW in frame F-Main                         = 5
         lbl-hndl = gcEAN:SIDE-LABEL-HANDLE in frame F-Main 
         lbl-hndl:row = lbl-hndl:row + gcEAN:ROW in frame F-Main  - widg-pos
         gcEAN:HIDDEN in frame F-Main                      = no.

      assign
         gcFEcoTaxOrigin:HIDDEN in frame F-Main            = yes
         gcFEcoTaxOrigin:ROW in frame F-Main               = 9
         gcFEcoTaxOrigin:HIDDEN in frame F-Main            = no.

      assign
         gcPriceUnitDesc:HIDDEN in frame F-Main            = yes
         gcPriceUnitDesc:ROW in frame F-Main               = 8
         gcPriceUnitDesc:HIDDEN in frame F-Main            = no.

      assign
         gcZollNummer:HIDDEN in frame F-Main               = yes
         widg-pos = gcZollNummer:ROW in frame F-Main 
         gcZollNummer:ROW in frame F-Main                  = 6
         lbl-hndl = gcZollNummer:SIDE-LABEL-HANDLE in frame F-Main 
         lbl-hndl:row = lbl-hndl:row + gcZollNummer:ROW in frame F-Main  - widg-pos
         gcZollNummer:HIDDEN in frame F-Main               = no.

      assign
         gdAkzeptierte_Menge:HIDDEN in frame F-Main        = yes.

      assign
         gdSteuersatz:HIDDEN in frame F-Main               = yes
         gdSteuersatz:ROW in frame F-Main                  = 20
         gdSteuersatz:HIDDEN in frame F-Main               = no.

      assign
         gdTaxSum:HIDDEN in frame F-Main                   = yes
         widg-pos = gdTaxSum:ROW in frame F-Main 
         gdTaxSum:ROW in frame F-Main                      = 21
         lbl-hndl = gdTaxSum:SIDE-LABEL-HANDLE in frame F-Main 
         lbl-hndl:row = lbl-hndl:row + gdTaxSum:ROW in frame F-Main  - widg-pos
         gdTaxSum:HIDDEN in frame F-Main                   = no.

      assign
         V_BelegPos.Gewicht:HIDDEN in frame F-Main         = yes
         widg-pos = V_BelegPos.Gewicht:ROW in frame F-Main 
         V_BelegPos.Gewicht:ROW in frame F-Main            = 12.5
         lbl-hndl = V_BelegPos.Gewicht:SIDE-LABEL-HANDLE in frame F-Main 
         lbl-hndl:row = lbl-hndl:row + V_BelegPos.Gewicht:ROW in frame F-Main  - widg-pos
         V_BelegPos.Gewicht:HIDDEN in frame F-Main         = no.

      assign
         V_BelegPos.GewichtVerp:HIDDEN in frame F-Main     = yes
         widg-pos = V_BelegPos.GewichtVerp:ROW in frame F-Main 
         V_BelegPos.GewichtVerp:ROW in frame F-Main        = 13.5
         lbl-hndl = V_BelegPos.GewichtVerp:SIDE-LABEL-HANDLE in frame F-Main 
         lbl-hndl:row = lbl-hndl:row + V_BelegPos.GewichtVerp:ROW in frame F-Main  - widg-pos
         V_BelegPos.GewichtVerp:HIDDEN in frame F-Main     = no.

      assign
         V_BelegPos.IncoTerm:HIDDEN in frame F-Main        = yes
         V_BelegPos.IncoTerm:ROW in frame F-Main           = 11.5
         V_BelegPos.IncoTerm:HIDDEN in frame F-Main        = no.

      assign
         V_BelegPos.LieferBedingung:HIDDEN in frame F-Main = yes
         widg-pos = V_BelegPos.LieferBedingung:ROW in frame F-Main 
         V_BelegPos.LieferBedingung:ROW in frame F-Main    = 11.5
         lbl-hndl = V_BelegPos.LieferBedingung:SIDE-LABEL-HANDLE in frame F-Main 
         lbl-hndl:row = lbl-hndl:row + V_BelegPos.LieferBedingung:ROW in frame F-Main  - widg-pos
         V_BelegPos.LieferBedingung:HIDDEN in frame F-Main = no.

      assign
         V_BelegPos.Liefertermin:HIDDEN in frame F-Main    = yes
         widg-pos = V_BelegPos.Liefertermin:ROW in frame F-Main 
         V_BelegPos.Liefertermin:ROW in frame F-Main       = 16
         lbl-hndl = V_BelegPos.Liefertermin:SIDE-LABEL-HANDLE in frame F-Main 
         lbl-hndl:row = lbl-hndl:row + V_BelegPos.Liefertermin:ROW in frame F-Main  - widg-pos
         V_BelegPos.Liefertermin:HIDDEN in frame F-Main    = no.

      assign
         V_BelegPos.Lieferzeit:HIDDEN in frame F-Main      = yes
         V_BelegPos.Lieferzeit:WIDTH in frame F-Main       = 6.

      assign
         V_BelegPos.Lieferzeit_Einheit:HIDDEN in frame F-Main = yes
         V_BelegPos.Lieferzeit_Einheit:WIDTH in frame F-Main = 14.

      assign
         V_BelegPos.Metalsurcharge:HIDDEN in frame F-Main  = yes
         widg-pos = V_BelegPos.Metalsurcharge:ROW in frame F-Main 
         V_BelegPos.Metalsurcharge:ROW in frame F-Main     = 16
         lbl-hndl = V_BelegPos.Metalsurcharge:SIDE-LABEL-HANDLE in frame F-Main 
         lbl-hndl:row = lbl-hndl:row + V_BelegPos.Metalsurcharge:ROW in frame F-Main  - widg-pos
         V_BelegPos.Metalsurcharge:HIDDEN in frame F-Main  = no.

      assign
         V_BelegPos.proz_RZ_1:HIDDEN in frame F-Main       = yes
         V_BelegPos.proz_RZ_1:ROW in frame F-Main          = 13
         V_BelegPos.proz_RZ_1:HIDDEN in frame F-Main       = no.

      assign
         V_BelegPos.proz_RZ_2:HIDDEN in frame F-Main       = yes
         V_BelegPos.proz_RZ_2:ROW in frame F-Main          = 14
         V_BelegPos.proz_RZ_2:HIDDEN in frame F-Main       = no.

      assign
         V_BelegPos.proz_RZ_3:HIDDEN in frame F-Main       = yes
         V_BelegPos.proz_RZ_3:ROW in frame F-Main          = 15
         V_BelegPos.proz_RZ_3:HIDDEN in frame F-Main       = no.

      assign
         V_BelegPos.proz_RZ_Art_1:HIDDEN in frame F-Main   = yes
         V_BelegPos.proz_RZ_Art_1:ROW in frame F-Main      = 13
         V_BelegPos.proz_RZ_Art_1:HIDDEN in frame F-Main   = no.

      assign
         V_BelegPos.proz_RZ_Art_2:HIDDEN in frame F-Main   = yes
         V_BelegPos.proz_RZ_Art_2:ROW in frame F-Main      = 14
         V_BelegPos.proz_RZ_Art_2:HIDDEN in frame F-Main   = no.

      assign
         V_BelegPos.proz_RZ_Art_3:HIDDEN in frame F-Main   = yes
         V_BelegPos.proz_RZ_Art_3:ROW in frame F-Main      = 15
         V_BelegPos.proz_RZ_Art_3:HIDDEN in frame F-Main   = no.

      assign
         V_BelegPos.Ursprungszeugnis:HIDDEN in frame F-Main = yes
         V_BelegPos.Ursprungszeugnis:ROW in frame F-Main   = 6
         V_BelegPos.Ursprungszeugnis:HIDDEN in frame F-Main = no.

      assign
         V_BelegPos.USTax_Override:HIDDEN in frame F-Main  = yes
         V_BelegPos.USTax_Override:ROW in frame F-Main     = 20
         V_BelegPos.USTax_Override:HIDDEN in frame F-Main  = no.

      assign
         V_BelegPos.USTax_TaxFree:HIDDEN in frame F-Main   = yes
         V_BelegPos.USTax_TaxFree:ROW in frame F-Main      = 19
         V_BelegPos.USTax_TaxFree:HIDDEN in frame F-Main   = no.

      assign
         V_BelegPos_LieferBedingung_Info:HIDDEN in frame F-Main = yes
         V_BelegPos_LieferBedingung_Info:ROW in frame F-Main = 11.5
         V_BelegPos_LieferBedingung_Info:HIDDEN in frame F-Main = no.

      assign
         V_BelegPos_Liefertermin_Info:HIDDEN in frame F-Main = yes
         V_BelegPos_Liefertermin_Info:ROW in frame F-Main  = 16
         V_BelegPos_Liefertermin_Info:HIDDEN in frame F-Main = no.

      assign
         V_BelegPos_Steuer_Bez:HIDDEN in frame F-Main      = yes
         widg-pos = V_BelegPos_Steuer_Bez:ROW in frame F-Main 
         V_BelegPos_Steuer_Bez:ROW in frame F-Main         = 20
         lbl-hndl = V_BelegPos_Steuer_Bez:SIDE-LABEL-HANDLE in frame F-Main 
         lbl-hndl:row = lbl-hndl:row + V_BelegPos_Steuer_Bez:ROW in frame F-Main  - widg-pos
         V_BelegPos_Steuer_Bez:HIDDEN in frame F-Main      = no.

      assign
         V_BelegPos_Versandtermin_Info:HIDDEN in frame F-Main = yes
         V_BelegPos_Versandtermin_Info:ROW in frame F-Main = 17
         V_BelegPos_Versandtermin_Info:HIDDEN in frame F-Main = no.

      assign
         V_BelegPos_Wunschtermin_Info:HIDDEN in frame F-Main = yes
         V_BelegPos_Wunschtermin_Info:ROW in frame F-Main  = 15
         V_BelegPos_Wunschtermin_Info:HIDDEN in frame F-Main = no.

      assign
         V_BelegPos.Versandtermin:HIDDEN in frame F-Main   = yes
         V_BelegPos.Versandtermin:ROW in frame F-Main      = 17
         V_BelegPos.Versandtermin:HIDDEN in frame F-Main   = no.

      assign
         V_BelegPos.Wareneinsatz:HIDDEN in frame F-Main    = yes
         V_BelegPos.Wareneinsatz:ROW in frame F-Main       = 7
         V_BelegPos.Wareneinsatz:HIDDEN in frame F-Main    = no.

      assign
         V_BelegPos.Wert_RZ_1:HIDDEN in frame F-Main       = yes
         V_BelegPos.Wert_RZ_1:ROW in frame F-Main          = 10
         V_BelegPos.Wert_RZ_1:HIDDEN in frame F-Main       = no.

      assign
         V_BelegPos.Wert_RZ_2:HIDDEN in frame F-Main       = yes
         V_BelegPos.Wert_RZ_2:ROW in frame F-Main          = 11
         V_BelegPos.Wert_RZ_2:HIDDEN in frame F-Main       = no.

      assign
         V_BelegPos.Wert_RZ_5:HIDDEN in frame F-Main       = yes
         V_BelegPos.Wert_RZ_5:ROW in frame F-Main          = 9
         V_BelegPos.Wert_RZ_5:HIDDEN in frame F-Main       = no.

      assign
         V_BelegPos.Wert_RZ_Art_1:HIDDEN in frame F-Main   = yes
         V_BelegPos.Wert_RZ_Art_1:ROW in frame F-Main      = 10
         V_BelegPos.Wert_RZ_Art_1:HIDDEN in frame F-Main   = no.

      assign
         V_BelegPos.Wert_RZ_Art_2:HIDDEN in frame F-Main   = yes
         V_BelegPos.Wert_RZ_Art_2:ROW in frame F-Main      = 11
         V_BelegPos.Wert_RZ_Art_2:HIDDEN in frame F-Main   = no.

      assign
         V_BelegPos.Wunschtermin:HIDDEN in frame F-Main    = yes
         widg-pos = V_BelegPos.Wunschtermin:ROW in frame F-Main 
         V_BelegPos.Wunschtermin:ROW in frame F-Main       = 15
         lbl-hndl = V_BelegPos.Wunschtermin:SIDE-LABEL-HANDLE in frame F-Main 
         lbl-hndl:row = lbl-hndl:row + V_BelegPos.Wunschtermin:ROW in frame F-Main  - widg-pos
         V_BelegPos.Wunschtermin:HIDDEN in frame F-Main    = no.

      assign
         V_BelegPos.Zeiteinheit:HIDDEN in frame F-Main     = yes
         V_BelegPos.Zeiteinheit:WIDTH in frame F-Main      = 12
         V_BelegPos.Zeiteinheit:HIDDEN in frame F-Main     = no.

    end.  /* BaseEntry Layout Case */

    when "QuickEntry":U then do:
      assign
         &IF '{&WINDOW-SYSTEM}' NE 'TTY':U &THEN
         frame F-Main:HIDDEN                               = yes &ENDIF
         frame F-Main:HEIGHT                               = 16.29.

      assign
         V_BelegPos.Abladestelle:HIDDEN in frame F-Main    = yes
         V_BelegPos.Abladestelle:WIDTH in frame F-Main     = 19.

      assign
         V_BelegPos.Bezeichnung[3]:HIDDEN in frame F-Main  = yes.

      assign
         S_ArtikelSpr.Bezeichnung[3]:HIDDEN in frame F-Main = yes.

      assign
         V_BelegPos.Bezeichnung[4]:HIDDEN in frame F-Main  = yes.

      assign
         S_ArtikelSpr.Bezeichnung[4]:HIDDEN in frame F-Main = yes.

      assign
         btnTax:HIDDEN in frame F-Main                     = yes
         btnTax:ROW in frame F-Main                        = 12.5
         btnTax:HIDDEN in frame F-Main                     = no.

      assign
         btnVME:HIDDEN in frame F-Main                     = yes
         btnVME:ROW in frame F-Main                        = 3.5
         btnVME:HIDDEN in frame F-Main                     = no.

      assign
         c_Gew-Mengeneinheit:HIDDEN in frame F-Main        = yes
         c_Gew-Mengeneinheit:WIDTH in frame F-Main         = 6.

      assign
         c_LME:HIDDEN in frame F-Main                      = yes
         c_LME:ROW in frame F-Main                         = 3.5
         c_LME:HIDDEN in frame F-Main                      = no.

      assign
         c_Mengeneinheit-1:HIDDEN in frame F-Main          = yes
         c_Mengeneinheit-1:ROW in frame F-Main             = 3.5
         c_Mengeneinheit-1:HIDDEN in frame F-Main          = no.

      assign
         c_Mengeneinheit-2:HIDDEN in frame F-Main          = yes.

      assign
         c_Mengeneinheit-3:HIDDEN in frame F-Main          = yes
         c_Mengeneinheit-3:ROW in frame F-Main             = 4.5
         c_Mengeneinheit-3:HIDDEN in frame F-Main          = no.

      assign
         c_Mengeneinheit-4:HIDDEN in frame F-Main          = yes
         c_Mengeneinheit-4:WIDTH in frame F-Main           = 6.

      assign
         c_Mengeneinheit-5:HIDDEN in frame F-Main          = yes.

      assign
         c_Preisherkunft-1:HIDDEN in frame F-Main          = yes
         c_Preisherkunft-1:ROW in frame F-Main             = 3.5
         c_Preisherkunft-1:HIDDEN in frame F-Main          = no.

      assign
         c_Preisherkunft-2:HIDDEN in frame F-Main          = yes
         c_Preisherkunft-2:ROW in frame F-Main             = 5.5
         c_Preisherkunft-2:HIDDEN in frame F-Main          = no.

      assign
         c_Preisherkunft-3:HIDDEN in frame F-Main          = yes
         c_Preisherkunft-3:ROW in frame F-Main             = 6.5
         c_Preisherkunft-3:HIDDEN in frame F-Main          = no.

      assign
         c_Preisherkunft-4:HIDDEN in frame F-Main          = yes
         c_Preisherkunft-4:ROW in frame F-Main             = 7.5
         c_Preisherkunft-4:HIDDEN in frame F-Main          = no.

      assign
         c_Preisherkunft-5:HIDDEN in frame F-Main          = yes.

      assign
         c_Preisherkunft-6:HIDDEN in frame F-Main          = yes.

      assign
         c_Rabatt-1:HIDDEN in frame F-Main                 = yes
         c_Rabatt-1:ROW in frame F-Main                    = 4.5
         c_Rabatt-1:HIDDEN in frame F-Main                 = no.

      assign
         c_Rabatt-2:HIDDEN in frame F-Main                 = yes
         c_Rabatt-2:ROW in frame F-Main                    = 5.5
         c_Rabatt-2:HIDDEN in frame F-Main                 = no.

      assign
         c_Rabatt-3:HIDDEN in frame F-Main                 = yes
         c_Rabatt-3:ROW in frame F-Main                    = 6.5
         c_Rabatt-3:HIDDEN in frame F-Main                 = no.

      assign
         c_text-1:HIDDEN in frame F-Main                   = yes
         c_text-1:WIDTH in frame F-Main                    = 3.

      assign
         c_text-14:HIDDEN in frame F-Main                  = yes.

      assign
         c_text-VME:HIDDEN in frame F-Main                 = yes
         c_text-VME:WIDTH in frame F-Main                  = 6.

      assign
         c_wBez-1:HIDDEN in frame F-Main                   = yes
         c_wBez-1:ROW in frame F-Main                      = 9.5
         c_wBez-1:HIDDEN in frame F-Main                   = no.

      assign
         d_beauftragt:HIDDEN in frame F-Main               = yes.

      assign
         d_geliefert:HIDDEN in frame F-Main                = yes.

      assign
         d_Gesamtpreis:HIDDEN in frame F-Main              = yes
         widg-pos = d_Gesamtpreis:ROW in frame F-Main 
         d_Gesamtpreis:ROW in frame F-Main                 = 9.5
         lbl-hndl = d_Gesamtpreis:SIDE-LABEL-HANDLE in frame F-Main 
         lbl-hndl:row = lbl-hndl:row + d_Gesamtpreis:ROW in frame F-Main  - widg-pos
         d_Gesamtpreis:HIDDEN in frame F-Main              = no.

      assign
         d_Menge:HIDDEN in frame F-Main                    = yes
         widg-pos = d_Menge:ROW in frame F-Main 
         d_Menge:ROW in frame F-Main                       = 3.5
         lbl-hndl = d_Menge:SIDE-LABEL-HANDLE in frame F-Main 
         lbl-hndl:row = lbl-hndl:row + d_Menge:ROW in frame F-Main  - widg-pos
         d_Menge:HIDDEN in frame F-Main                    = no.

      assign
         d_Mindestmenge:HIDDEN in frame F-Main             = yes
         d_Mindestmenge:WIDTH in frame F-Main              = 19.

      assign
         d_reserviert:HIDDEN in frame F-Main               = yes
         widg-pos = d_reserviert:ROW in frame F-Main 
         d_reserviert:ROW in frame F-Main                  = 4.5
         lbl-hndl = d_reserviert:SIDE-LABEL-HANDLE in frame F-Main 
         lbl-hndl:row = lbl-hndl:row + d_reserviert:ROW in frame F-Main  - widg-pos
         d_reserviert:HIDDEN in frame F-Main               = no.

      assign
         d_Storno:HIDDEN in frame F-Main                   = yes
         d_Storno:WIDTH in frame F-Main                    = 19.

      assign
         d_Verkaufspreis:HIDDEN in frame F-Main            = yes
         d_Verkaufspreis:WIDTH in frame F-Main             = 23.

      assign
         V_BelegPos.Einzelpreis:HIDDEN in frame F-Main     = yes
         widg-pos = V_BelegPos.Einzelpreis:ROW in frame F-Main 
         V_BelegPos.Einzelpreis:ROW in frame F-Main        = 3.5
         lbl-hndl = V_BelegPos.Einzelpreis:SIDE-LABEL-HANDLE in frame F-Main 
         lbl-hndl:row = lbl-hndl:row + V_BelegPos.Einzelpreis:ROW in frame F-Main  - widg-pos
         V_BelegPos.Einzelpreis:HIDDEN in frame F-Main     = no.

      assign
         gc_Preisbezug-Rabattart-1:HIDDEN in frame F-Main  = yes.

      assign
         gc_Preisbezug-Rabattart-2:HIDDEN in frame F-Main  = yes.

      assign
         gcCROInfo:HIDDEN in frame F-Main                  = yes
         gcCROInfo:ROW in frame F-Main                     = 6.5
         gcCROInfo:HIDDEN in frame F-Main                  = no.

      assign
         gcEAN:HIDDEN in frame F-Main                      = yes
         widg-pos = gcEAN:ROW in frame F-Main 
         gcEAN:ROW in frame F-Main                         = 16.29
         lbl-hndl = gcEAN:SIDE-LABEL-HANDLE in frame F-Main 
         lbl-hndl:row = lbl-hndl:row + gcEAN:ROW in frame F-Main  - widg-pos.

      assign
         gcFEcoTaxOrigin:HIDDEN in frame F-Main            = yes
         gcFEcoTaxOrigin:ROW in frame F-Main               = 4.5
         gcFEcoTaxOrigin:HIDDEN in frame F-Main            = no.

      assign
         gcPriceUnitDesc:HIDDEN in frame F-Main            = yes
         gcPriceUnitDesc:ROW in frame F-Main               = 3.5
         gcPriceUnitDesc:HIDDEN in frame F-Main            = no.

      assign
         gcTimeUnitCombo:HIDDEN in frame F-Main            = yes
         gcTimeUnitCombo:ROW in frame F-Main               = 10
         gcTimeUnitCombo:HIDDEN in frame F-Main            = no.

      assign
         gcuAbfahrtszeit:HIDDEN in frame F-Main            = yes
         gcuAbfahrtszeit:ROW in frame F-Main               = 14
         gcuAbfahrtszeit:HIDDEN in frame F-Main            = no.

      assign
         gcZollNummer:HIDDEN in frame F-Main               = yes
         gcZollNummer:WIDTH in frame F-Main                = 12.

      assign
         gdAkzeptierte_Menge:HIDDEN in frame F-Main        = yes
         gdAkzeptierte_Menge:WIDTH in frame F-Main         = 19.

      assign
         gdSteuersatz:HIDDEN in frame F-Main               = yes
         gdSteuersatz:ROW in frame F-Main                  = 10.5
         gdSteuersatz:HIDDEN in frame F-Main               = no.

      assign
         gdTaxSum:HIDDEN in frame F-Main                   = yes
         widg-pos = gdTaxSum:ROW in frame F-Main 
         gdTaxSum:ROW in frame F-Main                      = 12.5
         lbl-hndl = gdTaxSum:SIDE-LABEL-HANDLE in frame F-Main 
         lbl-hndl:row = lbl-hndl:row + gdTaxSum:ROW in frame F-Main  - widg-pos
         gdTaxSum:HIDDEN in frame F-Main                   = no.

      assign
         V_BelegPos.Gewicht:HIDDEN in frame F-Main         = yes
         V_BelegPos.Gewicht:WIDTH in frame F-Main          = 19.

      assign
         V_BelegPos.GewichtVerp:HIDDEN in frame F-Main     = yes.

      assign
         giKO_LagerOrt:HIDDEN in frame F-Main              = yes
         giKO_LagerOrt:ROW in frame F-Main                 = 5.5
         giKO_LagerOrt:HIDDEN in frame F-Main              = no.

      assign
         gtuAbfahrtsdatum:HIDDEN in frame F-Main           = yes
         gtuAbfahrtsdatum:ROW in frame F-Main              = 14
         gtuAbfahrtsdatum:HIDDEN in frame F-Main           = no.

      assign
         gtuAbfahrtsdatum_Info:HIDDEN in frame F-Main      = yes
         gtuAbfahrtsdatum_Info:ROW in frame F-Main         = 14
         gtuAbfahrtsdatum_Info:HIDDEN in frame F-Main      = no.

      assign
         V_BelegPos.IncoTerm:HIDDEN in frame F-Main        = yes.

      assign
         V_BelegPos.LagerOrt:HIDDEN in frame F-Main        = yes
         widg-pos = V_BelegPos.LagerOrt:ROW in frame F-Main 
         V_BelegPos.LagerOrt:ROW in frame F-Main           = 5.5
         lbl-hndl = V_BelegPos.LagerOrt:SIDE-LABEL-HANDLE in frame F-Main 
         lbl-hndl:row = lbl-hndl:row + V_BelegPos.LagerOrt:ROW in frame F-Main  - widg-pos
         V_BelegPos.LagerOrt:HIDDEN in frame F-Main        = no.

      assign
         V_BelegPos.LieferBedingung:HIDDEN in frame F-Main = yes
         V_BelegPos.LieferBedingung:WIDTH in frame F-Main  = 6.

      assign
         V_BelegPos.Liefertermin:HIDDEN in frame F-Main    = yes
         widg-pos = V_BelegPos.Liefertermin:ROW in frame F-Main 
         V_BelegPos.Liefertermin:ROW in frame F-Main       = 9
         lbl-hndl = V_BelegPos.Liefertermin:SIDE-LABEL-HANDLE in frame F-Main 
         lbl-hndl:row = lbl-hndl:row + V_BelegPos.Liefertermin:ROW in frame F-Main  - widg-pos
         V_BelegPos.Liefertermin:HIDDEN in frame F-Main    = no.

      assign
         V_BelegPos.Lieferzeit:HIDDEN in frame F-Main      = yes
         V_BelegPos.Lieferzeit:WIDTH in frame F-Main       = 6.

      assign
         V_BelegPos.Lieferzeit_Einheit:HIDDEN in frame F-Main = yes
         V_BelegPos.Lieferzeit_Einheit:WIDTH in frame F-Main = 13.67.

      assign
         V_BelegPos.Metalsurcharge:HIDDEN in frame F-Main  = yes
         widg-pos = V_BelegPos.Metalsurcharge:ROW in frame F-Main 
         V_BelegPos.Metalsurcharge:ROW in frame F-Main     = 8.5
         lbl-hndl = V_BelegPos.Metalsurcharge:SIDE-LABEL-HANDLE in frame F-Main 
         lbl-hndl:row = lbl-hndl:row + V_BelegPos.Metalsurcharge:ROW in frame F-Main  - widg-pos
         V_BelegPos.Metalsurcharge:HIDDEN in frame F-Main  = no.

      assign
         V_BelegPos.MMM_CusRefOrder_ID:HIDDEN in frame F-Main = yes
         widg-pos = V_BelegPos.MMM_CusRefOrder_ID:ROW in frame F-Main 
         V_BelegPos.MMM_CusRefOrder_ID:ROW in frame F-Main = 6.5
         lbl-hndl = V_BelegPos.MMM_CusRefOrder_ID:SIDE-LABEL-HANDLE in frame F-Main 
         lbl-hndl:row = lbl-hndl:row + V_BelegPos.MMM_CusRefOrder_ID:ROW in frame F-Main  - widg-pos
         V_BelegPos.MMM_CusRefOrder_ID:HIDDEN in frame F-Main = no.

      assign
         V_BelegPos.proz_RZ_1:HIDDEN in frame F-Main       = yes
         V_BelegPos.proz_RZ_1:ROW in frame F-Main          = 5.5
         V_BelegPos.proz_RZ_1:HIDDEN in frame F-Main       = no.

      assign
         V_BelegPos.proz_RZ_2:HIDDEN in frame F-Main       = yes
         V_BelegPos.proz_RZ_2:ROW in frame F-Main          = 6.5
         V_BelegPos.proz_RZ_2:HIDDEN in frame F-Main       = no.

      assign
         V_BelegPos.proz_RZ_3:HIDDEN in frame F-Main       = yes
         V_BelegPos.proz_RZ_3:ROW in frame F-Main          = 7.5
         V_BelegPos.proz_RZ_3:HIDDEN in frame F-Main       = no.

      assign
         V_BelegPos.proz_RZ_Art_1:HIDDEN in frame F-Main   = yes
         V_BelegPos.proz_RZ_Art_1:ROW in frame F-Main      = 5.5
         V_BelegPos.proz_RZ_Art_1:HIDDEN in frame F-Main   = no.

      assign
         V_BelegPos.proz_RZ_Art_2:HIDDEN in frame F-Main   = yes
         V_BelegPos.proz_RZ_Art_2:ROW in frame F-Main      = 6.5
         V_BelegPos.proz_RZ_Art_2:HIDDEN in frame F-Main   = no.

      assign
         V_BelegPos.proz_RZ_Art_3:HIDDEN in frame F-Main   = yes
         V_BelegPos.proz_RZ_Art_3:ROW in frame F-Main      = 7.5
         V_BelegPos.proz_RZ_Art_3:HIDDEN in frame F-Main   = no.

      assign
         V_BelegPos.Transportzeit:HIDDEN in frame F-Main   = yes
         widg-pos = V_BelegPos.Transportzeit:ROW in frame F-Main 
         V_BelegPos.Transportzeit:ROW in frame F-Main      = 10
         lbl-hndl = V_BelegPos.Transportzeit:SIDE-LABEL-HANDLE in frame F-Main 
         lbl-hndl:row = lbl-hndl:row + V_BelegPos.Transportzeit:ROW in frame F-Main  - widg-pos
         V_BelegPos.Transportzeit:HIDDEN in frame F-Main   = no.

      assign
         V_BelegPos.uCE_ReferenceDocItemPos:HIDDEN in frame F-Main = yes
         widg-pos = V_BelegPos.uCE_ReferenceDocItemPos:ROW in frame F-Main 
         V_BelegPos.uCE_ReferenceDocItemPos:ROW in frame F-Main = 13.5
         lbl-hndl = V_BelegPos.uCE_ReferenceDocItemPos:SIDE-LABEL-HANDLE in frame F-Main 
         lbl-hndl:row = lbl-hndl:row + V_BelegPos.uCE_ReferenceDocItemPos:ROW in frame F-Main  - widg-pos
         V_BelegPos.uCE_ReferenceDocItemPos:HIDDEN in frame F-Main = no.

      assign
         V_BelegPos.uCI_KommZeit:HIDDEN in frame F-Main    = yes
         widg-pos = V_BelegPos.uCI_KommZeit:ROW in frame F-Main 
         V_BelegPos.uCI_KommZeit:ROW in frame F-Main       = 11
         lbl-hndl = V_BelegPos.uCI_KommZeit:SIDE-LABEL-HANDLE in frame F-Main 
         lbl-hndl:row = lbl-hndl:row + V_BelegPos.uCI_KommZeit:ROW in frame F-Main  - widg-pos
         V_BelegPos.uCI_KommZeit:HIDDEN in frame F-Main    = no.

      assign
         V_BelegPos.uCI_KommZeiteinheit:HIDDEN in frame F-Main = yes
         V_BelegPos.uCI_KommZeiteinheit:ROW in frame F-Main = 11
         V_BelegPos.uCI_KommZeiteinheit:HIDDEN in frame F-Main = no.

      assign
         V_BelegPos.uCI_Lot:HIDDEN in frame F-Main         = yes
         widg-pos = V_BelegPos.uCI_Lot:ROW in frame F-Main 
         V_BelegPos.uCI_Lot:ROW in frame F-Main            = 15
         lbl-hndl = V_BelegPos.uCI_Lot:SIDE-LABEL-HANDLE in frame F-Main 
         lbl-hndl:row = lbl-hndl:row + V_BelegPos.uCI_Lot:ROW in frame F-Main  - widg-pos
         V_BelegPos.uCI_Lot:HIDDEN in frame F-Main         = no.

      assign
         V_BelegPos.uCI_Versandart:HIDDEN in frame F-Main  = yes
         widg-pos = V_BelegPos.uCI_Versandart:ROW in frame F-Main 
         V_BelegPos.uCI_Versandart:ROW in frame F-Main     = 12
         lbl-hndl = V_BelegPos.uCI_Versandart:SIDE-LABEL-HANDLE in frame F-Main 
         lbl-hndl:row = lbl-hndl:row + V_BelegPos.uCI_Versandart:ROW in frame F-Main  - widg-pos
         V_BelegPos.uCI_Versandart:HIDDEN in frame F-Main  = no.

      assign
         V_BelegPos.uCI_Warenausgangstermin:HIDDEN in frame F-Main = yes
         V_BelegPos.uCI_Warenausgangstermin:ROW in frame F-Main = 10
         V_BelegPos.uCI_Warenausgangstermin:HIDDEN in frame F-Main = no.

      assign
         V_BelegPos.uCW_Tour:HIDDEN in frame F-Main        = yes
         widg-pos = V_BelegPos.uCW_Tour:ROW in frame F-Main 
         V_BelegPos.uCW_Tour:ROW in frame F-Main           = 13
         lbl-hndl = V_BelegPos.uCW_Tour:SIDE-LABEL-HANDLE in frame F-Main 
         lbl-hndl:row = lbl-hndl:row + V_BelegPos.uCW_Tour:ROW in frame F-Main  - widg-pos
         V_BelegPos.uCW_Tour:HIDDEN in frame F-Main        = no.

      assign
         V_BelegPos.uCW_TransportNr:HIDDEN in frame F-Main = yes
         widg-pos = V_BelegPos.uCW_TransportNr:ROW in frame F-Main 
         V_BelegPos.uCW_TransportNr:ROW in frame F-Main    = 14
         lbl-hndl = V_BelegPos.uCW_TransportNr:SIDE-LABEL-HANDLE in frame F-Main 
         lbl-hndl:row = lbl-hndl:row + V_BelegPos.uCW_TransportNr:ROW in frame F-Main  - widg-pos
         V_BelegPos.uCW_TransportNr:HIDDEN in frame F-Main = no.

      assign
         V_BelegPos.Ursprungszeugnis:HIDDEN in frame F-Main = yes.

      assign
         V_BelegPos.USTax_Override:HIDDEN in frame F-Main  = yes
         V_BelegPos.USTax_Override:ROW in frame F-Main     = 11.5
         V_BelegPos.USTax_Override:HIDDEN in frame F-Main  = no.

      assign
         V_BelegPos.USTax_TaxFree:HIDDEN in frame F-Main   = yes
         V_BelegPos.USTax_TaxFree:ROW in frame F-Main      = 10.5
         V_BelegPos.USTax_TaxFree:HIDDEN in frame F-Main   = no.

      assign
         V_BelegPos_LieferBedingung_Info:HIDDEN in frame F-Main = yes.

      assign
         V_BelegPos_Liefertermin_Info:HIDDEN in frame F-Main = yes
         V_BelegPos_Liefertermin_Info:ROW in frame F-Main  = 9
         V_BelegPos_Liefertermin_Info:HIDDEN in frame F-Main = no.

      assign
         V_BelegPos_Steuer_Bez:HIDDEN in frame F-Main      = yes
         widg-pos = V_BelegPos_Steuer_Bez:ROW in frame F-Main 
         V_BelegPos_Steuer_Bez:ROW in frame F-Main         = 10.5
         lbl-hndl = V_BelegPos_Steuer_Bez:SIDE-LABEL-HANDLE in frame F-Main 
         lbl-hndl:row = lbl-hndl:row + V_BelegPos_Steuer_Bez:ROW in frame F-Main  - widg-pos
         V_BelegPos_Steuer_Bez:HIDDEN in frame F-Main      = no.

      assign
         V_BelegPos_uCI_Versandart_Info:HIDDEN in frame F-Main = yes
         V_BelegPos_uCI_Versandart_Info:ROW in frame F-Main = 12
         V_BelegPos_uCI_Versandart_Info:HIDDEN in frame F-Main = no.

      assign
         V_BelegPos_Versandtermin_Info:HIDDEN in frame F-Main = yes
         V_BelegPos_Versandtermin_Info:ROW in frame F-Main = 10
         V_BelegPos_Versandtermin_Info:HIDDEN in frame F-Main = no.

      assign
         V_BelegPos_Wunschtermin_Info:HIDDEN in frame F-Main = yes
         V_BelegPos_Wunschtermin_Info:ROW in frame F-Main  = 8
         V_BelegPos_Wunschtermin_Info:HIDDEN in frame F-Main = no.

      assign
         V_BeleI_Warenausgangstermin_Info:HIDDEN in frame F-Main = yes
         V_BeleI_Warenausgangstermin_Info:ROW in frame F-Main = 10
         V_BeleI_Warenausgangstermin_Info:HIDDEN in frame F-Main = no.

      assign
         V_BelegPos.Versandtermin:HIDDEN in frame F-Main   = yes
         V_BelegPos.Versandtermin:ROW in frame F-Main      = 10
         V_BelegPos.Versandtermin:HIDDEN in frame F-Main   = no.

      assign
         V_BelegPos.Wareneinsatz:HIDDEN in frame F-Main    = yes.

      assign
         V_BelegPos.Wert_RZ_1:HIDDEN in frame F-Main       = yes
         V_BelegPos.Wert_RZ_1:WIDTH in frame F-Main        = 24.

      assign
         V_BelegPos.Wert_RZ_2:HIDDEN in frame F-Main       = yes
         V_BelegPos.Wert_RZ_2:WIDTH in frame F-Main        = 23.

      assign
         V_BelegPos.Wert_RZ_Art_1:HIDDEN in frame F-Main   = yes.

      assign
         V_BelegPos.Wert_RZ_Art_2:HIDDEN in frame F-Main   = yes.

      assign
         V_BelegPos.Wunschtermin:HIDDEN in frame F-Main    = yes
         widg-pos = V_BelegPos.Wunschtermin:ROW in frame F-Main 
         V_BelegPos.Wunschtermin:ROW in frame F-Main       = 8
         lbl-hndl = V_BelegPos.Wunschtermin:SIDE-LABEL-HANDLE in frame F-Main 
         lbl-hndl:row = lbl-hndl:row + V_BelegPos.Wunschtermin:ROW in frame F-Main  - widg-pos
         V_BelegPos.Wunschtermin:HIDDEN in frame F-Main    = no.

      assign
         V_BelegPos.Zeiteinheit:HIDDEN in frame F-Main     = yes
         V_BelegPos.Zeiteinheit:ROW in frame F-Main        = 10
         V_BelegPos.Zeiteinheit:WIDTH in frame F-Main      = 12
         V_BelegPos.Zeiteinheit:HIDDEN in frame F-Main     = no.

      assign

         frame F-Main:VIRTUAL-HEIGHT                       = 16.29
                    when frame F-Main:SCROLLABLE
         &IF '{&WINDOW-SYSTEM}' NE 'TTY':U &THEN
         frame F-Main:HIDDEN                               = no &ENDIF.

    end.  /* QuickEntry Layout Case */

  end case.
end procedure.  /* CURRENT-WINDOW-layouts */
&ANALYZE-RESUME

/* ************************  Function Implementations ***************** */

&IF DEFINED(EXCLUDE-cUCIKommZeiteinheit) = 0 &THEN

&ANALYZE-SUSPEND _UIB-CODE-BLOCK _FUNCTION cUCIKommZeiteinheit Method-Library
function cUCIKommZeiteinheit returns character 
  (  ):
/* Description ---------------------------------------------------------------*/
/*                                                                            */
/* While the passed parameter to VBCSalesDocSvc:CreateWorkOrderToOrderLine    */
/* in the included file, v_wbel02.lib is read from different resources        */
/* depnding on the need (in some cases from the DB and in some cases from the */
/* screen value), this method was added to pass the correct value.            */
/*                                                                            */
/* Parameters ----------------------------------------------------------------*/
/*                                                                            */
/* <none>                                                                     */
/*                                                                            */
/*----------------------------------------------------------------------------*/

return input frame {&frame-name} V_BelegPos.uCI_KommZeiteinheit.

end function. /* cUCIKommZeiteinheit */

/* _UIB-CODE-BLOCK-END */
&ANALYZE-RESUME

&ENDIF


&IF DEFINED(EXCLUDE-iUCIKommZeit) = 0 &THEN

&ANALYZE-SUSPEND _UIB-CODE-BLOCK _FUNCTION iUCIKommZeit Method-Library
function iUCIKommZeit returns integer 
  (  ):
/* Description ---------------------------------------------------------------*/
/*                                                                            */
/* While the passed parameter to VBCSalesDocSvc:CreateWorkOrderToOrderLine    */
/* in the included file, v_wbel02.lib is read from different resources        */
/* depnding on the need (in some cases from the DB and in some cases from the */
/* screen value), this method was added to pass the correct value.            */
/*                                                                            */
/* Parameters ----------------------------------------------------------------*/
/*                                                                            */
/* <none>                                                                     */
/*                                                                            */
/*----------------------------------------------------------------------------*/

return input frame {&frame-name} V_BelegPos.uCI_KommZeit.

end function. /* iUCIKommZeit */

/* _UIB-CODE-BLOCK-END */
&ANALYZE-RESUME

&ENDIF


&ANALYZE-SUSPEND _UIB-CODE-BLOCK _FUNCTION pa_lUISvcACMReplacementUpdate V-table-Win 
function pa_lUISvcACMReplacementUpdate returns logical
  ( phFrame as handle ):
/* Description ---------------------------------------------------------------*/
/*                                                                            */
/* Super Override                                                             */
/*                                                                            */
/* Notes ---------------------------------------------------------------------*/
/*                                                                            */
/*                                                                            */
/*                                                                            */
/* Parameters ----------------------------------------------------------------*/
/*                                                                            */
/* <none>                                                                     */
/*                                                                            */
/* Examples ------------------------------------------------------------------*/
/*                                                                            */
/*                                                                            */
/*                                                                            */
/*----------------------------------------------------------------------------*/

/* Variables -----------------------------------------------------------------*/
/* lReturnValue  function return value                                        */
/*----------------------------------------------------------------------------*/

define variable lReturnValue as logical no-undo.

/* Buffers -------------------------------------------------------------------*/

/*----------------------------------------------------------------------------*/
/* Processing                                                                 */
/*----------------------------------------------------------------------------*/

/* Eingriff vor der Zuweisung des Screen-values */

lReturnValue = super (phFrame).

/* Eingriff nach der Zuweisung des Screen-values */

&IF LOOKUP("U_CI":U,"{&PA-OPTIONEN}":U) > 0 &THEN
apply 'leave':U to V_BelegPos.uCI_KommZeit in frame {&frame-name}.
&ENDIF

return lReturnValue.

end function. /* pa_lUISvcACMReplacementUpdate */

/* _UIB-CODE-BLOCK-END */
&ANALYZE-RESUME

&ANALYZE-SUSPEND _UIB-CODE-BLOCK _FUNCTION pa_lUISvcObjectState V-table-Win 
function pa_lUISvcObjectState returns logical
  ( pcStateCode as character ) :
/* Description ---------------------------------------------------------------*/
/*                                                                            */
/* Extend implementation in dmcuis00.p                                        */
/*                                                                            */
/* Notes ---------------------------------------------------------------------*/
/*                                                                            */
/*                                                                            */
/*                                                                            */
/* Parameters ----------------------------------------------------------------*/
/*                                                                            */
/* pcStateCode State-Code to check                                            */
/*                                                                            */
/*----------------------------------------------------------------------------*/

/* Variables -----------------------------------------------------------------*/
/*----------------------------------------------------------------------------*/

/* Buffers -------------------------------------------------------------------*/

/*----------------------------------------------------------------------------*/
/* Processing                                                                 */
/*----------------------------------------------------------------------------*/

case pcStateCode:

  when 'paSCIsCTPAllowed':U then

    &IF LOOKUP("PP","{&PA-MODULE}") > 0 &THEN
      do:
        
        if not pa-fields-enabled then
          return no.
        
        run get-attribute('CreateProdOrder':U).
        
        return return-value = 'yes':U.

      end. /* when 'paSCIsCTPAllowed':U */
    &ELSE
      return no.
    &ENDIF


  when 'paSCisDeliveryDateSensitive':U then

  &IF LOOKUP("JB","{&PA-MODULE}") > 0 &THEN

    return proj.base.cls.JBCProjectSvc:prpoInstance:lSchedProjectHasAuthority
             (V_BelegPos.Belegart,
              V_BelegPos.V_BelegPos_Obj).

  &ELSE

    return no.

  &ENDIF

  when 'paSCisCRONumberSensitive':U then
  do:

    if V_BelegPos.Satzart <> 'A':U then

      return no.

   if can-do({&pa_S_PTList_Set}, string(S_Artikel.ArtikelArt)) 
     and vert.base.cls.VBCSalesDocSvc:prpoInstance:lCanChangeCROSet
        (buffer V_BelegPos,
         buffer S_Artikel) = no then

    return no.

    /* enabling/disabling of the field CRONumber (KommissionsNr)   */
    /* field is only disabled if                                   */
    /* - updating a line with a set                                */
    /* - the line has been picked                                  */
    /* - the part has CRO warehouse without (KommLager ohne)       */
    /* - a work or purchase order has been generated for this line */

    &IF "{&pa_M_KommissionsNrEingabe}":U = "1":U &THEN

      return vert.base.cls.VBCSalesDocSvc:prpoInstance:lCanChangeCRO
        (buffer V_BelegPos,
         buffer S_Artikel,
         input frame {&frame-name} V_BelegPos.Lagerort,
         input frame {&frame-name} V_BelegPos.MMM_CusRefOrder_ID).

    &ELSE

      /* field is always enabled */

      return yes.

    &ENDIF

   end.


  {&{&PA-XBasisName}_C_UISvcObjectState}
  {&{&PA-XBasisName}_U_UISvcObjectState}
  {&{&PA-XBasisName}_Q_UISvcObjectState}
  {&{&PA-XBasisName}_UISvcObjectState}
  {&{&PA-XBasisName}_Y_UISvcObjectState}

  otherwise

    return super(pcStateCode).

end case.

end function. /* pa_lUISvcObjectState */

/* _UIB-CODE-BLOCK-END */
&ANALYZE-RESUME

&ANALYZE-SUSPEND _UIB-CODE-BLOCK _FUNCTION uUpdateDateFields V-table-Win 
function uUpdateDateFields returns logical
  ( phField as handle ):
/* Description ---------------------------------------------------------------*/
/*                                                                            */
/* Check Datefield against Delivery Timeframe and Tourplanning                */
/*                                                                            */
/* Notes ---------------------------------------------------------------------*/
/*                                                                            */
/*                                                                            */
/*                                                                            */
/* Parameters ----------------------------------------------------------------*/
/*                                                                            */
/* phField : Date Field to Check                                              */
/*                                                                            */
/* Examples ------------------------------------------------------------------*/
/*                                                                            */
/*                                                                            */
/*                                                                            */
/*----------------------------------------------------------------------------*/

/* Variables -----------------------------------------------------------------*/
/* lReturnValue  function return value                                        */
/*----------------------------------------------------------------------------*/

define variable lReturnValue as logical no-undo.

define variable lDateFieldChanged as logical    no-undo.
define variable tCheckDate        as date       no-undo.
define variable tFieldDate        as date       no-undo.
define variable cMessageNumber    as character  no-undo.
define variable hTimefield        as handle     no-undo.

define variable lTransportFound   as logical       no-undo. /* this is base! */

&IF LOOKUP("U_CW":U,"{&PA-OPTIONEN}":U) > 0 &THEN
define variable tTransportDate    as date          no-undo.
define variable tDeliveryDate     as date          no-undo.
define variable iCW_TransportNr   as integer       no-undo.
define variable uCW_Tour          as character     no-undo.
&ENDIF

/* Buffers -------------------------------------------------------------------*/

/*----------------------------------------------------------------------------*/
/* Processing                                                                 */
/*----------------------------------------------------------------------------*/

&IF LOOKUP("U_CI":U,"{&PA-OPTIONEN}":U) > 0 &THEN

  if lookup(phField:name,'Transportzeit,Zeiteinheit,uci_Kommzeit,uCI_Kommzeiteinheit':U) > 0 then
  do:
    assign
      hTimefield              = phField
      lDateFieldChanged       = {getwidgetattr hTimefield screen-value string} <> hTimefield:private-data
      hTimefield:private-data = {getwidgetattr hTimefield screen-value string}
      phField                 = V_BelegPos.Wunschtermin:handle in frame {&FRAME-NAME}.
      tFieldDate              = date({getwidgetattr phField screen-value string})
      .
  end.
  else if lookup(phField:name,'uCI_Versandart':U) > 0 then
  do:

    if input frame {&FRAME-NAME} V_BelegPos.Liefertermin <> ? then
      assign
        tFieldDate = input frame {&FRAME-NAME} V_BelegPos.Liefertermin
        phField    = V_BelegPos.Liefertermin:handle in frame {&FRAME-NAME}
        .
    else
      assign
        tFieldDate = input frame {&FRAME-NAME} V_BelegPos.Wunschtermin
        phField    = V_BelegPos.Wunschtermin:handle in frame {&FRAME-NAME}
        .

    lDateFieldChanged = yes.

  end.
  else
    assign
      tFieldDate           = date({getwidgetattr phField screen-value string})
      lDateFieldChanged    = string(tFieldDate,'{&PA_DATEFORMAT}':U) <> phField:private-data
      tFieldDate           = (if tFieldDate = ? then
                                input frame {&FRAME-NAME} V_BelegPos.Wunschtermin
                              else
                                tFieldDate)
      .

  if phField:name = 'Wunschtermin':U then
    cMessageNumber = 'uvanl00001':U.
  else
    cMessageNumber = 'uvanl00002':U.

  /* Kontrolle ob Liefertermin zu Anlieferungszeitfenster passt. */

  /* not for Value Line */
  if tFieldDate <> ?
    and V_BelegPos.Satzart = 'A':U
    and not V_BelegPos.WertPosition then
  do:

    if lDateFieldChanged
      &IF LOOKUP("U_CW":U,"{&PA-OPTIONEN}":U) > 0 &THEN
      or gluSAChanged
      &ENDIF
      then
    do:

      &IF LOOKUP("U_CW":U,"{&PA-OPTIONEN}":U) > 0 &THEN
      if available gbuS_VersandArt
        and gbuS_VersandArt.uCW_TourenPlanung then
      do:

        branche.vert.cls.UVC_TourSvc:prpoInstance:GetEarliestTransportInDTF(              V_BelegKopf.V_BelegKopf_Obj,
                                                                                          gcuDestinationStaat,
                                                                                          gcuDestinationPLZ,
                                                                                          gbuS_VersandArt.Versandart,
                                                                                          V_BelegKopf.Lagergruppe,
                                                                                          giKO_LagerOrt,
                                                                                          branche.vert.cls.UVC_TourSvc:prpoInstance:iGetStoragearea
                                                                                            (V_BelegPos.Artikel,
                                                                                             V_BelegKopf.Lagergruppe,
                                                                                             input frame {&frame-name} V_BelegPos.LagerOrt),
                                                                                          input frame {&frame-name} V_BelegPos.Transportzeit,
                                                                                          input frame {&frame-name} V_BelegPos.Zeiteinheit,
                                                                                          input frame {&frame-name} V_BelegPos.uCI_Kommzeit,
                                                                                          input frame {&frame-name} V_BelegPos.uCI_Kommzeiteinheit,
                                                                                          tFieldDate,
                                                                            input-output  tDeliveryDate,
                                                                                  output  uCW_Tour,
                                                                                  output  iCW_TransportNr,
                                                                                  output  tTransportDate,
                                                                            {fnarg pa_hADMTopContainer this-procedure}).

        if iCW_TransportNr = 0 then
        do:
          adm.method.cls.DMCMessageSvc:prpoInstance:lshowMessage('uvtra00006':U,         /* no Transport availabel */
                                                                  string(tFieldDate,'{&PA_DATEFORMAT}':U)).
          assign
            {setwidgetattr
               "V_BelegPos.uCW_Tour"
               "screen-value"
               "uCW_Tour"
               "in frame {&FRAME-NAME}"}
            {setwidgetattr
               "V_BelegPos.uCW_TransportNr"
               "screen-value"
               "string(iCW_TransportNr)"
               "in frame {&FRAME-NAME}"}
            {setwidgetattr
               "V_BelegPos.Liefertermin"
               "screen-value"
               "string(?)"
               "in frame {&FRAME-NAME}"}
            {setwidgetattr
               "V_BelegPos.Liefertermin"
               "private-data"
               "string(date(V_BelegPos.Liefertermin:screen-value in frame {&FRAME-NAME}),'{&PA_DATEFORMAT}':U)"
               "in frame {&FRAME-NAME}"}
            {setwidgetattr
               "gtuAbfahrtsdatum"
               "screen-value"
               "string(?)"
               "in frame {&frame-name}"}
            {setwidgetattr
               "gcuAbfahrtszeit"
               "screen-value"
               "'':U"
               "in frame {&frame-name}"}
            .

        end.
        else if V_BelegPos.uCW_TransportNr:screen-value in frame {&FRAME-NAME} = string(iCW_TransportNr) then
          /* if we already got the transport, we dont have to ask, just update the fields */
          assign
            {setwidgetattr
               "V_BelegPos.uCW_Tour"
               "screen-value"
               "uCW_Tour"
               "in frame {&FRAME-NAME}"}
            {setwidgetattr
               "V_BelegPos.uCW_TransportNr"
               "screen-value"
               "string(iCW_TransportNr)"
               "in frame {&FRAME-NAME}"}
            {setwidgetattr
               "V_BelegPos.Liefertermin"
               "screen-value"
               "string(tDeliveryDate,'{&PA_DATEFORMAT}':U)"
               "in frame {&FRAME-NAME}"}
            {setwidgetattr
               "V_BelegPos.Liefertermin"
               "private-data"
               "string(date(V_BelegPos.Liefertermin:screen-value in frame {&FRAME-NAME}),'{&PA_DATEFORMAT}':U)"
               "in frame {&FRAME-NAME}"}
            lTransportFound                                                = yes
            {setwidgetattr
               "gtuAbfahrtsdatum"
               "screen-value"
               "string(tTransportDate,'{&PA_DATEFORMAT}':U)"
               "in frame {&frame-name}"}
            {setwidgetattr
               "gcuAbfahrtszeit"
               "screen-value"
               "'':U"
               "in frame {&frame-name}"}
            .
        else if adm.method.cls.DMCMessageSvc:prpoInstance:lshowMessage
                  ('uvtra00005':U,
                   phField:screen-value,
                   string(iCW_TransportNr),
                   uCW_Tour,
                   string(tTransportDate,'{&PA_DATEFORMAT}':U)) then
          assign
            {setwidgetattr
               "V_BelegPos.uCW_Tour"
               "screen-value"
               "uCW_Tour"
               "in frame {&FRAME-NAME}"}
            {setwidgetattr
               "V_BelegPos.uCW_TransportNr"
               "screen-value"
               "string(iCW_TransportNr)"
               "in frame {&FRAME-NAME}"}
            {setwidgetattr
               "V_BelegPos.Liefertermin"
               "screen-value"
               "string(tDeliveryDate,'{&PA_DATEFORMAT}':U)"
               "in frame {&FRAME-NAME}"}
            {setwidgetattr
               "V_BelegPos.Liefertermin"
               "private-data"
               "string(date(V_BelegPos.Liefertermin:screen-value in frame {&FRAME-NAME}),'{&PA_DATEFORMAT}':U)"
               "in frame {&FRAME-NAME}"}
            lTransportFound                                                = yes
            {setwidgetattr
               "gtuAbfahrtsdatum"
               "screen-value"
               "string(tTransportDate,'{&PA_DATEFORMAT}':U)"
               "in frame {&frame-name}"}
            {setwidgetattr
               "gcuAbfahrtszeit"
               "screen-value"
               "'':U"
               "in frame {&frame-name}"}
            .
        else
          assign
            {setwidgetattr
               "V_BelegPos.uCW_Tour"
               "screen-value"
               "'':U"
               "in frame {&FRAME-NAME}"}
            {setwidgetattr
               "V_BelegPos.uCW_TransportNr"
               "screen-value"
               "'':U"
               "in frame {&FRAME-NAME}"}
            {setwidgetattr
               "gtuAbfahrtsdatum"
               "screen-value"
               "string(?)"
               "in frame {&frame-name}"}
            {setwidgetattr
               "gcuAbfahrtszeit"
               "screen-value"
               "'':U"
               "in frame {&frame-name}"}
            .

      end. /* Tour relevant */
      &ENDIF

      /* check timeframe if it is not already done by Tourplanning */
      /* but only if date field was changed */
      /* If deliverytime basis of a timeframe is "shipping date", trans-  */
      /* portation time and timeunit have to be considered.               */
      if not lTransportFound
        and lDateFieldChanged then
        tCheckDate = branche.vert.cls.UVC_CISalesDocumentSvc:prpoInstance:tDeliveryDatebyTimeframe
          (V_BelegKopf.V_BelegKopf_Obj,
           tFieldDate,
           V_BelegKopf.Lagergruppe,
           input frame {&frame-name} V_BelegPos.Lagerort,
           input frame {&frame-name} V_BelegPos.Transportzeit,
           V_BelegPos.Zeiteinheit:screen-value in frame {&frame-name},
           {fnarg pa_hADMTopContainer this-procedure}).

      if not lTransportFound
        and tCheckDate <> ?
        and tCheckdate <> tFieldDate then
        if adm.method.cls.DMCMessageSvc:prpoInstance:lshowMessage(cMessageNumber,
                                                                  string(tCheckdate,'{&PA_DATEFORMAT}':U)) then
        do:

          {setwidgetattr
             "phField"
             "screen-value"
             "string(tCheckdate,'{&PA_DATEFORMAT}':U)"}.

          {fnarg
            pa_lUISvcDisplayInfoFieldOfWidget
            "phField"}.

        end. /* if lshowMessage */

      phField:private-data = string(date({getwidgetattr phField screen-value string}),'{&PA_DATEFORMAT}':U).

    end. /* if lDateFieldChanged ... */
  end. /* tFieldDate <> ? */

  &IF LOOKUP("U_CW":U,"{&PA-OPTIONEN}":U) > 0 &THEN
  if input frame  {&FRAME-NAME} V_BelegPos.uCW_TransportNr > 0 then
    {setwidgetattr
       "V_BelegPos.uCI_Warenausgangstermin"
       "screen-value"
       "gtuAbfahrtsdatum:screen-value in frame {&frame-name}"
       "in frame {&frame-name}"}.
  else
  &ENDIF

  if date(V_BelegPos.Liefertermin:screen-value in frame {&frame-name}) <> ? then
    {setwidgetattr
       "V_BelegPos.uCI_Warenausgangstermin"
       "screen-value"
       "string(date(V_BelegPos.Liefertermin:screen-value in frame {&frame-name}) - dynamic-function('pa_iCalendTransportTime':U in target-procedure, V_BelegPos.Firma, V_BelegKopf.Lagergruppe, input frame {&frame-name} V_BelegPos.Lagerort, input frame {&frame-name} V_BelegPos.Transportzeit, V_BelegPos.Zeiteinheit:screen-value in frame {&frame-name}, date(V_BelegPos.Liefertermin:screen-value in frame {&frame-name}), no), V_BelegPos.Versandtermin:format in frame {&frame-name})"
       "in frame {&frame-name}"}.

  else
    {setwidgetattr
       "V_BelegPos.uCI_Warenausgangstermin"
       "screen-value"
       "string(date(V_BelegPos.Wunschtermin:screen-value in frame {&frame-name}) - dynamic-function('pa_iCalendTransportTime':U in target-procedure, V_BelegPos.Firma, V_BelegKopf.Lagergruppe, input frame {&frame-name} V_BelegPos.Lagerort, input frame {&frame-name} V_BelegPos.Transportzeit, V_BelegPos.Zeiteinheit:screen-value in frame {&frame-name}, date(V_BelegPos.Wunschtermin:screen-value in frame {&frame-name}), no),V_BelegPos.Versandtermin:format in frame {&frame-name})"
       "in frame {&frame-name}"}.

  {setwidgetattr
     "V_BelegPos.Versandtermin"
     "screen-value"
     "string(date(V_BelegPos.uCI_Warenausgangstermin:screen-value in frame {&frame-name}) - dynamic-function('pa_iCalendTransportTime':U in target-procedure, V_BelegPos.Firma, V_BelegKopf.Lagergruppe, input frame {&frame-name} V_BelegPos.Lagerort, input frame {&frame-name} V_BelegPos.uCI_KommZeit, V_BelegPos.uCI_KommZeiteinheit:screen-value in frame {&frame-name}, date(V_BelegPos.uCI_Warenausgangstermin:screen-value in frame {&frame-name}), no), V_BelegPos.Versandtermin:format in frame {&frame-name})"
     "in frame {&frame-name}"}.

  if lDateFieldChanged
    and date(input frame {&frame-name} V_BelegPos.uCI_Warenausgangstermin) < today then

    adm.method.cls.DMCMessageSvc:prpoInstance:lShowMessage(
      'v_bel00188':U,
      string(input frame {&frame-name} V_BelegPos.uCI_Warenausgangstermin,'{&PA_DATEFORMAT}':U)).

  {fnarg
    pa_lUISvcDisplayInfoFieldOfWidget
    "V_BelegPos.Versandtermin:handle in frame {&frame-name}"}.

  {fnarg
    pa_lUISvcDisplayInfoFieldOfWidget
    "V_BelegPos.Liefertermin:handle in frame {&frame-name}"}.

  {fnarg
    pa_lUISvcDisplayInfoFieldOfWidget
    "V_BelegPos.uCI_Warenausgangstermin:handle in frame {&frame-name}"}.

  &IF LOOKUP("U_CW":U,"{&PA-OPTIONEN}":U) > 0 &THEN
  {fnarg
    pa_lUISvcDisplayInfoFieldOfWidget
    "gtuAbfahrtsdatum:handle in frame {&frame-name}"}.
  &ENDIF

&ENDIF /* U_CI */

return lReturnValue.

end function. /* uUpdateDateFields */

/* _UIB-CODE-BLOCK-END */
&ANALYZE-RESUME

