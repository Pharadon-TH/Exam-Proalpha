&ANALYZE-SUSPEND _VERSION-NUMBER UIB_v8r2 GUI
&ANALYZE-RESUME

&ANALYZE-SUSPEND _UIB-CODE-BLOCK _CUSTOM _DECLARATIONS V-table-Win 

/* _UIB-CODE-BLOCK-END */
&ANALYZE-RESUME


&ANALYZE-SUSPEND _UIB-CODE-BLOCK _XFTR "Update Information" Procedure _INLINE
/* Actions: ? ? ? ? adm/support/proc/ds_pa_01.w */

/* _UIB-CODE-BLOCK-END */
&ANALYZE-RESUME

&ANALYZE-SUSPEND _UIB-CODE-BLOCK _CUSTOM _DEFINITIONS Procedure
/******************************************************************************/
/* @COPYRIGHT@                                                               */
/* Project: Proalpha                                                          */
/*                                                                            */
/* Name   : uvjvmo00.p                                                        */
/* Product: BRANCHE - Branchentemplates                                       */
/* Module : VERT - Vertrieb                                                   */
/*                                                                            */
/* Created: 6.1e00 as of 15.11.2016/Claas Kuehnlenz                           */
/* Current: @PAVERSION@ as of @PADATE@/@PALASTAUTHOR@                         */
/*                                                                            */
/*----------------------------------------------------------------------------*/
/* DESCRIPTION                                                                */
/*----------------------------------------------------------------------------*/
/*                                                                            */
/* DAO zu dsUVR_CIVersandBeleg (Data Access Object)                           */
/*                                                                            */
/*----------------------------------------------------------------------------*/
/* PARAMETERS                                                                 */
/*----------------------------------------------------------------------------*/
/* Name                      Description                                      */
/*----------------------------------------------------------------------------*/
/*                                                                            */
/*----------------------------------------------------------------------------*/
/* HISTORY                                                                    */
/*----------------------------------------------------------------------------*/
/* @FILEHISTORY@                                                              */
/******************************************************************************/

/* Procedure Information -----------------------------------------------------*/

&GLOBAL-DEFINE pa-Autor             Claas Kuehnlenz
&GLOBAL-DEFINE pa-Version           @PAVERSION@
&GLOBAL-DEFINE pa-Datum             @PADATE@
&GLOBAL-DEFINE pa-Letzter           @PALASTAUTHOR@

&GLOBAL-DEFINE pa-GenVersion       OEA
&GLOBAL-DEFINE pa-ProgrammTyp      DataAccessObject
&GLOBAL-DEFINE pa-Template         padataaccessobject.pjet
&GLOBAL-DEFINE pa-TemplateVersion  3.00
&GLOBAL-DEFINE pa-XBasisName       uvjvmo00_p
&GLOBAL-DEFINE pa-NameSpace        2.00

/*----------------------------------------------------------------------------*/
/* Definitions                                                                */
/*----------------------------------------------------------------------------*/

/* Parameters ----------------------------------------------------------------*/

/* Globals -------------------------------------------------------------------*/

{adm/template/incl/dt_dao00.df}

/* Temp-Tables ---------------------------------------------------------------*/

define temp-table ttOnHandStorageArea no-undo
  field StorageArea like ML_Ort.LagerOrt
  field Part  like S_Artikel.Artikel
  field OnHand as decimal
  index Main is primary unique
    StorageArea Part.

define temp-table ttBestandKommzone no-undo
  field Kommzone like ML_KommZone.KommZone
  field Artikel  like S_Artikel.Artikel
  field Bestand as decimal
  index Main is primary unique
    Kommzone Artikel.

define temp-table ttArtikelVerwendungspruefung no-undo
  field Lagergruppe like ML_Lagergruppe.Lagergruppe
  field Artikel     like S_Artikel.Artikel
  field ArtVar      like V_BelegPos.ArtVar
  index Main is primary unique
    Lagergruppe Artikel ArtVar.

define temp-table ttKommMenge no-undo
  field Firma         like VU_RA_Pos.Firma
  field BelegArt      like VU_RA_Pos.BelegArt
  field ReferenzNr    like VU_RA_Pos.ReferenzNr
  field PositionsNr   like VU_RA_Pos.PositionsNr
  field AbrufArt      like VU_RA_Pos.AbrufArt
  field AbrufNr       like VU_RA_Pos.AbrufNr
  field Vorschau      like VU_RA_Pos.Vorschau
  field VersandTermin like VU_RA_Pos.VersandTermin /* Mit Label Bereitstelltermin */
  field Menge         like VU_RA_Pos.Menge        initial 0
index Main is primary unique
  Firma BelegArt ReferenzNr PositionsNr AbrufArt AbrufNr Vorschau VersandTermin.
  
&IF LOOKUP("VS","{&PA-MODULE}") > 0 &THEN
/* Since the field uCI_DispatchQty does not exist in Service, the value must  */
/* be stored in a temp table to be able to access this value later.           */

  define temp-table ttGenerateDemandQtyForService no-undo
    field Doctype      like VU_RA_Pos.BelegArt
    field Owning_obj   like VS_AuftragMKT.VS_AuftragMKT_Obj
    field Qty          like VU_RA_Pos.Menge        initial 0
  index Main is primary unique
    Doctype Owning_obj.
&ENDIF   

/* SCOPEDs -------------------------------------------------------------------*/


/* Datasets ------------------------------------------------------------------*/

{branche/vert/incl/uv_vmo00.pds}

/* Variables -----------------------------------------------------------------*/
/*----------------------------------------------------------------------------*/
define variable pa-filter-Konto_min                     like ttUV_VersandBeleg.Konto                      no-undo init ?.
define variable pa-filter-Konto_max                     like ttUV_VersandBeleg.Konto                      no-undo init ?.
define variable pa-filter-Artikel_min                   like ttUV_VersandBeleg.Artikel                    no-undo init ?.
define variable pa-filter-Artikel_max                   like ttUV_VersandBeleg.Artikel                    no-undo init ?.
define variable pa-filter-ArtikelGruppe_min             like ttUV_VersandBeleg.ArtikelGruppe              no-undo init ?.
define variable pa-filter-ArtikelGruppe_max             like ttUV_VersandBeleg.ArtikelGruppe              no-undo init ?.
define variable pa-filter-Sparte_min                    like ttUV_VersandBeleg.Sparte                     no-undo init ?.
define variable pa-filter-Sparte_max                    like ttUV_VersandBeleg.Sparte                     no-undo init ?.
define variable pa-filter-ArtikelArt_min                like ttUV_VersandBeleg.ArtikelArt                 no-undo init ?.
define variable pa-filter-ArtikelArt_max                like ttUV_VersandBeleg.ArtikelArt                 no-undo init ?.
define variable pa-filter-Wunschtermin_min              like ttUV_VersandBeleg.Wunschtermin               no-undo init ?.
define variable pa-filter-Wunschtermin_max              like ttUV_VersandBeleg.Wunschtermin               no-undo init ?.
define variable pa-filter-Liefertermin_min              like ttUV_VersandBeleg.Liefertermin               no-undo init ?.
define variable pa-filter-Liefertermin_max              like ttUV_VersandBeleg.Liefertermin               no-undo init ?.
define variable pa-filter-uCI_Warenausgangst_min        like ttUV_VersandBeleg.uCI_Warenausgangstermin    no-undo init ?.
define variable pa-filter-uCI_Warenausgangst_max        like ttUV_VersandBeleg.uCI_Warenausgangstermin    no-undo init ?.
define variable pa-filter-Versandtermin_min             like ttUV_VersandBeleg.Versandtermin              no-undo init ?.
define variable pa-filter-Versandtermin_max             like ttUV_VersandBeleg.Versandtermin              no-undo init ?.
define variable pa-filter-BelegNummer_min               like ttUV_VersandBeleg.BelegNummer                no-undo init ?.
define variable pa-filter-BelegNummer_max               like ttUV_VersandBeleg.BelegNummer                no-undo init ?.
define variable pa-filter-Sachbearbeiter_min            like ttUV_VersandBeleg.Sachbearbeiter             no-undo init ?.
define variable pa-filter-Sachbearbeiter_max            like ttUV_VersandBeleg.Sachbearbeiter             no-undo init ?.
define variable pa-filter-AuftragsArt_min               like ttUV_VersandBeleg.AuftragsArt                no-undo init ?.
define variable pa-filter-AuftragsArt_max               like ttUV_VersandBeleg.AuftragsArt                no-undo init ?.
define variable pa-filter-LieferAdresse_min             like ttUV_VersandBeleg.LieferAdresse              no-undo init ?.
define variable pa-filter-LieferAdresse_max             like ttUV_VersandBeleg.LieferAdresse              no-undo init ?.
define variable pa-filter-AdressKennung_min             like ttUV_VersandBeleg.AdressKennung              no-undo init ?.
define variable pa-filter-AdressKennung_max             like ttUV_VersandBeleg.AdressKennung              no-undo init ?.
define variable pa-filter-Abladestelle_min              like ttUV_VersandBeleg.Abladestelle               no-undo init ?.
define variable pa-filter-Abladestelle_max              like ttUV_VersandBeleg.Abladestelle               no-undo init ?.
define variable pa-filter-uCI_LagerortKunde_min         like ttUV_VersandBeleg.uCI_LagerortKunde          no-undo init ?.
define variable pa-filter-uCI_LagerortKunde_max         like ttUV_VersandBeleg.uCI_LagerortKunde          no-undo init ?.
define variable pa-filter-VersandArt_min                like ttUV_VersandBeleg.VersandArt                 no-undo init ?.
define variable pa-filter-VersandArt_max                like ttUV_VersandBeleg.VersandArt                 no-undo init ?.
define variable pa-filter-LieferBedingung_min           like ttUV_VersandBeleg.LieferBedingung            no-undo init ?.
define variable pa-filter-LieferBedingung_max           like ttUV_VersandBeleg.LieferBedingung            no-undo init ?.
define variable pa-filter-Lieferant_min                 like ttUV_VersandBeleg.Lieferant                  no-undo init ?.
define variable pa-filter-Lieferant_max                 like ttUV_VersandBeleg.Lieferant                  no-undo init ?.
define variable pa-filter-iMRPRelease_var                 as integer                                      no-undo init ?.
define variable pa-filter-lPastOrderLines_var             as logical                                      no-undo init no.
define variable pa-filter-lTodayOrderLines_var            as logical                                      no-undo init yes.
define variable pa-filter-lFutureOrderLines_var           as logical                                      no-undo init yes.
define variable pa-filter-iBezugsdatum_var                as integer                                      no-undo init ?.
define variable pa-filter-iHorizont_var                   as integer                                      no-undo init ?.
define variable pa-filter-lBelegartU_var                  as logical                                      no-undo init ?.
define variable pa-filter-lBelegartVUA_var                as logical                                      no-undo init ?.
&IF LOOKUP("VS","{&PA-MODULE}") > 0 &THEN
  define variable pa-filter-lDocTypeServiceOrder_var        as logical                                      no-undo init ?.
  define variable pa-filter-lDocTypeRepairOrder_var         as logical                                      no-undo init ?.
&ENDIF  
define variable pa-filter-lBelegartPPF_var                as logical                                      no-undo init ?.
define variable pa-filter-lCoverageStatus_Without_var     as logical                                      no-undo init ?.
define variable pa-filter-lCoverageStatus_Available_var   as logical                                      no-undo init ?.
define variable pa-filter-lCoverageStatus_PAvailable_var  as logical                                      no-undo init ?.
define variable pa-filter-lCoverageStatus_Covered_var     as logical                                      no-undo init ?.
define variable pa-filter-lCoverageStatus_Open_var        as logical                                      no-undo init ?.
define variable pa-filter-StorageArea_min               like ttUV_VersandBeleg.StorageArea                no-undo init ?.
define variable pa-filter-StorageArea_max               like ttUV_VersandBeleg.StorageArea                no-undo init ?.
define variable pa-filter-CreditTerms_min               like ttUV_VersandBeleg.CreditTerms                no-undo init ?.
define variable pa-filter-CreditTerms_max               like ttUV_VersandBeleg.CreditTerms                no-undo init ?.
define variable pa-filter-DeliveryRestriction_min       like ttUV_VersandBeleg.LieferRestrikt             no-undo init ?.
define variable pa-filter-DeliveryRestriction_max       like ttUV_VersandBeleg.LieferRestrikt             no-undo init ?.
define variable pa-filter-MRPArea_min                   like ttUV_VersandBeleg.MRPArea                    no-undo init ?.
define variable pa-filter-MRPArea_max                   like ttUV_VersandBeleg.MRPArea                    no-undo init ?.

/* --> MO#HIDR-AH4-1123 thongdi_p 20.07.2026 Erweiterung Versandmonitor im Feld Best. Termin */
define variable pa-filter-xEbLiefertermin_min             as date                                         no-undo init ?.
define variable pa-filter-xEbLiefertermin_max             as date                                         no-undo init ?.
/* <-- MO#HIDR-AH4-1123 thongdi_p 20.07.2026 Erweiterung Versandmonitor im Feld Best. Termin */


define variable gtBezugsdatum                       as date                                         no-undo.

define variable gcSB_ShipmentRestrictions_keys     as character     no-undo.
define variable gcSB_ShipmentRestrictions_desc     as character     no-undo.
define variable glUCI_ReservationsInOnhand         as logical       no-undo.
define variable glMM_PickSafetyStock               as logical       no-undo.
define variable glUCI_ShippingMonitorReallocateAll as logical       no-undo.
define variable gdExchangeRate                     as decimal       no-undo.

define variable goSchedPegging as class mawi.base.cls.MMCSchedPeggingSvo no-undo.

/* Buffers -------------------------------------------------------------------*/

define buffer gbD_MeldungSpr for D_MeldungSpr.

/* _UIB-CODE-BLOCK-END */
&ANALYZE-RESUME


&ANALYZE-SUSPEND _UIB-PREPROCESSOR-BLOCK

/* ********************  Preprocessor Definitions  ******************** */

&Scoped-define PROCEDURE-TYPE Procedure
&Scoped-define DB-AWARE no



/* _UIB-PREPROCESSOR-BLOCK-END */
&ANALYZE-RESUME

/* ************************  Function Prototypes ********************** */


&IF DEFINED(EXCLUDE-cErrortext) = 0 &THEN

&ANALYZE-SUSPEND _UIB-CODE-BLOCK _FUNCTION-FORWARD cErrortext V-table-Win
function cErrortext returns character
  (input pcErrorcode as character,
   input pcSubstitute like V_BelegPos.uCI_MessageSubst) forward.

/* _UIB-CODE-BLOCK-END */
&ANALYZE-RESUME


&ENDIF




&IF DEFINED(EXCLUDE-cSetLocklevelValue) = 0 &THEN

&ANALYZE-SUSPEND _UIB-CODE-BLOCK _FUNCTION-FORWARD cSetLocklevelValue V-table-Win
function cSetLocklevelValue returns character 
  ( cLockStatusRecordObj as character,
    cTargetArea as character ) forward.

/* _UIB-CODE-BLOCK-END */
&ANALYZE-RESUME


&ENDIF


&IF DEFINED(EXCLUDE-dGetPhysicalOnHand) = 0 &THEN

&ANALYZE-SUSPEND _UIB-CODE-BLOCK _FUNCTION-FORWARD dGetPhysicalOnHand V-table-Win
function dGetPhysicalOnHand returns decimal
  ( buffer pbML_Ort   for ML_Ort,
           pcPart     like S_artikel.Artikel,
           pcPartType like V_BelegPos.ArtVar,
           pcOrigin   as character ) forward.

/* _UIB-CODE-BLOCK-END */
&ANALYZE-RESUME


&ENDIF


&IF DEFINED(EXCLUDE-iDunningLevel) = 0 &THEN

&ANALYZE-SUSPEND _UIB-CODE-BLOCK _FUNCTION-FORWARD iDunningLevel V-table-Win
function iDunningLevel returns integer 
  ( piKunde like S_Kunde.Kunde ) forward.

/* _UIB-CODE-BLOCK-END */
&ANALYZE-RESUME


&ENDIF


/* *********************** Procedure Settings ************************ */

&ANALYZE-SUSPEND _PROCEDURE-SETTINGS
/* Settings for THIS-PROCEDURE
   Type: Procedure
   Allow:
   Frames: 0
   Add Fields to: Neither
   Other Settings: CODE-ONLY
 */
&ANALYZE-RESUME _END-PROCEDURE-SETTINGS

/* *************************  Create Window  ************************** */

&ANALYZE-SUSPEND _CREATE-WINDOW
/* DESIGN Window definition (used by the UIB)
  CREATE WINDOW Procedure ASSIGN
         HEIGHT             = 6.95
         WIDTH              = 50.4.
/* END WINDOW DEFINITION */
                                                                        */
&ANALYZE-RESUME

&ANALYZE-SUSPEND _UIB-CODE-BLOCK _CUSTOM _INCLUDED-LIB Procedure
/* ************************* Included-Libraries *********************** */

{adm/method/incl/dm_dao00.lib}

/* _UIB-CODE-BLOCK-END */
&ANALYZE-RESUME





&ANALYZE-SUSPEND _UIB-CODE-BLOCK _CUSTOM _MAIN-BLOCK Procedure


/* ***************************  Main Block  *************************** */

/*----------------------------------------------------------------------------*/
/* Processing                                                                 */
/*----------------------------------------------------------------------------*/

/* _UIB-CODE-BLOCK-END */
&ANALYZE-RESUME



/* **********************  Internal Procedures  *********************** */

&IF DEFINED(EXCLUDE-fillCallSalesOrders) = 0 &THEN

&ANALYZE-SUSPEND _UIB-CODE-BLOCK _PROCEDURE fillCallSalesOrders Method-Library 
procedure fillCallSalesOrders :
/* Description ---------------------------------------------------------------*/
/*                                                                            */
/* Fills the dataset with call sales orders                                   */
/*                                                                            */
/* Notes ---------------------------------------------------------------------*/
/*                                                                            */
/*                                                                            */
/*                                                                            */
/* Parameters ----------------------------------------------------------------*/
/*                                                                            */
/* <none>                                                                     */
/*                                                                            */
/* Examples ------------------------------------------------------------------*/
/*                                                                            */
/*                                                                            */
/*                                                                            */
/*----------------------------------------------------------------------------*/

/* Variables -----------------------------------------------------------------*/
/*----------------------------------------------------------------------------*/
define variable iLieferant  like S_Lieferant.Lieferant                  no-undo.
define variable cDummy              as character                        no-undo.
define variable iDummy              as integer                          no-undo.
define variable cBelegartBez        as character                        no-undo.
define variable iDeliveryAddress  like S_LieferAdresse.LieferAdresse    no-undo.
define variable cUnloadingPoint   like V_BelegPos.Abladestelle          no-undo.
define variable dExcess           as   decimal                          no-undo.
define variable cMRPDocType         as character                        no-undo.
define variable cTargetArea       as character                          no-undo.

/* Buffers -------------------------------------------------------------------*/
define buffer bV_BelegKopf          for V_BelegKopf.
define buffer bV_BelegPos           for V_BelegPos.
define buffer bVU_RA_Abruf          for VU_RA_Abruf.
define buffer bVU_RA_Pos            for VU_RA_Pos.
define buffer bS_Kunde              for S_Kunde.
define buffer bS_Adresse-Kunde      for S_Adresse.
define buffer bS_BrancheSpr         for S_BrancheSpr.
define buffer bS_RegionSpr          for S_RegionSpr.
define buffer bS_Artikel            for S_Artikel.
define buffer bS_ArtikelSpr         for S_ArtikelSpr.
define buffer bS_SparteSpr          for S_SparteSpr.
define buffer bS_ArtKunde           for S_ArtKunde.
define buffer bS_Lieferant          for S_Lieferant.
define buffer bS_Adresse-Lief       for S_Adresse.
define buffer bS_Lieferadresse      for S_Lieferadresse.
define buffer bS_Adresse-LiefAdr    for S_Adresse.
define buffer bML_Ort               for ML_Ort.
define buffer bML_OrtSpr            for ML_OrtSpr.
define buffer bS_Abladestelle       for S_Abladestelle.
define buffer bML_Lagergruppe       for ML_Lagergruppe.
define buffer bML_OrtSpr-StorArea   for ML_OrtSpr.
define buffer bML_LagergruppeSpr    for ML_LagergruppeSpr.
define buffer bS_ZahlZielSpr        for S_ZahlZielSpr.


/*----------------------------------------------------------------------------*/
/* Processing                                                                 */
/*----------------------------------------------------------------------------*/

/* filter on fields that doesn't exist in call sales orders */
if   pa-filter-iMRPRelease_var = 2 /* no */ then
  return.

cBelegartBez = {fnarg
                 pa_cStCchDocTypeDesc
                 "'VUA':U,
                  pACConnectionSvc:prpcLanguage,
                  {&pa_CchDesc}"}.

empty temp-table ttKommMenge.

do for bS_Kunde,bML_Lagergruppe:

  Order:
  for each bV_BelegKopf  /* code checked by ouadi_M 14.09.2018 */
    where bV_BelegKopf.Firma           = {firma/vbelegko.fir pACConnectionSvc:prpcCompany}
      and bV_BelegKopf.BelegArt        = 'VUA':U
      and bV_BelegKopf.offen           = yes
      and bV_BelegKopf.BelegNummer    >= pa-filter-BelegNummer_min
      and bV_BelegKopf.BelegNummer    <= pa-filter-BelegNummer_max
      and bV_BelegKopf.JIT             = no /* JIT is not supported */
      and bV_BelegKopf.Kunde          >= pa-filter-Konto_min
      and bV_BelegKopf.Kunde          <= pa-filter-Konto_max
      and bV_BelegKopf.Sachbearbeiter >= pa-filter-Sachbearbeiter_min
      and bV_BelegKopf.Sachbearbeiter <= pa-filter-Sachbearbeiter_max
      and bV_BelegKopf.AuftragsArt    >= pa-filter-AuftragsArt_min
      and bV_BelegKopf.AuftragsArt    <= pa-filter-AuftragsArt_max
      and bV_Belegkopf.ZahlungsZiel   >= pa-filter-CreditTerms_min
      and bV_Belegkopf.ZahlungsZiel   <= pa-filter-CreditTerms_max
      and bV_BelegKopf.LieferRestrikt >= pa-filter-DeliveryRestriction_min
      and bV_BelegKopf.LieferRestrikt <= pa-filter-DeliveryRestriction_max
      use-index Kunde
    no-lock,
    each bV_BelegPos
    where bV_BelegPos.Firma             = {firma/vbelegko.fir pACConnectionSvc:prpcCompany}
      and bV_BelegPos.BelegArt          = bV_BelegKopf.BelegArt
      and bV_BelegPos.ReferenzNr        = bV_BelegKopf.ReferenzNr
      and bV_BelegPos.offen             = yes
      and bV_BelegPos.Satzart           = 'A':U
      and bV_BelegPos.WertPosition      = no
      and bV_BelegPos.Lagerort         <> ?
      and bV_BelegPos.Artikel          >= pa-filter-Artikel_min
      and bV_BelegPos.Artikel          <= pa-filter-Artikel_max
      and ((bV_BelegPos.uCI_Versandart >= pa-filter-VersandArt_min
        and bV_BelegPos.uCI_Versandart <= pa-filter-VersandArt_max)
         or bV_BelegPos.uCI_Versandart  = ?)
      and bV_BelegPos.LieferBedingung  >= pa-filter-LieferBedingung_min
      and bV_BelegPos.LieferBedingung  <= pa-filter-LieferBedingung_max
      and bV_BelegPos.LagerOrt         >= pa-filter-StorageArea_min
      and bV_BelegPos.LagerOrt         <= pa-filter-StorageArea_max
      use-index Main
    no-lock,
    each bVU_RA_Abruf
    where bVU_RA_Abruf.Firma              = {firma/vbelegko.fir pACConnectionSvc:prpcCompany}
      and bVU_RA_Abruf.BelegArt           = bV_BelegPos.BelegArt
      and bVU_RA_Abruf.ReferenzNr         = bV_BelegPos.ReferenzNr
      and bVU_RA_Abruf.PositionsNr        = bV_BelegPos.PositionsNr
      and bVU_RA_Abruf.AbrufArt           = (if bV_BelegKopf.FAB = yes then
                                               'FAB':U
                                             else
                                               'LAB':U)
      and bVU_RA_Abruf.Aktiv              = yes
      and bVU_RA_Abruf.uCI_LagerortKunde >= pa-filter-uCI_LagerortKunde_min
      and bVU_RA_Abruf.uCI_LagerortKunde <= pa-filter-uCI_LagerortKunde_max
    no-lock,
    each bVU_RA_Pos
    where bVU_RA_Pos.Firma                     = {firma/vbelegko.fir pACConnectionSvc:prpcCompany}
      and bVU_RA_Pos.BelegArt                  = bVU_RA_Abruf.BelegArt
      and bVU_RA_Pos.ReferenzNr                = bVU_RA_Abruf.ReferenzNr
      and bVU_RA_Pos.PositionsNr               = bVU_RA_Abruf.PositionsNr
      and bVU_RA_Pos.AbrufArt                  = bVU_RA_Abruf.AbrufArt
      and bVU_RA_Pos.AbrufNr                   = bVU_RA_Abruf.AbrufNr
      and bVU_RA_Pos.Vorschau                  = no
      and bVU_RA_Pos.AbrufTermin               >= pa-filter-Wunschtermin_min
      and bVU_RA_Pos.AbrufTermin               <= pa-filter-Wunschtermin_max
      and bVU_RA_Pos.AbrufTermin               >= pa-filter-Liefertermin_min
      and bVU_RA_Pos.AbrufTermin               <= pa-filter-Liefertermin_max
      and bVU_RA_Pos.uCI_Warenausgangstermin   >= pa-filter-uCI_Warenausgangst_min
      and bVU_RA_Pos.uCI_Warenausgangstermin   <= pa-filter-uCI_Warenausgangst_max
      and bVU_RA_Pos.Versandtermin             >= pa-filter-Versandtermin_min
      and bVU_RA_Pos.Versandtermin             <= pa-filter-Versandtermin_max
      and bVU_RA_Pos.dispositiv                =  yes
    no-lock
    by bVU_RA_Pos.Versandtermin
    by bVU_RA_Pos.AbrufZeit
    by bVU_RA_Pos.lfdNr
    on error undo, throw:
      
    /* check conditions */

    /* In Abrufauftr�gen gibt es noch keine Dispofreigabe ... */
    /* --> original
    case pa-filter-iMRPRelease_var:

      when 1 then /* yes */
        if bV_BelegPos.MRPRelease = no then
          next Order.

      when 2 then /* no */
        if bV_BelegPos.MRPRelease = yes then
          next Order.

    end case. /* pa-filter-iMRPRelease_var */
    <-- original */

    case pa-filter-iBezugsdatum_var:

      when 1 then gtBezugsdatum = bVU_RA_Pos.AbrufTermin.
      when 2 then gtBezugsdatum = bVU_RA_Pos.AbrufTermin.
      when 3 then gtBezugsdatum = bVU_RA_Pos.uCI_Warenausgangstermin.
      when 4 then gtBezugsdatum = bVU_RA_Pos.Versandtermin.
      /* --> MO#HIDR-AH4-1123 thongdi_p 20.07.2026 Erweiterung Versandmonitor im Feld Best. Termin */
      when 5 then gtBezugsdatum = basis.base.cls.BMCAddDataSvc:tValue
                                    (bV_BelegPos.V_BelegPos_Obj,
                                     'xEbLiefertermin':U).
      /* <-- MO#HIDR-AH4-1123 thongdi_p 20.07.2026 Erweiterung Versandmonitor im Feld Best. Termin */
    end case. /* pa-filter-iBezugsdatum_var */

    if not pa-filter-lPastOrderLines_var  
      and gtBezugsdatum < today then
      next Order.

    if not pa-filter-lTodayOrderLines_var  
      and gtBezugsdatum = today then 
      next Order.

    if not pa-filter-lFutureOrderLines_var  
      and gtBezugsdatum >  today  then
      next Order.
    else
      if gtBezugsdatum >  today + pa-filter-iHorizont_var then 
        next Order.

    /* check if Storage area matches to given range of MRP-Areas              */

    find bML_Ort
      where bML_Ort.Firma    = {firma/mlort.fir pACConnectionSvc:prpcCompany}
        and bML_Ort.LagerOrt = bV_BelegPos.LagerOrt
      no-lock no-error.

    if available bML_Ort then
    do:
      if not(    bML_Ort.Lagergruppe >= pa-filter-MRPArea_min
             and bML_Ort.Lagergruppe <= pa-filter-MRPArea_max) then 
        next Order.
    end.
    else
      if not(    bV_BelegKopf.Lagergruppe >= pa-filter-MRPArea_min
             and bV_BelegKopf.Lagergruppe <= pa-filter-MRPArea_max) then 
      next Order.

    /* load data and check conditions */

    find bS_Artikel
      where bS_Artikel.Firma          = {firma/sartikel.fir pACConnectionSvc:prpcCompany}
        and bS_Artikel.Artikel        = bV_BelegPos.Artikel
        and bS_Artikel.ArtikelGruppe >= pa-filter-ArtikelGruppe_min
        and bS_Artikel.ArtikelGruppe <= pa-filter-ArtikelGruppe_max
        and bS_Artikel.Sparte        >= pa-filter-Sparte_min
        and bS_Artikel.Sparte        <= pa-filter-Sparte_max
        and bS_Artikel.ArtikelArt    >= pa-filter-ArtikelArt_min
        and bS_Artikel.ArtikelArt    <= pa-filter-ArtikelArt_max
      no-lock no-error.

    if not available bS_Artikel then
      next Order.


    if not available bS_Kunde
      or bS_Kunde.Kunde <> bV_BelegKopf.Kunde then

      find bS_Kunde
        where bS_Kunde.Firma = {firma/s_kunde.fir pACConnectionSvc:prpcCompany}
          and bS_Kunde.Kunde = bV_BelegKopf.Kunde
        no-lock.

    find bS_Adresse-Kunde
      where bS_Adresse-Kunde.Firma    = {firma/s_adres.fir pACConnectionSvc:prpcCompany}
        and bS_Adresse-Kunde.AdressNr = bS_Kunde.AdressNr
      no-lock.

    branche.vert.cls.UVC_CAReleaseFunctionsSvc:prpoInstance:GetCallOrderUnloadingPoint(
      bVU_RA_Pos.VU_RA_Pos_Obj,
      input-output iDeliveryAddress,
      input-output cUnloadingPoint).

    if   cUnloadingPoint < pa-filter-Abladestelle_min
      or cUnloadingPoint > pa-filter-Abladestelle_max then

      next Order.

    find bS_Lieferadresse
      where bS_Lieferadresse.Firma         = {firma/s_kunde.fir pACConnectionSvc:prpcCompany}
        and bS_Lieferadresse.Lieferadresse = iDeliveryAddress
        and bS_Lieferadresse.Kunde         = bV_BelegKopf.Kunde
      no-lock no-error.

    find bS_Lieferant
      where bS_Lieferant.Firma     = {firma/sliefera.fir pACConnectionSvc:prpcCompany}
        and bS_Lieferant.Lieferant = bVU_RA_Abruf.Lieferant
      no-lock no-error.

    if bV_Belegpos.KO_Lagerort = ? then
      cTargetArea = 'VUL':U.
    else
      cTargetArea = 'MLL':U.

    /* create TT record */
    create ttUV_VersandBeleg.
    assign
      ttUV_VersandBeleg.Konto                   = bS_Kunde.Kunde
      ttUV_VersandBeleg.Konto_Name1             = bS_Adresse-Kunde.Name1
      ttUV_VersandBeleg.Konto_Name2             = bS_Adresse-Kunde.Name2
      ttUV_VersandBeleg.Konto_Name3             = bS_Adresse-Kunde.Name3
      ttUV_VersandBeleg.Konto_Suchbegriff       = bS_Kunde.Suchbegriff
      ttUV_VersandBeleg.Konto_Selektion         = bS_Kunde.Selektion
      ttUV_VersandBeleg.Konto_Branche           = bS_Kunde.Branche
      ttUV_VersandBeleg.Konto_Region            = bS_Kunde.Region
      ttUV_VersandBeleg.Belegart                = bV_BelegKopf.BelegArt
      ttUV_VersandBeleg.BelegartBez             = cBelegartBez
      ttUV_VersandBeleg.BelegNummer             = bV_BelegKopf.BelegNummer
      ttUV_VersandBeleg.PositionsNr             = bV_BelegPos.PositionsNr
      ttUV_VersandBeleg.BelegInfo               = bV_BelegKopf.BelegInfo
      ttUV_VersandBeleg.Abruf                   = bVU_RA_Abruf.Abruf
      ttUV_VersandBeleg.AbrufNr                 = bVU_RA_Abruf.AbrufNr
      ttUV_VersandBeleg.Abladestelle            = cUnloadingPoint
      ttUV_VersandBeleg.uCI_ZeichenKunde        = bVU_RA_Abruf.uCI_ZeichenKunde
      ttUV_VersandBeleg.uCI_LagerortKunde       = bVU_RA_Abruf.uCI_LagerortKunde
      ttUV_VersandBeleg.uCI_Hinweis1            = bVU_RA_Abruf.uCI_Hinweis1
      ttUV_VersandBeleg.uCI_Hinweis2            = bVU_RA_Abruf.uCI_Hinweis2
      ttUV_VersandBeleg.uCI_Hinweis3            = bVU_RA_Abruf.uCI_Hinweis3
      ttUV_VersandBeleg.uCI_Hinweis4            = bVU_RA_Abruf.uCI_Hinweis4
      ttUV_VersandBeleg.uCI_Sammellieferschein  = bV_BelegKopf.uCI_Sammellieferschein
      ttUV_VersandBeleg.Artikel                 = bS_Artikel.Artikel
      ttUV_VersandBeleg.ArtVar                  = bV_BelegPos.ArtVar
      ttUV_VersandBeleg.Artikelgruppe           = bS_Artikel.Artikelgruppe
      ttUV_VersandBeleg.Sparte                  = bS_Artikel.Sparte
      ttUV_VersandBeleg.Artikel_Selektion       = bS_Artikel.Selektion
      ttUV_VersandBeleg.Artikel_Suchbegriff     = bS_Artikel.Suchbegriff
      ttUV_VersandBeleg.ArtikelArt              = bS_Artikel.ArtikelArt
      ttUV_VersandBeleg.Wunschtermin            = bVU_RA_Pos.AbrufTermin
      ttUV_VersandBeleg.Liefertermin            = bVU_RA_Pos.AbrufTermin
      /* --> MO#HIDR-AH4-1123 thongdi_p 20.07.2026 Erweiterung Versandmonitor im Feld Best. Termin */      
      ttUV_VersandBeleg.xEbLiefertermin         = basis.base.cls.BMCAddDataSvc:tValue
                                                    (bV_BelegPos.V_BelegPos_Obj,
                                                     'xEbLiefertermin':U)   
      /* <-- MO#HIDR-AH4-1123 thongdi_p 20.07.2026 Erweiterung Versandmonitor im Feld Best. Termin */                                                 
      ttUV_VersandBeleg.Transportzeit           = (if available bS_Lieferadresse then
                                                     bS_LieferAdresse.TranspZeit
                                                   else
                                                     bV_BelegPos.Transportzeit)
      ttUV_VersandBeleg.Zeiteinheit             = (if available bS_Lieferadresse then
                                                     bS_LieferAdresse.Zeiteinheit
                                                   else
                                                     bV_BelegPos.Zeiteinheit)
      ttUV_VersandBeleg.uCI_Warenausgangstermin = bVU_RA_Pos.uCI_Warenausgangstermin
      ttUV_VersandBeleg.uCI_KommZeit            = (if available bS_Lieferadresse then
                                                     bS_LieferAdresse.uCI_KommZeit
                                                   else
                                                     bV_BelegPos.uCI_KommZeit)
      ttUV_VersandBeleg.uCI_KommZeiteinheit     = (if available bS_Lieferadresse then
                                                     bS_LieferAdresse.uCI_KommZeiteinheit
                                                   else
                                                     bV_BelegPos.uCI_KommZeiteinheit)
      ttUV_VersandBeleg.Versandtermin           = bVU_RA_Pos.Versandtermin
      ttUV_VersandBeleg.AuftragsArt             = bV_BelegKopf.AuftragsArt
      ttUV_VersandBeleg.Versandart              = bV_BelegPos.uCI_Versandart
      ttUV_VersandBeleg.LieferBedingung         = bV_BelegPos.LieferBedingung
      ttUV_VersandBeleg.LieferRestrikt          = bV_BelegKopf.LieferRestrikt
      ttUV_VersandBeleg.Sachbearbeiter          = bV_BelegKopf.Sachbearbeiter
      ttUV_VersandBeleg.KO_LagerOrt             = bV_BelegPos.KO_LagerOrt
      ttUV_VersandBeleg.MengenEinheit           = bV_BelegPos.MengenEinheit
      ttUV_VersandBeleg.VME_Faktor              = bV_BelegPos.VME_Faktor
      ttUV_VersandBeleg.MRPRelease              = bV_BelegPos.MRPRelease
      ttUV_VersandBeleg.Owning_Obj              = bVU_RA_Pos.VU_RA_Pos_Obj
      ttUV_VersandBeleg.V_BelegPos_Obj          = bV_BelegPos.V_BelegPos_Obj
      ttUV_VersandBeleg.ReferenzNr              = bV_BelegKopf.ReferenzNr
      ttUV_VersandBeleg.MRPDocType              = (if    bV_BelegKopf.FAB = yes
                                                      or bV_BelegKopf.JiT = yes then
                                                     'VLA':U
                                                   else
                                                     'VUA':U)
      ttUV_VersandBeleg.Nachkomma               = bV_BelegPos.Nachkomma
      ttUV_VersandBeleg.WaehrungNK              = bV_BelegKopf.WaehrungNK
      ttUV_VersandBeleg.StorageArea             = bV_BelegPos.LagerOrt
      ttUV_VersandBeleg.CreditTerms             = bV_BelegKopf.ZahlungsZiel
            ttUV_VersandBeleg.LocklevelOriginLSLSL    
        = cSetLocklevelValue(bV_BelegKopf.V_BelegKopf_Obj,                  
                             cTargetArea) when available bV_BelegKopf
      ttUV_VersandBeleg.LocklevelOriginMMP     
        = cSetLocklevelValue(bV_BelegKopf.V_BelegKopf_Obj,                  
                             'MMP':U) when available bV_BelegKopf
      ttUV_VersandBeleg.LocklevelPartLSLSL      
        = cSetLocklevelValue(bS_Artikel.S_Artikel_Obj,                  
                             cTargetArea) when available bS_Artikel       
      ttUV_VersandBeleg.LocklevelPartMMP        
        = cSetLocklevelValue(bS_Artikel.S_Artikel_Obj,                  
                             'MMP':U) when available bS_Artikel        
      ttUV_VersandBeleg.LocklevelCustomerLSLSL  
        = cSetLocklevelValue(bS_Kunde.S_Kunde_Obj,                  
                             cTargetArea) when available bS_Kunde      
      ttUV_VersandBeleg.LocklevelCustomerMMP    
        = cSetLocklevelValue(bS_Kunde.S_Kunde_Obj,                  
                             'MMP':U) when available bS_Kunde 
      ttUV_VersandBeleg.LocklevelCarrierLSL
        = cSetLocklevelValue(bS_Lieferant.S_Lieferant_Obj,
                             'MLL':U) when available bS_Lieferant
      ttUV_VersandBeleg.LocklevelCarrierVSD
        = cSetLocklevelValue(bS_Lieferant.S_Lieferant_Obj,
                             'VSD':U) when available bS_Lieferant
      ttUV_VersandBeleg.Mahnstufe
        = iDunningLevel(bS_Kunde.Kunde) when available bS_Kunde
      .

    /* --> MO#HIDR-AH4-1123 thongdi_p 20.07.2026 Erweiterung Versandmonitor im Feld Best. Termin */
    ttUV_VersandBeleg.xEbLiefertermin = basis.base.cls.BMCAddDataSvc:tValue
                                          (bV_BelegPos.V_BelegPos_Obj,
                                           'xEbLiefertermin':U).
                                           
    if pa-filter-xEbLiefertermin_min <> ? then
    do:
      if   ttUV_VersandBeleg.xEbLiefertermin = ?
        or ttUV_VersandBeleg.xEbLiefertermin < pa-filter-xEbLiefertermin_min
        or ttUV_VersandBeleg.xEbLiefertermin > pa-filter-xEbLiefertermin_max then
      do:
        delete ttUV_VersandBeleg.
        next Order.
      end.
    end.
    
    /* <-- MO#HIDR-AH4-1123 thongdi_p 20.07.2026 Erweiterung Versandmonitor im Feld Best. Termin */
    
    /* Ship-To Address */
    if available bS_Lieferadresse then
    do:

      find bS_Adresse-LiefAdr
        where bS_Adresse-LiefAdr.Firma    = {firma/s_adres.fir pACConnectionSvc:prpcCompany}
          and bS_Adresse-LiefAdr.AdressNr = bS_LieferAdresse.AdressNr
        no-lock.

      assign
        ttUV_VersandBeleg.LieferAdresse      = bS_LieferAdresse.LieferAdresse
        ttUV_VersandBeleg.AdressKennung      = bS_LieferAdresse.AdressKennung
        ttUV_VersandBeleg.LiefAdr_Name1      = bS_Adresse-LiefAdr.Name1
        ttUV_VersandBeleg.LiefAdr_Staat      = bS_Adresse-LiefAdr.Staat
        ttUV_VersandBeleg.LiefAdr_PLZ        = bS_Adresse-LiefAdr.PLZ
        ttUV_VersandBeleg.LiefAdr_Ort        = bS_Adresse-LiefAdr.Ort
        ttUV_VersandBeleg.LiefAdr_Bundesland = bS_Adresse-LiefAdr.Bundesland
        ttUV_VersandBeleg.LiefAdr_Name2      = bS_Adresse-LiefAdr.Name2
        ttUV_VersandBeleg.LiefAdr_Name3      = bS_Adresse-LiefAdr.Name3
        ttUV_VersandBeleg.LiefAdr_Strasse    = bS_Adresse-LiefAdr.Strasse
        ttUV_VersandBeleg.LiefAdr_HausNummer = bS_Adresse-LiefAdr.HausNummer
        .

    end. /* available bS_Lieferadresse */
    else
      assign
        ttUV_VersandBeleg.LieferAdresse      = ?
        ttUV_VersandBeleg.AdressKennung      = '':U
        ttUV_VersandBeleg.LiefAdr_Name1      = bS_Adresse-Kunde.Name1
        ttUV_VersandBeleg.LiefAdr_Staat      = bS_Adresse-Kunde.Staat
        ttUV_VersandBeleg.LiefAdr_PLZ        = bS_Adresse-Kunde.PLZ
        ttUV_VersandBeleg.LiefAdr_Ort        = bS_Adresse-Kunde.Ort
        ttUV_VersandBeleg.LiefAdr_Bundesland = bS_Adresse-Kunde.Bundesland
        ttUV_VersandBeleg.LiefAdr_Name2      = bS_Adresse-Kunde.Name2
        ttUV_VersandBeleg.LiefAdr_Name3      = bS_Adresse-Kunde.Name3
        ttUV_VersandBeleg.LiefAdr_Strasse    = bS_Adresse-Kunde.Strasse
        ttUV_VersandBeleg.LiefAdr_HausNummer = bS_Adresse-Kunde.HausNummer
        .

    if   ttUV_VersandBeleg.LieferAdresse < pa-filter-LieferAdresse_min
      or ttUV_VersandBeleg.LieferAdresse > pa-filter-LieferAdresse_max then
    do:
      delete ttUV_VersandBeleg.
      next Order.
    end.

    if   ttUV_VersandBeleg.AdressKennung < pa-filter-AdressKennung_min
      or ttUV_VersandBeleg.AdressKennung > pa-filter-AdressKennung_max then
    do:
      delete ttUV_VersandBeleg.
      next Order.
    end.

    if not available bS_Lieferant then
      find bS_Lieferant
        where bS_Lieferant.Firma     = {firma/sliefera.fir pACConnectionSvc:prpcCompany}
          and bS_Lieferant.Lieferant = bV_BelegKopf.Lieferant
        no-lock no-error.

    find bS_Abladestelle
      where bS_Abladestelle.Firma         = {firma/s_kunde.fir pACConnectionSvc:prpcCompany}
        and bS_Abladestelle.Kunde         = bV_BelegKopf.Kunde
        and bS_Abladestelle.LieferAdresse = iDeliveryAddress
        and bS_Abladestelle.Abladestelle  = cUnloadingPoint
      no-lock no-error.

    if not available bS_Lieferant then
    do:

      run mawi/base/proc/mmvtra00.p (       bV_BelegKopf.Firma,
                                            bV_BelegKopf.Kunde,
                                            bV_BelegPos.uCI_Versandart,
                                            (if available bS_Lieferadresse then
                                               bS_Lieferadresse.Lieferadresse
                                             else
                                               ?),
                                            (if available bS_Abladestelle then
                                               bS_Abladestelle.Abladestelle
                                             else
                                               '':U),
                                     output iLieferant,
                                     output cDummy,
                                     output cDummy,
                                     output iDummy,
                                     output iDummy,
                                     output cDummy).

      find bS_Lieferant
        where bS_Lieferant.Firma     = {firma/sliefera.fir pACConnectionSvc:prpcCompany}
          and bS_Lieferant.Lieferant = iLieferant
        no-lock no-error.

    end.

    if available bS_Lieferant then
      find bS_Adresse-Lief
        where bS_Adresse-Lief.Firma    = {firma/s_adres.fir pACConnectionSvc:prpcCompany}
          and bS_Adresse-Lief.AdressNr = bS_Lieferant.AdressNr
        no-lock.
    else
      release bS_Adresse-Lief.

    assign
      ttUV_VersandBeleg.Lieferant               = bS_Lieferant.Lieferant      when available bS_Lieferant
      ttUV_VersandBeleg.Lieferant_Name1         = bS_Adresse-Lief.Name1       when available bS_Adresse-Lief
      ttUV_VersandBeleg.Lieferant_Name2         = bS_Adresse-Lief.Name2       when available bS_Adresse-Lief
      ttUV_VersandBeleg.Lieferant_Name3         = bS_Adresse-Lief.Name3       when available bS_Adresse-Lief
      ttUV_VersandBeleg.Lieferant_Suchbegriff   = bS_Lieferant.Suchbegriff    when available bS_Lieferant
      ttUV_VersandBeleg.Lieferant_Selektion     = bS_Lieferant.Selektion      when available bS_Lieferant
      .

    if   ttUV_VersandBeleg.Lieferant < pa-filter-Lieferant_min
      or ttUV_VersandBeleg.Lieferant > pa-filter-Lieferant_max then
    do:
      delete ttUV_VersandBeleg.
      next Order.
    end.


    /* quantities */
    assign
      ttUV_VersandBeleg.Menge                   = bVU_RA_Pos.Menge
      ttUV_VersandBeleg.gelieferte_Menge        = bVU_RA_Pos.gelieferte_Menge + bVU_RA_Pos.uebern_Menge
      ttUV_VersandBeleg.stornierte_Menge        = bVU_RA_Pos.stornierte_Menge
      ttUV_VersandBeleg.KommMenge               = max(mawi.base.cls.MMCPickingSvc:prpoInstance:dReviewReservationQty
                                                        (bVU_RA_Pos.VU_RA_Pos_Obj),
                                                      mawi.base.cls.MMCPickingSvc:prpoInstance:duSuggestedQtyPerDocLine
                                                        (bVU_RA_Pos.VU_RA_Pos_Obj,
                                                         yes))
      ttUV_VersandBeleg.OffeneMenge             = ttUV_VersandBeleg.Menge
                                                  - ttUV_VersandBeleg.gelieferte_Menge
                                                  - ttUV_VersandBeleg.stornierte_Menge
                                                  - ttUV_VersandBeleg.KommMenge
      ttUV_VersandBeleg.uCI_DispatchQty         = bVU_RA_Pos.uCI_DispatchQty
      ttUV_VersandBeleg.uCI_DispatchQtyRemark   = bVU_RA_Pos.uCI_DispatchQtyRemark
      .

    /* VU_RA_Pos is traversed in the order of the Index Abruf1: */
    /* Firma BelegArt ReferenzNr PositionsNr AbrufArt AbrufNr Vorschau AbrufTermin AbrufZeit lfdNr */
    /* For JIT and FAB VU_RA_Pos.AbrufZeit is set so the records are traversed */
    /* in chronological order. For LAB AbrufZeit is empty so the records are   */
    /* traversed by VU_RA_Pos.lfdNr */
    if (ttUV_VersandBeleg.KommMenge > 0
      and ttUV_VersandBeleg.OffeneMenge < 0)
      or ttUV_VersandBeleg.OffeneMenge > 0 then

      find last ttKommMenge
        where ttKommMenge.Firma         = bVU_RA_Pos.Firma
          and ttKommMenge.BelegArt      = bVU_RA_Pos.BelegArt
          and ttKommMenge.ReferenzNr    = bVU_RA_Pos.ReferenzNr
          and ttKommMenge.PositionsNr   = bVU_RA_Pos.PositionsNr
          and ttKommMenge.AbrufArt      = bVU_RA_Pos.AbrufArt
          and ttKommMenge.AbrufNr       = bVU_RA_Pos.AbrufNr
          and ttKommMenge.Vorschau      = bVU_RA_Pos.Vorschau
          and ttKommMenge.VersandTermin = bVU_RA_Pos.VersandTermin
        no-lock no-error.

    if ttUV_VersandBeleg.KommMenge > 0
      and ttUV_VersandBeleg.OffeneMenge < 0 then
    do:
      /* Save the current excess quantity for later release lines since this  */
      /* ttUV_VersandBeleg will be deleted. */
      /* Allow for the unlikely possibility that there is more than one release line */
      /* with an excess picked quantity.  */
      if not available ttKommMenge then
      do:
        create ttKommMenge.
        assign
          ttKommMenge.Firma         = bVU_RA_Pos.Firma
          ttKommMenge.BelegArt      = bVU_RA_Pos.BelegArt
          ttKommMenge.ReferenzNr    = bVU_RA_Pos.ReferenzNr
          ttKommMenge.PositionsNr   = bVU_RA_Pos.PositionsNr
          ttKommMenge.AbrufArt      = bVU_RA_Pos.AbrufArt
          ttKommMenge.AbrufNr       = bVU_RA_Pos.AbrufNr
          ttKommMenge.Vorschau      = bVU_RA_Pos.Vorschau
          ttKommMenge.VersandTermin = bVU_RA_Pos.VersandTermin
        .
        validate ttKommMenge.
      end. /* not available ttKommMenge or ttKommMenge.AbrufZeit <> bVU_RA_Pos.AbrufZeit */

      assign
        dExcess                       = minimum(ttUV_VersandBeleg.KommMenge, - ttUV_VersandBeleg.OffeneMenge)
        ttKommMenge.Menge             = ttKommMenge.Menge + dExcess
        /* These don't really matter since this ttUV_VersandBeleg will be deleted immediately. */
        ttUV_VersandBeleg.KommMenge   = ttUV_VersandBeleg.KommMenge - dExcess
        ttUV_VersandBeleg.OffeneMenge = ttUV_VersandBeleg.OffeneMenge + dExcess
      .

    end. /* if ttUV_VersandBeleg.KommMenge > 0 and ttUV_VersandBeleg.OffeneMenge < 0 */
    else if ttUV_VersandBeleg.OffeneMenge > 0
      /* Check if there is any excess picked quantity from an earlier release line. */
      and available ttKommMenge
        and ttKommMenge.Menge > 0 then
    do:
      assign
        dExcess                       = minimum(ttKommMenge.Menge, ttUV_VersandBeleg.OffeneMenge)
        ttUV_VersandBeleg.KommMenge   = ttUV_VersandBeleg.KommMenge + dExcess
        ttUV_VersandBeleg.OffeneMenge = ttUV_VersandBeleg.OffeneMenge - dExcess
        ttKommMenge.Menge             = ttKommMenge.Menge - dExcess
      .

      if ttKommMenge.Menge <= 0 then /* Cannot be < 0, but just in case... */
        delete ttKommMenge.

    end. /* if ttUV_VersandBeleg.OffeneMenge > 0 and ... */

    if ttUV_VersandBeleg.OffeneMenge <= 0 then
    do:
      delete ttUV_VersandBeleg.
      next Order.
    end.

    find bML_Ort
      where bML_Ort.Firma    = {firma/mlort.fir pACConnectionSvc:prpcCompany}
        and bML_Ort.LagerOrt = bV_BelegPos.LagerOrt
      no-lock no-error.

    assign
      ttUV_VersandBeleg.Lagergruppe = (if available bML_Ort then
                                         bML_Ort.Lagergruppe
                                       else
                                         bV_BelegKopf.Lagergruppe)
      ttUV_VersandBeleg.MRPArea = ttUV_VersandBeleg.Lagergruppe
      .                                   


    run reallocateDemandCoverage in target-procedure (buffer bML_Lagergruppe,
                                                      bS_Artikel.S_Artikel_Obj,
                                                      ttUV_VersandBeleg.Artikel,
                                                      ttUV_VersandBeleg.ArtVar,
                                                      ttUV_VersandBeleg.Lagergruppe,
                                                      bV_BelegKopf.Lagergruppe,
                                                      ?).

    /* coverage status */
    assign
      cMRPDocType = (if ttUV_VersandBeleg.MRPDocType = 'VLA':U then
                       'VUA':U
                     else
                       ttUV_VersandBeleg.MRPDocType)
      ttUV_VersandBeleg.CoverageStatus 
        = mawi.base.cls.MMCMRPLinkSvc:prpoInstance:iCoverageStatusShippingMonitor
            (cMRPDocType,
             ttUV_VersandBeleg.Owning_Obj,
             0)
      .

    if   ttUV_VersandBeleg.CoverageStatus = {&uCI_CoverageStatus_Without}            and pa-filter-lCoverageStatus_Without_var    = no
      or ttUV_VersandBeleg.CoverageStatus = {&uCI_CoverageStatus_Available}          and pa-filter-lCoverageStatus_Available_var  = no
      or ttUV_VersandBeleg.CoverageStatus = {&uCI_CoverageStatus_PartiallyAvailable} and pa-filter-lCoverageStatus_PAvailable_var = no
      or ttUV_VersandBeleg.CoverageStatus = {&uCI_CoverageStatus_Covered}            and pa-filter-lCoverageStatus_Covered_var    = no
      or ttUV_VersandBeleg.CoverageStatus = {&uCI_CoverageStatus_Open}               and pa-filter-lCoverageStatus_Open_var       = no then
    do:
      delete ttUV_VersandBeleg.
      next Order.
    end.

    /* Compute some stuff only if the tt-record can't be deleted anymore. */

    {adm/incl/d__spr00.if
      &Tabelle  = "bS_BrancheSpr"
      &Selekt   = "where bS_BrancheSpr.Firma   = {firma/sbranche.fir pACConnectionSvc:prpcCompany}
                     and bS_BrancheSpr.Branche = bS_Kunde.Branche"
      &Sprache  = "pACConnectionSvc:prpcLanguage"
      &no-error = "no-error"
    }

    {adm/incl/d__spr00.if
      &Tabelle  = "bS_RegionSpr"
      &Selekt   = "where bS_RegionSpr.Firma   = {firma/sregion.fir pACConnectionSvc:prpcCompany}
                     and bS_RegionSpr.Region = bS_Kunde.Region"
      &Sprache  = "pACConnectionSvc:prpcLanguage"
      &no-error = "no-error"
    }

    {adm/incl/d__spr00.if
      &Tabelle  = "bS_ArtikelSpr"
      &Selekt   = "where bS_ArtikelSpr.Firma   = {firma/sartikel.fir pACConnectionSvc:prpcCompany}
                     and bS_ArtikelSpr.Artikel = bV_BelegPos.Artikel"
      &Sprache  = "pACConnectionSvc:prpcLanguage"
    }

    {adm/incl/d__spr00.if
      &Tabelle  = "bS_SparteSpr"
      &Selekt   = "where bS_SparteSpr.Firma   = {firma/ssparte.fir pACConnectionSvc:prpcCompany}
                     and bS_SparteSpr.Sparte  = bS_Artikel.Sparte"
      &Sprache  = "pACConnectionSvc:prpcLanguage"
      &no-error = "no-error"
    }

    find bS_ArtKunde
      where bS_ArtKunde.Firma   = {firma/sartkund.fir pACConnectionSvc:prpcCompany}
        and bS_ArtKunde.Artikel = bS_Artikel.Artikel
        and bS_ArtKunde.Kunde   = bS_Kunde.Kunde
      no-lock no-error.

    {adm/incl/d__spr00.if
      &Tabelle  = "bML_OrtSpr"
      &Selekt   = "where bML_OrtSpr.Firma    = {firma/mlort.fir pACConnectionSvc:prpcCompany}
                     and bML_OrtSpr.Lagerort = bV_BelegPos.KO_LagerOrt"
      &Sprache  = "pACConnectionSvc:prpcLanguage"
      &no-error = "no-error"
    }

    {adm/incl/d__spr00.if
      &Tabelle  = "bML_OrtSpr-StorArea"
      &Selekt   = "where bML_OrtSpr-StorArea.Firma    = {firma/mlort.fir pACConnectionSvc:prpcCompany}
                     and bML_OrtSpr-StorArea.Lagerort = ttUV_VersandBeleg.StorageArea"
      &Sprache  = "pACConnectionSvc:prpcLanguage"
      &no-error = "no-error"
    }

    {adm/incl/d__spr00.if
      &Tabelle  = "bML_LagergruppeSpr"
      &Selekt   = "where bML_LagergruppeSpr.Firma       = {firma/mlort.fir pACConnectionSvc:prpcCompany} 
                     and bML_LagergruppeSpr.Lagergruppe = ttUV_VersandBeleg.MRPArea"
      &Sprache  = "pACConnectionSvc:prpcLanguage"
      &no-error = "no-error"
    }

    {adm/incl/d__spr00.if
      &Tabelle  = "bS_ZahlZielSpr"
      &Selekt   = "where bS_ZahlZielSpr.Firma        = {firma/szahlzie.fir pACConnectionSvc:prpcCompany}
                     and bS_ZahlZielSpr.ZahlungsZiel = ttUV_VersandBeleg.CreditTerms"
      &Sprache  = "pACConnectionSvc:prpcLanguage"
      &no-error = "no-error"
    }

    assign
      ttUV_VersandBeleg.Konto_BrancheBez        = bS_BrancheSpr.Bezeichnung   when available bS_BrancheSpr
      ttUV_VersandBeleg.Konto_RegionBez         = bS_RegionSpr.Bezeichnung    when available bS_RegionSpr
      ttUV_VersandBeleg.AbladestelleBez         = bS_Abladestelle.Bezeichnung when available bS_Abladestelle
      ttUV_VersandBeleg.ArtikelBez              = bS_ArtikelSpr.Bezeichnung
      ttUV_VersandBeleg.ArtikelgruppeBez        = {fnarg
                                                     pa_cDyCchProductLineDesc
                                                     "pACConnectionSvc:prpcCompany,
                                                      bS_Artikel.Artikelgruppe,
                                                      pACConnectionSvc:prpcLanguage"}
      ttUV_VersandBeleg.SparteBez               = bS_SparteSpr.Bezeichnung
      ttUV_VersandBeleg.ArtikelArtBez           = {fnarg
                                                     pa_cStCchPartTypeDesc
                                                     "bS_Artikel.ArtikelArt,
                                                      pACConnectionSvc:prpcLanguage,
                                                      {&pa_CchDesc}"}
      ttUV_VersandBeleg.ArtikelNr               = bS_ArtKunde.ArtikelNr       when available bS_ArtKunde
      ttUV_VersandBeleg.ArtikelNrBez            = bS_ArtKunde.Bezeichnung     when available bS_ArtKunde
      ttUV_VersandBeleg.AuftragsArtBez          = {fnarg
                                                    pa_cDyCchOrderTypeDesc
                                                    "pACConnectionSvc:prpcCompany,
                                                     bV_BelegKopf.AuftragsArt,
                                                     pACConnectionSvc:prpcLanguage"}
      ttUV_VersandBeleg.VersandarBez            = {fnarg
                                                    pa_cDyCchShippingTypeDesc
                                                    "pACConnectionSvc:prpcCompany,
                                                     bV_BelegPos.uCI_Versandart,
                                                     pACConnectionSvc:prpcLanguage"}
      ttUV_VersandBeleg.LieferBedingungBez      = {fnarg
                                                    pa_cDyCchTermsOfDeliveryDesc
                                                    "pACConnectionSvc:prpcCompany,
                                                     bV_BelegPos.LieferBedingung,
                                                     pACConnectionSvc:prpcLanguage"}
      ttUV_VersandBeleg.LieferRestriktBez       = entry(lookup(string(bV_BelegKopf.LieferRestrikt), gcSB_ShipmentRestrictions_keys, '|':U),
                                                        gcSB_ShipmentRestrictions_desc, '|':U)
      ttUV_VersandBeleg.SachbearbeiterName      = {fnarg
                                                    pa_cDyCchUserName
                                                    "bV_BelegKopf.Sachbearbeiter,
                                                     {&pa_CchDesc}"}
      ttUV_VersandBeleg.KO_LagerOrtBez          = bML_OrtSpr.Bezeichnung      when available bML_OrtSpr
      ttUV_VersandBeleg.MengenEinheitKurzBez    = {fnarg
                                                     pa_cDyCchUnitOfMeasureDesc
                                                     "pACConnectionSvc:prpcCompany,
                                                      bV_BelegPos.MengenEinheit,
                                                      pACConnectionSvc:prpcLanguage,
                                                      {&pa_CchShortCut}"}
      ttUV_VersandBeleg.MengenEinheitKurzBezLME = {fnarg
                                                     pa_cDyCchUnitOfMeasureDesc
                                                     "pACConnectionSvc:prpcCompany,
                                                      bS_Artikel.LagerME,
                                                      pACConnectionSvc:prpcLanguage,
                                                      {&pa_CchShortCut}"}
      ttUV_VersandBeleg.StorageArea_Desc        = bML_OrtSpr-StorArea.Bezeichnung                                                 
      ttUV_VersandBeleg.CreditTerms_Desc        = bS_ZahlZielSpr.Bezeichnung                                           
      ttUV_VersandBeleg.MRPArea_desc            = bML_LagergruppeSpr.Bezeichnung                                     
      .

    if available bML_Ort then
      ttUV_VersandBeleg.Bestand  = dGetPhysicalOnHand(buffer bML_Ort,
                                                             bS_Artikel.Artikel,
                                                             ttUV_VersandBeleg.ArtVar,
                                                             bVU_RA_Pos.VU_RA_Pos_Obj).

    /* total values */
    assign
      gdExchangeRate                         = {fnarg
                                                  pa_dCurGetExchangeRate
                                                  "pACConnectionSvc:prpcCompany,
                                                   bV_BelegKopf.Waehrung,
                                                   bV_BelegKopf.Belegdatum,
                                                   string({&pa_V_Kurs}),
                                                   bV_BelegKopf.Kunde,
                                                   bV_BelegKopf.V_BelegKopf_Obj"}
      ttUV_VersandBeleg.GesamtwertOffen      = round(  (  ttUV_VersandBeleg.OffeneMenge
                                                        * bVU_RA_Pos.AE_Preis
                                                        / bV_BelegPos.Preisfaktor) 
                                                     * gdExchangeRate, bV_BelegKopf.WaehrungNK)
      ttUV_VersandBeleg.GesamtwertVerfuegbar = round(  (if ttUV_VersandBeleg.Bestand >= ttUV_VersandBeleg.OffeneMenge then
                                                            ttUV_VersandBeleg.OffeneMenge
                                                          * bVU_RA_Pos.AE_Preis
                                                          / bV_BelegPos.Preisfaktor
                                                        else
                                                            ttUV_VersandBeleg.Bestand
                                                          * bVU_RA_Pos.AE_Preis
                                                          / bV_BelegPos.Preisfaktor) 
                                                     * gdExchangeRate, bV_BelegKopf.WaehrungNK)
      .

    if bVU_RA_Pos.uCI_MessageCode > '':U then
      ttUV_VersandBeleg.Fehlermeldung = cErrortext(bVU_RA_Pos.uCI_MessageCode, bVU_RA_Pos.uCI_MessageSubst).

  end. /* for each bV_BelegKopf ... */

end. /* do for bS_Kunde */

end procedure. /* fillCallSalesOrders */


/* _UIB-CODE-BLOCK-END */
&ANALYZE-RESUME

&ENDIF


&IF DEFINED(EXCLUDE-fillDataset) = 0 &THEN

&ANALYZE-SUSPEND _UIB-CODE-BLOCK _PROCEDURE fillDataset Method-Library 
procedure fillDataset :
/* Description ---------------------------------------------------------------*/
/*                                                                            */
/* Fills the dataset                                                          */
/*                                                                            */
/* Notes ---------------------------------------------------------------------*/
/*                                                                            */
/*                                                                            */
/*                                                                            */
/* Parameters ----------------------------------------------------------------*/
/*                                                                            */
/* <none>                                                                     */
/*                                                                            */
/* Examples ------------------------------------------------------------------*/
/*                                                                            */
/*                                                                            */
/*                                                                            */
/*----------------------------------------------------------------------------*/
define input-output parameter dataset for dsUVR_CIVersandBeleg.

/* Variables -----------------------------------------------------------------*/
/*----------------------------------------------------------------------------*/

/* Buffers -------------------------------------------------------------------*/

/*----------------------------------------------------------------------------*/
/* Processing                                                                 */
/*----------------------------------------------------------------------------*/

if not session:batch-mode
  &IF "{&WINDOW-SYSTEM}" <> "TTY" &THEN
    or adm.method.cls.DMCSkinClientSvc:prplIsSkinClient
  &ENDIF
  then
  {fn
     pa_lUISvcSetWaitState} no-error.

assign
  pa-filter-Konto_min                       = adm.method.cls.DMCSessionSvc:iGetObjectProperty(dataset dsUVR_CIVersandBeleg:handle, 'Konto_min':U                     )
  pa-filter-Konto_max                       = adm.method.cls.DMCSessionSvc:iGetObjectProperty(dataset dsUVR_CIVersandBeleg:handle, 'Konto_max':U                     )
  pa-filter-Artikel_min                     = adm.method.cls.DMCSessionSvc:cGetObjectProperty(dataset dsUVR_CIVersandBeleg:handle, 'Artikel_min':U                   )
  pa-filter-Artikel_max                     = adm.method.cls.DMCSessionSvc:cGetObjectProperty(dataset dsUVR_CIVersandBeleg:handle, 'Artikel_max':U                   )
  pa-filter-ArtikelGruppe_min               = adm.method.cls.DMCSessionSvc:cGetObjectProperty(dataset dsUVR_CIVersandBeleg:handle, 'ArtikelGruppe_min':U             )
  pa-filter-ArtikelGruppe_max               = adm.method.cls.DMCSessionSvc:cGetObjectProperty(dataset dsUVR_CIVersandBeleg:handle, 'ArtikelGruppe_max':U             )
  pa-filter-Sparte_min                      = adm.method.cls.DMCSessionSvc:cGetObjectProperty(dataset dsUVR_CIVersandBeleg:handle, 'Sparte_min':U                    )
  pa-filter-Sparte_max                      = adm.method.cls.DMCSessionSvc:cGetObjectProperty(dataset dsUVR_CIVersandBeleg:handle, 'Sparte_max':U                    )
  pa-filter-ArtikelArt_min                  = adm.method.cls.DMCSessionSvc:iGetObjectProperty(dataset dsUVR_CIVersandBeleg:handle, 'ArtikelArt_min':U                )
  pa-filter-ArtikelArt_max                  = adm.method.cls.DMCSessionSvc:iGetObjectProperty(dataset dsUVR_CIVersandBeleg:handle, 'ArtikelArt_max':U                )
  pa-filter-Wunschtermin_min                = adm.method.cls.DMCSessionSvc:tGetObjectProperty(dataset dsUVR_CIVersandBeleg:handle, 'Wunschtermin_min':U              )
  pa-filter-Wunschtermin_max                = adm.method.cls.DMCSessionSvc:tGetObjectProperty(dataset dsUVR_CIVersandBeleg:handle, 'Wunschtermin_max':U              )
  pa-filter-Liefertermin_min                = adm.method.cls.DMCSessionSvc:tGetObjectProperty(dataset dsUVR_CIVersandBeleg:handle, 'Liefertermin_min':U              )
  pa-filter-Liefertermin_max                = adm.method.cls.DMCSessionSvc:tGetObjectProperty(dataset dsUVR_CIVersandBeleg:handle, 'Liefertermin_max':U              )
  pa-filter-uCI_Warenausgangst_min          = adm.method.cls.DMCSessionSvc:tGetObjectProperty(dataset dsUVR_CIVersandBeleg:handle, 'uCI_Warenausgangst_min':U        )
  pa-filter-uCI_Warenausgangst_max          = adm.method.cls.DMCSessionSvc:tGetObjectProperty(dataset dsUVR_CIVersandBeleg:handle, 'uCI_Warenausgangst_max':U        )
  pa-filter-Versandtermin_min               = adm.method.cls.DMCSessionSvc:tGetObjectProperty(dataset dsUVR_CIVersandBeleg:handle, 'Versandtermin_min':U             )
  pa-filter-Versandtermin_max               = adm.method.cls.DMCSessionSvc:tGetObjectProperty(dataset dsUVR_CIVersandBeleg:handle, 'Versandtermin_max':U             )
  pa-filter-BelegNummer_min                 = adm.method.cls.DMCSessionSvc:iGetObjectProperty(dataset dsUVR_CIVersandBeleg:handle, 'BelegNummer_min':U               )
  pa-filter-BelegNummer_max                 = adm.method.cls.DMCSessionSvc:iGetObjectProperty(dataset dsUVR_CIVersandBeleg:handle, 'BelegNummer_max':U               )
  pa-filter-Sachbearbeiter_min              = adm.method.cls.DMCSessionSvc:cGetObjectProperty(dataset dsUVR_CIVersandBeleg:handle, 'Sachbearbeiter_min':U            )
  pa-filter-Sachbearbeiter_max              = adm.method.cls.DMCSessionSvc:cGetObjectProperty(dataset dsUVR_CIVersandBeleg:handle, 'Sachbearbeiter_max':U            )
  pa-filter-AuftragsArt_min                 = adm.method.cls.DMCSessionSvc:cGetObjectProperty(dataset dsUVR_CIVersandBeleg:handle, 'AuftragsArt_min':U               )
  pa-filter-AuftragsArt_max                 = adm.method.cls.DMCSessionSvc:cGetObjectProperty(dataset dsUVR_CIVersandBeleg:handle, 'AuftragsArt_max':U               )
  pa-filter-LieferAdresse_min               = adm.method.cls.DMCSessionSvc:iGetObjectProperty(dataset dsUVR_CIVersandBeleg:handle, 'LieferAdresse_min':U             )
  pa-filter-LieferAdresse_max               = adm.method.cls.DMCSessionSvc:iGetObjectProperty(dataset dsUVR_CIVersandBeleg:handle, 'LieferAdresse_max':U             )
  pa-filter-AdressKennung_min               = adm.method.cls.DMCSessionSvc:cGetObjectProperty(dataset dsUVR_CIVersandBeleg:handle, 'AdressKennung_min':U             )
  pa-filter-AdressKennung_max               = adm.method.cls.DMCSessionSvc:cGetObjectProperty(dataset dsUVR_CIVersandBeleg:handle, 'AdressKennung_max':U             )
  pa-filter-Abladestelle_min                = adm.method.cls.DMCSessionSvc:cGetObjectProperty(dataset dsUVR_CIVersandBeleg:handle, 'Abladestelle_min':U              )
  pa-filter-Abladestelle_max                = adm.method.cls.DMCSessionSvc:cGetObjectProperty(dataset dsUVR_CIVersandBeleg:handle, 'Abladestelle_max':U              )
  pa-filter-uCI_LagerortKunde_min           = adm.method.cls.DMCSessionSvc:cGetObjectProperty(dataset dsUVR_CIVersandBeleg:handle, 'uCI_LagerortKunde_min':U         )
  pa-filter-uCI_LagerortKunde_max           = adm.method.cls.DMCSessionSvc:cGetObjectProperty(dataset dsUVR_CIVersandBeleg:handle, 'uCI_LagerortKunde_max':U         )
  pa-filter-VersandArt_min                  = adm.method.cls.DMCSessionSvc:iGetObjectProperty(dataset dsUVR_CIVersandBeleg:handle, 'VersandArt_min':U                )
  pa-filter-VersandArt_max                  = adm.method.cls.DMCSessionSvc:iGetObjectProperty(dataset dsUVR_CIVersandBeleg:handle, 'VersandArt_max':U                )
  pa-filter-LieferBedingung_min             = adm.method.cls.DMCSessionSvc:iGetObjectProperty(dataset dsUVR_CIVersandBeleg:handle, 'LieferBedingung_min':U           )
  pa-filter-LieferBedingung_max             = adm.method.cls.DMCSessionSvc:iGetObjectProperty(dataset dsUVR_CIVersandBeleg:handle, 'LieferBedingung_max':U           )
  pa-filter-Lieferant_min                   = adm.method.cls.DMCSessionSvc:iGetObjectProperty(dataset dsUVR_CIVersandBeleg:handle, 'Lieferant_min':U                 )
  pa-filter-Lieferant_max                   = adm.method.cls.DMCSessionSvc:iGetObjectProperty(dataset dsUVR_CIVersandBeleg:handle, 'Lieferant_max':U                 )
  pa-filter-iMRPRelease_var                 = adm.method.cls.DMCSessionSvc:iGetObjectProperty(dataset dsUVR_CIVersandBeleg:handle, 'iMRPRelease_var':U               )
  pa-filter-lPastOrderLines_var             = adm.method.cls.DMCSessionSvc:lGetObjectProperty(dataset dsUVR_CIVersandBeleg:handle, 'lPastOrderLines_var':U           )
  pa-filter-lTodayOrderLines_var            = adm.method.cls.DMCSessionSvc:lGetObjectProperty(dataset dsUVR_CIVersandBeleg:handle, 'lTodayOrderLines_var':U          )
  pa-filter-lFutureOrderLines_var           = adm.method.cls.DMCSessionSvc:lGetObjectProperty(dataset dsUVR_CIVersandBeleg:handle, 'lFutureOrderLines_var':U         )
  pa-filter-iBezugsdatum_var                = adm.method.cls.DMCSessionSvc:iGetObjectProperty(dataset dsUVR_CIVersandBeleg:handle, 'iBezugsdatum_var':U              )
  pa-filter-iHorizont_var                   = adm.method.cls.DMCSessionSvc:iGetObjectProperty(dataset dsUVR_CIVersandBeleg:handle, 'iHorizont_var':U                 )
  pa-filter-lBelegartU_var                  = adm.method.cls.DMCSessionSvc:lGetObjectProperty(dataset dsUVR_CIVersandBeleg:handle, 'lBelegartU_var':U                )
  pa-filter-lBelegartVUA_var                = adm.method.cls.DMCSessionSvc:lGetObjectProperty(dataset dsUVR_CIVersandBeleg:handle, 'lBelegartVUA_var':U              )
  &IF LOOKUP("VS","{&PA-MODULE}") > 0 &THEN  
    pa-filter-lDocTypeServiceOrder_var               = adm.method.cls.DMCSessionSvc:lGetObjectProperty(dataset dsUVR_CIVersandBeleg:handle, 'lDocTypeServiceOrder_var':U  )
    pa-filter-lDocTypeRepairOrder_var                = adm.method.cls.DMCSessionSvc:lGetObjectProperty(dataset dsUVR_CIVersandBeleg:handle, 'lDocTypeRepairOrder_var':U   )
  &ENDIF
  pa-filter-lBelegartPPF_var                = adm.method.cls.DMCSessionSvc:lGetObjectProperty(dataset dsUVR_CIVersandBeleg:handle, 'lBelegartPPF_var':U              )
  pa-filter-lCoverageStatus_Without_var     = adm.method.cls.DMCSessionSvc:lGetObjectProperty(dataset dsUVR_CIVersandBeleg:handle, 'lCoverageStatus_Without_var':U   )
  pa-filter-lCoverageStatus_Available_var   = adm.method.cls.DMCSessionSvc:lGetObjectProperty(dataset dsUVR_CIVersandBeleg:handle, 'lCoverageStatus_Available_var':U )
  pa-filter-lCoverageStatus_PAvailable_var  = adm.method.cls.DMCSessionSvc:lGetObjectProperty(dataset dsUVR_CIVersandBeleg:handle, 'lCoverageStatus_PAvailable_var':U)
  pa-filter-lCoverageStatus_Covered_var     = adm.method.cls.DMCSessionSvc:lGetObjectProperty(dataset dsUVR_CIVersandBeleg:handle, 'lCoverageStatus_Covered_var':U   )
  pa-filter-lCoverageStatus_Open_var        = adm.method.cls.DMCSessionSvc:lGetObjectProperty(dataset dsUVR_CIVersandBeleg:handle, 'lCoverageStatus_Open_var':U      )
  pa-filter-StorageArea_min                 = adm.method.cls.DMCSessionSvc:iGetObjectProperty(dataset dsUVR_CIVersandBeleg:handle, 'StorageArea_min':U               )         
  pa-filter-StorageArea_max                 = adm.method.cls.DMCSessionSvc:iGetObjectProperty(dataset dsUVR_CIVersandBeleg:handle, 'StorageArea_max':U               )
  pa-filter-CreditTerms_min                 = adm.method.cls.DMCSessionSvc:iGetObjectProperty(dataset dsUVR_CIVersandBeleg:handle, 'CreditTerms_min':U               )
  pa-filter-CreditTerms_max                 = adm.method.cls.DMCSessionSvc:iGetObjectProperty(dataset dsUVR_CIVersandBeleg:handle, 'CreditTerms_max':U               )
  pa-filter-DeliveryRestriction_min         = adm.method.cls.DMCSessionSvc:iGetObjectProperty(dataset dsUVR_CIVersandBeleg:handle, 'DeliveryRestriction_min':U       )
  pa-filter-DeliveryRestriction_max         = adm.method.cls.DMCSessionSvc:iGetObjectProperty(dataset dsUVR_CIVersandBeleg:handle, 'DeliveryRestriction_max':U       )
  pa-filter-MRPArea_min                     = adm.method.cls.DMCSessionSvc:iGetObjectProperty(dataset dsUVR_CIVersandBeleg:handle, 'MRPArea_min':U                   )
  pa-filter-MRPArea_max                     = adm.method.cls.DMCSessionSvc:iGetObjectProperty(dataset dsUVR_CIVersandBeleg:handle, 'MRPArea_max':U                   )
  /* --> MO#HIDR-AH4-1123 thongdi_p 20.07.2026 Erweiterung Versandmonitor im Feld Best. Termin */
  pa-filter-xEbLiefertermin_min             = adm.method.cls.DMCSessionSvc:tGetObjectProperty(dataset dsUVR_CIVersandBeleg:handle, 'xEbLiefertermin_min':U).
  pa-filter-xEbLiefertermin_max             = adm.method.cls.DMCSessionSvc:tGetObjectProperty(dataset dsUVR_CIVersandBeleg:handle, 'xEbLiefertermin_max':U).
  /* <-- MO#HIDR-AH4-1123 thongdi_p 20.07.2026 Erweiterung Versandmonitor im Feld Best. Termin */
  .

empty temp-table ttBestandKommzone.

empty temp-table ttOnHandStorageArea.

empty temp-table ttUV_LockStatus.

empty temp-table ttUV_DunningLevel.

assign
  gcSB_ShipmentRestrictions_desc     = adm.config.cls.DCCAppConfigSvc:prpoInstance:cParameterValue
                                         ('SB_ShipmentRestrictions_desc':U, '|':U)
  gcSB_ShipmentRestrictions_keys     = adm.config.cls.DCCAppConfigSvc:prpoInstance:cParameterValue
                                         ('SB_ShipmentRestrictions_keys':U, '|':U)
  glUCI_ReservationsInOnhand         = adm.config.cls.DCCAppConfigSvc:prpoInstance:lParameterValue
                                         ('UCI_ReservationsInOnhand':U)
  glMM_PickSafetyStock               = adm.config.cls.DCCAppConfigSvc:prpoInstance:lParameterValue
                                         ('MM_PickSafetyStock':U)
  glUCI_ShippingMonitorReallocateAll = adm.config.cls.DCCAppConfigSvc:prpoInstance:lParameterValue
                                         ('UCI_ShippingMonitorReallocateAll':U)
.

empty temp-table ttArtikelVerwendungspruefung.

goSchedPegging = mawi.base.cls.MMCSchedPeggingSvo:create().

if pa-filter-lBelegartU_var then
  run fillOrders in target-procedure.

if pa-filter-lBelegartVUA_var then
  run fillCallSalesOrders in target-procedure.
  
&IF LOOKUP("VS","{&PA-MODULE}") > 0 &THEN
  if pa-filter-lDocTypeServiceOrder_var then
    run fillServiceOrderMKT in target-procedure.
  
  if pa-filter-lDocTypeRepairOrder_var then 
    run fillRepairOrderLine in target-procedure.  
&ENDIF    

finally:

  empty temp-table ttBestandKommzone.

  empty temp-table ttOnHandStorageArea.

  empty temp-table ttUV_LockStatus.

  empty temp-table ttUV_DunningLevel.
  
  &IF LOOKUP("VS","{&PA-MODULE}") > 0 &THEN
    empty temp-table ttGenerateDemandQtyForService. 
  &ENDIF 
  if not session:batch-mode
    &IF "{&WINDOW-SYSTEM}" <> "TTY" &THEN
      or adm.method.cls.DMCSkinClientSvc:prplIsSkinClient
    &ENDIF
    then
    {fn
       pa_lUISvcResetWaitState} no-error.
end.

end procedure. /* fillDataset */


/* _UIB-CODE-BLOCK-END */
&ANALYZE-RESUME

&ENDIF

&IF DEFINED(EXCLUDE-fillOrders) = 0 &THEN

&ANALYZE-SUSPEND _UIB-CODE-BLOCK _PROCEDURE fillOrders Method-Library 
procedure fillOrders :
/* Description ---------------------------------------------------------------*/
/*                                                                            */
/* Fills the dataset with orders                                              */
/*                                                                            */
/* Notes ---------------------------------------------------------------------*/
/*                                                                            */
/*                                                                            */
/*                                                                            */
/* Parameters ----------------------------------------------------------------*/
/*                                                                            */
/* <none>                                                                     */
/*                                                                            */
/* Examples ------------------------------------------------------------------*/
/*                                                                            */
/*                                                                            */
/*                                                                            */
/*----------------------------------------------------------------------------*/

/* Variables -----------------------------------------------------------------*/
/*----------------------------------------------------------------------------*/

define variable iLieferant        like S_Lieferant.Lieferant            no-undo.
define variable cDummy            as character                          no-undo.
define variable iDummy            as integer                            no-undo.
define variable cBelegartBez      as character                          no-undo.
define variable iCoverageStatus   like ttUV_VersandBeleg.CoverageStatus no-undo.
define variable cTargetArea       as character                          no-undo.

/* Buffers -------------------------------------------------------------------*/

define buffer bV_BelegKopf             for V_BelegKopf.
define buffer bV_BelegPos              for V_BelegPos.
define buffer bV_BelegStueli           for V_BelegStueli.
define buffer bS_Kunde                 for S_Kunde.
define buffer bS_Adresse-Kunde         for S_Adresse.
define buffer bS_BrancheSpr            for S_BrancheSpr.
define buffer bS_RegionSpr             for S_RegionSpr.
define buffer bS_Artikel               for S_Artikel.
define buffer bS_ArtikelSpr            for S_ArtikelSpr.
define buffer bS_SparteSpr             for S_SparteSpr.
define buffer bS_ArtKunde              for S_ArtKunde.
define buffer bS_Lieferant             for S_Lieferant.
define buffer bS_Adresse-Lief          for S_Adresse.
define buffer bV_BelegKopfAdr          for V_BelegKopfAdr.
define buffer bV_BelegKopfAdr-K        for V_BelegKopfAdr.
define buffer bS_Lieferadresse         for S_Lieferadresse.
define buffer bS_Adresse-LiefAdr       for S_Adresse.
define buffer bML_Ort                  for ML_Ort.
define buffer bML_OrtSpr               for ML_OrtSpr.
define buffer bML_Lagergruppe          for ML_Lagergruppe.
define buffer bML_OrtSpr-StorArea      for ML_OrtSpr.
define buffer bML_LagergruppeSpr       for ML_LagergruppeSpr.
define buffer bS_ZahlZielSpr           for S_ZahlZielSpr.

/*----------------------------------------------------------------------------*/
/* Processing                                                                 */
/*----------------------------------------------------------------------------*/

/* filter on fields that doesn't exist in orders */
if   pa-filter-Abladestelle_min       > '':U
  or pa-filter-uCI_LagerortKunde_min  > '':U then
  return.

cBelegartBez = {fnarg
                 pa_cStCchDocTypeDesc
                 "'U':U,
                  pACConnectionSvc:prpcLanguage,
                  {&pa_CchDesc}"}.

do for bS_Kunde,bML_Lagergruppe:

  Order:
  for each bV_BelegPos
    where bV_BelegPos.Firma                      = {firma/vbelegko.fir pACConnectionSvc:prpcCompany}
      and bV_BelegPos.BelegArt                   = 'U':U
      and bV_BelegPos.offen                      = yes
      and bV_BelegPos.Artikel                    >= pa-filter-Artikel_min
      and bV_BelegPos.Artikel                    <= pa-filter-Artikel_max
      and bV_BelegPos.Satzart                    = 'A':U
      and bV_BelegPos.WertPosition               = no
      and bV_BelegPos.BelegNummer               >= pa-filter-BelegNummer_min
      and bV_BelegPos.BelegNummer               <= pa-filter-BelegNummer_max
      and ((bV_BelegPos.uCI_Versandart          >= pa-filter-VersandArt_min
        and bV_BelegPos.uCI_Versandart          <= pa-filter-VersandArt_max)
         or bV_BelegPos.uCI_Versandart          = ?)
      and bV_BelegPos.LieferBedingung           >= pa-filter-LieferBedingung_min
      and bV_BelegPos.LieferBedingung           <= pa-filter-LieferBedingung_max
      and bV_BelegPos.Wunschtermin              >= pa-filter-Wunschtermin_min
      and bV_BelegPos.Wunschtermin              <= pa-filter-Wunschtermin_max
      and ((bV_BelegPos.Liefertermin            >= pa-filter-Liefertermin_min
        and bV_BelegPos.Liefertermin            <= pa-filter-Liefertermin_max)
         or  (bV_BelegPos.Liefertermin           = ?
          and pa-filter-Liefertermin_min         = {&PA_DATEMIN}))
      and bV_BelegPos.uCI_Warenausgangstermin >= pa-filter-uCI_Warenausgangst_min
      and bV_BelegPos.uCI_Warenausgangstermin <= pa-filter-uCI_Warenausgangst_max
      and bV_BelegPos.Versandtermin           >= pa-filter-Versandtermin_min
      and bV_BelegPos.Versandtermin           <= pa-filter-Versandtermin_max
    no-lock
    on error undo, throw:

    if bV_BelegPos.uCI_Vertriebsweg = {&uCI_VertriebswegStrecke} then
      next Order.

    find bS_Artikel
      where bS_Artikel.Firma          = {firma/sartikel.fir pACConnectionSvc:prpcCompany}
        and bS_Artikel.Artikel        = bV_BelegPos.Artikel
        and bS_Artikel.ArtikelGruppe >= pa-filter-ArtikelGruppe_min
        and bS_Artikel.ArtikelGruppe <= pa-filter-ArtikelGruppe_max
        and bS_Artikel.Sparte        >= pa-filter-Sparte_min
        and bS_Artikel.Sparte        <= pa-filter-Sparte_max
        and bS_Artikel.ArtikelArt    >= pa-filter-ArtikelArt_min
        and bS_Artikel.ArtikelArt    <= pa-filter-ArtikelArt_max
      no-lock no-error.

    if not available bS_Artikel then
      next Order.

    if not can-do({&pa_S_PTList_Set}, string(bS_Artikel.ArtikelArt))
      and not(    bV_BelegPos.LagerOrt       >= pa-filter-StorageArea_min
              and bV_BelegPos.LagerOrt       <= pa-filter-StorageArea_max) then
      next Order.

    /* check conditions */

    case pa-filter-iMRPRelease_var:

      when 1 then /* yes */
        if bV_BelegPos.MRPRelease = no then
          next Order.

      when 2 then /* no */
        if bV_BelegPos.MRPRelease = yes then
          next Order.

    end case. /* pa-filter-iMRPRelease_var */

    case pa-filter-iBezugsdatum_var:

      when 1 then gtBezugsdatum = bV_BelegPos.Wunschtermin.
      when 2 then gtBezugsdatum = bV_BelegPos.Liefertermin.
      when 3 then gtBezugsdatum = bV_BelegPos.uCI_Warenausgangstermin.
      when 4 then gtBezugsdatum = bV_BelegPos.Versandtermin.
      /* --> MO#HIDR-AH4-1123 thongdi_p 20.07.2026 Erweiterung Versandmonitor im Feld Best. Termin */
      when 5 then gtBezugsdatum = basis.base.cls.BMCAddDataSvc:tValue
                                  (bV_BelegPos.V_BelegPos_Obj,
                                   'xEbLiefertermin':U).
      /* <-- MO#HIDR-AH4-1123 thongdi_p 20.07.2026 Erweiterung Versandmonitor im Feld Best. Termin */                             
    end case. /* pa-filter-iBezugsdatum_var */

    if not pa-filter-lPastOrderLines_var  
      and gtBezugsdatum < today then
      next Order.

    if not pa-filter-lTodayOrderLines_var  
      and gtBezugsdatum = today then 
      next Order.

    if not pa-filter-lFutureOrderLines_var  
      and gtBezugsdatum >  today  then
      next Order.
    else
      if gtBezugsdatum >  today + pa-filter-iHorizont_var then 
        next Order.


    /* load data and check conditions */
    find bV_BelegKopf
      where bV_BelegKopf.Firma           = bV_BelegPos.Firma
        and bV_BelegKopf.BelegArt        = bV_BelegPos.BelegArt
        and bV_BelegKopf.ReferenzNr      = bV_BelegPos.ReferenzNr
        and bV_BelegKopf.Kunde          >= pa-filter-Konto_min
        and bV_BelegKopf.Kunde          <= pa-filter-Konto_max
        and bV_BelegKopf.Sachbearbeiter >= pa-filter-Sachbearbeiter_min
        and bV_BelegKopf.Sachbearbeiter <= pa-filter-Sachbearbeiter_max
        and bV_BelegKopf.AuftragsArt    >= pa-filter-AuftragsArt_min
        and bV_BelegKopf.AuftragsArt    <= pa-filter-AuftragsArt_max
        and bV_Belegkopf.ZahlungsZiel   >= pa-filter-CreditTerms_min
        and bV_Belegkopf.ZahlungsZiel   <= pa-filter-CreditTerms_max
        and bV_BelegKopf.LieferRestrikt >= pa-filter-DeliveryRestriction_min
        and bV_BelegKopf.LieferRestrikt <= pa-filter-DeliveryRestriction_max
      no-lock no-error.

    if not available bV_BelegKopf then
      next Order.


    find bML_Ort
      where bML_Ort.Firma    = {firma/mlort.fir pACConnectionSvc:prpcCompany}
        and bML_Ort.LagerOrt = bV_BelegPos.LagerOrt
      no-lock no-error.

    if available bML_Ort then
    do:
      if not(    bML_Ort.Lagergruppe >= pa-filter-MRPArea_min
             and bML_Ort.Lagergruppe <= pa-filter-MRPArea_max) then 
        next Order.
    end.
    else
      if not(    bV_BelegKopf.Lagergruppe >= pa-filter-MRPArea_min
             and bV_BelegKopf.Lagergruppe <= pa-filter-MRPArea_max) then 
      next Order.


    if not can-do({&pa_S_PTList_Set}, string(bS_Artikel.ArtikelArt))
      and bV_BelegPos.Lagerort = ? then
      next Order.

    if not available bS_Kunde
      or bS_Kunde.Kunde <> bV_BelegKopf.Kunde then

      find bS_Kunde
        where bS_Kunde.Firma = {firma/s_kunde.fir pACConnectionSvc:prpcCompany}
          and bS_Kunde.Kunde = bV_BelegKopf.Kunde
        no-lock.

    release bS_Adresse-Kunde.

    find bV_BelegKopfAdr-K
      where bV_BelegKopfAdr-K.Firma      = bV_BelegKopf.Firma
        and bV_BelegKopfAdr-K.Belegart   = bV_BelegKopf.Belegart
        and bV_BelegKopfAdr-K.ReferenzNr = bV_BelegKopf.ReferenzNr
        and bV_BelegKopfAdr-K.Typ        = 'K':U
      no-lock no-error.
    
    if available bV_BelegKopfAdr-K then
    do:
      if bV_BelegKopfAdr-K.AdressNr <> ? then
      do:
        find bS_Adresse-Kunde
          where bS_Adresse-Kunde.Firma    = {firma/s_adres.fir pACConnectionSvc:prpcCompany}
            and bS_Adresse-Kunde.AdressNr = bV_BelegKopfAdr-K.AdressNr
          no-lock no-error.
      end.
    end.

    if not available bS_Adresse-Kunde then
      find bS_Adresse-Kunde
        where bS_Adresse-Kunde.Firma    = {firma/s_adres.fir pACConnectionSvc:prpcCompany}
          and bS_Adresse-Kunde.AdressNr = bS_Kunde.AdressNr
        no-lock.

    find bS_Lieferant
      where bS_Lieferant.Firma     = {firma/sliefera.fir pACConnectionSvc:prpcCompany}
        and bS_Lieferant.Lieferant = bV_BelegKopf.Lieferant
      no-lock no-error.

    if bV_Belegpos.KO_Lagerort = ? then
      cTargetArea = 'VUL':U.
    else
      cTargetArea = 'MLL':U.

    /* create TT record */
    create ttUV_VersandBeleg.
    assign
      ttUV_VersandBeleg.Konto                   = bS_Kunde.Kunde
      ttUV_VersandBeleg.Konto_Name1             = bS_Adresse-Kunde.Name1
      ttUV_VersandBeleg.Konto_Name2             = bS_Adresse-Kunde.Name2
      ttUV_VersandBeleg.Konto_Name3             = bS_Adresse-Kunde.Name3
      ttUV_VersandBeleg.Konto_Suchbegriff       = bS_Kunde.Suchbegriff
      ttUV_VersandBeleg.Konto_Selektion         = bS_Kunde.Selektion
      ttUV_VersandBeleg.Konto_Branche           = bS_Kunde.Branche
      ttUV_VersandBeleg.Konto_Region            = bS_Kunde.Region
      ttUV_VersandBeleg.Belegart                = bV_BelegKopf.BelegArt
      ttUV_VersandBeleg.BelegartBez             = cBelegartBez
      ttUV_VersandBeleg.BelegNummer             = bV_BelegKopf.BelegNummer
      ttUV_VersandBeleg.PositionsNr             = bV_BelegPos.PositionsNr
      ttUV_VersandBeleg.BelegInfo               = bV_BelegKopf.BelegInfo
      ttUV_VersandBeleg.uCI_Sammellieferschein  = bV_BelegKopf.uCI_Sammellieferschein
      ttUV_VersandBeleg.Artikel                 = bS_Artikel.Artikel
      ttUV_VersandBeleg.ArtVar                  = bV_BelegPos.ArtVar
      ttUV_VersandBeleg.Artikelgruppe           = bS_Artikel.Artikelgruppe
      ttUV_VersandBeleg.Sparte                  = bS_Artikel.Sparte
      ttUV_VersandBeleg.Artikel_Selektion       = bS_Artikel.Selektion
      ttUV_VersandBeleg.Artikel_Suchbegriff     = bS_Artikel.Suchbegriff
      ttUV_VersandBeleg.ArtikelArt              = bS_Artikel.ArtikelArt
      ttUV_VersandBeleg.Wunschtermin            = bV_BelegPos.Wunschtermin
      ttUV_VersandBeleg.Liefertermin            = bV_BelegPos.Liefertermin
      /* --> MO#HIDR-AH4-1123 thongdi_p 20.07.2026 Erweiterung Versandmonitor im Feld Best. Termin */
      ttUV_VersandBeleg.xEbLiefertermin         = basis.base.cls.BMCAddDataSvc:tValue
                                                    (bV_BelegPos.V_BelegPos_Obj,
                                                     'xEbLiefertermin':U)
      /* <-- MO#HIDR-AH4-1123 thongdi_p 20.07.2026 Erweiterung Versandmonitor im Feld Best. Termin */                                               
      ttUV_VersandBeleg.Transportzeit           = bV_BelegPos.Transportzeit
      ttUV_VersandBeleg.Zeiteinheit             = bV_BelegPos.Zeiteinheit
      ttUV_VersandBeleg.uCI_Warenausgangstermin = bV_BelegPos.uCI_Warenausgangstermin
      ttUV_VersandBeleg.uCI_KommZeit            = bV_BelegPos.uCI_KommZeit
      ttUV_VersandBeleg.uCI_KommZeiteinheit     = bV_BelegPos.uCI_KommZeiteinheit
      ttUV_VersandBeleg.Versandtermin           = bV_BelegPos.Versandtermin
      ttUV_VersandBeleg.AuftragsArt             = bV_BelegKopf.AuftragsArt
      ttUV_VersandBeleg.Versandart              = bV_BelegPos.uCI_Versandart
      ttUV_VersandBeleg.LieferBedingung         = bV_BelegPos.LieferBedingung
      ttUV_VersandBeleg.LieferRestrikt          = bV_BelegKopf.LieferRestrikt
      ttUV_VersandBeleg.Sachbearbeiter          = bV_BelegKopf.Sachbearbeiter
      ttUV_VersandBeleg.KO_LagerOrt             = bV_BelegPos.KO_LagerOrt
      ttUV_VersandBeleg.MengenEinheit           = bV_BelegPos.MengenEinheit
      ttUV_VersandBeleg.VME_Faktor              = bV_BelegPos.VME_Faktor
      ttUV_VersandBeleg.MRPRelease              = bV_BelegPos.MRPRelease
      ttUV_VersandBeleg.Owning_Obj              = bV_BelegPos.V_BelegPos_Obj
      ttUV_VersandBeleg.V_BelegPos_Obj          = bV_BelegPos.V_BelegPos_Obj
      ttUV_VersandBeleg.ReferenzNr              = bV_BelegKopf.ReferenzNr
      ttUV_VersandBeleg.MRPDocType              = bV_BelegKopf.BelegArt
      ttUV_VersandBeleg.Nachkomma               = bV_BelegPos.Nachkomma
      ttUV_VersandBeleg.WaehrungNK              = bV_BelegKopf.WaehrungNK
      ttUV_VersandBeleg.StorageArea             = bV_BelegPos.LagerOrt
      ttUV_VersandBeleg.CreditTerms             = bV_BelegKopf.ZahlungsZiel
      ttUV_VersandBeleg.LocklevelOriginLSLSL    
        = cSetLocklevelValue(bV_BelegKopf.V_BelegKopf_Obj,                  
                             cTargetArea) when available bV_BelegKopf
      ttUV_VersandBeleg.LocklevelOriginMMP     
        = cSetLocklevelValue(bV_BelegKopf.V_BelegKopf_Obj,                  
                             'MMP':U) when available bV_BelegKopf
      ttUV_VersandBeleg.LocklevelPartLSLSL      
        = cSetLocklevelValue(bS_Artikel.S_Artikel_Obj,                  
                             cTargetArea) when available bS_Artikel       
      ttUV_VersandBeleg.LocklevelPartMMP        
        = cSetLocklevelValue(bS_Artikel.S_Artikel_Obj,                  
                             'MMP':U) when available bS_Artikel        
      ttUV_VersandBeleg.LocklevelCustomerLSLSL  
        = cSetLocklevelValue(bS_Kunde.S_Kunde_Obj,                  
                             cTargetArea) when available bS_Kunde      
      ttUV_VersandBeleg.LocklevelCustomerMMP    
        = cSetLocklevelValue(bS_Kunde.S_Kunde_Obj,                  
                             'MMP':U) when available bS_Kunde   
      ttUV_VersandBeleg.LocklevelCarrierLSL
        = cSetLocklevelValue(bS_Lieferant.S_Lieferant_Obj,
                             'MLL':U) when available bS_Lieferant
      ttUV_VersandBeleg.LocklevelCarrierVSD
        = cSetLocklevelValue(bS_Lieferant.S_Lieferant_Obj,
                             'VSD':U) when available bS_Lieferant
      ttUV_VersandBeleg.Mahnstufe
        = iDunningLevel(bS_Kunde.Kunde) when available bS_Kunde
      .
    
    /* --> MO#HIDR-AH4-1123 thongdi_p 20.07.2026 Erweiterung Versandmonitor im Feld Best. Termin */
    ttUV_VersandBeleg.xEbLiefertermin = basis.base.cls.BMCAddDataSvc:tValue
                                        (bV_BelegPos.V_BelegPos_Obj,
                                         'xEbLiefertermin':U).
                                         
    if pa-filter-xEbLiefertermin_min <> ? then
    do:
      if   ttUV_VersandBeleg.xEbLiefertermin = ?
        or ttUV_VersandBeleg.xEbLiefertermin < pa-filter-xEbLiefertermin_min
        or ttUV_VersandBeleg.xEbLiefertermin > pa-filter-xEbLiefertermin_max then
      do:
        delete ttUV_VersandBeleg.
        next Order.
      end.
    end.
    /* <-- MO#HIDR-AH4-1123 thongdi_p 20.07.2026 Erweiterung Versandmonitor im Feld Best. Termin */
    
    if available bV_BelegKopfAdr-K
      and bV_BelegKopfAdr-K.AdressNr = ? then
      assign
        ttUV_VersandBeleg.Konto_Name1 = bV_BelegKopfAdr-K.Name1
        ttUV_VersandBeleg.Konto_Name2 = bV_BelegKopfAdr-K.Name2
        ttUV_VersandBeleg.Konto_Name3 = bV_BelegKopfAdr-K.Name3
      .

    /* Ship-To Address */
    find bV_BelegKopfAdr
      where bV_BelegKopfAdr.Firma      = bV_BelegKopf.Firma
        and bV_BelegKopfAdr.Belegart   = bV_BelegKopf.Belegart
        and bV_BelegKopfAdr.ReferenzNr = bV_BelegKopf.ReferenzNr
        and bV_BelegKopfAdr.Typ        = 'L':U
      no-lock no-error.

    release bS_Lieferadresse.
    release bS_Adresse-LiefAdr.

    if available bV_BelegKopfAdr then
    do:

      find first bS_Lieferadresse
        where bS_Lieferadresse.Firma         = {firma/s_kunde.fir pACConnectionSvc:prpcCompany}
          and bS_Lieferadresse.Kunde         = bV_BelegKopf.Kunde
          and bS_Lieferadresse.LieferAdresse = bV_BelegKopfAdr.LieferAdresse
        no-lock no-error.

      if available bS_Lieferadresse then
      do:

        find bS_Adresse-LiefAdr
          where bS_Adresse-LiefAdr.Firma    = {firma/s_adres.fir pACConnectionSvc:prpcCompany}
            and bS_Adresse-LiefAdr.AdressNr = bS_LieferAdresse.AdressNr
          no-lock.

        assign
          ttUV_VersandBeleg.LieferAdresse      = bS_LieferAdresse.LieferAdresse
          ttUV_VersandBeleg.AdressKennung      = bS_LieferAdresse.AdressKennung
          ttUV_VersandBeleg.LiefAdr_Name1      = bS_Adresse-LiefAdr.Name1
          ttUV_VersandBeleg.LiefAdr_Staat      = bS_Adresse-LiefAdr.Staat
          ttUV_VersandBeleg.LiefAdr_PLZ        = bS_Adresse-LiefAdr.PLZ
          ttUV_VersandBeleg.LiefAdr_Ort        = bS_Adresse-LiefAdr.Ort
          ttUV_VersandBeleg.LiefAdr_Bundesland = bS_Adresse-LiefAdr.Bundesland
          ttUV_VersandBeleg.LiefAdr_Name2      = bS_Adresse-LiefAdr.Name2
          ttUV_VersandBeleg.LiefAdr_Name3      = bS_Adresse-LiefAdr.Name3
          ttUV_VersandBeleg.LiefAdr_Strasse    = bS_Adresse-LiefAdr.Strasse
          ttUV_VersandBeleg.LiefAdr_HausNummer = bS_Adresse-LiefAdr.HausNummer
          .

      end. /* available bS_Lieferadresse */
      else

        assign
          ttUV_VersandBeleg.LieferAdresse      = ?
          ttUV_VersandBeleg.AdressKennung      = '':U
          ttUV_VersandBeleg.LiefAdr_Name1      = bV_BelegKopfAdr.Name1
          ttUV_VersandBeleg.LiefAdr_Staat      = bV_BelegKopfAdr.Staat
          ttUV_VersandBeleg.LiefAdr_PLZ        = bV_BelegKopfAdr.PLZ
          ttUV_VersandBeleg.LiefAdr_Ort        = bV_BelegKopfAdr.Ort
          ttUV_VersandBeleg.LiefAdr_Bundesland = bV_BelegKopfAdr.Bundesland
          ttUV_VersandBeleg.LiefAdr_Name2      = bV_BelegKopfAdr.Name2
          ttUV_VersandBeleg.LiefAdr_Name3      = bV_BelegKopfAdr.Name3
          ttUV_VersandBeleg.LiefAdr_Strasse    = bV_BelegKopfAdr.Strasse
          ttUV_VersandBeleg.LiefAdr_HausNummer = bV_BelegKopfAdr.HausNummer
          .

    end. /* available bV_BelegKopfAdr */
    else
      if available bV_BelegKopfAdr-K
        and bV_BelegKopfAdr-K.AdressNr = ? then
        assign
          ttUV_VersandBeleg.LieferAdresse      = ?
          ttUV_VersandBeleg.AdressKennung      = '':U
          ttUV_VersandBeleg.LiefAdr_Name1      = bV_BelegKopfAdr-K.Name1
          ttUV_VersandBeleg.LiefAdr_Staat      = bV_BelegKopfAdr-K.Staat
          ttUV_VersandBeleg.LiefAdr_PLZ        = bV_BelegKopfAdr-K.PLZ
          ttUV_VersandBeleg.LiefAdr_Ort        = bV_BelegKopfAdr-K.Ort
          ttUV_VersandBeleg.LiefAdr_Bundesland = bV_BelegKopfAdr-K.Bundesland
          ttUV_VersandBeleg.LiefAdr_Name2      = bV_BelegKopfAdr-K.Name2
          ttUV_VersandBeleg.LiefAdr_Name3      = bV_BelegKopfAdr-K.Name3
          ttUV_VersandBeleg.LiefAdr_Strasse    = bV_BelegKopfAdr-K.Strasse
          ttUV_VersandBeleg.LiefAdr_HausNummer = bV_BelegKopfAdr-K.HausNummer
          .
      else
        assign
          ttUV_VersandBeleg.LieferAdresse      = ?
          ttUV_VersandBeleg.AdressKennung      = '':U
          ttUV_VersandBeleg.LiefAdr_Name1      = bS_Adresse-Kunde.Name1
          ttUV_VersandBeleg.LiefAdr_Staat      = bS_Adresse-Kunde.Staat
          ttUV_VersandBeleg.LiefAdr_PLZ        = bS_Adresse-Kunde.PLZ
          ttUV_VersandBeleg.LiefAdr_Ort        = bS_Adresse-Kunde.Ort
          ttUV_VersandBeleg.LiefAdr_Bundesland = bS_Adresse-Kunde.Bundesland
          ttUV_VersandBeleg.LiefAdr_Name2      = bS_Adresse-Kunde.Name2
          ttUV_VersandBeleg.LiefAdr_Name3      = bS_Adresse-Kunde.Name3
          ttUV_VersandBeleg.LiefAdr_Strasse    = bS_Adresse-Kunde.Strasse
          ttUV_VersandBeleg.LiefAdr_HausNummer = bS_Adresse-Kunde.HausNummer
          .

    if   ttUV_VersandBeleg.LieferAdresse < pa-filter-LieferAdresse_min
      or ttUV_VersandBeleg.LieferAdresse > pa-filter-LieferAdresse_max then
    do:
      delete ttUV_VersandBeleg.
      next Order.
    end.

    if   ttUV_VersandBeleg.AdressKennung < pa-filter-AdressKennung_min
      or ttUV_VersandBeleg.AdressKennung > pa-filter-AdressKennung_max then
    do:
      delete ttUV_VersandBeleg.
      next Order.
    end.

    run mawi/base/proc/mmvtra00.p (       bV_BelegKopf.Firma,
                                          bV_BelegKopf.Kunde,
                                          bV_BelegPos.uCI_Versandart,
                                          (if available bS_Lieferadresse then
                                             bS_Lieferadresse.Lieferadresse
                                           else
                                             ?),
                                          '',
                                   output iLieferant,
                                   output cDummy,
                                   output cDummy,
                                   output iDummy,
                                   output iDummy,
                                   output cDummy).

    find bS_Lieferant
      where bS_Lieferant.Firma     = {firma/sliefera.fir pACConnectionSvc:prpcCompany}
        and bS_Lieferant.Lieferant = iLieferant
      no-lock no-error.

    if available bS_Lieferant then
      find bS_Adresse-Lief
        where bS_Adresse-Lief.Firma    = {firma/s_adres.fir pACConnectionSvc:prpcCompany}
          and bS_Adresse-Lief.AdressNr = bS_Lieferant.AdressNr
        no-lock.
    else
      release bS_Adresse-Lief.

    assign
      ttUV_VersandBeleg.Lieferant               = bS_Lieferant.Lieferant      when available bS_Lieferant
      ttUV_VersandBeleg.Lieferant_Name1         = bS_Adresse-Lief.Name1       when available bS_Adresse-Lief
      ttUV_VersandBeleg.Lieferant_Name2         = bS_Adresse-Lief.Name2       when available bS_Adresse-Lief
      ttUV_VersandBeleg.Lieferant_Name3         = bS_Adresse-Lief.Name3       when available bS_Adresse-Lief
      ttUV_VersandBeleg.Lieferant_Suchbegriff   = bS_Lieferant.Suchbegriff    when available bS_Lieferant
      ttUV_VersandBeleg.Lieferant_Selektion     = bS_Lieferant.Selektion      when available bS_Lieferant
      .

    if   ttUV_VersandBeleg.Lieferant < pa-filter-Lieferant_min
      or ttUV_VersandBeleg.Lieferant > pa-filter-Lieferant_max then
    do:
      delete ttUV_VersandBeleg.
      next Order.
    end.


    /* quantities */
    assign
      ttUV_VersandBeleg.Menge                   = bV_BelegPos.Menge
      ttUV_VersandBeleg.gelieferte_Menge        = bV_BelegPos.gelieferte_Menge
      ttUV_VersandBeleg.stornierte_Menge        = bV_BelegPos.stornierte_Menge
      ttUV_VersandBeleg.KommMenge               = max(mawi.base.cls.MMCPickingSvc:prpoInstance:dReviewReservationQty
                                                        (bV_BelegPos.V_BelegPos_Obj),
                                                      mawi.base.cls.MMCPickingSvc:prpoInstance:duSuggestedQtyPerDocLine
                                                        (bV_BelegPos.V_BelegPos_Obj,
                                                         yes))
      ttUV_VersandBeleg.OffeneMenge             = ttUV_VersandBeleg.Menge
                                                  - ttUV_VersandBeleg.gelieferte_Menge
                                                  - ttUV_VersandBeleg.stornierte_Menge
                                                  - ttUV_VersandBeleg.KommMenge
      ttUV_VersandBeleg.uCI_DispatchQty         = bV_BelegPos.uCI_DispatchQty
      ttUV_VersandBeleg.uCI_DispatchQtyRemark   = bV_BelegPos.uCI_DispatchQtyRemark
      .

    if ttUV_VersandBeleg.OffeneMenge <= 0 then
    do:
      delete ttUV_VersandBeleg.
      next Order.
    end.

    assign
      ttUV_VersandBeleg.Lagergruppe = mawi.dispo.cls.MDCMRPAreaSvc:prpoInstance:iGetMRPAreaPart
                                        (bV_BelegPos.Artikel,
                                         bV_BelegPos.Lagerort,
                                         (if bV_BelegPos.LagerOrt = ? then
                                            bV_BelegKopf.Lagergruppe
                                          else
                                            ?)).
      ttUV_VersandBeleg.MRPArea     = ttUV_VersandBeleg.Lagergruppe
      .

    run reallocateDemandCoverage in target-procedure (buffer bML_Lagergruppe,
                                                      bS_Artikel.S_Artikel_Obj,
                                                      ttUV_VersandBeleg.Artikel,
                                                      ttUV_VersandBeleg.ArtVar,
                                                      ttUV_VersandBeleg.Lagergruppe,
                                                      bV_BelegKopf.Lagergruppe,
                                                      ?).

    /* coverage status */

    if can-do({&pa_S_PTList_Set}, string(bS_Artikel.ArtikelArt)) then
    do:

      assign
        iCoverageStatus                  = {&uCI_CoverageStatus_Without}
        ttUV_VersandBeleg.CoverageStatus = {&uCI_CoverageStatus_Without}
        .

      Coverage-Set:
      for each bV_BelegStueli
        where bV_BelegStueli.Firma       = {firma/vbelegko.fir pACConnectionSvc:prpcCompany}
          and bV_BelegStueli.BelegArt    = bV_BelegPos.BelegArt
          and bV_BelegStueli.ReferenzNr  = bV_BelegPos.ReferenzNr
          and bV_BelegStueli.LfdNr_SR    = bV_BelegPos.LfdNr_SR
          and bV_BelegStueli.PositionsNr = bV_BelegPos.PositionsNr
        no-lock
        on error undo, throw:

        run reallocateDemandCoverage in target-procedure (buffer bML_Lagergruppe,
                                                          ?, /* S_Artikel_Obj */
                                                          bV_BelegStueli.Artikel,
                                                          bV_BelegStueli.ArtVar,
                                                          ?, /* Lagergruppe */
                                                          bV_BelegKopf.Lagergruppe,
                                                          bV_BelegStueli.Lagerort).

        /* partially covered by on hand               */
        /* only partially covered if sum of covered   */
        /* quantities is GE V_BelegStueli.Einzelmenge */
        iCoverageStatus
          = mawi.base.cls.MMCMRPLinkSvc:prpoInstance:iCoverageStatusShippingMonitor
              (ttUV_VersandBeleg.MRPDocType,
               bV_BelegStueli.V_BelegStueli_Obj,
               bV_BelegStueli.Einzelmenge).
        
        if iCoverageStatus = {&uCI_CoverageStatus_Without} then
        do:
          ttUV_VersandBeleg.CoverageStatus = {&uCI_CoverageStatus_Without}.
          leave Coverage-Set.
        end.

        ttUV_VersandBeleg.CoverageStatus = max(iCoverageStatus,ttUV_VersandBeleg.CoverageStatus).

      end. /* for each guV_BelegStueli */

    end. /* if can-do({&pa_S_PTList_Set}, string(bS_Artikel.ArtikelArt)) */
    else
      ttUV_VersandBeleg.CoverageStatus
        = mawi.base.cls.MMCMRPLinkSvc:prpoInstance:iCoverageStatusShippingMonitor
            (ttUV_VersandBeleg.MRPDocType,
             ttUV_VersandBeleg.Owning_Obj,
             0).

    if   ttUV_VersandBeleg.CoverageStatus = {&uCI_CoverageStatus_Without}            and pa-filter-lCoverageStatus_Without_var    = no
      or ttUV_VersandBeleg.CoverageStatus = {&uCI_CoverageStatus_Available}          and pa-filter-lCoverageStatus_Available_var  = no
      or ttUV_VersandBeleg.CoverageStatus = {&uCI_CoverageStatus_PartiallyAvailable} and pa-filter-lCoverageStatus_PAvailable_var = no
      or ttUV_VersandBeleg.CoverageStatus = {&uCI_CoverageStatus_Covered}            and pa-filter-lCoverageStatus_Covered_var    = no
      or ttUV_VersandBeleg.CoverageStatus = {&uCI_CoverageStatus_Open}               and pa-filter-lCoverageStatus_Open_var       = no then
    do:
      delete ttUV_VersandBeleg.
      next Order.
    end.

    /* Compute some stuff only if the tt-record can't be deleted anymore. */

    {adm/incl/d__spr00.if
      &Tabelle  = "bS_BrancheSpr"
      &Selekt   = "where bS_BrancheSpr.Firma   = {firma/sbranche.fir pACConnectionSvc:prpcCompany}
                     and bS_BrancheSpr.Branche = bS_Kunde.Branche"
      &Sprache  = "pACConnectionSvc:prpcLanguage"
      &no-error = "no-error"
    }

    {adm/incl/d__spr00.if
      &Tabelle  = "bS_RegionSpr"
      &Selekt   = "where bS_RegionSpr.Firma   = {firma/sregion.fir pACConnectionSvc:prpcCompany}
                     and bS_RegionSpr.Region = bS_Kunde.Region"
      &Sprache  = "pACConnectionSvc:prpcLanguage"
      &no-error = "no-error"
    }

    {adm/incl/d__spr00.if
      &Tabelle  = "bS_ArtikelSpr"
      &Selekt   = "where bS_ArtikelSpr.Firma   = {firma/sartikel.fir pACConnectionSvc:prpcCompany}
                     and bS_ArtikelSpr.Artikel = bV_BelegPos.Artikel"
      &Sprache  = "pACConnectionSvc:prpcLanguage"
    }

    {adm/incl/d__spr00.if
      &Tabelle  = "bS_SparteSpr"
      &Selekt   = "where bS_SparteSpr.Firma   = {firma/ssparte.fir pACConnectionSvc:prpcCompany}
                     and bS_SparteSpr.Sparte  = bS_Artikel.Sparte"
      &Sprache  = "pACConnectionSvc:prpcLanguage"
      &no-error = "no-error"
    }

    find bS_ArtKunde
      where bS_ArtKunde.Firma   = {firma/sartkund.fir pACConnectionSvc:prpcCompany}
        and bS_ArtKunde.Artikel = bS_Artikel.Artikel
        and bS_ArtKunde.Kunde   = bS_Kunde.Kunde
      no-lock no-error.

    if bV_BelegPos.KO_LagerOrt <> ? then
    do:

      {adm/incl/d__spr00.if
        &Tabelle  = "bML_OrtSpr"
        &Selekt   = "where bML_OrtSpr.Firma    = {firma/mlort.fir pACConnectionSvc:prpcCompany}
                       and bML_OrtSpr.Lagerort = bV_BelegPos.KO_LagerOrt"
        &Sprache  = "pACConnectionSvc:prpcLanguage"
        &no-error = "no-error"
      }

    end.

    if ttUV_VersandBeleg.StorageArea <> ? then
    do:

      {adm/incl/d__spr00.if
        &Tabelle  = "bML_OrtSpr-StorArea"
        &Selekt   = "where bML_OrtSpr-StorArea.Firma    = {firma/mlort.fir pACConnectionSvc:prpcCompany}
                       and bML_OrtSpr-StorArea.Lagerort = ttUV_VersandBeleg.StorageArea"
        &Sprache  = "pACConnectionSvc:prpcLanguage"
        &no-error = "no-error"
      }

    end.

    {adm/incl/d__spr00.if
      &Tabelle  = "bML_LagergruppeSpr"
      &Selekt   = "where bML_LagergruppeSpr.Firma       = {firma/mlort.fir pACConnectionSvc:prpcCompany} 
                     and bML_LagergruppeSpr.Lagergruppe = ttUV_VersandBeleg.MRPArea"
      &Sprache  = "pACConnectionSvc:prpcLanguage"
      &no-error = "no-error"
    }

    {adm/incl/d__spr00.if
      &Tabelle  = "bS_ZahlZielSpr"
      &Selekt   = "where bS_ZahlZielSpr.Firma        = {firma/szahlzie.fir pACConnectionSvc:prpcCompany}
                     and bS_ZahlZielSpr.ZahlungsZiel = ttUV_VersandBeleg.CreditTerms"
      &Sprache  = "pACConnectionSvc:prpcLanguage"
      &no-error = "no-error"
    }

    assign
      ttUV_VersandBeleg.Konto_BrancheBez        = bS_BrancheSpr.Bezeichnung   when available bS_BrancheSpr
      ttUV_VersandBeleg.Konto_RegionBez         = bS_RegionSpr.Bezeichnung    when available bS_RegionSpr
      ttUV_VersandBeleg.ArtikelBez              = bS_ArtikelSpr.Bezeichnung
      ttUV_VersandBeleg.ArtikelgruppeBez        = {fnarg
                                                     pa_cDyCchProductLineDesc
                                                     "pACConnectionSvc:prpcCompany,
                                                      bS_Artikel.Artikelgruppe,
                                                      pACConnectionSvc:prpcLanguage"}
      ttUV_VersandBeleg.SparteBez               = bS_SparteSpr.Bezeichnung
      ttUV_VersandBeleg.ArtikelArtBez           = {fnarg
                                                     pa_cStCchPartTypeDesc
                                                     "bS_Artikel.ArtikelArt,
                                                      pACConnectionSvc:prpcLanguage,
                                                      {&pa_CchDesc}"}
      ttUV_VersandBeleg.ArtikelNr               = bS_ArtKunde.ArtikelNr       when available bS_ArtKunde
      ttUV_VersandBeleg.ArtikelNrBez            = bS_ArtKunde.Bezeichnung     when available bS_ArtKunde
      ttUV_VersandBeleg.AuftragsArtBez          = {fnarg
                                                    pa_cDyCchOrderTypeDesc
                                                    "pACConnectionSvc:prpcCompany,
                                                     bV_BelegKopf.AuftragsArt,
                                                     pACConnectionSvc:prpcLanguage"}
      ttUV_VersandBeleg.VersandarBez            = {fnarg
                                                    pa_cDyCchShippingTypeDesc
                                                    "pACConnectionSvc:prpcCompany,
                                                     bV_BelegPos.uCI_Versandart,
                                                     pACConnectionSvc:prpcLanguage"}
      ttUV_VersandBeleg.LieferBedingungBez      = {fnarg
                                                    pa_cDyCchTermsOfDeliveryDesc
                                                    "pACConnectionSvc:prpcCompany,
                                                     bV_BelegPos.LieferBedingung,
                                                     pACConnectionSvc:prpcLanguage"}
      ttUV_VersandBeleg.LieferRestriktBez       = entry(lookup(string(bV_BelegKopf.LieferRestrikt), gcSB_ShipmentRestrictions_keys, '|':U),
                                                        gcSB_ShipmentRestrictions_desc, '|':U)
      ttUV_VersandBeleg.SachbearbeiterName      = {fnarg
                                                    pa_cDyCchUserName
                                                    "bV_BelegKopf.Sachbearbeiter,
                                                     {&pa_CchDesc}"}
      ttUV_VersandBeleg.KO_LagerOrtBez          = bML_OrtSpr.Bezeichnung      when available bML_OrtSpr
      ttUV_VersandBeleg.MengenEinheitKurzBez    = {fnarg
                                                     pa_cDyCchUnitOfMeasureDesc
                                                     "pACConnectionSvc:prpcCompany,
                                                      bV_BelegPos.MengenEinheit,
                                                      pACConnectionSvc:prpcLanguage,
                                                      {&pa_CchShortCut}"}
      ttUV_VersandBeleg.MengenEinheitKurzBezLME = {fnarg
                                                     pa_cDyCchUnitOfMeasureDesc
                                                     "pACConnectionSvc:prpcCompany,
                                                      bS_Artikel.LagerME,
                                                      pACConnectionSvc:prpcLanguage,
                                                      {&pa_CchShortCut}"}
      ttUV_VersandBeleg.StorageArea_Desc        = bML_OrtSpr-StorArea.Bezeichnung   when available bML_OrtSpr-StorArea
      ttUV_VersandBeleg.CreditTerms_Desc        = bS_ZahlZielSpr.Bezeichnung                                           
      ttUV_VersandBeleg.MRPArea_desc            = bML_LagergruppeSpr.Bezeichnung    when available bML_LagergruppeSpr
    .

    if available bML_Ort then
      ttUV_VersandBeleg.Bestand  = dGetPhysicalOnHand(buffer bML_Ort,
                                                             bS_Artikel.Artikel,
                                                             ttUV_VersandBeleg.ArtVar,
                                                             bV_BelegPos.V_BelegPos_Obj).

    /* total values */

    assign
      gdExchangeRate                         = {fnarg
                                                  pa_dCurGetExchangeRate
                                                  "pACConnectionSvc:prpcCompany,
                                                   bV_BelegKopf.Waehrung,
                                                   bV_BelegKopf.Belegdatum,
                                                   string({&pa_V_Kurs}),
                                                   bV_BelegKopf.Kunde,
                                                   bV_BelegKopf.V_BelegKopf_Obj"}
      ttUV_VersandBeleg.GesamtwertOffen      = round(  (  ttUV_VersandBeleg.OffeneMenge
                                                        * bV_BelegPos.Gesamtpreis
                                                        / bV_BelegPos.Menge) 
                                                     * gdExchangeRate, bV_BelegKopf.WaehrungNK)
      ttUV_VersandBeleg.GesamtwertVerfuegbar = round(  (if ttUV_VersandBeleg.Bestand >= ttUV_VersandBeleg.OffeneMenge then
                                                            ttUV_VersandBeleg.OffeneMenge
                                                          * bV_BelegPos.Gesamtpreis
                                                          / bV_BelegPos.Menge
                                                        else
                                                            ttUV_VersandBeleg.Bestand
                                                          * bV_BelegPos.Gesamtpreis
                                                          / bV_BelegPos.Menge) 
                                                     * gdExchangeRate, bV_BelegKopf.WaehrungNK)
      .

    if bV_BelegPos.uCI_MessageCode > '':U then
      ttUV_VersandBeleg.Fehlermeldung = cErrortext(bV_BelegPos.uCI_MessageCode, bV_BelegPos.uCI_MessageSubst).

  end. /* for each bV_BelegPos */

end. /* do for bS_Kunde */

end procedure. /* fillOrders */


/* _UIB-CODE-BLOCK-END */
&ANALYZE-RESUME

&ENDIF


&IF DEFINED(EXCLUDE-fillServiceOrderMKT) = 0 &THEN

&ANALYZE-SUSPEND _UIB-CODE-BLOCK _PROCEDURE fillServiceOrderMKT Method-Library

&IF LOOKUP("VS","{&PA-MODULE}") > 0 &THEN
procedure fillServiceOrderMKT :
/* Description ---------------------------------------------------------------*/
/*                                                                            */
/*  Fills the dataset with ServiceOrder PositionLines                         */
/*                                                                            */
/* Parameters ----------------------------------------------------------------*/
/*                                                                            */
/* <none>                                                                     */
/*                                                                            */ 
/*----------------------------------------------------------------------------*/

define variable cDocTypeDes              as character                   no-undo.

define variable cCustomerObj             as character                   no-undo.
define variable cPartObj                 as character                   no-undo.

define buffer bVS_Auftrag                for VS_Auftrag .
define buffer bVS_AuftragPos             for VS_AuftragPos .
define buffer bVS_AuftragMKT             for VS_AuftragMKT.
define buffer bML_Ort                    for ML_Ort.
define buffer bML_Lagergruppe            for ML_Lagergruppe.
define buffer bEBT_PurchDemands          for EBT_PurchDemands.

  cDocTypeDes = {fnarg
                 pa_cStCchDocTypeDesc
                 "'VSA':U,
                  pACConnectionSvc:prpcLanguage,
                  {&pa_CchDesc}"}.
  
  ServiceOrder:
  for each bVS_Auftrag 
    where bVS_Auftrag.Firma               = {firma/vbelegko.fir pACConnectionSvc:prpcCompany}
      and bVS_Auftrag.BelegArt            = 'VSA':U
      and bVS_Auftrag.offen               = yes
      and (   bVS_Auftrag.Auftragstyp     = {&pa_VS_StandardOrder}
           or bVS_Auftrag.Auftragstyp     = {&pa_VS_RushOrder}  )
      and (   bVS_Auftrag.Auftragsstatus  = {&pa_VS_Released}
           or bVS_Auftrag.Auftragsstatus  = {&pa_VS_inProcessing}  )
      and bVS_Auftrag.BelegNummer        >= pa-filter-BelegNummer_min
      and bVS_Auftrag.BelegNummer        <= pa-filter-BelegNummer_max
      and bVS_Auftrag.Kunde              >= pa-filter-Konto_min
      and bVS_Auftrag.Kunde              <= pa-filter-Konto_max
      and bVS_Auftrag.Sachbearbeiter     >= pa-filter-Sachbearbeiter_min
      and bVS_Auftrag.Sachbearbeiter     <= pa-filter-Sachbearbeiter_max
      and bVS_Auftrag.Auftragsart        >= pa-filter-AuftragsArt_min 
      and bVS_Auftrag.Auftragsart        <= pa-filter-AuftragsArt_max
      and bVS_Auftrag.Sachbearbeiter     >= pa-filter-Sachbearbeiter_min 
      and bVS_Auftrag.Sachbearbeiter     <= pa-filter-Sachbearbeiter_max
      and bVS_Auftrag.ZahlungsZiel       >= pa-filter-CreditTerms_min
      and bVS_Auftrag.ZahlungsZiel       <= pa-filter-CreditTerms_max
      and bVS_Auftrag.Lagergruppe        >= pa-filter-MRPArea_min
      and bVS_Auftrag.Lagergruppe        <= pa-filter-MRPArea_max 
      and bVS_Auftrag.Versandart         >= pa-filter-VersandArt_min
      and bVS_Auftrag.Versandart         <= pa-filter-VersandArt_max
      no-lock,                           
      each bVS_AuftragPos                
      where bVS_AuftragPos.Firma          = bVS_Auftrag.Firma
        and bVS_AuftragPos.BelegArt       = 'VSA':U
        and bVS_AuftragPos.ReferenzNr     = bVS_Auftrag.ReferenzNr
        and bVS_AuftragPos.offen          = yes
      no-lock
      on error undo, throw:
           
        ServiceOrderMatLine: 
        for each bVS_AuftragMKT
          where bVS_AuftragMKT.Firma                   = {firma/vbelegko.fir pACConnectionSvc:prpcCompany}
            and bVS_AuftragMKT.BelegArt                = 'VSA':U
            and bVS_AuftragMKT.ReferenzNr              = bVS_AuftragPos.ReferenzNr
            and bVS_AuftragMKT.LfdNr_Pos               = bVS_AuftragPos.PositionsNr
            and bVS_AuftragMKT.Satzart                 = 'M':U
            and bVS_AuftragMKT.Artikel                >= pa-filter-Artikel_min
            and bVS_AuftragMKT.Artikel                <= pa-filter-Artikel_max
            and bVS_AuftragMKT.Lagerort               >= pa-filter-StorageArea_min
            and bVS_AuftragMKT.Lagerort               <= pa-filter-StorageArea_max
            and bVS_AuftragMKT.LieferBedingung        >= pa-filter-LieferBedingung_min
            and bVS_AuftragMKT.LieferBedingung        <= pa-filter-LieferBedingung_max
            and bVS_AuftragMKT.Wunschtermin           >= pa-filter-Wunschtermin_min
            and bVS_AuftragMKT.Wunschtermin           <= pa-filter-Wunschtermin_max
            and (  (    bVS_AuftragMKT.Liefertermin   >= pa-filter-Liefertermin_min
                    and bVS_AuftragMKT.Liefertermin   <= pa-filter-Liefertermin_max)
                 or (    bVS_AuftragMKT.Liefertermin   = ?
                     and pa-filter-Liefertermin_min    = {&PA_DATEMIN}))           
            and bVS_AuftragMKT.Versandtermin          >= pa-filter-Versandtermin_min
            and bVS_AuftragMKT.Versandtermin          <= pa-filter-Versandtermin_max
          no-lock
          on error undo, throw:
            
        case pa-filter-iBezugsdatum_var:
       
          when 1 then gtBezugsdatum = bVS_AuftragMKT.Wunschtermin.
          when 2 then gtBezugsdatum = bVS_AuftragMKT.Liefertermin.
          when 3 then gtBezugsdatum = bVS_AuftragMKT.Versandtermin.
          when 4 then gtBezugsdatum = bVS_AuftragMKT.Versandtermin.
          /* --> MO#HIDR-AH4-1123 thongdi_p 20.07.2026 Erweiterung Versandmonitor im Feld Best. Termin */
          when 5 then gtBezugsdatum = ?.
          /* <-- MO#HIDR-AH4-1123 thongdi_p 20.07.2026 Erweiterung Versandmonitor im Feld Best. Termin */
          
          
        end case. /* pa-filter-iBezugsdatum_var */    
     
        if not pa-filter-lPastOrderLines_var  
          and gtBezugsdatum < today then
          next ServiceOrderMatLine.
        
        if not pa-filter-lTodayOrderLines_var  
          and gtBezugsdatum = today then 
          next ServiceOrderMatLine.
           
        if not pa-filter-lFutureOrderLines_var  
          and gtBezugsdatum >  today  then
          
          next ServiceOrderMatLine.
          
        else if gtBezugsdatum >  today + pa-filter-iHorizont_var then 
          next ServiceOrderMatLine.
     
        /* In the Materialposition (VS_AuftragMKT) of theServiceOrder          */
        /* there is no Supplier field (only in the Activity)                   */
            
        if pa-filter-Lieferant_min > 0 then
          next ServiceOrder.
        
        if   bVS_AuftragMKT.KO_Lagerort  <> ?
          or bVS_AuftragMKT.Bei_Lagerort <> ? then
              
          next ServiceOrderMatLine.  
          
                  
        /* check Customer */  
        
        if not vert.serv.cls.VSCFillShippingMonitorSvc:prpoInstance:lisCustomerAvailable(bVS_Auftrag.Kunde,
                                                                                         bVS_Auftrag.Firma)  then
        
          next ServiceOrder.
        
        /* In the service order, there is the possibility to create a once only customer      */
        /* in the document header and to add the customer address via the menu point Address. */
        /* This address is stored in VS_AuftragAdr, with VS_AuftragAdr.Type set to 'K':U.     */  
          
        if not vert.serv.cls.VSCFillShippingMonitorSvc:prpoInstance:lisCustomerAdrValid(bVS_Auftrag.Kunde,
                                                                                        bVS_Auftrag.Firma,
                                                                                        bVS_Auftrag.Belegart,
                                                                                        bVS_Auftrag.ReferenzNr) then
                                                                                        
          next ServiceOrder.
        
        if not vert.serv.cls.VSCFillShippingMonitorSvc:prpoInstance:lisPartAvailable(bVS_Auftrag.Firma,
                                                                                     bVS_AuftragMKT.Artikel,
                                                                                     pa-filter-ArtikelGruppe_min,
                                                                                     pa-filter-ArtikelGruppe_max,
                                                                                     pa-filter-Sparte_min,
                                                                                     pa-filter-Sparte_max,
                                                                                     pa-filter-ArtikelArt_min,
                                                                                     pa-filter-ArtikelArt_max) then
        
          next ServiceOrderMatLine. 
        
        create ttUV_VersandBeleg.
        
        vert.serv.cls.VSCFillShippingMonitorSvc:prpoInstance:FillTTShippingMonitorVSAHeaderInfo(buffer ttUV_VersandBeleg:handle,
                                                                                                buffer bVS_Auftrag,
                                                                                                cDocTypeDes).
        
        vert.serv.cls.VSCFillShippingMonitorSvc:prpoInstance:FillTTShippingMonitorVSAMaterialLines(buffer ttUV_VersandBeleg:handle,
                                                                                                   buffer bVS_Auftrag,
                                                                                                   buffer bVS_AuftragMKT). 

        assign
          cCustomerObj                                = vert.serv.cls.VSCFillShippingMonitorSvc:prpoInstance:cGetCustomerObjID(ttUV_VersandBeleg.Konto)
          cPartObj                                    = vert.serv.cls.VSCFillShippingMonitorSvc:prpoInstance:cGetPartObjID(bVS_AuftragMKt.Artikel)
          ttUV_VersandBeleg.LocklevelOriginLSLSL      = cSetLocklevelValue(bVS_Auftrag.VS_Auftrag_Obj,
                                                                           'VUL':U)
          ttUV_VersandBeleg.LocklevelCustomerLSLSL    = cSetLocklevelValue(cCustomerObj,
                                                                           'VUL':U)
          ttUV_VersandBeleg.LocklevelOriginMMP        = cSetLocklevelValue(bVS_Auftrag.VS_Auftrag_Obj,
                                                                           'MMP':U)
          ttUV_VersandBeleg.LocklevelPartLSLSL        = cSetLocklevelValue(cPartObj,
                                                                           'VUL':U)
          ttUV_VersandBeleg.LocklevelPartMMP          = cSetLocklevelValue(cPartObj,
                                                                           'MMP':U)
          ttUV_VersandBeleg.LocklevelCustomerLSLSL    = cSetLocklevelValue(cCustomerObj,
                                                                           'VUL':U)
          ttUV_VersandBeleg.LocklevelCustomerMMP      = cSetLocklevelValue(cCustomerObj,
                                                                           'MMP':U)
          ttUV_VersandBeleg.Mahnstufe                 = iDunningLevel(ttUV_VersandBeleg.Konto)
          .

        if ttUV_VersandBeleg.OffeneMenge <= 0 then
        do:

          delete ttUV_VersandBeleg.
          next ServiceOrderMatLine.

        end. /* if ttUV_VersandBeleg.OffeneMenge <= 0 */
       
        find bML_Ort
          where bML_Ort.Firma    = {firma/mlort.fir pACConnectionSvc:prpcCompany}
            and bML_Ort.LagerOrt = bVS_AuftragMKT.LagerOrt
          no-lock no-error.

        if available bML_Ort then
        do:
          
          ttUV_VersandBeleg.Bestand = dGetPhysicalOnHand(buffer bML_Ort,
                                                         bVS_AuftragMKT.Artikel,
                                                         ttUV_VersandBeleg.ArtVar,
                                                         bVS_AuftragMKT.VS_AuftragMKT_Obj).
        
          find bEBT_PurchDemands
            where bEBT_PurchDemands.E_BelegPosBei_Obj    = bVS_AuftragMKT.VS_AuftragMKT_Obj
              and bEBT_PurchDemands.ML_Ort_Obj           = bML_Ort.ML_Ort_Obj
              and bEBT_PurchDemands.E_BelegPosTermin_Obj = '':U
            no-lock no-error.
        
        end. /* if available bML_Ort */
                                                        
        run reallocateDemandCoverage in target-procedure (buffer bML_Lagergruppe,
                                                          cPartObj,
                                                          ttUV_VersandBeleg.Artikel,
                                                          ttUV_VersandBeleg.ArtVar,
                                                          ttUV_VersandBeleg.Lagergruppe,
                                                          bVS_Auftrag.Lagergruppe,
                                                          ?).
        
        ttUV_VersandBeleg.CoverageStatus 
          = mawi.base.cls.MMCMRPLinkSvc:prpoInstance:iCoverageStatusShippingMonitor
              (ttUV_VersandBeleg.MRPDocType,
               (if available bEBT_PurchDemands then
                  bEBT_PurchDemands.EBT_PurchDemands_Obj
                else
                  bVS_AuftragMKT.VS_AuftragMKT_Obj),
               0).

        if   ttUV_VersandBeleg.CoverageStatus = {&uCI_CoverageStatus_Without}            and pa-filter-lCoverageStatus_Without_var    = no
          or ttUV_VersandBeleg.CoverageStatus = {&uCI_CoverageStatus_Available}          and pa-filter-lCoverageStatus_Available_var  = no
          or ttUV_VersandBeleg.CoverageStatus = {&uCI_CoverageStatus_PartiallyAvailable} and pa-filter-lCoverageStatus_PAvailable_var = no
          or ttUV_VersandBeleg.CoverageStatus = {&uCI_CoverageStatus_Covered}            and pa-filter-lCoverageStatus_Covered_var    = no
          or ttUV_VersandBeleg.CoverageStatus = {&uCI_CoverageStatus_Open}               and pa-filter-lCoverageStatus_Open_var       = no then
        do:
          
          delete ttUV_VersandBeleg.
          next ServiceOrderMatLine.
          
        end. /* if   ttUV_VersandBeleg.CoverageStatus = {&uCI_CoverageStatus_Without}     */

        assign
          gdExchangeRate                         = vert.serv.cls.VSCFillShippingMonitorSvc:prpoInstance:dGetExchangeRate(bVS_Auftrag.Waehrung,
                                                                                                                         bVS_Auftrag.Belegdatum,
                                                                                                                         bVS_Auftrag.Kunde,
                                                                                                                         bVS_Auftrag.VS_Auftrag_Obj)
          ttUV_VersandBeleg.GesamtwertOffen      = round(  (  ttUV_VersandBeleg.OffeneMenge
                                                            * bVS_AuftragMKT.Gesamtpreis
                                                            / bVS_AuftragMKT.Menge) 
                                                         * gdExchangeRate, bVS_Auftrag.WaehrungNK)
          ttUV_VersandBeleg.GesamtwertVerfuegbar = round(  (if ttUV_VersandBeleg.Bestand >= ttUV_VersandBeleg.OffeneMenge then
                                                              ttUV_VersandBeleg.OffeneMenge
                                                              * bVS_AuftragMKT.Gesamtpreis
                                                              / bVS_AuftragMKT.Menge
                                                            else
                                                              ttUV_VersandBeleg.Bestand
                                                              * bVS_AuftragMKT.Gesamtpreis
                                                              / bVS_AuftragMKT.Menge) 
                                                         * gdExchangeRate, bVS_Auftrag.WaehrungNK)
        .                                                                                         
          

        /* Compute some stuff only if the tt-record can't be deleted anymore. */

        vert.serv.cls.VSCFillShippingMonitorSvc:prpoInstance:FillTTShippingMonitorVSAMiscFields(buffer ttUV_VersandBeleg:handle,
                                                                                                buffer bVS_Auftrag).
                                                                                      
        find ttGenerateDemandQtyForService
          where ttGenerateDemandQtyForService.Owning_obj = ttUV_VersandBeleg.Owning_obj
            and ttGenerateDemandQtyForService.Doctype = ttUV_VersandBeleg.Belegart 
          no-lock no-error.
       
        if available ttGenerateDemandQtyForService then
        
          ttUV_VersandBeleg.uCI_DispatchQty = ttGenerateDemandQtyForService.qty.
          
   end. /* for each bVS_AuftragMKT */  
      
  end. /* for each bVS_Auftrag*/ 

end procedure. /* fillServiceOrderMKT */
&ENDIF

/* _UIB-CODE-BLOCK-END */
&ANALYZE-RESUME

&ENDIF


&IF DEFINED(EXCLUDE-fillRepairOrderLine) = 0 &THEN

&ANALYZE-SUSPEND _UIB-CODE-BLOCK _PROCEDURE fillServiceOrderPositions Method-Library

&IF LOOKUP("VS","{&PA-MODULE}") > 0 &THEN
procedure fillRepairOrderLine :
/* Description ---------------------------------------------------------------*/
/*                                                                            */
/*  Fills the dataset with ServiceOrder MaterialLines (VS_AuftragMKT)         */
/*                                                                            */
/* Parameters ----------------------------------------------------------------*/
/*                                                                            */
/* <none>                                                                     */
/*                                                                            */
/*----------------------------------------------------------------------------*/  

define variable cDocTypeDes              as character                   no-undo.

define variable cCustomerObj             as character                   no-undo.
define variable cPartObj                 as character                   no-undo.

define buffer bVS_Auftrag                for VS_Auftrag .
define buffer bVS_AuftragPos             for VS_AuftragPos .
define buffer bML_Ort                    for ML_Ort.

  /* Only 'Serviceauftrag' exists for DocType, therefore done this way */
        
  cDocTypeDes = adm.base.cls.DBCTranslateSvc:prpoInstance:cTranslateGermanTerm('Reparaturauftrag':U,60).
 
  RepairOrder:
  for each bVS_Auftrag 
    where bVS_Auftrag.Firma               = {firma/vbelegko.fir pACConnectionSvc:prpcCompany}
      and bVS_Auftrag.BelegArt            = 'VSA':U
      and bVS_Auftrag.offen               = yes
      and bVS_Auftrag.Auftragstyp         = {&pa_VS_RepairOrder}
      and (   bVS_Auftrag.Auftragsstatus  = {&pa_VS_Released}
           or bVS_Auftrag.Auftragsstatus  = {&pa_VS_inProcessing}  
           or bVS_Auftrag.Auftragsstatus  = {&pa_VS_CompletionNotice})
      and bVS_Auftrag.BelegNummer        >= pa-filter-BelegNummer_min
      and bVS_Auftrag.BelegNummer        <= pa-filter-BelegNummer_max
      and bVS_Auftrag.Kunde              >= pa-filter-Konto_min
      and bVS_Auftrag.Kunde              <= pa-filter-Konto_max
      and bVS_Auftrag.Sachbearbeiter     >= pa-filter-Sachbearbeiter_min
      and bVS_Auftrag.Sachbearbeiter     <= pa-filter-Sachbearbeiter_max
      and bVS_Auftrag.Auftragsart        >= pa-filter-AuftragsArt_min 
      and bVS_Auftrag.Auftragsart        <= pa-filter-AuftragsArt_max
      and bVS_Auftrag.Sachbearbeiter     >= pa-filter-Sachbearbeiter_min 
      and bVS_Auftrag.Sachbearbeiter     <= pa-filter-Sachbearbeiter_max
      and bVS_Auftrag.ZahlungsZiel       >= pa-filter-CreditTerms_min
      and bVS_Auftrag.ZahlungsZiel       <= pa-filter-CreditTerms_max
      and bVS_Auftrag.Lagergruppe        >= pa-filter-MRPArea_min
      and bVS_Auftrag.Lagergruppe        <= pa-filter-MRPArea_max 
      and bVS_Auftrag.Versandart         >= pa-filter-VersandArt_min
      and bVS_Auftrag.Versandart         <= pa-filter-VersandArt_max
      no-lock
      on error undo, throw:
        
        /* In the RepairOrder there is only 'Wunschtermin' */
        
        case pa-filter-iBezugsdatum_var:
       
          when 1 then gtBezugsdatum = bVS_Auftrag.Wunschtermin.
          when 2 then gtBezugsdatum = bVS_Auftrag.Wunschtermin.
          when 3 then gtBezugsdatum = bVS_Auftrag.Wunschtermin.
          when 4 then gtBezugsdatum = bVS_Auftrag.Wunschtermin.
          /* --> MO#HIDR-AH4-1123 thongdi_p 20.07.2026 Erweiterung Versandmonitor im Feld Best. Termin */
          when 5 then gtBezugsdatum = ?.
          /* <-- MO#HIDR-AH4-1123 thongdi_p 20.07.2026 Erweiterung Versandmonitor im Feld Best. Termin */
        end case. /* pa-filter-iBezugsdatum_var */     
        
        if not pa-filter-lPastOrderLines_var  
          and gtBezugsdatum < today then
          next RepairOrder.
        
        if not pa-filter-lTodayOrderLines_var  
          and gtBezugsdatum = today then 
          next RepairOrder.
           
        if not pa-filter-lFutureOrderLines_var  
          and gtBezugsdatum >  today  then          
          next RepairOrder.
          
        else if gtBezugsdatum >  today + pa-filter-iHorizont_var then 
          next RepairOrder.
     
        /* In the Repairorder there is no Supplier field                   */
            
        if pa-filter-Lieferant_min > 0 then
          next RepairOrder.
        
        RepairOrderLine:  
        for each bVS_AuftragPos                
          where bVS_AuftragPos.Firma          = bVS_Auftrag.Firma
            and bVS_AuftragPos.BelegArt       = 'VSA':U
            and bVS_AuftragPos.ReferenzNr     = bVS_Auftrag.ReferenzNr
            and bVS_AuftragPos.offen          = yes
            and bVS_AuftragPos.Auftragsstatus = {&pa_VS_CompletionNotice}
        no-lock
        on error undo, throw:
               
          /* check Customer */ 
          
          if not vert.serv.cls.VSCFillShippingMonitorSvc:prpoInstance:lisCustomerAvailable(bVS_Auftrag.Kunde,
                                                                                           bVS_Auftrag.Firma)  then
          
            next RepairOrder.
          
          /* In the repair order, there is the possibility to create a once only customer      */
          /* in the document header and to add the customer address via the menu point Address. */
          /* This address is stored in VS_AuftragAdr, with VS_AuftragAdr.Type set to 'K':U.     */  
            
          if not vert.serv.cls.VSCFillShippingMonitorSvc:prpoInstance:lisCustomerAdrValid(bVS_Auftrag.Kunde,
                                                                                          bVS_Auftrag.Firma,
                                                                                          bVS_Auftrag.Belegart,
                                                                                          bVS_Auftrag.ReferenzNr) then
                                                                                          
            next RepairOrder.
          
          if not vert.serv.cls.VSCFillShippingMonitorSvc:prpoInstance:lisPartAvailable(bVS_Auftrag.Firma,
                                                                                       bVS_AuftragPos.ArtikelWartung,
                                                                                       pa-filter-ArtikelGruppe_min,
                                                                                       pa-filter-ArtikelGruppe_max,
                                                                                       pa-filter-Sparte_min,
                                                                                       pa-filter-Sparte_max,
                                                                                       pa-filter-ArtikelArt_min,
                                                                                       pa-filter-ArtikelArt_max) then
          
            next RepairOrderLine. 
          
          create ttUV_VersandBeleg.
          
          vert.serv.cls.VSCFillShippingMonitorSvc:prpoInstance:FillTTShippingMonitorVSAHeaderInfo(buffer ttUV_VersandBeleg:handle,
                                                                                                  buffer bVS_Auftrag,
                                                                                                  cDocTypeDes).
          vert.serv.cls.VSCFillShippingMonitorSvc:prpoInstance:FillTTShippingMonitorVSAPositionLine(buffer ttUV_VersandBeleg:handle,
                                                                                                    buffer bVS_Auftrag,
                                                                                                    buffer bVS_AuftragPos). 
          assign
            cCustomerObj                                = vert.serv.cls.VSCFillShippingMonitorSvc:prpoInstance:cGetCustomerObjID(ttUV_VersandBeleg.Konto)
            cPartObj                                    = vert.serv.cls.VSCFillShippingMonitorSvc:prpoInstance:cGetPartObjID(bVS_AuftragPos.ArtikelWartung)                                                                                        
            ttUV_VersandBeleg.LocklevelOriginLSLSL      = cSetLocklevelValue(bVS_Auftrag.VS_Auftrag_Obj,
                                                                             'VUL':U)
            ttUV_VersandBeleg.LocklevelCustomerLSLSL    = cSetLocklevelValue(cCustomerObj,
                                                                             'VUL':U)
            ttUV_VersandBeleg.LocklevelOriginMMP        = cSetLocklevelValue(bVS_Auftrag.VS_Auftrag_Obj,
                                                                             'MMP':U)
            ttUV_VersandBeleg.LocklevelPartLSLSL        = cSetLocklevelValue(cPartObj,
                                                                             'VUL':U)
            ttUV_VersandBeleg.LocklevelPartMMP          = cSetLocklevelValue(cPartObj,
                                                                             'MMP':U)
            ttUV_VersandBeleg.LocklevelCustomerLSLSL    = cSetLocklevelValue(cCustomerObj,
                                                                             'VUL':U)
            ttUV_VersandBeleg.LocklevelCustomerMMP      = cSetLocklevelValue(cCustomerObj,
                                                                             'MMP':U)
            ttUV_VersandBeleg.Mahnstufe                 = iDunningLevel(ttUV_VersandBeleg.Konto)
          .
          
          if ttUV_VersandBeleg.OffeneMenge <= 0 then
          do:

            delete ttUV_VersandBeleg.
            next RepairOrderLine.

          end. /* if ttUV_VersandBeleg.OffeneMenge <= 0 */
          
          find bML_Ort
            where bML_Ort.Firma    = {firma/mlort.fir pACConnectionSvc:prpcCompany}
              and bML_Ort.LagerOrt = bVS_Auftrag.LagerOrt
            no-lock no-error.

          if available bML_Ort then

            ttUV_VersandBeleg.Bestand = dGetPhysicalOnHand(buffer bML_Ort,
                                                           bVS_AuftragPos.ArtikelWartung,
                                                           ttUV_VersandBeleg.ArtVar,
                                                           bVS_AuftragPos.VS_AuftragPos_Obj).
            
          if ttUV_VersandBeleg.CoverageStatus = {&uCI_CoverageStatus_Available} and pa-filter-lCoverageStatus_Available_var  = no then
          do:
            
            delete ttUV_VersandBeleg.
            next RepairOrderLine.
            
          end. /* if   ttUV_VersandBeleg.CoverageStatus = {&uCI_CoverageStatus_Without}     */

          gdExchangeRate  = vert.serv.cls.VSCFillShippingMonitorSvc:prpoInstance:dGetExchangeRate(bVS_Auftrag.Waehrung,
                                                                                                  bVS_Auftrag.Belegdatum,
                                                                                                  bVS_Auftrag.Kunde,
                                                                                                  bVS_Auftrag.VS_Auftrag_Obj).
                                                                                                  
          /* Compute some stuff only if the tt-record can't be deleted anymore. */

          vert.serv.cls.VSCFillShippingMonitorSvc:prpoInstance:FillTTShippingMonitorVSAMiscFields(buffer ttUV_VersandBeleg:handle,
                                                                                                  buffer bVS_Auftrag).
                                                                                                  
          find ttGenerateDemandQtyForService
            where ttGenerateDemandQtyForService.Owning_obj = ttUV_VersandBeleg.Owning_obj
              and ttGenerateDemandQtyForService.Doctype = ttUV_VersandBeleg.Belegart 
            no-lock no-error.
       
          if available ttGenerateDemandQtyForService then
         
            ttUV_VersandBeleg.uCI_DispatchQty = ttGenerateDemandQtyForService.qty.                                                                                                      
              
        end. /* for each bVS_AuftragPos */ 
           
  end. /* or each bVS_Auftrag  */  

end procedure. /* fillRepairOrderPositions */
&ENDIF 

/* _UIB-CODE-BLOCK-END */
&ANALYZE-RESUME

&ENDIF


&IF DEFINED(EXCLUDE-reallocateDemandCoverage) = 0 &THEN

&ANALYZE-SUSPEND _UIB-CODE-BLOCK _PROCEDURE reallocateDemandCoverage Method-Library 
procedure reallocateDemandCoverage :
/* Description ---------------------------------------------------------------*/
/*                                                                            */
/* Reallocate demand/coverage for current entry if not done already.          */
/*                                                                            */
/* Notes ---------------------------------------------------------------------*/
/*                                                                            */
/*                                                                            */
/*                                                                            */
/* Parameters ----------------------------------------------------------------*/
/*                                                                            */
/* pbML_Lagergruppe     buffer for ML_Lagergruppe, used to avoid reloading    */
/* pcS_Artikel_Obj      Object ID of current part                             */
/* ttUV_VersandBeleg is available as a global buffer                          */
/*                                                                            */
/* Examples ------------------------------------------------------------------*/
/*                                                                            */
/*                                                                            */
/*                                                                            */
/*----------------------------------------------------------------------------*/

define parameter buffer       pbML_Lagergruppe for ML_Lagergruppe.
define input        parameter pcS_Artikel_Obj as character     no-undo.
define input        parameter pcArtikel         as character     no-undo.
define input        parameter pcArtVar          as character     no-undo.
define input        parameter piLagergruppe     as integer       no-undo.
define input        parameter piLagergruppeKopf as integer       no-undo.
define input        parameter piLagerort        as integer       no-undo.

/* Variables -----------------------------------------------------------------*/
/*----------------------------------------------------------------------------*/

define variable iLagergruppe as integer       no-undo.

/* Buffers -------------------------------------------------------------------*/

define buffer ML_Ort    for ML_Ort.
define buffer S_Artikel for S_Artikel.

/*----------------------------------------------------------------------------*/
/* Processing                                                                 */
/*----------------------------------------------------------------------------*/

  if pcS_Artikel_Obj = ? then /* Set line */
  do:
    if piLagerort <> ? then
    do:
      find ML_Ort
        where ML_Ort.Firma    = {firma/mlort.fir pACConnectionSvc:prpcCompany}
          and ML_Ort.LagerOrt = piLagerort
        no-lock.
      iLagergruppe = ML_Ort.Lagergruppe.
    end.
    else
      iLagergruppe = piLagergruppeKopf.
  end.
  else
    iLagergruppe = piLagergruppe.

  find ttArtikelVerwendungspruefung
    where ttArtikelVerwendungspruefung.Lagergruppe = iLagergruppe
      and ttArtikelVerwendungspruefung.Artikel     = pcArtikel
      and ttArtikelVerwendungspruefung.ArtVar      = pcArtVar
    no-error.

  if not available ttArtikelVerwendungspruefung then
  do:

    if not available pbML_Lagergruppe
      or pbML_Lagergruppe.Lagergruppe <> iLagergruppe then
      find pbML_Lagergruppe
        where pbML_Lagergruppe.Firma       = {firma/mlort.fir pACConnectionSvc:prpcCompany}
          and pbML_Lagergruppe.Lagergruppe = iLagergruppe
        no-lock.

    if glUCI_ShippingMonitorReallocateAll then
      mawi.base.cls.MMCSchedLoggingSvc:prpoInstance:createLogEntry
        ({&pa_MM_SchedTypeRealloc},
         pbML_Lagergruppe.ML_Lagergruppe_Obj,
         pcArtikel,
         pcArtVar).

    if pcS_Artikel_Obj = ? then
    do:
      find S_Artikel
        where S_Artikel.Firma   = {firma/sartikel.fir pACConnectionSvc:prpcCompany}
          and S_Artikel.Artikel = pcArtikel
        no-lock.
    end.

    goSchedPegging:reallocate((if pcS_Artikel_Obj <> ? then
                                 pcS_Artikel_Obj
                               else
                                 S_Artikel.S_Artikel_Obj),
                              pcArtVar,
                              pbML_Lagergruppe.ML_Lagergruppe_Obj).

    create ttArtikelVerwendungspruefung.
    assign
      ttArtikelVerwendungspruefung.Lagergruppe = iLagergruppe
      ttArtikelVerwendungspruefung.Artikel     = pcArtikel
      ttArtikelVerwendungspruefung.ArtVar      = pcArtVar
    .
    validate ttArtikelVerwendungspruefung.

  end. /* if not available ttArtikelVerwendungspruefung */

end procedure. /* reallocateDemandCoverage */


/* _UIB-CODE-BLOCK-END */
&ANALYZE-RESUME

&ENDIF


&IF DEFINED(EXCLUDE-storeDataset) = 0 &THEN

&ANALYZE-SUSPEND _UIB-CODE-BLOCK _PROCEDURE storeDataset Method-Library 
procedure storeDataset :
/* Description ---------------------------------------------------------------*/
/*                                                                            */
/* Saves changes in the Dataset to DB.                                        */
/*                                                                            */
/* Notes ---------------------------------------------------------------------*/
/*                                                                            */
/*                                                                            */
/*                                                                            */
/* Parameters ----------------------------------------------------------------*/
/*                                                                            */
/* <none>                                                                     */
/*                                                                            */
/* Examples ------------------------------------------------------------------*/
/*                                                                            */
/*                                                                            */
/*                                                                            */
/*----------------------------------------------------------------------------*/
define input-output parameter dataset for dsUVR_CIVersandBeleg.

/* Variables -----------------------------------------------------------------*/
/*----------------------------------------------------------------------------*/

/* Buffers -------------------------------------------------------------------*/
define buffer bttUV_VersandBeleg for temp-table ttUV_VersandBeleg.
define buffer bV_BelegKopf   for V_BelegKopf.
define buffer bV_BelegPos    for V_BelegPos.
define buffer bVU_RA_Abruf   for VU_RA_Abruf.
define buffer bVU_RA_Pos     for VU_RA_Pos.

&IF LOOKUP("VS","{&PA-MODULE}") > 0 &THEN
  define buffer bVS_AuftragMKT for VS_AuftragMKT.
  define buffer bVS_AuftragPos for VS_AuftragPos.
&ENDIF

/*----------------------------------------------------------------------------*/
/* Processing                                                                 */
/*----------------------------------------------------------------------------*/

for each ttUV_VersandBeleg_Old
  on error undo, throw:

  find bttUV_VersandBeleg
    where rowid(bttUV_VersandBeleg) = buffer ttUV_VersandBeleg_Old:after-rowid.

  find bV_BelegKopf
    where bV_BelegKopf.Firma            = {firma/vbelegko.fir pACConnectionSvc:prpcCompany}
      and bV_BelegKopf.BelegArt         = bttUV_VersandBeleg.BelegArt
      and bV_BelegKopf.ReferenzNr       = bttUV_VersandBeleg.ReferenzNr
    exclusive-lock no-wait no-error.

  if locked(bV_BelegKopf) then
  do:

    adm.method.cls.DMCMessageSvc:prpoInstance:lShowMessage
            ('uvvmo00004':U,
              string(bttUV_VersandBeleg.Belegnummer),
              string(bttUV_VersandBeleg.uCI_DispatchQty)).

    next.

  end.
  
  case adm.method.cls.DMCSessionSvc:cOwningTable(bttUV_VersandBeleg.Owning_Obj):

    when 'V_BelegPos':U then
    do:

      find bV_BelegPos
        where bV_BelegPos.V_BelegPos_Obj = bttUV_VersandBeleg.Owning_Obj
        exclusive-lock no-wait no-error.

      if available bV_BelegPos then
        assign
          bV_BelegPos.uCI_DispatchQty        = bttUV_VersandBeleg.uCI_DispatchQty
          bV_BelegPos.uCI_DispatchQtyRemark  = bttUV_VersandBeleg.uCI_DispatchQtyRemark
          .

      if locked(bV_BelegPos) then
      do:
        adm.method.cls.DMCMessageSvc:prpoInstance:lShowMessage
                ('uvvmo00004':U,
                  string(bttUV_VersandBeleg.Belegnummer),
                  string(bttUV_VersandBeleg.uCI_DispatchQty)). 

        find bV_BelegPos
          where bV_BelegPos.V_BelegPos_Obj = bttUV_VersandBeleg.Owning_Obj
          no-lock no-error.

        if available bV_BelegPos then
          assign
            bttUV_VersandBeleg.uCI_DispatchQty       = bV_BelegPos.uCI_DispatchQty       
            bttUV_VersandBeleg.uCI_DispatchQtyRemark = bV_BelegPos.uCI_DispatchQtyRemark 
            .

      end. /* if bV_BelegPos locked */

    end.

    when 'VU_RA_Pos':U then
    do:

      find bVU_RA_Pos
        where bVU_RA_Pos.VU_RA_Pos_Obj = bttUV_VersandBeleg.Owning_Obj
        exclusive-lock no-wait no-error.

      if available bVU_RA_Pos then
      do:

        find bVU_RA_Abruf
          where bVU_RA_Abruf.Firma        = {firma/vbelegko.fir pACConnectionSvc:prpcCompany}
            and bVU_RA_Abruf.BelegArt     = bVU_RA_Pos.BelegArt
            and bVU_RA_Abruf.ReferenzNr   = bVU_RA_Pos.ReferenzNr
            and bVU_RA_Abruf.PositionsNr  = bVU_RA_Pos.PositionsNr
            and bVU_RA_Abruf.AbrufArt     = bVU_RA_Pos.AbrufArt
            and bVU_RA_Abruf.AbrufNr      = bVU_RA_Pos.AbrufNr
          exclusive-lock no-wait no-error.

        find bV_BelegPos
          where bV_BelegPos.Firma         = {firma/vbelegko.fir pACConnectionSvc:prpcCompany}
            and bV_BelegPos.BelegArt      = bVU_RA_Pos.BelegArt
            and bV_BelegPos.ReferenzNr    = bVU_RA_Pos.ReferenzNr
            and bV_BelegPos.lfdNr_SR      = 0
            and bV_BelegPos.Positionsnr   = bVU_RA_Pos.PositionsNr
          exclusive-lock no-wait no-error.

        assign
          bVU_RA_Pos.uCI_DispatchQty        = bttUV_VersandBeleg.uCI_DispatchQty
          bVU_RA_Pos.uCI_DispatchQtyRemark  = bttUV_VersandBeleg.uCI_DispatchQtyRemark
          .

      end.
      else do:

        find bVU_RA_Pos
          where bVU_RA_Pos.VU_RA_Pos_Obj = bttUV_VersandBeleg.Owning_Obj
          no-lock no-error.

        if available bVU_RA_Pos then
          assign
            bttUV_VersandBeleg.uCI_DispatchQty       = bVU_RA_Pos.uCI_DispatchQty        
            bttUV_VersandBeleg.uCI_DispatchQtyRemark = bVU_RA_Pos.uCI_DispatchQtyRemark  
            .
      end. /* else do */

      if locked(bVU_RA_Pos)
        or locked(bVU_RA_Abruf)
        or locked(bV_BelegPos) then
        adm.method.cls.DMCMessageSvc:prpoInstance:lShowMessage
                ('uvvmo00004':U,
                  string(bttUV_VersandBeleg.Belegnummer),
                  string(bttUV_VersandBeleg.uCI_DispatchQty)).

    end.
    
    &IF LOOKUP("VS","{&PA-MODULE}") > 0 &THEN
      when 'VS_AuftragMKT':U then
      do:
        
        find bVS_AuftragMKT
          where bVS_AuftragMKT.VS_AuftragMKT_Obj = bttUV_VersandBeleg.Owning_Obj
          no-lock no-error.
      
        if available bVS_AuftragMKT then
        do:
          
          create ttGenerateDemandQtyForService.
          
          assign 
          
            ttGenerateDemandQtyForService.Doctype    = bttUV_VersandBeleg.Belegart
            ttGenerateDemandQtyForService.Qty        = bttUV_VersandBeleg.uCI_DispatchQty 
            ttGenerateDemandQtyForService.Owning_obj = bVS_AuftragMKT.VS_AuftragMKT_Obj
            .
          
          validate ttGenerateDemandQtyForService.
            
        end. /* if available bVS_AuftragMKT */     
        
      end. /* when 'when 'VS_AuftragMKT'' */
    
      when 'VS_AuftragPos':U then
      do:
        
        find bVS_AuftragPos
          where bVS_AuftragPos.VS_AuftragPos_Obj = bttUV_VersandBeleg.Owning_Obj
          no-lock no-error.
        
          if available bVS_AuftragPos then
          do:
            
            create ttGenerateDemandQtyForService.
            
            assign
             
              ttGenerateDemandQtyForService.Doctype    = bttUV_VersandBeleg.Belegart
              ttGenerateDemandQtyForService.Qty        = bttUV_VersandBeleg.uCI_DispatchQty 
              ttGenerateDemandQtyForService.Owning_obj = bVS_AuftragPos.VS_AuftragPos_Obj
              .
            
            validate ttGenerateDemandQtyForService.
              
          end. /* if available bVS_AuftragPos */     
            
      end. /* when 'VS_AuftragPos' */
    &ENDIF
  end case.

end. /* for each ttUV_VersandBeleg_Old */

end procedure. /* storeDataset */


/* _UIB-CODE-BLOCK-END */
&ANALYZE-RESUME

&ENDIF



/* ************************  Function Implementations ***************** */
&IF DEFINED(EXCLUDE-cErrortext) = 0 &THEN

&ANALYZE-SUSPEND _UIB-CODE-BLOCK _FUNCTION cErrortext Method-Library
function cErrortext returns character
  ( input pcErrorcode as character,
    input pcSubstitute like V_BelegPos.uCI_MessageSubst ):
/* Description ---------------------------------------------------------------*/
/*                                                                            */
/* Substitute values into error message                                       */
/*                                                                            */
/* Parameters ----------------------------------------------------------------*/
/*                                                                            */
/* pcErrorcode     Key for D_Meldung.Meldung                                  */
/* pcSubstitute    Values to substitute into D_MeldungSpr.Meldungstext        */
/*                                                                            */
/*----------------------------------------------------------------------------*/

/* Variables -----------------------------------------------------------------*/
/* cReturnValue  function return value                                        */
/*----------------------------------------------------------------------------*/

define variable cReturnValue as character no-undo.

/* Buffers -------------------------------------------------------------------*/

/*----------------------------------------------------------------------------*/
/* Processing                                                                 */
/*----------------------------------------------------------------------------*/

if not available gbD_MeldungSpr
  or gbD_MeldungSpr.Meldung <> pcErrorcode then
do:

  {adm/incl/d__spr00.if
    &Tabelle  = "gbD_MeldungSpr"
    &Selekt   = "where gbD_MeldungSpr.Meldung = pcErrorcode"
    &Sprache  = "pACConnectionSvc:prpcLanguage"
    &no-error = "no-error"
  }
end.

if available gbD_MeldungSpr then
  cReturnValue =  substitute(gbD_MeldungSpr.MeldungsText,
                         pcSubstitute[1],
                         pcSubstitute[2],
                         pcSubstitute[3],
                         pcSubstitute[4],
                         pcSubstitute[5],
                         pcSubstitute[6],
                         pcSubstitute[7],
                         pcSubstitute[8],
                         pcSubstitute[9]).
else
  cReturnValue = pcErrorcode.

return cReturnValue.

end function. /* cErrortext */

/* _UIB-CODE-BLOCK-END */
&ANALYZE-RESUME

&ENDIF

&IF DEFINED(EXCLUDE-cSetLocklevelValue) = 0 &THEN

&ANALYZE-SUSPEND _UIB-CODE-BLOCK _FUNCTION cSetLocklevelValue Method-Library
function cSetLocklevelValue returns character 
  ( cLockStatusRecordObj as character,
    cTargetArea as character
    ):
/* Description ---------------------------------------------------------------*/
/*                                                                            */
/* Set the lock level status                                                  */
/*                                                                            */
/* Notes ---------------------------------------------------------------------*/
/*                                                                            */
/*                                                                            */
/*                                                                            */
/* Parameters ----------------------------------------------------------------*/
/*                                                                            */
/* <none>                                                                     */
/*                                                                            */
/* Examples ------------------------------------------------------------------*/
/*                                                                            */
/*                                                                            */
/*                                                                            */
/*----------------------------------------------------------------------------*/

/* Variables -----------------------------------------------------------------*/
/* cReturnValue  function return value                                        */
/*----------------------------------------------------------------------------*/

define variable cReturnValue as character no-undo.

/* Buffers -------------------------------------------------------------------*/

define buffer bttUV_LockStatus for temp-table ttUV_LockStatus.

/*----------------------------------------------------------------------------*/
/* Processing                                                                 */
/*----------------------------------------------------------------------------*/    

find bttUV_LockStatus
  where bttUV_LockStatus.LockStatusRecordObj  = cLockStatusRecordObj
    and bttUV_LockStatus.TargetArea           = cTargetArea
  no-error.

if available bttUV_LockStatus then
  cReturnValue = bttUV_LockStatus.LockStatus.

else
do:

  case basis.buro.cls.BBCWorkflowSvc:prpoInstance:cLockStatusKey
         (cLockStatusRecordObj,                  
          cTargetArea):
    when 'info':U then
      cReturnValue = 'I':U.
    when 'lock':U then
      cReturnValue = 'S':U.
    when 'warn':U then
      cReturnValue = 'W':U.
    otherwise
      cReturnValue = 'o':U.

  end case.

  create bttUV_LockStatus.

  assign
    bttUV_LockStatus.LockStatusRecordObj  = cLockStatusRecordObj
    bttUV_LockStatus.TargetArea           = cTargetArea
    bttUV_LockStatus.LockStatus           = cReturnValue
    .

end. /* else available ttUV_LockStatus */

return cReturnValue.

end function. /* cSetLocklevelValue */

/* _UIB-CODE-BLOCK-END */
&ANALYZE-RESUME

&ENDIF


&IF DEFINED(EXCLUDE-dGetPhysicalOnHand) = 0 &THEN

&ANALYZE-SUSPEND _UIB-CODE-BLOCK _FUNCTION dGetPhysicalOnHand Method-Library
function dGetPhysicalOnHand returns decimal
  ( buffer pbML_Ort   for ML_Ort,
           pcPart     like S_artikel.Artikel,
           pcPartType like V_BelegPos.ArtVar,
           pcOrigin   as character
    ):
/* Description ---------------------------------------------------------------*/
/*                                                                            */
/*  calculate physical on hand                                                */
/*                                                                            */
/* Notes ---------------------------------------------------------------------*/
/*                                                                            */
/*                                                                            */
/*                                                                            */
/* Parameters ----------------------------------------------------------------*/
/*                                                                            */
/* pbML_Ort     buffer for ML_Ort                                             */
/* pcPart       Part                                                          */
/* pcPartType   PartType                                                      */
/* pcOrigin     Origin                                                        */
/*                                                                            */
/* Examples ------------------------------------------------------------------*/
/*                                                                            */
/*                                                                            */
/*                                                                            */
/*----------------------------------------------------------------------------*/

/* Variables -----------------------------------------------------------------*/

/*----------------------------------------------------------------------------*/

define variable dOnHand          as decimal no-undo.
define variable dPhysicalOnHand  as decimal extent {&pa_ML_PhysicalOnHandExtent} no-undo.
define variable dStockTypes      as decimal extent {&pa_ML_TypesOfInventoryExtent} no-undo.

/* Buffers -------------------------------------------------------------------*/
define buffer bML_KommZone        for ML_KommZone.
define buffer bMLM_PickPriority   for MLM_PickPriority.
/*----------------------------------------------------------------------------*/
/* Processing                                                                 */
/*----------------------------------------------------------------------------*/
/* calculate on-hand in staging zone */

find first bML_KommZone
  where bML_KommZone.Firma            = {firma/mlort.fir pACConnectionSvc:prpcCompany}
    and can-find(first bMLM_PickPriority
                 where bMLM_PickPriority.ML_KommZone_Obj = bML_KommZone.ML_KommZone_Obj
                   and bMLM_PickPriority.ML_Ort_Obj      = pbML_Ort.ML_Ort_Obj)
  use-index PickAreaPriority
  no-lock no-error.

if available bML_KommZone then
do:

  find ttBestandKommzone
    where ttBestandKommzone.Kommzone = bML_KommZone.KommZone
      and ttBestandKommzone.Artikel  = pcPart
    no-error.

  if available ttBestandKommzone then
    dOnHand = ttBestandKommzone.Bestand.
  else
  do:

    for each bMLM_PickPriority
      where bMLM_PickPriority.ML_KommZone_Obj = bML_KommZone.ML_KommZone_Obj
      no-lock
      on error undo, throw:

      dPhysicalOnHand = mawi.lager.cls.MLCOnHandInvSvc:prpoInstance:dOnHandStArea(pcPart,
                                                                                  '':U, /* Part Variant   */
                                                                                  bMLM_PickPriority.ML_Ort_Obj,
                                                                                  '':U, /* LOT ('' = ANY) */
                                                                                  ?     /* CRO (?  = ANY) */
                                                                                  ).

      if glMM_PickSafetyStock = no then

        dStockTypes = mawi.lager.cls.MLCPartStAreaSvc:prpoInstance:dStorPartDataStArea
                        (pcPart,
                         pcPartType,
                         bMLM_PickPriority.ML_Ort_Obj,
                         yes).      /* Nettable only ? */

      else
        dStockTypes = 0.

      dOnHand = dOnHand
                + dPhysicalOnHand[{&pa_ML_OnHandNettable}]
                - dStockTypes [{&pa_ML_SafetyStock}].

      if glUCI_ReservationsInOnhand then
        dOnHand = dOnHand
                  - dPhysicalOnHand[{&pa_ML_OnHandReservedNettable}]
                  + mawi.base.cls.MMCReservationSvc:prpoInstance:dReviewReservationQty
                      (pcOrigin, bMLM_PickPriority.ML_Ort_Obj, '':U).

    end. /* for each bMLM_PickPriority */

    dPhysicalOnHand = mawi.lager.cls.MLCOnHandInvSvc:prpoInstance:dOnHandStArea(pcPart,
                                                                                '':U, /* Part Variant   */
                                                                                bML_KommZone.ML_Ort_Obj,
                                                                                '':U, /* LOT ('' = ANY) */
                                                                                ?     /* CRO (?  = ANY) */
                                                                                ).

    if glMM_PickSafetyStock = no then

      dStockTypes = mawi.lager.cls.MLCPartStAreaSvc:prpoInstance:dStorPartDataStArea
                      (pcPart,
                       pcPartType,
                       bML_KommZone.ML_Ort_Obj,
                       yes).      /* Nettable only ? */

    else
      dStockTypes = 0.

    dOnHand = dOnHand
              + dPhysicalOnHand[{&pa_ML_OnHandNettable}]
              - dPhysicalOnHand[{&pa_ML_OnHandReservedNettable}]
              - dStockTypes [{&pa_ML_SafetyStock}].

    create ttBestandKommzone.
    assign
      ttBestandKommzone.Kommzone = bML_KommZone.KommZone
      ttBestandKommzone.Artikel  = pcPart
      ttBestandKommzone.Bestand  = dOnHand
    .
    validate ttBestandKommzone.

  end. /* else */

end. /* available bML_KommZone */
else
do:

  find ttOnHandStorageArea
    where ttOnHandStorageArea.StorageArea = pbML_Ort.Lagerort
      and ttOnHandStorageArea.Part        = pcPart
    no-error.

  if available ttOnHandStorageArea then
    dOnHand = ttOnHandStorageArea.OnHand.
  else
  do:

    dPhysicalOnHand = mawi.lager.cls.MLCOnHandInvSvc:prpoInstance:dOnHandStArea(pcPart,
                                                                                '':U, /* Part Variant   */
                                                                                pbML_Ort.ML_Ort_Obj,
                                                                                '':U, /* LOT ('' = ANY) */
                                                                                ?     /* CRO (?  = ANY) */
                                                                                ).

    if glMM_PickSafetyStock = no then

      dStockTypes = mawi.lager.cls.MLCPartStAreaSvc:prpoInstance:dStorPartDataStArea
                      (pcPart,
                       pcPartType,
                       pbML_Ort.ML_Ort_Obj,
                       yes).      /* Nettable only ? */

    else
      dStockTypes = 0.

    dOnHand = dOnHand
              + dPhysicalOnHand[{&pa_ML_OnHandNettable}]
              - dStockTypes [{&pa_ML_SafetyStock}].

    if glUCI_ReservationsInOnhand then
      dOnHand = dOnHand
                - dPhysicalOnHand[{&pa_ML_OnHandReservedNettable}]
                + mawi.base.cls.MMCReservationSvc:prpoInstance:dReviewReservationQty
                    (pcOrigin, pbML_Ort.ML_Ort_Obj, '':U).

    create ttOnHandStorageArea.
    assign
      ttOnHandStorageArea.StorageArea = pbML_Ort.LagerOrt
      ttOnHandStorageArea.Part        = pcPart
      ttOnHandStorageArea.OnHand      = dOnHand
    .
    validate ttOnHandStorageArea.

  end. /* else */
end.

return dOnHand.

end function. /* dGetPhysicalOnHand */

/* _UIB-CODE-BLOCK-END */
&ANALYZE-RESUME

&ENDIF

&IF DEFINED(EXCLUDE-iDunningLevel) = 0 &THEN

&ANALYZE-SUSPEND _UIB-CODE-BLOCK _FUNCTION iDunningLevel Method-Library
function iDunningLevel returns integer 
  ( piCustomer like S_Kunde.Kunde ):
/* Description ---------------------------------------------------------------*/
/*                                                                            */
/* Get the highest dunning level of a customer                                */
/*                                                                            */
/* Notes ---------------------------------------------------------------------*/
/*                                                                            */
/*                                                                            */
/*                                                                            */
/* Parameters ----------------------------------------------------------------*/
/*                                                                            */
/* piCustomer - customer                                                      */
/*                                                                            */
/* Examples ------------------------------------------------------------------*/
/*                                                                            */
/*                                                                            */
/*                                                                            */
/*----------------------------------------------------------------------------*/

/* Variables -----------------------------------------------------------------*/
/* iReturnValue  function return value                                        */
/*----------------------------------------------------------------------------*/

define variable iReturnValue as integer no-undo.

/* Buffers -------------------------------------------------------------------*/

&IF lookup("FO":U,"{&pa-Module}":U) > 0 &THEN
  define buffer bttUV_DunningLevel    for temp-table ttUV_DunningLevel.
  define buffer bFO_MahnKopf          for FO_MahnKopf.
&ENDIF


/*----------------------------------------------------------------------------*/
/* Processing                                                                 */
/*----------------------------------------------------------------------------*/    

&IF lookup("FO":U,"{&pa-Module}":U) > 0 &THEN

  find bttUV_DunningLevel
    where bttUV_DunningLevel.Customer = piCustomer
    no-error.

  if available bttUV_DunningLevel then

    iReturnValue = bttUV_DunningLevel.DunningLevel.

  else
  do:

    find last bFO_MahnKopf
        where bFO_MahnKopf.Firma    = {firma/fbbuchu.fir pACConnectionSvc:prpcCompany}
          and bFO_MahnKopf.Konto    = piCustomer
          and bFO_MahnKopf.gedruckt = yes
          use-index Konto
        no-lock no-error.

      if available bFO_MahnKopf then
        iReturnValue = bFO_MahnKopf.Mahnstufe.

    create bttUV_DunningLevel.

    assign
      bttUV_DunningLevel.Customer       = piCustomer
      bttUV_DunningLevel.DunningLevel   = iReturnValue
      .

  end. /* else available bttUV_DunningLevel */

&ENDIF

return iReturnValue.

end function. /* iDunningLevel */

/* _UIB-CODE-BLOCK-END */
&ANALYZE-RESUME

&ENDIF

