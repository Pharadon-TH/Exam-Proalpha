&ANALYZE-SUSPEND _VERSION-NUMBER UIB_v8r2 GUI
&ANALYZE-RESUME

&ANALYZE-SUSPEND _UIB-CODE-BLOCK _CUSTOM _DECLARATIONS V-table-Win 

/* _UIB-CODE-BLOCK-END */
&ANALYZE-RESUME

&ANALYZE-SUSPEND _UIB-CODE-BLOCK _XFTR "Update Information" Procedure _INLINE
/* Actions: ? ? ? ? adm/support/proc/ds_pa_01.w */

/* _UIB-CODE-BLOCK-END */
&ANALYZE-RESUME

&ANALYZE-SUSPEND _UIB-CODE-BLOCK _CUSTOM _DEFINITIONS Procedure
/******************************************************************************/
/* @COPYRIGHT@                                                                */
/* Project: Proalpha                                                          */
/*                                                                            */
/* Name   : ppjpwo00.p                                                        */
/* Product: PPS - Produktionsplanung & -steuerung                             */
/* Module : PROD - Produktion                                                 */
/*                                                                            */
/* Created: 6.2c04 as of 09.02.2016/Frank Eimer                               */
/* Current: @PAVERSION@ as of @PADATE@/@PALASTAUTHOR@                         */
/*                                                                            */
/*----------------------------------------------------------------------------*/
/* DESCRIPTION                                                                */
/*----------------------------------------------------------------------------*/
/*                                                                            */
/* DAO f�r das Drucken der Laufkarte �ber List und Label (Data Access Object) */
/*                                                                            */
/*----------------------------------------------------------------------------*/
/* PARAMETERS                                                                 */
/*----------------------------------------------------------------------------*/
/* Name                      Description                                      */
/*----------------------------------------------------------------------------*/
/*                                                                            */
/*----------------------------------------------------------------------------*/
/* HISTORY                                                                    */
/*----------------------------------------------------------------------------*/
/* @FILEHISTORY@                                                              */
/******************************************************************************/

/* Procedure Information -----------------------------------------------------*/

&GLOBAL-DEFINE pa-Autor             Frank Eimer
&GLOBAL-DEFINE pa-Version           @PAVERSION@
&GLOBAL-DEFINE pa-Datum             @PADATE@
&GLOBAL-DEFINE pa-Letzter           @PALASTAUTHOR@

&GLOBAL-DEFINE pa-GenVersion       OEA
&GLOBAL-DEFINE pa-ProgrammTyp      DataAccessObject
&GLOBAL-DEFINE pa-Template         padataaccessobject.pjet
&GLOBAL-DEFINE pa-TemplateVersion  3.00
&GLOBAL-DEFINE pa-XBasisName       ppjpwo00_p
&GLOBAL-DEFINE pa-NameSpace        2.00

/*----------------------------------------------------------------------------*/
/* Definitions                                                                */
/*----------------------------------------------------------------------------*/

/* Parameters ----------------------------------------------------------------*/

/* Globals -------------------------------------------------------------------*/

{adm/template/incl/dt_dao00.df}

/* SCOPEDs -------------------------------------------------------------------*/

/* Definitions for printing the Partusage section                             */
/* pa_pp_PartUasgeMaxDepth defines the Maximum distance/depth of work order   */
/* pa_pp_PartUsageCurrentNoFormatStr format for a single CurrentNo element    */

&scoped-define  pa_pp_PartUasgeMaxDepth             4
&scoped-define  pa_pp_PartUsageCurrentNoFormatStr  '9999':U

/* Variables -----------------------------------------------------------------*/
/*----------------------------------------------------------------------------*/

define variable giZeitfaktor     as integer      no-undo extent 3  init [1,60,3600].

/* Buffers -------------------------------------------------------------------*/

define temp-table TT_B_DruckZeile no-undo like TD_B_DruckZeile. /* code checked by Eimer_F 20.06.2016 */

/* Datasets ------------------------------------------------------------------*/

{pps/prod/incl/pp_pwo00.pds}

/* _UIB-CODE-BLOCK-END */
&ANALYZE-RESUME


&ANALYZE-SUSPEND _UIB-PREPROCESSOR-BLOCK

/* ********************  Preprocessor Definitions  ******************** */

&Scoped-define PROCEDURE-TYPE Procedure
&Scoped-define DB-AWARE no



/* _UIB-PREPROCESSOR-BLOCK-END */
&ANALYZE-RESUME

/* ************************  Function Prototypes ********************** */

&IF LOOKUP("M_APS":U,"{&PA-OPTIONEN}":U) > 0 &THEN

&IF DEFINED(EXCLUDE-lIsBomLineAssignedToOperation) = 0 &THEN

&ANALYZE-SUSPEND _UIB-CODE-BLOCK _FUNCTION-FORWARD lIsBomLineAssignedToOperation V-table-Win
function lIsBomLineAssignedToOperation returns logical
  ( buffer bPP_StkZeile for PP_StkZeile ) forward.

/* _UIB-CODE-BLOCK-END */
&ANALYZE-RESUME

&ENDIF
&ENDIF /* M_APS */

&IF LOOKUP("M_APS":U,"{&PA-OPTIONEN}":U) > 0 &THEN
&IF DEFINED(EXCLUDE-lSkipBOMLinePrintGroupChecks) = 0 &THEN

&ANALYZE-SUSPEND _UIB-CODE-BLOCK _FUNCTION-FORWARD lSkipBOMLinePrintGroupChecks V-table-Win
function lSkipBOMLinePrintGroupChecks returns logical
  ( buffer bPP_StkZeile for PP_StkZeile,
    pcReportType          as character,
    pcPrintGroup          as character,
    piActivityPositionMin as integer,
    piActivityPositionMax as integer ) forward.

/* _UIB-CODE-BLOCK-END */
&ANALYZE-RESUME

&ENDIF
&ENDIF /* M_APS */


/* *********************** Procedure Settings ************************ */

&ANALYZE-SUSPEND _PROCEDURE-SETTINGS
/* Settings for THIS-PROCEDURE
   Type: Procedure
   Allow:
   Frames: 0
   Add Fields to: Neither
   Other Settings: CODE-ONLY
 */
&ANALYZE-RESUME _END-PROCEDURE-SETTINGS

/* *************************  Create Window  ************************** */

&ANALYZE-SUSPEND _CREATE-WINDOW
/* DESIGN Window definition (used by the UIB)
  CREATE WINDOW Procedure ASSIGN
         HEIGHT             = 6.95
         WIDTH              = 50.4.
/* END WINDOW DEFINITION */
                                                                        */
&ANALYZE-RESUME

&ANALYZE-SUSPEND _UIB-CODE-BLOCK _CUSTOM _INCLUDED-LIB Procedure
/* ************************* Included-Libraries *********************** */

{adm/method/incl/dm_dao00.lib}
{pps/prod/incl/pp_arp01.lib}

/* _UIB-CODE-BLOCK-END */
&ANALYZE-RESUME

&ANALYZE-SUSPEND _UIB-CODE-BLOCK _CUSTOM _MAIN-BLOCK Procedure

/* ***************************  Main Block  *************************** */

/*----------------------------------------------------------------------------*/
/* Processing                                                                 */
/*----------------------------------------------------------------------------*/

/* _UIB-CODE-BLOCK-END */
&ANALYZE-RESUME



/* **********************  Internal Procedures  *********************** */


&IF DEFINED(EXCLUDE-BestimmeTeileVerwendung) = 0 &THEN

&ANALYZE-SUSPEND _UIB-CODE-BLOCK _PROCEDURE BestimmeTeileVerwendung Method-Library 
procedure BestimmeTeileVerwendung :
/* Description ---------------------------------------------------------------*/
/*                                                                            */
/* BestimmeTeileVerwendung                                                    */
/*                                                                            */
/* Notes ---------------------------------------------------------------------*/
/*                                                                            */
/*                                                                            */
/*                                                                            */
/* Parameters ----------------------------------------------------------------*/
/*                                                                            */
/* pcPP_Auftrag_Obj                                                           */
/* piCurrentDepth                                                             */
/* pcCurrentNo                                                                */
/* piLineCounter                                                              */
/*                                                                            */
/* Examples ------------------------------------------------------------------*/
/*                                                                            */
/*                                                                            */
/*                                                                            */
/*----------------------------------------------------------------------------*/
define input parameter pcPP_Auftrag_Obj          as character     no-undo.
define input        parameter piCurrentDepth     as integer       no-undo.
define input        parameter pcCurrentNo        as character     no-undo.
define input        parameter piLineCounter      as integer       no-undo.

/* Variables -----------------------------------------------------------------*/
/*----------------------------------------------------------------------------*/
define variable cAssociatedActivity  as character                 no-undo.

/* Buffers -------------------------------------------------------------------*/

/* Buffers -------------------------------------------------------------------*/
define buffer bPP_Auftrag                    for PP_Auftrag.
define buffer bPP_Auftrag-Assembly           for PP_Auftrag.
define buffer bPP_StkZeile                   for PP_StkZeile.
define buffer bMB_Aktivitaet-Draw            for MB_Aktivitaet.
define buffer bM_Ressource-Draw              for M_Ressource.
define buffer bM_RessourceSpr-Draw           for M_RessourceSpr.
define buffer bS_ArtikelSpr                  for S_ArtikelSpr.

/*----------------------------------------------------------------------------*/
/* Processing                                                                 */
/*----------------------------------------------------------------------------*/

if piCurrentDepth > {&pa_pp_PartUasgeMaxDepth} then
  leave.


find bPP_Auftrag
  where bPP_Auftrag.PP_Auftrag_Obj = pcPP_Auftrag_Obj
  no-lock no-error.

if available bPP_Auftrag
  and bPP_Auftrag.nicht_erster then
do:

  for each bPP_StkZeile
    where bPP_StkZeile.Firma           = bPP_Auftrag.Firma
      and bPP_StkZeile.Artikel         = bPP_Auftrag.Artikel
      and bPP_StkZeile.ArtVar          = bPP_Auftrag.ArtVar
      and bPP_StkZeile.Auftrag         = bPP_Auftrag.Auftrag
      and bPP_StkZeile.Baugruppenfolge = bPP_Auftrag.Baugruppenfolge
    no-lock:

    create ttPP_PartUsage-P.

    ttPP_PartUsage-P.PP_Auftrag_Obj = bPP_Auftrag.PP_Auftrag_Obj.

    find bPP_Auftrag-Assembly
      where bPP_Auftrag-Assembly.Firma        = bPP_StkZeile.Firma
        and bPP_Auftrag-Assembly.RueckMeldeNr = bPP_StkZeile.RueckMeldeNr
      no-lock.

    {adm/incl/d__spr00.if
      &Tabelle  = "bS_ArtikelSpr"
      &Selekt   =
        "where bS_ArtikelSpr.firma = ~{firma/sartikel.fir pACConnectionSvc:prpcCompany~}
           and bS_ArtikelSpr.Artikel = bPP_Auftrag-Assembly.Artikel"
      &Sprache  = pACConnectionSvc:prpcLanguage
      }

    cAssociatedActivity = pps.prod.cls.PPCProdBomLineSvc:prpoInstance:cGetAssociatedActivity(bPP_StkZeile.PP_StkZeile_Obj).

    if cAssociatedActivity <> ? then
    do:

      find bMB_Aktivitaet-Draw
        where bMB_Aktivitaet-Draw.MB_Aktivitaet_Obj = cAssociatedActivity
        no-lock no-error.

      if available bMB_Aktivitaet-Draw then
      do:

        assign
          ttPP_PartUsage-P.Activity = bMB_Aktivitaet-Draw.Aktivitaet
          ttPP_PartUsage-P.ActPos   = bMB_Aktivitaet-Draw.AktPos
          .

        find bM_Ressource-Draw
          where bM_Ressource-Draw.Firma     = {firma/mawi.fir pACConnectionSvc:prpcCompany}
            and bM_Ressource-Draw.RessArt   = bMB_Aktivitaet-Draw.BasisRessArt
            and bM_Ressource-Draw.Ressource = bMB_Aktivitaet-Draw.BasisRessource
          no-lock no-error.

        if available bM_Ressource-Draw then
        do:

          assign
            ttPP_PartUsage-P.BaseResource     = bM_Ressource-Draw.Ressource
            ttPP_PartUsage-P.ResourceLocation = bM_Ressource-Draw.Platz
            .

          {adm/incl/d__spr00.if
            &Tabelle  = "bM_RessourceSpr-Draw"
            &SelektOf = "of bM_Ressource-Draw"
            &Sprache  = pACConnectionSvc:prpcLanguage
          }

          if available bM_RessourceSpr-Draw then
            ttPP_PartUsage-P.BaseResourceDesc = bM_RessourceSpr-Draw.Bezeichnung.

        end. /* if available bM_Ressource-Draw  */

      end. /* if available bMB_Aktivitaet-Draw  */

    end. /* cAssociatedActivity <> ?  */

    assign
      piLineCounter                     = piLineCounter + 1
      pcCurrentNo                       = (if piCurrentDepth = 1 then
                                             '':U
                                           else
                                             substring(pcCurrentNo,1,(piCurrentDepth - 1) * length({&pa_pp_PartUsageCurrentNoFormatStr})))
      pcCurrentNo                       = pcCurrentNo + string(piLineCounter,{&pa_pp_PartUsageCurrentNoFormatStr})
      ttPP_PartUsage-P.iLevelCounter    = piCurrentDepth
      ttPP_PartUsage-P.CurrentNo        = pcCurrentNo
      ttPP_PartUsage-P.Structure        = (if piCurrentDepth < 10 then
                                             fill('.':U,piCurrentDepth - 1) + string(piCurrentDepth,'9':U)
                                           else
                                             '........':U + string(piCurrentDepth,'99':U))
      ttPP_PartUsage-P.PartUsage        = bPP_Auftrag-Assembly.Artikel
      ttPP_PartUsage-P.PartUsageDesc    = bS_ArtikelSpr.Bezeichnung
      ttPP_PartUsage-P.DataEntryNumber  = bPP_Auftrag-Assembly.RueckMeldeNr
      ttPP_PartUsage-P.AssemblySequence = bPP_Auftrag-Assembly.BaugruppenFolge
      ttPP_PartUsage-P.PP_Auftrag_ID    = bPP_Auftrag-Assembly.Auftrag

      .

    run BestimmeTeileVerwendung in target-procedure (bPP_Auftrag-Assembly.PP_Auftrag_Obj,
                                                     piCurrentDepth + 1,
                                                     pcCurrentNo,
                                                     piLineCounter).
  end. /*  for each bPP_StkZeile */

end. /* available bPP_Auftrag and bPP_Auftrag.nicht_erster then */

end procedure. /* BestimmeTeileVerwendung */


/* _UIB-CODE-BLOCK-END */
&ANALYZE-RESUME

&ENDIF


&IF DEFINED(EXCLUDE-CopyPP_StkZeile) = 0 &THEN

&ANALYZE-SUSPEND _UIB-CODE-BLOCK _PROCEDURE CopyPP_StkZeile Method-Library
procedure CopyPP_StkZeile :
/* Description ---------------------------------------------------------------*/
/*                                                                            */
/* PP_StkZeile was only available from activity. To make it available from    */
/* Auftrag ttPP_StkZeile-PWO was created and it is a copy of ttPP_StkZeile-P  */
/*                                                                            */
/* Notes ---------------------------------------------------------------------*/
/*                                                                            */
/*                                                                            */
/*                                                                            */
/* Parameters ----------------------------------------------------------------*/
/*                                                                            */
/* <none>                                                                     */
/*                                                                            */
/* Examples ------------------------------------------------------------------*/
/*                                                                            */
/*                                                                            */
/*                                                                            */
/*----------------------------------------------------------------------------*/

/* Variables -----------------------------------------------------------------*/
/*----------------------------------------------------------------------------*/

/* Buffers -------------------------------------------------------------------*/

define buffer bttPP_StkZeile-P             for temp-table ttPP_StkZeile-P.
define buffer bttPP_StkZeile-PWO           for temp-table ttPP_StkZeile-PWO.
define buffer bttML_Ort-PBOM               for temp-table ttML_Ort-PBOM.
define buffer bttML_Ort-PWO                for temp-table ttML_Ort-PWO.
define buffer bttMML_ValueStorage-P1BOM    for temp-table ttMML_ValueStorage-P1BOM.
define buffer bttMML_ValueStorage-P1WO     for temp-table ttMML_ValueStorage-P1WO.
define buffer bttS_Artikel-P               for temp-table ttS_Artikel-P.
define buffer bttS_Artikel-PWOStkZ         for temp-table ttS_Artikel-PWOStkZ.
define buffer bttS_ArtVar-P                for temp-table ttS_ArtVar-P.
define buffer bttS_ArtVar-PWOStkZ          for temp-table ttS_ArtVar-PWOStkZ.
define buffer bttS_MengenEinheit-P1StkZ    for temp-table ttS_MengenEinheit-P1StkZ.
define buffer bttS_MengenEinheit-P1WOStkZ  for temp-table ttS_MengenEinheit-P1WOStkZ.
define buffer bttS_MengenEinheit-P1StkZL   for temp-table ttS_MengenEinheit-P1StkZL.
define buffer bttS_MengenEinheit-P1WOStkZL for temp-table ttS_MengenEinheit-P1WOStkZL.
define buffer bttS_ArtikelArt-P1           for temp-table ttS_ArtikelArt-P1.
define buffer bttS_ArtikelArt-P1WOStkZ     for temp-table ttS_ArtikelArt-P1WOStkZ.
define buffer bttP_ZeichnungArtikel-P2     for temp-table ttP_ZeichnungArtikel-P2.
define buffer bttP_ZeichnungArtikel-P2WO   for temp-table ttP_ZeichnungArtikel-P2WO.
define buffer bttSBM_ValueFlowGroup-P1      for temp-table ttSBM_ValueFlowGroup-P1.
define buffer bttSBM_ValueFlowGroup-P1WOStk for temp-table ttSBM_ValueFlowGroup-P1WOStk.

&IF LOOKUP("MP":U,"{&PA-MODULE}":U) > 0 &THEN

  define buffer bttMP_ArtRes-P               for temp-table ttMP_ArtRes-P.
  define buffer bttMP_ArtRes-PWO             for temp-table ttMP_ArtRes-PWO.

&ENDIF

&IF LOOKUP("MC":U,"{&PA-MODULE}":U) > 0 &THEN

  define buffer bttMCL_LotMovements-P        for temp-table ttMCL_LotMovements-P.
  define buffer bttMCL_LotMovements-PWO      for temp-table ttMCL_LotMovements-PWO.

&ENDIF

/*----------------------------------------------------------------------------*/
/* Processing                                                                 */
/*----------------------------------------------------------------------------*/

for each bttPP_StkZeile-P
  no-lock
  on error undo, throw:

  create bttPP_StkZeile-PWO.

  {buffer-copy
     bttPP_StkZeile-P
     to bttPP_StkZeile-PWO
     assign
       "bttPP_StkZeile-PWO.Firma = pACConnectionSvc:prpcCompany"}

end. /* for each PP_StkZeile-P */

&IF LOOKUP("MC":U,"{&PA-MODULE}":U) > 0 &THEN

  for each bttMCL_LotMovements-P
    no-lock
    on error undo, throw:

    create bttMCL_LotMovements-PWO.

    {buffer-copy
       bttMCL_LotMovements-P
       to bttMCL_LotMovements-PWO
       assign
         "bttMCL_LotMovements-PWO.Company = pACConnectionSvc:prpcCompany"}

  end. /* for each MCL_LotMovements */

&ENDIF

&IF LOOKUP("MP":U,"{&PA-MODULE}":U) > 0 &THEN

  for each bttMP_ArtRes-P
    no-lock
    on error undo, throw:

    create bttMP_ArtRes-PWO.

    {buffer-copy
       bttMP_ArtRes-P
       to bttMP_ArtRes-PWO
       assign
         "bttMP_ArtRes-PWO.Firma = pACConnectionSvc:prpcCompany"}

  end. /* for each bttMP_ArtRes-P */

&ENDIF

for each bttML_Ort-PBOM
  no-lock
  on error undo, throw:

  create bttML_Ort-PWO.

  {buffer-copy
     bttML_Ort-PBOM
     to bttML_Ort-PWO
     assign
       "bttML_Ort-PWO.Firma  = pACConnectionSvc:prpcCompany"}

end. /* for each bttML_Ort-PBOM */

for each bttMML_ValueStorage-P1BOM
  no-lock
  on error undo, throw:

  create bttMML_ValueStorage-P1WO.

  {buffer-copy
     bttMML_ValueStorage-P1BOM
     to bttMML_ValueStorage-P1WO}

end. /* for each bttMML_ValueStorage-P1BOM */

for each bttP_ZeichnungArtikel-P2
  no-lock
  on error undo, throw:

  create bttP_ZeichnungArtikel-P2WO.

  {buffer-copy
     bttP_ZeichnungArtikel-P2
     to bttP_ZeichnungArtikel-P2WO
     assign
       "bttP_ZeichnungArtikel-P2WO.Firma = pACConnectionSvc:prpcCompany"}

end. /* for each bttP_ZeichnungArtikel-P2 */

for each bttS_Artikel-P
  no-lock
  on error undo, throw:

  create bttS_Artikel-PWOStkZ.

  {buffer-copy
     bttS_Artikel-P
     to bttS_Artikel-PWOStkZ
     assign
       "bttS_Artikel-PWOStkZ.Firma = pACConnectionSvc:prpcCompany"}

end. /* for each bttS_Artikel-P */

for each bttS_MengenEinheit-P1StkZ
  no-lock
  on error undo, throw:

  create bttS_MengenEinheit-P1WOStkZ.

  {buffer-copy
     bttS_MengenEinheit-P1StkZ
     to bttS_MengenEinheit-P1WOStkZ
     assign
       "bttS_MengenEinheit-P1WOStkZ.Firma = pACConnectionSvc:prpcCompany"}

end. /* for each bttS_MengenEinheit-P1StkZ */

for each bttS_ArtikelArt-P1
  no-lock
  on error undo, throw:

  create bttS_ArtikelArt-P1WOStkZ.

  {buffer-copy
     bttS_ArtikelArt-P1
     to bttS_ArtikelArt-P1WOStkZ}

end. /* for each bttS_ArtikelArt-P1 */

for each bttS_ArtVar-P
  no-lock
  on error undo, throw:

  create bttS_ArtVar-PWOStkZ.

  {buffer-copy
     bttS_ArtVar-P
     to bttS_ArtVar-PWOStkZ}

end. /* for each bttS_ArtVar-P */

for each bttS_MengenEinheit-P1StkZL
  no-lock
  on error undo, throw:

  create bttS_MengenEinheit-P1WOStkZL.

  {buffer-copy
     bttS_MengenEinheit-P1StkZL
     to bttS_MengenEinheit-P1WOStkZL
     assign
       "bttS_MengenEinheit-P1WOStkZL.Firma  = pACConnectionSvc:prpcCompany"}

end. /* for each bttS_MengenEinheit-P1StkZL */

for each bttSBM_ValueFlowGroup-P1
  no-lock
  on error undo, throw:

  create bttSBM_ValueFlowGroup-P1WOStk.

  {buffer-copy
     bttSBM_ValueFlowGroup-P1
     to bttSBM_ValueFlowGroup-P1WOStk
     assign
       "bttSBM_ValueFlowGroup-P1WOStk.Company = pACConnectionSvc:prpcCompany"}

end. /* for each bttSBM_ValueFlowGroup-P1 */

end procedure. /* CopyPP_StkZeile */


/* _UIB-CODE-BLOCK-END */
&ANALYZE-RESUME

&ENDIF


&IF DEFINED(EXCLUDE-fillDataset) = 0 &THEN

&ANALYZE-SUSPEND _UIB-CODE-BLOCK _PROCEDURE fillDataset Method-Library 
procedure fillDataset :
/* Description ---------------------------------------------------------------*/
/*                                                                            */
/* Fills the dataset.                                                         */
/*                                                                            */
/* Notes ---------------------------------------------------------------------*/
/*                                                                            */
/*                                                                            */
/*                                                                            */
/* Parameters ----------------------------------------------------------------*/
/*                                                                            */
/* dsBBM_WflBusinessProcess-P  The dataset.                                   */
/*                                                                            */
/* Examples ------------------------------------------------------------------*/
/*                                                                            */
/*                                                                            */
/*                                                                            */
/*----------------------------------------------------------------------------*/

define input-output parameter dataset for dsPP_Auftrag-P.

/* Variables -----------------------------------------------------------------*/
/*----------------------------------------------------------------------------*/

define variable cPKS                            as character no-undo.
define variable cFillMode                       as character no-undo.
define variable cContentLanguage                as character no-undo.
define variable cPP_Auftrag_Obj                 as character no-undo.
define variable iRMNR                           as integer   no-undo.
define variable cDruckGruppe                    as character no-undo.
define variable lSingleOrderOnly                as logical   no-undo.
define variable cActivitySelection              as character no-undo.
define variable iStorageAreaSelection           as integer   no-undo.
define variable cReportType                     as character no-undo.
define variable iActPos_min                     as integer   no-undo.
define variable iActPos_max                     as integer   no-undo.
define variable lOnlyOpenOperations             as logical   no-undo.
define variable iBOMPos_min                     as integer   no-undo.
define variable iBOMPos_max                     as integer   no-undo.
define variable lBOMAssociationAvailable        as logical   no-undo.
define variable lPrintActWithoutBOMAssociations as logical   no-undo.
define variable lPrintSDMRQEvenIfPosted         as logical   no-undo.
define variable lPrintRequisEvenIfPosted        as logical   no-undo.
define variable cFormeltext                     as character format 'x(20)':U extent 3 no-undo.
define variable iNumberOfJointProducts          as integer no-undo.

define variable iAnzahlTextZeilen               as integer   init 65 no-undo.
define variable cBomRowID                       as character no-undo.
define variable cWOArea                         as character no-undo.
define variable iAktWiederholfaktor             as integer   init 1 no-undo.
define variable iAktZaehler                     as integer   no-undo.
define variable cBomCoverageQty                 as character no-undo.
define variable lCalculateWOScrapQty            as logical   no-undo.
define variable lCalculateWOFinishedQty         as logical   no-undo.
define variable lCalculateOperationScrapQty     as logical   no-undo.

&IF LOOKUP("SB-QM-Production":U,"{&PA-OPTIONEN}":U) > 0 &THEN
define variable cCheckState_Keys                as character no-undo.
define variable cCheckState_Desc                as character no-undo.
define variable dQMQuantities                   as decimal extent 3 no-undo.
&ENDIF

/* Buffers -------------------------------------------------------------------*/

define buffer bPP_Auftrag                for PP_Auftrag.
define buffer bPP_Auftrag-Head           for PP_Auftrag.
&IF LOOKUP("MS","{&PA-MODULE}") > 0 &THEN
  define buffer bMSL_SerialNoRef         for MSL_SerialNoRef.
  define buffer bMS_SNR                  for MS_SNR.
&ENDIF
define buffer bPP_Auftrag-UA             for PP_Auftrag.
define buffer bPMM_BomHeadMaster         for PMM_BomHeadMaster.

define buffer bPPT_OrderPart             for PPT_OrderPart.
define buffer bPP_StkZeile               for PP_StkZeile.
define buffer bMB_Aktivitaet             for MB_Aktivitaet.
define buffer bPP_MatRess                for PP_MatRess.
define buffer bS_Lohnart                 for S_Lohnart.
define buffer bS_Artikel-PartVarType     for S_Artikel.                 /*to fill the Field PartVariantType */
define buffer bMLM_StorPartData          for MLM_StorPartData.
define buffer bV_BelegPos                for V_BelegPos.
define buffer bVU_RA_Pos                 for VU_RA_Pos.
define buffer bMMM_CusRefOrder           for MMM_CusRefOrder.
define buffer bDBM_ShortDescription      for DBM_ShortDescription.
define buffer bP_ZeichnungArtikel        for P_ZeichnungArtikel.
define buffer bPMM_Drawing               for PMM_Drawing.
define buffer bS_Kunde                   for S_Kunde.
define buffer bS_ArtKunde                for S_ArtKunde.
define buffer bM_LTPos                   for M_LTPos.

/* --> MO#MULA-LBr-0928 thongdi.p 14/07/2026 L&L - Laufkarte um Verpackungsmengeneinheit erweitern */
define buffer bS_ArtME                   for S_ArtME.
define buffer bttS_ArtME-P               for temp-table ttS_ArtME-P.
/* <-- MO#MULA-LBr-0928 thongdi.p 14/07/2026 L&L - Laufkarte um Verpackungsmengeneinheit erweitern */

define buffer bttPP_Auftrag-p            for temp-table ttPP_Auftrag-p.
&IF LOOKUP("MS","{&PA-MODULE}") > 0 &THEN
  define buffer bttMSL_SerialNoRef       for temp-table ttMSL_SerialNoRef.
  define buffer bttMS_SNR-P              for temp-table ttMS_SNR-P.
&ENDIF
define buffer bttPPT_OrderPart-P1        for temp-table ttPPT_OrderPart-P1.
define buffer bttMML_ValueStorage-P1     for temp-table ttMML_ValueStorage-P1.
define buffer bttM_Prioritaet-P          for temp-table ttM_Prioritaet-P.
define buffer bttBB_Vorgangskette-P      for temp-table ttBB_Vorgangskette-P.
define buffer bttS_AuftragsArt-P         for temp-table ttS_AuftragsArt-P.
define buffer bttML_Ort-P                for temp-table ttML_Ort-P.
define buffer bttS_Adresse-P8            for temp-table ttS_Adresse-P8.
define buffer bttPP_Zeichnung-P          for temp-table ttPP_Zeichnung-P.
define buffer bttPP_Zeichnung-PJP        for temp-table ttPP_Zeichnung-PJP.
define buffer bttPP_StkZeile-P           for temp-table ttPP_StkZeile-P.
define buffer bttMB_Aktivitaet-P         for temp-table ttMB_Aktivitaet-P.
define buffer bttS_Adresse-P31           for temp-table ttS_Adresse-P31.
define buffer bttMB_Ressource-P          for temp-table ttMB_Ressource-P.
define buffer bttS_Kostenstelle-P22      for temp-table ttS_Kostenstelle-P22.
define buffer bttM_Ressource-P           for temp-table ttM_Ressource-P.
define buffer bttS_Kostenstelle-P22Base  for temp-table ttS_Kostenstelle-P22BaseRes.
define buffer bttM_Ressource-PBase       for temp-table ttM_Ressource-PBaseRes.
define buffer bttMCL_LotMovements-P      for temp-table ttMCL_LotMovements-P.
define buffer bttMP_ArtRes-P             for temp-table ttMP_ArtRes-P.
define buffer bttS_Artikel-PWO           for temp-table ttS_Artikel-PWO.
define buffer bttS_ArtVar-PWO            for temp-table ttS_ArtVar-PWO.
define buffer bttS_MengenEinheit-P1      for temp-table ttS_MengenEinheit-P1.
define buffer bttS_ArtikelArt-P1WO       for temp-table ttS_ArtikelArt-P1WO.
define buffer bttSBM_ValueFlowGroup-P1WO for temp-table ttSBM_ValueFlowGroup-P1WO.
define buffer bttS_Artikel-PAct          for temp-table ttS_Artikel-PAct.
define buffer bttS_MengenEinheit-P1Act   for temp-table ttS_MengenEinheit-P1Act.
define buffer bttS_ArtikelArt-P1Act      for temp-table ttS_ArtikelArt-P1Act.
define buffer bttMML_ValueStorage-P1Act  for temp-table ttMML_ValueStorage-P1Act.
define buffer bttSBM_ValueFlowGroup-P1Act for temp-table ttSBM_ValueFlowGroup-P1Act.
define buffer bttS_MengenEinheit-P1StkZ  for temp-table ttS_MengenEinheit-P1StkZ.
define buffer bttML_Ort-PBOM             for temp-table ttML_Ort-PBOM.
define buffer bttMML_ValueStorage-P1BOM  for temp-table ttMML_ValueStorage-P1BOM.
define buffer bttS_Artikel-P             for temp-table ttS_Artikel-P.
define buffer bttS_ArtVar-P              for temp-table ttS_ArtVar-P.
define buffer bttSBM_ValueFlowGroup-P1   for temp-table ttSBM_ValueFlowGroup-P1.
define buffer bttS_MengenEinheit-P1StkZL for temp-table ttS_MengenEinheit-P1StkZL.
define buffer bttS_ArtikelArt-P1         for temp-table ttS_ArtikelArt-P1.
define buffer bttS_Artikel-PJP           for temp-table ttS_Artikel-PJP.
define buffer bttS_ArtVar-PJP            for temp-table ttS_ArtVar-PJP.
define buffer bttS_ArtikelArt-P1JP       for temp-table ttS_ArtikelArt-P1JP.
define buffer bttS_MengenEinheit-P1JP    for temp-table ttS_MengenEinheit-P1JP.
define buffer bttSBM_ValueFlowGroup-P1JP for temp-table ttSBM_ValueFlowGroup-P1JP.
define buffer bttP_ZeichnungArtikel-P2   for temp-table ttP_ZeichnungArtikel-P2.
define buffer bttS_Kunde-P6              for temp-table ttS_Kunde-P6.
define buffer bttS_ArtKunde-P            for temp-table ttS_ArtKunde-P.
/*---------------------------------------------------------------------------*/
/* Processing                                                                 */
/*----------------------------------------------------------------------------*/

{&{&pa-XBasisName}_C_FillDatasetStart}
{&{&pa-XBasisName}_U_FillDatasetStart}
{&{&pa-XBasisName}_Q_FillDatasetStart}
{&{&pa-XBasisName}_FillDatasetStart}
{&{&pa-XBasisName}_Y_FillDatasetStart}

cFillMode = adm.method.cls.DMCSessionSvc:cGetObjectProperty
              (dataset dsPP_Auftrag-P:handle,
               'FillMode':U).

if cFillMode = 'LLConfig':U then
  /* Create default data records when starting the List & Label designer.     */
  adm.repos.cls.DRCDataProviderSvc:prpoInstance:generateDummyRecords(dataset dsPP_Auftrag-P:get-top-buffer(1)).

else
do
  transaction
    on error  undo, throw
    on endkey undo, retry
    on stop   undo, retry:

  /* errorhandling for endkey and Stop condition because these errors are */
  /* not handled by the exception handling -> throw error manually!       */
  if retry then
    adm.method.cls.DMCMessageSvc:prpoInstance:showError('pprue00004':U).   

  assign
    /* values from PKS */
    cContentLanguage                = adm.method.cls.DMCSessionSvc:cGetObjectProperty
                                        (dataset dsPP_Auftrag-P:handle,
                                         'ContentLanguage':U)
    cPKS                            = adm.method.cls.DMCSessionSvc:cGetObjectPropertyPKS
                                        (dataset dsPP_Auftrag-P:handle,
                                         'Context':U)

    /* ACM parameters */
    lPrintActWithoutBOMAssociations = adm.config.cls.DCCAppConfigSvc:prpoInstance:lParameterValue
                                        ('PP_MixedRequisWithAllOprL':U)
    lPrintSDMRQEvenIfPosted         = adm.config.cls.DCCAppConfigSvc:prpoInstance:lParameterValue
                                        ('PP_PrintSDMRQEvenIfPosted':U)
    lPrintRequisEvenIfPosted        = adm.config.cls.DCCAppConfigSvc:prpoInstance:lParameterValue
                                        ('PP_PrintRequisEvenIfPosted':U)

    lSingleOrderOnly                = adm.method.cls.DMCParameterStringSvc:lReadValue
                                       (cPKS,
                                        'SingleOrderOnly':U,
                                        1)
    cReportType                     = adm.method.cls.DMCParameterStringSvc:cReadValue
                                        (cPKS,
                                         'ReportType':U,
                                         1)
    /* if you want, that only one single Bomline has to be printed            */
    /* then you have to give the rowid of this PP_StkZeile                    */
    /* in parameter BomRowID                                                  */
    cBomRowID                       = adm.method.cls.DMCParameterStringSvc:cReadValue
                                        (cPKS,
                                         'BomRowID':U,
                                           1)

    /* coverage quantity (Deckungsmenge) for the BomRow                       */
    cBomCoverageQty                 = adm.method.cls.DMCParameterStringSvc:cReadValue
                                        (cPKS,
                                         'BomDeckungsmenge':U,
                                         1)
    &IF LOOKUP("SB-QM-Production":U,"{&PA-OPTIONEN}":U) > 0 &THEN
      cCheckState_Keys              = adm.config.cls.DCCAppConfigSvc:prpoInstance:cParameterValue
                                        ('SB_QualityCheckState_keys':U,
                                         ',':U)
      cCheckState_Desc              = adm.config.cls.DCCAppConfigSvc:prpoInstance:cParameterValue
                                        ('SB_QualityCheckState_desc':U,
                                         ',':U)
    &ENDIF
    lCalculateWOScrapQty            = can-do(adm.repos.cls.DRCDataProviderSvc:prpoInstance:cGetUsedAndEssentialFieldsForTable
                                               ('bttPP_Auftrag-P':U),
                                             'Ausschussmenge':U)
    lCalculateWOFinishedQty         = can-do(adm.repos.cls.DRCDataProviderSvc:prpoInstance:cGetUsedAndEssentialFieldsForTable
                                               ('bttPP_Auftrag-P':U),
                                             'Fertigmenge':U)
    lCalculateOperationScrapQty     = can-do(adm.repos.cls.DRCDataProviderSvc:prpoInstance:cGetUsedAndEssentialFieldsForTable
                                               ('bttMB_Aktivitaet-P':U),
                                             'Ausschussmenge':U)
    .

  /* if you want to print a single order and do not have any further filter   */
  /* information, then you have to set the filter variables to minimum and/or */
  /* maximum values                                                           */
  /*--------------------------------------------------------------------------*/

  if lSingleOrderOnly then
  do:

    cPP_Auftrag_Obj                 = adm.method.cls.DMCParameterStringSvc:cReadValue
                                        (cPKS,
                                         'PP_Auftrag_Obj':U,
                         1).

    find bPP_Auftrag
      where bPP_Auftrag.PP_Auftrag_Obj = cPP_Auftrag_Obj
      no-lock no-error.

    if not available bPP_Auftrag then
      return.

    assign
      iRMNR                 = bPP_Auftrag.RueckMeldeNr
      cDruckGruppe          = ?
      cActivitySelection    = ?
      iStorageAreaSelection = ?
      iActPos_min           = 0
      iActPos_max           = 9999
      lOnlyOpenOperations   = no
      iBOMPos_min           = 0
      iBOMPos_max           = 999999
      .



  end. /* if lSingleOrderOnly */
  else
  do:

    assign
      iRMNR                 = integer(adm.method.cls.DMCParameterStringSvc:cReadValue
                                       (cPKS,
                                        'RMNR':U,
                                        1))
      cDruckGruppe          = adm.method.cls.DMCParameterStringSvc:cReadValue
                                (cPKS,
                                 'DruckGruppe':U,
                                 1)
      cActivitySelection    = adm.method.cls.DMCParameterStringSvc:cReadValue
                                (cPKS,
                                 'ActivityObjSelection':U,
                                 1)
      iStorageAreaSelection = adm.method.cls.DMCParameterStringSvc:iReadValue
                                (cPKS,
                                 'StorageAreaSelection':U,
                                 1)
      iActPos_min           = adm.method.cls.DMCParameterStringSvc:iReadValue
                                (cPKS,
                                 'AktPos':U,
                                 1)
      iActPos_min           = (if iActPos_min = ? then
                                 0
                               else
                                 iActPos_min)                                 
      iActPos_max           = adm.method.cls.DMCParameterStringSvc:iReadValue
                                (cPKS,
                                 'AktPos':U,
                                 2)
      iActPos_max           = (if iActPos_max = ? then
                                 99999
                               else
                                 iActPos_max)                                 
      lOnlyOpenOperations   = adm.method.cls.DMCParameterStringSvc:lReadValue
                                (cPKS,
                                 'lOnlyOpenOperations':U,
                                 1)
      iBOMPos_min           = adm.method.cls.DMCParameterStringSvc:iReadValue
                                (cPKS,
                                 'Position':U,
                                 1)
      iBOMPos_min           = (if iBOMPos_min = ? then
                                 0
                               else
                                 iBOMPos_min)  
      iBOMPos_max           = adm.method.cls.DMCParameterStringSvc:iReadValue
                                (cPKS,
                                 'Position':U,
                                 2)
      iBOMPos_max           = (if iBOMPos_max = ? then
                                 999999
                               else
                                 iBOMPos_max) 
      .

    find bPP_Auftrag
      where bPP_Auftrag.Firma        = {firma/ppauftra.fir pACConnectionSvc:prpcCompany}
        and bPP_Auftrag.RueckMeldeNr = iRMNR
      no-lock no-error.

    if not available bPP_Auftrag then
      return.

  end. /* else if lSingleOrderOnly */

  /* Start the accumulation. If the accumulation was started from previous    */
  /* operations the existing status is saved and replaced with the new status */
  /* of this operation. the old status is reset when the current operation is */
  /* finished.                                                                */

  pps.prod.cls.PPCProductionMaterialServiceWrapperSvc:prpoInstance:startAccumulation
   ({&pa_PP_AccumulationUseCase_PrintWO},
    bPP_Auftrag.PP_Auftrag_Obj).  

  cWOArea = pps.prod.cls.PPCProdWorkOrderSvc:prpoInstance:cGetArea(buffer bPP_Auftrag).

  /*----------------------------------------------------------------------*/
  /* Load Number of textlines to print                                    */
  /*----------------------------------------------------------------------*/

  find bPMM_BomHeadMaster
    where bPMM_BomHeadMaster.Company = {firma/pps.fir pACConnectionSvc:prpcCompany}
      and bPMM_BomHeadMaster.BomType = 'production':u
      and bPMM_BomHeadMaster.Part = bPP_Auftrag.Artikel
      and bPMM_BomHeadMaster.PartVariant = bPP_Auftrag.ArtVar
    no-lock no-error.

  if available bPMM_BomHeadMaster then
    case cReportType:

      when 'LK':u then /* Laufkarte */
        iAnzahlTextZeilen =  bPMM_BomHeadMaster.No_OpTextLines_JT.

      when 'SMS':u then /* Sammelmaterialschein */
        iAnzahlTextZeilen =  bPMM_BomHeadMaster.No_OpTextLines_MRQ.

      when 'LS':u then /* Lohnschein */
        iAnzahlTextZeilen =  bPMM_BomHeadMaster.No_OpTextLines_TT.

      when 'RS':u then /* R�ckmeldeschein */
        iAnzahlTextZeilen =  bPMM_BomHeadMaster.No_OpTextLines_DET.

      when 'SMF':u then /* Sammelmaterialschein fremd */
        iAnzahlTextZeilen =  bPMM_BomHeadMaster.No_OpTextLines_MRQE.

    end case.

  assign
    cReportType  = '':U when cReportType  = ?
    .

  adm.method.cls.DMCSessionSvc:setObjectProperty
    (dataset dsPP_Auftrag-P:handle,
     'MainTableOID':U,
     bPP_Auftrag.PP_Auftrag_Obj).

  /* Collect data.                                                          */

  /* First create the main record                                           */

  create bttPP_Auftrag-p.
  {buffer-copy
     bPP_Auftrag
     to bttPP_Auftrag-p
     assign
       "bttPP_Auftrag-p.Firma                    = pACConnectionSvc:prpcCompany
        bttPP_Auftrag-p.Order_MMM_CusRefOrder_ID = pps.prod.api.cls.PPCProdWorkOrderApi:Instance:cGetCRONumber(buffer bPP_Auftrag)
        bttPP_Auftrag-P.Ausschussmenge           = (if lCalculateWOScrapQty then
                                                      pps.base.cls.PMCScrapSvc:prpoInstance:dGetWorkOrderScrapQtyComplete (buffer bPP_Auftrag)
                                                    else
                                                      0)
        bttPP_Auftrag-P.Fertigmenge              = (if lCalculateWOFinishedQty then
                                                      pps.prod.cls.PPCProdWorkOrderSvc:prpoInstance:dGetFinishedQty (buffer bPP_Auftrag)
                                                    else
                                                      0)
        bttPP_Auftrag-P.OrderPartPosition        = 0"}

  adm.method.cls.DMCSessionSvc:setObjectProperty
    (dataset dsPP_Auftrag-P:handle,
     'Specialist':U,
     bttPP_Auftrag-p.Sachbearbeiter). 

  /* set the manufacturing status                                             */

  bttPP_Auftrag-p.MfgStatusLng = pps.prod.cls.PPCProdWorkOrderSvc:prpoInstance:cGetManufacturingStatus(bttPP_Auftrag-p.FertigungsStand).

  /* Lade Beschreibung zur Kommissionsnummer                                  */
  find bMMM_CusRefOrder
    where bMMM_CusRefOrder.Company =  {firma/mkommis.fir pACConnectionSvc:prpcCompany}
      and bMMM_CusRefOrder.MMM_CusRefOrder_ID = bttPP_Auftrag-p.Order_MMM_CusRefOrder_ID
    no-lock no-error.

  if available bMMM_CusRefOrder then
  do:

    {adm/incl/d__spr00.if
      &Tabelle  = "bDBM_ShortDescription"
      &Selekt   = "where bDBM_ShortDescription.Owning_Obj = bMMM_CusRefOrder.MMM_CusRefOrder_Obj"
      &Sprache  = pACConnectionSvc:prpcLanguage
    }

    if available bDBM_ShortDescription then
      bttPP_Auftrag-p.Order_MMM_CusRefOrder_ID_Desc = bDBM_ShortDescription.ShortDesc1.

  end.

  /* load the MasterPart Record to fill the PartVariantType                   */

  find bS_Artikel-PartVarType
    where bS_Artikel-PartVarType.Firma   = {firma/sartikel.fir pACConnectionSvc:prpcCompany}
      and bS_Artikel-PartVarType.Artikel = bttPP_Auftrag-P.Artikel
    no-lock.

  find bMLM_StorPartData
    where bMLM_StorPartData.Company     = pACConnectionSvc:prpcCompany
      and bMLM_StorPartData.Part        = bttPP_Auftrag-P.Artikel
      and bMLM_StorPartData.ArtVar      = bttPP_Auftrag-P.ArtVar
      and bMLM_StorPartData.Storagearea = bttPP_Auftrag-P.Lagerort
    no-lock no-error.

  /*----------------------------------------------------------------------------*/
  /* additional fields for production work order                                */
  /*----------------------------------------------------------------------------*/

  find first bPP_Auftrag-Head
    where bPP_Auftrag-Head.Firma        = {firma/ppauftra.fir pACConnectionSvc:prpcCompany}
      and bPP_Auftrag-Head.Auftrag      = bPP_Auftrag.Auftrag
      and bPP_Auftrag-Head.nicht_erster = no
    no-lock.

  assign
    /* cls for variant part */
    bttPP_Auftrag-P.ClassificationOwnerPV_Obj  = (if bPP_Auftrag-Head.BelegNummer > 0 then
                                                    bPP_Auftrag-Head.Coverage_Obj
                                                  else
                                                    bPP_Auftrag-Head.PP_Auftrag_Obj)
    bttPP_Auftrag-P.ClassificationSystemPV     = bPP_Auftrag-Head.SMLeiste
    bttPP_Auftrag-P.PartVariantType            = bS_Artikel-PartVarType.ArtVarTyp

    &IF LOOKUP("MS":U,"{&PA-MODULE}":U) > 0 &THEN
      /* serial numbers as text */
      bttPP_Auftrag-P.SerialNoAsText            = mawi.serie.cls.MSCSerialNoSvc:prpoInstance:clCreateSerialNoAsText
                                                    (bPP_Auftrag.PP_Auftrag_Obj,
                                                     yes)
    &ENDIF

    bttPP_Auftrag-P.StorageLocation = (if available bMLM_StorPartData then
                                         bMLM_StorPartData.StorageInfo
                                       else
                                         '':u)
    .

  &IF LOOKUP("SB-QM-Production":U,"{&PA-OPTIONEN}":U) > 0 &THEN

    find bPPT_OrderPart
      where bPPT_OrderPart.owning_Obj        = bttPP_Auftrag-P.PP_Auftrag_Obj
        and bPPT_OrderPart.OrderPartPosition = 0
      no-lock.

    assign
      dQMQuantities                    = stamm.base.cls.SBCQualityCheckSvc:prpoInstance:dCalculateQtyForDocument
                                           (bttPP_Auftrag-P.PP_Auftrag_Obj)
      bttPP_Auftrag-P.QMOKQty          = dQMQuantities[1]
      bttPP_Auftrag-P.QMNotOKQty       = dQMQuantities[2]
      bttPP_Auftrag-P.QMConditionalQty = dQMQuantities[3]
      bttPP_Auftrag-P.QMRelevant       = stamm.base.cls.SBCQualityCheckSvc:prpoInstance:lIsWorkOrderPartQMrelevant
                                           (bttPP_Auftrag-P.PP_Auftrag_Obj)
      bttPP_Auftrag-P.QMCheckState     = stamm.base.cls.SBCQualityCheckSvc:prpoInstance:cGetCurrentCheckStateForDocument
                                           (bPPT_OrderPart.PPT_OrderPart_Obj) 
      bttPP_Auftrag-P.QMCheckState     = entry(lookup(bttPP_Auftrag-P.QMCheckState,cCheckState_Keys),cCheckState_Desc)
      .

  &ENDIF

  /*-------------------------------------------------------------------------*/
  /* Fill serial numbers from PP_Auftrag                                     */
  /*-------------------------------------------------------------------------*/

&IF LOOKUP("MS","{&PA-MODULE}") > 0 &THEN

  for each bMSL_SerialNoRef
     where bMSL_SerialNoRef.Origin_Obj = bttPP_Auftrag-P.PP_Auftrag_Obj
     no-lock
     on error undo, throw:

     if not can-find(bttMSL_SerialNoRef
                       where bttMSL_SerialNoRef.Origin_Obj         = bMSL_SerialNoRef.Origin_Obj
                         and bttMSL_SerialNoRef.MS_SNR_Obj         = bMSL_SerialNoRef.MS_SNR_Obj
                         and bttMSL_SerialNoRef.MSL_SerialNoRef_ID = bMSL_SerialNoRef.MSL_SerialNoRef_ID) then
     do:

       create bttMSL_SerialNoRef.

       {buffer-copy
          bMSL_SerialNoRef
          to bttMSL_SerialNoRef
          assign
            "bttMSL_SerialNoRef.Company = pACConnectionSvc:prpcCompany"}

     end. /* if not can-find(bttMSL_SerialNoRef */

     find bMS_SNR
       where bMS_SNR.Firma        = {firma/mssnr.fir pACConnectionSvc:prpcCompany}
         and bMS_SNR.SNRArt       = bMSL_SerialNoRef.SerialNumberCat
         and bMS_SNR.Seriennummer = bMSL_SerialNoRef.SerialNumber
     no-lock no-error.

     if    available bMS_SNR
       and not can-find(bttMS_SNR-P
                          where bttMS_SNR-P.Firma        = {firma/mssnr.fir pACConnectionSvc:prpcCompany}
                            and bttMS_SNR-P.SNRArt       = bMSL_SerialNoRef.SerialNumberCat
                            and bttMS_SNR-P.Seriennummer = bMSL_SerialNoRef.SerialNumber )then
     do:

       create bttMS_SNR-P.

       {buffer-copy
          bMS_SNR
          to bttMS_SNR-P
          assign
            "bttMS_SNR-P.Firma = pACConnectionSvc:prpcCompany"}

     end. /* if    available bMS_SNR */

  end. /* for each bMSL_SerialNoRef */
&ENDIF

  /*-------------------------------------------------------------------------*/
  /* Lade wenn m�glich die Belegposition                                     */
  /*-------------------------------------------------------------------------*/

  find bV_BelegPos
    where bV_BelegPos.V_BelegPos_Obj = bttPP_Auftrag-P.Coverage_Obj
    no-lock no-error.

  if not available bV_BelegPos then
  do:  

    find bVU_RA_Pos
      where bVU_RA_Pos.VU_RA_Pos_Obj = bttPP_Auftrag-P.Coverage_Obj
      no-lock no-error.

    if available bVU_RA_Pos then
      find bV_BelegPos
        where bV_BelegPos.Firma       = {firma/vbelegko.fir pACConnectionSvc:prpcCompany}
          and bV_BelegPos.Belegart    = 'VUA':U
          and bV_BelegPos.ReferenzNr  = bVU_RA_Pos.ReferenzNr
          and bV_BelegPos.lfdNr_SR    = 0
          and bV_BelegPos.PositionsNr = bVU_RA_Pos.PositionsNr
        no-lock no-error.

  end. /* else if available bV_BelegPos */

  if available bV_BelegPos then
    bttPP_Auftrag-P.VBELP_Text = basis.text.cls.BTCTextSvc:prpoinstance:clLoadText
                                  (pACConnectionSvc:prpcCompany,
                                   'VBELP':U,
                                   bV_BelegPos.V_BelegPos_Obj,
                                   {&PA_DEFAULTSPRACHE}).

  /*----------------------------------------------------------------------*/
  /* work order values                                                    */
  /*----------------------------------------------------------------------*/

  {pps/prod/incl/ppjpwo00.if
    &bttPP_Auftrag-P        = "bPP_Auftrag"
    &bttMML_ValueStorage-P  = "bttMML_ValueStorage-P1"
    &bttM_Prioritaet-P      = "bttM_Prioritaet-P"
    &bttBB_Vorgangskette-P  = "bttBB_Vorgangskette-P"
    &bttS_AuftragsArt-P     = "bttS_AuftragsArt-P"
    &bttML_Ort-P            = "bttML_Ort-P"
    &bttS_Adresse-P         = "bttS_Adresse-P8"
    }

  /*----------------------------------------------------------------------*/
  /* Load Part and Part Variant Informations                              */
  /*----------------------------------------------------------------------*/

  {pps/base/incl/pmjpwo01.if
    &Artikel                 = "bttPP_Auftrag-P.Artikel"
    &ArtVarTyp               = "bttPP_Auftrag-P.PartVariantType"
    &ArtVar                  = "bttPP_Auftrag-P.ArtVar"
    &bttS_ArtVar-P           = "bttS_ArtVar-PWO"
    &bttS_Artikel-P          = "bttS_Artikel-PWO"
    &bttS_MengenEinheit-P    = "bttS_MengenEinheit-P1"
    &bttS_ArtikelArt-P       = "bttS_ArtikelArt-P1WO"
    &bttSBM_ValueFlowGroup-P = "bttSBM_ValueFlowGroup-P1WO"
    }
    
  /* --> MO#MULA-LBr-0928 thongdi.p 14/07/2026 L&L - Laufkarte um Verpackungsmengeneinheit erweitern */      
  /*----------------------------------------------------------------------*/
  /* Load Packaging Unit (Verpackungsmengeneinheit) - Haupt-VME           */
  /*----------------------------------------------------------------------*/
  
  find first bS_ArtME
    where bS_ArtME.Firma    = {firma/sartikel.fir pACConnectionSvc:prpcCompany}
      and bS_ArtME.Artikel  = bttPP_Auftrag-P.Artikel
      and bS_ArtME.HauptVME = yes
    no-lock no-error.
    
  if available bS_ArtME
    and not can-find(bttS_ArtME-P
                       where bttS_ArtME-P.Firma   = pACConnectionSvc:prpcCompany
                         and bttS_ArtME-P.Artikel = bS_ArtME.Artikel) then
  do:
    create bttS_ArtME-P.
    {buffer-copy
       bS_ArtME
       to bttS_ArtME-P
       assign
         "bttS_ArtME-P.Firma = pACConnectionSvc:prpcCompany"}
  end.
  /* <-- MO#MULA-LBr-0928 thongdi.p 14/07/2026 L&L - Laufkarte um Verpackungsmengeneinheit erweitern */
  
  &IF LOOKUP("M_PACK-PLUS":U,"{&PA-OPTIONEN}":U) > 0 &THEN

    find first bPPT_OrderPart
      where bPPT_OrderPart.Owning_Obj = bPP_Auftrag.PP_Auftrag_Obj
      no-lock no-error.

    if available bPPT_OrderPart then

      assign
        bttPP_Auftrag-P.FillQuantity = bPPT_OrderPart.FillQuantity
        bttPP_Auftrag-P.Weight       = bPPT_OrderPart.Weight
        .

  &ENDIF

  /* Kuppelprodukte (joint products) */
  iNumberOfJointProducts = 0.

  JointProductLoop:
  for each bPPT_OrderPart
    where bPPT_OrderPart.Company    = {firma/ppauftra.fir pACConnectionSvc:prpcCompany}
      and bPPT_OrderPart.Owning_Obj = bPP_Auftrag.PP_Auftrag_Obj
    no-lock:

    create bttPPT_OrderPart-P1.
    {buffer-copy
       bPPT_OrderPart
       to bttPPT_OrderPart-P1
       assign
         "bttPPT_OrderPart-P1.Company = pACConnectionSvc:prpcCompany"}

  &IF LOOKUP("SB-QM-Production":U,"{&PA-OPTIONEN}":U) > 0 &THEN
    assign
      dQMQuantities                        = stamm.base.cls.SBCQualityCheckSvc:prpoInstance:dCalculateQtyForDocument
                                               (bPPT_OrderPart.PPT_OrderPart_Obj)
      bttPPT_OrderPart-P1.QMOKQty          = dQMQuantities[1]
      bttPPT_OrderPart-P1.QMNotOKQty       = dQMQuantities[2]
      bttPPT_OrderPart-P1.QMConditionalQty = dQMQuantities[3]
      bttPPT_OrderPart-P1.QMRelevant       = stamm.base.cls.SBCQualityCheckSvc:prpoInstance:lIsPartQMrelevant
                                               (bPPT_OrderPart.Company,
                                                bPPT_OrderPart.Part,
                                                {&pa_SB_QM_CheckArea-WorkOrder})
                                             and bPP_Auftrag.CheckTimeQM <> {&pa_PM_QM_CheckTime-None}
      bttPPT_OrderPart-P1.QMCheckState     = stamm.base.cls.SBCQualityCheckSvc:prpoInstance:cGetCurrentCheckStateForDocument
                                               (bPPT_OrderPart.PPT_OrderPart_Obj) 
      bttPPT_OrderPart-P1.QMCheckState     = entry(lookup(bttPPT_OrderPart-P1.QMCheckState,cCheckState_Keys),cCheckState_Desc)
      bttPPT_OrderPart-P1.RueckmeldeNr     = bPP_Auftrag.RueckMeldeNr
      .
  &ENDIF

    /* Zeichnungen ... */
    {pps/prod/incl/ppjpwo05.if
      &bttPP_Auftrag-P    = "bPP_Auftrag"
      &bttPP_Zeichnung-P  = "bttPP_Zeichnung-PJP"
      &OrderPartPosition  = "bPPT_OrderPart.OrderPartPosition"
      }

    /* load the MasterPart Record to fill the PartVariantType                   */

    find bS_Artikel-PartVarType
      where bS_Artikel-PartVarType.Firma   = {firma/sartikel.fir pACConnectionSvc:prpcCompany}
        and bS_Artikel-PartVarType.Artikel = bPPT_OrderPart.Part
      no-lock.

    /*------------------------------------------------------------------------*/
    /* additional fields for joint product                                    */
    /*------------------------------------------------------------------------*/

    assign
      bttPPT_OrderPart-P1.PartVariantType = bS_Artikel-PartVarType.ArtVarTyp

      bttPPT_OrderPart-P1.TotalQuantity   = bPPT_OrderPart.QtyPerJointProduct * (if available bPP_Auftrag then
                                                                                bPP_Auftrag.Produktionsmenge
                                                                              else
                                                                                ?)
      bttPPT_OrderPart-P1.PercentageShareOperation = pps.prod.cls.PPCOrderPartSvc:prpoInstance:dGetOperationFactor(bPPT_OrderPart.PPT_OrderPart_Obj)
                                                     * 100
      bttPPT_OrderPart-P1.PercentageShareMaterial  = pps.prod.cls.PPCOrderPartSvc:prpoInstance:dGetMaterialFactor(bPPT_OrderPart.PPT_OrderPart_Obj)
                                                     * 100
      /* z�hle die Kuppelprodukte ... */
      iNumberOfJointProducts              = iNumberOfJointProducts + 1
      .

    find first bM_LTPos
      where bM_LTPos.Firma                = {firma/mlartort.fir pACConnectionSvc:prpcCompany}
        and bM_LTPos.Bereich              = 'P':U
        and bM_LTPos.Funktion             = {&pa_MM_PackagingInstruction}
        and bM_LTPos.Herk_BelegArt2       = 'PPA':U
        and bM_LTPos.Herk_Schluessel2     = bPPT_OrderPart.PPT_OrderPart_Obj
        and bM_LTPos.Herk_BelegArt3       = 'PPA':U
        and bM_LTPos.Herk_Schluessel3     = bPPT_OrderPart.PPT_OrderPart_Obj
        and bM_LTPos.M_PackVorschrift_Obj > '':U 
      no-lock no-error.

    if available bM_LTPos then

      mawi.base.cls.MMCPackagingSvc:prpoInstance:getRegulationDescription
        (       bM_LTPos.M_PackVorschrift_Obj,
         output bttPPT_OrderPart-P1.PackInstructName,
         output bttPPT_OrderPart-P1.PackInstructDesc,
         output bttPPT_OrderPart-P1.PackInstructRemark,
         output bttPPT_OrderPart-P1.PackInstructSearchTerm).

    /*----------------------------------------------------------------------*/
    /* Load Part and Part Variant Informations                              */
    /*----------------------------------------------------------------------*/

    {pps/base/incl/pmjpwo01.if
      &Artikel                 = "bttPPT_OrderPart-P1.Part"
      &ArtVarTyp               = "bttPPT_OrderPart-P1.PartVariantType"
      &ArtVar                  = "bttPPT_OrderPart-P1.PartVariant"
      &bttS_ArtVar-P           = "bttS_ArtVar-PJP"
      &bttS_Artikel-P          = "bttS_Artikel-PJP"
      &bttS_MengenEinheit-P    = "bttS_MengenEinheit-P1JP"
      &bttS_ArtikelArt-P       = "bttS_ArtikelArt-P1JP"
      &bttSBM_ValueFlowGroup-P = "bttSBM_ValueFlowGroup-P1JP"
      }

  end. /* for each bPPT_OrderPart */

  assign
    /* Anzahl Kuppelprodukte im PPA */
    bttPP_Auftrag-P.NumberOfJointProducts = iNumberOfJointProducts
    .

  /* St�cklistenzeilen ... */
  BOMLineLoop:
  for each bPP_StkZeile
    where bPP_StkZeile.Firma        = {firma/ppauftra.fir pACConnectionSvc:prpcCompany}
      and bPP_StkZeile.RueckMeldeNr = bPP_Auftrag.RueckMeldeNr
      and bPP_StkZeile.Position    >= iBOMPos_min
      and bPP_StkZeile.Position    <= iBOMPos_max
    no-lock
    on error undo, throw:

    /* Check usage category of BOM line */
    if cReportType > '':U then
    do:

      {pps/prod/incl/ppddru00.if
         &ippBOMLineBuffer       = "bPP_StkZeile"
         &ippCurrentPrintProgram = "cReportType"}

    end. /* if cReportType > '':U then */

    if cBomRowID <> '':u and 
      cBomRowID <> ? and 
      rowid (bPP_StkZeile) <> to-rowid(cBomRowID) then
      next BOMLineLoop.

    /* check if the current BOM line has to be added to the output table      */
    /* because some report types have special conditions for BOM lines.       */

    if    can-do('MS,MB,SMS,SMF':U,cReportType)
      and bPP_StkZeile.RueckMenge > 0
      and lPrintRequisEvenIfPosted = no then
      next BOMLineLoop.

    if    can-do('SMS,SMF':U,cReportType)
      and bPP_StkZeile.Lagerort <> iStorageAreaSelection then
      next BOMLineLoop.

    if can-do('MS,MB':U,cReportType) then
    do:
      if can-find(PP_Auftrag
                   where PP_Auftrag.Firma           = bPP_StkZeile.Firma
                     and PP_Auftrag.Auftrag         = bPP_StkZeile.Auftrag
                     and PP_Auftrag.Artikel         = bPP_StkZeile.Artikel
                     and PP_Auftrag.ArtVar          = bPP_StkZeile.ArtVar
                     and PP_Auftrag.BaugruppenFolge = bPP_StkZeile.BaugruppenFolge
                     and PP_Auftrag.bgr_lager       = no) then
        next BOMLineLoop.

      if pps.base.cls.PMCStandardBomSvc:prpoInstance:lIsPhantomAssembly(bPP_StkZeile.Artikel,
                                                                        bPP_StkZeile.StkZeilenArt) then
        next BOMLineLoop.

    end. /* if can-do('MS,MB':U,cReportType) then */

    &IF LOOKUP("M_APS":U,"{&PA-OPTIONEN}":U) > 0 &THEN
      if lSkipBOMLinePrintGroupChecks
           (buffer bPP_StkZeile,
            cReportType,
            cDruckgruppe,
            iActPos_min,
            iActPos_max) = yes then
        next BOMLineLoop.
    &ENDIF /* M_APS */

    /* load the MasterPart Record to fill the PartVariantType                   */

    find bS_Artikel-PartVarType
      where bS_Artikel-PartVarType.Firma   = {firma/sartikel.fir pACConnectionSvc:prpcCompany}
        and bS_Artikel-PartVarType.Artikel = bPP_StkZeile.Artikel
      no-lock.

    find first bMLM_StorPartData
      where bMLM_StorPartData.Company      = pACConnectionSvc:prpcCompany
        and bMLM_StorPartData.Part         = bPP_StkZeile.Artikel
        and bMLM_StorPartData.Storagearea  = bPP_StkZeile.LagerOrt
      no-lock no-error.

    /*-----------------------------------------------------------------------*/
    /* Ermittle die Rueckmeldenummer des Unterauftrags                       */
    /*-----------------------------------------------------------------------*/

    find bPP_Auftrag-UA
      where bPP_Auftrag-UA.Firma           = {firma/ppauftra.fir pACConnectionSvc:prpcCompany}
        and bPP_Auftrag-UA.Auftrag         = bPP_Auftrag.Auftrag
        and bPP_Auftrag-UA.Artikel         = bPP_StkZeile.Artikel
        and bPP_Auftrag-UA.ArtVar          = bPP_StkZeile.ArtVar
        and bPP_Auftrag-UA.BaugruppenFolge = bPP_StkZeile.BaugruppenFolge
      no-lock no-error.


    /* all special checks passed -> create the line in the output table       */

    create bttPP_StkZeile-P.

    {buffer-copy
       bPP_StkZeile
       to bttPP_StkZeile-P
       assign
         "bttPP_StkZeile-P.Firma                    = pACConnectionSvc:prpcCompany
          bttPP_StkZeile-P.IdentAkt                 = ?
          bttPP_StkZeile-P.iResNr                   = mawi.base.cls.MMCReservationSvc:prpoInstance:iReviewReservationNr
                                                        (bPP_StkZeile.PP_StkZeile_Obj,
                                                         'MSR':U)
          bttPP_StkZeile-P.BC_RueckMeldeNr          =   string(bPP_StkZeile.RueckmeldeNr,'99999999':U)
                                                      + string(bPP_StkZeile.Position,'999999':U)
          bttPP_StkZeile-P.Einzelmenge              =   bPP_StkZeile.BedarfsMenge
                                                      / bPP_Auftrag.ProduktionsMenge
          bttPP_StkZeile-P.PosToElektro             = pps.prod.cls.PPCProdBomLineSvr:prpoInstance:cGetPackedElectroBomLineInfo
                                                        (bPP_StkZeile.PP_StkZeile_Obj)
          bttPP_StkZeile-P.StkZeilenArt             = adm.config.cls.DCCAppConfigSvc:prpoInstance:cParamValsByRefParamValsLng
                                                        ('SB_BOMLineUsageCategory_descShort':U,
                                                         bPP_StkZeile.StkZeilenArt,
                                                         ',':U,
                                                         cContentLanguage)
          bttPP_StkZeile-P.PartVariantType          = bS_Artikel-PartVarType.ArtVarTyp
          bttPP_StkZeile-P.CoverageQty              = decimal(cBomCoverageQty)
          bttPP_StkZeile-P.StorageLocation          = (if available bMLM_StorPartData then
                                                         bMLM_StorPartData.StorageInfo
                                                       else
                                                         '':u)
          bttPP_StkZeile-P.StructCodeKurz           = RemoveLeadingZero(bttPP_StkZeile-P.StructCode)

          bttPP_StkZeile-P.RueckmeldeNrUnterauftrag = bPP_Auftrag-UA.RueckMeldeNr when available bPP_Auftrag-UA
          bttPP_StkZeile-P.InstallationLocList      = pps.prod.cls.PPCProdBomLineSvr:prpoInstance:cGetInstallationLocList
                                                        (bPP_StkZeile.PP_StkZeile_Obj)"}

    &IF LOOKUP("MS":U,"{&PA-MODULE}":U) > 0 &THEN

      /* serial numbers as text */

      bttPP_StkZeile-P.SerialNoAsText = mawi.serie.cls.MSCSerialNoSvc:prpoInstance:clCreateSerialNoAsText
                                          (bPP_StkZeile.PP_StkZeile_Obj,
                                           yes).

    &ENDIF

    /*------------------------------------------------------------------------*/
    /* Load Part and Part Variant Informations                                */
    /*------------------------------------------------------------------------*/

    {pps/base/incl/pmjpwo01.if
      &Artikel                 = "bttPP_StkZeile-P.Artikel"
      &ArtVarTyp               = "bttPP_StkZeile-P.PartVariantType"
      &ArtVar                  = "bttPP_StkZeile-P.ArtVar"
      &bttS_Artikel-P          = "bttS_Artikel-P"
      &bttS_ArtVar-P           = "bttS_ArtVar-P"
      &bttS_MengenEinheit-P    = "bttS_MengenEinheit-P1StkZ"
      &bttS_ArtikelArt-P       = "bttS_ArtikelArt-P1"
      &bttSBM_ValueFlowGroup-P = "bttSBM_ValueFlowGroup-P1"
    }

    assign
      bttPP_StkZeile-P.ArtikelArt  = bttS_ArtikelArt-P1.ArtikelArt
      bttPP_StkZeile-P.LME_KurzBez = {fnarg
                                        pa_cDyCchUnitOfMeasureDesc
                                        "pACConnectionSvc:prpcCompany,
                                         bttS_Artikel-P.LagerME,
                                         pACConnectionSvc:prpcLanguage,
                                         {&pa_CchShortCut}"}
      .

    /*------------------------------------------------------------------------*/
    /* Load BOM Informations                                                  */
    /*------------------------------------------------------------------------*/
    {pps/prod/incl/ppjpwo02.if
      &bPP_StkZeile           = "bPP_StkZeile"
      &bttS_MengenEinheit-P   = "bttS_MengenEinheit-P1StkZL"
      &bttML_Ort-P            = "bttML_Ort-PBOM"
      &bttMML_ValueStorage-P1 = "bttMML_ValueStorage-P1BOM"
    }

    /*------------------------------------------------------------------------*/
    /* Load BOM Informations Part 2                                           */
    /*------------------------------------------------------------------------*/
    {pps/prod/incl/ppjpwo04.if
      &bttPP_StkZeile-P       = "bttPP_StkZeile-P"
      &bttMCL_LotMovements-P  = "bttMCL_LotMovements-P"
      &bttMP_ArtRes-P         = "bttMP_ArtRes-P"
      }

    /*----------------------------------------------------------------------*/
    /* load formula text                                                    */
    /*----------------------------------------------------------------------*/

    {pps/incl/p__for00.if
      &Firma     = "bPP_StkZeile.firma"
      &Tabelle   = "bPP_StkZeile"
      &Bereich   = "'pp':U"
      &druckFkt  = "true"
      &DruckFeld = "cFormeltext"
      &EinMenge  = "  bPP_Auftrag.Produktionsmenge
                    - bPP_Auftrag.Entnahmemenge
                    + bPP_Auftrag.Anfahrausschuss"
      }

    assign
      bttPP_StkZeile-P.Formeltext1 = cFormeltext[1]
      bttPP_StkZeile-P.Formeltext2 = cFormeltext[2]
      bttPP_StkZeile-P.Formeltext3 = cFormeltext[3]
      .

    for each bP_ZeichnungArtikel
      where bP_ZeichnungArtikel.Firma       = {firma/pps.fir pACConnectionSvc:prpcCompany}
        and bP_ZeichnungArtikel.Artikel     = bttPP_StkZeile-P.Artikel
        and bP_ZeichnungArtikel.Druckfolge >= 0
      use-index DruFol
      no-lock:

      if    not can-find(bttP_ZeichnungArtikel-P2
                           where bttP_ZeichnungArtikel-P2.Firma      = bP_ZeichnungArtikel.Firma
                             and bttP_ZeichnungArtikel-P2.Artikel    = bP_ZeichnungArtikel.Artikel
                             and bttP_ZeichnungArtikel-P2.Druckfolge = bP_ZeichnungArtikel.Druckfolge
                             and bttP_ZeichnungArtikel-P2.Zeichnung  = bP_ZeichnungArtikel.Zeichnung)
        and can-find(first PMM_Drawing
                       where PMM_Drawing.Company        = {firma/pps.fir pACConnectionSvc:prpcCompany}
                         and PMM_Drawing.PMM_Drawing_ID = bP_ZeichnungArtikel.Zeichnung
                         and PMM_Drawing.isValidIndex   = yes) then
      do:

        find last bPMM_Drawing
          where bPMM_Drawing.Company = {firma/pps.fir pACConnectionSvc:prpcCompany}
            and bPMM_Drawing.PMM_Drawing_ID = bP_ZeichnungArtikel.Zeichnung
            and bPMM_Drawing.isValidIndex   = yes
          no-lock.

        create bttP_ZeichnungArtikel-P2.
        {buffer-copy
           bP_ZeichnungArtikel
           to bttP_ZeichnungArtikel-P2
           assign
             "bttP_ZeichnungArtikel-P2.Firma            = pACConnectionSvc:prpcCompany
              bttP_ZeichnungArtikel-P2.IndexNo          = bPMM_Drawing.IndexNo
              bttP_ZeichnungArtikel-P2.PurchaseRelevant = bPMM_Drawing.PurchaseRelevant
              bttP_ZeichnungArtikel-P2.PPSrelevant      = bPMM_Drawing.PPSrelevant
              bttP_ZeichnungArtikel-P2.B2BShop          = bPMM_Drawing.b2b_Shop"}

      end. /* if not can-find(bttP_ZeichnungArtikel-P2 */

    end. /* for each bP_ZeichnungArtikel */


  end. /* for each bPP_StkZeile */

  /* Aktivit�ten... */
  ActLoop:
  for each bMB_Aktivitaet
    where bMB_Aktivitaet.Firma          = {firma/mawib.fir pACConnectionSvc:prpcCompany}
      and bMB_Aktivitaet.Prozessbereich = cWOArea
      and bMB_Aktivitaet.Prozess        = bPP_Auftrag.Auftrag
      and bMB_Aktivitaet.Teilprozess    = bPP_Auftrag.RueckMeldeNr
      and bMB_Aktivitaet.AktPos        >= iActPos_min
      and bMB_Aktivitaet.AktPos        <= iActPos_max
    no-lock
    on error undo, throw:

    if    cDruckGruppe <> ?
      and not can-do(bMB_Aktivitaet.Gruppe,cDruckGruppe) then
      next ActLoop.

    /* Skip this operation  if it is already archived.              */

    if    bMB_Aktivitaet.fertig  = yes
      and lOnlyOpenOperations    = yes then

      next ActLoop.

    /* check if the current activity has to be added to the output table      */
    /* because some report types have special conditions for activities.      */

    if can-do('SMS,SMF':U,cReportType) then
    do:

      if bMB_Aktivitaet.MB_Aktivitaet_Obj <> cActivitySelection then
        next ActLoop.

      if    lPrintActWithoutBOMAssociations = no
        and not can-find(first PP_MatRess
                           where PP_MatRess.Firma    = {firma/ppauftra.fir bMB_Aktivitaet.Firma}
                             and PP_MatRess.IdentAkt = bMB_Aktivitaet.IdentAkt) then
        next ActLoop.

    end. /* if cReportType = 'SMS':U then */

    if can-do('RS,LS':U,cReportType) then
    do:

      if bMB_Aktivitaet.fertig = yes then
        next ActLoop.

      if cReportType = 'LS':u and bMB_Aktivitaet.AnzahlLS  = 0 then 
        next ActLoop.

      if cReportType = 'RS':u and bMB_Aktivitaet.AnzahlRMS = 0 then
        next ActLoop.

      if    bMB_Aktivitaet.AktArt <> {&pa_MM_ActivityTypeProduction}
        /* --> MaintenanceComponent Q_-E-MNTC-001  OsB 25.08.2021 */
        &IF lookup("Q_PLNTMNT":U,"{&PA-OPTIONEN}":U) > 0 &THEN
        and bMB_Aktivitaet.AktArt <> {&pa_MM_ActivityTypeMaintenance}
        &ENDIF
        /* <-- MaintenanceComponent Q_-E-MNTC-001  OsB 25.08.2021 */
        and bMB_Aktivitaet.AktArt <> {&pa_MM_ActivityTypeExternaloperation} then
        next ActLoop.

      if    lPrintSDMRQEvenIfPosted = no
        and (   bMB_Aktivitaet.Rueckmenge > 0
             or bMB_Aktivitaet.ist_te    <> 0
             or bMB_Aktivitaet.ist_tr    <> 0) then
        next ActLoop.

    end. /* if can-do('RS,LS':U,cReportType) then */

    if    cReportType = 'SMF':U
      and bMB_Aktivitaet.AktArt <> {&pa_MM_ActivityTypeExternaloperation} then
      next ActLoop.

    /* Bestimme f�r einen Lohnschein die Anzahl Ausrucke */
    if cReportType = 'LS':u then
    do:
      &IF "{&pa_PP_AnzahlArbeitspapiereInt}" = "0" &THEN
        iAktWiederholfaktor = (if bMB_Aktivitaet.AktArt = {&pa_MM_ActivityTypeExternaloperation} then
                                 bMB_Aktivitaet.AnzahlLS
                               else
                                 max(1,(bMB_Aktivitaet.AnzahlLS * bMB_Aktivitaet.BasisIntensitaet))).
      &ELSE
        iAktWiederholfaktor = bMB_Aktivitaet.AnzahlLS.
      &ENDIF
    end.

    /* Bestimme f�r einen R�ckmeldeschein die Anzahl Ausrucke */
    if cReportType = 'RS':u then
    do:
      &IF "{&pa_PP_AnzahlArbeitspapiereInt}" = "0" &THEN
        iAktWiederholfaktor = (if bMB_Aktivitaet.AktArt = {&pa_MM_ActivityTypeExternaloperation} then
                                 bMB_Aktivitaet.AnzahlRMS
                               else
                                 max(1,(bMB_Aktivitaet.AnzahlRMS * bMB_Aktivitaet.BasisIntensitaet))).
      &ELSE
        iAktWiederholfaktor = bMB_Aktivitaet.AnzahlRMS.
      &ENDIF
    end.

    do iAktZaehler = 1 to iAktWiederholfaktor:

      create bttMB_Aktivitaet-P.
      {buffer-copy
         bMB_Aktivitaet
         to bttMB_Aktivitaet-P
         assign
           "bttMB_Aktivitaet-P.Firma                 = pACConnectionSvc:prpcCompany
            bttMB_Aktivitaet-P.Ausschussmenge        = (if lCalculateOperationScrapQty then
                                                          pps.base.cls.PMCScrapSvc:prpoInstance:dGetOperationScrapQty(buffer bMB_Aktivitaet)
                                                        else
                                                          0)
            bttMB_Aktivitaet-P.AnzahlTextzeilen      = iAnzahlTextZeilen
            bttMB_Aktivitaet-P.OperationCategoryDesc = adm.config.cls.DCCAppConfigSvc:prpoInstance:cParamValByRefParamVal
                                                         ('MM_ActivityTypes_desc':U,
                                                          string(bMB_Aktivitaet.AktArt,'99':U))
            bttMB_Aktivitaet-P.ResourceCatDesc       = adm.config.cls.DCCAppConfigSvc:prpoInstance:cParamValByRefParamVal
                                                         ('PM_ResourceCategories_desc':U,
                                                          string(bMB_Aktivitaet.BasisRessArt,'99':U))"}

    &IF LOOKUP("SB-QM-Production":U,"{&PA-OPTIONEN}":U) > 0 &THEN
      assign
        dQMQuantities                       = stamm.base.cls.SBCQualityCheckSvc:prpoInstance:dCalculateQtyForDocument
                                                (bMB_Aktivitaet.MB_Aktivitaet_Obj)
        bttMB_Aktivitaet-P.QMOKQty          = dQMQuantities[1]
        bttMB_Aktivitaet-P.QMNotOKQty       = dQMQuantities[2]
        bttMB_Aktivitaet-P.QMConditionalQty = dQMQuantities[3]
        bttMB_Aktivitaet-P.QMRelevant       = stamm.base.cls.SBCQualityCheckSvc:prpoInstance:lIsOperationQMrelevant
                                                (bMB_Aktivitaet.MB_Aktivitaet_Obj)
        bttMB_Aktivitaet-P.QMCheckState     = stamm.base.cls.SBCQualityCheckSvc:prpoInstance:cGetCurrentCheckStateForDocument
                                                (bMB_Aktivitaet.MB_Aktivitaet_Obj) 
        bttMB_Aktivitaet-P.QMCheckState     = entry(lookup(bttMB_Aktivitaet-P.QMCheckState,cCheckState_Keys),cCheckState_Desc)
        .
    &ENDIF

      /* --> MaintenanceComponent Q_-E-MNTC-001  OsB 25.08.2021 */
      &IF lookup("Q_PLNTMNT":U,"{&PA-OPTIONEN}":U) > 0 &THEN
      if bMB_Aktivitaet.AktArt = {&pa_MM_ActivityTypeProduction}
        or bMB_Aktivitaet.AktArt = {&pa_MM_ActivityTypeMaintenance} then
      &ELSE
      /* <-- MaintenanceComponent Q_-E-MNTC-001  OsB 25.08.2021 */
      if bMB_Aktivitaet.AktArt = {&pa_MM_ActivityTypeProduction} then
      /* --> MaintenanceComponent Q_-E-MNTC-001  OsB 25.08.2021 */
      &ENDIF
      /* <-- MaintenanceComponent Q_-E-MNTC-001  OsB 25.08.2021 */
        assign
          bttMB_Aktivitaet-P.VorgabeZeit         = string(bMB_Aktivitaet.soll_te)
          bttMB_Aktivitaet-P.VorgabeZeit_Gesamt  = string(((bMB_Aktivitaet.soll_tr
                                                   / bMB_Aktivitaet.Basisintensitaet)
                                                   * (giZeitfaktor[integer(bMB_Aktivitaet.ZeitEinheitTr) + 1]
                                                   / giZeitfaktor[integer(bMB_Aktivitaet.ZeitEinheitTe) + 1]) )
                                                   + bMB_Aktivitaet.soll_te)
          .

      /* load additional activitiy information                                  */

      {pps/prod/incl/ppjpwo06.if
        &ippActivityDBBuffer       = "bMB_Aktivitaet"
        &ippActivityTTBuffer       = "bttMB_Aktivitaet-P"
        &ippValueStorageTTBuffer   = "bttMML_ValueStorage-P1Act"
        &ippttM_Ressource-PBase    = "bttM_Ressource-PBase"
        &ippttS_KostenStelle-PBase = "bttS_Kostenstelle-P22Base"
        &ippUsedCompany            = "pACConnectionSvc:prpcCompany"
        }

      /*------------------------------------------------------------------------*/
      /* Lade Lieferantenadresse bei Fremdleistungsaktivit�t                    */
      /*------------------------------------------------------------------------*/
      if bMB_Aktivitaet.AktArt = {&pa_MM_ActivityTypeExternaloperation} then
      do:
        {pps/prod/incl/ppjpwo08.if
          &bttMB_Aktivitaet-P   = "bttMB_Aktivitaet-P"
          &bttS_Adresse-P       = "bttS_Adresse-P31"
          }
      end.

      find first bM_LTPos
        where bM_LTPos.Firma                = {firma/mlartort.fir pACConnectionSvc:prpcCompany}
          and bM_LTPos.Bereich              = 'P':U
          and bM_LTPos.Funktion             = {&pa_MM_PackagingInstruction}
          and bM_LTPos.Herk_BelegArt2       = 'PPA':U
          and bM_LTPos.Herk_Schluessel2     = bMB_Aktivitaet.MB_Aktivitaet_Obj
          and bM_LTPos.Herk_BelegArt3       = 'PPA':U
          and bM_LTPos.Herk_Schluessel3     = bMB_Aktivitaet.MB_Aktivitaet_Obj
          and bM_LTPos.M_PackVorschrift_Obj > '':U 
        no-lock no-error.

      if available bM_LTPos then

        mawi.base.cls.MMCPackagingSvc:prpoInstance:getRegulationDescription
          (       bM_LTPos.M_PackVorschrift_Obj,
           output bttMB_Aktivitaet-P.PackInstructName,
           output bttMB_Aktivitaet-P.PackInstructDesc,
           output bttMB_Aktivitaet-P.PackInstructRemark,
           output bttMB_Aktivitaet-P.PackInstructSearchTerm).

      /* --> MaintenanceComponent Q_-E-MNTC-001  OsB 25.08.2021 */
      &IF lookup("Q_PLNTMNT":U,"{&PA-OPTIONEN}":U) > 0 &THEN
      if bMB_Aktivitaet.AktArt = {&pa_MM_ActivityTypeProduction}
        or bMB_Aktivitaet.AktArt = {&pa_MM_ActivityTypeMaintenance} then
      &ELSE
      /* <-- MaintenanceComponent Q_-E-MNTC-001  OsB 25.08.2021 */
      if bMB_Aktivitaet.AktArt = {&pa_MM_ActivityTypeProduction} then
      /* --> MaintenanceComponent Q_-E-MNTC-001  OsB 25.08.2021 */
      &ENDIF
      /* <-- MaintenanceComponent Q_-E-MNTC-001  OsB 25.08.2021 */
      do:

        /* In Abh�ngigkeit von S_Lohnart.druck_zeiten Sollzeiten drucken */

        find bS_Lohnart
          where bS_Lohnart.Firma   = {firma/slohnart.fir pACConnectionSvc:prpcCompany}
            and bS_Lohnart.Lohnart = bMB_Aktivitaet.LohnArt
          no-lock no-error.

        if    available bS_Lohnart
          and bS_Lohnart.druck_zeiten = yes then
        assign
          bttMB_Aktivitaet-P.Ruestzeit  = string(bMB_Aktivitaet.TR)
          bttMB_Aktivitaet-P.Stueckzeit = string(bMB_Aktivitaet.TE)
        .

      end.

      /*----------------------------------------------------------------------*/
      /* Load Part Informations                                               */
      /*----------------------------------------------------------------------*/

      if bMB_Aktivitaet.Artikel <> '':U then
      do:

        {pps/base/incl/pmjpwo01.if
          &Artikel                 = "bMB_Aktivitaet.Artikel"
          &bttS_Artikel-P          = "bttS_Artikel-PAct"
          &bttS_MengenEinheit-P    = "bttS_MengenEinheit-P1Act"
          &bttS_ArtikelArt-P       = "bttS_ArtikelArt-P1Act"
          &bttSBM_ValueFlowGroup-P = "bttSBM_ValueFlowGroup-P1Act"
          }

      end. /* if bMB_Aktivitaet.Artikel <> '':U */

      /*------------------------------------------------------------------------*/
      /* Load all Resources                                                     */
      /*------------------------------------------------------------------------*/

      {pps/prod/incl/ppjpwo03.if
        &Identakt            = "bMB_Aktivitaet.IdentAkt"
        &bttMB_Ressource-P   = "bttMB_Ressource-P"
        &bttM_Ressource-P    = "bttM_Ressource-P"
        &bttS_Kostenstelle-P = "bttS_Kostenstelle-P22"
        &ippReportType       = "cReportType"
        }

      for each bPP_MatRess
        where bPP_MatRess.Firma = {firma/ppauftra.fir pACConnectionSvc:prpcCompany}
          and bPP_MatRess.IdentAkt = bMB_Aktivitaet.IdentAkt
        no-lock
        on error undo, throw:

        find bttPP_StkZeile-P
          where bttPP_StkZeile-P.Firma    = {firma/ppauftra.fir pACConnectionSvc:prpcCompany}
            and bttPP_StkZeile-P.IdentStk = bPP_MatRess.IdentStk
            no-lock no-error.

        if available bttPP_StkZeile-P then
          assign
            bttPP_StkZeile-P.IdentAkt = bMB_Aktivitaet.IdentAkt
            lBOMAssociationAvailable  = yes
            .

      end. /* for each bPP_MatRess... */
               
    end. /* do iAktZaehler = 1 to iAktWiederholfaktor: */

  end. /* for each bMB_Aktivitaet ... */

  /* Zeichnungen ... */
  {pps/prod/incl/ppjpwo05.if
    &bttPP_Auftrag-P    = "bPP_Auftrag"
    &bttPP_Zeichnung-P  = "bttPP_Zeichnung-P"
    &OrderPartPosition  = "0"
    }

  /* Teileverwendung */
  run BestimmeTeileVerwendung in target-procedure (bPP_Auftrag.PP_Auftrag_Obj,
                                                   1,       /* currentDepht */
                                                   '':U,    /* current no   */
                                                   0).      /* line counter */

  /* Kunde */

  if not can-find(bttS_Kunde-P6
                    where bttS_Kunde-P6.Firma = {firma/s_kunde.fir pACConnectionSvc:prpcCompany}
                      and bttS_Kunde-P6.Kunde = bPP_Auftrag.Kunde) then
  do:

    find bS_Kunde
      where bS_Kunde.Firma = {firma/s_kunde.fir pACConnectionSvc:prpcCompany}
        and bS_Kunde.Kunde = bPP_Auftrag.Kunde
      no-lock no-error.

    if available bS_Kunde then
    do:

      create bttS_Kunde-P6.
      {buffer-copy
         bS_Kunde
         to bttS_Kunde-P6
         assign
           "bttS_Kunde-P6.Firma = {firma/s_kunde.fir pACConnectionSvc:prpcCompany}"}

      find bS_ArtKunde
        where bS_ArtKunde.Firma   = {firma/sartkund.fir pACConnectionSvc:prpcCompany}
          and bS_ArtKunde.Kunde   = (if available bS_Kunde then
                                       bS_Kunde.Kunde
                                     else
                                       0)
          and bS_ArtKunde.Artikel = bPP_Auftrag.Artikel
        no-lock no-error.

      if available bS_ArtKunde then
      do:

        create bttS_ArtKunde-P.

        {buffer-copy
           bS_ArtKunde
           except "Firma"
           to bttS_ArtKunde-P
           assign
             "bttS_ArtKunde-P.Firma = pACConnectionSvc:prpcCompany"}

      end. /* if available bS_ArtKunde then */


    end. /* if available bS_Kunde then */    

  end. /* if not can-find(bttS_Kunde-P6 */

  /* PP_StkZeile was only available from activity. To make it available from  */
  /* Auftrag ttPP_StkZeile-PWO was created and it is copy of ttPP_StkZeile-P  */

  run CopyPP_StkZeile in target-procedure.

  /* Stop the accumulation. If a previous accumulation use-cases is           */
  /* available, then it will be reset and the accumulation is continued with  */
  /* this use-case.                                                           */

  pps.prod.cls.PPCProductionMaterialServiceWrapperSvc:prpoInstance:stopAccumulation().

  /* Required Error-Handling. In case of an error we have to reset the        */
  /* current posting operations made during the current program iteration. If */
  /* we previously started an accumulation, then the last available use-case  */
  /* is restored and the error is forwarded to this operation iteration. If   */
  /* this operation started the accumulation all operations will be resetted  */
  /* and cleared.                                                             */

  catch oError as Progress.Lang.Error:

    pps.prod.cls.PPCProductionMaterialServiceWrapperSvc:prpoInstance:clearAllPendingPostings().

    /* forward the error to be able to handle the error outside               */

    undo, throw oError.

  end catch. /* catch oError as Progress.Lang.Error */

end. /* if cFillMode = 'LLConfig':U then ... else do:*/

{&{&pa-XBasisName}_C_FillDatasetEnd}
{&{&pa-XBasisName}_U_FillDatasetEnd}
{&{&pa-XBasisName}_Q_FillDatasetEnd}
{&{&pa-XBasisName}_FillDatasetEnd}
{&{&pa-XBasisName}_Y_FillDatasetEnd}

end procedure. /* fillDataset */

/* _UIB-CODE-BLOCK-END */
&ANALYZE-RESUME

&ENDIF

/* ************************  Function Implementations ***************** */

&IF LOOKUP("M_APS":U,"{&PA-OPTIONEN}":U) > 0 &THEN

&IF DEFINED(EXCLUDE-lIsBomLineAssignedToOperation) = 0 &THEN

&ANALYZE-SUSPEND _UIB-CODE-BLOCK _FUNCTION lIsBomLineAssignedToOperation Method-Library
function lIsBomLineAssignedToOperation returns logical
  ( buffer bPP_StkZeile for PP_StkZeile ):
/* Description ---------------------------------------------------------------*/
/* Check whether the Bom line is assigned to operation                        */
/* Parameters ----------------------------------------------------------------*/
/* bPP_StkZeile     PP_StkZeile buffer                                        */
/*----------------------------------------------------------------------------*/

return can-find (first PP_MatRess
                 where PP_MatRess.Firma     = bPP_StkZeile.Firma
                   and PP_MatRess.IdentStk  = bPP_StkZeile.IdentStk).

end function. /* lIsBomLineAssignedToOperation */

/* _UIB-CODE-BLOCK-END */
&ANALYZE-RESUME

&ENDIF
&ENDIF /* M_APS */

&IF LOOKUP("M_APS":U,"{&PA-OPTIONEN}":U) > 0 &THEN
&IF DEFINED(EXCLUDE-lSkipBOMLinePrintGroupChecks) = 0 &THEN

&ANALYZE-SUSPEND _UIB-CODE-BLOCK _FUNCTION lSkipBOMLinePrintGroupChecks Method-Library
function lSkipBOMLinePrintGroupChecks returns logical
  ( buffer bPP_StkZeile for PP_StkZeile,
    pcReportType          as character,
    pcPrintGroup          as character,
    piActivityPositionMin as integer,
    piActivityPositionMax as integer ):
/* Description ---------------------------------------------------------------*/
/* Check if BOM Line should be skipped from printing,                         */
/* based on seleted print groups                                              */
/* Parameters ----------------------------------------------------------------*/
/* bPP_StkZeile             PP_StkZeile buffer                                */
/* pcReportType             Print report type                                 */
/* pcPrintGroup             Print group to be printed                         */
/* piActivityPositionMin    Minimum activity position to print                */
/* piActivityPositionMax    Maximum activity position to print                */
/*----------------------------------------------------------------------------*/

if can-do('LK':U, pcReportType) = no then
  return no.

/* If print group = ?, then no activity has matching printgroup, */
/* but we still need to print unassigned material */
if pcPrintGroup = ? then
  return lIsBomLineAssignedToOperation
           (buffer bPP_StkZeile) = yes.

else
  /* Only print material connected to an operation matching the */
  /* print group filter or material that is not connected.      */
  return    not can-find (first PP_MatRess
                            where PP_MatRess.Firma    = bPP_StkZeile.Firma
                              and PP_MatRess.IdentStk = bPP_StkZeile.IdentStk
                              and can-find (first MB_Aktivitaet
                                              where MB_Aktivitaet.Firma     = {firma/mawib.fir pACConnectionSvc:prpcCompany}
                                                and MB_Aktivitaet.IdentAkt  = PP_MatRess.IdentAkt
                                                and MB_Aktivitaet.AktPos   >= piActivityPositionMin
                                                and MB_Aktivitaet.AktPos   <= piActivityPositionMax
                                                and lookup(pcPrintGroup, MB_Aktivitaet.Gruppe) > 0))
        and lIsBomLineAssignedToOperation
              (buffer bPP_StkZeile) = yes.

end function. /* lSkipBOMLinePrintGroupChecks */

/* _UIB-CODE-BLOCK-END */
&ANALYZE-RESUME

&ENDIF
&ENDIF /* M_APS */

