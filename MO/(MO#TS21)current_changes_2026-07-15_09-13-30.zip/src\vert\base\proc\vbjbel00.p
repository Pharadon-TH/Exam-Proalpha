
&ANALYZE-SUSPEND _UIB-CODE-BLOCK _CUSTOM _DECLARATIONS V-table-Win 

using adm.config.cls.*.
using gateway.base.einv.cls.*.
using mawi.base.cls.MMCCountryOfOriginSvo.
using stamm.base.cls.*.
using vert.auf.cls.VUCTSPPrintFreightPayerSvo.
using vert.base.cls.*.
using vert.fakt.cls.*.
using vert.fakt.einv.cls.*.
using vert.auf.cls.VUCEntryCertificateSvc.

/* _UIB-CODE-BLOCK-END */
&ANALYZE-RESUME

&ANALYZE-SUSPEND _UIB-CODE-BLOCK _XFTR "Update Information" Procedure _INLINE
/* Actions: ? ? ? ? adm/support/proc/ds_pa_01.w */

/* _UIB-CODE-BLOCK-END */
&ANALYZE-RESUME

&ANALYZE-SUSPEND _UIB-CODE-BLOCK _CUSTOM _DEFINITIONS Procedure
/******************************************************************************/
/* @COPYRIGHT@                                                                */
/* Project: Proalpha                                                          */
/*                                                                            */
/* Name   : vbjbel00.p                                                        */
/* Product: VERT - Vertrieb                                                   */
/* Module : BASE - Kernfunktionen                                             */
/*                                                                            */
/* Created: 6.2d01 as of 19.08.2016/Holger Tupath                             */
/* Current: @PAVERSION@ as of @PADATE@/@PALASTAUTHOR@                         */
/*                                                                            */
/*----------------------------------------------------------------------------*/
/* DESCRIPTION                                                                */
/*----------------------------------------------------------------------------*/
/*                                                                            */
/* Print DAO for documents in table V_BelegKopf (Data Access Object)          */
/*                                                                            */
/*----------------------------------------------------------------------------*/
/* PARAMETERS                                                                 */
/*----------------------------------------------------------------------------*/
/* Name                      Description                                      */
/*----------------------------------------------------------------------------*/
/*                                                                            */
/*----------------------------------------------------------------------------*/
/* HISTORY                                                                    */
/*----------------------------------------------------------------------------*/
/* @FILEHISTORY@                                                              */
/******************************************************************************/

/* Procedure Information -----------------------------------------------------*/

&GLOBAL-DEFINE pa-Autor             Holger Tupath
&GLOBAL-DEFINE pa-Version           @PAVERSION@
&GLOBAL-DEFINE pa-Datum             @PADATE@
&GLOBAL-DEFINE pa-Letzter           @PALASTAUTHOR@

&GLOBAL-DEFINE pa-GenVersion       OEA
&GLOBAL-DEFINE pa-ProgrammTyp      DataAccessObject
&GLOBAL-DEFINE pa-Template         padataaccessobject.pjet
&GLOBAL-DEFINE pa-TemplateVersion  3.00
&GLOBAL-DEFINE pa-XBasisName       vbjbel00_p
&GLOBAL-DEFINE pa-NameSpace        2.00


{adm/template/incl/dt_dao00.df}

&IF lookup("ER","{&PA-MODULE}") = 0 &THEN
&Scoped-define EXCLUDE-FillLineSupplierTaxIDForLLPrint
&Scoped-define EXCLUDE-FillHeadSupplierTaxIDForLLPrint
&ENDIF

&Scoped-define K_ZuErsetzendeZeichen  'ä,ö,ü,ß,é,è,ê,à,â,ç,ô,ù,¦,|,$,£,*,¢,^,{&pa-Backslash},&,_,!,%,[,]':U
&Scoped-define K_ErsatzZeichen        'a,o,u,ss,e,e,e,a,a,c,o,u,/,/, , , , , ,-,+,-, , ,(,)':U

define variable gcContentLanguage       as character                    no-undo.
define variable gcFirma                 as character                    no-undo.
define variable glPositions             as logical                      no-undo.
define variable gcEuroKurzBez           as character                    no-undo.
define variable glFactoring             as logical                      no-undo.
define variable giDiversAddressCounter  as integer    initial -1        no-undo.
define variable glISplitPaymentTaxKey   as logical    initial ?         no-undo.
define variable glIRegularTaxKey        as logical    initial ?         no-undo.
define variable glDomesticIndiaIntraState as logical                    no-undo.
&IF LOOKUP("U_CA":U,"{&PA-OPTIONEN}":U) > 0 &THEN
  define variable gcuGSAStatus          as character                    no-undo.
&ENDIF
&IF LOOKUP("Q_GELANG","{&PA-OPTIONEN}") > 0 &THEN
  define variable gcDocumentType        as character                    no-undo.
&ENDIF
define variable giH_TotalNoOfCopies     as integer                      no-undo.
define variable gtPCopyDate             as date                         no-undo.
define variable giDecimalsDomCur        as integer no-undo.

define buffer gbV_BelegKopf        for V_BelegKopf.
define buffer gbPV_BelegKopf-Org   for V_BelegKopf.


{vert/base/incl/vb_bel00.pds}

{vert/incl/v__bel00.tdf
  &KopfTabelle              = "ttV_BelegSumKopf-Calc"
  &PosTabelle               = "ttV_BelegSumPos-Calc"
  &ippNoReferenceOnlySwitch = "yes"

}

/* in order to collect the doc totals not only for the open quantities but    */
/* also for the origin quantities (used in blanket order) we need 2           */
/* additional temp tables                                                     */

{vert/incl/v__bel00.tdf
  &KopfTabelle              = "ttV_BelegSumKopf-VUR"
  &PosTabelle               = "ttV_BelegSumPos-VUR"
  &ippNoReferenceOnlySwitch = "yes"
}

{stamm/incl/s__adr03.tdf &ippNoReferenceOnlySwitch = "YES"}

/* Totals from the order if prepayment invoice or the final invoice  */
{vert/incl/v__bel00.tdf
  &KopfTabelle              = "ttPV_BelegSumKopf-Org"
  &PosTabelle               = "ttPV_BelegSumPos-Org"
  &ippNoReferenceOnlySwitch = "yes"
}

/* Totals of the original invoice in case of correction invoice      */
{vert/incl/v__bel00.tdf
  &KopfTabelle              = "ttPV_K_BelegSumKopf-Org"
  &PosTabelle               = "ttPV_K_BelegSumPos-Org"
  &ippNoReferenceOnlySwitch = "yes"
}

/* Sums of the correction invoice if it were correct                 */
{vert/incl/v__bel00.tdf
  &KopfTabelle              = "ttPV_K_BelegSumKopf-Cor"
  &PosTabelle               = "ttPV_K_BelegSumPos-Cor"
  &ippNoReferenceOnlySwitch = "yes"
}

&IF LOOKUP("U_CA":U,"{&PA-OPTIONEN}":U) > 0 &THEN
  define temp-table TT_V_PreisFind no-undo like TD_V_PREISFIND.
&ENDIF

define temp-table Kund_Adresse_Dummy  no-undo like S_Adresse.
define temp-table Lief_Adresse_Dummy  no-undo like S_Adresse.
define temp-table Rech_Adresse_Dummy  no-undo like S_Adresse.

/* _UIB-CODE-BLOCK-END */
&ANALYZE-RESUME


&ANALYZE-SUSPEND _UIB-PREPROCESSOR-BLOCK

/* ********************  Preprocessor Definitions  ******************** */

&Scoped-define PROCEDURE-TYPE Procedure
&Scoped-define DB-AWARE no



/* _UIB-PREPROCESSOR-BLOCK-END */
&ANALYZE-RESUME

/* ************************  Function Prototypes ********************** */

&ANALYZE-SUSPEND _UIB-CODE-BLOCK _FUNCTION-FORWARD lIsI_P_HZeroTaxKey V-table-Win
function lIsI_P_HZeroTaxKey returns logical 
  ( piH_TaxCode        like S_Steuer.Steuer,
    plP_TaxExtentUsed  as   logical,
    pcI_P_S_Steuer_Obj as   character )   forward.

/* _UIB-CODE-BLOCK-END */
&ANALYZE-RESUME

&ANALYZE-SUSPEND _UIB-CODE-BLOCK _FUNCTION-FORWARD lTaxKeyIsZeroTaxKey V-table-Win
function lTaxKeyIsZeroTaxKey returns logical 
  ( pdGesamt_Steuersatz as   decimal,
    piH_TaxCode         like S_Steuer.Steuer,
    plP_TaxExtentUsed   as   logical,
    pcI_P_S_Steuer_Obj  as   character )   forward.

/* _UIB-CODE-BLOCK-END */
&ANALYZE-RESUME

&ANALYZE-SUSPEND _UIB-CODE-BLOCK _FUNCTION lDocumentHasDifferentTaxKeys V-table-Win
function lDocumentHasDifferentTaxKeys returns logical
  ( pdGesamt_Steuersatz like V_BelegKopf.Steuersatz,
    piH_TaxCode         like S_Steuer.Steuer extent 11,
    plP_TaxExtentUsed   as   logical         extent 11,
    pcI_P_S_Steuer_Obj  as   character       extent 11 )   forward.

/* _UIB-CODE-BLOCK-END */
&ANALYZE-RESUME


&ANALYZE-SUSPEND _UIB-CODE-BLOCK _CUSTOM _INCLUDED-LIB Procedure
/* ************************* Included-Libraries *********************** */

{adm/method/incl/dm_dao00.lib}

/* _UIB-CODE-BLOCK-END */
&ANALYZE-RESUME





&ANALYZE-SUSPEND _UIB-CODE-BLOCK _CUSTOM _MAIN-BLOCK Procedure


/* ***************************  Main Block  *************************** */

/*----------------------------------------------------------------------------*/
/* Processing                                                                 */
/*----------------------------------------------------------------------------*/

/* _UIB-CODE-BLOCK-END */
&ANALYZE-RESUME




/* **********************  Internal Procedures  *********************** */


&IF DEFINED(EXCLUDE-A_fillDocumentTotalSumForLLPrint) = 0 &THEN

&ANALYZE-SUSPEND _UIB-CODE-BLOCK _PROCEDURE A_fillDocumentTotalSumForLLPrint Method-Library
procedure A_fillDocumentTotalSumForLLPrint :
/* Description ---------------------------------------------------------------*/
/*                                                                            */
/* Calculates the document total sums of Austrian fields.                     */
/* TT ttV_BelegSumKopf-Calc must be filled before calling this method!        */
/*                                                                            */
/* Notes ---------------------------------------------------------------------*/
/*                                                                            */
/* This method does only encapsulate code for better readability of           */
/* fillDataset procedure. It can only be used in the context of this DAO      */
/* run super() has been execute an a global ttV_BelegKopf-P Buffer is         */
/* available... so passing of paramters was forgone deliberatly.              */
/*                                                                            */
/*----------------------------------------------------------------------------*/

define variable iCount                     as integer                          no-undo.
define variable dGesamtAnzahlungenSteuer like V_Belegkopf.Nettosumme           no-undo.
define variable dAnzahlungenSteuer       like V_Belegkopf.Nettosumme           extent 0 no-undo.
define variable dGesamtWarenwertSteuer   like V_Belegkopf.Nettosumme           no-undo.
define variable dWarenwertEinzelsteuer   like V_Belegkopf.Nettosumme           extent 0 no-undo.

  
  assign
    dGesamtAnzahlungenSteuer = 0
    dGesamtWarenwertSteuer   = 0
    .
  
  do iCount = 1 to 10:
  
    if ttV_BelegSumKopf-Calc.Gesamt_Anzahlungen[iCount] <> 0 then
    do:
  
      if ttV_BelegKopf-P.Brutto = no then   /* von Nettobetrag */
  
        dAnzahlungenSteuer = round((ttV_BelegSumKopf-Calc.Gesamt_Anzahlungen[iCount]
                                    * ttV_BelegSumKopf-Calc.Gesamt_Steuersatz[iCount]) / 100,
                                    ttV_BelegKopf-P.WaehrungNK).
  
      else                                  /* aus Bruttobetrag */
  
        dAnzahlungenSteuer = round(ttV_BelegSumKopf-Calc.Gesamt_Anzahlungen[iCount]
                                   / (1 + ttV_BelegSumKopf-Calc.Gesamt_Steuersatz[iCount] / 100)
                                   * ttV_BelegSumKopf-Calc.Gesamt_Steuersatz[iCount] / 100,
                                   ttV_BelegKopf-P.WaehrungNK).
      assign
        dGesamtAnzahlungenSteuer[iCount]  = dGesamtAnzahlungenSteuer[iCount]
                                            + dAnzahlungenSteuer
        dGesamtAnzahlungenSteuer[11]      = dGesamtAnzahlungenSteuer[11]
                                            + dAnzahlungenSteuer
        .
  
    end. /* if ttV_BelegSumKopf-Calc.Gesamt_Anzahlungen[iCount] <> 0 then do: */
  
    if ttV_BelegSumKopf-Calc.TotalGoodsValue[iCount] <> 0 then
    do:
  
      if ttV_BelegKopf-P.Brutto = no then   /* von Nettobetrag */
  
        dWarenwertEinzelsteuer = round((ttV_BelegSumKopf-Calc.TotalGoodsValue[iCount]
                                        * ttV_BelegSumKopf-Calc.Gesamt_Steuersatz[iCount]) / 100,
                                        ttV_BelegKopf-P.WaehrungNK).
  
      else                                  /* aus Bruttobetrag */
  
        dWarenwertEinzelsteuer = round(ttV_BelegSumKopf-Calc.TotalGoodsValue[iCount]
                                       / (1 + ttV_BelegSumKopf-Calc.Gesamt_Steuersatz[iCount] / 100)
                                       * ttV_BelegSumKopf-Calc.Gesamt_Steuersatz[iCount] / 100,
                                       ttV_BelegKopf-P.WaehrungNK).
  
      assign
        dGesamtWarenwertSteuer[iCount]  = dGesamtWarenwertSteuer[iCount]
                                          + dWarenwertEinzelsteuer
        dGesamtWarenwertSteuer[11]      = dGesamtWarenwertSteuer[11]
                                          + dWarenwertEinzelsteuer
        .
  
    end. /* if ttV_BelegSumKopf-Calc.TotalGoodsValue[iCount] <> 0 then do: */
  
    if ttV_BelegKopf-P.Brutto = no then
      assign
        ttV_BelegKopf-P.A_CSteuer_Anzahlung = dGesamtAnzahlungenSteuer[(if iCount = 10 then
                                                                          11
                                                                        else
                                                                          iCount)]
        ttV_BelegKopf-P.A_CSteuer_AnzGes    = dGesamtAnzahlungenSteuer[(if iCount = 10 then
                                                                          11
                                                                        else
                                                                          iCount)] * -1
                                              + (if iCount = 10 then
                                                   ttV_BelegSumKopf-Calc.Gesamtsteuer
                                                 else if available ttV_BelegTaxrateSums-P then
                                                   ttV_BelegTaxrateSums-P.Steuer
                                                 else
                                                   0)
        ttV_BelegKopf-P.A_CBruttoAnz        = ttV_BelegSumKopf-Calc.Gesamt_Anzahlungen[(if iCount = 10 then
                                                                                          11
                                                                                        else
                                                                                          iCount)]
                                              + dGesamtAnzahlungenSteuer[(if iCount = 10 then
                                                                            11
                                                                          else
                                                                            iCount)]
        ttV_BelegKopf-P.A_CBruttoWarenwert  = ttV_BelegSumKopf-Calc.TotalGoodsValue[(if iCount = 10 then
                                                                                       11
                                                                                     else
                                                                                       iCount)]
                                              + dGesamtWarenwertSteuer[(if iCount = 10 then
                                                                          11
                                                                        else
                                                                          iCount)]
        .
  
  end. /* do iCount = 1 to 10: */

end procedure. /* A_fillDocumentTotalSumForLLPrint */


/* _UIB-CODE-BLOCK-END */
&ANALYZE-RESUME

&ENDIF


&IF DEFINED(EXCLUDE-fillAdvancePaymentLineForLLPrint) = 0 &THEN

&ANALYZE-SUSPEND _UIB-CODE-BLOCK _PROCEDURE fillAdvancePaymentLineForLLPrint Method-Library 
procedure fillAdvancePaymentLineForLLPrint :
/* Description ---------------------------------------------------------------*/
/*                                                                            */
/* Fill ttVB_AdvancePayment-P with records and add up the sum in a single     */
/* ttVB_AdvancePayment-PSum record.                                           */
/*                                                                            */
/* Notes ---------------------------------------------------------------------*/
/*                                                                            */
/* This procedure does only encapsulate code for better readability of        */
/* fillDataset procedure. It can only be used in the context of this DAO !    */
/* run super() must have been executed and a global ttV_BelegKopf-P and       */
/* ttV_BelegPos-P  must be available!                                         */
/*                                                                            */
/*----------------------------------------------------------------------------*/

define buffer bV_BelegPos-PPmtInv   for V_BelegPos.  /* origin partial pmt invoice line */
define buffer bV_BelegKopf-PPmtInv  for V_BelegKopf. /* origin partial pmt invoice head */


  /* One summation record is needed, which is created with the first call of    */
  /* this procedure, an then updated with all following calls.                  */
  
  find ttVB_AdvancePayment-PSum
    no-error.
  
  if not available ttVB_AdvancePayment-PSum then
  do:
    create ttVB_AdvancePayment-PSum.
  
    /* all decimal fields have initial ? so we need to set them to 0 explicitly */
    /* otherwise the summation done later will yield ?                          */
    assign
      ttVB_AdvancePayment-PSum.Owning_Obj               =  ttV_BelegKopf-P.V_BelegKopf_Obj
      ttVB_AdvancePayment-PSum.AmountNetPartPmtInv      =  0
      ttVB_AdvancePayment-PSum.AmountNetEURPartPmtInv   =  0
      ttVB_AdvancePayment-PSum.TaxAmountPartPmtInv      =  0
      ttVB_AdvancePayment-PSum.TaxAmountEURPartPmtInv   =  0
      ttVB_AdvancePayment-PSum.AmountGrossPartPmtInv    =  0
      ttVB_AdvancePayment-PSum.AmountGrossEURPartPmtInv =  0
      .
  
  end.
  
  create ttVB_AdvancePayment-P.
  
  assign
    ttVB_AdvancePayment-P.Owning_Obj = ttV_BelegPos-P.V_BelegPos_Obj
  
    ttVB_AdvancePayment-P.AmountNetPartPmtInv         = (if ttV_BelegKopf-P.Brutto = no then
                                                           ttV_BelegPos-P.Gesamtpreis
                                                         else
                                                           (ttV_BelegPos-P.Gesamtpreis / (1 + ttV_BelegPos-P.Steuersatz / 100))) * -1
    ttVB_AdvancePayment-P.AmountNetEURPartPmtInv      = ttVB_AdvancePayment-P.AmountNetPartPmtInv / ttS_Waehrung-P1.Eurofaktor
    ttVB_AdvancePayment-P.TaxAmountPartPmtInv         = (if ttV_BelegKopf-P.Brutto = no then
                                                           round(ttV_BelegPos-P.Gesamtpreis * ttV_BelegPos-P.Steuersatz / 100,
                                                                 ttV_BelegKopf-P.WaehrungNK)
                                                         else
                                                           round(ttV_BelegPos-P.Gesamtpreis / (100 + ttV_BelegPos-P.Steuersatz) * ttV_BelegPos-P.Steuersatz,
                                                                 ttV_BelegKopf-P.WaehrungNK)) * -1
    ttVB_AdvancePayment-P.TaxAmountEURPartPmtInv      = ttVB_AdvancePayment-P.TaxAmountPartPmtInv / ttS_Waehrung-P1.Eurofaktor
    ttVB_AdvancePayment-P.AmountGrossPartPmtInv       = (if ttV_BelegKopf-P.Brutto = yes then
                                                           ttV_BelegPos-P.Gesamtpreis
                                                         else
                                                           ttV_BelegPos-P.Gesamtpreis + round(ttV_BelegPos-P.Gesamtpreis * ttV_BelegPos-P.Steuersatz / 100,
                                                                                              ttV_BelegKopf-P.WaehrungNK)) * -1
    ttVB_AdvancePayment-P.AmountGrossEURPartPmtInv    = ttVB_AdvancePayment-P.AmountGrossPartPmtInv / ttS_Waehrung-P1.Eurofaktor
  
    ttVB_AdvancePayment-PSum.AmountNetPartPmtInv      = ttVB_AdvancePayment-PSum.AmountNetPartPmtInv      +  ttVB_AdvancePayment-P.AmountNetPartPmtInv
    ttVB_AdvancePayment-PSum.AmountNetEURPartPmtInv   = ttVB_AdvancePayment-PSum.AmountNetEURPartPmtInv   +  ttVB_AdvancePayment-P.AmountNetEURPartPmtInv
    ttVB_AdvancePayment-PSum.TaxAmountPartPmtInv      = ttVB_AdvancePayment-PSum.TaxAmountPartPmtInv      +  ttVB_AdvancePayment-P.TaxAmountPartPmtInv
    ttVB_AdvancePayment-PSum.TaxAmountEURPartPmtInv   = ttVB_AdvancePayment-PSum.TaxAmountEURPartPmtInv   +  ttVB_AdvancePayment-P.TaxAmountEURPartPmtInv
    ttVB_AdvancePayment-PSum.AmountGrossPartPmtInv    = ttVB_AdvancePayment-PSum.AmountGrossPartPmtInv    +  ttVB_AdvancePayment-P.AmountGrossPartPmtInv
    ttVB_AdvancePayment-PSum.AmountGrossEURPartPmtInv = ttVB_AdvancePayment-PSum.AmountGrossEURPartPmtInv +  ttVB_AdvancePayment-P.AmountGrossEURPartPmtInv
    .
  
  /*--------------------------------------------------------------------------*/
  /* Load buffers ttV_BelegPos-PPmtInv & ttV_BelegKopf-PPmtInv                */
  /*--------------------------------------------------------------------------*/

  find bV_BelegPos-PPmtInv
    where bV_BelegPos-PPmtInv.Firma       = ttV_BelegPos-P.Firma
      and bV_BelegPos-PPmtInv.Belegart    = ttV_BelegPos-P.Herk_Belegart
      and bV_BelegPos-PPmtInv.ReferenzNr  = ttV_BelegPos-P.Herk_ReferenzNr
      and bV_BelegPos-PPmtInv.LfdNr_SR    = 0
      and bV_BelegPos-PPmtInv.PositionsNr = ttV_BelegPos-P.Herk_PositionsNr
    no-lock no-error.

  if available bV_BelegPos-PPmtInv then
  do:

    create ttV_BelegPos-PPmtInv.

    {buffer-copy
       bV_BelegPos-PPmtInv
       to ttV_BelegPos-PPmtInv
       assign
         "ttV_BelegPos-PPmtInv.Owning_Obj = ttV_BelegPos-P.V_BelegPos_Obj
          ttV_BelegPos-PPmtInv.Firma      = gcFirma"}

    find bV_BelegKopf-PPmtInv
      where bV_BelegKopf-PPmtInv.Firma       = ttV_BelegPos-P.Firma
        and bV_BelegKopf-PPmtInv.Belegart    = ttV_BelegPos-P.Herk_Belegart
        and bV_BelegKopf-PPmtInv.ReferenzNr  = ttV_BelegPos-P.Herk_ReferenzNr
      no-lock.

    if available bV_BelegKopf-PPmtInv
      and not can-find (ttV_BelegKopf-PPmtInv
                          where ttV_BelegKopf-PPmtInv.Firma      = bV_BelegKopf-PPmtInv.Firma
                            and ttV_BelegKopf-PPmtInv.Belegart   = bV_BelegKopf-PPmtInv.Belegart
                            and ttV_BelegKopf-PPmtInv.ReferenzNr = bV_BelegKopf-PPmtInv.ReferenzNr) then
    do:

      create ttV_BelegKopf-PPmtInv.

      {buffer-copy
         bV_BelegKopf-PPmtInv
         to ttV_BelegKopf-PPmtInv
         assign
           "ttV_BelegKopf-PPmtInv.Firma = gcFirma"}

      /* fill fields OP_Aktiv and AusgleichDatum for */

      if available ttS_Artikel-P
        and ttS_Artikel-P.Artikelart        = {&pa_S_PT_PartPayAndMarkdowns}
        and ttV_BelegKopf-P.Belegart        = 'R':U
        and ttV_BelegKopf-P.Schlussrechnung = yes
        and ttV_BelegPos-P.Satzart          = 'A':U
        and ttV_BelegPos-P.Wertposition     = yes   then
      do:

      run vert/proc/v_vdru06.p (ttV_BelegPos-P.Firma,
                                ttV_BelegPos-P.Herk_Belegart,
                                ttV_BelegPos-P.Herk_ReferenzNr,
                                output ttV_BelegPos-PPmtInv.OP_Aktiv,
                                output ttV_BelegPos-PPmtInv.AusgleichDatum). 

      end.

    end.   /* available bV_BelegKopf-PPmtInv */

  end.  /* available bV_BelegPos-PPmtInv */

end procedure. /* fillAdvancePaymentLineForLLPrint */


/* _UIB-CODE-BLOCK-END */
&ANALYZE-RESUME

&ENDIF

&IF DEFINED(EXCLUDE-fillPostBillingLineInfoForLLPrint) = 0 &THEN

&IF DEFINED(EXCLUDE-FillContactInformation) = 0 &THEN

&ANALYZE-SUSPEND _UIB-CODE-BLOCK _PROCEDURE FillContactInformation Method-Library
procedure FillContactInformation :
/* Description ---------------------------------------------------------------*/
/*                                                                            */
/* fill ttS_Ansprech with data of the contact person                          */
/*                                                                            */
/*----------------------------------------------------------------------------*/
define buffer bS_Ansprech   for S_Ansprech.
define buffer bS_Adresse    for S_Adresse.
define buffer bVBT_Contacts for VBT_Contacts.

  ttV_BelegKopf-P.S_Ansprech_Obj = VBCContactPersonSvc:prpoInstance:cGetMasterContactOID
                                     (ttV_BelegKopf-P.V_BelegKopf_Obj,
                                      integer(SBCContactTypeEnu:Customer)).

  if ttV_BelegKopf-P.S_Ansprech_Obj > '':U then
  do:

    create ttS_Ansprech-P.
    create ttS_Adresse-PCoP.

    SBCSessionSvc:prpoInstance:FetchContactPerson
      (buffer bS_Ansprech,
       buffer ttV_BelegKopf-P:handle).

    if available bS_Ansprech then
    do:

      /* copy contact person details */

      {buffer-copy
         bS_Ansprech
         to ttS_Ansprech-P}

      /* if the contact person has no private address use invoice address     */
      /* details and details directly from the contact person record.         */

      if ttS_Ansprech-P.AdressNr = ? then
      do:

        {buffer-copy
           ttS_Adresse-PInv
           to ttS_Adresse-PCoP
           assign
             "ttS_Adresse-PCoP.Anrede      = ttS_Ansprech-P.Anrede
              ttS_Adresse-PCoP.Titel       = ttS_Ansprech-P.Titel
              ttS_Adresse-PCoP.Vorname     = ttS_Ansprech-P.Vorname
              ttS_Adresse-PCoP.Name1       = ttS_Ansprech-P.Nachname
              ttS_Adresse-PCoP.Name2       = '':U
              ttS_Adresse-PCoP.Name3       = '':U
              ttS_Adresse-PCoP.Briefanrede = ttS_Ansprech-P.Briefanrede
              ttS_Adresse-PCoP.Telefon     = ttS_Ansprech-P.Telefon
              ttS_Adresse-PCoP.Telefax     = ttS_Ansprech-P.Telefax
              ttS_Adresse-PCoP.EMail       = ttS_Ansprech-P.EMail
              ttS_Adresse-PCoP.Handy       = ttS_Ansprech-P.Handy
              ttS_Adresse-PCoP.AdressNr    = 0"}
        ttS_Ansprech-P.AdressNr = 0.

      end.
      /* if the contact person has a private address, it is used                */
      else
      do:
        
        find bS_Adresse
          where bS_Adresse.Firma    = {firma/s_adres.fir ttS_Ansprech-P.Firma}
            and bS_Adresse.AdressNr = ttS_Ansprech-P.AdressNr
          no-lock no-error.

        if available bS_Adresse then
          {buffer-copy
             bS_Adresse
             to ttS_Adresse-PCoP}
      end.
      
    end. /* if available bS_Ansprech */
    else
    do:
      /* there is no contact person assigned to the document  - use details     */
      /* customer and invoice address instead, so that the records              */
      /* ttS_Ansprech-P and ttS_Adresse-PCoP contain printable data.            */

      assign
        ttS_Ansprech-P.Briefanrede = ttS_Adresse-PCust.Briefanrede
        ttS_Ansprech-P.Telefon     = ttS_Adresse-PCust.Telefon
        ttS_Ansprech-P.Telefax     = ttS_Adresse-PCust.Telefax
        ttS_Ansprech-P.EMail       = ttS_Adresse-PCust.EMail
        .
      {buffer-copy
         ttS_Adresse-PInv
         to ttS_Adresse-PCoP}

    end.

  end. /* if ttV_BelegKopf-P.S_Ansprech_Obj > '':U  */
  else
  do:

    VBCContactPersonSvc:prpoInstance:GetContactPersonBuffer
      (ttV_BelegKopf-P.V_BelegKopf_Obj,
       buffer bVBT_Contacts).

    if available bVBT_Contacts then
    do:

      create ttS_Ansprech-P.

      {buffer-copy
         bVBT_Contacts
         to ttS_Ansprech-P
         assign
           "ttS_Ansprech-P.Name         = bVBT_Contacts.Name
            ttS_Ansprech-P.Vorname      = bVBT_Contacts.FirstName
            ttS_Ansprech-P.Nachname     = bVBT_Contacts.LastName
            ttS_Ansprech-P.Abteilung    = bVBT_Contacts.Department
            ttS_Ansprech-P.Funktion     = bVBT_Contacts.Function
            ttS_Ansprech-P.Telefon      = bVBT_Contacts.Telephone
            ttS_Ansprech-P.Handy        = bVBT_Contacts.CellPhone
            ttS_Ansprech-P.Telefax      = bVBT_Contacts.Fax
            ttS_Ansprech-P.EMail        = bVBT_Contacts.EMail
            ttS_Ansprech-P.Anrede       = bVBT_Contacts.Salutation
            ttS_Ansprech-P.Titel        = bVBT_Contacts.ContactTitle
            ttS_Ansprech-P.AdressAnrede = bVBT_Contacts.AdressSalutation
            ttS_Ansprech-P.BriefAnrede  = bVBT_Contacts.LetterSalutation"}

    end. /* if available bVBT_Contacts */

  end. /* else if ttV_BelegKopf-P.S_Ansprech_Obj > */

end procedure. /* FillContactInformation */


/* _UIB-CODE-BLOCK-END */
&ANALYZE-RESUME

&ENDIF


&IF lookup("U_CA":U,"{&PA-OPTIONEN}":U) > 0 &THEN

&ANALYZE-SUSPEND _UIB-CODE-BLOCK _PROCEDURE fillPostBillingLineInfoForLLPrint Method-Library 
procedure fillPostBillingLineInfoForLLPrint :
/* Description ---------------------------------------------------------------*/
/*                                                                            */
/* Create and fill ttVFT_PostBillingLine-P record for the current             */
/* ttV_BelegPos-P buffers                                                     */
/*                                                                            */
/* Notes ---------------------------------------------------------------------*/
/*                                                                            */
/* This procedure can only be used in the context of this DAO !               */
/* run super() must have been executed and a global ttV_BelegKopf-P  and      */
/* ttV_BelegPos-P must be available!                                          */
/*                                                                            */
/*----------------------------------------------------------------------------*/

define buffer bVFT_PostBillingLine      for VFT_PostBillingLine.
define buffer bV_BelegPos-RG            for V_BelegPos.
define buffer bV_BelegPos-Lieferschein  for V_BelegPos.
define buffer bS_MengenEinheitSpr       for S_MengenEinheitSpr.
define buffer bS_PreisEinheitSpr        for S_PreisEinheitSpr.
define buffer bS_WaehrungSpr            for S_WaehrungSpr.

define buffer bttVFT_PostBillingLine-P  for temp-table ttVFT_PostBillingLine-P.


  if lookup(ttV_BelegPos-P.Belegart,'R,G':U) > 0 then
  do:

    find bV_BelegPos-RG
      where bV_BelegPos-RG.V_BelegPos_Obj = ttV_BelegPos-P.V_BelegPos_Obj
      no-lock.

    if bV_BelegPos-RG.Satzart = 'A':U 
      and vert.fakt.cls.VFCPostBillingSvc:prpoInstance:lDocIsRGGeneratedFromVPB (buffer bV_BelegPos-RG) then
    do:

      find bVFT_PostBillingLine                   /* code checked by UPa 03.03.2022 */
        where bVFT_PostBillingLine.V_BelegPos_Obj = bV_BelegPos-RG.V_BelegPos_Obj
          and bVFT_PostBillingLine.archiviert     = yes
        no-lock.

      find bV_BelegPos-Lieferschein
        where bV_BelegPos-Lieferschein.V_BelegPos_Obj = bVFT_PostBillingLine.Origin_Obj
        no-lock.  

      create bttVFT_PostBillingLine-P.

      {buffer-copy
         bVFT_PostBillingLine
         to bttVFT_PostBillingLine-P
         assign
           "bttVFT_PostBillingLine-P.Owning_Obj_Pos = ttV_BelegPos-P.V_BelegPos_Obj"}

      validate bttVFT_PostBillingLine-P.

      assign
        bttVFT_PostBillingLine-P.PF_Ist_Menge        = bVFT_PostBillingLine.Ist_Menge        / bV_BelegPos-Lieferschein.VME_Faktor
        bttVFT_PostBillingLine-P.PF_NachfakturaMenge = bVFT_PostBillingLine.NachfakturaMenge / bV_BelegPos-Lieferschein.VME_Faktor
        bttVFT_PostBillingLine-P.PF_Soll_Menge       = bVFT_PostBillingLine.Soll_Menge       / bV_BelegPos-Lieferschein.VME_Faktor
        bttVFT_PostBillingLine-P.PF_VorschlagsStatus = adm.config.cls.DCCAppConfigSvc:prpoInstance:cParamValByRefParamValLng
                                                         ('VF_VPBState_desc':U,
                                                          bVFT_PostBillingLine.VorschlagsStatus,
                                                          pACConnectionSvc:prpcLanguage)
        bttVFT_PostBillingLine-P.PF_ZahlungsArt_Info = adm.config.cls.DCCAppConfigSvc:prpoInstance:cParamValByRefParamValLng
                                                         ('SB_PaymentMethods_desc':U,
                                                          bVFT_PostBillingLine.ZahlungsArt,
                                                          pACConnectionSvc:prpcLanguage)
        .

      empty temp-table TT_V_PreisFind.
      create TT_V_PreisFind.

      assign
        TT_V_PreisFind.Einzelpreis             = bVFT_PostBillingLine.Ist_Einzelpreis
        TT_V_PreisFind.Menge                   = bVFT_PostBillingLine.Soll_Menge
        TT_V_PreisFind.PreisFaktor             = bVFT_PostBillingLine.PreisFaktor
        TT_V_PreisFind.isDiscSurOnTotalPrice_1 = bVFT_PostBillingLine.Diff_isDiscSurOnTotalPrice_1
        TT_V_PreisFind.isDiscSurOnTotalPrice_2 = bVFT_PostBillingLine.Diff_isDiscSurOnTotalPrice_2
        TT_V_PreisFind.Wert_RZ_1               = bVFT_PostBillingLine.Ist_Wert_RZ_1
        TT_V_PreisFind.Wert_RZ_2               = bVFT_PostBillingLine.Ist_Wert_RZ_2
        TT_V_PreisFind.WaehrungNK              = ttV_BelegKopf-P.WaehrungNK
        .

      bttVFT_PostBillingLine-P.PF_Ist_Gesamtpreis = 
        &IF LOOKUP("Q_DEL":U,"{&PA-OPTIONEN}":U) > 0 &THEN
          bVFT_PostBillingLine.Ist_Metallzuschlag +
        &ENDIF
        {fnarg
          d_ZeilenGesamtPreisPostBillingLine
          "buffer TT_V_Preisfind,
           bVFT_PostBillingLine.Ist_abs_RZ_1,
           bVFT_PostBillingLine.Ist_abs_RZ_2,
           bVFT_PostBillingLine.Ist_abs_RZ_3"}.

      empty temp-table TT_V_PreisFind.
      create TT_V_PreisFind.

      assign
        TT_V_PreisFind.Einzelpreis             = bVFT_PostBillingLine.Soll_Einzelpreis
        TT_V_PreisFind.Menge                   = bVFT_PostBillingLine.Soll_Menge
        TT_V_PreisFind.PreisFaktor             = bVFT_PostBillingLine.PreisFaktor
        TT_V_PreisFind.isDiscSurOnTotalPrice_1 = bVFT_PostBillingLine.Diff_isDiscSurOnTotalPrice_1
        TT_V_PreisFind.isDiscSurOnTotalPrice_2 = bVFT_PostBillingLine.Diff_isDiscSurOnTotalPrice_2
        TT_V_PreisFind.Wert_RZ_1               = bVFT_PostBillingLine.Soll_Wert_RZ_1
        TT_V_PreisFind.Wert_RZ_2               = bVFT_PostBillingLine.Soll_Wert_RZ_2
        TT_V_PreisFind.WaehrungNK              = ttV_BelegKopf-P.WaehrungNK
        .

      bttVFT_PostBillingLine-P.PF_Soll_Gesamtpreis = 
        &IF LOOKUP("Q_DEL":U,"{&PA-OPTIONEN}":U) > 0 &THEN
          bVFT_PostBillingLine.Soll_Metallzuschlag +
        &ENDIF
        {fnarg
          d_ZeilenGesamtPreisPostBillingLine
          "buffer TT_V_Preisfind,
           bVFT_PostBillingLine.Soll_abs_RZ_1,
           bVFT_PostBillingLine.Soll_abs_RZ_2,
           bVFT_PostBillingLine.Soll_abs_RZ_3"}.

      empty temp-table TT_V_PreisFind.
      create TT_V_PreisFind.

      assign
        TT_V_PreisFind.Einzelpreis             = bVFT_PostBillingLine.Diff_Einzelpreis
        TT_V_PreisFind.Menge                   = bVFT_PostBillingLine.NachfakturaMenge
        TT_V_PreisFind.PreisFaktor             = bVFT_PostBillingLine.PreisFaktor
        TT_V_PreisFind.isDiscSurOnTotalPrice_1 = bVFT_PostBillingLine.Diff_isDiscSurOnTotalPrice_1
        TT_V_PreisFind.isDiscSurOnTotalPrice_2 = bVFT_PostBillingLine.Diff_isDiscSurOnTotalPrice_2
        TT_V_PreisFind.Wert_RZ_1               = bVFT_PostBillingLine.Diff_Wert_RZ_1
        TT_V_PreisFind.Wert_RZ_2               = bVFT_PostBillingLine.Diff_Wert_RZ_2
        TT_V_PreisFind.WaehrungNK              = ttV_BelegKopf-P.WaehrungNK
        .

      bttVFT_PostBillingLine-P.PF_Diff_Gesamtpreis = 
        &IF LOOKUP("Q_DEL":U,"{&PA-OPTIONEN}":U) > 0 &THEN
          bVFT_PostBillingLine.Diff_Metallzuschlag +
        &ENDIF
        {fnarg
          d_ZeilenGesamtPreisPostBillingLine
          "buffer TT_V_Preisfind,
           bVFT_PostBillingLine.Diff_abs_RZ_1,
           bVFT_PostBillingLine.Diff_abs_RZ_2,
           bVFT_PostBillingLine.Diff_abs_RZ_3"}.

      {adm/incl/d__spr00.if
        &Tabelle  = "bS_MengenEinheitSpr"
        &Selekt   = "where bS_MengenEinheitSpr.Firma         = {firma/smngeinh.fir pACConnectionSvc:prpcCompany}
                       and bS_MengenEinheitSpr.Mengeneinheit = bVFT_PostBillingLine.Mengeneinheit"
        &Sprache  = "gcContentLanguage"
        &no-error = "no-error"
      }

      if available bS_MengenEinheitSpr then
        assign
          bttVFT_PostBillingLine-P.BezeichnungME = bS_MengenEinheitSpr.Bezeichnung
          bttVFT_PostBillingLine-P.KurzBezME     = bS_MengenEinheitSpr.KurzBez
          .

      {adm/incl/d__spr00.if
        &Tabelle = "bS_PreisEinheitSpr"
        &Selekt  = "where bS_PreisEinheitSpr.Firma        = {firma/spreeinh.fir pACConnectionSvc:prpcCompany}
                      and bS_PreisEinheitSpr.Preiseinheit = bVFT_PostBillingLine.Preiseinheit"
        &Sprache = "gcContentLanguage"
        &no-error = "no-error"
      }

      if available bS_PreisEinheitSpr then
        assign
          bttVFT_PostBillingLine-P.KurzBezPE = bS_PreisEinheitSpr.KurzBez
          .

      {adm/incl/d__spr00.if
        &Tabelle  = "bS_WaehrungSpr"
        &Selekt   = "where bS_WaehrungSpr.Firma    = {firma/swaehrun.fir pACConnectionSvc:prpcCompany}
                       and bS_WaehrungSpr.Waehrung = ttV_BelegKopf-P.Waehrung"
        &Sprache  = "gcContentLanguage"
        &no-error = "no-error"
      }

      if available bS_WaehrungSpr then
        assign
          bttVFT_PostBillingLine-P.KurzBezWAE = bS_WaehrungSpr.KurzBez
          .

      validate bttVFT_PostBillingLine-P.

    end. /* bV_BelegPos-RG.Satzart = 'A':U ... */

  end. /* lookup(ttV_BelegPos-P.Belegart,'R,G':U) > 0 */

end procedure. /* fillPostBillingLineInfoForLLPrint */


/* _UIB-CODE-BLOCK-END */
&ANALYZE-RESUME

&ENDIF /*  lookup U_CA  */

&ENDIF

&IF DEFINED(EXCLUDE-fillBlanketOrderInfoForLLPrint) = 0 &THEN

&IF lookup("VU_RAAUF":U,"{&PA-OPTIONEN}":U) > 0 &THEN

&ANALYZE-SUSPEND _UIB-CODE-BLOCK _PROCEDURE fillBlanketOrderInfoForLLPrint Method-Library 
procedure fillBlanketOrderInfoForLLPrint :
/* Description ---------------------------------------------------------------*/
/*                                                                            */
/* Create and fill ttV_BlanketOrder-P record for the current                  */
/* ttV_BelegKopf-P / ttV_BelegPos-P buffers                                   */
/*                                                                            */
/* Notes ---------------------------------------------------------------------*/
/*                                                                            */
/* This procedure does only encapsulate code for better readability of        */
/* fillDataset procedure. It can only be used in the context of this DAO !    */
/* run super() must have been executed and a global ttV_BelegKopf-P  and      */
/* ttV_BelegPos-P must be available!                                          */
/*                                                                            */
/*----------------------------------------------------------------------------*/

define variable cV_BelegPos-Blanket_Obj like V_BelegPos.V_BelegPos_Obj  no-undo.

define buffer bV_BelegKopf-Blanket for V_BelegKopf.
define buffer bV_BelegPos-Blanket  for V_BelegPos.
define buffer bS_MengenEinheitSpr  for S_MengenEinheitSpr.

define buffer bttV_BlanketOrder-P for temp-table ttV_BlanketOrder-P.


  if   not can-do('U,L,R,G,VFP':U,ttV_BelegKopf-P.Belegart)
    or ttV_BelegPos-P.Herk_Belegart = '':U then /* the relationship to a blanket order is only defined in the line */
    return.

  cV_BelegPos-Blanket_Obj = vert.base.cls.VBCSalesDocSvc:prpoInstance:cGetSourceDocLineObj
                              ('VUR':U, ttV_BelegPos-P.V_BelegPos_Obj).

  if cV_BelegPos-Blanket_Obj = '':U then
    return.

  find bV_BelegPos-Blanket
    where bV_BelegPos-Blanket.V_BelegPos_Obj = cV_BelegPos-Blanket_Obj
    no-lock no-error.

  if available bV_BelegPos-Blanket then

    find bV_BelegKopf-Blanket
      where bV_BelegKopf-Blanket.Firma      = bV_BelegPos-Blanket.Firma
        and bV_BelegKopf-Blanket.BelegArt   = bV_BelegPos-Blanket.BelegArt
        and bV_BelegKopf-Blanket.ReferenzNr = bV_BelegPos-Blanket.ReferenzNr
      no-lock no-error.

  if available bV_BelegKopf-Blanket
    and available bV_BelegPos-Blanket then
  do:

    create bttV_BlanketOrder-P.

    assign
      bttV_BlanketOrder-P.Owning_Obj       = ttV_BelegPos-P.V_BelegPos_Obj
      bttV_BlanketOrder-P.AuftragsNr       = bV_BelegKopf-Blanket.Belegnummer
      bttV_BlanketOrder-P.AuftragsDatum    = bV_BelegKopf-Blanket.Belegdatum
      bttV_BlanketOrder-P.Vertragsnummer   = bV_BelegKopf-Blanket.Vertragsnummer
      bttV_BlanketOrder-P.VertragsDatum    = bV_BelegKopf-Blanket.Vertragsdatum
      bttV_BlanketOrder-P.PositionsNr      = bV_BelegPos-Blanket.PositionsNr
      bttV_BlanketOrder-P.Beleginfo        = bV_BelegKopf-Blanket.Beleginfo
      bttV_BlanketOrder-P.RahmenMenge      = bV_BelegPos-Blanket.Menge
      bttV_BlanketOrder-P.gelieferteMenge  = bV_BelegPos-Blanket.gelieferte_Menge
      bttV_BlanketOrder-P.beauftragteMenge = bV_BelegPos-Blanket.beauftragte_Menge
      bttV_BlanketOrder-P.Mindestmenge     = bV_BelegPos-Blanket.Mindestmenge
      .

    {adm/incl/d__spr00.if
      &Tabelle  = "bS_MengenEinheitSpr"
      &Selekt   = "where bS_MengenEinheitSpr.Firma          = {firma/smngeinh.fir bV_BelegKopf-Blanket.Firma}
                      and bS_MengenEinheitSpr.Mengeneinheit = bV_BelegPos-Blanket.Mengeneinheit"
      &Sprache  = "gcContentLanguage"
      &no-error = "no-error"
    }

    if available bS_MengenEinheitSpr then

      bttV_BlanketOrder-P.RahmenME = bS_MengenEinheitSpr.KurzBez.

  end. /* if available bV_BelegKopf-Blanket */

end procedure. /* fillBlanketOrderInfoForLLPrint */


/* _UIB-CODE-BLOCK-END */
&ANALYZE-RESUME

&ENDIF /*  lookup VU_RAAUF  */

&ENDIF

&IF DEFINED(EXCLUDE-fillCallforLLPrint) = 0 &THEN

&IF lookup("VS_CALL","{&PA-OPTIONEN}") > 0 &THEN

&ANALYZE-SUSPEND _UIB-CODE-BLOCK _PROCEDURE fillCallforLLPrint Method-Library 
procedure fillCallforLLPrint :
/* Description ---------------------------------------------------------------*/
/*                                                                            */
/* Create and fill Shipping Documents that are predecessors of ttV_BelegPos-P */
/* records.                                                                   */
/*                                                                            */
/* Notes ---------------------------------------------------------------------*/
/*                                                                            */
/* This procedure does only encapsulate code for better readability of        */
/* fillDataset procedure. It can only be used in the context of this DAO !    */
/* run super() must have been executed and a global ttV_BelegKopf-P  and      */
/* ttV_BelegPos-P must be available!                                          */
/*                                                                            */
/*----------------------------------------------------------------------------*/

define variable cSourceDocLineObj   as character                              no-undo.
define variable oIBCDocumentInfoDio as class info.base.cls.IBCDocumentInfoDio no-undo.

define buffer bVST_CallPosition       for VST_CallPosition.
define buffer bVST_Call               for VST_Call.
define buffer bttVST_CallPosition-P1  for temp-table ttVST_CallPosition-P1.
define buffer bttVST_Call-P           for temp-table ttVST_Call-P.

if    can-do('L,G,R,VUD':U, ttV_BelegKopf-P.Belegart)
  and ttV_BelegKopf-P.Herk_Belegart <> ? then
do:

  /* for current V_BelegPos: look for a source doc of type call     */
  /* (could be in the order VSC-R-G-R)                              */

  cSourceDocLineObj = vert.base.cls.VBCSalesDocSvc:prpoInstance:cGetSourceDocLineObj
                          ('VSC':U,
                            ttV_BelegPos-P.V_BelegPos_Obj).

  if cSourceDocLineObj <> ?
    and not can-find (bttVST_CallPosition-P1
                        where bttVST_CallPosition-P1.VST_CallPosition_Obj = cSourceDocLineObj) then

    find bVST_CallPosition
      where bVST_CallPosition.VST_CallPosition_Obj = cSourceDocLineObj
      no-lock no-error.

  if available bVST_CallPosition then
  do:

    if bVST_CallPosition.Origin_Obj > '':U then

       oIBCDocumentInfoDio = info.base.cls.IBCDocumentInfoDio:create(bVST_CallPosition.Origin_Obj, '':U).

    create bttVST_CallPosition-P1.

    {buffer-copy
       bVST_CallPosition
       to bttVST_CallPosition-P1
       assign
         "bttVST_CallPosition-P1.Firma            = gcFirma
          bttVST_CallPosition-P1.Owning_Obj       = ttV_BelegPos-P.V_BelegPos_Obj"}

    if valid-object(oIBCDocumentInfoDio)
      and oIBCDocumentInfoDio:prplIsValid = yes then

    assign
      bttVST_CallPosition-P1.Herkunft         = oIBCDocumentInfoDio:prpcDocumentInfo
      bttVST_CallPosition-P1.OriginDocType    = {fnarg
                                                   pa_cStCchDocTypeDesc
                                                   "oIBCDocumentInfoDio:prpcDocumentType,
                                                    pACConnectionSvc:prpcLanguage,
                                                    1"}
      bttVST_CallPosition-P1.OriginDocNumber  = oIBCDocumentInfoDio:prpiDocumentNumber
      bttVST_CallPosition-P1.OriginLineNumber = oIBCDocumentInfoDio:prpdDocumentPosition
      .

    validate bttVST_CallPosition-P1.

    find bVST_Call
      where bVST_Call.VST_Call_Obj = bVST_CallPosition.VST_Call_Obj
      no-lock.

     /* multiple positions might refer to the same head - prevent doubles! */

    if not can-find (bttVST_Call-P
                       where bttVST_Call-P.VST_Call_Obj = bVST_CallPosition.VST_Call_Obj) then
    do:

      create bttVST_Call-P.

      {buffer-copy
         bVST_Call
         to bttVST_Call-P
         assign
           "bttVST_Call-P.Firma = gcFirma"}

      validate bttVST_Call-P.

    end.

  end. /* if available bVST_CallPosition */

end. /* if    can-do('L,G,R,VUD':U, ttV_BelegKopf-P.Belegart) */

end procedure. /* fillCallforLLPrint */


/* _UIB-CODE-BLOCK-END */
&ANALYZE-RESUME

&ENDIF /* lookup VS_CALL */

&ENDIF

&IF DEFINED(EXCLUDE-fillCallOrderReleaseInfoForLLPrint) = 0 &THEN

&IF lookup("VU_ABAUF":U,"{&PA-OPTIONEN}":U) > 0 &THEN

&ANALYZE-SUSPEND _UIB-CODE-BLOCK _PROCEDURE fillCallOrderReleaseInfoForLLPrint Method-Library 
procedure fillCallOrderReleaseInfoForLLPrint :
/* Description ---------------------------------------------------------------*/
/*                                                                            */
/* Create and fill ttVU_CallOrderRelease-P record for the current             */
/* ttV_BelegKopf-P / ttV_BelegPos-P buffers                                   */
/*                                                                            */
/* Notes ---------------------------------------------------------------------*/
/*                                                                            */
/* This procedure does only encapsulate code for better readability of        */
/* fillDataset procedure. It can only be used in the context of this DAO !    */
/* run super() must have been executed and a global ttV_BelegKopf-P  and      */
/* ttV_BelegPos-P must be available!                                          */
/*                                                                            */
/*----------------------------------------------------------------------------*/
define variable cCallOrderRelease as character                        no-undo.

define buffer bV_BelegKopf-VUA for V_BelegKopf.
define buffer bVU_RA_Abruf     for VU_RA_Abruf.
define buffer bVU_RA_Pos       for VU_RA_Pos.


  cCallOrderRelease = vert.base.cls.VBCSalesDocSvc:prpoInstance:cCallOrderReleaseOfDocument
                                                                  (ttV_BelegKopf-P.V_BelegKopf_Obj,
                                                                   ttV_BelegPos-P.V_BelegPos_Obj).

  if cCallOrderRelease = '':U then
    return.

  /* Abrufauftrag, Abruf und AbrufPosition laden */

  find bV_BelegKopf-VUA
    where bV_BelegKopf-VUA.Firma      = {firma/vbelegko.fir ttV_BelegKopf-P.Firma}
      and bV_BelegKopf-VUA.Belegart   = entry(1,cCallOrderRelease,{&PA-DELIMITER3})
      and bV_BelegKopf-VUA.ReferenzNr = integer(entry(2,cCallOrderRelease,{&PA-DELIMITER3}))
    no-lock no-error.

  find bVU_RA_Abruf
    where bVU_RA_Abruf.Firma       = {firma/vbelegko.fir ttV_BelegKopf-P.Firma}
      and bVU_RA_Abruf.Belegart    = entry(1,cCallOrderRelease,{&PA-DELIMITER3})
      and bVU_RA_Abruf.ReferenzNr  = integer(entry(2,cCallOrderRelease,{&PA-DELIMITER3}))
      and bVU_RA_Abruf.PositionsNr = integer(entry(3,cCallOrderRelease,{&PA-DELIMITER3})) / 10
      and bVU_RA_Abruf.AbrufArt    = entry(4,cCallOrderRelease,{&PA-DELIMITER3})
      and bVU_RA_Abruf.AbrufNr     = integer(entry(5,cCallOrderRelease,{&PA-DELIMITER3}))
    no-lock no-error.

  /* Nur bei JiT-Abrufen besteht eine direkte Verknüpfung zum Terminbedarf. */

  if available bV_BelegKopf-VUA
    and available bVU_RA_Abruf
    and bV_BelegKopf-VUA.JiT = yes then
  do:

    find bVU_RA_Pos
      where bVU_RA_Pos.Firma       = {firma/vbelegko.fir ttV_BelegKopf-P.Firma}
        and bVU_RA_Pos.Belegart    = entry(1,cCallOrderRelease,{&PA-DELIMITER3})
        and bVU_RA_Pos.ReferenzNr  = integer(entry(2,cCallOrderRelease,{&PA-DELIMITER3}))
        and bVU_RA_Pos.PositionsNr = integer(entry(3,cCallOrderRelease,{&PA-DELIMITER3})) / 10
        and bVU_RA_Pos.AbrufArt    = entry(4,cCallOrderRelease,{&PA-DELIMITER3})
        and bVU_RA_Pos.AbrufNr     = integer(entry(5,cCallOrderRelease,{&PA-DELIMITER3}))
        and bVU_RA_Pos.LfdNr       = integer(entry(6,cCallOrderRelease,{&PA-DELIMITER3}))
      no-lock no-error.

  end.

  if  available bV_BelegKopf-VUA
    and available bVU_RA_Abruf then
  do:

    create ttVU_CallOrderRelease-P.
    assign
      ttVU_CallOrderRelease-P.Owning_Obj        = ttV_BelegPos-P.V_BelegPos_Obj
      ttVU_CallOrderRelease-P.Abruf             = bVU_RA_Abruf.Abruf
      ttVU_CallOrderRelease-P.AbrufDatum        = bVU_RA_Abruf.Abrufdatum
      ttVU_CallOrderRelease-P.AuftragsNr        = bV_BelegKopf-VUA.AuftragsNr
      ttVU_CallOrderRelease-P.AuftragsDatum     = bV_BelegKopf-VUA.AuftragsDatum
      ttVU_CallOrderRelease-P.Vertragsnummer    = bV_BelegKopf-VUA.Vertragsnummer
      ttVU_CallOrderRelease-P.VertragsDatum     = bV_BelegKopf-VUA.VertragsDatum
      ttVU_CallOrderRelease-P.VerwSchluessel    = bVU_RA_Abruf.VerwSchluessel
      /* -->  JWA Erweiterung des LL Drucks Lieferschein */
      &IF LOOKUP("U_CI":U,"{&PA-OPTIONEN}":U) > 0 &THEN
      ttVU_CallOrderRelease-P.uCI_Hinweis1      = bVU_RA_Abruf.uCI_Hinweis1
      ttVU_CallOrderRelease-P.uCI_Hinweis2      = bVU_RA_Abruf.uCI_Hinweis2
      ttVU_CallOrderRelease-P.uCI_Hinweis3      = bVU_RA_Abruf.uCI_Hinweis3
      ttVU_CallOrderRelease-P.uCI_Hinweis4      = bVU_RA_Abruf.uCI_Hinweis4
      ttVU_CallOrderRelease-P.uCA_Approved      = bVU_RA_Abruf.uCA_Approved
      ttVU_CallOrderRelease-P.uCI_LagerortKunde = bVU_RA_Abruf.uCI_LagerortKunde
      ttVU_CallOrderRelease-P.uCI_Verbrauchsstelle = bVU_RA_Abruf.uCI_Verbrauchsstelle
      ttVU_CallOrderRelease-P.uCI_ZeichenKunde  = bVU_RA_Abruf.uCI_ZeichenKunde
      &ENDIF
      /* <--  JWA Erweiterung des LL Drucks Lieferschein */
      &IF LOOKUP("U_CA":U,"{&PA-OPTIONEN}":U) > 0 &THEN
      ttVU_CallOrderRelease-P.uCA_DistributionZone = bVU_RA_Abruf.uCA_DistributionZone
      &ENDIF
      .

    if available bVU_RA_Pos then

      assign
        ttVU_CallOrderRelease-P.AbrufTermin = bVU_RA_Pos.AbrufTermin
        ttVU_CallOrderRelease-P.AbrufZeit   = bVU_RA_Pos.AbrufZeit
        .
    &IF LOOKUP("U_CA":U,"{&PA-OPTIONEN}":U) > 0 &THEN
    if available bV_BelegKopf-VUA
      and bV_BelegKopf-VUA.uCA_Staging = 2 then do:

      find bVU_RA_Pos
        where bVU_RA_Pos.Firma       = {firma/vbelegko.fir ttV_BelegKopf-P.Firma}
          and bVU_RA_Pos.Belegart    = entry(1,cCallOrderRelease,{&PA-DELIMITER3})
          and bVU_RA_Pos.ReferenzNr  = integer(entry(2,cCallOrderRelease,{&PA-DELIMITER3}))
          and bVU_RA_Pos.PositionsNr = integer(entry(3,cCallOrderRelease,{&PA-DELIMITER3})) / 10
          and bVU_RA_Pos.AbrufArt    = entry(4,cCallOrderRelease,{&PA-DELIMITER3})
          and bVU_RA_Pos.AbrufNr     = integer(entry(5,cCallOrderRelease,{&PA-DELIMITER3}))
          and bVU_RA_Pos.LfdNr       = integer(entry(6,cCallOrderRelease,{&PA-DELIMITER3}))
        no-lock no-error.

      if available bVU_RA_Pos then            
        assign
          ttVU_CallOrderRelease-P.uCI_OriginQuantity   = bVU_RA_Pos.uCI_OriginQuantity
          ttVU_CallOrderRelease-P.uCI_Verbrauchsstelle = bVU_RA_Pos.uCI_Verbrauchsstelle when bVU_RA_Pos.uCI_Verbrauchsstelle > '':U
          ttVU_CallOrderRelease-P.uCI_LagerortKunde    = bVU_RA_Pos.uCI_LagerortKunde when bVU_RA_Pos.uCI_LagerortKunde > '':U
          ttVU_CallOrderRelease-P.uCA_DistributionZone = bVU_RA_Pos.uCA_DistributionZone when bVU_RA_Pos.uCA_DistributionZone > '':U
          ttVU_CallOrderRelease-P.uCA_ReferenceNr      = bVU_RA_Pos.uCA_ReferenceNr
        .
    end. /* if available bV_BelegKopf-VUA */   
    &ENDIF 
   end. /* if  bV_BelegKopf-VUA */

end procedure. /* fillCallOrderReleaseInfoForLLPrint */


/* _UIB-CODE-BLOCK-END */
&ANALYZE-RESUME

&ENDIF /* lookup VU_ABAUF */

&ENDIF


&IF DEFINED(EXCLUDE-fillDropShippingPositionInfo) = 0 &THEN

&ANALYZE-SUSPEND _UIB-CODE-BLOCK _PROCEDURE fillDropShippingPositionInfo Method-Library
procedure fillDropShippingPositionInfo :
/* Description ---------------------------------------------------------------*/
/*                                                                            */
/* Fills V_EndCustomerPartInfo for Delivery note (Production company)         */
/*   document or ER_DeliveryNoteInfo temp-table for Invoice (Sales company)   */
/*   and assigns it to Head table                                             */
/*                                                                            */
/* Notes ---------------------------------------------------------------------*/
/*                                                                            */
/* This procedure does only encapsulate code for better readability of        */
/* fillDataset procedure. It can only be used in the context of this DAO !    */
/* run super() must have been executed and a global ttV_BelegKopf-P  and      */
/* ttV_BelegPos-P must be available!                                          */
/*                                                                            */
/*----------------------------------------------------------------------------*/

define buffer bV_BelegPos-Origin         for V_BelegPos.
define buffer bE_BelegPos-Origin         for E_BelegPos.
define buffer bER_BelegPos-Origin        for ER_BelegPos.
define buffer bttV_EndCustomerPartInfo-P for temp-table ttV_EndCustomerPartInfo-P.
define buffer bttER_DeliveryNoteInfo-P   for temp-table ttER_DeliveryNoteInfo-P.

if ttV_BelegPos-P.Herk_BelegArt = 'U':U then

  case ttV_BelegPos-P.BelegArt:

  &IF LOOKUP("V_","{&PA-MODULE}") > 0 &THEN
    when 'L':U then

      SBCDropShippingSvc:prpoInstance:fillEndCustomerPartLineData(ttV_BelegPos-P.Origin_Obj,
                                                                  ttV_BelegPos-P.V_BelegPos_Obj,
                                                                  input-output table bttV_EndCustomerPartInfo-P).
  &ENDIF

  &IF LOOKUP("ER":U,"{&PA-MODULE}":U) > 0 &THEN
    when 'R':U then
    do:

      find bV_BelegPos-Origin
        where bV_BelegPos-Origin.V_BelegPos_Obj = ttV_BelegPos-P.Origin_Obj
        no-lock no-error.

      if available bV_BelegPos-Origin then

        for each bE_BelegPos-Origin
          where bE_BelegPos-Origin.Firma               = {firma/ebelkop.fir bV_BelegPos-Origin.Firma}
            and bE_BelegPos-Origin.BelegArt            = 'EB':U
            and bE_BelegPos-Origin.Coverage_MRPDocType = bV_BelegPos-Origin.BelegArt
            and bE_BelegPos-Origin.Coverage_Obj        = bV_BelegPos-Origin.V_BelegPos_Obj
            and bE_BelegPos-Origin.Artikel             = bV_BelegPos-Origin.Artikel
          no-lock
          on error undo, throw:

          for each bER_BelegPos-Origin
            where bER_BelegPos-Origin.Firma            = {firma/ebelkop.fir bE_BelegPos-Origin.Firma}
              and bER_BelegPos-Origin.BelegArt         = 'ERR':U
              and bER_BelegPos-Origin.Herk_Belegart    = bE_BelegPos-Origin.BelegArt
              and bER_BelegPos-Origin.Herk_ReferenzNr  = bE_BelegPos-Origin.ReferenzNr
              and bER_BelegPos-Origin.Herk_PositionsNr = bE_BelegPos-Origin.PositionsNr
              and bER_BelegPos-Origin.Source_Obj       = bE_BelegPos-Origin.E_BelegPos_Obj
              and can-find(first ER_BelegKopf
                           where ER_BelegKopf.Firma       = bER_BelegPos-Origin.Firma
                             and ER_BelegKopf.BelegArt    = bER_BelegPos-Origin.BelegArt
                             and ER_BelegKopf.ReferenzNr  = bER_BelegPos-Origin.ReferenzNr
                             and ER_BelegKopf.BelegNummer > 0)              
            no-lock
            on error undo, throw:

            SBCDropShippingSvc:prpoInstance:fillDeliveryNoteInfo(bER_BelegPos-Origin.ER_BelegPos_Obj,
                                                                 ttV_BelegPos-P.V_BelegPos_Obj,
                                                                 input-output table bttER_DeliveryNoteInfo-P).

          end. /*  for each bER_BelegPos-Origin */

        end. /* for each bE_BelegPos-Origin */

    end. /* when 'R':U then */
  &ENDIF

  end case. /* case string(ttV_BelegPos-P.BelegArt) */

end procedure. /* fillDropShippingPositionInfo */


/* _UIB-CODE-BLOCK-END */
&ANALYZE-RESUME

&ENDIF


&IF DEFINED(EXCLUDE-fillDropShippingHeadInfo) = 0 &THEN

&ANALYZE-SUSPEND _UIB-CODE-BLOCK _PROCEDURE fillDropShippingHeadInfo Method-Library
procedure fillDropShippingHeadInfo :
/* Description ---------------------------------------------------------------*/
/*                                                                            */
/* Fills SBT_DropShipping temp-table and assigns it to Head table             */
/*                                                                            */
/* Notes ---------------------------------------------------------------------*/
/*                                                                            */
/* This procedure does only encapsulate code for better readability of        */
/* fillDataset procedure. It can only be used in the context of this DAO !    */
/* run super() must have been executed and a global ttV_BelegKopf-P  and      */
/* ttV_BelegPos-P must be available!                                          */
/*                                                                            */
/*----------------------------------------------------------------------------*/

define buffer bttSBT_DropShipping-P for temp-table ttSBT_DropShipping-P.

if ttV_BelegKopf-P.Herk_BelegArt = 'U':U then

  case string(ttV_BelegKopf-P.BelegArt):

    when 'L':U then

      SBCDropShippingSvc:prpoInstance:fillDropShippingHeadData(ttV_BelegKopf-P.Origin_Obj,
                                                               ttV_BelegKopf-P.V_BelegKopf_Obj,
                                                               input-output table bttSBT_DropShipping-P).
                                                                              
    when 'R':U then

      SBCDropShippingSvc:prpoInstance:fillDropShippingHeadInfoForInvoice(ttV_BelegKopf-P.Origin_Obj,
                                                                         input-output table bttSBT_DropShipping-P).

  end case.

end procedure. /* fillDropShippingHeadInfo */


/* _UIB-CODE-BLOCK-END */
&ANALYZE-RESUME

&ENDIF


&IF LOOKUP("Q_GELANG","{&PA-OPTIONEN}") > 0 &THEN

&IF DEFINED(EXCLUDE-FillEntryCertificate) = 0 &THEN

&ANALYZE-SUSPEND _UIB-CODE-BLOCK _PROCEDURE FillEntryCertificate Method-Library
procedure FillEntryCertificate :
/* Description ---------------------------------------------------------------*/
/*                                                                            */
/* Print Entry Certificate                                                    */
/*                                                                            */
/*----------------------------------------------------------------------------*/

define buffer bVUT_EntryCertificate     for            VUT_EntryCertificate.                             
define buffer bttVUT_EntryCertificate-P for temp-table ttVUT_EntryCertificate-P.


if not can-find(last bttVUT_EntryCertificate-P
                  where bttVUT_EntryCertificate-P.Company         = ttV_BelegKopf-P.Firma
                    and bttVUT_EntryCertificate-P.DocumentType    = ttV_BelegKopf-P.BelegArt
                    and bttVUT_EntryCertificate-P.ReferenceNumber = ttV_BelegKopf-P.ReferenzNr) then
do:

  find last bVUT_EntryCertificate
    where bVUT_EntryCertificate.Company         = ttV_BelegKopf-P.Firma
      and bVUT_EntryCertificate.DocumentType    = ttV_BelegKopf-P.BelegArt
      and bVUT_EntryCertificate.ReferenceNumber = ttV_BelegKopf-P.ReferenzNr
    no-lock no-error.

  if available bVUT_EntryCertificate then
  do:

    create bttVUT_EntryCertificate-P.

    {buffer-copy
       bVUT_EntryCertificate
       to bttVUT_EntryCertificate-P
       assign
         "bttVUT_EntryCertificate-P.Company = gcFirma"}

  end. /* if available bVUT_EntryCertificate */

end. /* if not can-find(last bttVUT_EntryCertificate-P */

end procedure. /* FillEntryCertificate */


/* _UIB-CODE-BLOCK-END */
&ANALYZE-RESUME

&ENDIF /* Q_GELANG */

&ENDIF


&IF DEFINED(EXCLUDE-HungarianLocalizationData) = 0 &THEN

&ANALYZE-SUSPEND _UIB-CODE-BLOCK _PROCEDURE HungarianLocalizationData Method-Library
procedure HungarianLocalizationData :
/* Description ---------------------------------------------------------------*/
/*                                                                            */
/* fill data for Hungary                                                      */
/*                                                                            */
/*----------------------------------------------------------------------------*/
define variable cH_NoOfExemplar      as character                       no-undo.
define variable cH_OrgOrNoOfCopies   as character                       no-undo.
define variable cH_OriginalOrCopy_1  as character                       no-undo.
define variable cH_OriginalOrCopy_2  as character                       no-undo.
define variable cH_OriginalOrCopy_3  as character                       no-undo.

  /* H_NoOfExemplar */
  cH_NoOfExemplar = adm.config.cls.DCCAppConfigSvc:prpoInstance:cParamValByRefParamValLng
                      ('VF_H_OrgOrNoOfCopies_desc':U,
                       '3':U,
                       gcContentLanguage).

  cH_NoOfExemplar = substitute(cH_NoOfExemplar, '':U).
  cH_NoOfExemplar = trim(cH_NoOfExemplar).                     

  find {&pa_DR_DataProviderVariablesTT}
    where {&pa_DR_DataProviderVariablesTT}.VariableName = 'H_NoOfExemplar':U
    no-error.

  if available {&pa_DR_DataProviderVariablesTT} then
    {&pa_DR_DataProviderVariablesTT}.CharacterValue = cH_NoOfExemplar. 


  /* H_OrgOrNoOfCopies */
  if ttV_BelegKopf-P.gedruckt = no then
    cH_OrgOrNoOfCopies = adm.config.cls.DCCAppConfigSvc:prpoInstance:cParamValByRefParamValLng
                           ('VF_H_OrgOrNoOfCopies_desc':U,
                            '1':U,
                            gcContentLanguage).
  else
  do:
    cH_OrgOrNoOfCopies = adm.config.cls.DCCAppConfigSvc:prpoInstance:cParamValByRefParamValLng
                           ('VF_H_OrgOrNoOfCopies_desc':U,
                            '2':U,
                            gcContentLanguage).
    cH_OrgOrNoOfCopies = substitute(cH_OrgOrNoOfCopies, ttV_BelegKopf-P.H_NoOfOutputs + 1).                        

  end. /* else ttV_BelegKopf-P.gedruckt = no */

  find {&pa_DR_DataProviderVariablesTT}
    where {&pa_DR_DataProviderVariablesTT}.VariableName = 'H_OrgOrNoOfCopies':U
    no-error.

  if available {&pa_DR_DataProviderVariablesTT} then
    {&pa_DR_DataProviderVariablesTT}.CharacterValue = cH_OrgOrNoOfCopies. 

  /* H_TotalNoOfCopies */
  find {&pa_DR_DataProviderVariablesTT}
    where {&pa_DR_DataProviderVariablesTT}.VariableName = 'H_TotalNoOfCopies':U
    no-error.

  if available {&pa_DR_DataProviderVariablesTT} then
    {&pa_DR_DataProviderVariablesTT}.IntegerValue = giH_TotalNoOfCopies. 


  /* H_OriginalOrCopy */
  assign
    /* Original */
    cH_OriginalOrCopy_1 = adm.config.cls.DCCAppConfigSvc:prpoInstance:cParamValByRefParamValLng
                            ('VF_H_OriginalOrCopy_desc':U,
                             '1':U,
                             gcContentLanguage) 
    /* Kopie */
    cH_OriginalOrCopy_2 = adm.config.cls.DCCAppConfigSvc:prpoInstance:cParamValByRefParamValLng
                            ('VF_H_OriginalOrCopy_desc':U,
                             '2':U,
                             gcContentLanguage) 
    /* Rechnungskopie */
    cH_OriginalOrCopy_3 = adm.config.cls.DCCAppConfigSvc:prpoInstance:cParamValByRefParamValLng
                            ('VF_H_OriginalOrCopy_desc':U,
                             '3':U,
                             gcContentLanguage) 
    .
    
  find {&pa_DR_DataProviderVariablesTT}
    where {&pa_DR_DataProviderVariablesTT}.VariableName = 'H_OriginalOrCopy_1':U
    no-error.

  if available {&pa_DR_DataProviderVariablesTT} then
    {&pa_DR_DataProviderVariablesTT}.CharacterValue = cH_OriginalOrCopy_1. 

  find {&pa_DR_DataProviderVariablesTT}
    where {&pa_DR_DataProviderVariablesTT}.VariableName = 'H_OriginalOrCopy_2':U
    no-error.

  if available {&pa_DR_DataProviderVariablesTT} then
    {&pa_DR_DataProviderVariablesTT}.CharacterValue = cH_OriginalOrCopy_2. 

  find {&pa_DR_DataProviderVariablesTT}
    where {&pa_DR_DataProviderVariablesTT}.VariableName = 'H_OriginalOrCopy_3':U
    no-error.

  if available {&pa_DR_DataProviderVariablesTT} then
    {&pa_DR_DataProviderVariablesTT}.CharacterValue = cH_OriginalOrCopy_3. 

end procedure. /* HungarianLocalizationData */


/* _UIB-CODE-BLOCK-END */
&ANALYZE-RESUME

&ENDIF


&IF DEFINED(EXCLUDE-ItalianLocalizationData) = 0 &THEN

&ANALYZE-SUSPEND _UIB-CODE-BLOCK _PROCEDURE ItalianLocalizationData Method-Library
procedure ItalianLocalizationData :
/* Description ---------------------------------------------------------------*/
/*                                                                            */
/* fill data for Italy                                                        */
/*                                                                            */
/*----------------------------------------------------------------------------*/
define buffer bS_I_TaxExemption  for S_I_TaxExemption.
define buffer bIS_Adresse-Carr   for S_Adresse.
define buffer bIS_Lieferant-Carr for S_Lieferant.

  if ttV_BelegKopf-P.S_I_TaxExemption_Obj  > '':U then
  do:

    find bS_I_TaxExemption
      where bS_I_TaxExemption.S_I_TaxExemption_Obj = ttV_BelegKopf-P.S_I_TaxExemption_Obj
      no-lock.

    create ttS_I_TaxExemption-P.

    {buffer-copy
       bS_I_TaxExemption
       to ttS_I_TaxExemption-P}

  end. /* if ttV_BelegKopf-P.S_I_TaxExemption_Obj  > '':U then  */

  if ttV_BelegKopf-P.I_Carrier <= 0 then
    return.

  find bIS_Lieferant-Carr
    where bIS_Lieferant-Carr.Firma     = {firma/sliefera.fir ttV_BelegKopf-P.Firma}
      and bIS_Lieferant-Carr.Lieferant = ttV_BelegKopf-P.I_Carrier
    no-lock no-error.

  if available bIS_Lieferant-Carr then
  do:

    create ttS_Lieferant-PCarr.

    {buffer-copy
       bIS_Lieferant-Carr
       to ttS_Lieferant-PCarr
       assign
         "ttS_Lieferant-PCarr.Firma = gcFirma"}

    ttS_Lieferant-PCarr.inlaendische_SteuerNr = string(ttS_Lieferant-PCarr.inlaendische_SteuerNr, 
                                                       SBCTaxMasterFilesSvc:prpoInstance:cFormatDomesticTaxIDForAcc(ttS_Lieferant-PCarr.Lieferant)).
    validate ttS_Lieferant-PCarr.

    find bIS_Adresse-Carr
      where bIS_Adresse-Carr.Firma    = {firma/s_adres.fir bIS_Lieferant-Carr.Firma}
        and bIS_Adresse-Carr.AdressNr = bIS_Lieferant-Carr.AdressNr
      no-lock no-error.

    if available bIS_Adresse-Carr then
    do:

      create ttS_Adresse-PCarr.

      {buffer-copy
         bIS_Adresse-Carr
         to ttS_Adresse-PCarr
         assign
           "ttS_Adresse-PCarr.Firma = gcFirma"}

    end. /* if available bIS_Adresse-Carr then */

  end. /* if available bIS_Lieferant-Carr then */

end procedure. /* ItalianLocalizationData */


/* _UIB-CODE-BLOCK-END */
&ANALYZE-RESUME

&ENDIF


&IF DEFINED(EXCLUDE-PolishLocalizationData) = 0 &THEN

&ANALYZE-SUSPEND _UIB-CODE-BLOCK _PROCEDURE PolishLocalizationData Method-Library
procedure PolishLocalizationData :
/* Description ---------------------------------------------------------------*/
/*                                                                            */
/* fill data for Poland                                                       */
/*                                                                            */
/*----------------------------------------------------------------------------*/
define variable lPOrgPositions       as logical   initial no            no-undo.
define variable cTemp                as character                       no-undo.
define variable cOIDHead             as character                       no-undo.
define variable cOIDPos              as character                       no-undo. 
define variable cOriginInvoice       as character                       no-undo.

define buffer bPV_Belegkopf          for V_BelegKopf.
define buffer bPV_BelegPos           for V_BelegPos.
define buffer bPS_ZahlZielSpr        for S_ZahlZielSpr.
define buffer bPS_VersandArtSpr      for S_VersandArtSpr.
define buffer bPS_WaehrungSpr        for S_WaehrungSpr.
define buffer bPMLM_StorPartData     for MLM_StorPartData.
define buffer bS_Staat               for S_Staat.
define buffer bS_MengenEinheitSpr    for S_MengenEinheitSpr.
define buffer bPS_MengenEinheitSpr   for S_MengenEinheitSpr.
define buffer bPS_LieferbedSpr       for S_LieferbedSpr.
define buffer bPS_Artikel            for S_Artikel.
define buffer bPS_ArtVar             for S_ArtVar.
define buffer bPS_ArtVarSpr          for S_ArtVarSpr.
define buffer bPS_ArtVarTypSpr       for S_ArtVarTypSpr.
define buffer bPS_ArtikelSpr         for S_ArtikelSpr.
define buffer bPS_ArtKunde           for S_ArtKunde.
define buffer bPSBM_CustomsTariffNo  for SBM_CustomsTariffNo.
define buffer bPS_PreiseinheitSpr    for S_PreisEinheitSpr.
define buffer bS_RabZuArtSpr         for S_RabZuArtSpr.
define buffer bttV_BelegKopf-PP      for temp-table ttV_BelegKopf-PP.
define buffer bttV_BelegPos-PP       for temp-table ttV_BelegPos-PP.
define buffer bttMLM_StorPartData-PP for temp-table ttMLM_StorPartData-PP.
define buffer bttS_ArtKunde-PP       for temp-table ttS_ArtKunde-PP.
define buffer bttS_Artikel-PP        for temp-table ttS_Artikel-PP.

  /* in case of correction */
  if VBCPolandHungarySpecialsSvc:prpoInstance:lIsAPolishCorrectingInvoice
                                                (ttV_BelegKopf-P.BelegArt,
                                                 ttV_BelegKopf-P.ReferenzNr) then
  do:

    /* original invoice */
    run vert/proc/v_vbelp0.p (gcFirma,
                              ttV_BelegKopf-P.Belegart,
                              ttV_BelegKopf-P.ReferenzNr,
                              'Original':U,
                              output Table ttPV_K_BelegSumKopf-Org by-reference,
                              output Table ttPV_K_BelegSumPos-Org by-reference).

    find first ttPV_K_BelegSumKopf-Org
      no-lock.

    /* corrected invoice */
    run vert/proc/v_vbelp0.p (gcFirma,
                              ttV_BelegKopf-P.Belegart,
                              ttV_BelegKopf-P.ReferenzNr,
                              'Corrected':U,
                              output Table ttPV_K_BelegSumKopf-Cor by-reference,
                              output Table ttPV_K_BelegSumPos-Cor by-reference).

    find first ttPV_K_BelegSumKopf-Cor
      no-lock.

  end. /* corrected invoice */

  if    ttV_BelegKopf-P.Belegart        = VBCSalesDocumentTypeSvc:Invoice
    and ttV_BelegKopf-P.Schlussrechnung = yes then
    lPOrgPositions = yes.

  if lPOrgPositions = no then
    for each bPV_BelegPos
      where bPV_BelegPos.Firma      = ttV_BelegKopf-P.Firma
        and bPV_BelegPos.Belegart   = ttV_BelegKopf-P.Belegart
        and bPV_BelegPos.ReferenzNr = ttV_BelegKopf-P.ReferenzNr
      no-lock:

      if can-find (bPS_Artikel
                   where bPS_Artikel.Firma      = {firma/sartikel.fir gcFirma}
                     and bPS_Artikel.Artikel    = bPV_BelegPos.Artikel
                     and bPS_Artikel.ArtikelArt = {&pa_S_PT_PartPayAndMarkdowns}) then
      do:

        lPOrgPositions = yes.
        leave.

      end.

  end. /* for each bPV_BelegPos */

  if lPOrgPositions = yes then
  do:

    find bPV_BelegKopf
      where bPV_BelegKopf.V_BelegKopf_Obj = ttV_BelegKopf-P.Origin_Obj
        and bPV_BelegKopf.Belegart        = 'U':U
      no-lock no-error.

    if not available bPV_BelegKopf then
      find bPV_BelegKopf
        where bPV_BelegKopf.V_BelegKopf_Obj = ttV_BelegKopf-P.Origin_Obj
          and bPV_BelegKopf.Belegart        = 'VUA':U
        no-lock no-error. 

    if available bPV_BelegKopf then
    do:
      find gbPV_BelegKopf-Org
        where rowid(gbPV_BelegKopf-Org) = rowid(bPV_BelegKopf)
        no-lock. 

      vert.base.cls.VBCSalesDocSvc:prpoInstance:CalcDocumentTotal
                                     (bPV_BelegKopf.V_BelegKopf_Obj,
                                      no,    
                                      output Table ttPV_BelegSumKopf-Org by-reference,
                                      output Table ttPV_BelegSumPos-Org  by-reference).
      find ttPV_BelegSumKopf-Org.

      {adm/incl/d__spr00.if
        &Tabelle = "bPS_WaehrungSpr"
        &Selekt  = "where bPS_WaehrungSpr.Firma    = {firma/swaehrun.fir gcFirma}
                      and bPS_WaehrungSpr.Waehrung = bPV_BelegKopf.Waehrung"
        &Sprache = "gcContentLanguage"
      }

      {adm/incl/d__spr00.if
        &Tabelle = "bPS_ZahlZielSpr"
        &Selekt  = "where bPS_ZahlZielSpr.Firma        = {firma/szahlzie.fir gcFirma}
                      and bPS_ZahlZielSpr.ZahlungsZiel =  bPV_BelegKopf.Zahlungsziel"
        &Sprache = "gcContentLanguage"
        &no-error = "no-error"
      }

      {adm/incl/d__spr00.if
        &Tabelle = "bPS_VersandArtSpr"
        &Selekt  = "where bPS_VersandArtSpr.Firma      = {firma/sversart.fir gcFirma}
                      and bPS_VersandArtSpr.VersandArt = bPV_BelegKopf.VersandArt"
        &Sprache = "gcContentLanguage"
        &no-error = "no-error"
      }

      {adm/incl/d__spr00.if
        &Tabelle  = "bPS_LieferbedSpr"
        &Selekt   = "where bPS_LieferbedSpr.Firma           = {firma/srabzuar.fir gcFirma}
                       and bPS_LieferbedSpr.Lieferbedingung = bPV_BelegKopf.Lieferbedingung"
        &Sprache  = "gcContentLanguage"
        &no-error = "no-error"
      }

      create bttV_BelegKopf-PP.
      {buffer-copy
         bPV_BelegKopf
         to bttV_BelegKopf-PP
         assign
           "bttV_BelegKopf-PP.Firma = gcFirma
            bttV_BelegKopf-PP.P_KurzBez      = bPS_WaehrungSpr.KurzBez
            bttV_BelegKopf-PP.P_ZBezeichnung = bPS_ZahlZielSpr.Bezeichnung   when available bPS_ZahlZielSpr
            bttV_BelegKopf-PP.P_VBezeichnung = bPS_VersandArtSpr.Bezeichnung when available bPS_VersandArtSpr
            bttV_BelegKopf-PP.P_LBezeichnung = bPS_LieferbedSpr.Bezeichnung  when available bPS_LieferbedSpr
            bttV_BelegKopf-PP.Empfaenger     = VBCContactPersonSvc:prpoInstance:cGetContactPersonName
                                                 (bPV_BelegKopf.V_BelegKopf_Obj,
                                                  integer(SBCContactTypeEnu:Customer))"}

      for each bPV_BelegPos
        where bPV_BelegPos.Firma      = {firma/vbelegko.fir gcFirma}
          and bPV_BelegPos.BelegArt   = bPV_BelegKopf.BelegArt
          and bPV_BelegPos.ReferenzNr = bPV_BelegKopf.ReferenzNr
          and bPV_BelegPos.Satzart    = 'A':U
        no-lock:

        {adm/incl/d__spr00.if
          &Tabelle  = "bPS_PreiseinheitSpr"
          &Selekt   = "where bPS_PreiseinheitSpr.Firma        = {firma/spreeinh.fir gcFirma}
                         and bPS_PreiseinheitSpr.Preiseinheit = bPV_Belegpos.Preiseinheit"
          &Sprache  = "gcContentLanguage"
        }

        {adm/incl/d__spr00.if
          &Tabelle  = "bPS_LieferbedSpr"
          &Selekt   = "where bPS_LieferbedSpr.Firma           = {firma/srabzuar.fir gcFirma}
                         and bPS_LieferbedSpr.Lieferbedingung = bPV_Belegpos.Lieferbedingung"
          &Sprache  = "gcContentLanguage"
        }

        {adm/incl/d__spr00.if
          &Tabelle  = "bPS_MengenEinheitSpr"
          &Selekt   = "where bPS_MengenEinheitSpr.Firma         = {firma/smngeinh.fir gcFirma}
                         and bPS_MengenEinheitSpr.Mengeneinheit = bPV_Belegpos.Mengeneinheit"
          &Sprache  = "gcContentLanguage"
          &no-error = "no-error"
        }

        create bttV_BelegPos-PP.
        {buffer-copy
           bPV_BelegPos
           to bttV_BelegPos-PP
           assign
             "bttV_BelegPos-PP.Firma = gcFirma
              bttV_BelegPos-PP.P_PKurzBez = bPS_PreiseinheitSpr.KurzBez
              bttV_BelegPos-PP.P_LBezeichnung = bPS_LieferbedSpr.Bezeichnung
              bttV_BelegPos-PP.P_MKurzBez = bPS_MengenEinheitSpr.KurzBez when available bPS_MengenEinheitSpr"}

        if bPV_BelegPos.VME_Faktor     <> 1
          and bPV_BelegPos.Einzelpreis <> 0 then
          assign
            bttV_BelegPos-PP.P_Einzelpreis_VME     = bPV_BelegPos.Einzelpreis
                                                    / bPV_BelegPos.Preisfaktor
                                                   * bPV_BelegPos.VME_Faktor
            bttV_BelegPos-PP.P_Eur_Einzelpreis_VME = bPV_BelegPos.Einzelpreis
                                                    / bPV_BelegPos.Preisfaktor
                                                    * bPV_BelegPos.VME_Faktor
                                                    / ttS_Waehrung-P1.Eurofaktor

            .

        if bPV_BelegPos.VME_Faktor   <> 1
          and bPV_BelegPos.Wert_RZ_1 <> 0 then

          bttV_BelegPos-PP.P_Fracht_VME = bPV_BelegPos.Wert_RZ_1
                                          / bPV_BelegPos.Preisfaktor
                                          * bPV_BelegPos.VME_Faktor.  

        assign
          bttV_BelegPos-PP.P_Eur_Einzelpreis = bPV_BelegPos.Einzelpreis
                                               / ttS_Waehrung-P1.Eurofaktor
          bttV_BelegPos-PP.P_Verkaufspreis   = bPV_BelegPos.Einzelpreis
                                               + bPV_BelegPos.Wert_RZ_1
                                               + bPV_BelegPos.Wert_RZ_2
          bttV_BelegPos-PP.P_Eur_Verkaufspreis = (bPV_BelegPos.Einzelpreis
                                                 + bPV_BelegPos.Wert_RZ_1
                                                 + bPV_BelegPos.Wert_RZ_2)
                                                 / ttS_Waehrung-P1.Eurofaktor
          bttV_BelegPos-PP.P_Eur_Wert_RZ_1     = bPV_BelegPos.Wert_RZ_1
                                                 / ttS_Waehrung-P1.Eurofaktor                            
          bttV_BelegPos-PP.P_Eur_Wert_RZ_2     = bPV_BelegPos.Wert_RZ_2
                                                 / ttS_Waehrung-P1.Eurofaktor                            
          .          

        if bttV_BelegPos-PP.offen
          and glPositions  then

          assign
            bttV_BelegPos-PP.Gesamtpreis = bttV_BelegPos-PP.Gesamtpreis_offen
            .

        assign
          bttV_BelegPos-PP.P_Eur_Gesamtpreis = bttV_BelegPos-PP.Gesamtpreis 
                                               / ttS_Waehrung-P1.Eurofaktor
          .

        if     bPV_BelegPos.VME_Faktor  <> 1
           and (bPV_BelegPos.Einzelpreis
                + bPV_BelegPos.Wert_RZ_1
                + bPV_BelegPos.Wert_RZ_2 <> 0) then
          assign
            bttV_BelegPos-PP.P_Eur_Verkaufspreis_VME = (bPV_BelegPos.Einzelpreis
                                                       + bPV_BelegPos.Wert_RZ_1
                                                       + bPV_BelegPos.Wert_RZ_2)
                                                      / bPV_BelegPos.Preisfaktor
                                                      * bPV_BelegPos.VME_Faktor
                                                      / ttS_Waehrung-P1.Eurofaktor
            bttV_BelegPos-PP.P_Verkaufspreis_VME     = (bPV_BelegPos.Einzelpreis
                                                       + bPV_BelegPos.Wert_RZ_1
                                                       + bPV_BelegPos.Wert_RZ_2)
                                                      / bPV_BelegPos.Preisfaktor
                                                      * bPV_BelegPos.VME_Faktor
            .


        assign
          bttV_BelegPos-PP.Auftragsmenge_LME    = bPV_BelegPos.Menge
          bttV_BelegPos-PP.gelieferteMenge_LME  = bttV_BelegPos-PP.gelieferte_Menge
          bttV_BelegPos-PP.offeneMenge_LME      = bttV_BelegPos-PP.Menge
                                                  - bttV_BelegPos-PP.gelieferte_Menge
                                                  - bttV_BelegPos-PP.stornierte_Menge
          bttV_BelegPos-PP.stornierteMenge_LME  = bPV_BelegPos.stornierte_Menge
        .

        assign
          bttV_BelegPos-PP.Auftragsmenge_VME = bttV_BelegPos-PP.Auftragsmenge_LME
                                                / bttV_BelegPos-PP.VME_Faktor
          bttV_BelegPos-PP.gelieferteMenge_VME  = bttV_BelegPos-PP.gelieferteMenge_LME
                                                / bttV_BelegPos-PP.VME_Faktor
          bttV_BelegPos-PP.offeneMenge_VME      = bttV_BelegPos-PP.offeneMenge_LME
                                                / bttV_BelegPos-PP.VME_Faktor
          bttV_BelegPos-PP.stornierteMenge_VME  = bttV_BelegPos-PP.stornierteMenge_LME
                                                / bttV_BelegPos-PP.VME_Faktor
          bttV_BelegPos-PP.P_Menge_komplett = if     bPV_BelegPos.offen = yes
                                                and glPositions = yes then
                                                (bPV_BelegPos.Menge
                                                 - bPV_BelegPos.stornierte_Menge
                                                 - bPV_BelegPos.gelieferte_Menge)
                                                / bPV_BelegPos.VME_Faktor
                                              else
                                                (bPV_BelegPos.Menge
                                                 - bPV_BelegPos.stornierte_Menge)
                                                / bPV_BelegPos.VME_Faktor
        .

        if bttV_BelegPos-PP.LieferTermin <> ? then

          assign
            cTemp                   = {fnarg
                                         pa_cDateWeekOfDate
                                         "bttV_BelegPos-PP.Liefertermin"}
            bttV_BelegPos-PP.LT_KW   = substring(cTemp,5,2) + '/':U + substring(cTemp,3,2)
            bttV_BelegPos-PP.LT_KW_4 = substring(cTemp,5,2) + '/':U + substring(cTemp,1,4)
            .

        bttV_BelegPos-PP.Menge_LME = (if bttV_BelegPos-PP.offen
                                        and glPositions then
                                        (bttV_BelegPos-PP.Menge
                                         - bttV_BelegPos-PP.stornierte_Menge
                                         - bttV_BelegPos-PP.gelieferte_Menge)
                                      else
                                        (bttV_BelegPos-PP.Menge
                                         - bttV_BelegPos-PP.stornierte_Menge)).

        if bPV_Belegpos.Wert_RZ_1 <> 0 then
        do:

         {adm/incl/d__spr00.if
           &Tabelle  = "bS_RabZuArtSpr"
           &Selekt   = "where bS_RabZuArtSpr.Firma  = {firma/srabzuar.fir gcFirma}
                          and bS_RabZuArtSpr.RZ_Art = bPV_BelegPos.Wert_RZ_Art_1"
           &Sprache  = "gcContentLanguage"
           &no-error = "no-error"
         }

          if available bS_RabZuArtSpr then
            bttV_BelegPos-PP.P_wert_RZ_Bez_1 = bS_RabZuArtSpr.Bezeichnung.

        end.

        if bPV_Belegpos.Wert_RZ_2 <> 0 then
        do:

          {adm/incl/d__spr00.if
            &Tabelle  = "bS_RabZuArtSpr"
            &Selekt   = "where bS_RabZuArtSpr.Firma  = {firma/srabzuar.fir gcFirma}
                           and bS_RabZuArtSpr.RZ_Art = bPV_BelegPos.Wert_RZ_Art_2"
            &Sprache  = "gcContentLanguage"
            &no-error = "no-error"
          }

           if available bS_RabZuArtSpr then
             bttV_BelegPos-PP.P_wert_RZ_Bez_2 = bS_RabZuArtSpr.Bezeichnung.

        end.

        if bPV_Belegpos.Proz_RZ_1 <> 0 then
        do:

          {adm/incl/d__spr00.if
            &Tabelle  = "bS_RabZuArtSpr"
            &Selekt   = "where bS_RabZuArtSpr.Firma  = {firma/srabzuar.fir gcFirma}
                           and bS_RabZuArtSpr.RZ_Art = bPV_Belegpos.Proz_RZ_Art_1"
            &Sprache  = "gcContentLanguage"
            &no-error = "no-error"
          }

           if available bS_RabZuArtSpr then
             bttV_BelegPos-PP.P_Proz_RZ_Bez_1 = bS_RabZuArtSpr.Bezeichnung.

        end.

        if bPV_Belegpos.Proz_RZ_2 <> 0 then
        do:

          {adm/incl/d__spr00.if
            &Tabelle  = "bS_RabZuArtSpr"
            &Selekt   = "where bS_RabZuArtSpr.Firma  = {firma/srabzuar.fir gcFirma}
                           and bS_RabZuArtSpr.RZ_Art = bPV_Belegpos.Proz_RZ_Art_2"
            &Sprache  = "gcContentLanguage"
            &no-error = "no-error"
          }

           if available bS_RabZuArtSpr then
             bttV_BelegPos-PP.P_Proz_RZ_Bez_2 = bS_RabZuArtSpr.Bezeichnung.

        end.

        if bPV_Belegpos.Proz_RZ_3 <> 0 then
        do:

          {adm/incl/d__spr00.if
            &Tabelle  = "bS_RabZuArtSpr"
            &Selekt   = "where bS_RabZuArtSpr.Firma  = {firma/srabzuar.fir gcFirma}
                           and bS_RabZuArtSpr.RZ_Art = bPV_Belegpos.Proz_RZ_Art_3"
            &Sprache  = "gcContentLanguage"
            &no-error = "no-error"
          }

           if available bS_RabZuArtSpr then
             bttV_BelegPos-PP.P_Proz_RZ_Bez_3 = bS_RabZuArtSpr.Bezeichnung.

        end.

        vert.base.cls.VBCSalesDocSvc:prpoInstance:cGetOIDOriginOrderOrQuote(bttV_BelegPos-PP.V_BelegPos_Obj,output cOIDHead,output cOIDPos).

        bttV_BelegPos-PP.ClassificationOwnerPV_Obj  = cOIDPos.

        if not can-find (bttMLM_StorPartData-PP
                           where bttMLM_StorPartData-PP.Company     = gcFirma
                             and bttMLM_StorPartData-PP.Part        = bPV_BelegPos.Artikel
                             and bttMLM_StorPartData-PP.ArtVar      = bPV_BelegPos.ArtVar
                             and bttMLM_StorPartData-PP.Storagearea = bPV_BelegPos.LagerOrt) then
        do:

          find bPMLM_StorPartData
            where bPMLM_StorPartData.Company     = bPV_BelegPos.Firma
              and bPMLM_StorPartData.Part        = bPV_BelegPos.Artikel
              and bPMLM_StorPartData.ArtVar      = bPV_BelegPos.ArtVar
              and bPMLM_StorPartData.Storagearea = bPV_BelegPos.LagerOrt
            no-lock no-error.

          if available bPMLM_StorPartData then
          do:

            create bttMLM_StorPartData-PP.
            {buffer-copy
               bPMLM_StorPartData
               to bttMLM_StorPartData-PP
               assign
                 "bttMLM_StorPartData-PP.Company = gcFirma"}

          end. /* if available bMLM_StorPartData then */

        end. /* if not can-find (bPMLM_StorPartData */

        if not can-find(bttS_ArtKunde-PP
                          where bttS_ArtKunde-PP.Firma   = gcFirma
                            and bttS_ArtKunde-PP.Kunde   = bPV_BelegKopf.Kunde
                            and bttS_ArtKunde-PP.Artikel = bPV_BelegPos.Artikel) then
        do:

          find bPS_ArtKunde
            where bPS_ArtKunde.Firma   = {firma/sartkund.fir gcFirma}
              and bPS_ArtKunde.Kunde   = bPV_BelegKopf.Kunde
              and bPS_ArtKunde.Artikel = bPV_BelegPos.Artikel
            no-lock no-error.

          if available bPS_ArtKunde then
          do:
            create bttS_ArtKunde-PP.
            {buffer-copy
               bPS_ArtKunde
               to bttS_ArtKunde-PP
               assign
                 "bttS_ArtKunde-PP.Firma = gcFirma"}
          end. /* available bPS_ArtKunde */

        end. /* if not can-find(bttS_ArtKunde-PP */

        find bPS_Artikel
          where bPS_Artikel.Firma   = {firma/sartikel.fir gcFirma}
            and bPS_Artikel.Artikel = bPV_BelegPos.Artikel
          no-lock no-error.

        if available bPS_Artikel then
        do:

          {adm/incl/d__spr00.if
            &Tabelle  = "bPS_ArtVarSpr"
            &Selekt   = "where bPS_ArtVarSpr.ArtVarTyp = bPS_Artikel.ArtVarTyp
                           and bPS_ArtVarSpr.ArtVar    = bPV_Belegpos.ArtVar"
            &Sprache  = "gcContentLanguage"
            &no-error = "no-error"
          }

          {adm/incl/d__spr00.if
            &Tabelle  = "bS_MengenEinheitSpr"
            &Selekt   = "where bS_MengenEinheitSpr.Firma         = {firma/smngeinh.fir bttV_BelegPos-PP.Firma}
                           and bS_MengenEinheitSpr.Mengeneinheit = (if bttV_BelegPos-PP.VME_Faktor <> 1 then
                                                                      bttV_BelegPos-PP.Mengeneinheit
                                                                    else
                                                                      bPS_Artikel.LagerME)"
            &Sprache  = "gcContentLanguage"
            &no-error = "no-error"
          }

          assign
            bttV_BelegPos-PP.P_ArtVarBez   = bPS_ArtVarSpr.Bezeichnung       when available bPS_ArtVarSpr
            bttV_BelegPos-PP.P_ArtVarKuz   = bPS_ArtVarSpr.KurzBez           when available bPS_ArtVarSpr
            bttV_BelegPos-PP.VerpackungsME = bS_MengenEinheitSpr.Bezeichnung when available bS_MengenEinheitSpr
            .

          if bPS_Artikel.Ursprungsland > '':U then
          do:

            find bS_Staat
              where bS_Staat.Staat =  bPS_Artikel.Ursprungsland
              no-lock no-error.

            if available bS_Staat then
              bttV_BelegPos-PP.P_IsoAlpha2Code = bS_Staat.IsoAlpha2Code.

          end. /* if bPS_Artikel.Ursprungsland > '':U then */

          if not can-find(ttSBM_CustomsTariffNo-PP
                            where ttSBM_CustomsTariffNo-PP.SBM_CustomsTariffNo_Obj = bPS_Artikel.SBM_CustomsTariffNo_Obj
                              and ttSBM_CustomsTariffNo-PP.Company                 = gcFirma) then
          do:

            find bPSBM_CustomsTariffNo
              where bPSBM_CustomsTariffNo.SBM_CustomsTariffNo_Obj = bPS_Artikel.SBM_CustomsTariffNo_Obj
              no-lock no-error.

            if available bPSBM_CustomsTariffNo then
            do:

              create ttSBM_CustomsTariffNo-PP.
              {buffer-copy
                 bPSBM_CustomsTariffNo
                 to ttSBM_CustomsTariffNo-PP
                 assign
                   "ttSBM_CustomsTariffNo-PP.Company = gcFirma"}

            end. /* if available bPSBM_CustomsTariffNo then */

          end. /* if not can-find(ttSBM_CustomsTariffNo-PP */

          if not can-find(bttS_Artikel-PP
                            where bttS_Artikel-PP.Firma   = gcFirma
                              and bttS_Artikel-PP.Artikel = bPS_Artikel.Artikel) then
          do:

            {adm/incl/d__spr00.if
              &Tabelle  = "bPS_ArtikelSpr"
              &Selekt   = "where bPS_ArtikelSpr.Firma   = {firma/sartikel.fir gcFirma}
                             and bPS_ArtikelSpr.Artikel = bPS_Artikel.Artikel"
              &Sprache  = "gcContentLanguage"
              &no-error = "no-error"
            }

            {adm/incl/d__spr00.if
              &Tabelle  = "bPS_ArtVarTypSpr"
              &Selekt   = "where bPS_ArtVarTypSpr.ArtVarTyp = bPS_Artikel.ArtVarTyp"
              &Sprache  = "gcContentLanguage"
              &no-error = "no-error"
            }

            {adm/incl/d__spr00.if
              &Tabelle  = "bS_MengenEinheitSpr"
              &Selekt   = "where bS_MengenEinheitSpr.Firma         = {firma/smngeinh.fir gcFirma}
                             and bS_MengenEinheitSpr.Mengeneinheit = bPS_Artikel.LagerME"
              &Sprache  = "gcContentLanguage"
              &no-error = "no-error"
            }

            create bttS_Artikel-PP.
            {buffer-copy
               bPS_Artikel
               to bttS_Artikel-PP
               assign
                 "bttS_Artikel-PP.Firma          = gcFirma
                  bttS_Artikel-PP.P_ArtBez       = bPS_ArtikelSpr.Bezeichnung      when available bPS_ArtikelSpr
                  bttS_Artikel-PP.P_ArtVarTypBez = bPS_ArtVarTypSpr.Bezeichnung    when available bPS_ArtVarTypSpr
                  bttS_Artikel-PP.P_LagerME      = bS_MengenEinheitSpr.Bezeichnung when available bS_MengenEinheitSpr"}

            if available bPS_ArtikelSpr then
              assign
                bttS_Artikel-PP.P_ArtBez12 = bPS_ArtikelSpr.Bezeichnung[1]
                                             + bPS_ArtikelSpr.Bezeichnung[2]
                bttS_Artikel-PP.P_ArtBez34 = bPS_ArtikelSpr.Bezeichnung[3]
                                             + bPS_ArtikelSpr.Bezeichnung[4]
                .

            {adm/incl/d__spr00.if
              &Tabelle  = "bPS_ArtikelSpr"
              &Selekt   = "where bPS_ArtikelSpr.Firma   = {firma/sartikel.fir gcFirma}
                             and bPS_ArtikelSpr.Artikel = bPS_Artikel.Artikel"
              &Sprache  = "{&pa_Defaultsprache}"
              &no-error = "no-error"
            }

            assign
              bttS_Artikel-PP.P_ArtBezDefLng = bPS_ArtikelSpr.Bezeichnung when available bPS_ArtikelSpr
              .

          end. /* if not can-find(bttS_Artikel-PP */

        end. /* if available bPS_Artikel then */

      end. /* for each bPV_BelegPos */

      find ttV_BelegKopf-PP.

      run P_fillOrgDocTaxrateSumsForLLPrint in target-procedure.

      run P_fillOrgDocTotalSumForLLPrint in target-procedure.

    end. /* if available bPV_BelegKopf then */

  end. /* if lPOrgPositions = yes then */

  assign
    ttV_BelegKopf-P.P_OriginInvoice = integer(SBCLocalizationPLSvc:prpoInstance:cPPrevInvoiceNumbers(cOriginInvoice, gbV_BelegKopf.V_BelegKopf_Obj, no, yes))
    ttV_BelegKopf-P.P_InvoiceChain  = SBCLocalizationPLSvc:prpoInstance:cPPrevInvoiceNumbers(ttV_BelegKopf-P.P_InvoiceChain, gbV_BelegKopf.V_BelegKopf_Obj, yes, yes)
    .

  if ttV_BelegKopf-P.P_RechnungsTyp > 0 then
  do:
    find bPV_BelegKopf  
      where bPV_BelegKopf.Firma      = ttV_BelegKopf-P.Firma
        and bPV_BelegKopf.Belegart   = ttV_BelegKopf-P.BelegArt
        and bPV_BelegKopf.ReferenzNr = (if ttV_BelegKopf-P.P_RechnungsTyp = VBCPolandHungarySpecialsSvc:CancellingInvoice then
                                          ttV_BelegKopf-P.P_stornierteRechnung
                                        else
                                          ttV_BelegKopf-P.P_korrigierteRechnung)
      no-lock no-error.

    if available bPV_BelegKopf then
      assign
        ttV_BelegKopf-P.P_KR_BelegDatum  = bPV_BelegKopf.BelegDatum
        ttV_BelegKopf-P.P_KR_BelegNummer = bPV_BelegKopf.BelegNummer
        .      
  end.

  find {&pa_DR_DataProviderVariablesTT}
    where {&pa_DR_DataProviderVariablesTT}.VariableName = 'P_CopyDate':U
    no-error.

  if available {&pa_DR_DataProviderVariablesTT} then
    {&pa_DR_DataProviderVariablesTT}.DateValue = gtPCopyDate. 

end procedure. /* PolishLocalizationData */


/* _UIB-CODE-BLOCK-END */
&ANALYZE-RESUME

&ENDIF


&IF DEFINED(EXCLUDE-uFillCreditInformation) = 0 &THEN

&ANALYZE-SUSPEND _UIB-CODE-BLOCK _PROCEDURE uFillCreditInformation Method-Library
procedure uFillCreditInformation :
/* Description ---------------------------------------------------------------*/
/*                                                                            */
/* Print Gutschriftsinformationen                                             */
/*                                                                            */
/* Notes ---------------------------------------------------------------------*/
/*                                                                            */
/*                                                                            */
/* Parameters ----------------------------------------------------------------*/
/*                                                                            */
/* <none>                                                                     */
/*                                                                            */
/* Examples ------------------------------------------------------------------*/
/*                                                                            */
/*                                                                            */
/*                                                                            */
/*----------------------------------------------------------------------------*/

/* Variables -----------------------------------------------------------------*/

&IF lookup("U_CW":U,"{&PA-OPTIONEN}":U) > 0 &THEN
define variable cBonusRateType           as character                 no-undo.
define variable cBonusRateTypeSupplement as character init '%':U      no-undo.
define variable dNextGradeValue          as decimal                   no-undo.
define variable dGradeValue              as decimal                   no-undo.

/*----------------------------------------------------------------------------*/

/* Buffers -------------------------------------------------------------------*/

define buffer bUSM_BonusType              for USM_BonusType.
define buffer bUSM_BonusContractType      for USM_BonusContractType.
define buffer bUVT_BonusBilling           for UVT_BonusBilling.
define buffer bUSM_BonusGrade             for USM_BonusGrade.
define buffer bS_Kunde                    for S_Kunde.

define buffer bttUSM_BonusType-P2         for temp-table ttUSM_BonusType-P2.
define buffer bttUVT_BonusBilling-P1      for temp-table ttUVT_BonusBilling-P1.

/*----------------------------------------------------------------------------*/
/* Processing                                                                 */
/*----------------------------------------------------------------------------*/

if not can-find(bttUVT_BonusBilling-P1
                  where bttUVT_BonusBilling-P1.CreditNote_Obj = ttV_BelegPos-P.V_BelegPos_Obj) then
do:

  find bUVT_BonusBilling   /* code checked by Martin_L 02.03.2018 */
    where bUVT_BonusBilling.CreditNote_Obj = ttV_BelegPos-P.V_BelegPos_Obj
    no-lock no-error. 

  if available bUVT_BonusBilling then
  do:

    find bUSM_BonusContractType
      where bUSM_BonusContractType.Company               = bUVT_BonusBilling.Company
        and bUSM_BonusContractType.USM_BonusContract_Obj = bUVT_BonusBilling.USM_BonusContract_Obj
        and bUSM_BonusContractType.USM_BonusType_ID      = bUVT_BonusBilling.USM_BonusType_ID
        and bUSM_BonusContractType.Periodtype            = bUVT_BonusBilling.Periodtype
      no-lock no-error.

    create bttUVT_BonusBilling-P1.
    {buffer-copy
       bUVT_BonusBilling
       to bttUVT_BonusBilling-P1
       assign
         "bttUVT_BonusBilling-P1.uRecipient                   = (if available bUSM_BonusContractType then
                                                                   (if bUSM_BonusContractType.Bonusrecipient then
                                                                      'Gruppenabrechnung':U
                                                                    else
                                                                      'Einzelabrechnung':U)
                                                                 else
                                                                   '':U)"}

    find bUSM_BonusType
      where bUSM_BonusType.Company          = gcFirma
        and bUSM_BonusType.USM_BonusType_ID = bUVT_BonusBilling.USM_BonusType_ID
      no-lock no-error.

    if available bUSM_BonusType then 
    do:

      if not can-find(bttUSM_BonusType-P2
                        where bttUSM_BonusType-P2.Company          = gcFirma
                          and bttUSM_BonusType-P2.USM_BonusType_ID = bUVT_BonusBilling.USM_BonusType_ID)then
      do:

        create bttUSM_BonusType-P2.
        {buffer-copy
           bUSM_BonusType
           to bttUSM_BonusType-P2}  

      end. /* if not can-find(bttUSM_BonusType-P2 */  

      cBonusRateType = adm.config.cls.DCCAppConfigSvc:prpoInstance:cParamValByRefParamVal('US_BonusBase_desc':U,
                                                                                              bUSM_BonusType.BonusBase).
      if cBonusRateType = adm.base.cls.DBCTranslateSvc:prpoInstance:cTranslateGermanTerm('Festwert':U, 18) then
      do:

        find bUSM_BonusContractType
          where bUSM_BonusContractType.USM_BonusContractType_Obj = bUVT_BonusBilling.USM_BonusContractType_Obj
          no-lock no-error.

        if available bUSM_bonusContractType then
          cBonusRateTypeSupplement = {fnarg
                                       pa_cCurShortDescOfCurrency
                                       "gcFirma,
                                       bUSM_BonusContractType.Currency"}.

      end. /* if cBonusRateType = 'Festwert':L18 then */   

      find bS_Kunde
        where bS_Kunde.Firma = {firma/s_kunde.fir gcFirma}
          and bS_Kunde.Kunde = bUVT_BonusBilling.Customer
        no-lock.

      dGradeValue = branche.vert.cls.UVC_BonusSvc:prpoInstance:dGradeValue(bUSM_BonusType.GradeBase,
                                                                           bS_Kunde.S_Kunde_Obj,
                                                                           bUVT_BonusBilling.USM_BonusContract_Obj,
                                                                           bUVT_BonusBilling.Gesamtbetrag,
                                                                           bUVT_BonusBilling.bonusfaehigerBetrag,
                                                                           bUVT_BonusBilling.Period,
                                                                           bUVT_BonusBilling.Year,
                                                                           bUVT_BonusBilling.Periodtype,
                                                                           bUVT_BonusBilling.Quantity).

    end. /* if available bUSM_BonusType */

    find first bUSM_BonusGrade
      where bUSM_BonusGrade.Company                   = gcFirma
        and bUSM_BonusGrade.USM_BonusContractType_Obj = bUVT_BonusBilling.USM_BonusContractType_Obj
        and bUSM_BonusGrade.GradeValue                > dGradeValue
      no-lock no-error.

    /* if there is no higher gradevalue available we need to find the one used for the   */
    /* calculation so the user can see that his customer reached the highest gradevalue. */
    if not available bUSM_BonusGrade then

      find last bUSM_BonusGrade 
        where bUSM_BonusGrade.Company                   = gcFirma
          and bUSM_BonusGrade.USM_BonusContractType_Obj = bUVT_BonusBilling.USM_BonusContractType_Obj
          and bUSM_BonusGrade.GradeValue               <= dGradeValue
        no-lock no-error.

    if available bUSM_BonusGrade then
      dNextGradeValue = bUSM_BonusGrade.GradeValue.

    assign
      bttUVT_BonusBilling-P1.uBonusRate          = string(bUVT_BonusBilling.BonusRate) + ' ':U + cBonusRateTypeSupplement 
      bttUVT_BonusBilling-P1.uDiffNextGradeValue = dNextGradeValue - dGradeValue
      bttUVT_BonusBilling-P1.uNextGradeValue     = dNextGradeValue
      .

  end. /* if available bUVT_BonusBilling */        

end. /* if not can-find(bttUVT_BonusBilling-P1 */                   

&ENDIF

end procedure. /* uFillCreditInformation */


/* _UIB-CODE-BLOCK-END */
&ANALYZE-RESUME

&ENDIF


&IF DEFINED(EXCLUDE-fillCreditTermsForLLPrint) = 0 &THEN

&ANALYZE-SUSPEND _UIB-CODE-BLOCK _PROCEDURE fillCreditTermsForLLPrint Method-Library 
procedure fillCreditTermsForLLPrint :
/* Description ---------------------------------------------------------------*/
/*                                                                            */
/* The TT ttV_BelegZZ-P has been filled by the dataset framework, but the     */
/* Printmask1-3 fields need to be filled manually because of complex logic.   */
/*                                                                            */
/* Notes ---------------------------------------------------------------------*/
/*                                                                            */
/* This procedure does only encapsulate code for better readability of        */
/* fillDataset procedure. It can only be used in the context of this DAO !    */
/* run super() must have been executed and a global ttV_BelegKopf-P  and      */
/* ttV_BelegPos-P must be available!                                          */
/*                                                                            */
/* Parameters ----------------------------------------------------------------*/
/*                                                                            */
/* <none>                                                                     */
/*                                                                            */
/* Examples ------------------------------------------------------------------*/
/*                                                                            */
/*                                                                            */
/*                                                                            */
/*----------------------------------------------------------------------------*/

/* Variables -----------------------------------------------------------------*/
/*----------------------------------------------------------------------------*/
define variable tTemp             as date                             no-undo.

/* Buffers -------------------------------------------------------------------*/

define buffer bS_ZahlZiel    for S_ZahlZiel.
define buffer bS_ZahlZielSpr for S_ZahlZielSpr.
define buffer bS_WaehrungSpr for S_WaehrungSpr.
define buffer bV_BelegZZ     for V_BelegZZ.

/*----------------------------------------------------------------------------*/
/* Processing                                                                 */
/*----------------------------------------------------------------------------*/

if available ttS_ZahlZiel-P then
do:

  /* The bS_ZahlZielSpr record is needed now to prepare the printmask fields. */
  /* The frameword does provide this record in the content dataset, which is  */
  /* too late for our purpose...                                              */

  {adm/incl/d__spr00.if
    &Tabelle  = "bS_ZahlZielSpr"
    &Selekt   = "where bS_ZahlZielSpr.Firma        = {firma/szahlzie.fir ttS_ZahlZiel-P.Firma}
                   and bS_ZahlZielSpr.ZahlungsZiel = ttS_ZahlZiel-P.ZahlungsZiel"
    &Sprache  = "gcContentLanguage"
  }


  /* The bS_WaehrungSpr record is needed now to prepare the printmask fields. */
  /* The frameword does provide this record in the content dataset, which is  */
  /* too late for our purpose...                                              */

  {adm/incl/d__spr00.if
    &Tabelle  = "bS_WaehrungSpr"
    &Selekt   = "where bS_WaehrungSpr.Firma    = {firma/swaehrun.fir ttS_Waehrung-P1.Firma}
                   and bS_WaehrungSpr.Waehrung = ttS_Waehrung-P1.Waehrung"
    &Sprache  = "gcContentLanguage"
  }


  /* We need bS_ZahlZiel to pass it's ROWID to old API's, that cannot deal    */
  /* with OID's yet.                                                          */

  find bS_ZahlZiel
    where bS_ZahlZiel.S_ZahlZiel_Obj = ttS_ZahlZiel-P.S_ZahlZiel_Obj
    no-lock.

  /* determine document netdate*/

  if ttS_ZahlZiel-P.Manuell = no then
  do:

    SBCCreditTermsSvc:prpoInstance:DeterminePaymentDate
      (       (if ttV_Belegkopf-P.ValutaDatum <> ? then
                 ttV_Belegkopf-P.ValutaDatum
               else
                 ttV_Belegkopf-P.Belegdatum),
              ttV_Belegkopf-P.Kunde,
              '':U, /* OID S_I_TOPRate */
              buffer bS_ZahlZiel,
       output tTemp,
       output tTemp,
       output ttV_Belegkopf-P.NetDate,
       output tTemp).

    if bS_ZahlZielSpr.Druckmaske1  > '':U
      and bS_ZahlZiel.Skontosatz1    <> 0 then

      run vert/proc/v_vdru00.p ('Druckmaske1':U,
                                ttV_BelegSumKopf-Calc.Endbetrag_Brutto,
                                ttV_BelegSumKopf-Calc.Skontofaehige_Summe,
                                ttV_BelegSumKopf-Calc.NetDisctableTotal,
                                bS_WaehrungSpr.KurzBez,
                                gcEuroKurzbez,
                                (if ttS_Waehrung-P1.Eurofaktor > 0 then
                                   yes
                                 else
                                   no),
                                ttS_Waehrung-P1.Eurofaktor,
                                rowid(gbV_BelegKopf),
                                ?,
                                rowid(bS_ZahlZiel),
                                'X(250)':U,  /* old Waimea print field format was X(60)... we are more generous now */
                                bS_ZahlZielSpr.Druckmaske1,
                                output ttV_BelegKopf-P.Printmask1).

    if bS_ZahlZielSpr.Druckmaske2  > '':U
      and bS_ZahlZiel.Skontosatz2    <> 0 then

      run vert/proc/v_vdru00.p ('Druckmaske2':U,
                                ttV_BelegSumKopf-Calc.Endbetrag_Brutto,
                                ttV_BelegSumKopf-Calc.Skontofaehige_Summe,
                                ttV_BelegSumKopf-Calc.NetDisctableTotal,
                                bS_WaehrungSpr.KurzBez,
                                gcEuroKurzbez,
                                (if ttS_Waehrung-P1.Eurofaktor > 0 then
                                   yes
                                 else
                                   no),
                                ttS_Waehrung-P1.Eurofaktor,
                                rowid(gbV_BelegKopf),
                                ?,
                                rowid(bS_ZahlZiel),
                                'X(250)':U,  /* old Waimea print field format was X(60)... we are more generous now */
                                bS_ZahlZielSpr.Druckmaske2,
                                output ttV_BelegKopf-P.Printmask2).

    if bS_ZahlZielSpr.Druckmaske3  > '':U then

      run vert/proc/v_vdru00.p ('Druckmaske3':U,
                                ttV_BelegSumKopf-Calc.Endbetrag_Brutto,
                                ttV_BelegSumKopf-Calc.Skontofaehige_Summe,
                                ttV_BelegSumKopf-Calc.NetDisctableTotal,
                                bS_WaehrungSpr.KurzBez,
                                gcEuroKurzbez,
                                (if ttS_Waehrung-P1.Eurofaktor > 0 then
                                   yes
                                 else
                                   no),
                                ttS_Waehrung-P1.Eurofaktor,
                                rowid(gbV_BelegKopf),
                                ?,
                                rowid(bS_ZahlZiel),
                                'X(250)':U,  /* old Waimea print field format was X(60)... we are more generous now */
                                bS_ZahlZielSpr.Druckmaske3,
                                output ttV_BelegKopf-P.Printmask3).

  end.
  /* manual credit terms via ttV_BelegZZ-P */
  else
    for each ttV_BelegZZ-P:

      /* We need V_BelegZZ to pass it's ROWID to old API's, that cannot deal    */
      /* with OID's yet.                                                        */

      find bV_BelegZZ
        where bV_BelegZZ.V_BelegZZ_Obj = ttV_BelegZZ-P.V_BelegZZ_Obj
        no-lock.

      if bS_ZahlZielSpr.Druckmaske1  > '':U
        and ttV_BelegZZ-P.SkontoDatum1    <> ?
        and ttV_BelegZZ-P.Skontosatz1     <> 0 then

        run vert/proc/v_vdru00.p ('Druckmaske1':U,
                                  ttV_BelegZZ-P.FW_Betrag,
                                  ttV_BelegZZ-P.FW_Betrag,
                                  ttV_BelegSumKopf-Calc.NetDisctableTotal,
                                  bS_WaehrungSpr.KurzBez,
                                  gcEuroKurzbez,
                                  (if ttS_Waehrung-P1.Eurofaktor > 0 then
                                     yes
                                   else
                                     no),
                                  ttS_Waehrung-P1.Eurofaktor,
                                  rowid(gbV_BelegKopf),
                                  rowid(bV_BelegZZ),
                                  rowid(bS_ZahlZiel),
                                  'X(250)':U,  /* old Waimea print field format was X(60)... we are more generous now */
                                  bS_ZahlZielSpr.Druckmaske1,
                                  output ttV_BelegZZ-P.Printmask1).

      if bS_ZahlZielSpr.Druckmaske2  > '':U
        and ttV_BelegZZ-P.SkontoDatum2    <> ?
        and ttV_BelegZZ-P.Skontosatz2     <> 0 then

        run vert/proc/v_vdru00.p ('Druckmaske2':U,
                                  ttV_BelegZZ-P.FW_Betrag,
                                  ttV_BelegZZ-P.FW_Betrag,
                                  ttV_BelegSumKopf-Calc.NetDisctableTotal,
                                  bS_WaehrungSpr.KurzBez,
                                  gcEuroKurzbez,
                                  (if ttS_Waehrung-P1.Eurofaktor > 0 then
                                     yes
                                   else
                                     no),
                                  ttS_Waehrung-P1.Eurofaktor,
                                  rowid(gbV_BelegKopf),
                                  rowid(bV_BelegZZ),
                                  rowid(bS_ZahlZiel),
                                  'X(250)':U,  /* old Waimea print field format was X(60)... we are more generous now */
                                  bS_ZahlZielSpr.Druckmaske2,
                                  output ttV_BelegZZ-P.Printmask2).

      if bS_ZahlZielSpr.Druckmaske3  > '':U then

        run vert/proc/v_vdru00.p ('Druckmaske3':U,
                                  ttV_BelegZZ-P.FW_Betrag,
                                  ttV_BelegZZ-P.FW_Betrag,
                                  ttV_BelegSumKopf-Calc.NetDisctableTotal,
                                  bS_WaehrungSpr.KurzBez,
                                  gcEuroKurzbez,
                                  (if ttS_Waehrung-P1.Eurofaktor > 0 then
                                     yes
                                   else
                                     no),
                                  ttS_Waehrung-P1.Eurofaktor,
                                  rowid(gbV_BelegKopf),
                                  rowid(bV_BelegZZ),
                                  rowid(bS_ZahlZiel),
                                  'X(250)':U,  /* old Waimea print field format was X(60)... we are more generous now */
                                  bS_ZahlZielSpr.Druckmaske3,
                                  output ttV_BelegZZ-P.Printmask3).

    end. /*  for each ttV_BelegZZ-P */
end. /*  available ttS_ZahlZiel-P */

end procedure. /* fillCreditTermsForLLPrint */


/* _UIB-CODE-BLOCK-END */
&ANALYZE-RESUME

&ENDIF


&IF DEFINED(EXCLUDE-fillDocumentBankForLLPrint) = 0 &THEN

&ANALYZE-SUSPEND _UIB-CODE-BLOCK _PROCEDURE fillDocumentBankForLLPrint Method-Library 
procedure fillDocumentBankForLLPrint :
/* Description ---------------------------------------------------------------*/
/*                                                                            */
/* Fills the documents bank information for ll print                          */
/*                                                                            */
/* Notes ---------------------------------------------------------------------*/
/*                                                                            */
/*                                                                            */
/*                                                                            */
/* Parameters ----------------------------------------------------------------*/
/*                                                                            */
/* <none>                                                                     */
/*                                                                            */
/* Examples ------------------------------------------------------------------*/
/*                                                                            */
/*                                                                            */
/*                                                                            */
/*----------------------------------------------------------------------------*/

/* Variables -----------------------------------------------------------------*/
/* cSBM_BankDataAccObj Object ID of the main Bank of Supplier                 */
/*----------------------------------------------------------------------------*/
define variable cSBM_BankDataAccObj like SBM_BankDataAcc.SBM_BankDataAcc_Obj no-undo.

/* Buffers -------------------------------------------------------------------*/

define buffer bSBM_BankDataAcc     for SBM_BankDataAcc.
define buffer bS_Bank              for S_Bank.
define buffer bSBM_SEPAMAndateID   for SBM_SEPAMAndateID.
define buffer bS_Konto             for S_Konto.
define buffer bS_Adresse           for S_Adresse.
define buffer bttSBM_BankDataAcc-P for temp-table ttSBM_BankDataAcc-P.
define buffer bttS_Bank-P          for temp-table ttS_Bank-P.
define buffer bttS_Adresse-PBank   for temp-table ttS_Adresse-PBank.

/*----------------------------------------------------------------------------*/
/* Processing                                                                 */
/*----------------------------------------------------------------------------*/

/* Assign Bank data */

cSBM_BankDataAccObj = (if ttV_BelegKopf-P.SBM_BankDataAcc_Obj > '':U then
                         ttV_BelegKopf-P.SBM_BankDataAcc_Obj
                       else
                         SBCMasterFilesAccountingSvc:prpoInstance:cDefaultMainBankObj
                           ({firma/s_kunde.fir gcFirma},
                            ttS_Kunde-P1.S_Kunde_obj,
                            ttV_BelegKopf-P.Waehrung)).  

find bSBM_BankDataAcc
  where bSBM_BankDataAcc.SBM_BankDataAcc_Obj = cSBM_BankDataAccObj
  no-lock no-error.

if available bSBM_BankDataAcc then
do:

  create bttSBM_BankDataAcc-P.
  {buffer-copy
     bSBM_BankDataAcc
     to bttSBM_BankDataAcc-P
     assign
       "bttSBM_BankDataAcc-P.Firma          = gcFirma
        ttV_BelegKopf-P.SBM_BankDataAcc_Obj = bSBM_BankDataAcc.SBM_BankDataAcc_Obj"}

  validate bttSBM_BankDataAcc-P.

  find bS_Bank
    where bS_Bank.S_Bank_Obj = bSBM_BankDataAcc.S_Bank_Obj
    no-lock.

  create bttS_Bank-P.
  {buffer-copy
     bS_Bank
     to bttS_Bank-P
     assign
       "bttS_Bank-P.Firma = gcFirma"}

  validate bttS_Bank-P.

  find bS_Adresse
    where bS_Adresse.Firma    = {firma/s_adres.fir gcFirma}
      and bS_Adresse.AdressNr = bS_Bank.AdressNr
    no-lock no-error.

  if available bS_Adresse then
  do:

    create bttS_Adresse-PBank.
    {buffer-copy
       bS_Adresse
       to bttS_Adresse-PBank
       assign
         "bttS_Adresse-PBank.Firma = gcFirma"}

  end. /* if available bS_Adresse then */

  if pACConnectionSvc:prpcLocalization = 'I':U then

    assign
      ttV_BelegKopf-P.I_CustomerIBAN      = bSBM_BankDataAcc.IBAN
      ttV_BelegKopf-P.I_CustomerAccountNr = bSBM_BankDataAcc.BankKonto
      ttV_BelegKopf-P.I_CustomerSortCode  = bS_Bank.BLZ
      .

end. /* if available bSBM_BankDataAcc then */

else

  if pACConnectionSvc:prpcLocalization = 'I':U then
    assign
      ttV_BelegKopf-P.I_CustomerIBAN      = ttV_BelegKopf-P.IBAN
      ttV_BelegKopf-P.I_CustomerAccountNr = ttV_BelegKopf-P.BankKonto
      .

find bS_Konto
  where bS_Konto.Firma = {firma/skonto.fir gcFirma}
    and bS_Konto.Konto = ttS_Kunde-P1.Kunde
  no-lock.

find last bSBM_SEPAMandateID
  where bSBM_SEPAMandateID.S_Konto_Obj = bS_Konto.S_Konto_Obj
    and bSBM_SEPAMandateID.Valid_on   <= today
  no-lock no-error.

  ttS_Kunde-P1.SEPAMandateID = (if available bSBM_SEPAMandateID then
                                  bSBM_SEPAMandateID.SEPAMandateID
                                else
                                  '':U).

  validate ttS_Kunde-P1.

end procedure. /* fillDocumentBankForLLPrint */


/* _UIB-CODE-BLOCK-END */
&ANALYZE-RESUME

&ENDIF


&IF DEFINED(EXCLUDE-fillDocumentHeadCalculatedFieldsForLLPrint) = 0 &THEN

&ANALYZE-SUSPEND _UIB-CODE-BLOCK _PROCEDURE fillDocumentHeadCalculatedFieldsForLLPrint Method-Library 
procedure fillDocumentHeadCalculatedFieldsForLLPrint :
/* Description ---------------------------------------------------------------*/
/*                                                                            */
/* Fill additional TT fields in ttV_Belegkopf-P that cannot be filled by      */
/* the dataset framework.                                                     */
/*                                                                            */
/* Notes ---------------------------------------------------------------------*/
/*                                                                            */
/* This procedure does only encapsulate code for better readability of        */
/* fillDataset procedure. It can only be used in the context of this DAO !    */
/* run super() must have been executed and a global ttV_BelegKopf-P and       */
/* and ttS_Kunde-P1  must be available!                                       */
/*                                                                            */
/* Parameters ----------------------------------------------------------------*/
/*                                                                            */
/* <none>                                                                     */
/*                                                                            */
/* Examples ------------------------------------------------------------------*/
/*                                                                            */
/*                                                                            */
/*                                                                            */
/*----------------------------------------------------------------------------*/

/* Variables -----------------------------------------------------------------*/
/*----------------------------------------------------------------------------*/

define variable cTemp       as character                        no-undo.
define variable cCountryISO like SBM_TaxTerritory.IsoAlpha2Code no-undo.
define variable iShipmentTo as integer                          no-undo.

/* Buffers -------------------------------------------------------------------*/

define buffer ttV_BelegPos-Unloading for temp-table ttV_BelegPos-P.
define buffer bttS_UStID-P           for temp-table ttS_UStID-P.
define buffer bS_UStID               for            S_UStID.
define buffer bS_Kunde               for            S_Kunde.

/*----------------------------------------------------------------------------*/
/* Processing                                                                 */
/*----------------------------------------------------------------------------*/

  if ttV_Belegkopf-P.LieferTermin <> ? then

    assign
      cTemp                   = {fnarg
                                   pa_cDateWeekOfDate
                                   "ttV_Belegkopf-P.Liefertermin"}
      ttV_Belegkopf-P.LT_KW   = substring(cTemp,5,2) + '/':U + substring(cTemp,3,2)
      ttV_Belegkopf-P.LT_KW_4 = substring(cTemp,5,2) + '/':U + substring(cTemp,1,4)
      .


  if ttV_Belegkopf-P.WunschTermin <> ? then

    assign
      cTemp                   = {fnarg
                                   pa_cDateWeekOfDate
                                   "ttV_Belegkopf-P.WunschTermin"}
      ttV_Belegkopf-P.WT_KW   = substring(cTemp,5,2) + '/':U + substring(cTemp,3,2)
      ttV_Belegkopf-P.WT_KW_4 = substring(cTemp,5,2) + '/':U + substring(cTemp,1,4)
      .

  /* Fill the customers UStId which might be different from V_BelegKopf.UStID */
  /* The customers UStID might not be relevant for the tax case, but the      */
  /* information should be printable on the invoice...                        */
  /* The tax case relevant UStID is aways found  in        */

  /* If we have a different invoice recipient then the invoice will have another customer no. */
  /* than the order or delivery note. The tax id refers to the recipient of goods!            */

  iShipmentTo = vert.base.cls.VBCSalesDocSvc:prpoInstance:iGetCustomerOfShipment(
                  ttV_BelegKopf-P.BelegArt,
                  ttV_BelegKopf-P.Kunde,
                  ttV_BelegKopf-P.Lieferung_an,
                  ttV_BelegKopf-P.Herk_BelegArt,
                  ttV_BelegKopf-P.Herk_ReferenzNr).

  find bS_Kunde
    where bS_Kunde.Firma  = {firma/s_kunde.fir gcFirma}
      and bS_Kunde.Kunde  = iShipmentTo
    no-lock no-error.

  if ttV_Belegkopf-P.TaxID > '':U then
    ttV_Belegkopf-P.CustomerUStId  = ttV_Belegkopf-P.TaxID.

  else

    if    ttS_Kunde-P1.AdressNr <> 0        /* real customer, not divers customer */
      and available bS_Kunde then
    do:
      assign
        cCountryISO                    = SBCTaxMasterFilesSvc:prpoInstance:cIsoAlphaCodeOfTaxTerritory
                                           (ttV_Belegkopf-P.Dest_SBM_TaxTerritory_Obj[{&pa_SB_TaxTerritoryExt_Country}])
        ttV_Belegkopf-P.CustomerUStId  = SBCTaxMasterFilesSvc:prpoInstance:cTaxID
                                           (bS_Kunde.S_Kunde_Obj,
                                            ttV_Belegkopf-P.TaxIDType,
                                            cCountryISO)
        .

      if ttV_Belegkopf-P.CustomerUStId = '':U then
        ttV_Belegkopf-P.CustomerUStId  = SBCTaxMasterFilesSvc:prpoInstance:cTaxID
                                           (bS_Kunde.S_Kunde_Obj,
                                            ttV_Belegkopf-P.TaxIDType,
                                            '':U).  /* empty country parameter means S_Kunde.Staat will be used */

    end.

  /* collect the details of this CustomerUStId in a special tt */

  if    ttV_Belegkopf-P.CustomerUStId > '':U
    and ttV_Belegkopf-P.TaxIDType     = {&pa_SB_TaxIDType_UStID}
    and available bS_Kunde then
  do:

    find bS_UStID
      where bS_UStID.Firma         = {firma/s_kunde.fir gcFirma}
        and bS_UStID.Kontenbereich = {&pa_S_CustomerTaxID}
        and bS_UStID.Konto         = bS_Kunde.Kunde
        and bS_UStID.UStID         = ttV_Belegkopf-P.CustomerUStId
      no-lock no-error.

    if available bS_UStID then
    do:

      ttV_BelegKopf-P.S_UStID_Obj = bS_UStID.S_UStID_Obj.

      create bttS_UStID-P.

      {buffer-copy
         bS_UStID
         to bttS_UStID-P
         assign
           "bttS_UStID-P.Firma = gcFirma"}

      validate bttS_UStID-P.

    end. /* if available bS_UStID */

  end. /* ttV_Belegkopf-P.CustomerUStId > '':U */

  &IF lookup("WS":U,"{&pa-Module}":U) > 0 &THEN

  /* To determine the webshop order number of a sales document from           */
  /* table V_BelegKopf the API cWebshopOrderNrOfSalesDoc is used.             */

  ttV_Belegkopf-P.WebshopOrderNr = web.shop.cls.WSCWebshopSvc:prpoInstance:cWebshopOrderNrOfSalesDoc(ttV_Belegkopf-P.V_Belegkopf_Obj).

  &ENDIF

  find first ttV_BelegPos-Unloading no-error.
  if available ttV_BelegPos-Unloading then
    ttV_Belegkopf-P.UnloadingPoint = ttV_BelegPos-Unloading.Abladestelle.


  assign
    ttV_Belegkopf-P.ContactCustomerNr    = ttV_Belegkopf-P.Kunde
    ttV_Belegkopf-P.ContactCustomerLabel = no
    .

  /* if VIS is in use, the contact number is printed for quotes of divers   */
  /* customers. A correspondig label ist generated from                     */
  /* glContactCustomerLabel (yes = contact, no = customer)                  */

  &IF lookup ("VC":U,"{&PA-MODULE}":U) > 0 &THEN

    if ttS_Kunde-P1.AdressNr           = 0
      and ttV_Belegkopf-P.BelegArt    = 'A':U
      and ttV_Belegkopf-P.Interessent > 0 then

      assign
        ttV_Belegkopf-P.ContactCustomerNr    = ttV_Belegkopf-P.Interessent
        ttV_Belegkopf-P.ContactCustomerLabel = yes
        .

  &ENDIF

end procedure. /* fillDocumentHeadCalculatedFieldsForLLPrint */


/* _UIB-CODE-BLOCK-END */
&ANALYZE-RESUME

&ENDIF


&IF DEFINED(EXCLUDE-fillDocumentLineCalculatedFieldsForLLPrint) = 0 &THEN

&ANALYZE-SUSPEND _UIB-CODE-BLOCK _PROCEDURE fillDocumentLineCalculatedFieldsForLLPrint Method-Library 
procedure fillDocumentLineCalculatedFieldsForLLPrint :
/* Description ---------------------------------------------------------------*/
/*                                                                            */
/* There are some calculated fields that are not found in                     */
/* ttVB_CalculatedLineValues-P1 but directly in ttV_BelegPos-P because they   */
/* are special or dependant of flag glPositions (which is not considered by   */
/* API LLFillLineValuesTT)                                                    */
/*                                                                            */
/* Notes ---------------------------------------------------------------------*/
/*                                                                            */
/* This procedure does only encapsulate code for better readability of        */
/* fillDataset procedure. It can only be used in the context of this DAO !    */
/* run super() must have been executed and a global ttV_BelegKopf-P and       */
/* ttV_BelegPos-P  must be available!                                         */
/*                                                                            */
/* Parameters ----------------------------------------------------------------*/
/*                                                                            */
/* <none>                                                                     */
/*                                                                            */
/* Examples ------------------------------------------------------------------*/
/*                                                                            */
/*                                                                            */
/*                                                                            */
/*----------------------------------------------------------------------------*/

/* Variables -----------------------------------------------------------------*/
/*----------------------------------------------------------------------------*/
define variable cOIDHead                  as character                 no-undo.
define variable cOIDPos                   as character                 no-undo.
define variable cTemp                     as character                 no-undo.
define variable dGelieferteMenge          like V_BelegPos.Menge        no-undo.
define variable dBeauftragteMenge         like V_BelegPos.Menge        no-undo.
define variable dAuftragsmenge            like V_BelegPos.Menge        no-undo.
define variable dStornomenge              like V_BelegPos.Menge        no-undo.
define variable dPBetragBrutto            as   decimal                 no-undo.
define variable dPBetragNetto             as   decimal                 no-undo.

/* Buffers -------------------------------------------------------------------*/

define buffer bVS_AuftragPos           for VS_AuftragPos.
define buffer bVS_AuftragMKT           for VS_AuftragMKT.
define buffer bV_BelegKopf-OrigInvoice for V_BelegKopf.
define buffer bV_BelegPos              for V_BelegPos.
define buffer bPV_BelegPos             for V_BelegPos.
define buffer bS_MengenEinheitSpr      for S_MengenEinheitSpr.
define buffer bP_V_BelegKopf           for V_BelegKopf.
define buffer bDBM_ShortDescription    for DBM_ShortDescription.

&IF LOOKUP("U_CI":U,"{&PA-OPTIONEN}":U) > 0 &THEN  
  define buffer bS_VersandartSpr         for S_VersandartSpr.
&ENDIF

/*----------------------------------------------------------------------------*/
/* Processing                                                                 */
/*----------------------------------------------------------------------------*/

  /* fill fields OP_Aktiv  and AusgleichDatum */

  if available ttS_Artikel-P
    and ttS_Artikel-P.Artikelart        = {&pa_S_PT_PartPayAndMarkdowns}
    and ttV_BelegKopf-P.Belegart        = 'R':U
    and ttV_BelegKopf-P.Schlussrechnung = yes
    and ttV_BelegPos-P.Satzart          = 'A':U
    and ttV_BelegPos-P.Wertposition     = yes   then
  do:

    run vert/proc/v_vdru06.p (ttV_BelegPos-P.Firma,
                              ttV_BelegPos-P.Herk_Belegart,
                              ttV_BelegPos-P.Herk_ReferenzNr,
                              output ttV_BelegPos-P.OP_Aktiv,
                              output ttV_BelegPos-P.AusgleichDatum).

  end.

  /* fill field Berechnung_Info */

  &IF   lookup("VS","{&PA-MODULE}") > 0
    AND lookup("VS_SAUF","{&PA-OPTIONEN}") > 0 &THEN

    if ttV_BelegPos-P.Herk_BelegArt = 'VSA':U then
    do:

      if num-entries(ttV_BelegPos-P.Herk_Schluessel,{&PA-DELIMITER3}) = 3 then
      do:

        find bVS_AuftragPos
          where bVS_AuftragPos.Firma       = ttV_BelegPos-P.Firma
            and bVS_AuftragPos.Belegart    = 'VSA':U
            and bVS_AuftragPos.ReferenzNr  = integer(entry(2,ttV_BelegPos-P.Herk_Schluessel,{&PA-DELIMITER3}))
            and bVS_AuftragPos.PositionsNr = integer(entry(3,ttV_BelegPos-P.Herk_Schluessel,{&PA-DELIMITER3}))
          no-lock no-error.

        if available bVS_AuftragPos then
          ttV_BelegPos-P.Berechnung_Info = adm.config.cls.DCCAppConfigSvc:prpoInstance:cParamValByRefParamValLng
                                             ('VS_ServiceOrderCalcIndicators_desc':U,
                                              string(bVS_AuftragPos.Berechnung),
                                              gcContentLanguage).

      end. /* Origin Table is VS_AuftragPos (3 entries in V_BelegPos.Herk_Schluessel) */
      else
      do:

        find bVS_AuftragMKT
          where bVS_AuftragMKT.Firma      = ttV_BelegPos-P.Firma
            and bVS_AuftragMKT.Belegart   = 'VSA':U
            and bVS_AuftragMKT.ReferenzNr = integer(entry(2,ttV_BelegPos-P.Herk_Schluessel,{&PA-DELIMITER3}))
            and bVS_AuftragMKT.lfdNr_Pos  = integer(entry(3,ttV_BelegPos-P.Herk_Schluessel,{&PA-DELIMITER3}))
            and bVS_AuftragMKT.Satzart    = entry(4,ttV_BelegPos-P.Herk_Schluessel,{&PA-DELIMITER3})
            and bVS_AuftragMKT.lfdNr_Akt  = integer(entry(5,ttV_BelegPos-P.Herk_Schluessel,{&PA-DELIMITER3}))
            and bVS_AuftragMKT.lfdNr      = integer(entry(6,ttV_BelegPos-P.Herk_Schluessel,{&PA-DELIMITER3}))
          no-lock no-error.

        if available bVS_AuftragMKT then
          ttV_BelegPos-P.Berechnung_Info = adm.config.cls.DCCAppConfigSvc:prpoInstance:cParamValByRefParamValLng
                                             ('VS_ServiceOrderCalcIndicators_desc':U,
                                              string(bVS_AuftragMKT.Berechnung),
                                              gcContentLanguage).

      end. /* else.. Origin Table is VS_AuftragMKT (5 entries in V_BelegPos.Herk_Schluessel) */

    end.
  &ENDIF /* VS, VS_SAUF */

  assign
    ttV_BelegPos-P.Einzelpreis_VME       = (if ttV_BelegPos-P.Preisfaktor <> 0 then
                                                ttV_BelegPos-P.Einzelpreis
                                              / ttV_BelegPos-P.Preisfaktor
                                              * ttV_BelegPos-P.VME_Faktor
                                            else
                                              ttV_BelegPos-P.Einzelpreis)
    ttV_BelegPos-P.Verkaufspreis         =  ttV_BelegPos-P.Einzelpreis
                                              + ttV_BelegPos-P.Wert_RZ_1
                                              + ttV_BelegPos-P.Wert_RZ_2
    ttV_BelegPos-P.Verkaufspreis_VME     = (if ttV_BelegPos-P.Preisfaktor <> 0 then
                                              round((  ttV_BelegPos-P.Einzelpreis
                                                     + ttV_BelegPos-P.Wert_RZ_1
                                                     + ttV_BelegPos-P.Wert_RZ_2)
                                                    / ttV_BelegPos-P.Preisfaktor
                                                    * ttV_BelegPos-P.VME_Faktor,
                                                    ttV_BelegKopf-P.WaehrungNK)
                                            else
                                              ttV_BelegPos-P.Verkaufspreis)
    ttV_BelegPos-P.EffektiverEinzelpreis = ttV_BelegPos-P.Einzelpreis
                                             * (1 + ttV_BelegPos-P.proz_RZ_1 / 100)
                                             * (1 + ttV_BelegPos-P.proz_RZ_2 / 100)
                                             * (1 + ttV_BelegPos-P.proz_RZ_3 / 100)
                                             * (1 + ttV_BelegPos-P.proz_RZ_4 / 100)
                                             * (1 + ttV_BelegPos-P.proz_RZ_5 / 100)
                                             + (ttV_BelegPos-P.Wert_RZ_1 + ttV_BelegPos-P.Wert_RZ_2 + ttV_BelegPos-P.Wert_RZ_3 + ttV_BelegPos-P.Wert_RZ_4 + ttV_BelegPos-P.Wert_RZ_5)
    .

  &IF "{&pa_S_F_EcoTax}":U = "1":U &THEN
    if pACConnectionSvc:prpcLocalization = 'F':U then
    do:

      if    ttV_BelegPos-P.VME_Faktor <> 1
        and ttV_BelegPos-P.Wert_RZ_5  <> 0 then

        ttV_BelegPos-P.F_EcoTax_SU =   ttV_BelegPos-P.Wert_RZ_5
                                     / ttV_BelegPos-P.PreisFaktor
                                     * ttV_BelegPos-P.VME_Faktor.

      if ttV_BelegPos-P.Wert_RZ_5 <> 0 then

        ttV_BelegPos-P.F_EcoTaxDesc = adm.base.cls.DBCTranslateSvc:prpoInstance:cTranslateGermanTerm('Umweltabgabe':U, 18).

      ttV_BelegPos-P.F_SellingPriceWithEcoTax =   ttV_BelegPos-P.Einzelpreis
                                                + ttV_BelegPos-P.Wert_RZ_1
                                                + ttV_BelegPos-P.Wert_RZ_2
                                                + ttV_BelegPos-P.Wert_RZ_5.

      if    ttV_BelegPos-P.VME_Faktor <> 1
        and not(  ttV_BelegPos-P.Einzelpreis
                + ttV_BelegPos-P.Wert_RZ_1
                + ttV_BelegPos-P.Wert_RZ_2
                + ttV_BelegPos-P.Wert_RZ_5  = 0) then

        ttV_BelegPos-P.F_SellingPriceWithEcoTax_SU = round((ttV_BelegPos-P.Einzelpreis
                                                            + ttV_BelegPos-P.Wert_RZ_1
                                                            + ttV_BelegPos-P.Wert_RZ_2
                                                            + ttV_BelegPos-P.Wert_RZ_5)
                                                            / ttV_BelegPos-P.Preisfaktor
                                                            * ttV_BelegPos-P.VME_Faktor,
                                                              ttV_BelegKopf-P.WaehrungNK).

      if ttV_BelegPos-P.Wert_RZ_5 = 0 then

        ttV_BelegPos-P.F_EcoTaxSum = (if ttV_BelegPos-P.offen then
                                        ttV_BelegPos-P.Wert_RZ_5
                                        * (  ttV_BelegPos-P.Menge
                                           - ttV_BelegPos-P.stornierte_Menge
                                           - ttV_BelegPos-P.gelieferte_Menge)
                                        / ttV_BelegPos-P.Preisfaktor
                                      else
                                        ttV_BelegPos-P.Wert_RZ_5
                                        * (  ttV_BelegPos-P.Menge
                                           - ttV_BelegPos-P.stornierte_Menge)
                                        / ttV_BelegPos-P.Preisfaktor ).

      ttV_BelegPos-P.F_SumWithoutEcoTax = (if ttV_BelegPos-P.offen then
                                             ttV_BelegPos-P.Gesamtpreis_offen - ttV_BelegPos-P.Wert_RZ_5
                                                                                * (  ttV_BelegPos-P.Menge
                                                                                   - ttV_BelegPos-P.stornierte_Menge
                                                                                   - ttV_BelegPos-P.gelieferte_Menge)
                                                                                / ttV_BelegPos-P.Preisfaktor
                                           else
                                             ttV_BelegPos-P.Gesamtpreis - ttV_BelegPos-P.Wert_RZ_5
                                                                          * (  ttV_BelegPos-P.Menge
                                                                             - ttV_BelegPos-P.stornierte_Menge)
                                                                          / ttV_BelegPos-P.Preisfaktor ).

      ttV_BelegKopf-P.F_EcoTaxAmount = ttV_BelegKopf-P.F_EcoTaxAmount + round(  ttV_BelegPos-P.Wert_RZ_5
                                                                              * ttV_BelegPos-P.Menge
                                                                              / ttV_BelegPos-P.Preisfaktor,
                                                                              ttV_BelegKopf-P.WaehrungNK).

    end. /* if pACConnectionSvc:prpcLocalization = 'F':U then */
  &ENDIF

  /* Credits may follow an invoice... to print the invoice date a credit      */
  /* position references, the original invoice is needed.                     */
  /* Reset field to ? first, because initial is today...                      */

  ttV_BelegPos-P.InvoiceDateCredit = ?.

  if ttV_BelegPos-P.Herk_BelegArt = 'R':U then
  do:

    find bV_BelegKopf-OrigInvoice
      where bV_BelegKopf-OrigInvoice.Firma       = ttV_BelegPos-P.Firma
        and bV_BelegKopf-OrigInvoice.Belegart    = ttV_BelegPos-P.Herk_Belegart
        and bV_BelegKopf-OrigInvoice.ReferenzNr  = ttV_BelegPos-P.Herk_ReferenzNr
      no-lock no-error.

    if available bV_BelegKopf-OrigInvoice then

      assign
        ttV_BelegPos-P.InvoiceDateCredit     = bV_BelegKopf-OrigInvoice.Belegdatum
        ttV_BelegPos-P.InvoiceNumber         = bV_BelegKopf-OrigInvoice.Belegnummer
        .

  end. /* if V_BelegPos.Herk_BelegArt = 'R':U then */

  if pACConnectionSvc:prpcLocalization = 'P':U
    and ttV_BelegKopf-P.P_RechnungsTyp = VBCPolandHungarySpecialsSvc:CorrectingInvoice then
  do:

    find first bPV_BelegPos
      where bPV_BelegPos.Firma            = ttV_BelegPos-P.Firma
        and bPV_BelegPos.Belegart         = ttV_BelegPos-P.BelegArt
        and bPV_BelegPos.ReferenzNr       = ttV_BelegPos-P.ReferenzNr
        and bPV_BelegPos.LfdNr_SR         = ttV_BelegPos-P.LfdNr_SR
        and bPV_BelegPos.P_StorniertePos  = ttV_BelegPos-P.P_korrigiertePos
        and bPV_BelegPos.P_StorniertePos <> 0
      no-lock no-error.

    if available bPV_BelegPos then
      assign
        ttV_BelegPos-P.P_Diff_Menge         = ttV_BelegPos-P.Menge       + bPV_BelegPos.Menge
        ttV_BelegPos-P.P_Diff_Wert          = ttV_BelegPos-P.GesamtPreis + bPV_BelegPos.GesamtPreis
        ttV_BelegPos-P.P_Diff_Gewicht       = bPV_BelegPos.Gewicht
                                              * (bPV_BelegPos.Menge 
                                                 - bPV_BelegPos.stornierte_Menge)
                                              + ttV_BelegPos-P.Gewicht
                                              * (ttV_BelegPos-P.Menge
                                                 - ttV_BelegPos-P.stornierte_Menge)
        ttV_BelegPos-P.P_Diff_Gesamtgewicht = (bPV_BelegPos.Gewicht
                                              * (bPV_BelegPos.Menge
                                                 - bPV_BelegPos.stornierte_Menge))
                                              + (bPV_BelegPos.GewichtVerp
                                                 * (bPV_BelegPos.Menge
                                                    - bPV_BelegPos.stornierte_Menge)
                                                 / bPV_BelegPos.VME_Faktor)
                                              + (ttV_BelegPos-P.Gewicht
                                                 * (ttV_BelegPos-P.Menge
                                                    - ttV_BelegPos-P.stornierte_Menge))
                                              + (ttV_BelegPos-P.GewichtVerp
                                                * (ttV_BelegPos-P.Menge
                                                   - ttV_BelegPos-P.stornierte_Menge)
                                                / ttV_BelegPos-P.VME_Faktor)

        .

  end. /* if pACConnectionSvc:prpcLocalization = 'P':U then */

  /* Weight of position without packaging material */

  ttV_BelegPos-P.WeightNet  = ttV_BelegPos-P.Gewicht
                               * (if ttV_BelegPos-P.offen
                                    and glPositions   then
                                    ttV_BelegPos-P.Menge
                                    - ttV_BelegPos-P.stornierte_Menge
                                    - ttV_BelegPos-P.gelieferte_Menge
                                  else
                                    ttV_BelegPos-P.Menge
                                    - ttV_BelegPos-P.stornierte_Menge).

  /* Total weight of position including packaging material */

  ttV_BelegPos-P.WeightTotal = (ttV_BelegPos-P.Gewicht
                                 * (if ttV_BelegPos-P.offen
                                      and glPositions then
                                      ttV_BelegPos-P.Menge
                                      - ttV_BelegPos-P.stornierte_Menge
                                      - ttV_BelegPos-P.gelieferte_Menge
                                    else
                                      ttV_BelegPos-P.Menge
                                      - ttV_BelegPos-P.stornierte_Menge))
                                + (ttV_BelegPos-P.GewichtVerp
                                   * (if ttV_BelegPos-P.offen
                                        and glPositions then
                                        ttV_BelegPos-P.Menge
                                        - ttV_BelegPos-P.stornierte_Menge
                                        - ttV_BelegPos-P.gelieferte_Menge
                                      else
                                        ttV_BelegPos-P.Menge
                                        - ttV_BelegPos-P.stornierte_Menge)
                                     / ttV_BelegPos-P.VME_Faktor).

  find bV_BelegPos
    where bV_BelegPos.V_BelegPos_Obj = ttV_BelegPos-P.V_BelegPos_Obj
    no-lock.

  ttV_BelegPos-P.WeightGross = vert.base.cls.VBCSalesDocSvc:prpoInstance:dCalcTotalWeightDocLine
                                 (buffer bV_BelegPos, glPositions, yes).

  ttV_BelegPos-P.Menge_LME = (if ttV_BelegPos-P.offen
                                and glPositions then
                                (ttV_BelegPos-P.Menge
                                 - ttV_BelegPos-P.stornierte_Menge
                                 - ttV_BelegPos-P.gelieferte_Menge)
                              else
                                (ttV_BelegPos-P.Menge
                                 - ttV_BelegPos-P.stornierte_Menge)).


  assign
    ttV_BelegPos-P.Rabattbetrag             = ttV_BelegSumPos-Calc.Rabattbetrag
    ttV_BelegPos-P.rabattfaehige_Summe      = ttV_BelegSumPos-Calc.RF_Summe
    ttV_BelegPos-P.Summe                    = ttV_BelegSumPos-Calc.Summe
    ttV_BelegPos-P.Uebertrag                = ttV_BelegSumPos-Calc.Uebertrag
    ttV_BelegPos-P.Zwischensumme            = ttV_BelegSumPos-Calc.Summe + ttV_BelegSumPos-Calc.Rabattbetrag
    .

   if ttV_BelegPos-P.Satzart               = 'A':U
      and ttV_BelegPos-P.Alternativposition = no then

     ttV_BelegPos-P.Uebertrag = ttV_BelegSumPos-Calc.Uebertrag.

  if ttS_Waehrung-P1.Eurofaktor > 0
    and not ttS_Waehrung-P1.ISO_KurzBez = 'EUR':U then

    assign
      ttV_BelegPos-P.Eur_Rabattbetrag         = ttV_BelegPos-P.Rabattbetrag        /  ttS_Waehrung-P1.Eurofaktor
      ttV_BelegPos-P.Eur_rabattfaehige_Summe  = ttV_BelegPos-P.rabattfaehige_Summe /  ttS_Waehrung-P1.Eurofaktor
      ttV_BelegPos-P.Eur_Summe                = ttV_BelegPos-P.Summe               /  ttS_Waehrung-P1.Eurofaktor
      ttV_BelegPos-P.Eur_Uebertrag            = ttV_BelegPos-P.Uebertrag           /  ttS_Waehrung-P1.Eurofaktor
      ttV_BelegPos-P.Eur_Zwischensumme        = ttV_BelegPos-P.Zwischensumme       /  ttS_Waehrung-P1.Eurofaktor
      .

  &IF lookup("M_PACK","{&PA-OPTIONEN}") > 0 &THEN

  ttV_BelegPos-P.ParcelNumbers = mawi.base.cls.MMCPackagingSvc:prpoInstance:clGetInternalParcelNumberAsText
                                  (ttV_BelegKopf-P.Firma,                               /* Company                                                  */
                                   'V':U,                                               /* Area = V (Sales), E ( Purchasing) usw.                   */
                                   {&pa_MM_PackagingDelivery},                          /* Function Code                                            */
                                   '':U,                                                /* Document Type 1                                          */
                                   '':U,                                                /* Key from a Transport Document                            */
                                   ttV_BelegPos-P.BelegArt,                             /* Document Type 2                                          */
                                   {vert/incl/v_belko.sl &Tabelle = "ttV_BelegKopf-P"}, /* Key or Object-ID from a Document Position                */
                                   ttV_BelegPos-P.BelegArt,                             /* Document Type 3                                          */
                                   {vert/incl/v_belpo.sl &Tabelle = "ttV_Belegpos-P"},  /* Key or Object-ID from a Document Position                */
                                   '':U,                                                /* Package                                                  */
                                   0,                                                   /* 0 = all,                                                 */
                                   0,                                                   /* Fill Quantity from Package                               */
                                   ?,                                                   /* width                                                    */
                                   ?,                                                   /* height                                                   */
                                   ?).                                                  /* depth                                                    */                                     

  &ENDIF

  vert.base.cls.VBCSalesDocSvc:prpoInstance:cGetOIDOriginOrderOrQuote(ttV_BelegPos-P.V_BelegPos_Obj,output cOIDHead,output cOIDPos).

  assign
    ttV_BelegPos-P.ClassificationOwnerPV_Obj  = cOIDPos
    ttV_BelegPos-P.ClassificationSystemPV     = ?
    .


  if ttV_BelegPos-P.LieferTermin <> ? then

    assign
      cTemp                   = {fnarg
                                   pa_cDateWeekOfDate
                                   "ttV_BelegPos-P.Liefertermin"}
      ttV_BelegPos-P.LT_KW   = substring(cTemp,5,2) + '/':U + substring(cTemp,3,2)
      ttV_BelegPos-P.LT_KW_4 = substring(cTemp,5,2) + '/':U + substring(cTemp,1,4)
      .


  if ttV_BelegPos-P.WunschTermin <> ? then

    assign
      cTemp                   = {fnarg
                                   pa_cDateWeekOfDate
                                   "ttV_BelegPos-P.WunschTermin"}
      ttV_BelegPos-P.WT_KW   = substring(cTemp,5,2) + '/':U + substring(cTemp,3,2)
      ttV_BelegPos-P.WT_KW_4 = substring(cTemp,5,2) + '/':U + substring(cTemp,1,4)
      .

  /* Wertposition oder Artikel ********************************** */

  if ttV_BelegPos-P.Satzart = 'A':U then
  do:

    assign
      dGelieferteMenge  = 0
      dBeauftragteMenge = 0
      dAuftragsmenge    = ttV_BelegPos-P.Menge
      dStornomenge      = ttV_BelegPos-P.stornierte_Menge
      .

    &IF DEFINED(EXCLUDE-Rahmen) = 0 &THEN

    if can-do('VUR,L':U,ttV_BelegPos-P.Belegart) then
    do:

      run vert/proc/v_vdru05.p (rowid(bV_BelegPos),
                                output dBeauftragteMenge,
                                output dGelieferteMenge).

      if ttV_BelegPos-P.Belegart         = 'L':U
        and ttV_BelegPos-P.Herk_Belegart = 'U':U then

        assign
          dAuftragsmenge = dBeauftragteMenge + dGelieferteMenge
          dStornomenge   = dGelieferteMenge
          .

    end. /* if can-do('VUR,L':U,V_BelegPos.Belegart) then */

    &ENDIF

    assign
      ttV_BelegPos-P.Auftragsmenge_LME    = dAuftragsmenge
      ttV_BelegPos-P.gelieferteMenge_LME  = (if ttV_BelegPos-P.Belegart = 'VUR':U then
                                               dGelieferteMenge
                                             else
                                               ttV_BelegPos-P.gelieferte_Menge)
      ttV_BelegPos-P.offeneMenge_LME      = ttV_BelegPos-P.Menge
                                            - ttV_BelegPos-P.gelieferte_Menge
                                            - ttV_BelegPos-P.stornierte_Menge
      ttV_BelegPos-P.stornierteMenge_LME  = dStornomenge
      ttV_BelegPos-P.beauftragteMenge_LME = dBeauftragteMenge
      .

    assign
      ttV_BelegPos-P.Auftragsmenge_VME    = ttV_BelegPos-P.Auftragsmenge_LME
                                            / ttV_BelegPos-P.VME_Faktor

      ttV_BelegPos-P.gelieferteMenge_VME  = ttV_BelegPos-P.gelieferteMenge_LME
                                            / ttV_BelegPos-P.VME_Faktor

      ttV_BelegPos-P.offeneMenge_VME      = ttV_BelegPos-P.offeneMenge_LME
                                            / ttV_BelegPos-P.VME_Faktor

      ttV_BelegPos-P.stornierteMenge_VME  = ttV_BelegPos-P.stornierteMenge_LME
                                            / ttV_BelegPos-P.VME_Faktor
      ttV_BelegPos-P.Vertragsmenge_VME    = ttV_BelegPos-P.Menge
                                            / ttV_BelegPos-P.VME_Faktor
      ttV_BelegPos-P.Menge_komplett       = ttV_BelegPos-P.Menge_LME
                                            / ttV_BelegPos-P.VME_Faktor
      ttV_BelegPos-P.beauftragteMenge_VME = ttV_BelegPos-P.beauftragteMenge_LME
                                            / ttV_BelegPos-P.VME_Faktor

      .

  end. /* ttV_BelegPos-P.Satzart = 'A':U */

  if available ttS_Artikel-P then
  do:

    {adm/incl/d__spr00.if
      &Tabelle  = "bS_MengenEinheitSpr"
      &Selekt   = "where bS_MengenEinheitSpr.Firma          = {firma/smngeinh.fir ttV_BelegPos-P.Firma}
                      and bS_MengenEinheitSpr.Mengeneinheit = (if ttV_BelegPos-P.VME_Faktor <> 1 then
                                                                 ttV_BelegPos-P.Mengeneinheit
                                                               else
                                                                 ttS_Artikel-P.LagerME)"
      &Sprache  = "gcContentLanguage"
    }

    ttV_BelegPos-P.VerpackungsME = bS_MengenEinheitSpr.Bezeichnung.

  end.

  if lookup(ttV_BelegPos-P.Belegart,'A,U,L,R,G,VFP,VUD,VUA':U) > 0 
    and ttV_BelegPos-P.Satzart = 'A':U
    and ttV_BelegPos-P.MMM_CusRefOrder_ID  <> '':U 
    and ttV_BelegPos-P.MMM_CusRefOrder_Obj <> '':U then
  do:
    {adm/incl/d__spr00.if
      &Tabelle  = "bDBM_ShortDescription"
      &Selekt   = "where bDBM_ShortDescription.Owning_Obj = ttV_BelegPos-P.MMM_CusRefOrder_Obj"
      &Sprache  = "gcContentLanguage"
      &no-error = "no-error"
    }

    if available bDBM_ShortDescription then
      ttV_BelegPos-P.CROInfo = bDBM_ShortDescription.ShortDesc1.
  end.

  &IF LOOKUP("U_CI":U,"{&PA-OPTIONEN}":U) > 0 &THEN

    if ttV_BelegPos-P.Satzart = 'A':U then
    do:

      {adm/incl/d__spr00.if
        &Tabelle = "bS_VersandArtSpr"
        &Selekt  = "where bS_VersandArtSpr.Firma      = {firma/sversart.fir ttV_BelegPos-P.Firma}
                      and bS_VersandArtSpr.VersandArt = ttV_BelegPos-P.uCI_VersandArt"
        &Sprache = "gcContentLanguage"
        &no-error = "no-error"
      }

      if available bS_VersandartSpr then
        ttV_BelegPos-P.BezeichnungVA = bS_VersandartSpr.Bezeichnung.

    end. 

  &ENDIF

  /* The total tax has already been calculated in method LLFillLineValuesTT   */
  /* but we have to handle flag glPositions here (which is not considered by  */
  /* API LLFillLineValuesTT).                                                  */

  if pACConnectionSvc:prpcLocalization = 'USA':U then

    ttV_BelegPos-P.USTax_TotalTaxAmount = if ttV_BelegPos-P.Gesamtpreis = 0 then
                                            0
                                          else
                                            (if    ttV_BelegPos-P.offen = yes
                                               and glPositions          = yes then
                                               round(ttV_BelegPos-P.USTax_TotalTaxAmount
                                                     * ttV_BelegPos-P.Gesamtpreis_offen
                                                     / ttV_BelegPos-P.Gesamtpreis,
                                                     ttV_BelegKopf-P.WaehrungNK)
                                             else
                                               ttV_BelegPos-P.USTax_TotalTaxAmount).

  if pACConnectionSvc:prpcLocalization = 'P':U then
  do:

    assign
      dPBetragBrutto                    = round((  ({vert/incl/v__bel01.if
                                                      &cc_offen  = "ttV_BelegKopf-P.offen"
                                                      &Tabelle   = "ttV_BelegPos-P"
                                                      &Nachkomma = "ttV_BelegKopf-P.WaehrungNK"
                                                      &Brutto    = "ttV_BelegKopf-P.Brutto"})
                                                 * (1 + ttV_BelegPos-P.Steuersatz / 100)),
                                                ttV_BelegKopf-P.WaehrungNK)
      dPBetragNetto                     = round((({vert/incl/v__bel01.if
                                                    &cc_offen  = "ttV_BelegKopf-P.offen"
                                                    &Tabelle   = "ttV_BelegPos-P"
                                                    &Nachkomma = "ttV_BelegKopf-P.WaehrungNK"
                                                    &Brutto    = "ttV_BelegKopf-P.Brutto"})),
                                                ttV_BelegKopf-P.WaehrungNK)
      ttV_BelegPos-P.P_Bruttobetrag     =   dPBetragBrutto
                                          * (if    ttV_BelegKopf-P.P_RechnungsTyp  = VBCPolandHungarySpecialsSvc:CorrectingInvoice
                                               and ttV_BelegPos-P.P_korrigiertePos = 0
                                               and ttV_BelegPos-P.Herk_BelegArt    = 'R':U then
                                               -1
                                             else
                                               1)
      ttV_BelegPos-P.P_Bruttobetrag_EW  =   (dPBetragNetto * ttV_BelegKopf-P.Kurs)
                                          + (  (dPBetragBrutto - dPBetragNetto)
                                             * ttV_BelegKopf-P.Kurs)
                                          * (if    ttV_BelegKopf-P.P_RechnungsTyp  = VBCPolandHungarySpecialsSvc:CorrectingInvoice
                                               and ttV_BelegPos-P.P_korrigiertePos = 0
                                               and ttV_BelegPos-P.Herk_BelegArt    = 'R':U then
                                               -1
                                             else
                                               1)
      ttV_BelegPos-P.P_Gesamtpreis_EW   =   dPBetragNetto * ttV_BelegKopf-P.Kurs
                                          * (if    ttV_BelegKopf-P.P_RechnungsTyp  = VBCPolandHungarySpecialsSvc:CorrectingInvoice
                                               and ttV_BelegPos-P.P_korrigiertePos = 0
                                               and ttV_BelegPos-P.Herk_BelegArt    = 'R':U then
                                               -1
                                             else
                                               1)
      ttV_BelegPos-P.P_KorrInfo         = (not ttV_BelegPos-P.P_storniertePos = 0)
      ttV_BelegPos-P.P_Steuerbetrag     =   (dPBetragBrutto - dPBetragNetto)
                                          * (if    ttV_BelegKopf-P.P_RechnungsTyp  = VBCPolandHungarySpecialsSvc:CorrectingInvoice
                                               and ttV_BelegPos-P.P_korrigiertePos = 0
                                               and ttV_BelegPos-P.Herk_Belegart    = 'R':U then
                                               -1
                                             else
                                               1)
      ttV_BelegPos-P.P_Steuerbetrag_EW  =   (dPBetragBrutto - dPBetragNetto)
                                          * ttV_BelegKopf-P.Kurs
                                          * (if    ttV_BelegKopf-P.P_RechnungsTyp  = VBCPolandHungarySpecialsSvc:CorrectingInvoice
                                               and ttV_BelegPos-P.P_korrigiertePos = 0
                                               and ttV_BelegPos-P.Herk_Belegart    = 'R':U then
                                               -1
                                             else
                                               1)
      ttV_BelegPos-P.P_Verkaufspreis_EW =   (  ttV_BelegPos-P.Einzelpreis
                                             + ttV_BelegPos-P.Wert_RZ_1
                                             + ttV_BelegPos-P.Wert_RZ_2)
                                          * ttV_BelegKopf-P.Kurs
      .

    /* P_PrePaymentDate */

    if    ttV_BelegKopf-P.Schlussrechnung = yes
      and can-find(S_Artikel
                     where S_Artikel.Firma      = {firma/sartikel.fir gcFirma}
                       and S_Artikel.Artikel    = ttV_BelegPos-P.Artikel
                       and S_Artikel.ArtikelArt = {&pa_S_PT_PartPayAndMarkdowns}) then
    do:

      find bP_V_BelegKopf
        where bP_V_BelegKopf.Firma      = {firma/vbelegko.fir gcFirma}
          and bP_V_BelegKopf.Belegart   = ttV_BelegPos-P.Herk_Belegart
          and bP_V_BelegKopf.ReferenzNr = ttV_BelegPos-P.Herk_ReferenzNr
        no-lock no-error.

      ttV_BelegPos-P.P_PrePaymentDate = (if available bP_V_BelegKopf then
                                           string(bP_V_BelegKopf.Belegdatum)
                                         else
                                           '':U).

    end. /* if ttV_BelegKopf-P.Schlussrechnung = yes */

  end. /* if pACConnectionSvc:prpcLocalization = 'P':U */

end procedure. /* fillDocumentLineCalculatedFieldsForLLPrint */


/* _UIB-CODE-BLOCK-END */
&ANALYZE-RESUME

&ENDIF


&IF DEFINED(EXCLUDE-fillDocumentLineTaxForLLPrint) = 0 &THEN

&ANALYZE-SUSPEND _UIB-CODE-BLOCK _PROCEDURE fillDocumentLineTaxForLLPrint Method-Library 
procedure fillDocumentLineTaxForLLPrint :
/* Description ---------------------------------------------------------------*/
/*                                                                            */
/* fills the temp-table ttS_Steuer-PLine                                      */
/*                                                                            */
/*----------------------------------------------------------------------------*/

define buffer bS_Steuer            for S_Steuer.
define buffer bSBM_TaxRate         for SBM_TaxRate.
define buffer bttS_Steuer-PLine    for temp-table ttS_Steuer-PLine.
define buffer bttSBM_TaxRate-PLine for temp-table ttSBM_TaxRate-PLine.

/*----------------------------------------------------------------------------*/
/* Processing                                                                 */
/*----------------------------------------------------------------------------*/

if ttV_BelegPos-P.S_Steuer_Obj > '':U
  and not can-find(bttS_Steuer-PLine
                     where bttS_Steuer-PLine.S_Steuer_Obj = ttV_BelegPos-P.S_Steuer_Obj) then
do:

  find bS_Steuer
    where bS_Steuer.S_Steuer_Obj = ttV_BelegPos-P.S_Steuer_Obj
    no-lock.

  create bttS_Steuer-PLine.

  {buffer-copy
     bS_Steuer
     to bttS_Steuer-PLine
     assign
       "bttS_Steuer-PLine.Firma = gcFirma"}

  if pACConnectionSvc:prpcLocalization = 'I':U then
  do:

    if    glISplitPaymentTaxKey = ?
      and bttS_Steuer-PLine.I_TaxType = {&pa_S_I_TaxTypeSplitPayment} then
      glISplitPaymentTaxKey     = yes.

    if    glIRegularTaxKey      = ?
      and bttS_Steuer-PLine.I_TaxType <> {&pa_S_I_TaxTypeSplitPayment} then
      glIRegularTaxKey          = yes.

    if    can-do('R,G':U, ttV_BelegKopf-P.Belegart)
      and glISplitPaymentTaxKey = yes
      and (glIRegularTaxKey
           or (    ttV_BelegKopf-P.S_Steuer_Obj <> ?
               and bttS_Steuer-PLine.I_TaxType <> {&pa_S_I_TaxTypeSplitPayment})) then

      adm.method.cls.DMCMessageSvc:prpoInstance:showError
        ('v_beli0008':U,
         string(ttV_BelegKopf-P.Kunde),
         string (ttV_BelegKopf-P.BelegNummer)).

  end. /* if pACConnectionSvc:prpcLocalization = 'I':U then */


  if not can-find(bttSBM_TaxRate-PLine
                    where bttSBM_TaxRate-PLine.SBM_TaxRate_Obj = bS_Steuer.SBM_TaxRate_Obj) then
  do:

    find bSBM_TaxRate
      where bSBM_TaxRate.SBM_TaxRate_Obj = bS_Steuer.SBM_TaxRate_Obj
      no-lock.

    create bttSBM_TaxRate-PLine.

    {buffer-copy
       bSBM_TaxRate
       to bttSBM_TaxRate-PLine}

    /* List & Label can not process ? in a unique index field, so we set this */
    /* date to the latest possible date (31.12.9999)                          */

    if bttSBM_TaxRate-PLine.valid_to = ? then

      bttSBM_TaxRate-PLine.valid_to = {&pa_DateMax}.

  end. /* if not can-find(bttSBM_TaxRate-PLine */

end.  /* S_Steuer_Obj > '':U  */

end procedure. /* fillDocumentLineTaxForLLPrint */


/* _UIB-CODE-BLOCK-END */
&ANALYZE-RESUME

&ENDIF


&IF DEFINED(EXCLUDE-fillDocumentOrdererForLLPrint) = 0 &THEN

&ANALYZE-SUSPEND _UIB-CODE-BLOCK _PROCEDURE fillDocumentOrdererForLLPrint Method-Library 
procedure fillDocumentOrdererForLLPrint :
/* Description ---------------------------------------------------------------*/
/*                                                                            */
/* fills the orderer temp-tables                                              */
/*                                                                            */
/* Notes ---------------------------------------------------------------------*/
/*                                                                            */
/*                                                                            */
/*                                                                            */
/* Parameters ----------------------------------------------------------------*/
/*                                                                            */
/* piCustomer       customer                                                  */
/*                                                                            */
/* Examples ------------------------------------------------------------------*/
/*                                                                            */
/*                                                                            */
/*                                                                            */
/*----------------------------------------------------------------------------*/

define input parameter piCustomer   like S_Kunde.Kunde    no-undo.

/* Variables -----------------------------------------------------------------*/
/*----------------------------------------------------------------------------*/

/* Buffers -------------------------------------------------------------------*/

define buffer bS_Kunde-Orderer        for S_Kunde.
define buffer bS_Verband-Orderer      for S_Verband.
define buffer bS_Konto                for S_Konto.
define buffer bSBM_SEPAMAndateID      for SBM_SEPAMAndateID.

/*----------------------------------------------------------------------------*/
/* Processing                                                                 */
/*----------------------------------------------------------------------------*/

if piCustomer <> ttV_BelegKopf-P.Kunde then
do:

  find bS_Kunde-Orderer
    where bS_Kunde-Orderer.Firma  = {firma/s_kunde.fir gcFirma}
      and bS_Kunde-Orderer.Kunde  = piCustomer
    no-lock no-error.

  if available bS_Kunde-Orderer then
  do:

    find bS_Konto
      where bS_Konto.Firma = {firma/skonto.fir gcFirma}
        and bS_Konto.Konto = piCustomer
      no-lock.

    find last bSBM_SEPAMandateID
      where bSBM_SEPAMandateID.S_Konto_Obj = bS_Konto.S_Konto_Obj
        and bSBM_SEPAMandateID.Valid_on   <= today
      no-lock no-error.

    {buffer-copy
       bS_Kunde-Orderer
       to ttS_Kunde-P1Orderer
       assign
         "ttS_Kunde-P1Orderer.Firma = gcFirma
          ttS_Kunde-P1Orderer.SEPAMandateID = (if available bSBM_SEPAMandateID then
                                                 bSBM_SEPAMandateID.SEPAMandateID
                                               else
                                                 '':U)"}

    ttS_Kunde-P1Orderer.inlaendische_SteuerNr = string(ttS_Kunde-P1Orderer.inlaendische_SteuerNr, 
                                                       SBCTaxMasterFilesSvc:prpoInstance:cFormatDomesticTaxIDForAcc(ttS_Kunde-P1Orderer.Kunde)).

    validate ttS_Kunde-P1Orderer.

    ttV_BelegKopf-P.Orderer_S_Kunde_Obj = bS_Kunde-Orderer.S_Kunde_Obj.

    find bS_Verband-Orderer
      where bS_Verband-Orderer.Firma  = {firma/s_kunde.fir gcFirma}
        and bS_Verband-Orderer.Kunde  = bS_Kunde-Orderer.Verband
      no-lock no-error.

    if available bS_Verband-Orderer then
    do:

      {buffer-copy
         bS_Verband-Orderer
         to ttS_Verband-POrderer
         assign
           "ttS_Verband-POrderer.Firma = gcFirma"}

      validate ttS_Verband-POrderer.

      ttV_BelegKopf-P.Orderer_S_Verband_Obj = bS_Verband-Orderer.S_Verband_Obj.

    end.  /* if available bS_Verband-Orderer */

  end.  /* if available bS_Kunde-Orderer */

end.  /* if piCustomer <> ttV_BelegKopf-P.Kunde */

end procedure. /* fillDocumentOrdererForLLPrint */


/* _UIB-CODE-BLOCK-END */
&ANALYZE-RESUME

&ENDIF

&IF DEFINED(EXCLUDE-fillDocumentSerialNoForLLPrint) = 0 &THEN

&ANALYZE-SUSPEND _UIB-CODE-BLOCK _PROCEDURE fillDocumentSerialNoForLLPrint Method-Library 
procedure fillDocumentSerialNoForLLPrint :
/* Description ---------------------------------------------------------------*/
/*                                                                            */
/* fills the serial number informations for document line                     */
/*                                                                            */
/* Notes ---------------------------------------------------------------------*/
/*                                                                            */
/*                                                                            */
/*                                                                            */
/* Parameters ----------------------------------------------------------------*/
/*                                                                            */
/* <none>                                                                     */
/*                                                                            */
/* Examples ------------------------------------------------------------------*/
/*                                                                            */
/*                                                                            */
/*                                                                            */
/*----------------------------------------------------------------------------*/

/* Variables -----------------------------------------------------------------*/
/*----------------------------------------------------------------------------*/

/* Buffers -------------------------------------------------------------------*/

/*----------------------------------------------------------------------------*/
/* Processing                                                                 */
/*----------------------------------------------------------------------------*/

&IF LOOKUP("MS","{&PA-MODULE}") > 0 &THEN

  mawi.serie.cls.MSCSerialNoSvc:prpoInstance:GetSNForDocument
    (             ttV_BelegPos-P.V_BelegPos_Obj,
     input-output table ttMS_SNR-P1 by-reference).

  ttV_BelegPos-P.SerialNumber = mawi.serie.cls.MSCSerialNoSvc:prpoInstance:clCreateSerialNoAsText
                                  (ttV_BelegPos-P.V_BelegPos_Obj,
                                   (if    ttV_BelegPos-P.Belegart = 'U':U
                                      and glPositions             = yes
                                      and ttV_BelegKopf-P.offen   = yes then
                                      no
                                    else
                                      yes)).

&ENDIF  /* MS */

end procedure. /* fillDocumentSerialNoForLLPrint */


/* _UIB-CODE-BLOCK-END */
&ANALYZE-RESUME

&ENDIF


&IF DEFINED(EXCLUDE-fillDocumentSurchargesForLLPrint) = 0 &THEN

&ANALYZE-SUSPEND _UIB-CODE-BLOCK _PROCEDURE fillDocumentSurchargesForLLPrint Method-Library 
procedure fillDocumentSurchargesForLLPrint :
/* Description ---------------------------------------------------------------*/
/*                                                                            */
/* fills the surcharges temp-table                                            */
/*                                                                            */
/* Notes ---------------------------------------------------------------------*/
/*                                                                            */
/* This procedure does only encapsulate code for better readability of        */
/* fillDataset procedure. It can only be used in the context of this DAO !    */
/* run super() must have been executed and a global ttV_BelegKopf-P  and      */
/* ttV_BelegPos-P must be available!                                          */
/*                                                                            */
/* Parameters ----------------------------------------------------------------*/
/*                                                                            */
/* <none>                                                                     */
/*                                                                            */
/* Examples ------------------------------------------------------------------*/
/*                                                                            */
/*                                                                            */
/*                                                                            */
/*----------------------------------------------------------------------------*/

/* Variables -----------------------------------------------------------------*/
/*----------------------------------------------------------------------------*/

define variable iCount     as  integer     no-undo.
define variable dEURFactor as  decimal     no-undo initial ?.
define variable cACMKey    as  character   no-undo.

/* Buffers -------------------------------------------------------------------*/

define buffer bttVB_Surcharges-P    for temp-table ttVB_Surcharges-P.

/*----------------------------------------------------------------------------*/
/* Processing                                                                 */
/*----------------------------------------------------------------------------*/

/* If Eurofaktor field is > 0  and the documents domestic currency is not */
/* EUR, the EUR_* fields are filled ... this was important during the     */
/* years of transition to the Euro. It might be important again if        */
/* further countried join the Euro or countries having the Euro now,      */
/* abandom it in the future!                                              */

if    ttS_Waehrung-P1.Eurofaktor > 0
  and not ttS_Waehrung-P1.ISO_KurzBez = 'EUR':U then

  dEURFactor = ttS_Waehrung-P1.Eurofaktor.

do iCount = 1 to 5:

  create bttVB_Surcharges-P.

  assign    
    bttVB_Surcharges-P.Owning_Obj     = ttV_BelegKopf-P.V_BelegKopf_Obj
    bttVB_Surcharges-P.SeqNo          = iCount
    bttVB_Surcharges-P.SurchargeValue = (if iCount < 5 then
                                           ttV_BelegKopf-P.Zuschlag[iCount]
                                         else
                                           round(((ttV_BelegSumKopf-Calc.Belegsumme[11] - ttV_BelegSumKopf-Calc.Gesamt_Anzahlungen[11])
                                                  * ttV_BelegKopf-P.proz_Zuschlag / 100),
                                                 ttV_BelegKopf-P.WaehrungNK))

    /* Get the surcharge description using the current language from ACM.     */    
    /* If the ACM is missing (for whatever reason), fall back to the text of  */
    /* V_BelegKopf.                                                           */

    cACMKey                           = 'VB_NameSurchargesDocHeader':U + string(iCount)                                            
    bttVB_Surcharges-P.SurchargeDesc  = (if adm.config.cls.DCCAppConfigSvc:prpoInstance:lParameterIsDefined(cACMKey) = yes then
                                           adm.config.cls.DCCAppConfigSvc:prpoInstance:cParameterValueLng
                                             (cACMKey,
                                              gcContentLanguage)
                                         else
                                           ttV_BelegKopf-P.ZuschlBez[iCount]
                                         )
    .

  if dEURFactor <> ? then

    bttVB_Surcharges-P.SurchargeEUR = bttVB_Surcharges-P.SurchargeValue / dEURFactor.

  validate bttVB_Surcharges-P.

end.  /* do iCount = 1 to 5 */

end procedure. /* fillDocumentSurchargesForLLPrint */


/* _UIB-CODE-BLOCK-END */
&ANALYZE-RESUME

&ENDIF


&IF DEFINED(EXCLUDE-fillDocumentTaxForLLPrint) = 0 &THEN

&ANALYZE-SUSPEND _UIB-CODE-BLOCK _PROCEDURE fillDocumentTaxForLLPrint Method-Library 
procedure fillDocumentTaxForLLPrint :
/* Description ---------------------------------------------------------------*/
/*                                                                            */
/* fills the temp-table ttS_Steuer-P                                          */
/*                                                                            */
/*----------------------------------------------------------------------------*/

define buffer bS_Steuer        for S_Steuer.
define buffer bSBM_TaxRate     for SBM_TaxRate.
define buffer bttS_Steuer-P    for temp-table ttS_Steuer-P.
define buffer bttSBM_TaxRate-P for temp-table ttSBM_TaxRate-P.

/*----------------------------------------------------------------------------*/
/* Processing                                                                 */
/*----------------------------------------------------------------------------*/

/* If automatic tax determination is active, ttV_BelegKopf.S_Steuer_Obj is    */
/* empty. SteuerSatzZuschl is defined via positions (Hauptleistung).          */


if ttV_BelegKopf-P.S_Steuer_Obj = '':U then
  ttV_BelegKopf-P.S_Steuer_Obj  = vert.base.cls.VBCSalesTaxSvc:prpoInstance:cDocumentMainTaxCode
                                    (ttV_BelegKopf-P.Belegart,
                                     ttV_BelegKopf-P.ReferenzNr).

if    ttV_BelegKopf-P.S_Steuer_Obj                    > '':U
  and not can-find(bttS_Steuer-P
                     where bttS_Steuer-P.S_Steuer_Obj = ttV_BelegKopf-P.S_Steuer_Obj) then
do:

  find bS_Steuer
    where bS_Steuer.S_Steuer_Obj  = ttV_BelegKopf-P.S_Steuer_Obj
    no-lock.

  create bttS_Steuer-P.

  {buffer-copy
     bS_Steuer
     to bttS_Steuer-P
     assign
       "bttS_Steuer-P.Firma = gcFirma"}

  if not can-find(bttSBM_TaxRate-P
                    where bttSBM_TaxRate-P.SBM_TaxRate_Obj = bS_Steuer.SBM_TaxRate_Obj) then
  do:

    find bSBM_TaxRate
      where bSBM_TaxRate.SBM_TaxRate_Obj = bS_Steuer.SBM_TaxRate_Obj
      no-lock.

    create bttSBM_TaxRate-P.

    {buffer-copy
       bSBM_TaxRate
       to bttSBM_TaxRate-P}

    /* List & Label can not process ? in a unique index field, so we set this */
    /* date to the latest possible date (31.12.9999)                          */

    if bttSBM_TaxRate-P.valid_to = ? then

      bttSBM_TaxRate-P.valid_to = {&pa_DateMax}.

  end. /* if not can-find(bttSBM_TaxRate-P */

end.

end procedure. /* fillDocumentTaxForLLPrint */


/* _UIB-CODE-BLOCK-END */
&ANALYZE-RESUME

&ENDIF


&IF DEFINED(EXCLUDE-fillDocumentTaxrateSumsForLLPrint) = 0 &THEN

&ANALYZE-SUSPEND _UIB-CODE-BLOCK _PROCEDURE fillDocumentTaxrateSumsForLLPrint Method-Library 
procedure fillDocumentTaxrateSumsForLLPrint :
/* Description ---------------------------------------------------------------*/
/*                                                                            */
/* Calculates the taxrate dependant document sums annd returns it in a format */
/* usable by List&Label print.                                                */
/* TT ttV_BelegSumKopf-Calc must be filled before calling this procedure!     */
/*                                                                            */
/* Notes ---------------------------------------------------------------------*/
/*                                                                            */
/* This procedure does only encapsulate code for better readability of        */
/* fillDataset procedure. It can only be used in the context of this DAO      */
/* run super() has been execute an a global ttV_BelegKopf-P Buffer is         */
/* available... so passing of paramters was forgone deliberatly.              */
/*                                                                            */
/*----------------------------------------------------------------------------*/

define variable iTaxRates        as   integer               no-undo.
define variable iTaxRatesCounter as   integer               no-undo.
define variable lVariousTaxRates as   logical               no-undo.
define variable dPGesamtsumme    as   decimal               no-undo.
define variable dEurofaktor      like S_Waehrung.Eurofaktor no-undo.
define variable i                as   integer               no-undo.
define variable dNetAmountOC     as   decimal               no-undo. 
define variable dTaxAmountOC     as   decimal               no-undo. 
define variable dNetAmountOCCIT  as   decimal               no-undo. 
define variable dTaxAmountOCCIT  as   decimal               no-undo. 

/* Buffers -------------------------------------------------------------------*/

define buffer bttV_BelegPos-P   for temp-table ttV_BelegPos-P.

define buffer bV_H_TaxEval      for V_H_TaxEval.

define buffer bS_Steuer-SGST    for S_Steuer.
define buffer bSBM_TaxRate-SGST for SBM_TaxRate.
define buffer bS_Steuer-CGST    for S_Steuer.
define buffer bSBM_TaxRate-CGST for SBM_TaxRate.
define buffer bS_Steuer-TaxFree for S_Steuer.
define buffer bS_Steuer          for S_Steuer.
/*----------------------------------------------------------------------------*/
/* Processing                                                                 */
/*----------------------------------------------------------------------------*/

/* Check if different tax rates are available in the current document. If   */
/* only one single tax rate (e.g. zero) is available, then the print must   */
/* be done only one time.                                                   */

CheckTaxRates:
do iTaxRatesCounter = 2 to extent(ttV_BelegSumKopf-Calc.Gesamt_Steuersatz):

  if ttV_BelegSumKopf-Calc.Gesamt_Steuersatz[1] <> ttV_BelegSumKopf-Calc.Gesamt_Steuersatz[iTaxRatesCounter] then
  do:

    lVariousTaxRates = yes.
    leave CheckTaxRates.

  end.

end. /* CheckTaxRates */

/* translate the TT_V_BelegSumme record with its extents to the non           */
/* extent records of ttV_BelegTaxrateSums-P. Primary key and Main sort case   */
/* is Gesamt_Steuersatz!                                                      */

do iTaxRates = 1 to extent(ttV_BelegSumKopf-Calc.Gesamt_Steuersatz):

  /* If we are in first loop we can add, this slot must always be in use.          */
  /* The 'not can-find(ttV_BelegTaxrateSums-P...' must be done from second loop,   */
  /* because several slots can be filled with TaxRate 0 but only the first is used.*/
  /* If we found a slot that was not added we must search if any position or the   */
  /* head surcharges use this slot.                                                */

  /* If only tax rates with value zero exists in the current document, then   */
  /* the print of the sum section must be ensured.                            */
  /* If a text line is the only line with tax rate value zero, then do not    */
  /* print this value in the sum section.                                     */

  if (    (   lVariousTaxRates = no
           or (   can-find(first ttV_BelegSumPos-Calc
                             where ttV_BelegSumPos-Calc.Steuersatz = ttV_BelegSumKopf-Calc.Gesamt_Steuersatz[iTaxRates])
               or ttV_BelegKopf-P.SteuerSatzZuschl                 = ttV_BelegSumKopf-Calc.Gesamt_Steuersatz[iTaxRates]))
      /* there is not yet a record with the unique pk index fields */
      and not can-find(first ttV_BelegTaxrateSums-P
                         where ttV_BelegTaxrateSums-P.Owning_Obj    = ttV_BelegKopf-P.V_BelegKopf_Obj
                           and ttV_BelegTaxrateSums-P.Steuersatz    = ttV_BelegSumKopf-Calc.Gesamt_Steuersatz[iTaxRates]
                                 and ttV_BelegTaxrateSums-P.P_TaxKey      = (if pACConnectionSvc:prpcLocalization = 'P':U then
                                                                         ttV_BelegSumKopf-Calc.I_P_S_Steuer_Obj[iTaxRates]
                                                                       else
                                                                         '':U)
                           and ttV_BelegTaxrateSums-P.TaxArrayID    = 0)
      /* there is at least one line with this tax rate */                           
      and can-find(first bttV_BelegPos-P
                     where bttV_BelegPos-P.Firma      = {firma/vbelegko.fir gcFirma}
                       and bttV_BelegPos-P.BelegArt   = ttV_BelegKopf-P.BelegArt
                       and bttV_BelegPos-P.ReferenzNr = ttV_BelegKopf-P.ReferenzNr
                       and bttV_BelegPos-P.Satzart    = 'A':U
                       and bttV_BelegPos-P.Steuersatz = ttV_BelegSumKopf-Calc.Gesamt_Steuersatz[iTaxRates])) then
  do:

    create ttV_BelegTaxrateSums-P.

    /* first fill all fields in domestic currency */

    assign
      /* main index fields */
      ttV_BelegTaxrateSums-P.Owning_Obj        = ttV_BelegKopf-P.V_BelegKopf_Obj
      ttV_BelegTaxrateSums-P.Steuersatz        = ttV_BelegSumKopf-Calc.Gesamt_Steuersatz[iTaxRates]
      ttV_BelegTaxrateSums-P.P_TaxKey          = (if pACConnectionSvc:prpcLocalization = 'P':U then
                                                    ttV_BelegSumKopf-Calc.I_P_S_Steuer_Obj[iTaxRates]
                                                  else
                                                    '':U)
      ttV_BelegTaxrateSums-P.TaxArrayID        = 0
      /* others */    
      ttV_BelegTaxrateSums-P.Anzahlungen       = ttV_BelegSumKopf-Calc.Gesamt_Anzahlungen[iTaxRates]
      ttV_BelegTaxrateSums-P.AnzahlungenSteuer = ttV_BelegSumKopf-Calc.Gesamt_AnzahlungenSteuer[iTaxRates]
      ttV_BelegTaxrateSums-P.Warenwert         = ttV_BelegSumKopf-Calc.Gesamt_Belegsumme[iTaxRates]
      ttV_BelegTaxrateSums-P.Warenwert_ohne_AA = ttV_BelegSumKopf-Calc.Gesamt_Belegsumme[iTaxRates]
                                                 - ttV_BelegSumKopf-Calc.Gesamt_Anzahlungen[iTaxRates]
      .

    if ttV_BelegSumKopf-Calc.Gesamt_Steuersatz[iTaxRates] = 0 then
    do:

      /* Find the first position with tax rate 0. Search for the S_Steuer
         entry of that tax rate to determine whether reverse charge is yes
         or no. This is sufficient for the whole document since we can only 
         have either reverse charge yes or no at the same time.             */

      find first ttV_BelegPos-P
        where ttV_BelegPos-P.Firma      = ttV_BelegKopf-P.Firma
          and ttV_BelegPos-P.Belegart   = ttV_BelegKopf-P.Belegart
          and ttV_BelegPos-P.ReferenzNr = ttV_BelegKopf-P.ReferenzNr
          and ttV_BelegPos-P.SteuerSatz = 0
        no-lock no-error.

      if available ttV_BelegPos-P then
        find bS_Steuer
          where bS_Steuer.S_Steuer_Obj = ttV_BelegPos-P.S_Steuer_Obj
          no-lock no-error.

      if available bS_Steuer then
        ttV_BelegTaxrateSums-P.ReverseCharge =    bS_Steuer.ReverseCharge
                                               or bS_Steuer.P_ReverseCharge.

    end. /* ttV_BelegSumKopf-Calc.Gesamt_Steuersatz[iTaxRates] = 0 */

    if pACConnectionSvc:prpcLocalization = 'H':U then
    do:

      find bS_Steuer-TaxFree
        where bS_Steuer-TaxFree.Firma                = {firma/ssteuer.fir gcFirma}
          and bS_Steuer-TaxFree.SBM_TaxTerritory_Obj = ttV_BelegKopf-P.Tax_SBM_TaxTerritory_Obj[{&pa_SB_TaxTerritoryExt_Country}]
          and bS_Steuer-TaxFree.Steuer               = ttV_BelegSumKopf-Calc.H_TaxCode[iTaxRates]
          and bS_Steuer-TaxFree.H_TaxFreeReason      > '':U
        no-lock no-error.

      if available bS_Steuer-TaxFree then
        ttV_BelegTaxrateSums-P.H_TaxFreeReason = adm.config.cls.DCCAppConfigSvc:prpoInstance:cParamValByRefParamValLng
                                                   ('VB_H_TaxFreeReasonCollection_desc':U, 
                                                    bS_Steuer-TaxFree.H_TaxFreeReason, 
                                                    gcContentLanguage).
    end.  

    if pACConnectionSvc:prpcLocalization = 'I':U then

      ttV_BelegTaxrateSums-P.I_SplitPaymentTax = ttV_BelegSumKopf-Calc.I_SplitPaymentTax.

    if available ttV_BelegSumKopf-VUR then

      ttV_BelegTaxrateSums-P.Warenwert_Vertrag = ttV_BelegSumKopf-VUR.Gesamt_Belegsumme[iTaxRates].

    if pACConnectionSvc:prpcLocalization = 'USA':U then
    do:

      ttV_BelegTaxrateSums-P.Steuer = round(ttV_BelegKopf-P.USTax_TaxAmount[iTaxRates] + vert.base.cls.VBCSalesTaxSvc:prpoInstance:dUSTax_SurchargeTaxAmount(buffer gbV_BelegKopf, ttV_BelegSumKopf-Calc.Gesamt_Belegsumme[11]), 
                                            ttV_BelegKopf-P.WaehrungNK).

      if available ttV_BelegSumKopf-VUR then

        ttV_BelegTaxrateSums-P.Steuer_Vertrag  = round(ttV_BelegSumKopf-VUR.Gesamtsteuer,
                                                       ttV_BelegKopf-P.WaehrungNK).

    end. /* if pACConnectionSvc:prpcLocalization = 'USA':U */

    else
    do:

      &IF "{&pa_V_MwStSchlussrechnung}":U <> "1":U &THEN

      if ttV_BelegKopf-P.Brutto = no then   /* von Nettobetrag */
      do:

        ttV_BelegTaxrateSums-P.Steuer  = round((ttV_BelegSumKopf-Calc.Gesamt_Belegsumme[iTaxRates]
                                               + (if iTaxRates = ttV_BelegKopf-P.Zuschlag_Extent then
                                                    ttV_BelegSumKopf-Calc.Gesamtzuschlag
                                                  else
                                                    0))
                                               * ttV_BelegSumKopf-Calc.Gesamt_Steuersatz[iTaxRates] / 100,
                                               ttV_BelegKopf-P.WaehrungNK).
        if available ttV_BelegSumKopf-VUR then

          ttV_BelegTaxrateSums-P.Steuer_Vertrag  = round((ttV_BelegSumKopf-VUR.Gesamt_Belegsumme[iTaxRates]
                                                          + (if iTaxRates = ttV_BelegKopf-P.Zuschlag_Extent then
                                                               ttV_BelegSumKopf-VUR.Gesamtzuschlag
                                                             else
                                                               0))
                                                          * ttV_BelegSumKopf-VUR.Gesamt_Steuersatz[iTaxRates] / 100,
                                                          ttV_BelegKopf-P.WaehrungNK).

      end.
      else                              /* aus Bruttobetrag */
      do:

        ttV_BelegTaxrateSums-P.Steuer = round((ttV_BelegSumKopf-Calc.Gesamt_Belegsumme[iTaxRates]
                                               + (if iTaxRates = ttV_BelegKopf-P.Zuschlag_Extent then
                                                    ttV_BelegSumKopf-Calc.Gesamtzuschlag
                                                  else
                                                    0))
                                               / (1 + ttV_BelegSumKopf-Calc.Gesamt_Steuersatz[iTaxRates] / 100)
                                               * ttV_BelegSumKopf-Calc.Gesamt_Steuersatz[iTaxRates] / 100,
                                               ttV_BelegKopf-P.WaehrungNK).

        if available ttV_BelegSumKopf-VUR then

          ttV_BelegTaxrateSums-P.Steuer_Vertrag  = round((ttV_BelegSumKopf-VUR.Gesamt_Belegsumme[iTaxRates]
                                                          + (if iTaxRates = ttV_BelegKopf-P.Zuschlag_Extent then
                                                               ttV_BelegSumKopf-VUR.Gesamtzuschlag
                                                             else
                                                               0))
                                                          / (1 + ttV_BelegSumKopf-VUR.Gesamt_Steuersatz[iTaxRates] / 100)
                                                          * ttV_BelegSumKopf-VUR.Gesamt_Steuersatz[iTaxRates] / 100,
                                                          ttV_BelegKopf-P.WaehrungNK).

      end.

      &ELSE

      if ttV_BelegKopf-P.Brutto = no then   /* von Nettobetrag */
      do:

        ttV_BelegTaxrateSums-P.Steuer = round((ttV_BelegSumKopf-Calc.Gesamt_Belegsumme[iTaxRates]
                                               - ttV_BelegSumKopf-Calc.Gesamt_Anzahlungen[iTaxRates]
                                               + (if iTaxRates = ttV_BelegKopf-P.Zuschlag_Extent then
                                                    ttV_BelegSumKopf-Calc.Gesamtzuschlag
                                                  else
                                                    0))
                                               * ttV_BelegSumKopf-Calc.Gesamt_Steuersatz[iTaxRates] / 100,
                                               ttV_BelegKopf-P.WaehrungNK)

                                        + ttV_BelegSumKopf-Calc.Gesamt_AnzahlungenSteuer[iTaxRates].

        if available ttV_BelegSumKopf-VUR then

          ttV_BelegTaxrateSums-P.Steuer_Vertrag  = round((ttV_BelegSumKopf-VUR.Gesamt_Belegsumme[iTaxRates]
                                                         - ttV_BelegSumKopf-VUR.Gesamt_Anzahlungen[iTaxRates]
                                                         + (if iTaxRates = ttV_BelegKopf-P.Zuschlag_Extent then
                                                              ttV_BelegSumKopf-VUR.Gesamtzuschlag
                                                            else
                                                              0))
                                                         * ttV_BelegSumKopf-VUR.Gesamt_Steuersatz[iTaxRates] / 100,
                                                         ttV_BelegKopf-P.WaehrungNK)

                                                   + ttV_BelegSumKopf-VUR.Gesamt_AnzahlungenSteuer[iTaxRates].

      end.
      else                              /* aus Bruttobetrag */
      do:

        ttV_BelegTaxrateSums-P.Steuer = round((ttV_BelegSumKopf-Calc.Gesamt_Belegsumme[iTaxRates]
                                               - ttV_BelegSumKopf-Calc.Gesamt_Anzahlungen[iTaxRates]
                                               + (if iTaxRates = ttV_BelegKopf-P.Zuschlag_Extent then
                                                    ttV_BelegSumKopf-Calc.Gesamtzuschlag
                                                  else
                                                    0))
                                               / (1 + ttV_BelegSumKopf-Calc.Gesamt_Steuersatz[iTaxRates] / 100)
                                               * ttV_BelegSumKopf-Calc.Gesamt_Steuersatz[iTaxRates] / 100,
                                               ttV_BelegKopf-P.WaehrungNK)
                                        + ttV_BelegSumKopf-Calc.Gesamt_AnzahlungenSteuer[iTaxRates].

        if available ttV_BelegSumKopf-VUR then

          ttV_BelegTaxrateSums-P.Steuer_Vertrag  = round((ttV_BelegSumKopf-VUR.Gesamt_Belegsumme[iTaxRates]
                                                          - ttV_BelegSumKopf-VUR.Gesamt_Anzahlungen[iTaxRates]
                                                          + (if iTaxRates = ttV_BelegKopf-P.Zuschlag_Extent then
                                                               ttV_BelegSumKopf-VUR.Gesamtzuschlag
                                                             else
                                                               0))
                                                          / (1 + ttV_BelegSumKopf-VUR.Gesamt_Steuersatz[iTaxRates] / 100)
                                                          * ttV_BelegSumKopf-VUR.Gesamt_Steuersatz[iTaxRates] / 100,
                                                          ttV_BelegKopf-P.WaehrungNK)
                                                   + ttV_BelegSumKopf-VUR.Gesamt_AnzahlungenSteuer[iTaxRates].

      end. /* else */

        &IF LOOKUP("U_CA":U,"{&PA-OPTIONEN}":U) > 0 &THEN

          if ttV_BelegKopf-P.ZahlungsArt = {&uCA_ZahlArtGutschriftsverfahren}
            and can-do('R,G':U,ttV_BelegKopf-P.BelegArt)
            and ttV_BelegTaxrateSums-P.Steuer         <> 0
            and ttV_BelegKopf-P.uGSASteuerKorr        <> 0 then
          do:

            ttV_BelegTaxrateSums-P.Steuer = ttV_BelegTaxrateSums-P.Steuer + ttV_BelegKopf-P.uGSASteuerKorr * ttV_BelegKopf-P.Kurs.

          end.

        &ENDIF

      &ENDIF

    end. /* else (if pACConnectionSvc:prpcLocalization = 'USA':U) */

    assign
      ttV_BelegTaxrateSums-P.Summe_excl =  ttV_BelegSumKopf-Calc.Gesamt_Belegsumme[iTaxRates]
                                            + (if iTaxRates = ttV_BelegKopf-P.Zuschlag_Extent then
                                                 ttV_BelegSumKopf-Calc.Gesamtzuschlag
                                               else
                                                 0)
                                            - (if ttV_BelegKopf-P.Brutto = no then /* Nettobeleg oder Bruttobeleg */
                                                 0
                                               else
                                                 ttV_BelegTaxrateSums-P.Steuer)

      ttV_BelegTaxrateSums-P.Summe_incl = ttV_BelegSumKopf-Calc.Gesamt_Belegsumme[iTaxRates]
                                            + (if iTaxRates = ttV_BelegKopf-P.Zuschlag_Extent then
                                                 ttV_BelegSumKopf-Calc.Gesamtzuschlag
                                               else
                                                 0)
                                            + (if ttV_BelegKopf-P.Brutto = no then /* Nettobeleg oder Bruttobeleg */
                                                 ttV_BelegTaxrateSums-P.Steuer
                                               else
                                                 0)
      .


    /* All surcharges have the same taxrate  - the surcharge fields are only
       filled for the taxrate they correspond with... (Zuschlag_Extent)       */
    if iTaxRates = ttV_BelegKopf-P.Zuschlag_Extent then
    do:

      ttV_BelegTaxrateSums-P.Zuschlaege     =  ttV_BelegSumKopf-Calc.Gesamtzuschlag.

      if glPositions then
        ttV_BelegTaxrateSums-P.Zuschlaege_offen = ttV_BelegTaxrateSums-P.Zuschlaege
                                                  - ttV_BelegKopf-P.Zuschlag_ueber[1]
                                                  - ttV_BelegKopf-P.Zuschlag_ueber[2]
                                                  - ttV_BelegKopf-P.Zuschlag_ueber[3]
                                                  - ttV_BelegKopf-P.Zuschlag_ueber[4].

    end.

    /* The *_Vertrag fields are only calculated if the document is VUR */

    if available ttV_BelegSumKopf-VUR then
    do:
      assign

        ttV_BelegTaxrateSums-P.Summe_excl_Vertrag      = ttV_BelegSumKopf-VUR.Gesamt_Belegsumme[iTaxRates]
                                                         + (if iTaxRates = ttV_BelegKopf-P.Zuschlag_Extent then
                                                              ttV_BelegSumKopf-VUR.Gesamtzuschlag
                                                            else
                                                              0)
                                                         - (if ttV_BelegKopf-P.Brutto = no then /* Nettobeleg oder Bruttobeleg */
                                                              0
                                                            else
                                                              ttV_BelegTaxrateSums-P.Steuer_Vertrag)


        ttV_BelegTaxrateSums-P.Summe_incl_Vertrag      = ttV_BelegSumKopf-VUR.Gesamt_Belegsumme[iTaxRates]
                                                         + (if iTaxRates = ttV_BelegKopf-P.Zuschlag_Extent then
                                                              ttV_BelegSumKopf-VUR.Gesamtzuschlag
                                                            else
                                                              0)
                                                         + (if ttV_BelegKopf-P.Brutto = no then /* Nettobeleg oder Bruttobeleg */
                                                              ttV_BelegTaxrateSums-P.Steuer_Vertrag
                                                            else
                                                              0)
        .
    end.

    /* If Eurofaktor field is > 0  and the documents domestic currency is not */
    /* EUR, the EUR_* fields are filled ... this was important during the     */
    /* years of transition to the Euro. It might be important again if        */
    /* further countries join the Euro or countries having the Euro now,      */
    /* abandom it in the future!                                              */

    if ttS_Waehrung-P1.Eurofaktor > 0 then
      assign
        ttV_BelegTaxrateSums-P.Eur_Anzahlungen          = ttV_BelegTaxrateSums-P.Anzahlungen / ttS_Waehrung-P1.Eurofaktor
        ttV_BelegTaxrateSums-P.Eur_AnzahlungenSteuer    = ttV_BelegTaxrateSums-P.AnzahlungenSteuer / ttS_Waehrung-P1.Eurofaktor
        ttV_BelegTaxrateSums-P.Eur_Summe_excl           = ttV_BelegTaxrateSums-P.Summe_excl / ttS_Waehrung-P1.Eurofaktor
        ttV_BelegTaxrateSums-P.Eur_Summe_excl_Vertrag   = ttV_BelegTaxrateSums-P.Summe_excl_Vertrag  / ttS_Waehrung-P1.Eurofaktor
        ttV_BelegTaxrateSums-P.Eur_Summe_incl           = ttV_BelegTaxrateSums-P.Summe_incl / ttS_Waehrung-P1.Eurofaktor
        ttV_BelegTaxrateSums-P.Eur_Summe_incl_Vertrag   = ttV_BelegTaxrateSums-P.Summe_incl_Vertrag  / ttS_Waehrung-P1.Eurofaktor
        ttV_BelegTaxrateSums-P.Eur_Steuer               = ttV_BelegTaxrateSums-P.Steuer  / ttS_Waehrung-P1.Eurofaktor
        ttV_BelegTaxrateSums-P.Eur_Steuer_Vertrag       = ttV_BelegTaxrateSums-P.Steuer_Vertrag  / ttS_Waehrung-P1.Eurofaktor
        ttV_BelegTaxrateSums-P.Eur_Warenwert            = ttV_BelegTaxrateSums-P.Warenwert / ttS_Waehrung-P1.Eurofaktor
        ttV_BelegTaxrateSums-P.Eur_Warenwert_Vertrag    = ttV_BelegTaxrateSums-P.Warenwert_Vertrag / ttS_Waehrung-P1.Eurofaktor
        ttV_BelegTaxrateSums-P.Eur_Warenwert_ohne_AA    = ttV_BelegTaxrateSums-P.Warenwert_ohne_AA / ttS_Waehrung-P1.Eurofaktor
        ttV_BelegTaxrateSums-P.Eur_Zuschlaege           =  ttV_BelegTaxrateSums-P.Zuschlaege / ttS_Waehrung-P1.Eurofaktor
      .

    /* The evaluated tax and tax base will be printed only if the national    */
    /* currency is not equal to the document currency.                        */

    if     pACConnectionSvc:prpcLocalization = 'H':U
      and {fn pa_iHHUFCurrency} <> ttV_BelegKopf-P.Waehrung then


      for each bV_H_TaxEval
        fields (TaxEval TaxBaseEval)
        where bV_H_TaxEval.Firma        = ttV_BelegKopf-P.Firma
          and bV_H_TaxEval.Belegart     = ttV_BelegKopf-P.Belegart
          and bV_H_TaxEval.Referenznr   = ttV_BelegKopf-P.Referenznr
          and can-find(S_Steuer
                       where S_Steuer.S_Steuer_Obj = bV_H_TaxEval.S_Steuer_Obj
                         and can-find (SBM_TaxRate
                                       where SBM_TaxRate.SBM_TaxRate_Obj = S_Steuer.SBM_TaxRate_Obj
                                         and SBM_TaxRate.TaxRate         = ttV_BelegSumKopf-Calc.Gesamt_Steuersatz[iTaxRates]))
        no-lock
        on error undo, throw:

        assign
          ttV_BelegTaxrateSums-P.H_TaxAmount_EW = ttV_BelegTaxrateSums-P.H_TaxAmount_EW + bV_H_TaxEval.TaxEval
          ttV_BelegTaxrateSums-P.H_NetAmount_EW = ttV_BelegTaxrateSums-P.H_NetAmount_EW + bV_H_TaxEval.TaxBaseEval
          .

      end. /* for each bV_H_TaxEval */

    if pACConnectionSvc:prpcLocalization = 'IN':U then
    do:

      /* C_IN_AmountInWords, C_IN_TaxAmountInWords */

      assign
        ttV_BelegTaxrateSums-P.C_IN_AmountInWords    = string(SBCLakhsCurrencySvc:prpoInstance:cAmountInWords(  ttV_BelegSumKopf-Calc.Gesamt_Belegsumme[11]
                                                                                                              + ttV_BelegSumKopf-Calc.Gesamtzuschlag
                                                                                                              + (if ttV_BelegKopf-P.Brutto = no then
                                                                                                                   ttV_BelegSumKopf-Calc.Gesamtsteuer
                                                                                                                 else
                                                                                                                   0),
                                                                                                              ttV_BelegKopf-P.Waehrung))
        ttV_BelegTaxrateSums-P.C_IN_TaxAmountInWords = string(SBCLakhsCurrencySvc:prpoInstance:cAmountInWords(ttV_BelegTaxrateSums-P.Steuer,
                                                                                                              ttV_BelegKopf-P.Waehrung))
        .

      if    glDomesticIndiaIntraState = yes
        and not (ttV_BelegTaxrateSums-P.Steuer * ttV_BelegSumKopf-Calc.Gesamt_Steuersatz[iTaxRates] = 0) then
      do:

        find bS_Steuer-SGST
          where bS_Steuer-SGST.S_Steuer_Obj = ttV_BelegSumKopf-Calc.NS_Steuer_Obj[iTaxRates]
          no-lock no-error.

        /* cIN_TaxCGST */

        if    available bS_Steuer-SGST 
          and bS_Steuer-SGST.AddOn_S_Steuer_Obj > '':U then
        do:

          find bSBM_TaxRate-SGST
            where bSBM_TaxRate-SGST.SBM_TaxRate_Obj = bS_Steuer-SGST.SBM_TaxRate_Obj
            no-lock no-error.             

          if available bSBM_TaxRate-SGST then                        

            /* to avoid rounding differences calculate CGST tax using the difference between sum tax rate - SGST tax rate */     

            ttV_BelegTaxrateSums-P.cIN_TaxCGST = string(  round((ttV_BelegTaxrateSums-P.Steuer * 100 / ttV_BelegSumKopf-Calc.Gesamt_Steuersatz[iTaxRates] 
                                                              * SBCTaxMasterFilesSvc:prpoInstance:dTaxRateOfTaxCodeObj(ttV_BelegSumKopf-Calc.NS_Steuer_Obj[iTaxRates]) / 100),
                                                              ttV_BelegKopf-P.WaehrungNK) 
                                                     - round((ttV_BelegTaxrateSums-P.Steuer * 100 / ttV_BelegSumKopf-Calc.Gesamt_Steuersatz[iTaxRates]  
                                                              * bSBM_TaxRate-SGST.TaxRate / 100),
                                                             ttV_BelegKopf-P.WaehrungNK)).

        end. /* available bS_Steuer-SGST */

        /* cIN_TaxSGST */

        if available bS_Steuer-SGST then
        do:

          find bSBM_TaxRate-SGST
            where bSBM_TaxRate-SGST.SBM_TaxRate_Obj = bS_Steuer-SGST.SBM_TaxRate_Obj
            no-lock no-error.                            

          /* note: VEinzelsteuer is already rounded, this might lead to differences to the calculation in P_Variable */
          /*       for small amounts (this was adopted from v_dbel01.cxiin)                                          */

          if available bSBM_TaxRate-SGST then                        

            ttV_BelegTaxrateSums-P.cIN_TaxSGST = string(round((ttV_BelegTaxrateSums-P.Steuer * 100 / ttV_BelegSumKopf-Calc.Gesamt_Steuersatz[iTaxRates]  
                                                            * bSBM_TaxRate-SGST.TaxRate / 100),
                                                           ttV_BelegKopf-P.WaehrungNK)).

        end. /* available bS_Steuer-SGST */

      end. /* if glDomesticIndiaIntraState = yes */

      /* cIN_TaxIGST */

      if    glDomesticIndiaIntraState = no
        and not (ttV_BelegTaxrateSums-P.Steuer * ttV_BelegSumKopf-Calc.Gesamt_Steuersatz[iTaxRates] = 0) then

        ttV_BelegTaxrateSums-P.cIN_TaxIGST = string(round((ttV_BelegTaxrateSums-P.Steuer * 100 / ttV_BelegSumKopf-Calc.Gesamt_Steuersatz[iTaxRates] 
                                                        * SBCTaxMasterFilesSvc:prpoInstance:dTaxRateOfTaxCodeObj(ttV_BelegSumKopf-Calc.NS_Steuer_Obj[iTaxRates]) / 100),
                                                        ttV_BelegKopf-P.WaehrungNK)).

      if glDomesticIndiaIntraState = yes then
      do:

        find bS_Steuer-SGST
          where bS_Steuer-SGST.S_Steuer_Obj = ttV_BelegSumKopf-Calc.NS_Steuer_Obj[iTaxRates]
          no-lock no-error.

        /* cIN_TaxRateCGST */

        if    available bS_Steuer-SGST
          and bS_Steuer-SGST.AddOn_S_Steuer_Obj > '':U then
        do:

          find bS_Steuer-CGST
            where bS_Steuer-CGST.S_Steuer_Obj = bS_Steuer-SGST.AddOn_S_Steuer_Obj
            no-lock no-error.

          if available bS_Steuer-CGST then
          do:

            find bSBM_TaxRate-CGST
              where bSBM_TaxRate-CGST.SBM_TaxRate_Obj = bS_Steuer-CGST.SBM_TaxRate_Obj
              no-lock no-error.                

            if available bSBM_TaxRate-CGST then

              ttV_BelegTaxrateSums-P.cIN_TaxRateCGST = string(bSBM_TaxRate-CGST.TaxRate).

          end. /* available bS_Steuer-CGST */

        end. /* available bS_Steuer-SGST and bS_Steuer-SGST.AddOn_S_Steuer_Obj > '':U */

        /* cIN_TaxRateSGST */

        if available bS_Steuer-SGST then
        do:

          find bSBM_TaxRate-SGST
            where bSBM_TaxRate-SGST.SBM_TaxRate_Obj = bS_Steuer-SGST.SBM_TaxRate_Obj
            no-lock no-error.  

          if available bSBM_TaxRate-SGST then  

            ttV_BelegTaxrateSums-P.cIN_TaxRateSGST = string(bSBM_TaxRate-SGST.TaxRate).

        end. /* if available bS_Steuer-SGST then */

      end. /* if glDomesticIndiaIntraState = yes then */ 

      /* cIN_TaxRateIGST */

      if glDomesticIndiaIntraState = no then 

        ttV_BelegTaxrateSums-P.cIN_TaxRateIGST = string(SBCTaxMasterFilesSvc:prpoInstance:dTaxRateOfTaxCodeObj(ttV_BelegSumKopf-Calc.NS_Steuer_Obj[iTaxRates])).

    end. /* pACConnectionSvc:prpcLocalization = 'IN':U */

    if   pACConnectionSvc:prpcLocalization = 'P':U
      or pACConnectionSvc:prpcLocalization = 'GB':U then
    do:

      assign
        dPGesamtsumme                             = (  ttV_BelegSumKopf-Calc.Gesamt_Belegsumme[11]
                                                     + ttV_BelegSumKopf-Calc.Gesamtzuschlag
                                                     + (if ttV_BelegKopf-P.Brutto = no then /* Nettobeleg oder Bruttobeleg */
                                                          ttV_BelegSumKopf-Calc.Gesamtsteuer
                                                        else
                                                          0))
        dEurofaktor                               = (if available ttS_Waehrung-P1 then
                                                       ttS_Waehrung-P1.Eurofaktor
                                                     else
                                                       0)
        .

      /* P_Zahlhinweis */

      if iTaxRates = ttV_BelegKopf-P.Zuschlag_Extent then

        ttV_BelegTaxrateSums-P.P_Zahlhinweis = string(dPGesamtsumme >= 0).

      SBCLocalizationPLSvc:prpoInstance:ReadTaxEvalPerRate
        (       ttV_BelegKopf-P.V_BelegKopf_Obj,
                ttV_BelegSumKopf-Calc.Gesamt_Steuersatz[iTaxRates],
                ttV_BelegSumKopf-Calc.P_NoToggle[iTaxRates],
                ttV_BelegSumKopf-Calc.P_NPV[iTaxRates],
                ttV_BelegSumKopf-Calc.P_befreit[iTaxRates],
         output dNetAmountOC,   
         output dTaxAmountOC,   
         output dNetAmountOCCIT,
         output dTaxAmountOCCIT).

      assign
        ttV_BelegTaxrateSums-P.GB_NetAmountOC = if ttV_BelegKopf-P.BelegArt = 'G':U then
                                                  - dNetAmountOC
                                                else
                                                  dNetAmountOC
        ttV_BelegTaxrateSums-P.GB_TaxAmountOC = if ttV_BelegKopf-P.BelegArt = 'G':U then
                                                  - dTaxAmountOC
                                                else
                                                  dTaxAmountOC
        .

      if pACConnectionSvc:prpcLocalization = 'P':U then
      do:
        if ttV_BelegTaxrateSums-P.Steuer <> 0 then
          assign
            ttV_BelegTaxrateSums-P.Steuer_EW       = dTaxAmountOC 
            ttV_BelegTaxrateSums-P.P_Steuer_EW_CIT = dTaxAmountOCCIT
            .
        assign
          ttV_BelegTaxrateSums-P.P_Summe_excl_EW          = dNetAmountOC
          ttV_BelegTaxrateSums-P.P_Summe_excl_EW_CIT      = dNetAmountOCCIT  
          ttV_BelegTaxrateSums-P.P_Summe_incl_EW          = dNetAmountOC    + dTaxAmountOC
          ttV_BelegTaxrateSums-P.P_Summe_incl_EW_CIT      = dNetAmountOCCIT + dTaxAmountOCCIT
          ttV_BelegTaxrateSums-P.P_Summe_incl_EW_Combined = dNetAmountOCCIT + dTaxAmountOC
          ttV_BelegTaxrateSums-P.WorteEndBetrag           = SBCLocalizationPLSvc:prpoInstance:cSpokenNumber
                                                              (gcFirma,
                                                               gcContentLanguage,
                                                               ttV_BelegKopf-P.Waehrung,
                                                               dPGesamtsumme)
          ttV_BelegTaxrateSums-P.WorteEndBetrag_EUR       = SBCLocalizationPLSvc:prpoInstance:cSpokenNumber
                                                              (gcFirma,
                                                               gcContentLanguage,
                                                               ?,
                                                               dPGesamtsumme / dEuroFaktor)
          .
      end.

    end. /* if pACConnectionSvc:prpcLocalization = 'P':U or 'GB':U then */

    if    not SBCLocalizationSvc:prpoInstance:lIsLocalizationHungaryOrPoland()  
      and can-do('R,G':U, ttV_BelegKopf-P.Belegart) then
    do:
      
      if ttV_BelegKopf-P.Waehrung <> 0 then
      do:
        if pACConnectionSvc:prpcLocalization = 'GB':U then
          assign
            ttV_BelegTaxrateSums-P.EW_Steuer     = ttV_BelegTaxrateSums-P.GB_TaxAmountOC
            ttV_BelegTaxrateSums-P.EW_Summe_excl = ttV_BelegTaxrateSums-P.GB_NetAmountOC
            .        
        else
          assign
            ttV_BelegTaxrateSums-P.EW_Steuer     = round({fnarg
                                                            pa_dCurDomCurAmtNonEur
                                                            "ttV_BelegTaxrateSums-P.Steuer,
                                                            ttV_BelegKopf-P.Kurs,
                                                            1"},
                                                         giDecimalsDomCur)
            ttV_BelegTaxrateSums-P.EW_Summe_excl = round({fnarg
                                                            pa_dCurDomCurAmtNonEur
                                                            "ttV_BelegTaxrateSums-P.Summe_excl,
                                                            ttV_BelegKopf-P.Kurs,
                                                            1"},
                                                         giDecimalsDomCur)
            .
      end. /* if ttV_BelegKopf-P.Waehrung <> 0 */
      else
        assign
          ttV_BelegTaxrateSums-P.EW_Steuer     = ttV_BelegTaxrateSums-P.Steuer
          ttV_BelegTaxrateSums-P.EW_Summe_excl = ttV_BelegTaxrateSums-P.Summe_excl
          .        

      ttV_BelegTaxrateSums-P.EW_Summe_incl = ttV_BelegTaxrateSums-P.EW_Summe_excl
                                           + ttV_BelegTaxrateSums-P.EW_Steuer.                                             

    end. /* if not SBCLocalizationSvc:prpoInstance:lIsLocalizationHungaryOrPoland() ... */

  end. /* if lVariousTaxRates and not can-find(ttV_BelegTaxrateSums-P */

end. /* iTaxRates = 1 to extent(ttV_BelegSumKopf-Calc.Gesamt_Steuersatz) */

end procedure. /* fillDocumentTaxrateSumsForLLPrint */


/* _UIB-CODE-BLOCK-END */
&ANALYZE-RESUME

&ENDIF


&IF DEFINED(EXCLUDE-fillDataset) = 0 &THEN

&ANALYZE-SUSPEND _UIB-CODE-BLOCK _PROCEDURE fillDataset Procedure 
procedure fillDataset :
/* Description ---------------------------------------------------------------*/
/*                                                                            */
/* Fills the dataset.                                                         */
/*                                                                            */
/* Parameters ----------------------------------------------------------------*/
/*                                                                            */
/* dsV_BelegKopf-P  The dataset.                                              */
/*                                                                            */
/*----------------------------------------------------------------------------*/

define input-output parameter dataset for dsV_BelegKopf-P.

define variable cPKS              as character                        no-undo.
define variable cBelegArt         as character                        no-undo.
define variable cPrintObjectOID   as character                        no-undo.
define variable cPrepareString    as character                        no-undo.
define variable iReferenzNr       as integer                          no-undo.
define variable iCustomer         as integer                          no-undo.
define variable lPrintZUGFeRD     as logical                          no-undo.
define variable lSendXRechnung    as logical                          no-undo.
define variable lcZUGFeRDInvoice  as longchar                         no-undo.
define variable cZUGFeRDProfile   as character                        no-undo.
define variable iSpoolNr          as integer                          no-undo.
define variable iSubSpoolNr       as integer                          no-undo.
define variable oZUGFeRD          as SBCZugFerdInvoice                no-undo.
define variable dExRateVal        as decimal                          no-undo.
&IF LOOKUP("U_CA":U,"{&PA-OPTIONEN}":U) > 0 &THEN
  define variable ixFunktion         as integer                       no-undo initial ?.
&ENDIF
define variable cOaPTextsOID         as character                        no-undo.
define variable lOaPText             as logical                          no-undo.
define variable tServiceDate         as date                             no-undo. 
define variable cCountryOfOrigin     as character                        no-undo.
define variable iRegionOfOrigin      as integer                          no-undo.
&IF (lookup("MC":U,"{&PA-MODULE}":U) > 0) &THEN
  define variable oLotCountryRegionOfOrigin as MMCCountryOfOriginSvo     no-undo.
  define variable cCharge                   as character                 no-undo.
&ENDIF
&IF LOOKUP("Q_TRANS","{&PA-OPTIONEN}") > 0 &THEN
  define variable oGetFreightPayerAccountNo as VUCTSPPrintFreightPayerSvo no-undo.
&ENDIF

define buffer bS_Adresse                    for S_Adresse.
define buffer bS_Lieferadresse              for S_Lieferadresse.
define buffer bS_ArtVar                     for S_ArtVar.
define buffer bS_ArtikelSpr                 for S_ArtikelSpr.
define buffer bS_Staat                      for S_Staat.
define buffer bS_ArtKunde-Set               for S_ArtKunde.
define buffer bBJT_SpoolDetail              for BJT_SpoolDetail.
define buffer bSBT_SpoolDetail              for SBT_SpoolDetail.
define buffer bSBT_Tracking                 for SBT_Tracking.
define buffer bBJ_Spool                     for BJ_Spool.
&IF LOOKUP("U_CI":U,"{&PA-OPTIONEN}":U) > 0 &THEN
define buffer buV_BelegKopf                 for V_BelegKopf.
&ENDIF
define buffer bS_PreisEinheit               for S_PreisEinheit.
define buffer bSBM_OaPTexts                 for SBM_OaPTexts.
define buffer bS_Mengeneinheit              for S_MengenEinheit.
define buffer bS_Lieferant-Supp             for S_Lieferant.
define buffer bS_Adresse-Supp               for S_Adresse.
define buffer bV_BelegKopfAdr               for V_BelegKopfAdr.
define buffer bS_StaatSpr                   for S_StaatSpr.
define buffer bS_StaatSpr-Origin            for S_StaatSpr.
define buffer bVUT_TrackingInfoHead         for VUT_TrackingInfoHead.
define buffer bVUT_TrackingInfoLine         for VUT_TrackingInfoLine.
define buffer bDBM_ShortDescription         for DBM_ShortDescription.
define buffer bBU_Benutzer                  for BU_Benutzer.
define buffer bttS_PreisEinheit-PPos        for temp-table ttS_PreisEinheit-PPos.
define buffer bttS_MengenEinheit-PSet       for temp-table ttS_MengenEinheit-PSet.
define buffer bttBU_Benutzer-P3             for temp-table ttBU_Benutzer-P3.

/*----------------------------------------------------------------------------*/
/* Processing                                                                 */
/*----------------------------------------------------------------------------*/

{&{&pa-XBasisName}_C_FillDatasetStart}
{&{&pa-XBasisName}_U_FillDatasetStart}
{&{&pa-XBasisName}_Q_FillDatasetStart}
{&{&pa-XBasisName}_FillDatasetStart}
{&{&pa-XBasisName}_Y_FillDatasetStart}

assign
  glISplitPaymentTaxKey = ?
  glIRegularTaxKey      = ?
  .

if adm.method.cls.DMCSessionSvc:cGetObjectProperty
     (dataset dsV_BelegKopf-P:handle,
      'FillMode':U) = 'LLConfig':U then

  /* Create default data records when starting the List & Label designer.     */

  adm.repos.cls.DRCDataProviderSvc:prpoInstance:generateDummyRecords(dataset dsV_BelegKopf-P:get-top-buffer(1)).

else
do:

  assign
    gcContentLanguage  = adm.method.cls.DMCSessionSvc:cGetObjectProperty
                           (dataset dsV_BelegKopf-P:handle,
                            'ContentLanguage':U)
    cPKS               = adm.method.cls.DMCSessionSvc:cGetObjectPropertyPKS
                           (dataset dsV_BelegKopf-P:handle,
                            'Context':U)
    cBelegArt          = adm.method.cls.DMCParameterStringSvc:cReadValue
                           (cPKS,
                            'Belegart':U,
                            1)
    iReferenzNr        = adm.method.cls.DMCParameterStringSvc:iReadValue
                           (cPKS,
                            'ReferenzNr':U,
                            1)
    glPositions        = adm.method.cls.DMCParameterStringSvc:lReadValue
                           (cPKS,
                            'Positionen':U,
                            1)
    cPrintObjectOID    = adm.method.cls.DMCParameterStringSvc:cReadValue
                           (cPKS,
                            'PrintDocumentOID':U,
                            1)

    lPrintZUGFeRD      = adm.method.cls.DMCParameterStringSvc:lReadValue
                           (cPKS,
                            '&ZUGFERD':U,
                            1)
    cZUGFeRDProfile    = adm.method.cls.DMCParameterStringSvc:cReadValue
                           (cPKS,
                            '&ZUGFERDProfile':U,
                            1)
    lSendXrechnung     = adm.method.cls.DMCParameterStringSvc:lReadValue
                           (cPKS,
                            '&SendXRechnung':U,
                            1)
    iSpoolNr           = adm.method.cls.DMCParameterStringSvc:iReadValue
                           (cPKS,
                            '&SpoolNr':U,
                            1)
    iSubSpoolNr        = adm.method.cls.DMCParameterStringSvc:iReadValue
                           (cPKS,
                            '&SubSpoolNr':U,
                            1)
    giH_TotalNoOfCopies = adm.method.cls.DMCParameterStringSvc:iReadValue
                          (cPKS,
                           '&LLNoOfCopies':U,
                           1)
    &IF LOOKUP("Q_GELANG","{&PA-OPTIONEN}") > 0 &THEN
    gcDocumentType     = adm.method.cls.DMCParameterStringSvc:cReadValue
                           (cPKS,
                            'DocumentType':U,
                            1)
    &ENDIF
    gcFirma            = {firma/vbelegko.fir pACConnectionSvc:prpcCompany}
    gtPCopyDate        = adm.method.cls.DMCParameterStringSvc:tReadValue
                           (cPKS,
                            'P_CopyDate':U,
                            1)
    &IF LOOKUP("U_CA":U,"{&PA-OPTIONEN}":U) > 0 &THEN
    ixFunktion         = adm.method.cls.DMCParameterStringSvc:iReadValue
                           (cPKS,
                            'xPackFunktion':U,
                            1)
    &ENDIF
    .

  if glPositions = ? then
    glPositions = yes.

  if lSendXRechnung = ? then
    lSendXRechnung = no.

  /* The PrintObjectOID is the only param deliverd by print via ELBV... All   */
  /* other params (Belegart/ReferenzNr/etc. ) need to be set from the record  */
  /* itself in that case.                                                     */

  if cPrintObjectOID > '':U then
  do:
    find gbV_BelegKopf
      where gbV_BelegKopf.V_BelegKopf_Obj  = cPrintObjectOID
      no-lock.

    assign
      cBelegArt    =  gbV_BelegKopf.Belegart
      iReferenzNr  =  gbV_BelegKopf.ReferenzNr
      .
  end.
  else
    release gbV_BelegKopf.

  release gbPV_BelegKopf-Org no-error.

  if    lPrintZUGFeRD 
    and not VBCSalesDocSvc:prpoInstance:lDocumentHasUniqueLineNumbers(
              gcFirma,
              cBelegArt,
              iReferenzNr) then
    adm.method.cls.DMCMessageSvc:prpoInstance:showError('vfrec00025':U).

  /*--------------------------------------------------------------------------*/
  /* The following TT's cannot be filled by the DS framework, because the     */
  /* physical DB relations differ from the relations in the DS or complex     */
  /* logic is needed to fill the TT.                                          */
  /*--------------------------------------------------------------------------*/

  /* all adresses are exempt */
  buffer ttS_Adresse-PCust:fill-mode                  = 'no-fill':U.
  buffer ttS_Adresse-PInv:fill-mode                   = 'no-fill':U.
  buffer ttS_Adresse-P16Del:fill-mode                 = 'no-fill':U.
  buffer ttS_Adresse-PCoP:fill-mode                   = 'no-fill':U.
  buffer ttS_Adresse-POrd:fill-mode                   = 'no-fill':U.
  buffer ttS_Adresse-PSite:fill-mode                  = 'no-fill':U.
  buffer ttS_Adresse-PVert:fill-mode                  = 'no-fill':U.
  buffer ttS_Adresse-PCustShpDoc:fill-mode            = 'no-fill':U.
  buffer ttS_Adresse-PInvShpDoc:fill-mode             = 'no-fill':U.
  buffer ttS_Adresse-PDelShpDoc:fill-mode             = 'no-fill':U.
  buffer ttS_Adresse-P16PC:fill-mode                  = 'no-fill':U.

  buffer ttS_Ansprech-P:fill-mode                     = 'no-fill':U.
  buffer ttS_ArtVar-P:fill-mode                       = 'no-fill':U.
  buffer ttV_BelegTaxrateSums-P:fill-mode             = 'no-fill':U.
  buffer ttV_BelegTaxrateSums-PP:fill-mode            = 'no-fill':U.
  buffer ttV_BelegTaxrateSums-PPOrg:fill-mode         = 'no-fill':U.
  buffer ttV_BelegTaxrateSums-PPCor:fill-mode         = 'no-fill':U.
  buffer ttVB_CalculatedLineValues-P1:fill-mode       = 'no-fill':U.
  buffer ttVFT_PostBillingLine-P:fill-mode            = 'no-fill':U.
  buffer ttV_BlanketOrder-P:fill-mode                 = 'no-fill':U.
  buffer ttVU_CallOrderRelease-P:fill-mode            = 'no-fill':U.
  buffer ttMCL_LotMovements-P:fill-mode               = 'no-fill':U.
  buffer ttV_BelegKopf-PShpDoc:fill-mode              = 'no-fill':U.
  buffer ttV_BelegPos-PShpDoc:fill-mode               = 'no-fill':U.
  buffer ttS_Mengeneinheit-P2:fill-mode               = 'no-fill':U.
  buffer ttMCL_LotMovements-PSetLine:fill-mode        = 'no-fill':U.
  buffer ttV_BelegTotalSum-P:fill-mode                = 'no-fill':U.
  buffer ttV_BelegTotalSum-PP:fill-mode               = 'no-fill':U.
  buffer ttV_BelegTotalSum-PPOrg:fill-mode            = 'no-fill':U.
  buffer ttV_BelegTotalSum-PPCor:fill-mode            = 'no-fill':U.
  buffer ttVST_MaintContractPos-P:fill-mode           = 'no-fill':U.
  buffer ttVST_MaintContract-P:fill-mode              = 'no-fill':U.
  buffer ttS_Artikel-PMaint:fill-mode                 = 'no-fill':U.
  buffer ttS_ArtVar-PMaint:fill-mode                  = 'no-fill':U.
  buffer ttMS_SNR-PMaint:fill-mode                    = 'no-fill':U.
  buffer ttS_AuftragsArt-P2Maint:fill-mode            = 'no-fill':U.
  buffer ttVS_AuftragPos-P:fill-mode                  = 'no-fill':U.
  buffer ttVS_Auftrag-P:fill-mode                     = 'no-fill':U.
  buffer ttVST_CallPosition-P1:fill-mode              = 'no-fill':U.
  buffer ttVST_Call-P:fill-mode                       = 'no-fill':U.
  buffer ttS_Artikel-P1:fill-mode                     = 'no-fill':U.
  buffer ttS_AuftragsArt-P2:fill-mode                 = 'no-fill':U.
  buffer ttS_ArtVar-P1:fill-mode                      = 'no-fill':U.
  buffer ttMS_SNR-PSO:fill-mode                       = 'no-fill':U.
  buffer ttS_ArtikelSpr-P:fill-mode                   = 'no-fill':U.
  buffer ttVB_Surcharges-P:fill-mode                  = 'no-fill':U.
  buffer ttS_Steuer-P:fill-mode                       = 'no-fill':U.
  buffer ttS_Steuer-PLine:fill-mode                   = 'no-fill':U.
  buffer ttS_Kunde-P1Orderer:fill-mode                = 'no-fill':U.
  buffer ttS_Verband-POrderer:fill-mode               = 'no-fill':U.
  buffer ttS_Vertreter-P5:fill-mode                   = 'no-fill':U.
  buffer ttMS_SNR-P1:fill-mode                        = 'no-fill':U.
  buffer ttMS_SNR-P1Set:fill-mode                     = 'no-fill':U.
  buffer ttM_LTPos-P1:fill-mode                       = 'no-fill':U.
  buffer ttMM_PackSummary-P:fill-mode                 = 'no-fill':U.
  buffer ttVB_AdvancePayment-P:fill-mode              = 'no-fill':U.
  buffer ttVB_AdvancePayment-PSum:fill-mode           = 'no-fill':U.
  buffer ttS_ArtKunde-PSet:fill-mode                  = 'no-fill':U.
  buffer ttS_ArtVar-P1Set:fill-mode                   = 'no-fill':U.
  buffer ttV_BelegPos-PPmtInv:fill-mode               = 'no-fill':U.
  buffer ttV_BelegKopf-PPmtInv:fill-mode              = 'no-fill':U.
  buffer ttMP_ArtPlatz-P3:fill-mode                   = 'no-fill':U.
  buffer ttVU_RA_Preis-P1:fill-mode                   = 'no-fill':U.
  buffer ttVU_RA_Preis-P1Alternate:fill-mode          = 'no-fill':U.
  buffer ttV_BelegKalk-P:fill-mode                    = 'no-fill':U.
  buffer ttSBT_Metal-P:fill-mode                      = 'no-fill':U.
  buffer ttS_MengenEinheit-PMet:fill-mode             = 'no-fill':U.
  buffer ttSBM_Metal-P:fill-mode                      = 'no-fill':U.
  buffer ttS_UStID-P:fill-mode                        = 'no-fill':U.
  buffer ttS_BankVerb-P2:fill-mode                    = 'no-fill':U.
  buffer ttSBM_BankDataAcc-P:fill-mode                = 'no-fill':U.
  buffer ttS_Bank-P:fill-mode                         = 'no-fill':U.
  buffer ttSBM_TaxRate-P:fill-mode                    = 'no-fill':U.
  buffer ttSBM_TaxRate-PLine:fill-mode                = 'no-fill':U.
  buffer ttMMT_StockReceipt-P:fill-mode               = 'no-fill':U.
  buffer ttV_H_CorrectionInvoice-P:fill-mode          = 'no-fill':U.

  buffer ttS_I_TaxExemption-P:fill-mode               = 'no-fill':U.
  buffer ttS_Lieferant-PCarr:fill-mode                = 'no-fill':U.
  buffer ttS_Adresse-PCarr:fill-mode                  = 'no-fill':U.
  buffer ttI_Bank_Adress-P:fill-mode                  = 'no-fill':U.

  buffer ttUSM_CWLieferzeitfenster-P:fill-mode        = 'no-fill':U.
  buffer ttV_BelegKopf-P2:fill-mode                   = 'no-fill':U.
  buffer ttV_BelegPos-PInv:fill-mode                  = 'no-fill':U.
  buffer ttV_BelegKopf-P2Order:fill-mode              = 'no-fill':U.
  buffer ttS_Artikel-P10:fill-mode                    = 'no-fill':U.
  buffer ttV_BelegPos-POrder:fill-mode                = 'no-fill':U.
  buffer ttS_MengenEinheit-P10:fill-mode              = 'no-fill':U.
  buffer ttS_ArtKunde-P11:fill-mode                   = 'no-fill':U.
  buffer ttUVT_BonusBilling-P1:fill-mode              = 'no-fill':U.
  buffer ttUSM_BonusType-P2:fill-mode                 = 'no-fill':U.
  buffer ttFB_Buchung-P5:fill-mode                    = 'no-fill':U.
  buffer ttFO_OP-P1:fill-mode                         = 'no-fill':U.
  buffer ttuBackorderLinies-P:fill-mode               = 'no-fill':U.
  buffer ttV_BelegPos-P8:fill-mode                    = 'no-fill':U.
  buffer ttV_BelegKopf-P9:fill-mode                   = 'no-fill':U.
  buffer ttS_MengenEinheit-PBOrder:fill-mode          = 'no-fill':U.
  buffer ttUVT_DatesOfVersionsBOPos-P:fill-mode       = 'no-fill':U.
  buffer ttVUT_EntryCertificate-P:fill-mode           = 'no-fill':U.
  buffer ttS_PreisEinheit-PPos:fill-mode              = 'no-fill':U.
  buffer ttV_BelegKopf-PP:fill-mode                   = 'no-fill':U.
  buffer ttV_BelegPos-PP:fill-mode                    = 'no-fill':U.
  buffer ttS_Artikel-PP:fill-mode                     = 'no-fill':U.
  buffer ttMLM_StorPartData-PP:fill-mode              = 'no-fill':U.
  buffer ttS_ArtKunde-PP:fill-mode                    = 'no-fill':U.
  buffer ttSBM_CustomsTariffNo-PP:fill-mode           = 'no-fill':U.
  buffer ttSBT_DropShipping-P:fill-mode               = 'no-fill':U.
  buffer ttV_EndCustomerPartInfo-P:fill-mode          = 'no-fill':U.
  buffer ttER_DeliveryNoteInfo-P:fill-mode            = 'no-fill':U.
  buffer ttSBM_OaPTexts-P:fill-mode                   = 'no-fill':U.
  buffer ttS_Lieferant-PSupp:fill-mode                = 'no-fill':U.
  buffer ttS_Adresse-PSupp:fill-mode                  = 'no-fill':U.
  buffer ttVUT_TrackingInfoLine-P:fill-mode           = 'no-fill':U.
  buffer ttBU_Benutzer-P3:fill-mode                   = 'no-fill':U.

  {&{&pa-XBasisName}_C_SetBufferFillMode}
  {&{&pa-XBasisName}_U_SetBufferFillMode}
  {&{&pa-XBasisName}_Q_SetBufferFillMode}
  {&{&pa-XBasisName}_SetBufferFillMode}
  {&{&pa-XBasisName}_Y_SetBufferFillMode}

  buffer {&pa_DR_DataProviderVariablesTT}:fill-mode   = 'no-fill':U.

  cPrepareString =    ' and V_BelegKopf.Firma      = ':U + quoter(gcFirma)
                    + ' and V_BelegKopf.Belegart   = ':U + quoter(cBelegArt)
                    + ' and V_BelegKopf.ReferenzNr = ':U + quoter(iReferenzNr).

  {setproperty
    dsV_BelegKopf-P
    'ttV_BelegKopf-PAddPrepareString':U
    "cPrepareString"}.

  /* we need V_Belegkopf to fill further variables for AddPrepareString  on   */
  /* child tables. Furthermore the record is needed to pass it's ROWID to old */
  /* API's, that cannot deal with OID's yet.                                  */

  if not available gbV_BelegKopf then
    find gbV_BelegKopf
      where gbV_BelegKopf.Firma       = gcFirma
        and gbV_BelegKopf.Belegart    = cBelegArt
        and gbV_BelegKopf.ReferenzNr  = iReferenzNr
      no-lock.

  tServiceDate = vert.base.cls.VBCSalesDocSvc:prpoInstance:tGetReferenceDate(buffer gbV_BelegKopf).

  find {&pa_DR_DataProviderVariablesTT}
    where {&pa_DR_DataProviderVariablesTT}.VariableName = 'Leistungsdatum':U
    no-error.

  if available {&pa_DR_DataProviderVariablesTT} then
    {&pa_DR_DataProviderVariablesTT}.DateValue = tServiceDate.

  &IF LOOKUP("U_CA":U,"{&PA-OPTIONEN}":U) > 0 &THEN

    find {&pa_DR_DataProviderVariablesTT}
      where {&pa_DR_DataProviderVariablesTT}.VariableName = 'Vorabbeleg':U
      no-error.

    if available {&pa_DR_DataProviderVariablesTT} then
      {&pa_DR_DataProviderVariablesTT}.CharacterValue = (if ixFunktion >= 0 then
                                                           '1':U
                                                         else
                                                           '':U).

  &ENDIF

  &IF LOOKUP("Q_TRANS","{&PA-OPTIONEN}") > 0 &THEN
    oGetFreightPayerAccountNo = VUCTSPPrintFreightPayerSvo:create
                                  (gbV_BelegKopf.Belegart,
                                   gbV_BelegKopf.AccountNoOrigin,
                                   gbV_BelegKopf.FreightPayerOrigin).

    find {&pa_DR_DataProviderVariablesTT}
      where {&pa_DR_DataProviderVariablesTT}.VariableName = 'CustomerNrOrigin':U
      no-error.

    if available {&pa_DR_DataProviderVariablesTT} then
      {&pa_DR_DataProviderVariablesTT}.CharacterValue = oGetFreightPayerAccountNo:prpcAccountNrOrigin.

    find {&pa_DR_DataProviderVariablesTT}
      where {&pa_DR_DataProviderVariablesTT}.VariableName = 'FreightPayerOrigin':U
      no-error.

    if available {&pa_DR_DataProviderVariablesTT} then
      {&pa_DR_DataProviderVariablesTT}.CharacterValue = oGetFreightPayerAccountNo:prpcFreightPayerOrigin.

    find {&pa_DR_DataProviderVariablesTT}
      where {&pa_DR_DataProviderVariablesTT}.VariableName = 'FreightPayerCustomerNr':U
      no-error.

    if available {&pa_DR_DataProviderVariablesTT} then
      {&pa_DR_DataProviderVariablesTT}.CharacterValue = gbV_BelegKopf.FreightPayerAccountNo.
  &ENDIF

  /* iCustomer is needed to load S_ArtKunde records of V_BelegPos             */

  iCustomer = vert.base.cls.VBCSalesDocSvc:prpoInstance:iGetCustomerOfShipment(buffer gbV_BelegKopf).

  {setproperty
    dsV_BelegKopf-P
    'ttS_ArtKunde-PAddPrepareString':U
    "'and S_ArtKunde.Kunde = ':U + quoter(iCustomer) "}.

  /* LfdNr  for V_BelegBestOrt is always 1 or no address exists  */

  {setproperty
    dsV_BelegKopf-P
    'ttV_BelegBestOrt-PAddPrepareString':U
    "'and V_BelegBestOrt.LfdNr = 1':U"}.

  run super (input-output dataset dsV_BelegKopf-P by-reference).

  /*--------------------------------------------------------------------------*/
  /* normalize Firma/Company fields of data to gcFirma                        */
  /*--------------------------------------------------------------------------*/

  run normalizeCompany in target-procedure.

  /* Load the document header now - no second find statement for this buffer  */
  /* is allowed in this programm - all sub procedures rely on this record!    */

  find ttV_BelegKopf-P.

  /* The currency information of the document is mandatory in the following   */
  /* loop to calculate line values... this is done by sub procedures. As the  */
  /* document MUST have one currency record, the following find for buffer    */
  /* ttS_Waehrung-P1 is the only find necessary and allowed in this DAO!      */

  find ttS_Waehrung-P1.

  if ttV_BelegKopf-P.Lieferant > 0 then
  do:

    find bS_Lieferant-Supp
      where bS_Lieferant-Supp.Firma     = {firma/sliefera.fir gcFirma}
        and bS_Lieferant-Supp.Lieferant = ttV_BelegKopf-P.Lieferant
      no-lock no-error.

    if available bS_Lieferant-Supp then
    do:

      create ttS_Lieferant-PSupp.

      {buffer-copy
         bS_Lieferant-Supp
         to ttS_Lieferant-PSupp}
        assign
          ttS_Lieferant-PSupp.Firma = gcFirma.

      ttS_Lieferant-PSupp.inlaendische_SteuerNr = string(ttS_Lieferant-PSupp.inlaendische_SteuerNr, 
                                                         SBCTaxMasterFilesSvc:prpoInstance:cFormatDomesticTaxIDForAcc(ttS_Lieferant-PSupp.Lieferant)).
      validate ttS_Lieferant-PSupp.

      find bS_Adresse-Supp
        where bS_Adresse-Supp.Firma    = {firma/s_adres.fir gcFirma} 
          and bS_Adresse-Supp.AdressNr = bS_Lieferant-Supp.AdressNr
        no-lock no-error.

      if available bS_Adresse-Supp then
      do:

        create ttS_Adresse-PSupp.

        {buffer-copy
           bS_Adresse-Supp
           to ttS_Adresse-PSupp}
          assign
            ttS_Adresse-PSupp.Firma = gcFirma.

      end. /* if available bS_Adresse-Supp then */

    end. /* if available bS_Lieferant-Supp then */

  end. /* if ttV_BelegKopf-P.Lieferant > 0 then  */

  assign
    ttV_BelegKopf-P.CopyOrOriginalInvoice   = VFCXInvoiceSvc:prpoInstance:cCopyOrOriginalInvoice
                                                (ttV_BelegKopf-P.V_BelegKopf_Obj,
                                                 ttV_BelegKopf-P.BelegArt)
    ttV_BelegKopf-P.CopyOrOriginalTextBlock = VFCXInvoiceSvc:prpoInstance:clCopyOrOriginalTextBlock
                                                (ttV_BelegKopf-P.V_BelegKopf_Obj,
                                                 ttV_BelegKopf-P.BelegArt)
    .

  /* ---------------------------------- */
  /* add data for foreign localizations */
  /* ---------------------------------- */
  
  if pACConnectionSvc:prpcLocalization = 'H':U then
    run HungarianLocalizationData in target-procedure.

  if pACConnectionSvc:prpcLocalization = 'P':U then
    run PolishLocalizationData in target-procedure.

  if pACConnectionSvc:prpcLocalization = 'I':U then
    run ItalianLocalizationData in target-procedure.

  /* fill DropShipping info */

  run fillDropShippingHeadInfo in target-procedure.

  /* Specalist information is needed for sales documents                      */

  adm.method.cls.DMCSessionSvc:setObjectProperty
    (dataset dsV_BelegKopf-P:handle,
     'Specialist':U,
      ttV_BelegKopf-P.Sachbearbeiter).

  adm.method.cls.DMCSessionSvc:setObjectProperty
    (dataset dsV_BelegKopf-P:handle,
     'MainTableOID':U,
      ttV_BelegKopf-P.V_BelegKopf_Obj).

  /* note if we have an Indian transaction within the same state */

  glDomesticIndiaIntraState = (    pACConnectionSvc:prpcLocalization = 'IN':U
                               and SBCTaxMasterFilesSvc:prpoInstance:cIsoAlphaCodeOfTaxTerritory(ttV_BelegKopf-P.Dept_SBM_TaxTerritory_Obj[{&pa_SB_TaxTerritoryExt_Country}]) = 'IN':U
                               and SBCTaxMasterFilesSvc:prpoInstance:iTaxTransactionTypeOfDocument(ttV_BelegKopf-P.V_BelegKopf_Obj) = {&pa_SB_DomesticTransaction}
                               and SBCTaxMasterFilesSvc:prpoInstance:lIsTransactionWithinSameState(ttV_BelegKopf-P.Dept_SBM_TaxTerritory_Obj,
                                                                                                   ttV_BelegKopf-P.Dest_SBM_TaxTerritory_Obj) = yes).

  /* If a document is already archived the flag lPositions is always "no" and */
  /* the state passed via PKS becomes irrelevant.                             */

  if ttV_BelegKopf-P.offen = no then
    glPositions = no.

  /* ------------------------------------------------------------------------ */
  /* determine customer, invoice and delivery address by calling appserver    */
  /* As AdressNr field of records in the TT might be ? or zero, the records   */
  /* need some post processing before they are usable in the dataset context! */

  /* use dummy tt for appserver call and copy results because of changes from PA-36404 */

  {adm/incl/d__run03.if
     &Procedure   = "vert/base/proc/vbndoc06.p"
     &Arguments   = "ttV_BelegKopf-P.V_BelegKopf_Obj,
                     output table Kund_Adresse_Dummy,
                     output table Lief_Adresse_Dummy,
                     output table Rech_Adresse_Dummy"
  }

  empty temp-table ttS_Adresse-PCust.
  empty temp-table ttS_Adresse-P.
  empty temp-table ttS_Adresse-PInv.

  temp-table ttS_Adresse-PCust:copy-temp-table(temp-table Kund_Adresse_Dummy:handle, no, yes, yes).
  temp-table ttS_Adresse-P:copy-temp-table(    temp-table Lief_Adresse_Dummy:handle, no, yes, yes).
  temp-table ttS_Adresse-PInv:copy-temp-table( temp-table Rech_Adresse_Dummy:handle, no, yes, yes).

  /* there is one entry in each tt, that is manually linke to ttV_BelegKopf     */

  find ttS_Adresse-PCust no-error.

  if available ttS_Adresse-PCust then
  do:
    /* A AdressNr number is needed for linking of TT's ... use the artificial */
    /* number (negative!!!) from giDiversAddressCounter and decrease counter  */
    /* for the next usage...                                                  */

    if ttS_Adresse-PCust.AdressNr = ?
      or ttS_Adresse-PCust.AdressNr = 0 then
      assign
        ttS_Adresse-PCust.AdressNr = giDiversAddressCounter
        giDiversAddressCounter     = giDiversAddressCounter - 1
        .

    assign
      ttV_BelegKopf-P.AdressNrCust = ttS_Adresse-PCust.AdressNr
      ttS_Adresse-PCust.Firma      = ttV_BelegKopf-P.Firma
      .

  end.

  find ttS_Adresse-P no-error.

  if available ttS_Adresse-P then
  do:

    create ttS_Adresse-P16Del.
    {buffer-copy
       ttS_Adresse-P
       to ttS_Adresse-P16Del}

    /* Fill AdrRow fields */

    {vert/base/incl/vb_bel00.if
      &ippSourceAdrTable = "ttS_Adresse-P"
      &ippTargetTable    = "ttS_Adresse-P16Del"
    }     

    empty temp-table ttS_Adresse-P.

    /* A AdressNr number is needed for linking of TT's ... use the artificial */
    /* number (negative!!!) from giDiversAddressCounter and decrease counter  */
    /* for the next usage...                                                  */

    if ttS_Adresse-P16Del.AdressNr = ?
      or ttS_Adresse-P16Del.AdressNr = 0 then
      assign
        ttS_Adresse-P16Del.AdressNr  = giDiversAddressCounter
        giDiversAddressCounter       = giDiversAddressCounter - 1
        .

    assign
      ttV_BelegKopf-P.AdressNrDel = ttS_Adresse-P16Del.AdressNr
      ttS_Adresse-P16Del.Firma      = ttV_BelegKopf-P.Firma
      .

    /* the master data delivery address holds additional information not      */
    /* available in the ttS_Adresse-P16Del record. If the AddressNr is valid,   */
    /* a corresponding master data record exists, that can be used to print   */
    /* information like e.g. S_Lieferadresse.AdressKennung                    */

   if ttS_Adresse-P16Del.AdressNr > 0 then
     find first bS_Lieferadresse
        where bS_Lieferadresse.Firma    = {firma/s_kunde.fir ttV_BelegKopf-P.Firma}
          and bS_Lieferadresse.AdressNr = ttS_Adresse-P16Del.AdressNr
          and bS_Lieferadresse.Kunde    = ttV_BelegKopf-P.Kunde
        no-lock no-error.

   if available bS_Lieferadresse then
     {buffer-copy
        bS_Lieferadresse
        to ttS_LieferAdresse-P
        assign
          "ttS_LieferAdresse-P.Firma = ttV_BelegKopf-P.Firma"}

    cOaPTextsOID = vert.base.cls.VBCSalesDocSvc:prpoInstance:cGetOaPTextOID
                     (ttS_Adresse-P16Del.Staat).

    if    can-do('L,VUD,R,VFP':U,ttV_BelegKopf-P.BelegArt)
      and cOaPTextsOID > '':U then
    do:

      find bSBM_OaPTexts
        where bSBM_OaPTexts.SBM_OaPTexts_Obj = cOaPTextsOID
        no-lock no-error.

      if available bSBM_OaPTexts then
      do:

        create ttSBM_OaPTexts-P.
        {buffer-copy
           bSBM_OaPTexts
           to ttSBM_OaPTexts-P
           assign
             "ttSBM_OaPTexts-P.AddressNo = ttS_Adresse-P16Del.AdressNr"}

      end. /* if available bSBM_OaPTexts */

    end. /* if can-do('L,VUD,R,VFP':U,ttV_BelegKopf-P.BelegArt) */

  end. /* if available ttS_Adresse-P then */ 

  find ttS_Adresse-PInv no-error.

  if available ttS_Adresse-PInv then
  do:

    /* A AdressNr number is needed for linking of TT's ... use the artificial */
    /* number (negative!!!) from giDiversAddressCounter and decrease counter  */
    /* for the next usage...                                                  */

    if ttS_Adresse-PInv.AdressNr = ?
      or ttS_Adresse-PInv.AdressNr = 0 then
      assign
        ttS_Adresse-PInv.AdressNr  = giDiversAddressCounter
        giDiversAddressCounter     = giDiversAddressCounter - 1
        .

    assign
      ttV_BelegKopf-P.AdressNrInv = ttS_Adresse-PInv.AdressNr
      ttS_Adresse-PInv.Firma      = ttV_BelegKopf-P.Firma
      .

  end.

  if ttV_BelegKopf-P.Versendung = yes then
  do:

    find bS_Staat
      where bS_Staat.Staat = ttS_Adresse-P16Del.Staat
      no-lock.

  end.

  find bBU_Benutzer
    where bBU_Benutzer.Benutzer = ttV_BelegKopf-P.Sachbearbeiter
    no-lock no-error.

  if available bBU_Benutzer then
  do:

    create bttBU_Benutzer-P3.
    {buffer-copy
       bBU_Benutzer
       to bttBU_Benutzer-P3}

  end. /* if available bBU_Benutzer then */

  //  determine contact person and contact person address of document

  run FillContactInformation in target-procedure.
  
  /*--------------------------------------------------------------------------*/
  /* determine orderer address                                                */
  /*--------------------------------------------------------------------------*/

  vert.base.cls.VBCSalesDocSvc:prpoInstance:OrdererAddressOfDocument
                                             (ttV_BelegKopf-P.V_BelegKopf_Obj,
                                              output table ttS_Adresse-POrd).

  /* If no "real" orderer address could be determined by the API call, the    */
  /* ttS_Adresse-PCust is copied to ttS_Adresse-POrd, because in that case    */
  /* the customer is the orderer.                                             */

  find ttS_Adresse-POrd
    no-error.

  if not available ttS_Adresse-POrd
    and available ttS_Adresse-PCust then

    {buffer-copy
       ttS_Adresse-PCust
       to ttS_Adresse-POrd}

  find ttS_Adresse-POrd
    no-error.

  if available ttS_Adresse-POrd then
  do:

    /* A AdressNr number is needed for linking of TT's ... use the artificial */
    /* number (negative!!!) from giDiversAddressCounter and decrease counter  */
    /* for the next usage...                                                  */

    if   ttS_Adresse-POrd.AdressNr = ?
      or ttS_Adresse-POrd.AdressNr = 0 then
      assign
        ttS_Adresse-POrd.AdressNr = giDiversAddressCounter
        giDiversAddressCounter    = giDiversAddressCounter - 1
        .

    assign
      ttV_BelegKopf-P.AdressNrOrd = ttS_Adresse-POrd.AdressNr
      ttS_Adresse-POrd.Firma      = ttV_BelegKopf-P.Firma
      .

  end. /* if available ttS_Adresse-POrd */

  /*--------------------------------------------------------------------------*/
  /* determine plant address                                                  */
  /*--------------------------------------------------------------------------*/

  vert.base.cls.VBCSalesDocSvc:prpoInstance:PlantAddressOfDocument
                                              (ttV_BelegKopf-P.V_Belegkopf_Obj,
                                               output table ttS_Adresse-PSite).
  find ttS_Adresse-PSite
    no-error.

  if available ttS_Adresse-PSite  then
  do:

    /* A AdressNr number is needed for linking of TT's ... use the artificial */
    /* number (negative!!!) from giDiversAddressCounter and decrease counter  */
    /* for the next usage...                                                  */

    if   ttS_Adresse-PSite.AdressNr = ?
      or ttS_Adresse-PSite.AdressNr = 0 then
      assign
        ttS_Adresse-PSite.AdressNr = giDiversAddressCounter
        giDiversAddressCounter     = giDiversAddressCounter - 1
        .

    assign
      ttV_BelegKopf-P.AdressNrSite = ttS_Adresse-PSite.AdressNr
      ttS_Adresse-PSite.Firma      = ttV_BelegKopf-P.Firma
      .

  end. /* if available ttS_Adresse-PSite */

  find  bV_BelegKopfAdr
    where bV_BelegKopfAdr.Firma      = ttV_BelegKopf-P.Firma
      and bV_BelegKopfAdr.BelegArt   = ttV_BelegKopf-P.BelegArt
      and bV_BelegKopfAdr.ReferenzNr = ttV_BelegKopf-P.ReferenzNr
      and bV_BelegKopfAdr.Typ        = 'E':U
    no-lock no-error.

  if available bV_BelegKopfAdr then
  do:

    {adm/incl/d__spr00.if
      &Tabelle  = "bS_StaatSpr"
      &Selekt   = "where bS_StaatSpr.Staat = bV_BelegKopfAdr.Staat"
      &Sprache  = "gcContentLanguage"
      &no-error = "no-error"
    }

    assign 
      ttV_BelegKopf-P.EndUserFormOfAddress = bV_BelegKopfAdr.Anrede
      ttV_BelegKopf-P.EndUserFirstName     = bV_BelegKopfAdr.Vorname 
      ttV_BelegKopf-P.EndUserName          = bV_BelegKopfAdr.Name1
      ttV_BelegKopf-P.EndUserName2         = bV_BelegKopfAdr.Name2    
      ttV_BelegKopf-P.EndUserName3         = bV_BelegKopfAdr.Name3    
      ttV_BelegKopf-P.EndUserState         = bV_BelegKopfAdr.Staat
      ttV_BelegKopf-P.EndUserStreet        = bV_BelegKopfAdr.Strasse 
      ttV_BelegKopf-P.EndUserHouseNumber   = bV_BelegKopfAdr.Hausnummer 
      ttV_BelegKopf-P.EndUserOrt           = bV_BelegKopfAdr.Ort
      ttV_BelegKopf-P.EndUserZipCode       = bV_BelegKopfAdr.PLZ
      ttV_BelegKopf-P.EndUserZipCodePOBox  = bV_BelegKopfAdr.PLZ_Postfach
      ttV_BelegKopf-P.EndUserPOBox         = bV_BelegKopfAdr.Postfach
      ttV_BelegKopf-P.EndUserStreetPostfix = bV_BelegKopfAdr.StreetPostfix
      ttV_BelegKopf-P.EndUserStreetPrefix  = bV_BelegKopfAdr.StreetPrefix
      ttV_BelegKopf-P.EndUserStateDesc     = bS_StaatSpr.Bezeichnung when available bS_StaatSpr
      .

  end. /* if available bV_BelegKopfAdr */

  run uFillUnloadingPoints in target-procedure.

  run uFillCustomerGroup in target-procedure.

  &IF LOOKUP("U_CI":U,"{&PA-OPTIONEN}":U) > 0 &THEN
  if ttV_BelegKopf-P.Belegart = 'A':U then
  do:

    find first buV_BelegKopf
      where buV_BelegKopf.Firma      = ttV_BelegKopf-P.Firma
        and buV_BelegKopf.Belegart   = ttV_BelegKopf-P.uHerk_Belegart
        and buV_BelegKopf.ReferenzNr = ttV_BelegKopf-P.uHerk_ReferenzNr
      no-lock no-error.

    if available buV_BelegKopf then
      ttV_BelegKopf-P.uHerkunftsversion = buV_BelegKopf.uAngebotsversion.

  end. /* if bV_BelegKopf.Belegart = 'A':U */

  if ttV_BelegKopf-P.Belegart = 'U':U
    and ttV_BelegKopf-P.Herk_Belegart = 'A':U then
  do:

    find first buV_BelegKopf
      where buV_BelegKopf.Firma      = ttV_BelegKopf-P.Firma
        and buV_BelegKopf.Belegart   = ttV_BelegKopf-P.Herk_Belegart
        and buV_BelegKopf.ReferenzNr = ttV_BelegKopf-P.Herk_ReferenzNr
      no-lock no-error.

    if available buV_BelegKopf then
      assign
        ttV_BelegKopf-P.uAngebot         = buV_BelegKopf.uAngebot
        ttV_BelegKopf-P.uAngebotsversion = buV_BelegKopf.uAngebotsversion
        .

  end. /* if ttV_BelegKopf.Belegart = 'U':U or 'A':U */
  &ENDIF

  /* sales agents of document                                                 */

  vert.base.cls.VBCSalesDocSvc:prpoInstance:LLFillSalesAgentTT
    (       ttV_BelegKopf-P.V_BelegKopf_Obj,
     output table ttS_Vertreter-P5 by-reference,
     output table ttS_Adresse-PVert by-reference).

  &IF lookup ("V_Anz":U,"{&PA-OPTIONEN}":U) > 0 &THEN

    /* only if a payment plan exists start printing the title and the lines */

    if can-find(first ttVBT_DocPaymentLines-P
                  where ttVBT_DocPaymentLines-P.Owning_Obj = ttV_BelegKopf-P.V_BelegKopf_Obj) then
    do:

      for each ttVBT_DocPaymentLines-P
        where ttVBT_DocPaymentLines-P.Owning_Obj = ttV_Belegkopf-P.V_BelegKopf_Obj
        exclusive-lock:

        ttVBT_DocPaymentLines-P.TotalPaid = (if ttVBT_DocPaymentLines-P.IsOpen = no then
                                               vert.base.cls.VBCSalesDocSvc:prpoInstance:dPaidAmountInvoice(ttVBT_DocPaymentLines-P.V_BelegKopf_Obj)
                                             else
                                               0).

      end. /* for each ttVBT_DocPaymentLines-P */

    end. /* if can-find(first ttVBT_DocPaymentLines-P */

  &ENDIF

  if lookup(ttV_BelegKopf-P.Belegart,'A,U,L,R,G,VFP,VUD,VUR,VUA':U) > 0 
    and ttV_BelegKopf-P.MMM_CusRefOrder_ID  <> '':U
    and ttV_BelegKopf-P.MMM_CusRefOrder_Obj <> '':U then
  do:
    {adm/incl/d__spr00.if
      &Tabelle  = "bDBM_ShortDescription"
      &Selekt   = "where bDBM_ShortDescription.Owning_Obj = ttV_BelegKopf-P.MMM_CusRefOrder_Obj"
      &Sprache  = "gcContentLanguage"
      &no-error = "no-error"
    }

    if available bDBM_ShortDescription then
      ttV_BelegKopf-P.CROInfo = bDBM_ShortDescription.ShortDesc1.
  end.


  /* load customer and union information of orderer                           */

  run fillDocumentOrdererForLLPrint in target-procedure (iCustomer).

  /* Furthermore the EUR is needed as a currency...*/

  run fillEuroKurzBezGlobalVar in target-procedure.

  /* the sales document might have a credit term which is needed by sub       */
  /* procedures... the sub procedures will check wether a credit term is      */
  /* available before using it. As the document CAN have one credit term at   */
  /* most, the following find for buffer ttS_ZahlZiel-P is the only find      */
  /* necessary and allowed in this DAO!                                       */

  find ttS_ZahlZiel-P
    no-error.

  /* there must be exactly one customer - even if it is the divers customer   */

  find ttS_Kunde-P1.

  ttS_Kunde-P1.inlaendische_SteuerNr = string(ttS_Kunde-P1.inlaendische_SteuerNr, 
                                              SBCTaxMasterFilesSvc:prpoInstance:cFormatDomesticTaxIDForAcc(ttS_Kunde-P1.Kunde)).
  validate ttS_Kunde-P1. 

  ttV_BelegKopf-P.Empfaenger = VBCContactPersonSvc:prpoInstance:cGetContactPersonName
                                 (gbV_BelegKopf.V_BelegKopf_Obj,
                                  integer(SBCContactTypeEnu:Customer)).

  if can-do('L,VUD,R,VFP':U,ttV_BelegKopf-P.BelegArt) then

    assign
      lOaPText                              =     available bSBM_OaPTexts
                                              and available ttS_Kunde-P1
                                              and ttS_Kunde-P1.OaPText = yes
                                              and can-find(first ttV_BelegPos-P
                                                             where ttV_BelegPos-P.Ursprungszeugnis = yes)
      ttV_BelegKopf-P.PrintDocHeaderOaPText = lOaPText
      .

  &IF lookup("M_ATLAS":U,"{&PA-OPTIONEN}":U) > 0 &THEN

    if    can-do('U,L,VFP,VUD,R':U,ttV_BelegKopf-P.Belegart)
      and SBCLocalApplicationSvc:prpoInstance:lCheckModulsAndOptionsAtlas(no) then

      ttV_BelegKopf-P.MRN = VFCAtlasSvc:prpoInstance:cGetSalesDocumentMRNNumber
                              (ttV_BelegKopf-P.Firma,
                               'V_BelegKopf':U,
                               {vert/incl/v_belko.sl &Tabelle = "ttV_BelegKopf-P"}).

  &ENDIF
  /* Fill calculated fields of document header ttV_BelegKopf-P that could not */
  /* be filled by the framework.                                              */

  if pACConnectionSvc:prpcLocalization = 'I':U then
  do:

    {adm/incl/d__run03.if
      &Procedure = "stamm/proc/s_nadri0.p"
      &Arguments = "ttS_Kunde-P1.Firma,
                    ttS_Kunde-P1.S_Kunde_Obj,
                    (ttV_BelegKopf-P.ZahlungsArt = integer({&pa_F_I_RIBAPaymentType})),
                    output table ttI_Bank_Adress-P"
    }

    ttV_BelegKopf-P.I_RIBA = (ttV_BelegKopf-P.ZahlungsArt = integer({&pa_F_I_RIBAPaymentType})).

  end. /* if pACConnectionSvc:prpcLocalization = 'I':U then */

  run fillDocumentHeadCalculatedFieldsForLLPrint in target-procedure.

  /* Fill the global variable Factoring to get the provider variable and to   */
  /* decide if the information of the factor bank should be filled            */

  run fillFactoringGlobalVar in target-procedure.

  /*------------------------------------------------------------------------*/
  /* Packaging  ->   Section: P    Subsection: PPE                          */
  /*------------------------------------------------------------------------*/

  &IF lookup("M_PACK","{&PA-OPTIONEN}") > 0 &THEN

    run fillPackagingInfoForLLPrint in target-procedure.

  &ENDIF  /* Packmittel */

  /*------------------------------------------------------------------------*/
  /* Delivery time window  ->   Section: P    Subsection: ULZ               */
  /*------------------------------------------------------------------------*/

  &IF LOOKUP("U_CI","{&PA-OPTIONEN}") > 0 &THEN

    run uFillTimeWindowForDeliveryAddress in target-procedure.

  &ENDIF

  &IF LOOKUP("U_CW","{&PA-OPTIONEN}") > 0 &THEN

    if ttV_BelegKopf-P.BelegArt = 'L':U then

      run uFillBackOrderLinies in target-procedure.

  &ENDIF

  &IF LOOKUP("Q_GELANG","{&PA-OPTIONEN}") > 0 &THEN

    if gcDocumentType = 'VUC':U then

      run FillEntryCertificate in target-procedure.

  &ENDIF

  /* ttV_BelegSumKopf-Calc and ttV_BelegSumPos-Calc are filled for further    */
  /* usage in procedure fillDocumentTaxrateSumsForLLPrint and                 */
  /* procedure fillDocumentTotalSumForLLPrint.                                */
  /* ttV_BelegSumPos-Calc is needed in the following loop over ttV_BelegPos-P */

  vert.base.cls.VBCSalesDocSvc:prpoInstance:CalcDocumentTotal
                                 (ttV_BelegKopf-P.V_BelegKopf_Obj,
                                  glPositions, /* open quantity or total quatity, depending on user choice and  archiving state */
                                  output Table ttV_BelegSumKopf-Calc by-reference,
                                  output Table ttV_BelegSumPos-Calc  by-reference).

  find ttV_BelegSumKopf-Calc.

  /* In case of a blanket order we additionally need the document totals with */
  /* reference to the origin quantity                                         */

  if ttV_BelegKopf-P.BelegArt = 'VUR':U then
  do:
     vert.base.cls.VBCSalesDocSvc:prpoInstance:CalcDocumentTotal
                                   (ttV_BelegKopf-P.V_BelegKopf_Obj,
                                    no,    /* the origin quantity (not only the open quantity) */
                                    output Table ttV_BelegSumKopf-VUR by-reference,
                                    output Table ttV_BelegSumPos-VUR  by-reference).
    find ttV_BelegSumKopf-VUR.

  end.

  if    SBCLocalizationSvc:prpoInstance:lIsLocalizationHungary()
    and ttV_BelegKopf-P.BelegArt = 'R':U then
  do:

    if ttV_BelegKopf-P.H_InvoiceType > 0 then
      run H_fillDocumentOriginInfoForLLPrint in target-procedure.
    else
      assign
        ttV_BelegKopf-P.H_OrigDocDate = ?
        ttV_BelegKopf-P.H_OrigDocNo   = ?
        ttV_BelegKopf-P.H_OrigTaxDate = ?
        .                

    ttV_BelegKopf-P.H_InvoiceType_Short = adm.config.cls.DCCAppConfigSvc:prpoInstance:cParamValByRefParamValLng
                                            ('VF_CorrectingInvoiceTypes_shortDesc':U,
                                             string(ttV_BelegKopf-P.H_InvoiceType),
                                             gcContentLanguage).

    if gbV_BelegKopf.Waehrung = {fn pa_iHHUFCurrency} then
      ttV_BelegKopf-P.H_ExRateEval = ?.
      
    else
    do:
      
      if gbV_BelegKopf.H_ExRateEval <> ? then
        dExRateVal = gbV_BelegKopf.H_ExRateEval.
    
      else
        dExRateVal = {fnarg
                        pa_dHCurGetExchangeRate
                        "gbV_BelegKopf.Waehrung,
                         vert.base.cls.VBCPolandHungarySpecialsSvc:prpoInstance:tTaxPeriodDateForInvoicing
                           (buffer gbV_BelegKopf),
                         {&pa_FB_H_NationalExchangeRate},
                         gbV_BelegKopf.Kunde,
                         '':U"}.
    
      if dExRateVal <> 0 then
        dExRateVal = SBCSessionSvc:prpoInstance:dExchangeRateQuotation(dExRateVal).
        
      ttV_BelegKopf-P.H_ExRateEval = dExRateVal.
    
    end. /* else do: (if gbV_BelegKopf.Waehrung = {fn pa_iHHUFCurrency}) */

  end. /* if pACConnectionSvc:prpcLocalization = 'H':U ... */

  &IF LOOKUP("U_CA":U,"{&PA-OPTIONEN}":U) > 0 &THEN

    gcuGSAStatus = if ttV_BelegKopf-P.BelegArt = 'GSA':U then 
                     adm.config.cls.DCCAppConfigSvc:prpoInstance:cParamValByRefParamValLng
                       ('UCA_CreditMemoStatus_desc':U,
                        string(ttV_BelegKopf-P.uGSAStatus),
                        gcContentLanguage)
                    else 
                      '':U. 

  &ENDIF /* U_CA */

  /*--------------------------------------------------------------------------*/
  /* Fill additional information of V_BelegPos that could no be determined    */
  /* by the dataset framework.                                                */
  /*--------------------------------------------------------------------------*/

  /* Since the DS framework creates a temp-table entry for all lines we need  */
  /* to check if only non-archived lines should be printed. If that is the    */
  /* case, all temp-table entries representing an archived line need to be    */
  /* deleted in order to prevent further run time errors.                     */

  if glPositions then
  do:

    for each ttV_BelegPos-P
      where ttV_BelegPos-P.Firma      = gcFirma
        and ttV_BelegPos-P.BelegArt   = ttV_BelegKopf-P.BelegArt
        and ttV_BelegPos-P.ReferenzNr = ttV_BelegKopf-P.ReferenzNr
        and ttV_BelegPos-P.offen      = no
      exclusive-lock:

      delete ttV_BelegPos-P.

    end. /* for each ttV_BelegPos-P */

  end. /* if glPositions then */

  &IF LOOKUP("Q_GELANG":U,"{&PA-OPTIONEN}":U) > 0 &THEN
    if gcDocumentType = 'VUC':U then
    do:

      for each ttV_BelegPos-P
        where ttV_BelegPos-P.Firma      = gcFirma
          and ttV_BelegPos-P.BelegArt   = ttV_BelegKopf-P.BelegArt
          and ttV_BelegPos-P.ReferenzNr = ttV_BelegKopf-P.ReferenzNr
        exclusive-lock:

        if VUCEntryCertificateSvc:prpoInstance:lCheckIfServiceOrValueLine
             (ttV_BelegPos-P.Artikel,
              ttV_BelegPos-P.LagerOrt,
              ttV_BelegPos-P.Wertposition) then

          delete ttV_BelegPos-P.

        end. /* for each ttV_BelegPos-P */

     end. /* if    gcDocumentType = 'VUC':U */
  &ENDIF

  &IF LOOKUP("U_CA":U,"{&PA-OPTIONEN}":U) > 0 &THEN
    adm.method.cls.DMCSessionSvc:hAddSuperProcedure
      ('vert/fakt/proc/vfrnfv00.p':U,
       session).
  &ENDIF

  for each ttV_BelegPos-P:

    /* Based on the ACM parameters: 'VF_H_CorrectingInvoiceOnlyModLines' and  */
    /* 'VF_P_CorrectingInvoiceOnlyModLines' ONLY modified correcting invoice  */
    /* lines need to be printed.                                              */

    if    adm.config.cls.DCCAppConfigSvc:prpoInstance:lParameterValue('VF_H_CorrectingInvoiceOnlyModLines':U) = yes
      and VBCPolandHungarySpecialsSvc:prpoInstance:lIsAHungarianCorrectingInvoice
                                                  (ttV_BelegKopf-P.BelegArt,
                                                   ttV_BelegKopf-P.ReferenzNr)
      and (   ttV_BelegPos-P.H_CancelledLine > 0
           or ttV_BelegPos-P.H_CorrectedLine > 0)
      and vert.base.cls.VBCSalesDocSvc:prpoInstance:lHisModCorrectedLine(ttV_BelegPos-P.V_BelegPos_Obj) = no then
    do:

      delete ttV_BelegPos-P.
      next.

    end. /* if  ... lIsAHungarianCorrectingInvoice */

    if    adm.config.cls.DCCAppConfigSvc:prpoInstance:lParameterValue('VF_P_CorrectingInvoiceOnlyModLines':U) = yes
      and VBCPolandHungarySpecialsSvc:prpoInstance:lIsAPolishCorrectingInvoice
                                                  (ttV_BelegKopf-P.BelegArt,
                                                   ttV_BelegKopf-P.ReferenzNr)
      and (   ttV_BelegPos-P.P_storniertePos  > 0
           or ttV_BelegPos-P.P_korrigiertePos > 0)
      and VBCSalesDocSvc:prpoInstance:lPisModCorrectedLine(ttV_BelegPos-P.V_BelegPos_Obj) = no then
    do:

      delete ttV_BelegPos-P.
      next.

    end. /* if ... lIsAPolishCorrectingInvoice */

    /* The positon must have one part -  if the field Artikel is not empty    */
    /* e.g. sum positions - that  is loaded now to allow all following code   */
    /* in the for each and called procedures to use the correct buffer        */
    /* without loading it again...                                            */
    /* No second find of ttS_Artikel-P is allowed in this programm!           */

    if ttV_BelegPos-P.Artikel > '':U then

      find ttS_Artikel-P
        where ttS_Artikel-P.Firma   = ttV_BelegPos-P.Firma
          and ttS_Artikel-P.Artikel = ttV_BelegPos-P.Artikel.

    /*------------------------------------------------------------------------*/
    /* In case of Artikel being pa_S_PT_ConfiguredPart                        */
    /* Get and fill WuP-relevant Teile-ID value for Materialnummer field      */
    /*------------------------------------------------------------------------*/

    &IF LOOKUP("Q_AEBW":U,"{&PA-OPTIONEN}":U) > 0 &THEN

      if available  ttS_Artikel-P
        and         ttS_Artikel-P.ArtikelArt = {&pa_S_PT_ConfiguredPart}
        and can-do ('U,L,VUD,VFP,R':U,ttV_BelegKopf-P.BelegArt) then

        ttV_BelegPos-P.Materialnummer = gateway.cls.GMCOaPSvc:prpoInstance:cGetCorrectPartName
                                          (ttS_Artikel-P.Artikel,
                                           ttV_BelegPos-P.V_BelegPos_Obj).
    &ENDIF

    /*------------------------------------------------------------------------*/
    /*   Fill ttS_PreisEinheit-PPos                                           */
    /*------------------------------------------------------------------------*/

      if    available ttS_Artikel-P
        and not can-find(bttS_PreisEinheit-PPos
                           where bttS_PreisEinheit-PPos.Firma        = ttS_Artikel-P.Firma
                             and bttS_PreisEinheit-PPos.Preiseinheit = ttS_Artikel-P.Preiseinheit) then
      do:

        find bS_PreisEinheit
          where bS_PreisEinheit.Firma        = {firma/spreeinh.fir ttS_Artikel-P.Firma}
            and bS_PreisEinheit.Preiseinheit = ttS_Artikel-P.Preiseinheit
          no-lock no-error.

        if available bS_PreisEinheit then
        do:

          create bttS_PreisEinheit-PPos.
          {buffer-copy
             bS_PreisEinheit
             to bttS_PreisEinheit-PPos
             assign
               "bttS_PreisEinheit-PPos.Firma = ttS_Artikel-P.Firma"}

        end. /* if available bS_PreisEinheit */

      end. /* if not can-find(bttS_PreisEinheit-P... */

    /*------------------------------------------------------------------------*/
    /*  Calculated Line Values                                                */
    /*------------------------------------------------------------------------*/

    create ttVB_CalculatedLineValues-P1.

    /* Filling Eur_Factor enables the API LLFillLineValuesTT to fill the      */
    /* EUR_ fields.                                                           */

    assign
      ttV_BelegPos-P.Gesamtpreis_Vertrag      = ttV_BelegPos-P.Gesamtpreis
      ttVB_CalculatedLineValues-P1.Eur_Factor =  ttS_Waehrung-P1.Eurofaktor
      .

    /* Get calculated line values */

    vert.base.cls.VBCSalesDocSvc:prpoInstance:LLFillLineValuesTT
      (ttV_BelegPos-P.V_BelegPos_Obj,
       gcContentLanguage,
       '':U,
       buffer ttV_BelegPos-P:handle,
       buffer ttVB_CalculatedLineValues-P1:handle).

    validate ttVB_CalculatedLineValues-P1.

    /* ttV_BelegPos-P.Gesamtpreis / ttVB_CalculatedLineValues-P1.Eur_TotalPrice  */
    /* are overwritten depending on glPositions flag! If the flag has been set   */
    /* to YES, only the open total is used - the field Gesamtpreis which usually */
    /* holds the total, is overwritten with field Gesamtpreis_offen which holds  */
    /* the open total. As Eur_TotalPrice is based on Gesamtpreis, it needs to    */
    /* recalculated too.                                                         */

    if ttV_BelegPos-P.offen
      and glPositions  then

      assign
        ttV_BelegPos-P.Gesamtpreis                  = ttV_BelegPos-P.Gesamtpreis_offen
        ttVB_CalculatedLineValues-P1.Eur_TotalPrice = ttV_BelegPos-P.Gesamtpreis / ttS_Waehrung-P1.Eurofaktor
        .

    if pACConnectionSvc:prpcLocalization = 'H':U then

      assign
        ttVB_CalculatedLineValues-P1.H_GrossPrice        = ttV_BelegPos-P.Gesamtpreis * ((ttV_BelegPos-P.SteuerSatz / 100) + 1)
        ttVB_CalculatedLineValues-P1.H_GrossPriceRounded = round(ttVB_CalculatedLineValues-P1.H_GrossPrice, ttV_BelegKopf-P.WaehrungNK)
        ttVB_CalculatedLineValues-P1.H_TaxAmount         = ttVB_CalculatedLineValues-P1.H_GrossPrice - ttV_BelegPos-P.Gesamtpreis
        ttVB_CalculatedLineValues-P1.H_TaxAmountRounded  = ttVB_CalculatedLineValues-P1.H_GrossPriceRounded - ttV_BelegPos-P.Gesamtpreis
        ttVB_CalculatedLineValues-P1.H_TaxDifference     = ttVB_CalculatedLineValues-P1.H_TaxAmount - ttVB_CalculatedLineValues-P1.H_TaxAmountRounded
        ttVB_CalculatedLineValues-P1.H_EffectivePrice    = ttV_BelegPos-P.Einzelpreis * (1 + ttV_BelegPos-P.proz_RZ_1 / 100)
                                                                                      * (1 + ttV_BelegPos-P.proz_RZ_2 / 100)
                                                                                      * (1 + ttV_BelegPos-P.proz_RZ_3 / 100)
                                                                                      * (1 + ttV_BelegPos-P.proz_RZ_4 / 100)
                                                                                      * (1 + ttV_BelegPos-P.proz_RZ_5 / 100)
                                                                                      + (ttV_BelegPos-P.Wert_RZ_1 
                                                                                         + ttV_BelegPos-P.Wert_RZ_2 
                                                                                         + ttV_BelegPos-P.Wert_RZ_3 
                                                                                         + ttV_BelegPos-P.Wert_RZ_4 
                                                                                         + ttV_BelegPos-P.Wert_RZ_5)
        .

    &IF LOOKUP("U_CA":U,"{&PA-OPTIONEN}":U) > 0 &THEN

      if ttV_BelegKopf-P.Belegart = 'GSA':U then

        run uFillCreditMemo in target-procedure.

    &ENDIF

    /* load country and region of origin from lots or parts master data       */

    if available ttS_Artikel-P then
    do:

      assign
        cCountryOfOrigin = '':U
        iRegionOfOrigin  = 0
        .

      &IF (lookup("MC":U,"{&PA-MODULE}":U) > 0) &THEN
        cCharge = mawi.charge.cls.MCCLotSvc:prpoInstance:cUniqueLot
                    (ttV_BelegPos-P.V_BelegPos_Obj,
                     (if ttV_BelegPos-P.BelegArt = 'VUD':U then
                        '':U
                      else
                        'ar':U),
                     ttV_BelegPos-P.LagerOrt).

        if cCharge > '':U then
        do:

          oLotCountryRegionOfOrigin = MMCCountryOfOriginSvo:create
                                        (ttV_BelegPos-P.Artikel,
                                         cCharge,
                                         '':U).

          assign
            cCountryOfOrigin = oLotCountryRegionOfOrigin:prpcCountry
            iRegionOfOrigin  = oLotCountryRegionOfOrigin:prpiRegion
            .

        end. /* if cCharge > '':U */
      &ENDIF

      {adm/incl/d__spr00.if
        &Tabelle  = "bS_StaatSpr-Origin"
        &Selekt   = "where bS_StaatSpr-Origin.Staat = (if cCountryOfOrigin > '':U then
                                                         cCountryOfOrigin
                                                       else
                                                         ttS_Artikel-P.Ursprungsland)"
        &Sprache  = "gcContentLanguage"
        &no-error = "no-error"}

      assign
        ttV_BelegPos-P.CountryOfOriginDesc = (if available bS_StaatSpr-Origin then
                                                bS_StaatSpr-Origin.Bezeichnung
                                              else
                                                '':U)
        ttV_BelegPos-P.RegionOfOriginDesc  = SBCBusinessCategorySvc:prpoInstance:cGetRegionDescription
                                               ((if cCountryOfOrigin > '':U then
                                                   cCountryOfOrigin
                                                 else
                                                   ttS_Artikel-P.Ursprungsland),
                                                (if iRegionOfOrigin > 0 then
                                                   iRegionOfOrigin
                                                 else
                                                   ttS_Artikel-P.Bundesland))
        .

    end. /* if available ttS_Artikel-P */

    /* load the correcponding calculated line from ttV_BelegSumPos-Calc which */
    /* is needed in fillDocumentLineCalculatedFieldsForLLPrint.               */

    find ttV_BelegSumPos-Calc
      where ttV_BelegSumPos-Calc.LfdNr_SR    = ttV_BelegPos-P.LfdNr_SR
        and ttV_BelegSumPos-Calc.PositionsNr = ttV_BelegPos-P.PositionsNr.

    /* There are some calculated fields that are not found in                 */
    /* ttVB_CalculatedLineValues-P1 but directly in ttV_BelegPos-P because    */
    /* the are special or dependant of flag glPositions (which is not         */
    /* considered by API LLFillLineValuesTT)                                  */
    /* Those fields are calculated in the following procedure call.           */

    run fillDocumentLineCalculatedFieldsForLLPrint in target-procedure.


    &IF LOOKUP("Q_DEL","{&PA-OPTIONEN}") > 0 &THEN

    /* Fill Metal temp-tables                                                 */

    SBCMetalSvc:prpoInstance:fillMetalsTTForLLPrint
      (ttV_BelegPos-P.V_BelegPos_Obj,
       input-output table ttSBM_Metal-P by-reference,
       input-output table ttSBT_Metal-P by-reference).

    for each ttSBT_Metal-P
      no-lock:

    &IF LOOKUP("E_":U,"{&PA-MODULE}":U) > 0  &THEN
      eink.base.cls.EBCFillPrintTTSvc:prpoInstance:FillStorageUnitByIDForLLPrint
        (ttSBT_Metal-P.UnitOfMeasure,
         input-output table ttS_MengenEinheit-PMet by-reference).
    &ENDIF

    end. /* for each ttSBT_Metal-P */

    &ENDIF

    &IF lookup ("V_Anz":U,"{&PA-OPTIONEN}":U) > 0 &THEN

    /* Advance payments are calculated for each document line that            */
    /* constitutes such a payment.                                            */

    if ttV_BelegPos-P.Anz_BelegArt  > '':U then
      run fillAdvancePaymentLineForLLPrint in target-procedure.


    &ENDIF

    run FillPricesBlanketOrCallSalesOrderForLLPrint in target-procedure.

    /*------------------------------------------------------------------------*/
    /* Part description is always provided additionally  in default language, */
    /* because sometimes translations of technical specifications used are so */
    /* poor, that users prefer the original term...                           */
    /*------------------------------------------------------------------------*/

    if not can-find(ttS_ArtikelSpr-P
                where ttS_ArtikelSpr-P.Firma   = gcFirma
                  and ttS_ArtikelSpr-P.Artikel = ttV_BelegPos-P.Artikel
                  and ttS_ArtikelSpr-P.Sprache = {&pa_Defaultsprache}) then
    do:

      {adm/incl/d__spr00.if
         &Tabelle = "bS_ArtikelSpr"
         &Selekt  = "where bS_ArtikelSpr.Firma   = {firma/sartikel.fir gcFirma}
                       and bS_ArtikelSpr.Artikel = ttV_BelegPos-P.Artikel"
         &Sprache  = "{&pa_Defaultsprache}"
         &no-error = "no-error"
      }

      if available bS_ArtikelSpr then
      do:

        create ttS_ArtikelSpr-P.

        {buffer-copy
           bS_ArtikelSpr
           to ttS_ArtikelSpr-P
           assign
             "ttS_ArtikelSpr-P.Firma = gcFirma"}

      end. /* if available bS_ArtikelSpr */

    end. /* if not can-find(ttS_ArtikelSpr-P */

    /* Reserved quantity is no field in V_BelegPos -> fill it manually */

    ttV_BelegPos-P.reservierte_Menge = mawi.base.cls.MMCMRPLinkSvc:prpoInstance:dReservedOnHand
                                         (ttV_BelegPos-P.Belegart, 
                                          ttV_BelegPos-P.V_BelegPos_Obj).

    /* It iss sufficient to just check for ArtVar to guarantee that           */
    /* ttS_Artikel-P is available, because sum positions or other positions   */
    /* without "real" part have no variant either...                          */

    if ttV_BelegPos-P.Artvar > '':U then
    do:

      /*----------------------------------------------------------------------*/
      /* ttS_ArtVar-P must be filled manually because field                   */
      /* ttV_BelegPos-P.ArtVarTyp is needed to determine the right records,   */
      /* but this field is not yet filled during run super() of fillDataset.  */
      /*----------------------------------------------------------------------*/

      ttV_BelegPos-P.ArtVarTyp = ttS_Artikel-P.ArtVarTyp.

      find bS_ArtVar
        where bS_ArtVAr.ArtVarTyp = ttV_BelegPos-P.ArtVarTyp
          and bS_ArtVAr.ArtVar    = ttV_BelegPos-P.Artvar
        no-lock.

      if not can-find(ttS_ArtVar-P
                        where ttS_ArtVar-P.ArtVarTyp = ttV_BelegPos-P.ArtVarTyp
                          and ttS_ArtVar-P.ArtVar    = ttV_BelegPos-P.Artvar) then

      do:

        create ttS_ArtVar-P.
        {buffer-copy
           bS_ArtVAr
           to ttS_ArtVar-P}

      end.

    end. /* ttV_BelegPos-P.Artvar > '':U */

    if can-do('L,VUD,R,VFP':U,ttV_BelegKopf-P.BelegArt) then

      ttV_BelegPos-P.PrintDocPositionOaPText =     available bSBM_OaPTexts
                                               and (   lOaPText = yes
                                                    or (    available ttS_Kunde-P1
                                                        and ttS_Kunde-P1.OaPText = yes
                                                        and adm.config.cls.DCCAppConfigSvc:prpoInstance:lParameterValue('GM_OaPAlwaysPrintPreferenceTexts':U)))
                                               and ttV_BelegPos-P.Ursprungszeugnis = no.   

    /*------------------------------------------------------------------------*/
    /* Lot information of document lines                                      */
    /*------------------------------------------------------------------------*/

    &IF LOOKUP("MC":U,"{&PA-MODULE}":U) > 0 &THEN

    if available ttS_Artikel-P
      and ttS_Artikel-P.Chargenart > '':U then

      mawi.charge.cls.MCCLotSvc:prpoInstance:PrintLotInformations
                                              (ttV_BelegPos-P.V_BelegPos_Obj,
                                               ttV_BelegPos-P.LagerOrt,
                                               ttV_BelegPos-P.Belegart,
                                               ttV_BelegPos-P.Artikel,
                                               '':U,
                                               gcContentLanguage,
                                               input-output table ttMCL_LotMovements-P).

    &ENDIF

    /*------------------------------------------------------------------------*/
    /* serial number information of document line                             */
    /*------------------------------------------------------------------------*/

    &IF LOOKUP("MS","{&PA-MODULE}") > 0 &THEN

      run fillDocumentSerialNoForLLPrint in target-procedure.

    &ENDIF

    /*------------------------------------------------------------------------*/
    /* Packing List  -> Section: P   Subsection: MP                           */
    /*------------------------------------------------------------------------*/

    &IF LOOKUP("MP","{&PA-MODULE}") > 0 &THEN

      run FillStorageLocationForLLPrint in target-procedure.

    &ENDIF

    /*------------------------------------------------------------------------*/
    /* Call order  -> Section: P    Subsection: AB                            */
    /*------------------------------------------------------------------------*/

    &IF lookup("VU_ABAUF":U,"{&PA-OPTIONEN}":U) > 0 &THEN

    run fillCallOrderReleaseInfoForLLPrint in target-procedure.

    &ENDIF

    /*------------------------------------------------------------------------*/
    /* PostBillingLine  -> Section: P    Subsection: VPB                      */
    /*------------------------------------------------------------------------*/

    &IF lookup("U_CA":U,"{&PA-OPTIONEN}":U) > 0 &THEN

    run fillPostBillingLineInfoForLLPrint in target-procedure.

    &ENDIF  /* lookup "U_CA" */

    /*------------------------------------------------------------------------*/
    /* Blanket order  -> Section: P    Subsection: AR                         */
    /*------------------------------------------------------------------------*/

    &IF lookup("VU_RAAUF":U,"{&PA-OPTIONEN}":U) > 0 &THEN

    run fillBlanketOrderInfoForLLPrint in target-procedure.

    &ENDIF  /* lookup "VU_RAAUF" */

    /*------------------------------------------------------------------------*/ 
    /* Blanket Order form  -> Section: P Subsection: UBA                      */
    /*------------------------------------------------------------------------*/

    &IF LOOKUP("U_CA":U,"{&PA-OPTIONEN}":U) > 0 &THEN

    run uFillReservedOrdersSection in target-procedure.

    &ENDIF  

    /*------------------------------------------------------------------------*/ 
    /* Blanket Order form  -> Section: P Subsection: ULP                      */
    /*------------------------------------------------------------------------*/

    &IF LOOKUP("U_CA":U,"{&PA-OPTIONEN}":U) > 0 &THEN
    run uFillDeliveryScheduleDatesSection in target-procedure.
    &ENDIF  

    /*------------------------------------------------------------------------*/
    /* Delivery notes  -> Section: P Subsection: LS / LMS                     */
    /*------------------------------------------------------------------------*/

    run fillShippingDocumentsForLLPrint in target-procedure.

    /*------------------------------------------------------------------------*/
    /* Origin Order  -> Section: P Subsection: UAU                            */
    /*------------------------------------------------------------------------*/

    &IF LOOKUP("U_CI":U,"{&PA-OPTIONEN}":U) > 0 &THEN

    run uFillOrderSection in target-procedure.

    &ENDIF

    /*------------------------------------------------------------------------*/
    /* Credit Information -> Section: P Subsection: UBO                       */
    /*------------------------------------------------------------------------*/

    &IF lookup("U_CI":U,"{&PA-OPTIONEN}":U) > 0 &THEN

    run uFillCreditInformation in target-procedure.

    &ENDIF

    /*------------------------------------------------------------------------*/
    /* Service order -> Section: P Subsection: VS                             */
    /*------------------------------------------------------------------------*/

    &IF lookup("VS_SAUF":U,"{&PA-OPTIONEN}":U) > 0 &THEN

    run fillServiceOrderInfoForLLPrint in target-procedure.

    &ENDIF

    /*------------------------------------------------------------------------*/
    /* Call -> Section: P Subsection: CA                                      */
    /*------------------------------------------------------------------------*/

    &IF lookup("VS_CALL","{&PA-OPTIONEN}") > 0 &THEN

    run fillCALLforLLPrint in target-procedure.

    &ENDIF

    /*------------------------------------------------------------------------*/
    /* Call -> Section: P Subsection: CA    only Credits                      */
    /*------------------------------------------------------------------------*/

    &IF lookup("VS_SAUF":U,"{&PA-OPTIONEN}":U) > 0 &THEN

    run fillServiceOrderInfoForLLPrint in target-procedure.

    &ENDIF
    /*------------------------------------------------------------------------*/
    /* Maintenance agreement -> Section: P Subsection: VW                     */
    /*------------------------------------------------------------------------*/

    &IF lookup("VS_WVERT":U,"{&PA-OPTIONEN}":U) > 0 &THEN

    run fillMaintenanceAgreementInfoForLLPrint in target-procedure.

    &ENDIF

    /*------------------------------------------------------------------------*/
    /* Call Sales Order -> Section: PA Subsection: PAP                        */
    /*------------------------------------------------------------------------*/

    &IF lookup("VU_ABAUF_FZ":U,"{&PA-OPTIONEN}":U) > 0 &THEN

    run FillPricesAlternatepartForLLPrint in target-procedure.

    &ENDIF

    /*------------------------------------------------------------------------*/
    /* Fill DropShipping of position info                                     */
    /*------------------------------------------------------------------------*/

    run fillDropShippingPositionInfo in target-procedure.

    /*------------------------------------------------------------------------*/
    /* Quote -> Section: P Subsection: KP                                     */
    /*------------------------------------------------------------------------*/

    &IF LOOKUP("VN_KALK":U,"{&PA-OPTIONEN}":U) > 0 &THEN

    run fillQuotationCostingForLLPrint in target-procedure.

    &ENDIF

    for each ttV_BelegStueli-P
      where ttV_BelegStueli-P.Firma       = {firma/vbelegko.fir gcFirma}
        and ttV_BelegStueli-P.Belegart    = ttV_BelegPos-P.Belegart
        and ttV_BelegStueli-P.ReferenzNr  = ttV_BelegPos-P.ReferenzNr
        and ttV_BelegStueli-P.lfdNr_SR    = ttV_BelegPos-P.lfdNr_SR
        and ttV_BelegStueli-P.PositionsNr = ttV_BelegPos-P.PositionsNr:

      /* The set parts must exist in TT ttS_Artikel-PSet...                   */

      find ttS_Artikel-PSet
        where ttS_Artikel-PSet.Firma      = ttV_BelegStueli-P.Firma
          and ttS_Artikel-PSet.Artikel    = ttV_BelegStueli-P.Artikel.

      /* calculate unit price rounded to WaehrungNK of document and           */
      /* Eur_UnitPrice.                                                       */

      assign
        ttV_BelegStueli-P.UnitPriceRounded     =  round(ttV_BelegStueli-P.Einzelpreis,
                                                        ttV_BelegKopf-P.WaehrungNK)
        ttV_BelegStueli-P.TotalQuantity        = ( ttV_BelegPos-P.Menge
                                                  - ttV_BelegPos-P.gelieferte_Menge
                                                  - ttV_BelegPos-P.stornierte_Menge)
                                                  * ttV_BelegStueli-P.EinzelMenge
       .

      if ttS_Waehrung-P1.Eurofaktor > 0
        and not ttS_Waehrung-P1.ISO_KurzBez = 'EUR':U then

        ttV_BelegStueli-P.Eur_UnitPrice = ttV_BelegStueli-P.Einzelpreis / ttS_Waehrung-P1.Eurofaktor.

      /*----------------------------------------------------------------------*/
      /* Lot information of set lines                                         */
      /*----------------------------------------------------------------------*/

      &IF LOOKUP("MC":U,"{&PA-MODULE}":U) > 0 &THEN

      if ttS_Artikel-PSet.Chargenart > '':U then

        mawi.charge.cls.MCCLotSvc:prpoInstance:PrintLotInformations
                                                 (ttV_BelegStueli-P.V_BelegStueli_Obj,
                                                  ttV_BelegStueli-P.LagerOrt,
                                                  ttV_BelegStueli-P.BelegArt,
                                                  ttV_BelegStueli-P.Artikel,
                                                  '':U,
                                                  gcContentLanguage,
                                                  input-output table ttMCL_LotMovements-PSetLine).

      &ENDIF  /* MC */

      /*----------------------------------------------------------------------*/
      /* Serial numbers of set lines                                          */
      /*----------------------------------------------------------------------*/

      &IF LOOKUP("MS","{&PA-MODULE}") > 0 &THEN

      mawi.serie.cls.MSCSerialNoSvc:prpoInstance:GetSNForDocument
        (             ttV_BelegStueli-P.V_BelegStueli_Obj,
         input-output table ttMS_SNR-P1Set by-reference).

      ttV_BelegStueli-P.SerialNumber = mawi.serie.cls.MSCSerialNoSvc:prpoInstance:clCreateSerialNoAsText
                                         (ttV_BelegStueli-P.V_BelegStueli_Obj,
                                          (if    ttV_BelegPos-P.Belegart = 'U':U
                                             and glPositions             = yes
                                             and ttV_BelegKopf-P.offen   = yes then
                                             no
                                           else
                                             yes)).

      &ENDIF  /* MS */

      /*----------------------------------------------------------------------*/
      /* customer part information of set lines                               */
      /*----------------------------------------------------------------------*/

      if not can-find(ttS_ArtKunde-PSet
                        where ttS_ArtKunde-PSet.Artikel = ttV_BelegStueli-P.Artikel) then
      do:

        find bS_ArtKunde-Set
          where bS_ArtKunde-Set.Firma   = {firma/sartkund.fir gcFirma}
            and bS_ArtKunde-Set.Kunde   = iCustomer
            and bS_ArtKunde-Set.Artikel = ttV_BelegStueli-P.Artikel
          no-lock no-error.

        if available bS_ArtKunde-Set then
        do:

          create ttS_ArtKunde-PSet.

          {buffer-copy
             bS_ArtKunde-Set
             except "Firma"
             to ttS_ArtKunde-PSet
             assign
               "ttS_ArtKunde-PSet.Firma = gcFirma"}

        end. /* available bS_ArtKunde-Set */
      end.  /* not can-find ttS_ArtKunde-PSet */

      /*----------------------------------------------------------------------*/
      /* ArtVar / ArtVarTyp information of set parts                          */
      /*----------------------------------------------------------------------*/

      if ttV_BelegStueli-P.Artvar > '':U then
      do:

        /*--------------------------------------------------------------------*/
        /* ttS_ArtVar-P1Set must be filled manually because                   */
        /* field ttV_BelegStueli-P.ArtVarTyp is needed to determine  the      */
        /* right records, but this field is not yet filled during run         */
        /* super() of fillDataset.                                            */
        /*--------------------------------------------------------------------*/

        ttV_BelegStueli-P.ArtVarTyp = ttS_Artikel-PSet.ArtVarTyp.

        if not can-find(ttS_ArtVar-P1Set
                          where ttS_ArtVar-P1Set.ArtVarTyp   = ttV_BelegStueli-P.ArtVarTyp
                            and ttS_ArtVar-P1Set.ArtVar      = ttV_BelegStueli-P.Artvar) then

        do:

          find bS_ArtVar
            where bS_ArtVAr.ArtVarTyp = ttV_BelegStueli-P.ArtVarTyp
              and bS_ArtVAr.ArtVar    = ttV_BelegStueli-P.Artvar
            no-lock.

          create ttS_ArtVar-P1Set.
          {buffer-copy
             bS_ArtVAr
             to ttS_ArtVar-P1Set}

        end.

      end. /* ttV_BelegPos-P.Artvar > '':U */

      if not can-find(bttS_MengenEinheit-PSet
                        where bttS_MengenEinheit-PSet.Firma         = gcFirma
                          and bttS_MengenEinheit-PSet.Mengeneinheit = ttV_BelegStueli-P.Mengeneinheit) then
      do:

        find bS_Mengeneinheit
          where bS_Mengeneinheit.Firma         = {firma/smngeinh.fir gcFirma}
            and bS_Mengeneinheit.Mengeneinheit = ttV_BelegStueli-P.Mengeneinheit
          no-lock no-error.

        if available bS_Mengeneinheit then
        do:

          create bttS_MengenEinheit-PSet.
          {buffer-copy
             bS_Mengeneinheit
             to bttS_MengenEinheit-PSet}

        end. /* if available bS_Mengeneinheit then */

      end. /* if not can-find (bttS_MengenEinheit-PSet */

    end. /*  each ttV_BelegStueli-P */

    /* tax information of document line */

    run fillDocumentLineTaxForLLPrint in target-procedure.

    if    pACConnectionSvc:prpcLocalization = 'H':U
      and ttV_BelegKopf-P.BelegArt          = 'R':U
      and ttV_BelegKopf-P.H_InvoiceType     = 2 then

      run H_fillCorrectionInvoiceDiffForLLPrint in target-procedure.

    /*------------------------------------------------------------------------*/
    /* Invoice for drop shipment order: determine suppliers tax ID for line   */
    /*------------------------------------------------------------------------*/

    &IF lookup("ER","{&PA-MODULE}") > 0 &THEN

    /* Determine the suppliers tax id by the A/P Invoice Voucher if we are in an */
    /* invoice for a drop shipment order. This is only possible if there is only */
    /* one purchase order for the order line.                                    */

    if    ttV_BelegPos-P.BelegArt      = 'R':U
      and ttV_BelegPos-P.Herk_BelegArt = 'U':U
      /* --> WH2015-07-011 cpl Sammelstreckenfaktura */
      &IF LOOKUP("U_CI":U,"{&PA-OPTIONEN}":U) > 0 &THEN
      and ttV_BelegPos-P.uCI_Vertriebsweg = {&uCI_VertriebswegStrecke} then
      &ELSE
      and ttV_BelegKopf-P.Strecke      = yes then
      &ENDIF
      /* <-- WH2015-07-011 cpl Sammelstreckenfaktura */


      run FillLineSupplierTaxIDForLLPrint in target-procedure.

    &ENDIF

  end. /* for each ttV_BelegPos-P */


  /*--------------------------------------------------------------------------*/
  /*                                                                          */
  /*  Further header information that might depend processed line information */
  /*                                                                          */
  /*--------------------------------------------------------------------------*/

  /*--------------------------------------------------------------------------*/
  /* calculate document taxrate dependent summation information               */
  /*--------------------------------------------------------------------------*/

  if VBCPolandHungarySpecialsSvc:prpoInstance:lIsAPolishCorrectingInvoice
                                                (ttV_BelegKopf-P.BelegArt,
                                                 ttV_BelegKopf-P.ReferenzNr) then
  do:
    run P_fillK_OrgDocTaxrateSumsForLLPrint in target-procedure.
    run P_fillK_OrgDocTotalSumForLLPrint in target-procedure.
    run P_fillK_CorDocTaxrateSumsForLLPrint in target-procedure.
    run P_fillK_CorDocTotalSumForLLPrint in target-procedure.
  end.

  giDecimalsDomCur = {fn pa_iCurDecimalsOfDomCur}.
  if SBCLocalizationSvc:prpoInstance:lIsLocalizationItaly() then 
    run I_fillDocumentTaxrateSumsForLLPrint in target-procedure.
  else 
    run fillDocumentTaxrateSumsForLLPrint in target-procedure.

  if SBCLocalizationSvc:prpoInstance:lIsLocalizationHungary() then 

    run H_fillDocumentTaxrateSumsForLLPrint in target-procedure.

  /*--------------------------------------------------------------------------*/
  /* caculate document total sum information                                  */
  /*--------------------------------------------------------------------------*/

  run fillDocumentTotalSumForLLPrint in target-procedure.

  if SBCLocalizationSvc:prpoInstance:lIsLocalizationHungary() then 

    run H_fillDocumentTotalSumForLLPrint in target-procedure.

  if pACConnectionSvc:prpcLocalization = 'A':U then

    run A_fillDocumentTotalSumForLLPrint in target-procedure.

  /*--------------------------------------------------------------------------*/
  /* calculate surcharges of document header                                  */
  /*--------------------------------------------------------------------------*/

  run fillDocumentSurchargesForLLPrint in target-procedure.

  /*--------------------------------------------------------------------------*/
  /* fill bank account information for the header.                            */
  /*--------------------------------------------------------------------------*/

  run fillDocumentBankForLLPrint in target-procedure.

  /*--------------------------------------------------------------------------*/
  /* fill tax information of document header                                  */
  /*--------------------------------------------------------------------------*/

  run fillDocumentTaxForLLPrint in target-procedure.

  /*--------------------------------------------------------------------------*/
  /* prepare printmasks of manual credit terms                                */
  /*--------------------------------------------------------------------------*/

  run fillCreditTermsForLLPrint in target-procedure.

  /*--------------------------------------------------------------------------*/
  /*  Fill global L&L Variables                                               */
  /*--------------------------------------------------------------------------*/

  run fillProviderVariablesForLLPrint in target-procedure.

  /* Fill profit center address */

  &IF LOOKUP("S_ProfCenter","{&PA-OPTIONEN}") > 0 &THEN
    SBCProfitCenterSvc:prpoInstance:GetProfitCenterAddressTT
      (                   ttV_BelegKopf-P.SBM_ProfitCenter_Obj,
       input-output table ttS_Adresse-P by-reference).

    find first ttS_Adresse-P
      no-lock no-error.

    if available ttS_Adresse-P then
    do:

      create ttS_Adresse-P16PC.
      {buffer-copy
         ttS_Adresse-P
         to ttS_Adresse-P16PC
         assign
           "ttS_Adresse-P16PC.Firma = ttV_BelegKopf-P.Firma"}

      /* Fill AdrRow fields */

      {vert/base/incl/vb_bel00.if
         &ippSourceAdrTable = "ttS_Adresse-P"
         &ippTargetTable    = "ttS_Adresse-P16PC"
      }

      empty temp-table ttS_Adresse-P.

    end. /* if available ttS_Adresse-P then */

  &ENDIF

  /* Fill tracking info */

  find last bVUT_TrackingInfoHead
    where bVUT_TrackingInfoHead.Owning_Obj = ttV_BelegKopf-P.V_BelegKopf_Obj
    no-lock no-error.

  if available bVUT_TrackingInfoHead then
  do:

    for each bVUT_TrackingInfoLine
      where bVUT_TrackingInfoLine.VUT_TrackingInfoHead_Obj = bVUT_TrackingInfoHead.VUT_TrackingInfoHead_Obj
      no-lock
      on error undo, throw:

      create ttVUT_TrackingInfoLine-P.

      {buffer-copy
         bVUT_TrackingInfoLine
         to ttVUT_TrackingInfoLine-P
         assign
           "ttVUT_TrackingInfoLine-P.Owning_Obj = ttV_BelegKopf-P.V_BelegKopf_Obj"}

    end. /* for each VUT_TrackingInfoLine */

  end. /* if available VUT_TrackingInfoHead */

  /*--------------------------------------------------------------------------*/
  /* Invoice for drop shipment order: determine suppliers tax ID for header   */
  /*--------------------------------------------------------------------------*/

  &IF lookup("ER","{&PA-MODULE}") > 0 &THEN

  if    ttV_BelegKopf-P.BelegArt      = 'R':U
    and ttV_BelegKopf-P.Herk_BelegArt = 'U':U
    /* --> WH2015-07-011 cpl Sammelstreckenfaktura */
    &IF LOOKUP("U_CI":U,"{&PA-OPTIONEN}":U) > 0 &THEN
    and can-find(first ttV_BelegPos-P of ttV_BelegKopf-P
                 where ttV_BelegPos-P.uCI_Vertriebsweg = {&uCI_VertriebswegStrecke}) then
    &ELSE
    and ttV_BelegKopf-P.Strecke      = yes then
    &ENDIF
    /* <-- WH2015-07-011 cpl Sammelstreckenfaktura */


    run FillHeadSupplierTaxIDForLLPrint in target-procedure.

  &ENDIF

  /*--------------------------------------------------------------------------*/
  /* Fill factoring bank data if there is an valid factor assignment and it is*/
  /* not an partial payment invoice                                           */
  /*--------------------------------------------------------------------------*/

  if glFactoring then
    run fillFactorBankDataForLLPrint in target-procedure.

  /*--------------------------------------------------------------------------*/
  /* ZUGFeRD integration                                                      */
  /*--------------------------------------------------------------------------*/

  if    (   lPrintZUGFeRD
         or lSendXRechnung)
    and cZUGFeRDProfile <> GBCZUGFeRDProfiles:None then
  do:
    // Legacy implementation. Should only be used in maintenance cases.
    if DCCAppConfigSvc:prpoInstance:lParameterValue('VF_eInvoiceUseLegacyXMLCreation':U) then
    do:

      // Mapping of "old" ZUGFeRD-Format to new ZUGFeRD Profile
      // Old provided ZUGFeRD versions (+ XRechnung combined with highest ZUGFeRD
      // version). New uses just the profiles in the highest available ZUGFeRD 
      // version. So XRECHNUNG --> 'X'; COMFORT / EXTENDED --> '2.1.1'
      case cZUGFeRDProfile:
        when GBCZUGFeRDProfiles:XRECHNUNG then
          cZUGFeRDProfile = GBCZUGFeRDVersions:XRechnung.
        when GBCZUGFeRDProfiles:COMFORT 
          or when GBCZUGFeRDProfiles:EXTENDED then
          cZUGFeRDProfile = GBCZUGFeRDVersions:ZUGFeRDVersion_2_1_1.
      end case.
      
      oZugferd = SBCZugFerdInvoice:oGetNewZugferdInvoice(cZUGFeRDProfile).
  
      oZugferd:SetdDatasetdsV_BelegKopf-P(dataset dsV_BelegKopf-P bind,this-procedure ).
      oZugferd:newZUGFeRDInvoice(cZUGFeRDProfile).
      oZugferd:prpcLanguage = gcContentLanguage.
      oZugferd:readProAlphaInvoice().
      lcZUGFeRDInvoice = oZugferd:clGetXMLAsLongchar().
    end. /* VF_eInvoiceUseLegacyXMLCreation */
    else
      lcZUGFeRDInvoice = VFCEN16931CreationSvc:prpoInstance:clCreateEN16931Invoice
                           (ttV_BelegKopf-P.V_BelegKopf_Obj,
                            cZUGFeRDProfile,
                            pACConnectionSvc:prpcLocalization,
                            input-output dataset dsV_BelegKopf-P by-reference).

    // The bBJ_Spool record must exist otherwise the print kernel cannot
    // incorporate the ZugFerd XML into the PDF...
    // otherwise save the xRechnung as an XML in case of sending via INWB

    if not lSendXRechnung then
    do:

      find bBJ_Spool
        where bBJ_Spool.SpoolNr = iSpoolNr
        no-lock.

      /* The bBJT_SpoolDetail record might be locked if a workflow batch        */
      /* is the originator of a PDF-GEN print operation...  (ELBV)              */

      find bBJT_SpoolDetail
        where bBJT_SpoolDetail.BJ_Spool_Obj = bBJ_Spool.BJ_Spool_Obj
          and bBJT_SpoolDetail.SubSpoolNr   = iSubSpoolNr
        exclusive-lock no-wait no-error.

      if available bBJT_SpoolDetail then
      do:

        /* The bBJT_SpoolDetail is available in exclusive-lock and the field    */
        /* ZugferdXML is used to pass the XML to the print kernel.              */

        bBJT_SpoolDetail.ZugferdXML = lcZUGFeRDInvoice.
        validate bBJT_SpoolDetail.
      end.
      else
      do:
        /* The bBJT_SpoolDetail record is locked and a new SBT_SpoolDetail      */
        /* record ( part of the ELBV kernel) is created, then the field         */
        /* OutputContent is used to pass the XML to the print kernel. Cleanup   */
        /* of the SBT_SpoolDetail record is done by the ELBV kernel, once the   */
        /* PDF has been created and stored.                                     */

        create bSBT_Tracking.

        assign
          bSBT_Tracking.SBT_Tracking_Obj  = adm.method.cls.DMCSessionSvc:cObjectID('SBT_Tracking':U)
          bSBT_Tracking.Owning_Obj        = bBJ_Spool.BJ_Spool_Obj
          bSBT_Tracking.TrackingSequence  = iSubSpoolNr
          .

        create bSBT_SpoolDetail.

        assign
          bSBT_SpoolDetail.SBT_Tracking_Obj = bSBT_Tracking.SBT_Tracking_Obj
          bSBT_SpoolDetail.Machine          = bBJ_Spool.Maschine
          bSBT_SpoolDetail.Interface        = bBJ_Spool.Schnittstelle
          bSBT_SpoolDetail.Printer          = bBJ_Spool.Drucker
          .
  
        copy-lob from object lcZUGFeRDInvoice to object bSBT_SpoolDetail.OutputContent.
  
      end.

    end. /* if not lSendXRechnung  */
    else
    /* See method description for why we need to do it that way */
      VFCXInvoiceXMLCreationSvc:prpoInstance:saveXMLInDatabase
        (lcZUGFeRDInvoice, 
         ttV_BelegKopf-P.V_BelegKopf_Obj).

  end.  

end. /* else: if adm.method.cls.DMCSessionSvc:cGetObjectProperty */

{&{&pa-XBasisName}_C_FillDatasetEnd}
{&{&pa-XBasisName}_U_FillDatasetEnd}
{&{&pa-XBasisName}_Q_FillDatasetEnd}
{&{&pa-XBasisName}_FillDatasetEnd}
{&{&pa-XBasisName}_Y_FillDatasetEnd}

finally:
  delete object oZugferd no-error.

end.

end procedure. /* fillDataset */

/* _UIB-CODE-BLOCK-END */
&ANALYZE-RESUME

&ENDIF

&IF DEFINED(EXCLUDE-fillDocumentTotalSumForLLPrint) = 0 &THEN

&ANALYZE-SUSPEND _UIB-CODE-BLOCK _PROCEDURE fillDocumentTotalSumForLLPrint Method-Library 
procedure fillDocumentTotalSumForLLPrint :
/* Description ---------------------------------------------------------------*/
/*                                                                            */
/* Calculates the document total sums.                                        */
/* TT ttV_BelegSumKopf-Calc must be filled before calling this procedure!     */
/*                                                                            */
/* Notes ---------------------------------------------------------------------*/
/*                                                                            */
/* This procedure does only encapsulate code for better readability of        */
/* fillDataset procedure. It can only be used in the context of this DAO      */
/* run super() has been executed and a global ttV_BelegKopf-P Buffer is       */
/* available... so passing of parameters was forgone deliberatly.             */
/*                                                                            */
/*----------------------------------------------------------------------------*/

/* Variables -----------------------------------------------------------------*/
/* clSwissQRCodeContent   content of swiss QR code for QR invoice             */
/*----------------------------------------------------------------------------*/

define variable dGesamtgewicht        like V_BelegPos.Gewicht no-undo.
define variable iTaxRates             as   integer            no-undo.
define variable I                     as   integer            no-undo.
define variable iLastUsedTaxExtent    as   integer            no-undo.
define variable iFirst0RateExtent     as   integer            no-undo.
define variable lVariousTaxRates      as   logical            no-undo.
define variable dTotalNetAmountOC     as   decimal            no-undo. 
define variable dTotalTaxAmountOC     as   decimal            no-undo. 
define variable dTotalNetAmountOCCIT  as   decimal            no-undo. 
define variable dTotalTaxAmountOCCIT  as   decimal            no-undo. 
define variable clSwissQRCodeContent  as   longchar           no-undo.

define buffer bttV_BelegPos-P for temp-table ttV_BelegPos-P.
define buffer bS_Firma        for            S_Firma.
define buffer bS_BankVerb     for            S_BankVerb.


  create ttV_BelegTotalSum-P.
  
  assign
  
    ttV_BelegTotalSum-P.Gesamtsumme    = ttV_BelegSumKopf-Calc.Gesamt_Belegsumme[11]
                                         + ttV_BelegSumKopf-Calc.Gesamtzuschlag
                                         + (if pACConnectionSvc:prpcLocalization = 'I':U then
                                              ttV_BelegSumKopf-Calc.I_SplitPaymentTax
                                            else
                                              0 )
                                         + (if ttV_BelegKopf-P.Brutto = no then /* Nettobeleg oder Bruttobeleg */
                                              ttV_BelegSumKopf-Calc.Gesamtsteuer
                                            else
                                              0)
    ttV_BelegTotalSum-P.Frachtsumme    = ttV_BelegSumKopf-Calc.Frachtsumme
    ttV_BelegTotalSum-P.Owning_Obj     = ttV_BelegKopf-P.V_BelegKopf_Obj
    .
  
  if pACConnectionSvc:prpcLocalization = 'CH':U then
  do:
  
    fix-codepage(clSwissQRCodeContent) = 'utf-8':U.
  
    find bS_Firma
      where bS_Firma.Firma = gcFirma
      no-lock. 
  
    find bS_BankVerb
      where bS_BankVerb.S_BankVerb_Obj = ttV_Belegkopf-P.S_BankVerb_Obj
      no-lock no-error.
  
    if    available bS_BankVerb
      and ttV_Belegkopf-P.IBAN = '':U then
      ttV_Belegkopf-P.IBAN = bS_BankVerb.IBAN. /* IBAN is needed in plain text as well! */
  
   clSwissQRCodeContent =   'SPC':U                                                + {&pa-CRLF}  /* fix value "SPC" (Swiss Payments Code)                   */
                          + '0200':U                                               + {&pa-CRLF}  /* fix value, e.g. "0200 for version 2.0                   */
                          + '1':U                                                  + {&pa-CRLF}  /* fix value "1" (indicating UTF-8)                        */
                          + replace(ttV_Belegkopf-P.IBAN,' ':U,'':U)               + {&pa-CRLF}  /* only "CH" or "LI" IBANs                                 */
                          + 'S':U                                                  + {&pa-CRLF}  /* recipient address type (structured "S" or combined "K") */
                          + trim((if bS_Firma.Anzeigename > '':U then
                                    bS_Firma.Anzeigename
                                  else
                                    bS_Firma.Name1))                               + {&pa-CRLF}  /* recipient name                                          */
                          + trim(bS_Firma.Strasse)                                  + {&pa-CRLF}  /* recipient street                                        */
                          + trim(bS_Firma.Hausnummer)                               + {&pa-CRLF}  /* recipient street number                                 */
                          + trim(bS_Firma.PLZ)                                     + {&pa-CRLF}  /* recipient ZIP code                                      */
                          + trim(bS_Firma.Ort)                                     + {&pa-CRLF}  /* recipient city                                          */
                          + trim(bS_Firma.Staat)                                   + {&pa-CRLF}  /* recipient country                                       */
                          + '':U                                                   + {&pa-CRLF}  /* payee address type (structured "S" or combined "K")     */
                          + '':U                                                   + {&pa-CRLF}  /* payee name           (not supported by 05/2020)         */          
                          + '':U                                                   + {&pa-CRLF}  /* payee street         (not supported by 05/2020)         */          
                          + '':U                                                   + {&pa-CRLF}  /* payee street number  (not supported by 05/2020)         */          
                          + '':U                                                   + {&pa-CRLF}  /* payee ZIP code       (not supported by 05/2020)         */          
                          + '':U                                                   + {&pa-CRLF}  /* payee city           (not supported by 05/2020)         */          
                          + '':U                                                   + {&pa-CRLF}  /* payee country        (not supported by 05/2020)         */          
                          + (if   ttV_Belegkopf-P.GesamtBrutto     > 0
                               or ttV_Belegkopf-P.ZuschlSum_Brutto > 0 then                            
                               replace(trim(string(ttV_BelegTotalSum-P.Gesamtsumme,
                                                   '>>>>>>>>9.99-':U)),
                                                   ',':U,
                                                   '.':U)                                                        /* max. 12 digits ("." as seperator)       */
                             else                                                                                                                            
                               '':U)                                               + {&pa-CRLF}  /* credit or negativ invoice --> no amount                 */
                          + trim(ttS_Waehrung-P1.ISO_KurzBez)                      + {&pa-CRLF}  /* only "CHF" or "EUR"                                     */
                          + 'S':U                                                  + {&pa-CRLF}  /* payer address type (structured "S" or combined "K")     */
                          + trim((if ttS_Adresse-PCust.Vorname > '':U then
                                    ttS_Adresse-PCust.Vorname
                                    + ' ':U
                                  else
                                    '':U)
                                    + ttS_Adresse-PCust.Name1)                     + {&pa-CRLF}  /* payer name                                              */          
                          + trim(ttS_Adresse-PCust.Strasse)                        + {&pa-CRLF}  /* payer street                                            */          
                          + trim(ttS_Adresse-PCust.Hausnummer)                     + {&pa-CRLF}  /* payer street number                                     */          
                          + trim(ttS_Adresse-PCust.PLZ)                            + {&pa-CRLF}  /* payer ZIP code                                          */          
                          + trim(ttS_Adresse-PCust.Ort)                            + {&pa-CRLF}  /* payer city                                              */          
                          + trim(ttS_Adresse-PCust.Staat)                          + {&pa-CRLF}  /* payer country                                           */          
                          + trim(ttV_Belegkopf-P.RemittanceRefType)                + {&pa-CRLF}  /* reference type (QRR, SCOR or NON), max. 4 characters    */
                          + trim(ttV_Belegkopf-P.RemittanceReference)              + {&pa-CRLF}  /* reference, max. 27 characters                           */
                          + trim(ttV_Belegkopf-P.BelegInfo)                        + {&pa-CRLF}  /* unstructured message, max. 140 characters               */
                          + 'EPD':U                                                + {&pa-CRLF}. /* fix value "EPD"                                         */
  
     copy-lob clSwissQRCodeContent to ttV_Belegkopf-P.CH_QRCode no-error.
  
  end. /* if pACConnectionSvc:prpcLocalization = 'CH':U */
  
  if    pACConnectionSvc:prpcLocalization = 'F':U
    and ttV_BelegTotalSum-P.Gesamtsumme   = 0
    and can-do('R,G':U, ttV_BelegKopf-P.Belegart)
    and (   can-find(first V_BelegPos /* There exists no invoiceable lines. */
                     where V_BelegPos.Firma      = ttV_BelegKopf-P.Firma
                       and V_BelegPos.Belegart   = ttV_BelegKopf-P.Belegart
                       and V_BelegPos.ReferenzNr = ttV_BelegKopf-P.ReferenzNr
                       and V_BelegPos.Satzart    = 'A':U)
         /* The total document amount is zero but there are non-zero surcharges. */
         or ttV_BelegKopf-P.Zuschlag[1] <> 0
         or ttV_BelegKopf-P.Zuschlag[2] <> 0
         or ttV_BelegKopf-P.Zuschlag[3] <> 0
         or ttV_BelegKopf-P.Zuschlag[4] <> 0) then
  
    adm.method.cls.DMCMessageSvc:prpoInstance:lShowMessage
      ('vfrecf0002':U,
       string(ttV_BelegKopf-P.Belegnummer)).
  
  /* The *_Vertrag fields are only calculated if the document is VUR */
  
  if available ttV_BelegSumKopf-VUR then
    assign
      ttV_BelegTotalSum-P.Frachtsumme_Vertrag      = ttV_BelegSumKopf-VUR.Frachtsumme
  
  
      ttV_BelegTotalSum-P.Gesamtsumme_Vertrag      = ttV_BelegSumKopf-VUR.Gesamt_Belegsumme[11]
                                                         + ttV_BelegSumKopf-VUR.Gesamtzuschlag
                                                         + (if ttV_BelegKopf-P.Brutto = no then /* Nettobeleg oder Bruttobeleg */
                                                              ttV_BelegSumKopf-VUR.Gesamtsteuer
                                                            else
                                                              0)
      .
  
  if can-do('GB,P,I':U, pACConnectionSvc:prpcLocalization) then
  do:
  
    if SBCLocalizationSvc:prpoInstance:lIsLocalizationGreatBritain() then
    do I = 1 to 10:
      if ttV_BelegSumKopf-Calc.Gesamt_Steuersatz[I] = 0 then
      do:
  
        iFirst0RateExtent = I.
  
        leave.
  
      end.
  
    end. /* if .. do I = 1 to 10 */
  
    else  /* lIsLocalizationItaly() or lIsLocalizationPoland() */    
      do I = 1 to 10:
        if lTaxKeyIsZeroTaxKey(ttV_BelegSumKopf-Calc.Gesamt_Steuersatz[I],
                               ttV_BelegSumKopf-Calc.H_TaxCode[I],
                               ttV_BelegSumKopf-Calc.P_TaxExtentUsed[I],
                               ttV_BelegSumKopf-Calc.I_P_S_Steuer_Obj[I]) then
      do:
  
        iFirst0RateExtent = I.
  
        leave.
  
      end.
  
      end. /* else do I = 1 to 10 */

  
    /* bestimme den letzten verwendeten Steuersatz */
  
    /* determine at least the Zuschlag_Extent to be printed */
    /* otherwise an error occures for zero value documents  */
    do iLastUsedTaxExtent = 10 to 1 by -1:
  
      if   ttV_BelegSumKopf-Calc.Gesamt_Belegsumme[iLastUsedTaxExtent] <> 0
        or (    iLastUsedTaxExtent = ttV_BelegKopf-P.Zuschlag_Extent
            and ttV_BelegSumKopf-Calc.Gesamtzuschlag   <> 0)
        or (    pACConnectionSvc:prpcLocalization    = 'P':U
            and ttV_BelegSumKopf-Calc.P_TaxExtentUsed[iLastUsedTaxExtent] = yes)
        or (    pACConnectionSvc:prpcLocalization    = 'I':U
            and ttV_BelegSumKopf-Calc.I_P_S_Steuer_Obj[iLastUsedTaxExtent] > '':U)
        or ttV_BelegSumKopf-Calc.Gesamt_Anzahlungen[iLastUsedTaxExtent] <> 0
        or (    ttV_BelegKopf-P.BelegArt = 'VUR':U
            and ttV_BelegSumKopf-Calc.Gesamt_Belegsumme[iLastUsedTaxExtent] <> 0)
        or (    ttV_BelegSumKopf-Calc.Gesamt_Belegsumme[iLastUsedTaxExtent]  = 0
            and can-find(first V_BelegPos
                           where V_BelegPos.Firma      = ttV_BelegKopf-P.Firma
                             and V_BelegPos.Belegart   = ttV_BelegKopf-P.Belegart
                             and V_BelegPos.ReferenzNr = ttV_BelegKopf-P.ReferenzNr
                             and V_BelegPos.Satzart    = 'A':U
                             and V_BelegPos.SteuerSatz = ttV_BelegSumKopf-Calc.Gesamt_Steuersatz[iLastUsedTaxExtent])) then
      do:
  
        /* bei einer Pos. mit Steuersatz 0 % muss man mehr Aufwand betreiben um das letzte verwendete  */
        /* Extent zu bestimmen da 0 der Initialwert in allen Extents ist - in diesem Fall brauchen wir */
        /* bei 1 beginnend das 1. Extent mit 0 %.                                                      */
        /* So, wie es hier programmiert ist, kann der Steuersatz des letzten Extent auch <> 0 % sein,
           es ist einfach das letzte genutzte Extent. Auch wenn 2 Pos ex, beide Steuersatz <> 0, ist iLastUsedTaxExtent = 2   */
  
        if    ttV_BelegSumKopf-Calc.Gesamt_Steuersatz[iLastUsedTaxExtent]    = 0
          and not lIsI_P_HZeroTaxKey(ttV_BelegSumKopf-Calc.H_TaxCode[iLastUsedTaxExtent],
                                     ttV_BelegSumKopf-Calc.P_TaxExtentUsed[iLastUsedTaxExtent],
                                     ttV_BelegSumKopf-Calc.I_P_S_Steuer_Obj[iLastUsedTaxExtent])
          and iLastUsedTaxExtent <> iFirst0RateExtent then
  
          next.
  
        leave.
  
      end.
  
    end. /* do iLastUsedTaxExtent = 10 to 1 by -1: */
  
    if SBCLocalizationSvc:prpoInstance:lIsLocalizationPoland()
      and iLastUsedTaxExtent > 0 then
    do:

      if ttV_BelegKopf-P.Waehrung = 0 then
  
        assign
          dTotalNetAmountOC      = ttV_BelegSumKopf-Calc.Endbetrag
          dTotalTaxAmountOC      = ttV_BelegSumKopf-Calc.Endbetrag_brutto - ttV_BelegSumKopf-Calc.Endbetrag
          dTotalNetAmountOCCIT   = dTotalNetAmountOC
          dTotalTaxAmountOCCIT   = dTotalTaxAmountOC
          .
  
      else
  
        SBCLocalizationPLSvc:prpoInstance:ReadTaxEvalPerRate
          (      ttV_BelegKopf-P.V_BelegKopf_Obj,
                  ?,
                  ttV_BelegSumKopf-Calc.P_NoToggle[iLastUsedTaxExtent],
                  ttV_BelegSumKopf-Calc.P_NPV[iLastUsedTaxExtent],
                  ttV_BelegSumKopf-Calc.P_befreit[iLastUsedTaxExtent],
           output dTotalNetAmountOC,
           output dTotalTaxAmountOC,
           output dTotalNetAmountOCCIT,
           output dTotalTaxAmountOCCIT).
  
    end.


    if SBCLocalizationSvc:prpoInstance:lIsLocalizationGreatBritain() then 
      assign
        ttV_BelegTotalSum-P.GB_TotalTaxAmountOC = if ttV_BelegKopf-P.BelegArt = 'G':U then
                                                    - dTotalTaxAmountOC
                                                  else
                                                    dTotalTaxAmountOC
        ttV_BelegTotalSum-P.GB_TotalNetAmountOC = if ttV_BelegKopf-P.BelegArt = 'G':U then
                                                    - dTotalNetAmountOC
                                                  else
                                                    dTotalNetAmountOC
        .
  
    if SBCLocalizationSvc:prpoInstance:lIsLocalizationPoland() then
      assign
        ttV_BelegTotalSum-P.P_Gesamtsumme_EW          = dTotalNetAmountOC    + dTotalTaxAmountOC
        ttV_BelegTotalSum-P.P_Gesamtsumme_EW_CIT      = dTotalNetAmountOCCIT + dTotalTaxAmountOCCIT 
        ttV_BelegTotalSum-P.P_Gesamtsumme_EW_Combined = dTotalNetAmountOCCIT + dTotalTaxAmountOC
        ttV_BelegTotalSum-P.P_Gesamtsumme_netto       = (if can-do('R,G':U, ttV_BelegKopf-P.Belegart) then
                                                           dTotalNetAmountOC
                                                         else
                                                           ttV_BelegSumKopf-Calc.Gesamt_Belegsumme[11])
        ttV_BelegTotalSum-P.P_Gesamtsumme_netto_CIT   = (if can-do('R,G':U, ttV_BelegKopf-P.Belegart) then
                                                           dTotalNetAmountOCCIT
                                                         else
                                                           ttV_BelegSumKopf-Calc.Gesamt_Belegsumme[11])
        .
  
  end. /* if pACConnectionSvc:prpcLocalization = 'GB':U or 'P':U then */
  
  /* If Eurofaktor field is > 0  and the documents domestic currency is not */
  /* EUR, the EUR_* fields are filled ... this was important during the     */
  /* years of transition to the Euro. It might be important again if        */
  /* further countried join the Euro or countries having the Euro now,      */
  /* abandom it in the future!                                              */
  
  if ttS_Waehrung-P1.Eurofaktor > 0
    and not ttS_Waehrung-P1.ISO_KurzBez = 'EUR':U then
  do:
  
    assign
      ttV_BelegTotalSum-P.Eur_Gesamtsumme          = ttV_BelegTotalSum-P.Gesamtsumme / ttS_Waehrung-P1.Eurofaktor
      ttV_BelegTotalSum-P.Eur_Frachtsumme          = ttV_BelegTotalSum-P.Frachtsumme / ttS_Waehrung-P1.Eurofaktor
      ttV_BelegTotalSum-P.Eur_Zuschlaege           = ttV_BelegSumKopf-Calc.Gesamtzuschlag / ttS_Waehrung-P1.Eurofaktor
      ttV_BelegTotalSum-P.Eur_Frachtsumme_Vertrag  = ttV_BelegTotalSum-P.Frachtsumme_Vertrag  / ttS_Waehrung-P1.Eurofaktor
      ttV_BelegTotalSum-P.Eur_Gesamtsumme_Vertrag  = ttV_BelegTotalSum-P.Gesamtsumme_Vertrag  / ttS_Waehrung-P1.Eurofaktor
      .
  
  end.
  
  if pACConnectionSvc:prpcLocalization = 'F':U then
  do:
  
    do iTaxRates = 1 to extent(ttV_BelegSumKopf-Calc.Gesamt_Steuersatz):
  
      if (    (   lVariousTaxRates = no
               or (   can-find(first ttV_BelegSumPos-Calc
                                 where ttV_BelegSumPos-Calc.Steuersatz = ttV_BelegSumKopf-Calc.Gesamt_Steuersatz[iTaxRates])
                   or ttV_BelegKopf-P.SteuerSatzZuschl                 = ttV_BelegSumKopf-Calc.Gesamt_Steuersatz[iTaxRates]))
          and can-find (first bttV_BelegPos-P
                where bttV_BelegPos-P.Firma      = {firma/vbelegko.fir gcFirma}
                  and bttV_BelegPos-P.BelegArt   = ttV_BelegKopf-P.BelegArt
                  and bttV_BelegPos-P.ReferenzNr = ttV_BelegKopf-P.ReferenzNr
                  and bttV_BelegPos-P.Satzart    = 'A':U
                  and bttV_BelegPos-P.Steuersatz = ttV_BelegSumKopf-Calc.Gesamt_Steuersatz[iTaxRates])) then
  
  
      assign
        ttV_BelegTotalSum-P.F_EcoTaxAmount             = ttV_BelegSumKopf-Calc.F_EcoTaxNetSum[iTaxRates]
        ttV_BelegTotalSum-P.F_NetPurchaseWithoutEcoTax = ttV_BelegSumKopf-Calc.Gesamt_Belegsumme[iTaxRates] 
                                                         - ttV_BelegSumKopf-Calc.F_EcoTaxNetSum[iTaxRates]
        .
  
    end. /* iTaxRates = 1 to extent(ttV_BelegSumKopf-Calc.Gesamt_Steuersatz): */
  
  end. /* if pACConnectionSvc:prpcLocalization = 'F':U then */
  
  /* Global buffer gbV_BelegKopf is loaded no-lock in fillDataset and available */
  /* fillDatset finishes. The buffer is needed to use old API's that require    */
  /* a ROWID as input parameter. To access field values ttV_BelegKopf-P should  */
  /* be used.                                                                   */
  
  run vert/proc/v_vdru02.p (rowid(gbV_BelegKopf),
                            glPositions,
                            yes,
                            0,               /* ReferenzNR */
                            output dGesamtgewicht).
  
  ttV_BelegTotalSum-P.Gesamtgewicht = dGesamtgewicht.
  
  run vert/proc/v_vdru02.p (rowid(gbV_BelegKopf),
                            glPositions,
                            no,
                            0,               /* ReferenzNR */
                            output dGesamtgewicht).
  
  ttV_BelegTotalSum-P.Gewicht = dGesamtgewicht.
  
  /* Bei normalen Zahlungszielen ergeben sich skontierbare Beträge aus der      */
  /* Berechnung des Belegs. Beim manuellen Zahlungsziel spielen diese           */
  /* skontierbaren Beträge keine Rolle. Das hängt einzig von der manuellen      */
  /* Aufteilung des Anwenders ab (V_BelegZZ)                                    */
  if not (ttV_BelegKopf-P.Belegart = 'R':U
            and available ttS_ZahlZiel-P
            and ttS_ZahlZiel-P.manuell = yes)  then
    assign
      ttV_BelegTotalSum-P.Skontofaehige_Summe      = round(ttV_BelegSumKopf-Calc.Skontofaehige_Summe,ttV_BelegKopf-P.WaehrungNK)
      ttV_BelegTotalSum-P.skonto_Summe_Euro        = ttV_BelegSumKopf-Calc.Skontofaehige_Summe / ttS_Waehrung-P1.Eurofaktor
      &IF "{&pa_S_F_EcoTax}":U = "1":U &THEN
        ttV_Belegkopf-P.F_NetPurchaseWithoutEcoTax =   ttV_BelegTotalSum-P.Gesamtsumme
                                                     - ttV_BelegKopf-P.F_EcoTaxAmount when (pACConnectionSvc:prpcLocalization = 'F':U)
      &ENDIF
      .
  
  if ttV_BelegKopf-P.Endbetrag = ? then
    ttV_BelegKopf-P.Endbetrag = ttV_BelegSumKopf-Calc.Endbetrag.

end procedure. /* fillDocumentTotalSumForLLPrint */


/* _UIB-CODE-BLOCK-END */
&ANALYZE-RESUME

&ENDIF


&IF DEFINED(EXCLUDE-P_fillOrgDocTaxrateSumsForLLPrint) = 0 &THEN

&ANALYZE-SUSPEND _UIB-CODE-BLOCK _PROCEDURE P_fillOrgDocTaxrateSumsForLLPrint Method-Library 
procedure P_fillOrgDocTaxrateSumsForLLPrint :
/* Description ---------------------------------------------------------------*/
/*                                                                            */
/* Calculates the taxrate dependant document sums annd returns it in a format */
/* usable by List&Label print.                                                */
/* TT ttPV_BelegSumKopf-Org must be filled before calling this procedure!     */
/*                                                                            */
/* Notes ---------------------------------------------------------------------*/
/*                                                                            */
/* This procedure does only encapsulate code for better readability of        */
/* fillDataset procedure. It can only be used in the context of this DAO      */
/* run super() has been execute an a global ttV_BelegKopf-PP Buffer is        */
/* available... so passing of paramters was forgone deliberatly.              */
/*                                                                            */
/*----------------------------------------------------------------------------*/

define variable iTaxRates        as   integer               no-undo.
define variable lVariousTaxRates as   logical               no-undo.
define variable dPGesamtsumme    as   decimal               no-undo.
define variable dEurofaktor      like S_Waehrung.Eurofaktor no-undo.
define variable i                as   integer               no-undo.

define buffer bttV_BelegPos-PP   for temp-table ttV_BelegPos-PP.

  /* Check if different tax rates are available in the current document. If   */
  /* only one single tax rate (e.g. zero) is available, then the print must   */
  /* be done only one time.                                                   */
  
lVariousTaxRates = lDocumentHasDifferentTaxKeys (ttPV_BelegSumKopf-Org.Gesamt_Steuersatz,
                                                 ttPV_BelegSumKopf-Org.H_TaxCode,
                                                 ttPV_BelegSumKopf-Org.P_TaxExtentUsed,
                                                 ttPV_BelegSumKopf-Org.I_P_S_Steuer_Obj).
  
  /* translate the TT_V_BelegSumme record with its extents to the non         */
  /* extent records of ttV_BelegTaxrateSums-PP. Primary key and Main sort     */
  /* case is Gesamt_Steuersatz!                                               */
  
  do iTaxRates = 1 to extent(ttPV_BelegSumKopf-Org.Gesamt_Steuersatz):
  
    /* If we are in first loop we can add, this slot must always be in use.          */
    /* The 'not can-find(ttV_BelegTaxrateSums-PP...' must be done from second loop,  */
    /* because several slots can be filled with TaxRate 0 but only the first is used.*/
    /* If we found a slot that was not added we must search if any position or the   */
    /* head surcharges use this slot.                                                */
  
    /* If only tax rates with value zero exists in the current document, then   */
    /* the print of the sum section must be ensured.                            */
    /* If a text line is the only line with tax rate value zero, then do not    */
    /* print this value in the sum section.                                     */
  
    if ((lVariousTaxRates = no
      or (can-find(first ttPV_BelegSumPos-Org
                     where ttPV_BelegSumPos-Org.Steuersatz = ttPV_BelegSumKopf-Org.Gesamt_Steuersatz[iTaxRates])))
        /* there is not yet a record with the unique pk index fields */
        and not can-find(first ttV_BelegTaxrateSums-PP
                           where ttV_BelegTaxrateSums-PP.Owning_Obj = ttV_BelegKopf-PP.V_BelegKopf_Obj
                             and ttV_BelegTaxrateSums-PP.Steuersatz = ttPV_BelegSumKopf-Org.Gesamt_Steuersatz[iTaxRates]
                             and ttV_BelegTaxrateSums-PP.P_TaxKey   = ttPV_BelegSumKopf-Org.I_P_S_Steuer_Obj[iTaxRates]
                             and ttV_BelegTaxrateSums-PP.TaxArrayID = 0)
        and ttPV_BelegSumKopf-Org.I_P_S_Steuer_Obj[iTaxRates] > '':U
        /* there is at least one line with this tax rate */                           
        and can-find(first bttV_BelegPos-PP
                       where bttV_BelegPos-PP.Firma      = {firma/vbelegko.fir gcFirma}
                         and bttV_BelegPos-PP.BelegArt   = ttV_BelegKopf-PP.BelegArt
                         and bttV_BelegPos-PP.ReferenzNr = ttV_BelegKopf-PP.ReferenzNr
                         and bttV_BelegPos-PP.Satzart    = 'A':U
                         and bttV_BelegPos-PP.Steuersatz = ttPV_BelegSumKopf-Org.Gesamt_Steuersatz[iTaxRates])) then
    do:
  
      create ttV_BelegTaxrateSums-PP.
  
      /* first fill all fields in domestic currency */
  
      assign
        /* main index fields */
        ttV_BelegTaxrateSums-PP.Owning_Obj        = ttV_BelegKopf-PP.V_BelegKopf_Obj
        /* check later for {&PA_F_P_STEUERBEFREIT} , {&PA_F_P_NPV} and '-':U */
        ttV_BelegTaxrateSums-PP.Steuersatz        = ttPV_BelegSumKopf-Org.Gesamt_Steuersatz[iTaxRates]
        ttV_BelegTaxrateSums-PP.P_TaxKey          = ttPV_BelegSumKopf-Org.I_P_S_Steuer_Obj[iTaxRates]
        ttV_BelegTaxrateSums-PP.TaxArrayID        = 0
        /* others */    
        ttV_BelegTaxrateSums-PP.Warenwert         = ttPV_BelegSumKopf-Org.Gesamt_Belegsumme[iTaxRates]
        .
  
      if ttV_BelegKopf-PP.Brutto = no then   /* von Nettobetrag */
        ttV_BelegTaxrateSums-PP.Steuer  = round((ttPV_BelegSumKopf-Org.Gesamt_Belegsumme[iTaxRates]
                                               + (if iTaxRates = ttV_BelegKopf-PP.Zuschlag_Extent then
                                                    ttPV_BelegSumKopf-Org.Gesamtzuschlag
                                                  else
                                                    0))
                                               * ttPV_BelegSumKopf-Org.Gesamt_Steuersatz[iTaxRates] / 100,
                                               ttV_BelegKopf-PP.WaehrungNK).
  
      else                              /* aus Bruttobetrag */
        ttV_BelegTaxrateSums-PP.Steuer = round((ttPV_BelegSumKopf-Org.Gesamt_Belegsumme[iTaxRates]
                                               + (if iTaxRates = ttV_BelegKopf-PP.Zuschlag_Extent then
                                                    ttPV_BelegSumKopf-Org.Gesamtzuschlag
                                                  else
                                                    0))
                                               / (1 + ttPV_BelegSumKopf-Org.Gesamt_Steuersatz[iTaxRates] / 100)
                                               * ttPV_BelegSumKopf-Org.Gesamt_Steuersatz[iTaxRates] / 100,
                                               ttV_BelegKopf-PP.WaehrungNK).
  
      assign
        ttV_BelegTaxrateSums-PP.Summe_excl =  ttPV_BelegSumKopf-Org.Gesamt_Belegsumme[iTaxRates]
                                              + (if iTaxRates = ttV_BelegKopf-PP.Zuschlag_Extent then
                                                   ttPV_BelegSumKopf-Org.Gesamtzuschlag
                                                 else
                                                   0)
                                              - (if ttV_BelegKopf-PP.Brutto = no then /* Nettobeleg oder Bruttobeleg */
                                                   0
                                                 else
                                                   ttV_BelegTaxrateSums-PP.Steuer)
  
        ttV_BelegTaxrateSums-PP.Summe_incl = ttPV_BelegSumKopf-Org.Gesamt_Belegsumme[iTaxRates]
                                              + (if iTaxRates = ttV_BelegKopf-PP.Zuschlag_Extent then
                                                   ttPV_BelegSumKopf-Org.Gesamtzuschlag
                                                 else
                                                   0)
                                              + (if ttV_BelegKopf-PP.Brutto = no then /* Nettobeleg oder Bruttobeleg */
                                                   ttV_BelegTaxrateSums-PP.Steuer
                                                 else
                                                   0)
  
        .
  
      /* All surcharches have the same taxrate  - the surcharge fields are only */
      /* filled for the taxrate they correspond with... (Zuschlag_Extent)       */
  
      if iTaxRates = ttV_BelegKopf-PP.Zuschlag_Extent then
  
        ttV_BelegTaxrateSums-PP.Zuschlaege = ttPV_BelegSumKopf-Org.Gesamtzuschlag.
  
      /* If Eurofaktor field is > 0  and the documents domestic currency is not */
      /* EUR, the EUR_* fields are filled ... this was important during the     */
      /* years of transition to the Euro. It might be important again if        */
      /* further countried join the Euro or countries having the Euro now,      */
      /* abandom it in the future!                                              */
  
      if ttS_Waehrung-P1.Eurofaktor > 0 then
        assign
          ttV_BelegTaxrateSums-PP.Eur_Steuer               = ttV_BelegTaxrateSums-PP.Steuer  / ttS_Waehrung-P1.Eurofaktor
          ttV_BelegTaxrateSums-PP.Eur_Summe_excl           = ttV_BelegTaxrateSums-PP.Summe_excl / ttS_Waehrung-P1.Eurofaktor
          ttV_BelegTaxrateSums-PP.Eur_Summe_incl           = ttV_BelegTaxrateSums-PP.Summe_incl / ttS_Waehrung-P1.Eurofaktor
          ttV_BelegTaxrateSums-PP.Eur_Warenwert            = ttV_BelegTaxrateSums-PP.Warenwert / ttS_Waehrung-P1.Eurofaktor
          .
  
      assign
        dPGesamtsumme = (  ttPV_BelegSumKopf-Org.Gesamt_Belegsumme[11]
                         + ttPV_BelegSumKopf-Org.Gesamtzuschlag
                         + (if ttV_BelegKopf-PP.Brutto = no then /* Nettobeleg oder Bruttobeleg */
                              ttPV_BelegSumKopf-Org.Gesamtsteuer
                            else
                              0))
        dEurofaktor   = (if available ttS_Waehrung-P1 then
                           ttS_Waehrung-P1.Eurofaktor
                         else
                           0)
        .
  
      assign
        ttV_BelegTaxrateSums-PP.WorteEndBetrag     = SBCLocalizationPLSvc:prpoInstance:cSpokenNumber
                                                       (gcFirma,
                                                        gcContentLanguage,
                                                        ttV_BelegKopf-PP.Waehrung,
                                                        dPGesamtsumme)
        ttV_BelegTaxrateSums-PP.WorteEndBetrag_EUR = SBCLocalizationPLSvc:prpoInstance:cSpokenNumber
                                                       (gcFirma,
                                                        gcContentLanguage,
                                                        ?,
                                                        dPGesamtsumme / dEuroFaktor)
        .
  
    end. /* if lVariousTaxRates and not can-find(ttV_BelegTaxrateSums-PP */
  
  end. /* iTaxRates = 1 to extent(ttPV_BelegSumKopf-Org.Gesamt_Steuersatz) */

end procedure. /* P_fillOrgDocTaxrateSumsForLLPrint */


/* _UIB-CODE-BLOCK-END */
&ANALYZE-RESUME

&ENDIF


&IF DEFINED(EXCLUDE-P_fillOrgDocTotalSumForLLPrint) = 0 &THEN

&ANALYZE-SUSPEND _UIB-CODE-BLOCK _PROCEDURE P_fillOrgDocTotalSumForLLPrint Method-Library 
procedure P_fillOrgDocTotalSumForLLPrint :
/* Description ---------------------------------------------------------------*/
/*                                                                            */
/* Calculates total sums for the original document.                           */
/* TT ttPV_BelegSumKopf-Org must be filled before calling this procedure!     */
/*                                                                            */
/* Notes ---------------------------------------------------------------------*/
/*                                                                            */
/* This procedure does only encapsulate code for better readability of        */
/* fillDataset procedure. It can only be used in the context of this DAO      */
/* run super() has been execute an a global ttV_BelegKopf-PP Buffer is         */
/* available... so passing of paramters was forgone deliberatly.              */
/*                                                                            */
/*----------------------------------------------------------------------------*/

define variable dGesamtgewicht     like V_BelegPos.Gewicht no-undo.

  create ttV_BelegTotalSum-PP.
  
  assign
  
    ttV_BelegTotalSum-PP.Gesamtsumme    = ttPV_BelegSumKopf-Org.Gesamt_Belegsumme[11]
                                          + ttPV_BelegSumKopf-Org.Gesamtzuschlag
                                          + (if ttV_BelegKopf-PP.Brutto = no then /* Nettobeleg oder Bruttobeleg */
                                               ttPV_BelegSumKopf-Org.Gesamtsteuer
                                             else
                                               0)
    ttV_BelegTotalSum-PP.Frachtsumme    = ttPV_BelegSumKopf-Org.Frachtsumme
    ttV_BelegTotalSum-PP.Owning_Obj     = ttV_BelegKopf-PP.V_BelegKopf_Obj
    .
  
  /* If Eurofaktor field is > 0  and the documents domestic currency is not */
  /* EUR, the EUR_* fields are filled ... this was important during the     */
  /* years of transition to the Euro. It might be important again if        */
  /* further countried join the Euro or countries having the Euro now,      */
  /* abandom it in the future!                                              */
  
  if ttS_Waehrung-P1.Eurofaktor > 0
    and not ttS_Waehrung-P1.ISO_KurzBez = 'EUR':U then
  
    assign
      ttV_BelegTotalSum-PP.Eur_Gesamtsumme = ttV_BelegTotalSum-PP.Gesamtsumme / ttS_Waehrung-P1.Eurofaktor
      ttV_BelegTotalSum-PP.Eur_Frachtsumme = ttV_BelegTotalSum-PP.Frachtsumme / ttS_Waehrung-P1.Eurofaktor
      ttV_BelegTotalSum-PP.Eur_Zuschlaege  = ttPV_BelegSumKopf-Org.Gesamtzuschlag / ttS_Waehrung-P1.Eurofaktor
      .
  
  /* Global buffer gbPV_BelegKopf-Org is loaded no-lock in fillDataset and available */
  /* fillDatset finishes. The buffer is needed to use old API's that require         */
  /* a ROWID as input parameter. To access field values ttV_BelegKopf-PP should      */
  /* be used.                                                                        */
  
  run vert/proc/v_vdru02.p (rowid(gbPV_BelegKopf-Org),
                            glPositions,
                            yes,
                            0,               /* ReferenzNR */
                            output dGesamtgewicht).
  
  ttV_BelegTotalSum-PP.Gesamtgewicht = dGesamtgewicht.
  
  run vert/proc/v_vdru02.p (rowid(gbPV_BelegKopf-Org),
                            glPositions,
                            no,
                            0,               /* ReferenzNR */
                            output dGesamtgewicht).
  
  ttV_BelegTotalSum-PP.Gewicht = dGesamtgewicht.

end procedure. /* P_fillOrgDocTotalSumForLLPrint */


/* _UIB-CODE-BLOCK-END */
&ANALYZE-RESUME

&ENDIF


&IF DEFINED(EXCLUDE-P_fillK_OrgDocTaxrateSumsForLLPrint) = 0 &THEN

&ANALYZE-SUSPEND _UIB-CODE-BLOCK _PROCEDURE P_fillK_OrgDocTaxrateSumsForLLPrint Method-Library 
procedure P_fillK_OrgDocTaxrateSumsForLLPrint :
/* Description ---------------------------------------------------------------*/
/*                                                                            */
/* Calculates the taxrate dependant document sums annd returns it in a format */
/* usable by List&Label print.                                                */
/* TT ttPV_K_BelegSumKopf-Org must be filled before calling this procedure!     */
/*                                                                            */
/* Notes ---------------------------------------------------------------------*/
/*                                                                            */
/* This procedure does only encapsulate code for better readability of        */
/* fillDataset procedure. It can only be used in the context of this DAO      */
/* run super() has been execute an a global ttV_BelegKopf-P Buffer is         */
/* available... so passing of paramters was forgone deliberatly.              */
/*                                                                            */
/*----------------------------------------------------------------------------*/

define variable iTaxRates        as   integer               no-undo.
define variable lVariousTaxRates as   logical               no-undo.
define variable dPGesamtsumme    as   decimal               no-undo.
define variable dEurofaktor      like S_Waehrung.Eurofaktor no-undo.
define variable i                as   integer               no-undo.

define variable dExRate          like V_BelegKopf.Kurs      no-undo.
define variable dTaxExRate       like V_BelegKopf.Kurs      no-undo.
define variable dGesamtBelegsumme as decimal                 no-undo.

define buffer bttV_BelegPos-P   for temp-table ttV_BelegPos-P.
  
  dExRate    = {fnarg
                 pa_dCurGetExchangeRate
                 "gcFirma,
                  gbV_BelegKopf.Waehrung,
                  gbV_BelegKopf.P_PostPeriodExRateDate,
                  {&pa_V_Kurs},
                  gbV_BelegKopf.Kunde,
                  gbV_BelegKopf.V_BelegKopf_Obj"}.
  
  dTaxExRate = {fnarg
                 pa_dCurGetExchangeRate
                 "gcFirma,
                  gbV_BelegKopf.Waehrung,
                  gbV_BelegKopf.P_TaxPeriodExRateDate,
                  {&pa_V_Kurs},
                  gbV_BelegKopf.Kunde,
                  gbV_BelegKopf.V_BelegKopf_Obj"}.
  
  /* Check if different tax rates are available in the current document. If   */
  /* only one single tax rate (e.g. zero) is available, then the print must   */
  /* be done only one time.                                                   */
  
  lVariousTaxRates = lDocumentHasDifferentTaxKeys (ttPV_K_BelegSumKopf-Org.Gesamt_Steuersatz,
                                                   ttPV_K_BelegSumKopf-Org.H_TaxCode,
                                                   ttPV_K_BelegSumKopf-Org.P_TaxExtentUsed,
                                                   ttPV_K_BelegSumKopf-Org.I_P_S_Steuer_Obj).
  
  /* translate the TT_V_BelegSumme record with it's extents to the non     
     extent records of ttV_BelegTaxrateSums-PPOrg.                         
     Primary key and Main sort case is Gesamt_Steuersatz!                     */
  
  do iTaxRates = 1 to extent(ttPV_K_BelegSumKopf-Org.Gesamt_Steuersatz):
  
    /* If we are in first loop we can add, this slot must always be in use.          */
    /* The 'not can-find(ttV_BelegTaxrateSums-PPOrg...' must be done from second loop,   */
    /* because several slots can be filled with TaxRate 0 but only the first is used.*/
    /* If we found a slot that was not added we must search if any position or the   */
    /* head surcharges use this slot.                                                */
  
    /* If only tax rates with value zero exists in the current document, then   */
    /* the print of the sum section must be ensured.                            */
    /* If a text line is the only line with tax rate value zero, then do not    */
    /* print this value in the sum section.                                     */
  
    if ((lVariousTaxRates = no
      or (can-find(first ttPV_K_BelegSumPos-Org
                     where ttPV_K_BelegSumPos-Org.Steuersatz = ttPV_K_BelegSumKopf-Org.Gesamt_Steuersatz[iTaxRates])
            or ttV_BelegKopf-P.SteuerSatzZuschl              = ttPV_K_BelegSumKopf-Org.Gesamt_Steuersatz[iTaxRates]))
        /* there is not yet a record with the unique pk index fields */
        and not can-find(first ttV_BelegTaxrateSums-PPOrg
                           where ttV_BelegTaxrateSums-PPOrg.Owning_Obj = ttV_BelegKopf-P.V_BelegKopf_Obj
                             and ttV_BelegTaxrateSums-PPOrg.Steuersatz = ttPV_K_BelegSumKopf-Org.Gesamt_Steuersatz[iTaxRates]
                             and ttV_BelegTaxrateSums-PPOrg.P_TaxKey   = ttPV_K_BelegSumKopf-Org.I_P_S_Steuer_Obj[iTaxRates]
                             and ttV_BelegTaxrateSums-PPOrg.TaxArrayID = 0)
        /* there is at least one line with this tax rate */                           
        and can-find(first bttV_BelegPos-P
                       where bttV_BelegPos-P.Firma      = {firma/vbelegko.fir gcFirma}
                         and bttV_BelegPos-P.BelegArt   = ttV_BelegKopf-P.BelegArt
                         and bttV_BelegPos-P.ReferenzNr = ttV_BelegKopf-P.ReferenzNr
                         and bttV_BelegPos-P.Satzart    = 'A':U
                         and bttV_BelegPos-P.Steuersatz = ttPV_K_BelegSumKopf-Org.Gesamt_Steuersatz[iTaxRates])) then
    do:
  
      create ttV_BelegTaxrateSums-PPOrg.
  
      assign
        /* main index fields */
        ttV_BelegTaxrateSums-PPOrg.Owning_Obj        = ttV_BelegKopf-P.V_BelegKopf_Obj
        ttV_BelegTaxrateSums-PPOrg.Steuersatz        = ttPV_K_BelegSumKopf-Org.Gesamt_Steuersatz[iTaxRates]
        ttV_BelegTaxrateSums-PPOrg.P_TaxKey          = ttPV_K_BelegSumKopf-Org.I_P_S_Steuer_Obj[iTaxRates]
        ttV_BelegTaxrateSums-PPOrg.TaxArrayID        = 0
        /* others */    
        ttV_BelegTaxrateSums-PPOrg.Anzahlungen       = ttPV_K_BelegSumKopf-Org.Gesamt_Anzahlungen[iTaxRates]
        ttV_BelegTaxrateSums-PPOrg.Warenwert         = ttPV_K_BelegSumKopf-Org.Gesamt_Belegsumme[iTaxRates]
        ttV_BelegTaxrateSums-PPOrg.Warenwert_ohne_AA = ttPV_K_BelegSumKopf-Org.Gesamt_Belegsumme[iTaxRates]
                                                       - ttPV_K_BelegSumKopf-Org.Gesamt_Anzahlungen[iTaxRates]
        dGesamtBelegsumme                            = (if iTaxRates = ttV_BelegKopf-P.Zuschlag_Extent then
                                                          ttPV_K_BelegSumKopf-Org.Gesamtzuschlag
                                                        else
                                                          0)
        .
  
      if ttV_BelegKopf-P.Brutto = no then   /* von Nettobetrag */
        ttV_BelegTaxrateSums-PPOrg.Steuer  = round((ttPV_K_BelegSumKopf-Org.Gesamt_Belegsumme[iTaxRates]
                                               + dGesamtBelegsumme)
                                               * ttPV_K_BelegSumKopf-Org.Gesamt_Steuersatz[iTaxRates] / 100,
                                               ttV_BelegKopf-P.WaehrungNK).
      else                              /* aus Bruttobetrag */
        ttV_BelegTaxrateSums-PPOrg.Steuer = round((ttPV_K_BelegSumKopf-Org.Gesamt_Belegsumme[iTaxRates]
                                               + dGesamtBelegsumme)
                                               / (1 + ttPV_K_BelegSumKopf-Org.Gesamt_Steuersatz[iTaxRates] / 100)
                                               * ttPV_K_BelegSumKopf-Org.Gesamt_Steuersatz[iTaxRates] / 100,
                                               ttV_BelegKopf-P.WaehrungNK).
  
      assign
  
        ttV_BelegTaxrateSums-PPOrg.Summe_excl =  ttPV_K_BelegSumKopf-Org.Gesamt_Belegsumme[iTaxRates]
                                              + dGesamtBelegsumme
                                              - (if ttV_BelegKopf-P.Brutto = no then /* Nettobeleg oder Bruttobeleg */
                                                   0
                                                 else
                                                   ttV_BelegTaxrateSums-PPOrg.Steuer)
  
        ttV_BelegTaxrateSums-PPOrg.Summe_incl = ttPV_K_BelegSumKopf-Org.Gesamt_Belegsumme[iTaxRates]
                                              + dGesamtBelegsumme
                                              + (if ttV_BelegKopf-P.Brutto = no then /* Nettobeleg oder Bruttobeleg */
                                                   ttV_BelegTaxrateSums-PPOrg.Steuer
                                                 else
                                                   0)
        .
  
  
      /* All surcharches have the same taxrate  - the surcharge fields are only */
      /* filled for the taxrate they correspond with... (Zuschlag_Extent)       */
  
      if iTaxRates = ttV_BelegKopf-P.Zuschlag_Extent then
        ttV_BelegTaxrateSums-PPOrg.Zuschlaege     =  ttPV_K_BelegSumKopf-Org.Gesamtzuschlag.
  
      /* If Eurofaktor field is > 0  and the documents domestic currency is not */
      /* EUR, the EUR_* fields are filled ... this was important during the     */
      /* years of transition to the Euro. It might be important again if        */
      /* further countried join the Euro or countries having the Euro now,      */
      /* abandom it in the future!                                              */
  
      if ttS_Waehrung-P1.Eurofaktor > 0 then
        assign
          ttV_BelegTaxrateSums-PPOrg.Eur_Anzahlungen          = ttV_BelegTaxrateSums-PPOrg.Anzahlungen / ttS_Waehrung-P1.Eurofaktor
          ttV_BelegTaxrateSums-PPOrg.Eur_Summe_excl           = ttV_BelegTaxrateSums-PPOrg.Summe_excl / ttS_Waehrung-P1.Eurofaktor
          ttV_BelegTaxrateSums-PPOrg.Eur_Summe_incl           = ttV_BelegTaxrateSums-PPOrg.Summe_incl / ttS_Waehrung-P1.Eurofaktor
          ttV_BelegTaxrateSums-PPOrg.Eur_Steuer               = ttV_BelegTaxrateSums-PPOrg.Steuer  / ttS_Waehrung-P1.Eurofaktor
          ttV_BelegTaxrateSums-PPOrg.Eur_Warenwert            = ttV_BelegTaxrateSums-PPOrg.Warenwert / ttS_Waehrung-P1.Eurofaktor
          ttV_BelegTaxrateSums-PPOrg.Eur_Warenwert_ohne_AA    = ttV_BelegTaxrateSums-PPOrg.Warenwert_ohne_AA / ttS_Waehrung-P1.Eurofaktor
          ttV_BelegTaxrateSums-PPOrg.Eur_Zuschlaege           = ttV_BelegTaxrateSums-PPOrg.Zuschlaege / ttS_Waehrung-P1.Eurofaktor
        .
  
      assign
        dPGesamtsumme = (  ttPV_K_BelegSumKopf-Org.Gesamt_Belegsumme[11]
                         + ttPV_K_BelegSumKopf-Org.Gesamtzuschlag
                         + (if ttV_BelegKopf-P.Brutto = no then /* Nettobeleg oder Bruttobeleg */
                              ttPV_K_BelegSumKopf-Org.Gesamtsteuer
                            else
                              0))
        dEurofaktor   = (if available ttS_Waehrung-P1 then
                           ttS_Waehrung-P1.Eurofaktor
                         else
                           0)
  
        ttV_BelegTaxrateSums-PPOrg.WorteEndBetrag = SBCLocalizationPLSvc:prpoInstance:cSpokenNumber
                                                      (gcFirma,
                                                       gcContentLanguage,
                                                       ttV_BelegKopf-P.Waehrung,
                                                       dPGesamtsumme)
        .
        
      if dEuroFaktor <> 0 then
        ttV_BelegTaxrateSums-PPOrg.WorteEndBetrag_EUR = SBCLocalizationPLSvc:prpoInstance:cSpokenNumber
                                                          (gcFirma,
                                                           gcContentLanguage,
                                                           ?,
                                                           dPGesamtsumme / dEuroFaktor).
  
      /* P_Zahlhinweis */
      if iTaxRates = ttV_BelegKopf-P.Zuschlag_Extent then
        ttV_BelegTaxrateSums-PPOrg.P_Zahlhinweis = string(dPGesamtsumme >= 0).
  
      assign
        ttV_BelegTaxrateSums-PPOrg.P_Gesamtsumme_EW = dPGesamtsumme * dExRate
        ttV_BelegTaxrateSums-PPOrg.P_Summe_excl_EW  = ttV_BelegTaxrateSums-PPOrg.Summe_excl * dExRate
        ttV_BelegTaxrateSums-PPOrg.P_Summe_incl_EW  = ttV_BelegTaxrateSums-PPOrg.Summe_incl * dExRate
        ttV_BelegTaxrateSums-PPOrg.Steuer_EW        = ttV_BelegTaxrateSums-PPOrg.Steuer * dTaxExRate
        .
  
    end. /* if lVariousTaxRates and not can-find(ttV_BelegTaxrateSums-PPOrg */
  
  end. /* iTaxRates = 1 to extent(ttPV_K_BelegSumKopf-Org.Gesamt_Steuersatz) */

end procedure. /* P_fillK_OrgDocTaxrateSumsForLLPrint */


/* _UIB-CODE-BLOCK-END */
&ANALYZE-RESUME

&ENDIF


&IF DEFINED(EXCLUDE-P_fillK_OrgDocTotalSumForLLPrint) = 0 &THEN

&ANALYZE-SUSPEND _UIB-CODE-BLOCK _PROCEDURE P_fillK_OrgDocTotalSumForLLPrint Method-Library 
procedure P_fillK_OrgDocTotalSumForLLPrint :
/* Description ---------------------------------------------------------------*/
/*                                                                            */
/* Calculates the document total sums.                                        */
/* TT ttPV_K_BelegSumKopf-Org must be filled before calling this procedure!     */
/*                                                                            */
/* Notes ---------------------------------------------------------------------*/
/*                                                                            */
/* This procedure does only encapsulate code for better readability of        */
/* fillDataset procedure. It can only be used in the context of this DAO      */
/* run super() has been execute an a global ttV_BelegKopf-P Buffer is         */
/* available... so passing of paramters was forgone deliberatly.              */
/*                                                                            */
/*----------------------------------------------------------------------------*/

create ttV_BelegTotalSum-PPOrg.
assign
  ttV_BelegTotalSum-PPOrg.Gesamtsumme = ttPV_K_BelegSumKopf-Org.Gesamt_Belegsumme[11]
                                        + ttPV_K_BelegSumKopf-Org.Gesamtzuschlag
                                        + (if ttV_BelegKopf-P.Brutto = no then /* Nettobeleg oder Bruttobeleg */
                                             ttPV_K_BelegSumKopf-Org.Gesamtsteuer
                                           else
                                             0)
  ttV_BelegTotalSum-PPOrg.Frachtsumme = ttPV_K_BelegSumKopf-Org.Frachtsumme
  ttV_BelegTotalSum-PPOrg.Owning_Obj  = ttV_BelegKopf-P.V_BelegKopf_Obj
  .

/* If Eurofaktor field is > 0  and the documents domestic currency is not */
/* EUR, the EUR_* fields are filled ... this was important during the     */
/* years of transition to the Euro. It might be important again if        */
/* further countried join the Euro or countries having the Euro now,      */
/* abandom it in the future!                                              */

if ttS_Waehrung-P1.Eurofaktor > 0
  and not ttS_Waehrung-P1.ISO_KurzBez = 'EUR':U then
  assign
    ttV_BelegTotalSum-PPOrg.Eur_Frachtsumme          = ttV_BelegTotalSum-PPOrg.Frachtsumme / ttS_Waehrung-P1.Eurofaktor
    ttV_BelegTotalSum-PPOrg.Eur_Gesamtsumme          = ttV_BelegTotalSum-PPOrg.Gesamtsumme / ttS_Waehrung-P1.Eurofaktor
    ttV_BelegTotalSum-PPOrg.Eur_Zuschlaege           = ttPV_K_BelegSumKopf-Org.Gesamtzuschlag / ttS_Waehrung-P1.Eurofaktor
    .

end procedure. /* P_fillK_OrgDocTotalSumForLLPrint */


/* _UIB-CODE-BLOCK-END */
&ANALYZE-RESUME

&ENDIF


&IF DEFINED(EXCLUDE-P_fillK_CorDocTaxrateSumsForLLPrint) = 0 &THEN

&ANALYZE-SUSPEND _UIB-CODE-BLOCK _PROCEDURE P_fillK_CorDocTaxrateSumsForLLPrint Method-Library 
procedure P_fillK_CorDocTaxrateSumsForLLPrint :
/* Description ---------------------------------------------------------------*/
/*                                                                            */
/* Calculates the taxrate dependant document sums annd returns it in a format */
/* usable by List&Label print.                                                */
/* TT ttPV_K_BelegSumKopf-Cor must be filled before calling this procedure!   */
/*                                                                            */
/* Notes ---------------------------------------------------------------------*/
/*                                                                            */
/* This procedure does only encapsulate code for better readability of        */
/* fillDataset procedure. It can only be used in the context of this DAO      */
/* run super() has been execute an a global ttV_BelegKopf-P Buffer is         */
/* available... so passing of paramters was forgone deliberatly.              */
/*                                                                            */
/*----------------------------------------------------------------------------*/

define variable iTaxRates        as   integer               no-undo.
define variable iTaxRatesCounter as   integer               no-undo.
define variable lVariousTaxRates as   logical               no-undo.
define variable dPGesamtsumme    as   decimal               no-undo.
define variable dEurofaktor      like S_Waehrung.Eurofaktor no-undo.
define variable i                as   integer               no-undo.

define variable dExRate          like V_BelegKopf.Kurs      no-undo.
define variable dTaxExRate       like V_BelegKopf.Kurs      no-undo.


define buffer bttV_BelegPos-P   for temp-table ttV_BelegPos-P.

  dExRate    = {fnarg
                 pa_dCurGetExchangeRate
                 "gcFirma,
                  gbV_BelegKopf.Waehrung,
                  gbV_BelegKopf.P_PostPeriodExRateDate,
                  {&pa_V_Kurs},
                  gbV_BelegKopf.Kunde,
                  gbV_BelegKopf.V_BelegKopf_Obj"}.
  
  dTaxExRate = {fnarg
                 pa_dCurGetExchangeRate
                 "gcFirma,
                  gbV_BelegKopf.Waehrung,
                  gbV_BelegKopf.P_TaxPeriodExRateDate,
                  {&pa_V_Kurs},
                  gbV_BelegKopf.Kunde,
                  gbV_BelegKopf.V_BelegKopf_Obj"}.
  
  /* Check if different tax rates are available in the current document. If   */
  /* only one single tax rate (e.g. zero) is available, then the print must   */
  /* be done only one time.                                                   */
  
  CheckTaxRates:
  do iTaxRatesCounter = 2 to extent(ttPV_K_BelegSumKopf-Cor.Gesamt_Steuersatz):
  
    if ttPV_K_BelegSumKopf-Cor.Gesamt_Steuersatz[1] <> ttPV_K_BelegSumKopf-Cor.Gesamt_Steuersatz[iTaxRatesCounter] then
    do:
  
      lVariousTaxRates = yes.
      leave CheckTaxRates.
  
    end.
  
  end. /* CheckTaxRates */

  /* translate the TT_V_BelegSumme record with it's extents to the non          */
  /* extent records of ttV_BelegTaxrateSums-PPCor. Primary key and Main sort case   */
  /* is Gesamt_Steuersatz!                                                      */
  
  do iTaxRates = 1 to extent(ttPV_K_BelegSumKopf-Cor.Gesamt_Steuersatz):
  
    /* If we are in first loop we can add, this slot must always be in use.          */
    /* The 'not can-find(ttV_BelegTaxrateSums-PPCor...' must be done from second loop,   */
    /* because several slots can be filled with TaxRate 0 but only the first is used.*/
    /* If we found a slot that was not added we must search if any position or the   */
    /* head surcharges use this slot.                                                */
  
    /* If only tax rates with value zero exists in the current document, then   */
    /* the print of the sum section must be ensured.                            */
    /* If a text line is the only line with tax rate value zero, then do not    */
    /* print this value in the sum section.                                     */
  
    if ((lVariousTaxRates = no
      or (can-find(first ttPV_K_BelegSumPos-Cor
                     where ttPV_K_BelegSumPos-Cor.Steuersatz = ttPV_K_BelegSumKopf-Cor.Gesamt_Steuersatz[iTaxRates])
            or ttV_BelegKopf-P.SteuerSatzZuschl              = ttPV_K_BelegSumKopf-Cor.Gesamt_Steuersatz[iTaxRates]))
        /* there is not yet a record with the unique pk index fields */
        and not can-find(first ttV_BelegTaxrateSums-PPCor
                           where ttV_BelegTaxrateSums-PPCor.Owning_Obj = ttV_BelegKopf-P.V_BelegKopf_Obj
                             and ttV_BelegTaxrateSums-PPCor.Steuersatz = ttPV_K_BelegSumKopf-Cor.Gesamt_Steuersatz[iTaxRates]
                             and ttV_BelegTaxrateSums-PPCor.P_TaxKey   = ttPV_K_BelegSumKopf-Cor.I_P_S_Steuer_Obj[iTaxRates]
                             and ttV_BelegTaxrateSums-PPCor.TaxArrayID = 0)
        /* there is at least one line with this tax rate */                           
        and can-find(first bttV_BelegPos-P
                       where bttV_BelegPos-P.Firma      = {firma/vbelegko.fir gcFirma}
                         and bttV_BelegPos-P.BelegArt   = ttV_BelegKopf-P.BelegArt
                         and bttV_BelegPos-P.ReferenzNr = ttV_BelegKopf-P.ReferenzNr
                         and bttV_BelegPos-P.Satzart    = 'A':U
                         and bttV_BelegPos-P.Steuersatz = ttPV_K_BelegSumKopf-Cor.Gesamt_Steuersatz[iTaxRates])) then
    do:
  
      create ttV_BelegTaxrateSums-PPCor.
  
      assign
        /* main index fields */
        ttV_BelegTaxrateSums-PPCor.Owning_Obj        = ttV_BelegKopf-P.V_BelegKopf_Obj
        ttV_BelegTaxrateSums-PPCor.Steuersatz        = ttPV_K_BelegSumKopf-Cor.Gesamt_Steuersatz[iTaxRates]
        ttV_BelegTaxrateSums-PPCor.P_TaxKey          = ttPV_K_BelegSumKopf-Cor.I_P_S_Steuer_Obj[iTaxRates]
        ttV_BelegTaxrateSums-PPCor.TaxArrayID        = 0
        /* others */    
        ttV_BelegTaxrateSums-PPCor.Anzahlungen       = ttPV_K_BelegSumKopf-Cor.Gesamt_Anzahlungen[iTaxRates]
        ttV_BelegTaxrateSums-PPCor.Warenwert         = ttPV_K_BelegSumKopf-Cor.Gesamt_Belegsumme[iTaxRates]
        ttV_BelegTaxrateSums-PPCor.Warenwert_ohne_AA = ttPV_K_BelegSumKopf-Cor.Gesamt_Belegsumme[iTaxRates]
                                                       - ttPV_K_BelegSumKopf-Cor.Gesamt_Anzahlungen[iTaxRates]
        .
  
  
  
      if ttV_BelegKopf-P.Brutto = no then   /* von Nettobetrag */
        ttV_BelegTaxrateSums-PPCor.Steuer  = round((ttPV_K_BelegSumKopf-Cor.Gesamt_Belegsumme[iTaxRates]
                                               + (if iTaxRates = ttV_BelegKopf-P.Zuschlag_Extent then
                                                    ttPV_K_BelegSumKopf-Cor.Gesamtzuschlag
                                                  else
                                                    0))
                                               * ttPV_K_BelegSumKopf-Cor.Gesamt_Steuersatz[iTaxRates] / 100,
                                               ttV_BelegKopf-P.WaehrungNK).
      else                              /* aus Bruttobetrag */
        ttV_BelegTaxrateSums-PPCor.Steuer = round((ttPV_K_BelegSumKopf-Cor.Gesamt_Belegsumme[iTaxRates]
                                               + (if iTaxRates = ttV_BelegKopf-P.Zuschlag_Extent then
                                                    ttPV_K_BelegSumKopf-Cor.Gesamtzuschlag
                                                  else
                                                    0))
                                               / (1 + ttPV_K_BelegSumKopf-Cor.Gesamt_Steuersatz[iTaxRates] / 100)
                                               * ttPV_K_BelegSumKopf-Cor.Gesamt_Steuersatz[iTaxRates] / 100,
                                               ttV_BelegKopf-P.WaehrungNK).
  
      assign
  
        ttV_BelegTaxrateSums-PPCor.Summe_excl =  ttPV_K_BelegSumKopf-Cor.Gesamt_Belegsumme[iTaxRates]
                                              + (if iTaxRates = ttV_BelegKopf-P.Zuschlag_Extent then
                                                   ttPV_K_BelegSumKopf-Cor.Gesamtzuschlag
                                                 else
                                                   0)
                                              - (if ttV_BelegKopf-P.Brutto = no then /* Nettobeleg oder Bruttobeleg */
                                                   0
                                                 else
                                                   ttV_BelegTaxrateSums-PPCor.Steuer)
  
        ttV_BelegTaxrateSums-PPCor.Summe_incl = ttPV_K_BelegSumKopf-Cor.Gesamt_Belegsumme[iTaxRates]
                                              + (if iTaxRates = ttV_BelegKopf-P.Zuschlag_Extent then
                                                   ttPV_K_BelegSumKopf-Cor.Gesamtzuschlag
                                                 else
                                                   0)
                                              + (if ttV_BelegKopf-P.Brutto = no then /* Nettobeleg oder Bruttobeleg */
                                                   ttV_BelegTaxrateSums-PPCor.Steuer
                                                 else
                                                   0)
        .
  
  
      /* All surcharches have the same taxrate  - the surcharge fields are only */
      /* filled for the taxrate they correspond with... (Zuschlag_Extent)       */
  
      if iTaxRates = ttV_BelegKopf-P.Zuschlag_Extent then
        ttV_BelegTaxrateSums-PPCor.Zuschlaege     =  ttPV_K_BelegSumKopf-Cor.Gesamtzuschlag.
  
      /* If Eurofaktor field is > 0  and the documents domestic currency is not */
      /* EUR, the EUR_* fields are filled ... this was important during the     */
      /* years of transition to the Euro. It might be important again if        */
      /* further countried join the Euro or countries having the Euro now,      */
      /* abandom it in the future!                                              */
  
      if ttS_Waehrung-P1.Eurofaktor > 0 then
        assign
          ttV_BelegTaxrateSums-PPCor.Eur_Anzahlungen          = ttV_BelegTaxrateSums-PPCor.Anzahlungen / ttS_Waehrung-P1.Eurofaktor
          ttV_BelegTaxrateSums-PPCor.Eur_Summe_excl           = ttV_BelegTaxrateSums-PPCor.Summe_excl / ttS_Waehrung-P1.Eurofaktor
          ttV_BelegTaxrateSums-PPCor.Eur_Summe_incl           = ttV_BelegTaxrateSums-PPCor.Summe_incl / ttS_Waehrung-P1.Eurofaktor
          ttV_BelegTaxrateSums-PPCor.Eur_Steuer               = ttV_BelegTaxrateSums-PPCor.Steuer  / ttS_Waehrung-P1.Eurofaktor
          ttV_BelegTaxrateSums-PPCor.Eur_Warenwert            = ttV_BelegTaxrateSums-PPCor.Warenwert / ttS_Waehrung-P1.Eurofaktor
          ttV_BelegTaxrateSums-PPCor.Eur_Warenwert_ohne_AA    = ttV_BelegTaxrateSums-PPCor.Warenwert_ohne_AA / ttS_Waehrung-P1.Eurofaktor
          ttV_BelegTaxrateSums-PPCor.Eur_Zuschlaege           = ttV_BelegTaxrateSums-PPCor.Zuschlaege / ttS_Waehrung-P1.Eurofaktor
        .
  
      assign
        dPGesamtsumme = (  ttPV_K_BelegSumKopf-Cor.Gesamt_Belegsumme[11]
                         + ttPV_K_BelegSumKopf-Cor.Gesamtzuschlag
                         + (if ttV_BelegKopf-P.Brutto = no then /* Nettobeleg oder Bruttobeleg */
                              ttPV_K_BelegSumKopf-Cor.Gesamtsteuer
                            else
                              0))
        dEurofaktor   = (if available ttS_Waehrung-P1 then
                           ttS_Waehrung-P1.Eurofaktor
                         else
                           0)
  
        ttV_BelegTaxrateSums-PPCor.WorteEndBetrag = SBCLocalizationPLSvc:prpoInstance:cSpokenNumber
                                                      (gcFirma,
                                                       gcContentLanguage,
                                                       ttV_BelegKopf-P.Waehrung,
                                                       dPGesamtsumme)
        .
        
      if dEuroFaktor <> 0 then
        ttV_BelegTaxrateSums-PPCor.WorteEndBetrag_EUR = SBCLocalizationPLSvc:prpoInstance:cSpokenNumber
                                                          (gcFirma,
                                                           gcContentLanguage,
                                                           ?,
                                                           dPGesamtsumme / dEuroFaktor).
  
      /* P_Zahlhinweis */
      if iTaxRates = ttV_BelegKopf-P.Zuschlag_Extent then
        ttV_BelegTaxrateSums-PPCor.P_Zahlhinweis = string(dPGesamtsumme >= 0).
  
      assign
        ttV_BelegTaxrateSums-PPCor.P_Gesamtsumme_EW = dPGesamtsumme * dExRate
        ttV_BelegTaxrateSums-PPCor.P_Summe_excl_EW  = ttV_BelegTaxrateSums-PPCor.Summe_excl * dExRate
        ttV_BelegTaxrateSums-PPCor.P_Summe_incl_EW  = ttV_BelegTaxrateSums-PPCor.Summe_incl * dExRate
        ttV_BelegTaxrateSums-PPCor.Steuer_EW        = ttV_BelegTaxrateSums-PPCor.Steuer * dTaxExRate
        .
  
    end. /* if lVariousTaxRates and not can-find(ttV_BelegTaxrateSums-PPCor */
  
  end. /* iTaxRates = 1 to extent(ttPV_K_BelegSumKopf-Cor.Gesamt_Steuersatz) */

end procedure. /* P_fillK_CorDocTaxrateSumsForLLPrint */


/* _UIB-CODE-BLOCK-END */
&ANALYZE-RESUME

&ENDIF


&IF DEFINED(EXCLUDE-P_fillK_CorDocTotalSumForLLPrint) = 0 &THEN

&ANALYZE-SUSPEND _UIB-CODE-BLOCK _PROCEDURE P_fillK_CorDocTotalSumForLLPrint Method-Library 
procedure P_fillK_CorDocTotalSumForLLPrint :
/* Description ---------------------------------------------------------------*/
/*                                                                            */
/* Calculates the document total sums.                                        */
/* TT ttPV_K_BelegSumKopf-Cor must be filled before calling this procedure!     */
/*                                                                            */
/* Notes ---------------------------------------------------------------------*/
/*                                                                            */
/* This procedure does only encapsulate code for better readability of        */
/* fillDataset procedure. It can only be used in the context of this DAO      */
/* run super() has been execute an a global ttV_BelegKopf-P Buffer is         */
/* available... so passing of paramters was forgone deliberatly.              */
/*                                                                            */
/*----------------------------------------------------------------------------*/

  create ttV_BelegTotalSum-PPCor.
  assign
    ttV_BelegTotalSum-PPCor.Gesamtsumme = ttPV_K_BelegSumKopf-Cor.Gesamt_Belegsumme[11]
                                          + ttPV_K_BelegSumKopf-Cor.Gesamtzuschlag
                                          + (if ttV_BelegKopf-P.Brutto = no then /* Nettobeleg oder Bruttobeleg */
                                               ttPV_K_BelegSumKopf-Cor.Gesamtsteuer
                                             else
                                               0)
    ttV_BelegTotalSum-PPCor.Frachtsumme = ttPV_K_BelegSumKopf-Cor.Frachtsumme
    ttV_BelegTotalSum-PPCor.Owning_Obj  = ttV_BelegKopf-P.V_BelegKopf_Obj
    .
  
  /* If Eurofaktor field is > 0  and the documents domestic currency is not */
  /* EUR, the EUR_* fields are filled ... this was important during the     */
  /* years of transition to the Euro. It might be important again if        */
  /* further countried join the Euro or countries having the Euro now,      */
  /* abandom it in the future!                                              */
  
  if ttS_Waehrung-P1.Eurofaktor > 0
    and not ttS_Waehrung-P1.ISO_KurzBez = 'EUR':U then
    assign
      ttV_BelegTotalSum-PPCor.Eur_Frachtsumme          = ttV_BelegTotalSum-PPCor.Frachtsumme / ttS_Waehrung-P1.Eurofaktor
      ttV_BelegTotalSum-PPCor.Eur_Gesamtsumme          = ttV_BelegTotalSum-PPCor.Gesamtsumme / ttS_Waehrung-P1.Eurofaktor
      ttV_BelegTotalSum-PPCor.Eur_Zuschlaege           = ttPV_K_BelegSumKopf-Cor.Gesamtzuschlag / ttS_Waehrung-P1.Eurofaktor
      .

end procedure. /* P_fillK_CorDocTotalSumForLLPrint */


/* _UIB-CODE-BLOCK-END */
&ANALYZE-RESUME

&ENDIF


&IF DEFINED(EXCLUDE-fillEuroKurzBezGlobalVar) = 0 &THEN

&ANALYZE-SUSPEND _UIB-CODE-BLOCK _PROCEDURE fillEuroKurzBezGlobalVar Method-Library 
procedure fillEuroKurzBezGlobalVar :
/* Description ---------------------------------------------------------------*/
/*                                                                            */
/* Fill global variable gcEuroKurzBez, because the value is needed as         */
/* as L&L variable and for print masks.                                       */
/*                                                                            */
/* Notes ---------------------------------------------------------------------*/
/*                                                                            */
/* The ISO code EUR is used to determine the S_Waehrung record of the         */
/* EUR currency and the S_WaehrungSpr.KurzBez is returned because a           */
/* string in gcContentLanguage is needed.                                     */
/*                                                                            */
/*----------------------------------------------------------------------------*/

define buffer bS_Waehrung     for S_Waehrung.
define buffer bS_WaehrungSpr  for S_WaehrungSpr.

  
  /* currency EUR  must exist ! */
  
  find first bS_Waehrung
    where bS_Waehrung.Firma       =  {firma/swaehrun.fir gcFirma}
      and bS_Waehrung.ISO_KurzBez = 'EUR':U
    no-lock.
  
  {adm/incl/d__spr00.if
     &Tabelle  = "bS_WaehrungSpr"
     &Selekt   = "where bS_WaehrungSpr.Firma    = {firma/swaehrun.fir gcFirma}   /* code checked by Tupath 03.01.2017 */
                    and bS_WaehrungSpr.Waehrung = bS_Waehrung.Waehrung"
     &Sprache  = "gcContentLanguage"
   }
  
  gcEuroKurzBez = bS_WaehrungSpr.KurzBez.

end procedure. /* fillEuroKurzBezGlobalVar */


/* _UIB-CODE-BLOCK-END */
&ANALYZE-RESUME

&ENDIF


&IF DEFINED(EXCLUDE-fillFactorBankDataForLLPrint) = 0 &THEN

&ANALYZE-SUSPEND _UIB-CODE-BLOCK _PROCEDURE fillFactorBankDataForLLPrint Method-Library 
procedure fillFactorBankDataForLLPrint :
/* Description ---------------------------------------------------------------*/
/*                                                                            */
/* Create and fill bttS_BankVerb-P2 record for the current gbV_BelegKopf      */
/*                                                                            */
/*----------------------------------------------------------------------------*/

/* Variables -----------------------------------------------------------------*/
/* cFactorObj      factor OID                                                 */
/*----------------------------------------------------------------------------*/

define variable cFactorObj like FMM_Factor.FMM_Factor_Obj no-undo.

define buffer bFMM_Factor           for FMM_Factor.
define buffer bS_BankVerb           for S_BankVerb.
define buffer bS_Bank               for S_Bank.
define buffer bS_Adresse            for S_Adresse.
define buffer bttS_BankVerb-P2      for temp-table ttS_BankVerb-P2.


&IF LOOKUP("FM_Factor","{&PA-OPTIONEN}") > 0 &THEN

  cFactorObj = fibu.base.cls.FMCMasterFilesSvc:prpoInstance:cValidFactorAssignmentObj
                 (ttS_Kunde-P1.S_Kunde_Obj,
                  gbV_BelegKopf.BelegDatum).

  if cFactorObj > '':U then
  do:

    ttV_BelegKopf-P.FMM_Factor_Obj = cFactorObj.

    find bFMM_Factor
      where bFMM_Factor.FMM_Factor_Obj = cFactorObj
      no-lock no-error.

    if    available bFMM_Factor
      and bFMM_Factor.S_BankVerb_Obj > '':U then
    do:

      find bS_BankVerb
        where bS_BankVerb.S_BankVerb_Obj = bFMM_Factor.S_BankVerb_Obj
        no-lock no-error.

      if available bS_BankVerb then
      do:

        find bS_Bank
          where bS_Bank.Firma = {firma/s_bank_.fir bS_BankVerb.Firma}
            and bS_Bank.Bank  = bS_BankVerb.Bank
          no-lock.

        find bS_Adresse
          where bS_Adresse.Firma    = {firma/s_adres.fir bS_Bank.Firma}
            and bS_Adresse.AdressNr = bS_Bank.AdressNr
          no-lock.

        create bttS_BankVerb-P2.

        assign
          bttS_BankVerb-P2.V_BelegKopf_Obj = gbV_BelegKopf.V_BelegKopf_Obj
          bttS_BankVerb-P2.Name1           = bS_Adresse.Name1
          bttS_BankVerb-P2.IBAN            = bS_BankVerb.IBAN
          bttS_BankVerb-P2.BankAccount     = bS_BankVerb.BankKonto
          bttS_BankVerb-P2.Swift           = bS_Bank.SwiftNr
          bttS_BankVerb-P2.BankRoutingNo   = bS_Bank.BLZ
          .

        validate bttS_BankVerb-P2.

      end. /* if available bS_BankVerb  */

    end. /* if available bFMM_Factor  */

  end. /* if cFactorObj > '':U */

&ENDIF

end procedure. /* fillFactorBankDataForLLPrint */


/* _UIB-CODE-BLOCK-END */
&ANALYZE-RESUME

&ENDIF


&IF DEFINED(EXCLUDE-fillFactoringGlobalVar) = 0 &THEN

&ANALYZE-SUSPEND _UIB-CODE-BLOCK _PROCEDURE fillFactoringGlobalVar Method-Library 
procedure fillFactoringGlobalVar :
/* Description ---------------------------------------------------------------*/
/*                                                                            */
/* Fill global variable glFactoring                                           */
/*                                                                            */
/*----------------------------------------------------------------------------*/

&IF LOOKUP("FM_Factor","{&PA-OPTIONEN}") > 0 &THEN

  glFactoring = (    fibu.base.cls.FMCMasterFilesSvc:prpoInstance:lCustomerHasValidFactorAssignment
                       (gbV_BelegKopf.Kunde,
                        gbV_BelegKopf.BelegDatum)
                 and not (    gbV_BelegKopf.Schlussrechnung = no
                          and gbV_BelegKopf.Teilrechnung    = no
                          and can-do('R,G':U,gbV_BelegKopf.Belegart)
                          and can-find(first V_BelegPos
                                         where V_BelegPos.Firma      = gbV_BelegKopf.Firma
                                           and V_BelegPos.BelegArt   = gbV_BelegKopf.Belegart
                                           and V_BelegPos.ReferenzNr = gbV_BelegKopf.ReferenzNr
                                           and can-find(S_Artikel
                                                          where S_Artikel.Firma      = {firma/sartikel.fir V_BelegPos.Firma}
                                                            and S_Artikel.Artikel    = V_BelegPos.Artikel
                                                            and S_Artikel.ArtikelArt = {&pa_S_PT_PartPayAndMarkdowns})))).

&ENDIF

end procedure. /* fillFactoringGlobalVar */


/* _UIB-CODE-BLOCK-END */
&ANALYZE-RESUME

&ENDIF


&IF DEFINED(EXCLUDE-FillHeadSupplierTaxIDForLLPrint) = 0 &THEN

&ANALYZE-SUSPEND _UIB-CODE-BLOCK _PROCEDURE FillHeadSupplierTaxIDForLLPrint Method-Library 
procedure FillHeadSupplierTaxIDForLLPrint :
/* Description ---------------------------------------------------------------*/
/*                                                                            */
/* If the suppliers tax id of each doc. line is the same then it can be       */
/* copied for the doc. header                                                 */
/*                                                                            */
/*----------------------------------------------------------------------------*/

define variable cSuppTaxIDHead           like V_BelegKopf.TaxID         no-undo.

define buffer bttV_BelegPos-P for temp-table ttV_BelegPos-P.


  for each bttV_BelegPos-P
    break by bttV_BelegPos-P.PositionsNr:
  
    if first(bttV_BelegPos-P.PositionsNr) then
  
      cSuppTaxIDHead = bttV_BelegPos-P.SupplierTaxID.
  
    else
  
      if bttV_BelegPos-P.SupplierTaxID <> cSuppTaxIDHead then
  
        cSuppTaxIDHead = '':U.
  
  end. /* for each bttV_BelegPos-P */
  
  ttV_BelegKopf-P.SupplierTaxID = cSuppTaxIDHead.

end procedure. /* FillHeadSupplierTaxIDForLLPrint */


/* _UIB-CODE-BLOCK-END */
&ANALYZE-RESUME

&ENDIF


&IF DEFINED(EXCLUDE-fillMaintenanceAgreementInfoForLLPrint) = 0 &THEN

&ANALYZE-SUSPEND _UIB-CODE-BLOCK _PROCEDURE fillMaintenanceAgreementInfoForLLPrint Method-Library 
procedure fillMaintenanceAgreementInfoForLLPrint :
/* Description ---------------------------------------------------------------*/
/*                                                                            */
/* Create and fill Maintenance Agreement information if predecessors  of      */
/* ttV_BelegPos-P exist.                                                      */
/*                                                                            */
/* Notes ---------------------------------------------------------------------*/
/*                                                                            */
/* This procedure does only encapsulate code for better readability of        */
/* fillDataset procedure. It can only be used in the context of this DAO !    */
/* run super() must have been executed and a global ttV_BelegKopf-P  and      */
/* ttV_BelegPos-P must be available!                                          */
/*                                                                            */
/*----------------------------------------------------------------------------*/

define variable cSourceDocLineObj as  character       no-undo.

&IF LOOKUP("VS_WVERT","{&PA-OPTIONEN}") > 0 &THEN
define buffer bVST_MaintContractPos     for VST_MaintContractPos.
define buffer bVST_MaintContract        for VST_MaintContract.
define buffer bS_Artikel                for S_Artikel.
define buffer bS_ArtVar                 for S_ArtVar.
define buffer bS_AuftragsArt            for S_AuftragsArt.

&IF LOOKUP("MS","{&PA-MODULE}") > 0 &THEN
define buffer bMS_SNR                   for MS_SNR.
define buffer bttMS_SNR-PMaint          for temp-table ttMS_SNR-PMaint.
&ENDIF

define buffer bttVST_MaintContractPos-P for temp-table ttVST_MaintContractPos-P.
define buffer bttVST_MaintContract-P    for temp-table ttVST_MaintContract-P.
define buffer bttS_Artikel-PMaint       for temp-table ttS_Artikel-PMaint.
define buffer bttS_ArtVar-PMaint        for temp-table ttS_ArtVar-PMaint.
define buffer bttS_AuftragsArt-P2Maint  for temp-table ttS_AuftragsArt-P2Maint.
&ENDIF


&IF LOOKUP("VS_WVERT","{&PA-OPTIONEN}") > 0 &THEN

  if    can-do('R,G':U,ttV_BelegKopf-P.Belegart)
    and ttV_BelegKopf-P.Herk_Belegart <> ? then
  do:

    /* for current V_BelegPos: look for a source doc of type      */
    /* maintenance contract (could be in the order VSW-R-G-R)     */

    cSourceDocLineObj = vert.base.cls.VBCSalesDocSvc:prpoInstance:cGetSourceDocLineObj
                          ('VSW':U,
                           ttV_BelegPos-P.V_BelegPos_Obj).

    if cSourceDocLineObj <> ? then
    do:

      find bVST_MaintContractPos
        where bVST_MaintContractPos.VST_MaintContractPos_Obj = cSourceDocLineObj
        no-lock no-error.

      if available bVST_MaintContractPos then

        find bVST_MaintContract
          where bVST_MaintContract.VST_MaintContract_Obj = bVST_MaintContractPos.VST_MaintContract_Obj
          no-lock.

      else

        find bVST_MaintContract
          where bVST_MaintContract.VST_MaintContract_Obj = cSourceDocLineObj
          no-lock no-error.

      if available bVST_MaintContract then
      do:

        if not can-find(bttVST_MaintContract-P
                          where bttVST_MaintContract-P.VST_MaintContract_Obj = bVST_MaintContract.VST_MaintContract_Obj
                             or bttVST_MaintContract-P.VST_MaintContract_Obj = ttV_BelegKopf-P.Origin_Obj) then
        do:

          create bttVST_MaintContract-P.

          {buffer-copy
             bVST_MaintContract
             except "Firma"
             to bttVST_MaintContract-P
             assign
               "bttVST_MaintContract-P.Firma = gcFirma"}

            if    ttV_BelegKopf-P.Origin_Obj  > '':U 
              and ttV_BelegKopf-P.Origin_Obj <> bttVST_MaintContract-P.VST_MaintContract_Obj then

              bttVST_MaintContract-P.VST_MaintContract_Obj = ttV_BelegKopf-P.Origin_Obj.

            else

              ttV_BelegKopf-P.Origin_Obj = bVST_MaintContract.VST_MaintContract_Obj.

          validate bttVST_MaintContract-P.

        end.  /* if not can-find(bttVST_MaintContract-P */

        if    available bVST_MaintContractPos
          and not can-find(bttVST_MaintContractPos-P
                     where bttVST_MaintContractPos-P.VST_MaintContractPos_Obj = cSourceDocLineObj) then        
        do:

          create bttVST_MaintContractPos-P.

          {buffer-copy
             bVST_MaintContractPos
             to bttVST_MaintContractPos-P
             assign
               "bttVST_MaintContractPos-P.Firma         = gcFirma
                bttVST_MaintContractPos-P.Owning_Obj    = ttV_BelegPos-P.V_BelegPos_Obj"}

          validate bttVST_MaintContractPos-P.

        end. /* if available bVST_MaintContractPos */

        if    available bttVST_MaintContractPos-P
          and bttVST_MaintContractPos-P.ArtikelWartung > '':U then
        do:

          find bS_Artikel
            where bS_Artikel.Firma   = {firma/sartikel.fir gcFirma}
              and bS_Artikel.Artikel = bttVST_MaintContractPos-P.ArtikelWartung
            no-lock no-error.

          if available bS_Artikel then
          do:

            bttVST_MaintContractPos-P.ArtVarTyp = bS_Artikel.ArtVarTyp.

            if not can-find(bttS_Artikel-PMaint
                       where bttS_Artikel-PMaint.Firma   = gcFirma
                         and bttS_Artikel-PMaint.Artikel = bttVST_MaintContractPos-P.ArtikelWartung) then
            do:

              create bttS_Artikel-PMaint.

              {buffer-copy
                 bS_Artikel
                 to bttS_Artikel-PMaint
                 assign
                   "bttS_Artikel-PMaint.Firma = gcFirma"}

              validate bttS_Artikel-PMaint.

            end.  /* if not can-find(bttS_Artikel-PMaint */

          end.  /* if available bS_Artikel */

          if    bttVST_MaintContractPos-P.ArtVarWartung > '':U
            and not can-find(bttS_ArtVar-PMaint
                       where bttS_ArtVar-PMaint.ArtVarTyp = bttVST_MaintContractPos-P.ArtVarTyp
                         and bttS_ArtVar-PMaint.ArtVar    = bttVST_MaintContractPos-P.ArtVarWartung) then
          do:

            find bS_ArtVar
              where bS_ArtVar.ArtVarTyp = bttVST_MaintContractPos-P.ArtVarTyp
                and bS_ArtVar.ArtVar    = bttVST_MaintContractPos-P.ArtVarWartung
              no-lock no-error.

            if available bS_ArtVar then
            do:

              create bttS_ArtVar-PMaint.

              {buffer-copy
                 bS_ArtVar
                 to bttS_ArtVar-PMaint}

              validate bttS_ArtVar-PMaint.

            end.  /* if available bS_ArtVar */

          end.  /* if bttVST_MaintContractPos-P.ArtVarWartung > '':U */

          &IF LOOKUP("MS","{&PA-MODULE}") > 0 &THEN

            if    bttVST_MaintContractPos-P.MS_SNR_Obj > '':U
              and not can-find(bttMS_SNR-PMaint
                         where bttMS_SNR-PMaint.MS_SNR_Obj = bttVST_MaintContractPos-P.MS_SNR_Obj) then
            do:

              find bMS_SNR
                where bMS_SNR.MS_SNR_Obj = bttVST_MaintContractPos-P.MS_SNR_Obj
                no-lock no-error.

              if available bMS_SNR then
              do:

                create bttMS_SNR-PMaint.

                {buffer-copy
                   bMS_SNR
                   to bttMS_SNR-PMaint
                   assign
                     "bttMS_SNR-PMaint.Firma = gcFirma"}

                validate bttMS_SNR-PMaint.

              end.  /* if available bMS_SNR */

            end.  /* if bttVST_MaintContractPos-P.MS_SNR_Obj > '':U */

          &ENDIF

        end.  /* if    available bttVST_MaintContractPos-P ... */

        find bS_AuftragsArt
          where bS_AuftragsArt.S_AuftragsArt_Obj = bVST_MaintContract.S_AuftragsArt_Obj
          no-lock no-error.

        if    available bS_AuftragsArt
          and not can-find(bttS_AuftragsArt-P2Maint
                     where bttS_AuftragsArt-P2Maint.S_AuftragsArt_Obj = bS_AuftragsArt.S_AuftragsArt_Obj) then
        do:

          create bttS_AuftragsArt-P2Maint.

          {buffer-copy
             bS_AuftragsArt
             to bttS_AuftragsArt-P2Maint
             assign
               "bttS_AuftragsArt-P2Maint.Firma = gcFirma"}

          validate bttS_AuftragsArt-P2Maint.

        end.  /* if available bS_AuftragsArt */

      end.  /* if available bVST_MaintContract */

    end.  /* if cSourceDocLineObj <> ? */

  end.  /* if ttV_BelegKopf-P.Belegart = 'R':U */

&ENDIF  /* VS_WVERT */

end procedure. /* fillMaintenanceAgreementInfoForLLPrint */


/* _UIB-CODE-BLOCK-END */
&ANALYZE-RESUME

&ENDIF


&IF DEFINED(EXCLUDE-fillPackagingInfoForLLPrint) = 0 &THEN

&ANALYZE-SUSPEND _UIB-CODE-BLOCK _PROCEDURE fillPackagingInfoForLLPrint Method-Library 
procedure fillPackagingInfoForLLPrint :
/* Description ---------------------------------------------------------------*/
/*                                                                            */
/* Create and fill Packaging information                                      */
/*                                                                            */
/* Notes ---------------------------------------------------------------------*/
/*                                                                            */
/* This procedure does only encapsulate code for better readability of        */
/* fillDataset procedure. It can only be used in the context of this DAO !    */
/* run super() must have been executed and a global ttV_BelegKopf-P  and      */
/* ttV_BelegPos-P must be available!                                          */
/*                                                                            */
/*----------------------------------------------------------------------------*/

define buffer bV_BelegPos-Invoice for V_BelegPos.
define buffer bV_BelegPos         for V_BelegPos.
define buffer bV_BelegKopf        for V_BelegKopf.

define buffer bttM_LTPos-P1                 for temp-table ttM_LTPos-P1.
define buffer bttMM_PackSummary-P           for temp-table ttMM_PackSummary-P.
define buffer bttMM_PackSummary-P-Duplicate for temp-table ttMM_PackSummary-P.


&IF lookup("M_PACK","{&PA-OPTIONEN}") > 0 &THEN

  if   ttV_BelegKopf-P.Belegart = 'L':U 
    or ttV_BelegKopf-P.Belegart = 'VUD':U then
  do:

    mawi.base.cls.MMCPackagingSvc:prpoInstance:PrintPackagingForm
      (             ttV_BelegKopf-P.Firma,
                    gcContentLanguage,
                    'V':U,
                    ttV_BelegKopf-P.Kunde,
                    ttV_BelegKopf-P.Belegart,
                    {vert/incl/v_belko.sl &Tabelle = "ttV_BelegKopf-P"},
                    yes,
                    yes,
                    adm.config.cls.DCCAppConfigSvc:prpoInstance:lParameterValue('MM_PackagingPrintingDeliveryNoteWeights':U),
       input-output table ttM_LTPos-P1,
       input-output table ttMM_PackSummary-P).
           
  end.
  else if ttV_BelegKopf-P.Belegart      = 'R':U
    and ttV_BelegKopf-P.Herk_ReferenzNr = ? 
    and ttV_BelegKopf-P.Herk_BelegArt   = 'L':U then
  do:   

    for each bV_BelegPos-Invoice
      where bV_BelegPos-Invoice.Firma      = {firma/vbelegko.fir ttV_BelegKopf-P.Firma}
        and bV_BelegPos-Invoice.Belegart   = ttV_BelegKopf-P.Belegart
        and bV_BelegPos-Invoice.ReferenzNr = ttV_BelegKopf-P.ReferenzNr
      no-lock,
      each bV_BelegPos
        where bV_BelegPos.Firma       = {firma/vbelegko.fir ttV_BelegKopf-P.Firma}
          and bV_BelegPos.Belegart    = bV_BelegPos-Invoice.Herk_Belegart
          and bV_BelegPos.ReferenzNr  = bV_BelegPos-Invoice.Herk_ReferenzNr
          and bV_BelegPos.PositionsNr = bV_BelegPos-Invoice.Herk_PositionsNr
        no-lock:

        find bV_BelegKopf
          where bV_BelegKopf.Firma      = bV_BelegPos.Firma
            and bV_BelegKopf.Belegart   = bV_BelegPos.Belegart
            and bV_BelegKopf.ReferenzNr = bV_BelegPos.ReferenzNr
          no-lock.

          mawi.base.cls.MMCPackagingSvc:prpoInstance:PrintPackagingForm
          (             bV_BelegKopf.Firma,
                        gcContentLanguage,
                        'V':U,
                        bV_BelegKopf.Kunde,
                        bV_BelegKopf.Belegart,
                        {vert/incl/v_belpo.sl &Tabelle = "bV_BelegPos"}, 
                        yes,
                        yes,
                        no,
                        yes,
                        no,
           input-output table ttM_LTPos-P1,
           input-output table ttMM_PackSummary-P).

        for each bttM_LTPos-P1
          where bttM_LTPos-P1.DocumentLine = bV_BelegPos.V_BelegPos_Obj:

          bttM_LTPos-P1.DocumentLine = bV_BelegPos-Invoice.V_BelegPos_Obj.          
          validate bttM_LTPos-P1.

        end.  /* for each bttM_LTPos-P1 */    

    end.  /* for each bV_BelegPos-Invoice */

    for each bttMM_PackSummary-P:

      for each bttMM_PackSummary-P-Duplicate
        where bttMM_PackSummary-P-Duplicate.Herk_Schluessel2 <> bttMM_PackSummary-P.Herk_Schluessel2
          and bttMM_PackSummary-P-Duplicate.Mehrweg           = bttMM_PackSummary-P.Mehrweg
          and bttMM_PackSummary-P-Duplicate.Zubehoer          = bttMM_PackSummary-P.Zubehoer
          and bttMM_PackSummary-P-Duplicate.Packmittel        = bttMM_PackSummary-P.Packmittel:

        bttMM_PackSummary-P.Menge = bttMM_PackSummary-P.Menge + bttMM_PackSummary-P-Duplicate.Menge.

        validate bttMM_PackSummary-P.

        delete bttMM_PackSummary-P-Duplicate.

      end.  /* for each bttMM_PackSummary-P-Duplicate */

      bttMM_PackSummary-P.Herk_Schluessel2 = ttV_BelegKopf-P.V_BelegKopf_Obj.

      validate bttMM_PackSummary-P.

    end.  /* for each bttMM_PackSummary-P */

  end.  /* if    ttV_BelegKopf-P.Belegart = 'R':U */
  else

    mawi.base.cls.MMCPackagingSvc:prpoInstance:PrintPackagingForm
      (             ttV_BelegKopf-P.Firma,
                    gcContentLanguage,
                    'V':U,
                    ttV_BelegKopf-P.Kunde,
                    ttV_BelegKopf-P.Belegart,
                    {vert/incl/v_belko.sl &Tabelle = "ttV_BelegKopf-P"},
                    yes,
                    yes,
                    yes,
       input-output table ttM_LTPos-P1,
       input-output table ttMM_PackSummary-P).

&ENDIF

end procedure. /* fillPackagingInfoForLLPrint */


/* _UIB-CODE-BLOCK-END */
&ANALYZE-RESUME

&ENDIF

&IF DEFINED(EXCLUDE-FillPricesAlternatepartForLLPrint) = 0 &THEN

&IF lookup("VU_ABAUF_FZ":U,"{&PA-OPTIONEN}":U) > 0 &THEN

&ANALYZE-SUSPEND _UIB-CODE-BLOCK _PROCEDURE FillPricesAlternatepartForLLPrint Method-Library 
procedure FillPricesAlternatepartForLLPrint :
/* Description ---------------------------------------------------------------*/
/*                                                                            */
/*  Create and fill Prices for AlternatePart                                  */
/*                                                                            */
/* Notes ---------------------------------------------------------------------*/
/*                                                                            */
/* This procedure does only encapsulate code for better readability of        */
/* fillDataset procedure. It can only be used in the context of this DAO !    */
/* run super() must have been executed and a global ttV_BelegKopf-P  and      */
/* ttV_BelegPos-P must be available!                                          */
/*                                                                            */
/*----------------------------------------------------------------------------*/

define buffer bVU_RA_Preis                  for VU_RA_Preis.
define buffer bttVU_RA_Preis-P1Alternate    for temp-table ttVU_RA_Preis-P1Alternate.


  if can-do('VUR,VUA':U,ttV_BelegKopf-P.Belegart) then
  
    for each ttVU_RA_Artikel-P
      where ttVU_RA_Artikel-P.Firma       = ttV_BelegPos-P.Firma
        and ttVU_RA_Artikel-P.Belegart    = ttV_BelegPos-P.Belegart
        and ttVU_RA_Artikel-P.ReferenzNr  = ttV_BelegPos-P.ReferenzNr
        and ttVU_RA_Artikel-P.PositionsNr = ttV_BelegPos-P.PositionsNr
      no-lock,
      each bVU_RA_Preis
        where bVU_RA_Preis.Firma       = ttVU_RA_Artikel-P.Firma
          and bVU_RA_Preis.Belegart    = ttVU_RA_Artikel-P.Belegart
          and bVU_RA_Preis.ReferenzNr  = ttVU_RA_Artikel-P.ReferenzNr
          and bVU_RA_Preis.PositionsNr = ttVU_RA_Artikel-P.PositionsNr
          and bVU_RA_Preis.Artikel     = ttVU_RA_Artikel-P.Artikel
          and bVU_RA_Preis.ArtVar      = ttVU_RA_Artikel-P.ArtVar
        no-lock:
  
      create  bttVU_RA_Preis-P1Alternate.
  
      {buffer-copy
         bVU_RA_Preis
         to bttVU_RA_Preis-P1Alternate
         assign
           "bttVU_RA_Preis-P1Alternate.Firma             = gcFirma
            bttVU_RA_Preis-P1Alternate.Eur_Einzelpreis   = bttVU_RA_Preis-P1Alternate.Einzelpreis / ttS_Waehrung-P1.Eurofaktor
            bttVU_RA_Preis-P1Alternate.Eur_Gesamtpreis   = (bttVU_RA_Preis-P1Alternate.Einzelpreis
                                                              * (1 + bttVU_RA_Preis-P1Alternate.proz_RZ_1 / 100)
                                                              * (1 + bttVU_RA_Preis-P1Alternate.proz_RZ_2 / 100)
                                                              * (1 + bttVU_RA_Preis-P1Alternate.proz_RZ_3 / 100)
                                                              + bttVU_RA_Preis-P1Alternate.Wert_RZ_1
                                                              + bttVU_RA_Preis-P1Alternate.Wert_RZ_2) / ttS_Waehrung-P1.Eurofaktor
            bttVU_RA_Preis-P1Alternate.Eur_Verkaufspreis = (bttVU_RA_Preis-P1Alternate.Einzelpreis
                                                              + bttVU_RA_Preis-P1Alternate.wert_RZ_1
                                                              + bttVU_RA_Preis-P1Alternate.wert_RZ_2) / ttS_Waehrung-P1.Eurofaktor
            bttVU_RA_Preis-P1Alternate.Gesamtpreis       = (bttVU_RA_Preis-P1Alternate.Einzelpreis
                                                              * (1 + bttVU_RA_Preis-P1Alternate.proz_RZ_1 / 100)
                                                              * (1 + bttVU_RA_Preis-P1Alternate.proz_RZ_2 / 100)
                                                              * (1 + bttVU_RA_Preis-P1Alternate.proz_RZ_3 / 100)
                                                              + bttVU_RA_Preis-P1Alternate.Wert_RZ_1
                                                              + bttVU_RA_Preis-P1Alternate.Wert_RZ_2)"}
  
      validate bttVU_RA_Preis-P1Alternate.
  
      vert.base.cls.VBCSalesDocSvc:prpoInstance:LLFillDiscountSurchargeDesc
         (gcContentLanguage,
         buffer bttVU_RA_Preis-P1Alternate:handle,
         buffer bttVU_RA_Preis-P1Alternate:handle).
  
    end.

end procedure. /* FillPricesAlternatepartForLLPrint */


/* _UIB-CODE-BLOCK-END */
&ANALYZE-RESUME

&ENDIF

&ENDIF

&IF DEFINED(EXCLUDE-FillPricesBlanketOrCallSalesOrderForLLPrint) = 0 &THEN

&ANALYZE-SUSPEND _UIB-CODE-BLOCK _PROCEDURE FillPricesBlanketOrCallSalesOrderForLLPrint Method-Library 
procedure FillPricesBlanketOrCallSalesOrderForLLPrint :
/* Description ---------------------------------------------------------------*/
/*                                                                            */
/*  Create and fill Prices for Blanket or Call Sales Order                    */
/*                                                                            */
/* Notes ---------------------------------------------------------------------*/
/*                                                                            */
/* This procedure does only encapsulate code for better readability of        */
/* fillDataset procedure. It can only be used in the context of this DAO !    */
/* run super() must have been executed and a global ttV_BelegKopf-P  and      */
/* ttV_BelegPos-P must be available!                                          */
/*                                                                            */
/*----------------------------------------------------------------------------*/

define buffer bVU_RA_Preis         for VU_RA_Preis.
define buffer bttVU_RA_Preis-P1    for temp-table ttVU_RA_Preis-P1.

if can-do('VUR,VUA':U,ttV_BelegKopf-P.Belegart) then

  for each bVU_RA_Preis
    where bVU_RA_Preis.Firma       = ttV_BelegPos-P.Firma
      and bVU_RA_Preis.Belegart    = ttV_BelegPos-P.Belegart
      and bVU_RA_Preis.ReferenzNr  = ttV_BelegPos-P.ReferenzNr
      and bVU_RA_Preis.PositionsNr = ttV_BelegPos-P.PositionsNr
      and bVU_RA_Preis.Artikel     = ttV_BelegPos-P.Artikel
      and bVU_RA_Preis.ArtVar      = ttV_BelegPos-P.ArtVar
      and bVU_RA_Preis.gueltig_ab  > ttV_BelegPos-P.gueltig_ab
    no-lock:

    create  bttVU_RA_Preis-P1.

    {buffer-copy
       bVU_RA_Preis
       to bttVU_RA_Preis-P1
       assign
         "bttVU_RA_Preis-P1.Firma             = gcFirma
          bttVU_RA_Preis-P1.Eur_Einzelpreis   = bttVU_RA_Preis-P1.Einzelpreis / ttS_Waehrung-P1.Eurofaktor
          bttVU_RA_Preis-P1.Eur_Gesamtpreis   = (bttVU_RA_Preis-P1.Einzelpreis
                                                   * (1 + bttVU_RA_Preis-P1.proz_RZ_1 / 100)
                                                   * (1 + bttVU_RA_Preis-P1.proz_RZ_2 / 100)
                                                   * (1 + bttVU_RA_Preis-P1.proz_RZ_3 / 100)
                                                   + bttVU_RA_Preis-P1.Wert_RZ_1
                                                   + bttVU_RA_Preis-P1.Wert_RZ_2) / ttS_Waehrung-P1.Eurofaktor
          bttVU_RA_Preis-P1.Eur_Verkaufspreis = (bttVU_RA_Preis-P1.Einzelpreis
                                                   + bttVU_RA_Preis-P1.wert_RZ_1
                                                   + bttVU_RA_Preis-P1.wert_RZ_2) / ttS_Waehrung-P1.Eurofaktor
          bttVU_RA_Preis-P1.Gesamtpreis       = (bttVU_RA_Preis-P1.Einzelpreis
                                                   * (1 + bttVU_RA_Preis-P1.proz_RZ_1 / 100)
                                                   * (1 + bttVU_RA_Preis-P1.proz_RZ_2 / 100)
                                                   * (1 + bttVU_RA_Preis-P1.proz_RZ_3 / 100)
                                                   + bttVU_RA_Preis-P1.Wert_RZ_1
                                                   + bttVU_RA_Preis-P1.Wert_RZ_2)"}

    validate bttVU_RA_Preis-P1.

    vert.base.cls.VBCSalesDocSvc:prpoInstance:LLFillDiscountSurchargeDesc
       (gcContentLanguage,
        buffer bttVU_RA_Preis-P1:handle,
        buffer bttVU_RA_Preis-P1:handle).

  end.

end procedure. /* FillPricesBlanketOrCallSalesOrder */


/* _UIB-CODE-BLOCK-END */
&ANALYZE-RESUME

&ENDIF

&IF DEFINED(EXCLUDE-fillProviderVariablesForLLPrint) = 0 &THEN

&ANALYZE-SUSPEND _UIB-CODE-BLOCK _PROCEDURE fillProviderVariablesForLLPrint Method-Library 
procedure fillProviderVariablesForLLPrint :
/* Description ---------------------------------------------------------------*/
/*                                                                            */
/* Fill TT {&pa_DR_DataProviderVariablesTT} to provide global variables       */
/*                                                                            */
/*----------------------------------------------------------------------------*/

  /* fill the variable temp-table */
  
  find {&pa_DR_DataProviderVariablesTT}
    where {&pa_DR_DataProviderVariablesTT}.VariableName = 'EuroKurzBez':U
    no-error.
  
  if available {&pa_DR_DataProviderVariablesTT} then
  do:
  
    {&pa_DR_DataProviderVariablesTT}.CharacterValue = gcEuroKurzBez.
  
  
  end.
  
  find {&pa_DR_DataProviderVariablesTT}
    where {&pa_DR_DataProviderVariablesTT}.VariableName = 'Sammelrechnung':U
    no-error.
  
  if available {&pa_DR_DataProviderVariablesTT} then
  
    {&pa_DR_DataProviderVariablesTT}.LogicalValue =
      (   (    ttV_BelegKopf-P.Belegart        = 'R':U
           and ttV_BelegKopf-P.Schlussrechnung = no
           and vert.fakt.cls.VFCConsolidatedInvoiceSvc:prpoInstance:lIsConsolidatedInvoice(ttV_BelegKopf-P.V_BelegKopf_Obj))
       or (    ttV_BelegKopf-P.Belegart        = 'G':U
           and ttV_BelegKopf-P.Schlussrechnung = no
           and vert.base.cls.VBCSalesDocSvc:prpoInstance:lIsCollectiveCreditNote(ttV_BelegKopf-P.V_BelegKopf_Obj))).
  
  
  find {&pa_DR_DataProviderVariablesTT}
    where {&pa_DR_DataProviderVariablesTT}.VariableName = 'Schlussrechnung':U
    no-error.
  
  if available {&pa_DR_DataProviderVariablesTT} then
  
    {&pa_DR_DataProviderVariablesTT}.LogicalValue =
      (ttV_BelegKopf-P.Belegart             = 'R':U
        and ttV_BelegKopf-P.Schlussrechnung = yes
        and ttV_BelegKopf-P.Teilrechnung    = no).
  
  
  find {&pa_DR_DataProviderVariablesTT}
    where {&pa_DR_DataProviderVariablesTT}.VariableName = 'Teilrechnung':U
    no-error.
  
  if available {&pa_DR_DataProviderVariablesTT} then
  
    {&pa_DR_DataProviderVariablesTT}.LogicalValue =
      (ttV_BelegKopf-P.Belegart        = 'R':U
        and ttV_BelegKopf-P.Schlussrechnung = yes
        and ttV_BelegKopf-P.Teilrechnung    = yes).
  
  find {&pa_DR_DataProviderVariablesTT}
    where {&pa_DR_DataProviderVariablesTT}.VariableName = 'Anzahlung':U
    no-error.
  
  if available {&pa_DR_DataProviderVariablesTT} then
  
    {&pa_DR_DataProviderVariablesTT}.LogicalValue =
      (    ttV_BelegKopf-P.Belegart        = 'R':U
       and ttV_BelegKopf-P.Schlussrechnung = no
       and ttV_BelegKopf-P.Teilrechnung    = no
       and can-find(first V_BelegPos
                      where V_BelegPos.Firma      = {firma/vbelegko.fir ttV_BelegKopf-P.Firma}
                        and V_BelegPos.BelegArt   = ttV_BelegKopf-P.Belegart
                        and V_BelegPos.ReferenzNr = ttV_BelegKopf-P.ReferenzNr
                        and can-find(S_Artikel
                                       where S_Artikel.Firma      = {firma/sartikel.fir V_BelegPos.Firma}
                                         and S_Artikel.Artikel    = V_BelegPos.Artikel
                                         and S_Artikel.ArtikelArt = {&pa_S_PT_PartPayAndMarkdowns}))).
  
  find {&pa_DR_DataProviderVariablesTT}
    where {&pa_DR_DataProviderVariablesTT}.VariableName = 'Positionen':U
    no-error.
  
  if available {&pa_DR_DataProviderVariablesTT} then
    {&pa_DR_DataProviderVariablesTT}.LogicalValue = glPositions.
  
  
  find {&pa_DR_DataProviderVariablesTT}
    where {&pa_DR_DataProviderVariablesTT}.VariableName = 'Wert_RZ_1_Label':U
    no-error.
  
  if available {&pa_DR_DataProviderVariablesTT} then
  do:
  
    {&pa_DR_DataProviderVariablesTT}.CharacterValue = string(adm.config.cls.DCCAppConfigSvc:prpoInstance:cParameterValueLng
                                                             ('VB_DiscountSurchargeValueColumnLabel1':U,
                                                              gcContentLanguage)).
  
  end.
  
  find {&pa_DR_DataProviderVariablesTT}
    where {&pa_DR_DataProviderVariablesTT}.VariableName = 'Wert_RZ_2_Label':U
    no-error.
  
  if available {&pa_DR_DataProviderVariablesTT} then
  do:
  
    {&pa_DR_DataProviderVariablesTT}.CharacterValue = string(adm.config.cls.DCCAppConfigSvc:prpoInstance:cParameterValueLng
                                                             ('VB_DiscountSurchargeValueColumnLabel2':U,
                                                              gcContentLanguage)).
  
  end.
  
  find {&pa_DR_DataProviderVariablesTT}
    where {&pa_DR_DataProviderVariablesTT}.VariableName = 'Proz_RZ_1_Label':U
    no-error.
  
  if available {&pa_DR_DataProviderVariablesTT} then
  do:
  
    {&pa_DR_DataProviderVariablesTT}.CharacterValue = string(adm.config.cls.DCCAppConfigSvc:prpoInstance:cParameterValueLng
                                                             ('VB_DiscountSurchargePercColumnLabel1':U,
                                                              gcContentLanguage)).
  
  end.
  
  find {&pa_DR_DataProviderVariablesTT}
    where {&pa_DR_DataProviderVariablesTT}.VariableName = 'Proz_RZ_2_Label':U
    no-error.
  
  if available {&pa_DR_DataProviderVariablesTT} then
  do:
  
    {&pa_DR_DataProviderVariablesTT}.CharacterValue = string(adm.config.cls.DCCAppConfigSvc:prpoInstance:cParameterValueLng
                                                             ('VB_DiscountSurchargePercColumnLabel2':U,
                                                              gcContentLanguage)).
  
  end.
  
  find {&pa_DR_DataProviderVariablesTT}
    where {&pa_DR_DataProviderVariablesTT}.VariableName = 'Proz_RZ_3_Label':U
    no-error.
  
  if available {&pa_DR_DataProviderVariablesTT} then
  do:
  
    {&pa_DR_DataProviderVariablesTT}.CharacterValue = string(adm.config.cls.DCCAppConfigSvc:prpoInstance:cParameterValueLng
                                                             ('VB_DiscountSurchargePercColumnLabel3':U,
                                                              gcContentLanguage)).
  
  end.
  
  find {&pa_DR_DataProviderVariablesTT}
    where {&pa_DR_DataProviderVariablesTT}.VariableName = 'Factoring':U
    no-error.
  
  if available {&pa_DR_DataProviderVariablesTT} then
  
    {&pa_DR_DataProviderVariablesTT}.LogicalValue = glFactoring.
  
  
  &IF LOOKUP("U_CA":U,"{&PA-OPTIONEN}":U) > 0 &THEN 
  
    find {&pa_DR_DataProviderVariablesTT}
      where {&pa_DR_DataProviderVariablesTT}.VariableName = 'uGSAStatus':U
      no-error.
  
    if available {&pa_DR_DataProviderVariablesTT} then
    do:
  
      {&pa_DR_DataProviderVariablesTT}.CharacterValue = gcuGSAStatus.
  
    end. 
  
  &ENDIF

end procedure. /* fillProviderVariablesForLLPrint */


/* _UIB-CODE-BLOCK-END */
&ANALYZE-RESUME

&ENDIF


&IF DEFINED(EXCLUDE-fillQuotationCostingForLLPrint) = 0 &THEN

&IF LOOKUP("VN_KALK":U,"{&PA-OPTIONEN}":U) > 0 &THEN

&ANALYZE-SUSPEND _UIB-CODE-BLOCK _PROCEDURE fillQuotationCostingForLLPrint Method-Library 
procedure fillQuotationCostingForLLPrint :
/* Description ---------------------------------------------------------------*/
/*                                                                            */
/*  Create and fill Quotation Costing for Lines                               */
/*                                                                            */
/* Notes ---------------------------------------------------------------------*/
/*                                                                            */
/* This procedure does only encapsulate code for better readability of        */
/* fillDataset procedure. It can only be used in the context of this DAO !    */
/* run super() must have been executed and a global ttV_BelegKopf-P  and      */
/* ttV_BelegPos-P must be available!                                          */
/*                                                                            */
/*----------------------------------------------------------------------------*/

define buffer bV_BelegKalk     for V_BelegKalk.
define buffer bttV_BelegKalk-P for temp-table ttV_BelegKalk-P.

  for each bV_BelegKalk
    where bV_BelegKalk.Firma       = ttV_BelegPos-P.Firma
      and bV_BelegKalk.Belegart    = ttV_BelegPos-P.Belegart
      and bV_BelegKalk.ReferenzNr  = ttV_BelegPos-P.ReferenzNr
      and bV_BelegKalk.LfdNr_SR    = ttV_BelegPos-P.lfdNr_SR
      and bV_BelegKalk.PositionsNr = ttV_BelegPos-P.PositionsNr
      and bV_BelegKalk.druckbar    = yes
      no-lock
    on error undo, throw:
  
  
    create bttV_BelegKalk-P.
  
    {buffer-copy
       bV_BelegKalk
       to bttV_BelegKalk-P
       assign
         "bttV_BelegKalk-P.Firma         = gcFirma"}
  
  end. /* for each bV_BelegKalk */

end procedure. /* fillQuotationCostingForLLPrint */


/* _UIB-CODE-BLOCK-END */
&ANALYZE-RESUME

&ENDIF

&ENDIF


&IF DEFINED(EXCLUDE-fillServiceOrderInfoForLLPrint) = 0 &THEN

&ANALYZE-SUSPEND _UIB-CODE-BLOCK _PROCEDURE fillServiceOrderInfoForLLPrint Method-Library 
procedure fillServiceOrderInfoForLLPrint :
/* Description ---------------------------------------------------------------*/
/*                                                                            */
/* Create and fill Service Order information if predecessors  of              */
/* ttV_BelegPos-P exist.                                                      */
/*                                                                            */
/* Notes ---------------------------------------------------------------------*/
/*                                                                            */
/* This procedure does only encapsulate code for better readability of        */
/* fillDataset procedure. It can only be used in the context of this DAO !    */
/* run super() must have been executed and a global ttV_BelegKopf-P  and      */
/* ttV_BelegPos-P must be available!                                          */
/*                                                                            */
/*----------------------------------------------------------------------------*/

define variable cSourceDocLineObj as character no-undo.

&IF lookup("VS_SAUF","{&PA-OPTIONEN}") > 0 &THEN
  define buffer bVS_AuftragPos        for VS_AuftragPos.
  define buffer bVS_Auftrag           for VS_Auftrag.
  define buffer bVS_Auftrag_RepQuote  for VS_Auftrag.
  define buffer bS_Artikel            for S_Artikel.
  define buffer bS_AuftragsArt        for S_AuftragsArt.
  define buffer bMMT_StockReceipt     for MMT_StockReceipt.
  define buffer bVST_Call             for VST_Call.
  define buffer bV_BelegPos           for V_BelegPos.
  define buffer bV_BelegKopf          for V_BelegKopf.

  define buffer bttVS_AuftragPos-P    for temp-table ttVS_AuftragPos-P.
  define buffer bttVS_Auftrag-P       for temp-table ttVS_Auftrag-P.
  define buffer bttS_Artikel-P1       for temp-table ttS_Artikel-P1.  
  define buffer bttS_AuftragsArt-P2   for temp-table ttS_AuftragsArt-P2.
  define buffer bttMMT_StockReceipt-P for temp-table ttMMT_StockReceipt-P.
  define buffer bttV_BelegPos-P1      for temp-table ttV_BelegPos-P1.
  define buffer bttV_BelegKopf-P1     for temp-table ttV_BelegKopf-P1.

  &IF "{&pa_S_Varianten}" = "1" &THEN
    define buffer bS_ArtVar      for S_ArtVar.
    define buffer bttS_ArtVar-P1 for temp-table ttS_ArtVar-P1.
  &ENDIF

  &IF (lookup("MS","{&PA-MODULE}") > 0) &THEN
    define buffer bMS_SNR       for MS_SNR.
    define buffer bttMS_SNR-PSO for temp-table ttMS_SNR-PSO.
  &ENDIF

&ENDIF

/*----------------------------------------------------------------------------*/
/* Processing                                                                 */
/*----------------------------------------------------------------------------*/

&IF lookup("VS_SAUF","{&PA-OPTIONEN}") > 0 &THEN

  /* look for a service order as preceding document                 */
  /* if we have created the documents in the order VSA-R-G-R then   */
  /* the source doc. type of the last invoice and credit note is    */
  /* not VSA                                                        */

  if    can-do('R,G,L':U,ttV_BelegKopf-P.Belegart)
    and ttV_BelegKopf-P.Herk_Belegart <> ? then
  do:

    /* For current V_BelegPos: look for a source doc of type service order.   */
    /* This code does not consider doc lines that have been manually added    */
    /* to the invoice after adoption of the service order, but if any invoice */
    /* line is still linked to the service order, all information of the      */
    /* service order head will be available for printing...                   */

    cSourceDocLineObj = vert.base.cls.VBCSalesDocSvc:prpoInstance:cGetSourceDocLineObj
                         ('VSA':U,
                          ttV_BelegPos-P.V_BelegPos_Obj).

    if    cSourceDocLineObj <> ? then

      find bVS_AuftragPos
        where bVS_AuftragPos.VS_AuftragPos_Obj = cSourceDocLineObj
        no-lock no-error.

    if available bVS_AuftragPos then
      ttV_BelegPos-P.VS_AuftragPos_Obj = bVS_AuftragPos.VS_AuftragPos_Obj.

    if    available bVS_AuftragPos
      and not can-find (bttVS_AuftragPos-P
                     where bttVS_AuftragPos-P.VS_AuftragPos_Obj = cSourceDocLineObj) then
    do:

      create bttVS_AuftragPos-P.
      {buffer-copy
         bVS_AuftragPos
         to bttVS_AuftragPos-P}

      find bVS_Auftrag
        where bVS_Auftrag.Firma      = bVS_AuftragPos.Firma
          and bVS_Auftrag.Belegart   = bVS_AuftragPos.BelegArt
          and bVS_Auftrag.ReferenzNr = bVS_AuftragPos.ReferenzNr
        no-lock.

      /* multiple positions might refer to the same head - prevent doubles! */

      find bttVS_Auftrag-P
        where bttVS_Auftrag-P.Firma      = gcFirma
          and bttVS_Auftrag-P.Belegart   = bVS_AuftragPos.BelegArt
          and bttVS_Auftrag-P.ReferenzNr = bVS_AuftragPos.ReferenzNr
        no-lock no-error.

      if not available bttVS_Auftrag-P then
      do:

        create bttVS_Auftrag-P.

        {buffer-copy
           bVS_Auftrag
           to bttVS_Auftrag-P
           assign
             "bttVS_Auftrag-P.Firma = gcFirma"}

      end. /* if not available bttVS_Auftrag-P */

      /* source document is a quote order */

      if bttVS_Auftrag-P.Herk_BelegArt = 'VSA':U then
      do:

        find bVS_Auftrag_RepQuote
          where bVS_Auftrag_RepQuote.VS_Auftrag_Obj = bttVS_Auftrag-P.Origin_Obj
          no-lock no-error.

        if available bVS_Auftrag_RepQuote then

          find bVST_Call
            where bVST_Call.VST_Call_Obj = bVS_Auftrag_RepQuote.Origin_Obj
            no-lock no-error.

      end.
      else 
      do:

        /* else source document is the call */ 

        find bVST_Call
          where bVST_Call.VST_Call_Obj = bttVS_Auftrag-P.Origin_Obj
          no-lock no-error.

      end.  

      if available bVST_Call then
      do:

        find first bMMT_StockReceipt
          where bMMT_StockReceipt.OriginDocType = bVST_Call.Belegart
            and bMMT_StockReceipt.Origin_obj    = bVST_Call.VST_Call_Obj
          no-lock no-error.

        if available bMMT_StockReceipt
          and not can-find (bttMMT_StockReceipt-P
                             where bttMMT_StockReceipt-P.MMT_StockReceipt_Obj = bMMT_StockReceipt.MMT_StockReceipt_Obj) then
          do:

            create bttMMT_StockReceipt-P.

            {buffer-copy
               bMMT_StockReceipt
               to bttMMT_StockReceipt-P
               assign
                 "bttMMT_StockReceipt-P.Company   = gcFirma
                  bttMMT_StockReceipt-P.VS_Auftrag_Obj = bVS_Auftrag.VS_Auftrag_Obj"}

            validate bttMMT_StockReceipt-P.

          end.

      end.  /* if available bVST_Call */

      /* the same bttS_Artikel-P1 must only be create once... */

      find bttS_Artikel-P1
        where bttS_Artikel-P1.Firma   = gcFirma
          and bttS_Artikel-P1.Artikel = bVS_AuftragPos.ArtikelWartung
        no-error.

      if not available bttS_Artikel-P1 then
      do:

        find bS_Artikel
          where bS_Artikel.Firma   = {firma/sartikel.fir bVS_AuftragPos.Firma}
            and bS_Artikel.Artikel = bVS_AuftragPos.ArtikelWartung
          no-lock no-error.

        /* VS_AuftragPos.ArtikelWartung can be empty ! */

          if available bS_Artikel then
          do:

            create bttS_Artikel-P1.

            {buffer-copy
               bS_Artikel
               to bttS_Artikel-P1
               assign
                 "bttS_Artikel-P1.Firma = gcFirma"}
          end.

      end. /*  available bttS_Artikel-P1 */

      /* ... but the same bttS_Artikel-P1 might have differnt variants!       */

      &IF "{&pa_S_Varianten}" = "1" &THEN

      if available bttS_Artikel-P1 then
      do:
        if    bttS_Artikel-P1.ArtVarTyp > 0
          and bVS_AuftragPos.ArtVarWartung > '':U
          and not can-find(bttS_ArtVar-P1
                             where bttS_ArtVar-P1.ArtVarTyp = bttS_Artikel-P1.ArtVarTyp
                               and bttS_ArtVar-P1.ArtVar    = bVS_AuftragPos.ArtVarWartung) then
        do:

          bttVS_AuftragPos-P.ArtVarTyp = bttS_Artikel-P1.ArtVarTyp.

          find bS_ArtVar
            where bS_ArtVar.ArtVarTyp = bttS_Artikel-P1.ArtVarTyp
              and bS_ArtVar.ArtVar    = bVS_AuftragPos.ArtVarWartung
            no-lock no-error.

          if available bS_ArtVar then
          do:

            create bttS_ArtVar-P1.

            {buffer-copy
               bS_ArtVar
               to bttS_ArtVar-P1}

          end. /* if available bS_ArtVar */

        end. /* if bS_Artikel.ArtVarTyp > 0 */
      end. /* available bttS_Artikel-P1 */

      &ENDIF /* &IF "{&pa_S_Varianten}":U = "1":U */


      if not can-find(bttS_AuftragsArt-P2
                where bttS_AuftragsArt-P2.Firma       = gcFirma
                  and bttS_AuftragsArt-P2.Auftragsart = bVS_Auftrag.Auftragsart) then
      do:

       find bS_AuftragsArt
         where bS_AuftragsArt.Firma       = {firma/saufart.fir gcFirma}
           and bS_AuftragsArt.Auftragsart = bVS_Auftrag.Auftragsart
         no-lock no-error.

        if available bS_AuftragsArt then
        do:

          create bttS_AuftragsArt-P2.

          {buffer-copy
             bS_AuftragsArt
             to bttS_AuftragsArt-P2
             assign
               "bttS_AuftragsArt-P2.Firma = gcFirma"}

        end. /* if available bS_AuftragsArt */

      end. /* if not can-find(bttS_AuftragsArt-P2 */

    end. /* if not can-find ( if cSourceDocLineObj <> ? */

    &IF LOOKUP("MS","{&PA-MODULE}") > 0 &THEN

      if not can-find(bttMS_SNR-PSO
                where bttMS_SNR-PSO.MS_SNR_Obj = bVS_AuftragPos.MS_SNR_Obj) then
      do:

        find bMS_SNR
          where bMS_SNR.MS_SNR_Obj = bVS_AuftragPos.MS_SNR_Obj
          no-lock no-error.

        if available bMS_SNR then
        do:

          create bttMS_SNR-PSO.

          {buffer-copy
             bMS_SNR
             to bttMS_SNR-PSO
             assign
               "bttMS_SNR-PSO.Firma = gcFirma"}

        end. /* if available bMS_SNR */

      end. /* if not can-find(bttMS_SNR-PSO */

    &ENDIF

    if    available bttVS_AuftragPos-P
      and bttVS_AuftragPos-P.VS_AuftragPos_Obj > '':U
      and not can-find(first bttV_BelegPos-P1
                         where bttV_BelegPos-P1.Firma         = bttVS_AuftragPos-P.Firma
                           and bttV_BelegPos-P1.Belegart      = 'L':U
                           and bttV_BelegPos-P1.Herk_BelegArt = 'VSA':U
                           and bttV_BelegPos-P1.Origin_Obj    = bttVS_AuftragPos-P.VS_AuftragPos_Obj) then
    do:

      find first bV_BelegPos
        where bV_BelegPos.Firma          = bVS_AuftragPos.Firma
          and bV_BelegPos.Belegart       = 'L':U
          and bV_BelegPos.Herk_BelegArt  = 'VSA':U
          and bV_BelegPos.Origin_Obj     = bVS_AuftragPos.VS_AuftragPos_Obj
        no-lock no-error.

      if available bV_BelegPos then
      do:

        create bttV_BelegPos-P1.

        {buffer-copy
           bV_BelegPos
           to bttV_BelegPos-P1
           assign
             "bttV_BelegPos-P1.Firma = gcFirma"}

        if not can-find(bttV_BelegKopf-P1
                          where bttV_BelegKopf-P1.Firma      = bV_BelegPos.Firma
                            and bttV_BelegKopf-P1.Belegart   = bV_BelegPos.Belegart
                            and bttV_BelegKopf-P1.ReferenzNr = bV_BelegPos.ReferenzNr) then
        do:

          find bV_BelegKopf
            where bV_BelegKopf.Firma      = bV_BelegPos.Firma
              and bV_BelegKopf.Belegart   = bV_BelegPos.Belegart
              and bV_BelegKopf.ReferenzNr = bV_BelegPos.ReferenzNr
            no-lock no-error.

          if available bV_BelegKopf then
          do:

            create bttV_BelegKopf-P1.

            {buffer-copy
               bV_BelegKopf
               to bttV_BelegKopf-P1
               assign
                 "bttV_BelegKopf-P1.Firma      = gcFirma
                  bttV_BelegKopf-P1.Empfaenger = VBCContactPersonSvc:prpoInstance:cGetContactPersonName
                                                   (bV_BelegKopf.V_BelegKopf_Obj,
                                                    integer(SBCContactTypeEnu:Customer))"}

          end. /* if available bV_BelegKopf */

        end. /* if not can-find(bttV_BelegKopf-P1 */        

      end. /* if available bV_BelegPos */

    end. /* if available bttVS_AuftragPos-P */

  end. /* if  ttV_BelegKopf-P.Belegart = 'R':U */

&ENDIF /* &IF lookup("VS_SAUF":U,"{&PA-OPTIONEN}":U) */

end procedure. /* fillServiceOrderInfoForLLPrint */

/* _UIB-CODE-BLOCK-END */
&ANALYZE-RESUME

&ENDIF


&IF DEFINED(EXCLUDE-fillShippingDocumentsForLLPrint) = 0 &THEN

&ANALYZE-SUSPEND _UIB-CODE-BLOCK _PROCEDURE fillShippingDocumentsForLLPrint Method-Library 
procedure fillShippingDocumentsForLLPrint :
/* Description ---------------------------------------------------------------*/
/*                                                                            */
/* Create and fill Shipping Documents that are predecessors of ttV_BelegPos-P */
/* records.                                                                   */
/*                                                                            */
/* Notes ---------------------------------------------------------------------*/
/*                                                                            */
/* This procedure does only encapsulate code for better readability of        */
/* fillDataset procedure. It can only be used in the context of this DAO !    */
/* run super() must have been executed and a global ttV_BelegKopf-P  and      */
/* ttV_BelegPos-P must be available!                                          */
/*                                                                            */
/*----------------------------------------------------------------------------*/
define variable gcSourceDocLineObj      as character                    no-undo.

define buffer bV_BelegPos-L      for V_BelegPos.
define buffer bV_BelegKopf-L     for V_BelegKopf.
define buffer bS_MengenEinheit-L for S_MengenEinheit.


  gcSourceDocLineObj = vert.base.cls.VBCSalesDocSvc:prpoInstance:cGetSourceDocLineObj
                         ('L':U,
                          ttV_BelegPos-P.V_BelegPos_Obj).
  
  if    ttV_BelegKopf-P.P_RechnungsTyp > 0
    and can-find(ttV_BelegPos-PShpDoc
                 where ttV_BelegPos-PShpDoc.V_BelegPos_Obj = gcSourceDocLineObj) then
    gcSourceDocLineObj = '':U.
  
  if gcSourceDocLineObj > '':U
    and not can-find (ttV_BelegPos-PShpDoc
                        where ttV_BelegPos-PShpDoc.V_BelegPos_Obj = gcSourceDocLineObj) then
    find bV_BelegPos-L
      where bV_BelegPos-L.V_BelegPos_Obj = gcSourceDocLineObj
      no-lock no-error.
  
  if not available bV_BelegPos-L then
    return.
  
    find bV_BelegKopf-L
      where bV_BelegKopf-L.Firma      = bV_BelegPos-L.Firma
        and bV_BelegKopf-L.Belegart   = bV_BelegPos-L.Belegart
        and bV_BelegKopf-L.ReferenzNr = bV_BelegPos-L.ReferenzNr
      no-lock.                                                                                                         

    find bS_MengenEinheit-L                                                                                            
      where bS_MengenEinheit-L.Firma         = {firma/smngeinh.fir bV_BelegPos-L.Firma}                                
        and bS_MengenEinheit-L.Mengeneinheit =  bV_BelegPos-L.Mengeneinheit                                            
      no-lock.                                                                                                         

    create ttV_BelegPos-PShpDoc.                                                                                       

    {buffer-copy
       bV_BelegPos-L
       to ttV_BelegPos-PShpDoc
       assign
         "ttV_BelegPos-PShpDoc.Owning_Obj = ttV_BelegPos-P.V_BelegPos_Obj
                       ttV_BelegPos-PShpDoc.Firma      = gcFirma"}                                                                 

    if not can-find(ttV_BelegKopf-PShpDoc                                                                              
                      where ttV_BelegKopf-PShpDoc.Firma      = ttV_BelegPos-PShpDoc.Firma                              
                        and ttV_BelegKopf-PShpDoc.Belegart   = ttV_BelegPos-PShpDoc.Belegart                           
                        and ttV_BelegKopf-PShpDoc.ReferenzNr = ttV_BelegPos-PShpDoc.ReferenzNr ) then                  
    do:
      create ttV_BelegKopf-PShpDoc.

      {buffer-copy
         bV_BelegKopf-L
         to ttV_BelegKopf-PShpDoc
         assign
           "ttV_BelegKopf-PShpDoc.Firma = gcFirma"}

      /* use dummy tt for appserver call and copy results because of changes from PA-36404 */

      {adm/incl/d__run03.if
        &Procedure   = "vert/base/proc/vbndoc06.p"
        &Arguments   = "bV_BelegKopf-L.V_BelegKopf_Obj,
                        output table Kund_Adresse_Dummy,
                        output table Lief_Adresse_Dummy,
                        output table Rech_Adresse_Dummy"
      }

    // in consolidated invoices each position may have a customer/shipping/invoice address
    // do not delete the entries of former positions 
    find Kund_Adresse_Dummy no-error.
    if available Kund_Adresse_Dummy then     
      Kund_Adresse_Dummy.Firma = ttV_BelegKopf-PShpDoc.Firma.

    find Lief_Adresse_Dummy no-error.
    if available Lief_Adresse_Dummy then     
      Lief_Adresse_Dummy.Firma = ttV_BelegKopf-PShpDoc.Firma.

    find Rech_Adresse_Dummy no-error.
    if available Rech_Adresse_Dummy then     
      Rech_Adresse_Dummy.Firma = ttV_BelegKopf-PShpDoc.Firma.
  
      temp-table ttS_Adresse-PCustShpDoc:copy-temp-table(temp-table Kund_Adresse_Dummy:handle, no, yes, yes).
      temp-table ttS_Adresse-PDelShpDoc:copy-temp-table( temp-table Lief_Adresse_Dummy:handle, no, yes, yes).
      temp-table ttS_Adresse-PInvShpDoc:copy-temp-table( temp-table Rech_Adresse_Dummy:handle, no, yes, yes).

    // there is one entry in each tt, that is manually linked to ttV_BelegKopf-PShpDoc
    find ttS_Adresse-PCustShpDoc 
      where ttS_Adresse-PCustShpDoc.Firma    = Kund_Adresse_Dummy.Firma
        and ttS_Adresse-PCustShpDoc.AdressNr = Kund_Adresse_Dummy.AdressNr 
        no-error.

      if available ttS_Adresse-PCustShpDoc then
      do:

      // An AdressNr number is needed for linking of TT's ... use the artificial
      // number (negative!!!) from giDiversAddressCounter and decrease counter
      // for the next usage

        if ttS_Adresse-PCustShpDoc.AdressNr = ?
          or ttS_Adresse-PCustShpDoc.AdressNr = 0 then
          assign
            ttS_Adresse-PCustShpDoc.AdressNr = giDiversAddressCounter
            giDiversAddressCounter           = giDiversAddressCounter - 1
            .

        assign
          ttV_BelegKopf-PShpDoc.AdressNrCust = ttS_Adresse-PCustShpDoc.AdressNr
          ttS_Adresse-PCustShpDoc.Firma      = ttV_BelegKopf-PShpDoc.Firma
          .
      end. /* ttS_Adresse-PCustShpDoc */

    find ttS_Adresse-PDelShpDoc
      where ttS_Adresse-PDelShpDoc.Firma    = Lief_Adresse_Dummy.Firma
        and ttS_Adresse-PDelShpDoc.AdressNr = Lief_Adresse_Dummy.AdressNr 
        no-error.

      if available ttS_Adresse-PDelShpDoc then
      do:

      // An AdressNr number is needed for linking of TT's ... use the artificial
      // number (negative!!!) from giDiversAddressCounter and decrease counter
      // for the next usage

        if ttS_Adresse-PDelShpDoc.AdressNr = ?
          or ttS_Adresse-PDelShpDoc.AdressNr = 0 then
          assign
            ttS_Adresse-PDelShpDoc.AdressNr = giDiversAddressCounter
            giDiversAddressCounter          = giDiversAddressCounter - 1
            .

        assign
          ttV_BelegKopf-PShpDoc.AdressNrDel = ttS_Adresse-PDelShpDoc.AdressNr
          ttS_Adresse-PDelShpDoc.Firma      = ttV_BelegKopf-PShpDoc.Firma
          .

      end. /* ttS_Adresse-PDelShpDoc */

    find ttS_Adresse-PInvShpDoc 
      where ttS_Adresse-PInvShpDoc.Firma    = Rech_Adresse_Dummy.Firma
        and ttS_Adresse-PInvShpDoc.AdressNr = Rech_Adresse_Dummy.AdressNr 
        no-error.

      if available ttS_Adresse-PInvShpDoc then
      do:

      // An AdressNr number is needed for linking of TT's ... use the artificial
      // number (negative!!!) from giDiversAddressCounter and decrease counter
      // for the next usage

        if ttS_Adresse-PInvShpDoc.AdressNr = ?
          or ttS_Adresse-PInvShpDoc.AdressNr = 0 then
          assign
            ttS_Adresse-PInvShpDoc.AdressNr = giDiversAddressCounter
            giDiversAddressCounter          = giDiversAddressCounter - 1
            .

        assign
          ttV_BelegKopf-PShpDoc.AdressNrInv = ttS_Adresse-PInvShpDoc.AdressNr
          ttS_Adresse-PInvShpDoc.Firma      = ttV_BelegKopf-PShpDoc.Firma
          .

      end. /* available ttS_Adresse-PInvShpDoc*/

    end.

    if not can-find(ttS_Mengeneinheit-P2
                      where ttS_Mengeneinheit-P2.Firma         = gcFirma
                        and ttS_Mengeneinheit-P2.Mengeneinheit = bV_BelegPos-L.Mengeneinheit) then
    do:

      create ttS_Mengeneinheit-P2.

      {buffer-copy
         bS_MengenEinheit-L
         to ttS_Mengeneinheit-P2
         assign
           "ttS_Mengeneinheit-P2.Firma = gcFirma"}

    end.

end procedure. /* fillShippingDocumentsForLLPrint */

/* _UIB-CODE-BLOCK-END */
&ANALYZE-RESUME

&ENDIF

&IF DEFINED(EXCLUDE-FillStorageLocationForLLPrint) = 0 &THEN

&IF lookup("MP", "{&PA-MODULE}") > 0 &THEN

&ANALYZE-SUSPEND _UIB-CODE-BLOCK _PROCEDURE FillStorageLocationForLLPrint Method-Library 
procedure FillStorageLocationForLLPrint :
/* Description ---------------------------------------------------------------*/
/*                                                                            */
/* Create and fill Storage Location Infos                                     */
/*                                                                            */
/* Notes ---------------------------------------------------------------------*/
/*                                                                            */
/* This procedure does only encapsulate code for better readability of        */
/* fillDataset procedure. It can only be used in the context of this DAO !    */
/* run super() must have been executed and a global ttV_BelegKopf-P  and      */
/* ttV_BelegPos-P must be available!                                          */
/*                                                                            */
/*----------------------------------------------------------------------------*/

define variable iReservationNumber as integer       no-undo.

define buffer bttMP_ArtPlatz-P3    for temp-table ttMP_ArtPlatz-P3.


  /* Storage Location Informations */
  
  if ttV_BelegKopf-P.Belegart = 'U':U then
  do:
  
    iReservationNumber    = mawi.base.cls.MMCReservationSvc:prpoInstance:iReviewReservationNr
                             (ttV_BelegPos-P.V_BelegPos_Obj).
  
    mawi.platz.cls.MPCRanWareHouseSvc:prpoInstance:GetStorageLocationsAsTT
            (             ttV_BelegPos-P.V_BelegPos_Obj,
                          '':U,
                          iReservationNumber,
                          gcFirma,
             input-output table bttMP_ArtPlatz-P3).
  end.

end procedure. /* FillStorageLocationForLLPrint */


/* _UIB-CODE-BLOCK-END */
&ANALYZE-RESUME

&ENDIF
&ENDIF


&IF DEFINED(EXCLUDE-H_fillCorrectionInvoiceDiffForLLPrint) = 0 &THEN

&ANALYZE-SUSPEND _UIB-CODE-BLOCK _PROCEDURE H_fillCorrectionInvoiceDiffForLLPrint Method-Library 
procedure H_fillCorrectionInvoiceDiffForLLPrint :
/* Description ---------------------------------------------------------------*/
/*                                                                            */
/* Fill correction invoice diffenrences in ttV_H_CorrectionInvoice-P that     */
/* cannot be filled by the dataset framework.                                 */
/*                                                                            */
/* Notes ---------------------------------------------------------------------*/
/*                                                                            */
/* This method does only encapsulate code for better readability of           */
/* fillDataset procedure. It can only be used in the context of this DAO!     */
/* run super() must have been executed and a global ttV_BelegKopf-P and       */
/* and ttS_Kunde-P1 must be available!                                        */
/*                                                                            */
/*----------------------------------------------------------------------------*/

define buffer bttV_BelegPos-P for temp-table ttV_BelegPos-P.

  find first bttV_BelegPos-P
    where bttV_BelegPos-P.Firma            = ttV_BelegPos-P.Firma
      and bttV_BelegPos-P.Belegart         = ttV_BelegPos-P.BelegArt
      and bttV_BelegPos-P.ReferenzNr       = ttV_BelegPos-P.ReferenzNr
      and bttV_BelegPos-P.LfdNr_SR         = ttV_BelegPos-P.LfdNr_SR
      and bttV_BelegPos-P.H_CancelledLine  = ttV_BelegPos-P.H_CorrectedLine
      and bttV_BelegPos-P.H_CancelledLine <> 0
    no-lock no-error.
  
  if not available bttV_BelegPos-P then
    return.

  create ttV_H_CorrectionInvoice-P.

  assign
    ttV_H_CorrectionInvoice-P.Owning_Obj    = ttV_BelegPos-P.V_BelegPos_Obj
    ttV_H_CorrectionInvoice-P.Diff_Quantity = bttV_BelegPos-P.Menge       + ttV_BelegPos-P.Menge
    ttV_H_CorrectionInvoice-P.Diff_Amount   = bttV_BelegPos-P.GesamtPreis + ttV_BelegPos-P.GesamtPreis
    .

  validate ttV_H_CorrectionInvoice-P.

end procedure. /* H_fillCorrectionInvoiceDiffForLLPrint */


/* _UIB-CODE-BLOCK-END */
&ANALYZE-RESUME

&ENDIF


&IF DEFINED(EXCLUDE-H_fillDocumentOriginInfoForLLPrint) = 0 &THEN

&ANALYZE-SUSPEND _UIB-CODE-BLOCK _PROCEDURE H_fillDocumentOriginInfoForLLPrint Method-Library 
procedure H_fillDocumentOriginInfoForLLPrint :
/* Description ---------------------------------------------------------------*/
/*                                                                            */
/* Fill document origin fields in ttV_BelegKopf-P that cannot be filled by    */
/* the dataset framework.                                                     */
/*                                                                            */
/* Notes ---------------------------------------------------------------------*/
/*                                                                            */
/* This method does only encapsulate code for better readability of           */
/* fillDataset procedure. It can only be used in the context of this DAO!     */
/* run super() must have been executed and a global ttV_BelegKopf-P and       */
/* and ttS_Kunde-P1 must be available!                                        */
/*                                                                            */
/*----------------------------------------------------------------------------*/

define variable cOriginInvoice       as character                       no-undo.
define buffer bV_BelegKopf for V_BelegKopf.

assign
  // Hungary does not have any chain field, so the Polish field is used until a refactoring is done 
  ttV_BelegKopf-P.H_OrigDocNo    = integer(SBCLocalizationHUSvc:prpoInstance:cHPrevInvoiceNumbers(cOriginInvoice, ttV_BelegKopf-P.V_BelegKopf_Obj, no, yes))
  ttV_BelegKopf-P.P_InvoiceChain = SBCLocalizationHUSvc:prpoInstance:cHPrevInvoiceNumbers(ttV_BelegKopf-P.P_InvoiceChain, ttV_BelegKopf-P.V_BelegKopf_Obj, yes, yes)
  .

find last bV_BelegKopf
  where bV_BelegKopf.Firma      = ttV_BelegKopf-P.Firma
    and bV_BelegKopf.BelegArt    = 'R':U // must be an invoice
    and bV_BelegKopf.offen       = no
    and bV_BelegKopf.BelegNummer = ttV_BelegKopf-P.H_OrigDocNo
  no-lock no-error.

if available bV_BelegKopf then

  assign
    ttV_BelegKopf-P.H_OrigDocDate = bV_BelegKopf.Belegdatum
    ttV_BelegKopf-P.H_OrigTaxDate = bV_BelegKopf.H_TaxDate
    .

end procedure. /* H_fillDocumentOriginInfoForLLPrint */


/* _UIB-CODE-BLOCK-END */
&ANALYZE-RESUME

&ENDIF


&IF DEFINED(EXCLUDE-H_fillDocumentTaxrateSumsForLLPrint) = 0 &THEN

&ANALYZE-SUSPEND _UIB-CODE-BLOCK _PROCEDURE H_fillDocumentTaxrateSumsForLLPrint Method-Library 
procedure H_fillDocumentTaxrateSumsForLLPrint :
/* Description ---------------------------------------------------------------*/
/*                                                                            */
/* Calculates the taxrate dependant document sums of Hungarian fields         */
/* TT ttV_BelegTaxrateSums-P must be filled before calling this method!       */
/*                                                                            */
/* Notes ---------------------------------------------------------------------*/
/*                                                                            */
/* This method does only encapsulate code for better readability of           */
/* fillDataset procedure. It can only be used in the context of this DAO      */
/* run super() has been execute an a global ttV_BelegKopf-P Buffer is         */
/* available... so passing of paramters was forgone deliberatly.              */
/*                                                                            */
/*----------------------------------------------------------------------------*/

/* This second for each over ttV_BelegPos-P is necessary since                */
/* ttV_BelegTaxrateSums-P has not been created in the first for each. It was  */
/* created after the for each in procedure fillDocumentTaxrateSumsForLLPrint. */

  for each ttV_BelegPos-P:
  
    find ttV_BelegTaxrateSums-P
      where ttV_BelegTaxrateSums-P.Owning_Obj = ttV_BelegKopf-P.V_BelegKopf_Obj
        and ttV_BelegTaxrateSums-P.Steuersatz = ttV_BelegPos-P.SteuerSatz
        and ttV_BelegTaxrateSums-P.P_TaxKey   = (if pACConnectionSvc:prpcLocalization = 'P':U then
                                                   ttV_BelegPos-P.S_Steuer_Obj
                                                 else
                                                   '':U)
        and ttV_BelegTaxrateSums-P.TaxArrayID     = 0    
      exclusive-lock no-error.
  
    if available ttV_BelegTaxrateSums-P then
    do:
  
      find ttVB_CalculatedLineValues-P1
        where ttVB_CalculatedLineValues-P1.Owning_Obj = ttV_BelegPos-P.V_BelegPos_Obj
        no-lock.
  
      assign
        ttV_BelegTaxrateSums-P.H_NetAmount   = ttV_BelegTaxrateSums-P.H_NetAmount   + (ttVB_CalculatedLineValues-P1.H_GrossPrice - ttVB_CalculatedLineValues-P1.H_TaxAmount)
        ttV_BelegTaxrateSums-P.H_TaxAmount   = ttV_BelegTaxrateSums-P.H_TaxAmount   + ttVB_CalculatedLineValues-P1.H_TaxAmount
        ttV_BelegTaxrateSums-P.H_GrossAmount = ttV_BelegTaxrateSums-P.H_GrossAmount + ttVB_CalculatedLineValues-P1.H_GrossPrice
        .
  
    end. /* if available ttV_BelegTaxrateSums-P */
  
  end. /* for each ttV_BelegPos-P */

end procedure. /* H_fillDocumentTaxrateSumsForLLPrint */


/* _UIB-CODE-BLOCK-END */
&ANALYZE-RESUME

&ENDIF


&IF DEFINED(EXCLUDE-H_fillDocumentTotalSumForLLPrint) = 0 &THEN

&ANALYZE-SUSPEND _UIB-CODE-BLOCK _PROCEDURE H_fillDocumentTotalSumForLLPrint Method-Library 
procedure H_fillDocumentTotalSumForLLPrint :
/* Description ---------------------------------------------------------------*/
/*                                                                            */
/* Calculates the document total sums of Hungarian fields.                    */
/* TT ttV_BelegTaxrateSums-P must be filled before calling this method!       */
/*                                                                            */
/* Notes ---------------------------------------------------------------------*/
/*                                                                            */
/* This method does only encapsulate code for better readability of           */
/* fillDataset procedure. It can only be used in the context of this DAO      */
/* run super() has been execute an a global ttV_BelegKopf-P Buffer is         */
/* available... so passing of paramters was forgone deliberatly.              */
/*                                                                            */
/*----------------------------------------------------------------------------*/

  for each ttV_BelegTaxrateSums-P:
  
    assign
      ttV_BelegTotalSum-P.H_NetTotal       = ttV_BelegTotalSum-P.H_NetTotal   + ttV_BelegTaxrateSums-P.H_NetAmount
      ttV_BelegTotalSum-P.H_TaxTotal       = ttV_BelegTotalSum-P.H_TaxTotal   + ttV_BelegTaxrateSums-P.H_TaxAmount
      ttV_BelegTotalSum-P.H_GrossTotal     = ttV_BelegTotalSum-P.H_GrossTotal + ttV_BelegTaxrateSums-P.H_GrossAmount
  
      ttV_BelegTaxrateSums-P.H_NetAmount   = round(ttV_BelegTaxrateSums-P.H_NetAmount,  ttV_BelegKopf-P.WaehrungNK)
      ttV_BelegTaxrateSums-P.H_TaxAmount   = round(ttV_BelegTaxrateSums-P.H_TaxAmount,  ttV_BelegKopf-P.WaehrungNK)
      ttV_BelegTaxrateSums-P.H_GrossAmount = round(ttV_BelegTaxrateSums-P.H_GrossAmount,ttV_BelegKopf-P.WaehrungNK)
      .
  
  end. /* for each ttV_BelegTaxrateSums-P */
  
  for each ttVB_CalculatedLineValues-P1:
  
    ttV_BelegTotalSum-P.H_TaxDifferenceTotal = ttV_BelegTotalSum-P.H_TaxDifferenceTotal + ttVB_CalculatedLineValues-P1.H_TaxDifference.
  
  end.
  
  assign
    ttV_BelegTotalSum-P.H_NetTotal           = round(ttV_BelegTotalSum-P.H_NetTotal,          ttV_BelegKopf-P.WaehrungNK)
    ttV_BelegTotalSum-P.H_TaxTotal           = round(ttV_BelegTotalSum-P.H_TaxTotal,          ttV_BelegKopf-P.WaehrungNK)
    ttV_BelegTotalSum-P.H_GrossTotal         = round(ttV_BelegTotalSum-P.H_GrossTotal,        ttV_BelegKopf-P.WaehrungNK)
    ttV_BelegTotalSum-P.H_TaxDifferenceTotal = round(ttV_BelegTotalSum-P.H_TaxDifferenceTotal,ttV_BelegKopf-P.WaehrungNK)
    .

end procedure. /* H_fillDocumentTotalSumForLLPrint */


/* _UIB-CODE-BLOCK-END */
&ANALYZE-RESUME

&ENDIF

&IF DEFINED(EXCLUDE-I_fillDocumentTaxrateSumsForLLPrint) = 0 &THEN

&ANALYZE-SUSPEND _UIB-CODE-BLOCK _PROCEDURE I_fillDocumentTaxrateSumsForLLPrint Method-Library 
procedure I_fillDocumentTaxrateSumsForLLPrint :
/* Description ---------------------------------------------------------------*/
/*                                                                            */
/* Calculates the taxrate dependant document sums of Italian fields           */
/* TT ttV_BelegTaxrateSums-P must be filled before calling this method!       */
/*                                                                            */
/* Notes ---------------------------------------------------------------------*/
/*                                                                            */
/* This procedure does only encapsulate code for better readability of        */
/* fillDataset procedure. It can only be used in the context of this DAO      */
/* run super() has been execute an a global ttV_BelegKopf-P Buffer is         */
/* available... so passing of paramters was forgone deliberatly.              */
/*                                                                            */
/* this method is a copy for Italy only to avoid new errors for countries     */
/* with only one 0% tax key                                                   */
/*----------------------------------------------------------------------------*/

define variable iTaxRates                    as   integer               no-undo.
define variable lVariousTaxRates             as   logical               no-undo.
define variable lITaxRatesTaxKeyIsZeroTaxKey as   logical               no-undo.

define buffer bttV_BelegPos-P   for temp-table ttV_BelegPos-P.
define buffer bS_Steuer         for S_Steuer.

/*----------------------------------------------------------------------------*/
/* Check if different tax rates are available in the current document. If   */
/* only one single tax rate (e.g. zero) is available, then the print must   */
/* be done only one time.                                                   */
                           
lVariousTaxRates = lDocumentHasDifferentTaxKeys (ttV_BelegSumKopf-Calc.Gesamt_Steuersatz,
                                                 ttV_BelegSumKopf-Calc.H_TaxCode,
                                                 ttV_BelegSumKopf-Calc.P_TaxExtentUsed,
                                                 ttV_BelegSumKopf-Calc.I_P_S_Steuer_Obj).

/* translate the TT_V_BelegSumme record with its extents to the non           */
/* extent records of ttV_BelegTaxrateSums-P. Primary key and Main sort case   */
/* is Gesamt_Steuersatz!                                                      */   

do iTaxRates = 1 to extent(ttV_BelegSumKopf-Calc.Gesamt_Steuersatz):

  /* If we are in first loop we can add, this slot must always be in use.          */
  /* The 'not can-find(ttV_BelegTaxrateSums-P...' must be done from second loop,   */
  /* because several slots can be filled with TaxRate 0 but only the first is used.*/
  /* If we found a slot that was not added we must search if any position or the   */
  /* head surcharges use this slot.                                                */

  /* If only tax rates with value zero exists in the current document, then   */
  /* the print of the sum section must be ensured.                            */
  /* If a text line is the only line with tax rate value zero, then do not    */
  /* print this value in the sum section.                                     */

  /* if there is only one tax rate then it is either in 2 (mistake in trigger V_BelegPos) or in 1 */
  if lVariousTaxRates = no 
    and iTaxrates = 3 then 
    leave.
    
  lITaxRatesTaxKeyIsZeroTaxKey = lTaxKeyIsZeroTaxKey(ttV_BelegSumKopf-Calc.Gesamt_Steuersatz[iTaxRates],
                                                     ttV_BelegSumKopf-Calc.H_TaxCode[iTaxRates],
                                                     ttV_BelegSumKopf-Calc.P_TaxExtentUsed[iTaxRates],
                                                     ttV_BelegSumKopf-Calc.I_P_S_Steuer_Obj[iTaxRates]).

  if (    (   lVariousTaxRates = no
           or (   can-find(first ttV_BelegSumPos-Calc
                             where ttV_BelegSumPos-Calc.Steuersatz = ttV_BelegSumKopf-Calc.Gesamt_Steuersatz[iTaxRates])
               or ttV_BelegKopf-P.SteuerSatzZuschl                 = ttV_BelegSumKopf-Calc.Gesamt_Steuersatz[iTaxRates]))
      /* there is not yet a record with the unique pk index fields */
      and (    (   ttV_BelegSumKopf-Calc.Gesamt_Steuersatz[iTaxRates] > 0
                or (    ttV_BelegSumKopf-Calc.Gesamt_Steuersatz[iTaxRates] = 0 
                    and lITaxRatesTaxKeyIsZeroTaxKey))
            and not can-find(first ttV_BelegTaxrateSums-P
                               where ttV_BelegTaxrateSums-P.Owning_Obj    = ttV_BelegKopf-P.V_BelegKopf_Obj
                                 and ttV_BelegTaxrateSums-P.Steuersatz    = ttV_BelegSumKopf-Calc.Gesamt_Steuersatz[iTaxRates]
                                 and ttV_BelegTaxrateSums-P.P_TaxKey      = ttV_BelegSumKopf-Calc.I_P_S_Steuer_Obj[iTaxRates]
                                 and ttV_BelegTaxrateSums-P.TaxArrayID    = 0))
      and can-find(first bttV_BelegPos-P
                     where bttV_BelegPos-P.Firma      = {firma/vbelegko.fir gcFirma}
                       and bttV_BelegPos-P.BelegArt   = ttV_BelegKopf-P.BelegArt
                       and bttV_BelegPos-P.ReferenzNr = ttV_BelegKopf-P.ReferenzNr
                       and bttV_BelegPos-P.Satzart    = 'A':U
                       and bttV_BelegPos-P.Steuersatz = ttV_BelegSumKopf-Calc.Gesamt_Steuersatz[iTaxRates])) then
  do:

    create ttV_BelegTaxrateSums-P.

    /* first fill all fields in domestic currency */

    assign
      /* main index fields */
      ttV_BelegTaxrateSums-P.Owning_Obj        = ttV_BelegKopf-P.V_BelegKopf_Obj
      ttV_BelegTaxrateSums-P.Steuersatz        = ttV_BelegSumKopf-Calc.Gesamt_Steuersatz[iTaxRates]
      ttV_BelegTaxrateSums-P.P_TaxKey          = ttV_BelegSumKopf-Calc.I_P_S_Steuer_Obj[iTaxRates]
      ttV_BelegTaxrateSums-P.TaxArrayID        = 0
      /* others */    
      ttV_BelegTaxrateSums-P.Anzahlungen       = ttV_BelegSumKopf-Calc.Gesamt_Anzahlungen[iTaxRates]
      ttV_BelegTaxrateSums-P.AnzahlungenSteuer = ttV_BelegSumKopf-Calc.Gesamt_AnzahlungenSteuer[iTaxRates]
      ttV_BelegTaxrateSums-P.Warenwert         = ttV_BelegSumKopf-Calc.Gesamt_Belegsumme[iTaxRates]
      ttV_BelegTaxrateSums-P.Warenwert_ohne_AA = ttV_BelegSumKopf-Calc.Gesamt_Belegsumme[iTaxRates]
                                                 - ttV_BelegSumKopf-Calc.Gesamt_Anzahlungen[iTaxRates]
      .

    if lITaxRatesTaxKeyIsZeroTaxKey then
    do:

      /* Find the first position with tax rate 0. Search for the S_Steuer
         entry of that tax rate to determine whether reverse charge is yes
         or no. This is sufficient for the whole document since we can only 
         have either reverse charge yes or no at the same time.             */

      find first ttV_BelegPos-P
        where ttV_BelegPos-P.Firma      = ttV_BelegKopf-P.Firma
          and ttV_BelegPos-P.Belegart   = ttV_BelegKopf-P.Belegart
          and ttV_BelegPos-P.ReferenzNr = ttV_BelegKopf-P.ReferenzNr
          and ttV_BelegPos-P.SteuerSatz = 0
        no-lock no-error.

      if available ttV_BelegPos-P then
        find bS_Steuer
          where bS_Steuer.S_Steuer_Obj = ttV_BelegPos-P.S_Steuer_Obj
          no-lock no-error.

      if available bS_Steuer then
        ttV_BelegTaxrateSums-P.ReverseCharge =    bS_Steuer.ReverseCharge
                                               or bS_Steuer.P_ReverseCharge.

    end. /* ttV_BelegSumKopf-Calc.Gesamt_Steuersatz[iTaxRates] = 0 */

    ttV_BelegTaxrateSums-P.I_SplitPaymentTax = ttV_BelegSumKopf-Calc.I_SplitPaymentTax.

    if available ttV_BelegSumKopf-VUR then

      ttV_BelegTaxrateSums-P.Warenwert_Vertrag = ttV_BelegSumKopf-VUR.Gesamt_Belegsumme[iTaxRates].


    &IF "{&pa_V_MwStSchlussrechnung}":U <> "1":U &THEN

    if ttV_BelegKopf-P.Brutto = no then   /* von Nettobetrag */
    do:

      ttV_BelegTaxrateSums-P.Steuer  = round((ttV_BelegSumKopf-Calc.Gesamt_Belegsumme[iTaxRates]
                                             + (if iTaxRates = ttV_BelegKopf-P.Zuschlag_Extent then
                                                  ttV_BelegSumKopf-Calc.Gesamtzuschlag
                                                else
                                                  0))
                                             * ttV_BelegSumKopf-Calc.Gesamt_Steuersatz[iTaxRates] / 100,
                                             ttV_BelegKopf-P.WaehrungNK).
      if available ttV_BelegSumKopf-VUR then

        ttV_BelegTaxrateSums-P.Steuer_Vertrag  = round((ttV_BelegSumKopf-VUR.Gesamt_Belegsumme[iTaxRates]
                                                        + (if iTaxRates = ttV_BelegKopf-P.Zuschlag_Extent then
                                                             ttV_BelegSumKopf-VUR.Gesamtzuschlag
                                                           else
                                                             0))
                                                        * ttV_BelegSumKopf-VUR.Gesamt_Steuersatz[iTaxRates] / 100,
                                                        ttV_BelegKopf-P.WaehrungNK).

    end.
    else                              /* aus Bruttobetrag */
    do:

      ttV_BelegTaxrateSums-P.Steuer = round((ttV_BelegSumKopf-Calc.Gesamt_Belegsumme[iTaxRates]
                                             + (if iTaxRates = ttV_BelegKopf-P.Zuschlag_Extent then
                                                  ttV_BelegSumKopf-Calc.Gesamtzuschlag
                                                else
                                                  0))
                                             / (1 + ttV_BelegSumKopf-Calc.Gesamt_Steuersatz[iTaxRates] / 100)
                                             * ttV_BelegSumKopf-Calc.Gesamt_Steuersatz[iTaxRates] / 100,
                                             ttV_BelegKopf-P.WaehrungNK).

      if available ttV_BelegSumKopf-VUR then

        ttV_BelegTaxrateSums-P.Steuer_Vertrag  = round((ttV_BelegSumKopf-VUR.Gesamt_Belegsumme[iTaxRates]
                                                        + (if iTaxRates = ttV_BelegKopf-P.Zuschlag_Extent then
                                                             ttV_BelegSumKopf-VUR.Gesamtzuschlag
                                                           else
                                                             0))
                                                        / (1 + ttV_BelegSumKopf-VUR.Gesamt_Steuersatz[iTaxRates] / 100)
                                                        * ttV_BelegSumKopf-VUR.Gesamt_Steuersatz[iTaxRates] / 100,
                                                        ttV_BelegKopf-P.WaehrungNK).

    end.

    &ELSE

    if ttV_BelegKopf-P.Brutto = no then   /* von Nettobetrag */
    do:

      ttV_BelegTaxrateSums-P.Steuer = round((ttV_BelegSumKopf-Calc.Gesamt_Belegsumme[iTaxRates]
                                             - ttV_BelegSumKopf-Calc.Gesamt_Anzahlungen[iTaxRates]
                                             + (if iTaxRates = ttV_BelegKopf-P.Zuschlag_Extent then
                                                  ttV_BelegSumKopf-Calc.Gesamtzuschlag
                                                else
                                                  0))
                                             * ttV_BelegSumKopf-Calc.Gesamt_Steuersatz[iTaxRates] / 100,
                                             ttV_BelegKopf-P.WaehrungNK)

                                      + ttV_BelegSumKopf-Calc.Gesamt_AnzahlungenSteuer[iTaxRates].

      if available ttV_BelegSumKopf-VUR then

        ttV_BelegTaxrateSums-P.Steuer_Vertrag  = round((ttV_BelegSumKopf-VUR.Gesamt_Belegsumme[iTaxRates]
                                                       - ttV_BelegSumKopf-VUR.Gesamt_Anzahlungen[iTaxRates]
                                                       + (if iTaxRates = ttV_BelegKopf-P.Zuschlag_Extent then
                                                            ttV_BelegSumKopf-VUR.Gesamtzuschlag
                                                          else
                                                            0))
                                                       * ttV_BelegSumKopf-VUR.Gesamt_Steuersatz[iTaxRates] / 100,
                                                       ttV_BelegKopf-P.WaehrungNK)

                                                 + ttV_BelegSumKopf-VUR.Gesamt_AnzahlungenSteuer[iTaxRates].

    end.
    else                              /* aus Bruttobetrag */
    do:

      ttV_BelegTaxrateSums-P.Steuer = round((ttV_BelegSumKopf-Calc.Gesamt_Belegsumme[iTaxRates]
                                             - ttV_BelegSumKopf-Calc.Gesamt_Anzahlungen[iTaxRates]
                                             + (if iTaxRates = ttV_BelegKopf-P.Zuschlag_Extent then
                                                  ttV_BelegSumKopf-Calc.Gesamtzuschlag
                                                else
                                                  0))
                                             / (1 + ttV_BelegSumKopf-Calc.Gesamt_Steuersatz[iTaxRates] / 100)
                                             * ttV_BelegSumKopf-Calc.Gesamt_Steuersatz[iTaxRates] / 100,
                                             ttV_BelegKopf-P.WaehrungNK)
                                      + ttV_BelegSumKopf-Calc.Gesamt_AnzahlungenSteuer[iTaxRates].

      if available ttV_BelegSumKopf-VUR then

        ttV_BelegTaxrateSums-P.Steuer_Vertrag  = round((ttV_BelegSumKopf-VUR.Gesamt_Belegsumme[iTaxRates]
                                                        - ttV_BelegSumKopf-VUR.Gesamt_Anzahlungen[iTaxRates]
                                                        + (if iTaxRates = ttV_BelegKopf-P.Zuschlag_Extent then
                                                             ttV_BelegSumKopf-VUR.Gesamtzuschlag
                                                           else
                                                             0))
                                                        / (1 + ttV_BelegSumKopf-VUR.Gesamt_Steuersatz[iTaxRates] / 100)
                                                        * ttV_BelegSumKopf-VUR.Gesamt_Steuersatz[iTaxRates] / 100,
                                                        ttV_BelegKopf-P.WaehrungNK)
                                                 + ttV_BelegSumKopf-VUR.Gesamt_AnzahlungenSteuer[iTaxRates].

    end.

      &IF LOOKUP("U_CA":U,"{&PA-OPTIONEN}":U) > 0 &THEN

        if ttV_BelegKopf-P.ZahlungsArt = {&uCA_ZahlArtGutschriftsverfahren}
          and can-do('R,G':U,ttV_BelegKopf-P.BelegArt)
          and ttV_BelegTaxrateSums-P.Steuer         <> 0
          and ttV_BelegKopf-P.uGSASteuerKorr        <> 0 then
        do:

          ttV_BelegTaxrateSums-P.Steuer = ttV_BelegTaxrateSums-P.Steuer + ttV_BelegKopf-P.uGSASteuerKorr * ttV_BelegKopf-P.Kurs.

        end.

      &ENDIF

    &ENDIF

    assign

      ttV_BelegTaxrateSums-P.Summe_excl =  ttV_BelegSumKopf-Calc.Gesamt_Belegsumme[iTaxRates]
                                            + (if iTaxRates = ttV_BelegKopf-P.Zuschlag_Extent then
                                                 ttV_BelegSumKopf-Calc.Gesamtzuschlag
                                               else
                                                 0)
                                            - (if ttV_BelegKopf-P.Brutto = no then /* Nettobeleg oder Bruttobeleg */
                                                 0
                                               else
                                                 ttV_BelegTaxrateSums-P.Steuer)

      ttV_BelegTaxrateSums-P.Summe_incl = ttV_BelegSumKopf-Calc.Gesamt_Belegsumme[iTaxRates]
                                            + (if iTaxRates = ttV_BelegKopf-P.Zuschlag_Extent then
                                                 ttV_BelegSumKopf-Calc.Gesamtzuschlag
                                               else
                                                 0)
                                            + (if ttV_BelegKopf-P.Brutto = no then /* Nettobeleg oder Bruttobeleg */
                                                 ttV_BelegTaxrateSums-P.Steuer
                                               else
                                                 0)
      .


    /* All surcharges have the same taxrate  - the surcharge fields are only
       filled for the taxrate they correspond with... (Zuschlag_Extent)       */
    if iTaxRates = ttV_BelegKopf-P.Zuschlag_Extent then
    do:

      ttV_BelegTaxrateSums-P.Zuschlaege =  ttV_BelegSumKopf-Calc.Gesamtzuschlag.

      if glPositions then
        ttV_BelegTaxrateSums-P.Zuschlaege_offen = ttV_BelegTaxrateSums-P.Zuschlaege
                                                  - ttV_BelegKopf-P.Zuschlag_ueber[1]
                                                  - ttV_BelegKopf-P.Zuschlag_ueber[2]
                                                  - ttV_BelegKopf-P.Zuschlag_ueber[3]
                                                  - ttV_BelegKopf-P.Zuschlag_ueber[4].

    end.

    /* The *_Vertrag fields are only calculated if the document is VUR */

    if available ttV_BelegSumKopf-VUR then
    do:
      assign

        ttV_BelegTaxrateSums-P.Summe_excl_Vertrag      = ttV_BelegSumKopf-VUR.Gesamt_Belegsumme[iTaxRates]
                                                         + (if iTaxRates = ttV_BelegKopf-P.Zuschlag_Extent then
                                                              ttV_BelegSumKopf-VUR.Gesamtzuschlag
                                                            else
                                                              0)
                                                         - (if ttV_BelegKopf-P.Brutto = no then /* Nettobeleg oder Bruttobeleg */
                                                              0
                                                            else
                                                              ttV_BelegTaxrateSums-P.Steuer_Vertrag)


        ttV_BelegTaxrateSums-P.Summe_incl_Vertrag      = ttV_BelegSumKopf-VUR.Gesamt_Belegsumme[iTaxRates]
                                                         + (if iTaxRates = ttV_BelegKopf-P.Zuschlag_Extent then
                                                              ttV_BelegSumKopf-VUR.Gesamtzuschlag
                                                            else
                                                              0)
                                                         + (if ttV_BelegKopf-P.Brutto = no then /* Nettobeleg oder Bruttobeleg */
                                                              ttV_BelegTaxrateSums-P.Steuer_Vertrag
                                                            else
                                                              0)
        .
    end.

    /* If Eurofaktor field is > 0  and the documents domestic currency is not */
    /* EUR, the EUR_* fields are filled ... this was important during the     */
    /* years of transition to the Euro. It might be important again if        */
    /* further countries join the Euro or countries having the Euro now,      */
    /* abandom it in the future!                                              */

    if ttS_Waehrung-P1.Eurofaktor > 0 then
    do:
      assign
        ttV_BelegTaxrateSums-P.Eur_Anzahlungen          = ttV_BelegTaxrateSums-P.Anzahlungen / ttS_Waehrung-P1.Eurofaktor
        ttV_BelegTaxrateSums-P.Eur_AnzahlungenSteuer    = ttV_BelegTaxrateSums-P.AnzahlungenSteuer / ttS_Waehrung-P1.Eurofaktor
        ttV_BelegTaxrateSums-P.Eur_Summe_excl           = ttV_BelegTaxrateSums-P.Summe_excl / ttS_Waehrung-P1.Eurofaktor
        ttV_BelegTaxrateSums-P.Eur_Summe_excl_Vertrag   = ttV_BelegTaxrateSums-P.Summe_excl_Vertrag  / ttS_Waehrung-P1.Eurofaktor
        ttV_BelegTaxrateSums-P.Eur_Summe_incl           = ttV_BelegTaxrateSums-P.Summe_incl / ttS_Waehrung-P1.Eurofaktor
        ttV_BelegTaxrateSums-P.Eur_Summe_incl_Vertrag   = ttV_BelegTaxrateSums-P.Summe_incl_Vertrag  / ttS_Waehrung-P1.Eurofaktor
        ttV_BelegTaxrateSums-P.Eur_Steuer               = ttV_BelegTaxrateSums-P.Steuer  / ttS_Waehrung-P1.Eurofaktor
        ttV_BelegTaxrateSums-P.Eur_Steuer_Vertrag       = ttV_BelegTaxrateSums-P.Steuer_Vertrag  / ttS_Waehrung-P1.Eurofaktor
        ttV_BelegTaxrateSums-P.Eur_Warenwert            = ttV_BelegTaxrateSums-P.Warenwert / ttS_Waehrung-P1.Eurofaktor
        ttV_BelegTaxrateSums-P.Eur_Warenwert_Vertrag    = ttV_BelegTaxrateSums-P.Warenwert_Vertrag / ttS_Waehrung-P1.Eurofaktor
        ttV_BelegTaxrateSums-P.Eur_Warenwert_ohne_AA    = ttV_BelegTaxrateSums-P.Warenwert_ohne_AA / ttS_Waehrung-P1.Eurofaktor
        ttV_BelegTaxrateSums-P.Eur_Zuschlaege           = ttV_BelegTaxrateSums-P.Zuschlaege / ttS_Waehrung-P1.Eurofaktor
      .

    end.

    if can-do('R,G':U, ttV_BelegKopf-P.Belegart) then
    do:
      
      if ttV_BelegKopf-P.Waehrung <> 0 then
        assign
          ttV_BelegTaxrateSums-P.EW_Steuer     = round({fnarg
                                                          pa_dCurDomCurAmtNonEur
                                                          "ttV_BelegTaxrateSums-P.Steuer,
                                                          ttV_BelegKopf-P.Kurs,
                                                          1"},
                                                       giDecimalsDomCur)
          ttV_BelegTaxrateSums-P.EW_Summe_excl = round({fnarg
                                                          pa_dCurDomCurAmtNonEur
                                                          "ttV_BelegTaxrateSums-P.Summe_excl,
                                                          ttV_BelegKopf-P.Kurs,
                                                          1"},
                                                       giDecimalsDomCur)
          .

      else
        assign
          ttV_BelegTaxrateSums-P.EW_Steuer     = ttV_BelegTaxrateSums-P.Steuer
          ttV_BelegTaxrateSums-P.EW_Summe_excl = ttV_BelegTaxrateSums-P.Summe_excl
          .        

      ttV_BelegTaxrateSums-P.EW_Summe_incl = ttV_BelegTaxrateSums-P.EW_Summe_excl
                                           + ttV_BelegTaxrateSums-P.EW_Steuer.                                             

    end. /* if can-do('R,G':U, ttV_BelegKopf-P.Belegart) */

  end. /* if lVariousTaxRates and not can-find(ttV_BelegTaxrateSums-P */

end. /* iTaxRates = 1 to extent(ttV_BelegSumKopf-Calc.Gesamt_Steuersatz) */

end procedure. /* I_fillDocumentTaxrateSumsForLLPrint */


/* _UIB-CODE-BLOCK-END */
&ANALYZE-RESUME

&ENDIF

&IF DEFINED(EXCLUDE-FillLineSupplierTaxIDForLLPrint) = 0 &THEN

&ANALYZE-SUSPEND _UIB-CODE-BLOCK _PROCEDURE FillLineSupplierTaxIDForLLPrint Method-Library 
procedure FillLineSupplierTaxIDForLLPrint :
/* Description ---------------------------------------------------------------*/
/*                                                                            */
/* Determine the suppliers tax id by the A/P Invoice Voucher if we are in an  */
/* invoice for a drop shipment order. This is only possible if there is only  */
/* one purchase order for the order line.                                     */
/*                                                                            */
/* Notes ---------------------------------------------------------------------*/
/*                                                                            */
/* If the suppliers tax id for each doc. line is the same then it can be      */
/* copied for the doc. header                                                 */
/*                                                                            */
/*----------------------------------------------------------------------------*/

define variable cSuppTaxIDLine           like V_BelegKopf.TaxID         no-undo.

define buffer bV_BelegPos    for V_BelegPos.
define buffer bE_BelegPos    for E_BelegPos.
define buffer bER_BelegPos   for ER_BelegPos.
define buffer bER_BelegKopf  for ER_BelegKopf.

find bV_BelegPos
  where bV_BelegPos.V_BelegPos_Obj = ttV_BelegPos-P.Origin_Obj
    and bV_BelegPos.BelegArt       = 'U':U
  no-lock no-error.

if available bV_BelegPos then
do:

  find bE_BelegPos     /* without 'first' - only if there is only one purchase line */
    where bE_BelegPos.Firma               = {firma/ebelkop.fir bV_BelegPos.Firma}
      and bE_BelegPos.BelegArt            = 'EB':U
      and bE_BelegPos.Coverage_MRPDocType = bV_BelegPos.BelegArt
      and bE_BelegPos.Coverage_Obj        = bV_BelegPos.V_BelegPos_Obj
      and bE_BelegPos.Artikel             = bV_BelegPos.Artikel
    no-lock no-error.

  if available bE_BelegPos then

    /* es könnte mehrere Teilrechnungen zu einer Bestellpos. geben          */
    /* SteuerNr wird nur dann gemerkt, wenn es in allen ERR die gleiche ist */

    for each bER_BelegPos
      where bER_BelegPos.Firma            = bE_BelegPos.Firma
        and bER_BelegPos.Belegart         = 'ERR':U
        and bER_BelegPos.Herk_Belegart    = bE_BelegPos.Belegart
        and bER_BelegPos.Herk_ReferenzNr  = bE_BelegPos.ReferenzNr
        and bER_BelegPos.Herk_PositionsNr = bE_BelegPos.PositionsNr
      no-lock,
    first bER_BelegKopf
      where bER_BelegKopf.Firma       = bER_BelegPos.Firma
        and bER_BelegKopf.Belegart    = bER_BelegPos.Belegart
        and bER_BelegKopf.ReferenzNr  = bER_BelegPos.ReferenzNr
        and bER_BelegKopf.BelegNummer > 0
      no-lock
      break by bER_BelegKopf.ReferenzNr:

      if first(bER_BelegKopf.ReferenzNr) then

        cSuppTaxIDLine = bER_BelegKopf.SuppTaxID.

      else

        if bER_BelegKopf.SuppTaxID <> cSuppTaxIDLine then

          cSuppTaxIDLine = '':U.

    end. /* for each bER_BelegPos, first bER_BelegKopf */

end.

ttV_BelegPos-P.SupplierTaxID = cSuppTaxIDLine.

end procedure. /* FillLineSupplierTaxIDForLLPrint */


/* _UIB-CODE-BLOCK-END */
&ANALYZE-RESUME

&ENDIF


&IF DEFINED(EXCLUDE-normalizeCompany) = 0 &THEN

&ANALYZE-SUSPEND _UIB-CODE-BLOCK _PROCEDURE normalizeCompany Method-Library 
procedure normalizeCompany :
/* Description ---------------------------------------------------------------*/
/*                                                                            */
/* Set the field Firma/Company of all records in the dataset that have        */
/* a relation using this field to gcFirma.                                    */
/*                                                                            */
/* Notes ---------------------------------------------------------------------*/
/*                                                                            */
/* During fill of dataset company includes are considered for selecting data  */
/* but the TT records are not normalized concerning the company relation.     */
/* Example:                                                                   */
/* ttV_BelegPos-P.Firma can be '110'  and the dependent unit of measure       */
/* ttS_MengenEinheit-P.Firma can be ''.  This would lead to exclusion of the  */
/* dependent unit of measure during export to L&L.                            */
/*                                                                            */
/*----------------------------------------------------------------------------*/

  for each ttV_BelegKopf-P:
    ttV_BelegKopf-P.Firma = gcFirma.
  end.
  
  for each ttV_BelegPos-P:
    ttV_BelegPos-P.Firma = gcFirma.
  end.
  
  for each ttS_Kunde-P1:
    ttS_Kunde-P1.Firma = gcFirma.
  end.
  
  for each ttS_Waehrung-P1:
    ttS_Waehrung-P1.Firma = gcFirma.
  end.
  
  for each ttS_VersandArt-P:
    ttS_VersandArt-P.Firma = gcFirma.
  end.
  
  for each ttS_ZahlZiel-P:
    ttS_ZahlZiel-P.Firma = gcFirma.
  end.
  
  for each ttS_Verband-P:
    ttS_Verband-P.Firma = gcFirma.
  end.
  
  for each ttS_LieferBed-P:
    ttS_LieferBed-P.Firma = gcFirma.
  end.
  
  for each ttS_AuftragsArt-P:
    ttS_AuftragsArt-P.Firma = gcFirma.
  end.
  
  for each ttS_Adresse-PVert:
    ttS_Adresse-PVert.Firma = gcFirma.
  end.
  
  for each ttS_MengenEinheit-P:
    ttS_MengenEinheit-P.Firma = gcFirma.
  end.
  
  for each ttS_Artikel-P:
    ttS_Artikel-P.Firma = gcFirma.
  end.
  
  for each ttS_MengenEinheit-PStorUnit:
    ttS_MengenEinheit-PStorUnit.Firma = gcFirma.
  end.
  
  for each ttS_Artikel-PMaint:
    ttS_Artikel-PMaint.Firma = gcFirma.
  end.
  
  for each ttS_ArtikelSpr-P:
    ttS_ArtikelSpr-P.Firma = gcFirma.
  end.
  
  for each ttS_ArtKunde-P:
    ttS_ArtKunde-P.Firma = gcFirma.
  end.
  
  for each ttML_Ort-P:
    ttML_Ort-P.Firma = gcFirma.
  end.
  
  for each ttS_PreisEinheit-P:
    ttS_PreisEinheit-P.Firma = gcFirma.
  end.
  
  for each ttS_LieferBed-P1:
    ttS_LieferBed-P1.Firma = gcFirma.
  end.
  
  for each ttMLM_StorPartData-P:
    ttMLM_StorPartData-P.Company = gcFirma.
  end.
  
  for each ttMLM_StorPartData-PSetLine:
    ttMLM_StorPartData-PSetLine.Company = gcFirma.
  end.
  
  for each ttS_MengenEinheit-P2:
    ttS_MengenEinheit-P2.Firma = gcFirma.
  end.
  
  for each ttVS_Auftrag-P:
    ttVS_Auftrag-P.Firma = gcFirma.
  end.
  
  for each ttS_Artikel-P1:
    ttS_Artikel-P1.Firma = gcFirma.
  end.
  
  for each ttS_AuftragsArt-P2:
    ttS_AuftragsArt-P2.Firma = gcFirma.
  end.
  
  for each ttV_BelegBestOrt-P:
    ttV_BelegBestOrt-P.Firma = gcFirma.
  
    /* Fill AdrRow fields */
  
    {vert/base/incl/vb_bel00.if
       &ippSourceAdrTable = "ttV_BelegBestOrt-P"
       &ippTargetTable    = "ttV_BelegBestOrt-P"
    }  
  end.
  
  for each ttV_BelegZZ-P:
    ttV_BelegZZ-P.Firma = gcFirma.
  end.
  
  for each ttML_Lagergruppe-P1:
    ttML_Lagergruppe-P1.Firma = gcFirma.
  end.
  
  for each ttVU_RA_Artikel-P:
    ttVU_RA_Artikel-P.Firma = gcFirma.
  end.
  
  for each ttS_Artikel-PAlternate:
    ttS_Artikel-PAlternate.Firma = gcFirma.
  end.
  
  for each ttS_MengenEinheit-PSet:
    ttS_MengenEinheit-PSet.Firma = gcFirma.
  end.

end procedure. /* normalizeCompany */


/* _UIB-CODE-BLOCK-END */
&ANALYZE-RESUME

&ENDIF

&IF DEFINED(EXCLUDE-uFillBackOrderLinies) = 0 &THEN

&ANALYZE-SUSPEND _UIB-CODE-BLOCK _PROCEDURE uFillBackOrderLinies Method-Library
procedure uFillBackOrderLinies :
/* Description ---------------------------------------------------------------*/
/*                                                                            */
/* Fill Back Order Lines section (P.URK & P.URP).                             */
/*                                                                            */
/*----------------------------------------------------------------------------*/

&IF LOOKUP("U_CW":U,"{&PA-OPTIONEN}":U) > 0 &THEN

define variable lUV_PrintPartialDeliveredBOLines as logical no-undo.
define variable lPrintable                       as logical no-undo.
define variable iuKunde                          as integer no-undo.

define buffer buV_BelegPos           for V_BelegPos.
define buffer buV_BelegPos-W         for V_BelegPos.
define buffer buV_BelegPos-Order     for V_BelegPos.
define buffer buS_Mengeneinheit      for S_MengenEinheit.
define buffer buS_Artikel            for S_Artikel.
define buffer buV_BelegKopf-Order    for V_BelegKopf.
define buffer buS_ArtKunde           for S_ArtKunde.
define buffer bttuBackorderLinies-P  for temp-table ttuBackorderLinies-P.
define buffer bttV_BelegPos-POrder   for temp-table ttV_BelegPos-POrder.
define buffer bttS_MengenEinheit-P10 for temp-table ttS_MengenEinheit-P10.
define buffer bttS_Artikel-P2        for temp-table ttS_Artikel-P10.
define buffer bttV_BelegKopf-P2Order for temp-table ttV_BelegKopf-P2Order.
define buffer bttS_ArtKunde-P        for temp-table ttS_ArtKunde-P11.

  empty temp-table bttuBackorderLinies-P.
  
  lUV_PrintPartialDeliveredBOLines = adm.config.cls.DCCAppConfigSvc:prpoInstance:lParameterValue('UV_BackorderLiniesPrintDouble':U).
  
  for each buV_BelegPos
    where buV_BelegPos.Firma      = ttV_BelegKopf-P.Firma
      and buV_BelegPos.BelegArt   = ttV_BelegKopf-P.BelegArt
      and buV_BelegPos.ReferenzNr = ttV_BelegKopf-P.ReferenzNr
    no-lock
    break by buV_BelegPos.Herk_ReferenzNr: /* code checked by shafieian_a 16.03.2017 */
  
    if first-of (buV_BelegPos.Herk_ReferenzNr) then
    do:
  
      for each buV_BelegPos-Order
        where buV_BelegPos-Order.Firma      = ttV_BelegKopf-P.firma
          and buV_BelegPos-Order.BelegArt   = 'U':U
          and buV_BelegPos-Order.ReferenzNr = buV_BelegPos.Herk_ReferenzNr
          and buV_BelegPos-Order.LfdNr_SR   = 0
        no-lock:
  
        lPrintable = no.
  
        /* Positions with open quantities only are backlog lines!               */
        if buV_BelegPos-Order.Menge - (  buV_BelegPos-Order.gelieferte_Menge
                                       + buV_BelegPos-Order.stornierte_Menge) > 0 then
          lPrintable = yes.
  
        if    not lUV_PrintPartialDeliveredBOLines
          and lPrintable
          and can-find(first buV_BelegPos-W
                         where buV_BelegPos-W.Firma            = ttV_BelegKopf-P.Firma
                           and buV_BelegPos-W.BelegArt         = 'L':U
                           and buV_BelegPos-W.Herk_ReferenzNr  = buV_BelegPos-Order.ReferenzNr
                           and buV_BelegPos-W.Herk_PositionsNr = buV_BelegPos-Order.PositionsNr
                           and buV_BelegPos-W.ReferenzNr       = ttV_BelegKopf-P.ReferenzNr
                           and buV_BelegPos-W.LfdNr_SR         = 0 ) then
          lPrintable = no.
  
        if lPrintable then
        do:
  
          create bttuBackorderLinies-P.
            assign
              bttuBackorderLinies-P.Owning_Obj    = ttV_BelegKopf-P.V_BelegKopf_Obj
              bttuBackorderLinies-P.AuftragsNr    = buV_BelegPos-Order.BelegNummer
              bttuBackorderLinies-P.AuftragsPosNr = buV_BelegPos-Order.PositionsNr
              bttuBackorderLinies-P.AuftragsRefNr = buV_BelegPos-Order.ReferenzNr
              bttuBackorderLinies-P.Artikel       = buV_BelegPos-Order.Artikel
              .
  
        end. /* if lPrintable then */
  
      end. /* for each buV_BelegPos-Order */
  
    end. /* if first-of (buV_BelegPos.Herk_ReferenzNr) then */
  
  end. /* for each buV_BelegPos  */
  
  for each bttuBackorderLinies-P
    break by bttuBackorderLinies-P.AuftragsNr
    by bttuBackorderLinies-P.AuftragsPosNr
    on error undo, throw:
  
    if not can-find(bttS_Artikel-P2
                      where bttS_Artikel-P2.Firma   = gcFirma
                        and bttS_Artikel-P2.Artikel = bttuBackorderLinies-P.Artikel) then
    do:
  
      find buS_Artikel
        where buS_Artikel.Firma   = {firma/sartikel.fir gcFirma}
          and buS_Artikel.Artikel = bttuBackorderLinies-P.Artikel
        no-lock no-error.
  
      if available buS_Artikel then
      do:
  
        create bttS_Artikel-P2.
        {buffer-copy
           buS_Artikel
           to bttS_Artikel-P2
           assign
             "bttS_Artikel-P2.Firma = gcFirma"}
  
      end. /* if available buS_Artikel then */
  
    end. /* if not can-find(bttS_Artikel-P2 */
  
    if not can-find(bttV_BelegPos-POrder
                      where bttV_BelegPos-POrder.Firma       = gcFirma
                        and bttV_BelegPos-POrder.BelegArt    = 'U':U
                        and bttV_BelegPos-POrder.ReferenzNr  = bttuBackorderLinies-P.AuftragsRefNr
                        and bttV_BelegPos-POrder.LfdNr_SR    = 0
                        and bttV_BelegPos-POrder.PositionsNr = bttuBackorderLinies-P.AuftragsPosNr) then
    do:
  
      find buV_BelegPos-Order
        where buV_BelegPos-Order.Firma       = {firma/vbelegko.fir gcFirma}
          and buV_BelegPos-Order.BelegArt    = 'U':U
          and buV_BelegPos-Order.ReferenzNr  = bttuBackorderLinies-P.AuftragsRefNr
          and buV_BelegPos-Order.LfdNr_SR    = 0
          and buV_BelegPos-Order.PositionsNr = bttuBackorderLinies-P.AuftragsPosNr
        no-lock no-error.
  
      if available buV_BelegPos-Order then
      do:
  
        create bttV_BelegPos-POrder.
        {buffer-copy
           buV_BelegPos-Order
           to bttV_BelegPos-POrder
           assign
             "bttV_BelegPos-POrder.Firma = gcFirma"}
  
        bttV_BelegPos-POrder.offene_Menge = buV_BelegPos-Order.Menge
                                          - buV_BelegPos-Order.gelieferte_Menge
                                          - buV_BelegPos-Order.stornierte_Menge.
  
      end. /* if available buV_BelegPos-Order then */
  
    end. /* if not can-find(bttV_BelegPos-POrder */
  
    find buV_BelegKopf-Order
      where buV_BelegKopf-Order.Firma      = {firma/vbelegko.fir gcFirma}
        and buV_BelegKopf-Order.BelegArt   = 'U':U
        and buV_BelegKopf-Order.ReferenzNr = bttuBackorderLinies-P.AuftragsRefNr
      no-lock no-error.

    if     available buV_BelegKopf-Order
       and not can-find(bttV_BelegKopf-P2Order
                        where bttV_BelegKopf-P2Order.Firma      = gcFirma
                          and bttV_BelegKopf-P2Order.BelegArt   = 'U':U
                          and bttV_BelegKopf-P2Order.ReferenzNr = bttuBackorderLinies-P.AuftragsRefNr) then
    do:

        create bttV_BelegKopf-P2Order.
        {buffer-copy
           buV_BelegKopf-Order
           to bttV_BelegKopf-P2Order
           assign
             "bttV_BelegKopf-P2Order.Firma      = gcFirma
              bttV_BelegKopf-P2Order.Empfaenger = VBCContactPersonSvc:prpoInstance:cGetContactPersonName
                                                    (buV_BelegKopf-Order.V_BelegKopf_Obj,
                                                     integer(SBCContactTypeEnu:Customer))"}

    end. /* if available buV_BelegKopf-Order then */
  
    if not can-find(bttS_MengenEinheit-P10
                      where bttS_MengenEinheit-P10.Firma         = gcFirma
                        and bttS_MengenEinheit-P10.Mengeneinheit = buV_BelegPos-Order.Mengeneinheit) then
    do:
  
      find buS_Mengeneinheit
        where buS_Mengeneinheit.Firma         = {firma/smngeinh.fir gcFirma}
          and buS_Mengeneinheit.Mengeneinheit = buV_BelegPos-Order.Mengeneinheit
        no-lock no-error.
  
      if available buS_Mengeneinheit then
      do:
  
        create bttS_MengenEinheit-P10.
        {buffer-copy
           buS_Mengeneinheit
           to bttS_MengenEinheit-P10
           assign
             "bttS_MengenEinheit-P10.Firma = gcFirma"}
  
      end. /* if available buS_Mengeneinheit then */
  
    end. /* if not can-find (bttS_MengenEinheit-P10 */
  
    if available buV_BelegKopf-Order then
      iuKunde = vert.base.cls.VBCSalesDocSvc:prpoInstance:iGetCustomerOfShipment(buffer buV_BelegKopf-Order).
  
    if available buV_BelegKopf-Order
      and not can-find(bttS_ArtKunde-P
                         where bttS_ArtKunde-P.Firma   = gcFirma
                           and bttS_ArtKunde-P.Kunde   = iuKunde
                           and bttS_ArtKunde-P.Artikel = buS_Artikel.Artikel) then
    do:
  
      find buS_ArtKunde
        where buS_ArtKunde.Firma   = {firma/sartkund.fir gcFirma}
          and buS_ArtKunde.Kunde   = iuKunde
          and buS_ArtKunde.Artikel = buS_Artikel.Artikel
        no-lock no-error.
  
      if available buS_ArtKunde then
      do:
  
        create bttS_ArtKunde-P.
        {buffer-copy
           buS_ArtKunde
           to bttS_ArtKunde-P
           assign
             "bttS_ArtKunde-P.Firma = gcFirma"}
  
      end. /* if available buS_ArtKunde then */
  
    end. /* if available buV_BelegKopf-Order  */
  
  end. /* for each bttuBackorderLinies */

&ENDIF

end procedure. /* uFillBackOrderLinies */


/* _UIB-CODE-BLOCK-END */
&ANALYZE-RESUME

&ENDIF


&IF DEFINED(EXCLUDE-uFillCreditMemo) = 0 &THEN

&ANALYZE-SUSPEND _UIB-CODE-BLOCK _PROCEDURE uFillCreditMemo Method-Library
procedure uFillCreditMemo :
/* Description ---------------------------------------------------------------*/
/*                                                                            */
/*    Process credit memo                                                     */
/*                                                                            */
/*----------------------------------------------------------------------------*/

&IF LOOKUP("U_CA":U,"{&PA-OPTIONEN}":U) > 0 &THEN

define variable cuObjectID    as character no-undo.

/* Buffers -------------------------------------------------------------------*/

define buffer bV_BelegKopf    for            V_BelegKopf.
define buffer bFB_Buchung     for            FB_Buchung.
define buffer bFO_OP          for            FO_OP.
define buffer bttFB_Buchung-P for temp-table ttFB_Buchung-P5.
define buffer bttFO_OP-P      for temp-table ttFO_OP-P1.


  cuObjectID = branche.vert.cls.UVC_CACreditMemoSvc:prpoInstance:cFindInvoiceGSA
                 (gcFirma,
                  ttV_BelegKopf-P.Kunde,
                  ttV_BelegPos-P.uGSALieferscheinnummer,
                  ttV_BelegPos-P.uGSALieferscheinDatum,
                  ttV_BelegPos-P.Artikel).
  
  if cuObjectID > '':U then
  
    find bV_BelegKopf
      where bV_BelegKopf.V_BelegKopf_Obj = cuObjectID
      no-lock no-error.
  
  if   not available bV_BelegKopf
    or can-find(bttFB_Buchung-P
                  where bttFB_Buchung-P.Firma           = gcFirma
                    and bttFB_Buchung-P.Konto           = bV_BelegKopf.Kunde
                    and bttFB_Buchung-P.Belegnummer     = bV_BelegKopf.Belegnummer
                    and bttFB_Buchung-P.Belegdatum      = bV_BelegKopf.Belegdatum
                    and bttFB_Buchung-P.Herk_Belegart   = bV_BelegKopf.Belegart
                    and bttFB_Buchung-P.Herk_ReferenzNr = bV_BelegKopf.ReferenzNr) then
    return.

  
  find first bFB_Buchung
    where bFB_Buchung.Firma           = {firma/fbbuchu.fir gcFirma}
      and bFB_Buchung.Konto           = bV_BelegKopf.Kunde
      and bFB_Buchung.Belegnummer     = bV_BelegKopf.Belegnummer
      and bFB_Buchung.Belegdatum      = bV_BelegKopf.Belegdatum
      and bFB_Buchung.Herk_Belegart   = bV_BelegKopf.Belegart
      and bFB_Buchung.Herk_ReferenzNr = bV_BelegKopf.ReferenzNr
    use-index KontoBeleg
    no-lock no-error.
  
  if not available bFB_Buchung then
    return.
  
    create bttFB_Buchung-P.
    {buffer-copy
       bFB_Buchung
       to bttFB_Buchung-P
       assign
         "bttFB_Buchung-P.Firma      = gcFirma
          bttFB_Buchung-P.Owning_Obj = ttV_BelegPos-P.V_BelegPos_Obj"}

    if can-find(bttFO_OP-P
                  where bttFO_OP-P.FB_Buchung_Obj = bFB_Buchung.FB_Buchung_Obj) then
      return.

    find bFO_OP 
      where bFO_OP.FB_Buchung_Obj = bFB_Buchung.FB_Buchung_Obj
      no-lock no-error. 

    if available bFO_OP then
    do:

      create bttFO_OP-P.
      {buffer-copy
         bFO_OP
         to bttFO_OP-P}

    end. /* if available buFO_OP */ 
  
  &ENDIF /* U_CA */

end procedure. /* uFillCreditMemo */


/* _UIB-CODE-BLOCK-END */
&ANALYZE-RESUME

&ENDIF


&ANALYZE-SUSPEND _UIB-CODE-BLOCK _PROCEDURE ufillCustomerGroup Method-Library
procedure uFillCustomerGroup :
/* Description ---------------------------------------------------------------*/
/*                                                                            */
/* Fill customer group variable                                               */
/*                                                                            */

&IF LOOKUP("U_CW":U,"{&PA-OPTIONEN}":U) > 0 &THEN

  define variable cuCustomerGroup_Desc  as character                    no-undo. 
  define variable cuCustomerGroup       as character                    no-undo.

  define buffer buV_BelegPos-Bonus            for V_BelegPos.
  define buffer bUVT_BonusBilling             for UVT_BonusBilling.
  define buffer bUSM_BonusContract            for USM_BonusContract. 
  define buffer bUSM_CustomerGroup            for USM_CustomerGroup.
  define buffer bDBM_ShortDescription         for DBM_ShortDescription.

  assign
    cuCustomerGroup        = '':U
    cuCustomerGroup_Desc   = '':U
    .

  find buV_BelegPos-Bonus                                                 /* code checked by Martin_L 16.02.2018 */
    where buV_BelegPos-Bonus.Firma       = {firma/vbelegko.fir ttV_BelegKopf-P.Firma}
      and buV_BelegPos-Bonus.BelegArt    = ttV_BelegKopf-P.BelegArt
      and buV_BelegPos-Bonus.ReferenzNr  = ttV_BelegKopf-P.ReferenzNr
      and buV_BelegPos-Bonus.LfdNr_SR    = 0
    no-lock no-error.

  if available buV_BelegPos-Bonus then
    find bUVT_BonusBilling             /* code checked by Martin_L 02.03.2018 */
      where bUVT_BonusBilling.CreditNote_Obj = buV_BelegPos-Bonus.V_BelegPos_Obj
      no-lock no-error.

  if available bUVT_BonusBilling then
    find bUSM_BonusContract
      where bUSM_BonusContract.USM_BonusContract_Obj = bUVT_BonusBilling.USM_BonusContract_Obj
      no-lock no-error.

  if available bUSM_BonusContract then
    find bUSM_CustomerGroup
      where bUSM_CustomerGroup.USM_CustomerGroup_Obj = bUSM_BonusContract.Owning_Obj
      no-lock no-error.

  if available bUSM_CustomerGroup then
  do:

    cuCustomerGroup = bUSM_CustomerGroup.USM_CustomerGroup_ID.

    {adm/incl/d__spr00.if
      &Tabelle  = "bDBM_ShortDescription"
      &Selekt   = "where bDBM_ShortDescription.owning_obj = bUSM_CustomerGroup.USM_CustomerGroup_Obj"
      &Sprache  = "gcContentLanguage"
      &no-error = "no-error"
    }

    if available bDBM_ShortDescription then
      cuCustomerGroup_Desc = bDBM_ShortDescription.ShortDesc1.
    else
      cuCustomerGroup_Desc = '':U.

  end.

  find {&pa_DR_DataProviderVariablesTT}
    where {&pa_DR_DataProviderVariablesTT}.VariableName = 'uCustomerGroup':U
    no-error.

  if available {&pa_DR_DataProviderVariablesTT} then
    {&pa_DR_DataProviderVariablesTT}.CharacterValue = cuCustomerGroup.  

  find {&pa_DR_DataProviderVariablesTT}
    where {&pa_DR_DataProviderVariablesTT}.VariableName = 'uCustomerGroup_Desc':U
    no-error.

  if available {&pa_DR_DataProviderVariablesTT} then
    {&pa_DR_DataProviderVariablesTT}.CharacterValue = cuCustomerGroup_Desc.   

&ENDIF

end procedure. /* ufillCustomerGroup */

/* _UIB-CODE-BLOCK-END */
&ANALYZE-RESUME


&IF DEFINED(EXCLUDE-uFillOrderSection) = 0 &THEN

&ANALYZE-SUSPEND _UIB-CODE-BLOCK _PROCEDURE uFillOrderSection Method-Library
procedure uFillOrderSection :
/* Description ---------------------------------------------------------------*/
/*                                                                            */
/* Fill origin order section (UAU).                                           */
/*                                                                            */
/*----------------------------------------------------------------------------*/

&IF LOOKUP("U_CI":U,"{&PA-OPTIONEN}":U) > 0 &THEN

define variable cSourceDocLineObj as character no-undo.

define buffer buV_BelegKopf      for V_BelegKopf.
define buffer buV_BelegPos       for V_BelegPos.

define buffer bttV_BelegKopf-P2  for temp-table ttV_BelegKopf-P2.
define buffer bttV_BelegPos-PInv for temp-table ttV_BelegPos-PInv.


  if    can-do('L,R':U,ttV_BelegPos-P.Belegart)
    and ttV_BelegPos-P.Herk_Belegart <> ? then
  do:
  
    cSourceDocLineObj = vert.base.cls.VBCSalesDocSvc:prpoInstance:cGetSourceDocLineObj
                           ('U':U,
                            ttV_BelegPos-P.V_BelegPos_Obj).
  
    if cSourceDocLineObj = ? then
      cSourceDocLineObj = vert.base.cls.VBCSalesDocSvc:prpoInstance:cGetSourceDocLineObj
                             ('VUA':U,
                              ttV_BelegPos-P.V_BelegPos_Obj).
  
    if cSourceDocLineObj = ? then
      return.
  
    find buV_BelegPos
      where buV_BelegPos.V_BelegPos_Obj = cSourceDocLineObj
      no-lock no-error. 
  
    if not available buV_BelegPos then
      return.
  
    create bttV_BelegPos-PInv.   

    assign   
      bttV_BelegPos-PInv.Owning_Obj     = ttV_BelegPos-P.V_BelegPos_Obj                                           
      bttV_BelegPos-PInv.PositionsNr    = ttV_BelegPos-P.PositionsNr
      bttV_BelegPos-PInv.LfdNr_SR       = ttV_BelegPos-P.LfdNr_SR
      .

    {buffer-copy
       buV_BelegPos
       except "PositionsNr LfdNr_SR"
       to bttV_BelegPos-PInv
       assign
         "bttV_BelegPos-PInv.Firma            = gcFirma
          bttV_BelegPos-PInv.Auftragsposition = buV_BelegPos.PositionsNr"} 

    if not can-find(bttV_BelegKopf-P2                                                                              
                      where bttV_BelegKopf-P2.Firma      = gcFirma                          
                        and bttV_BelegKopf-P2.Belegart   = bttV_BelegPos-PInv.Belegart                           
                        and bttV_BelegKopf-P2.ReferenzNr = bttV_BelegPos-PInv.ReferenzNr ) then                   
    do:

      find buV_BelegKopf
        where buV_BelegKopf.Firma      = {firma/vbelegko.fir gcFirma}
          and buV_BelegKopf.Belegart   = bttV_BelegPos-PInv.Belegart
          and buV_BelegKopf.ReferenzNr = bttV_BelegPos-PInv.ReferenzNr
        no-lock no-error.

      if available buV_BelegKopf then
      do:

        create bttV_BelegKopf-P2.    

        {buffer-copy
           buV_BelegKopf
           to bttV_BelegKopf-P2
           assign
             "bttV_BelegKopf-P2.Firma      = gcFirma
              bttV_BelegKopf-P2.Empfaenger = VBCContactPersonSvc:prpoInstance:cGetContactPersonName
                                               (buV_BelegKopf.V_BelegKopf_Obj,
                                                integer(SBCContactTypeEnu:Customer))"}

      end. /* if available buV_BelegKopf then */

    end. /* if not can-find(bttV_BelegKopf-P2 */  
  
  end. /* if can-do('L,R':U,ttV_BelegPos-P.Belegart */

&ENDIF

end procedure. /* uFillOrderSection */


/* _UIB-CODE-BLOCK-END */
&ANALYZE-RESUME

&ENDIF


&IF DEFINED(EXCLUDE-uFillTimeWindowForDeliveryAddress) = 0 &THEN

&ANALYZE-SUSPEND _UIB-CODE-BLOCK _PROCEDURE uFillTimeWindowForDeliveryAddress Method-Library
procedure uFillTimeWindowForDeliveryAddress :
/* Description ---------------------------------------------------------------*/
/*                                                                            */
/* Fill time window for delivery address.                                     */
/*                                                                            */
/*----------------------------------------------------------------------------*/

&IF LOOKUP("U_CI":U,"{&PA-OPTIONEN}":U) > 0 &THEN

define buffer bUSM_CWLieferzeitfenster     for            USM_CWLieferzeitfenster.
define buffer bttUSM_CWLieferzeitfenster-P for temp-table ttUSM_CWLieferzeitfenster-P.


  if can-do('U,L,R,G':U,ttV_BelegKopf-P.BelegArt) then
  
  for each bUSM_CWLieferzeitfenster
    where bUSM_CWLieferzeitfenster.Owning_Obj = ttV_BelegKopf-P.V_BelegKopf_Obj
    no-lock:
  
    create bttUSM_CWLieferzeitfenster-P.
    {buffer-copy
       bUSM_CWLieferzeitfenster
       to bttUSM_CWLieferzeitfenster-P}
  
  end. /* end for each bUSM_CWLieferzeitfenster */

&ENDIF

end procedure. /* uFillTimeWindowForDeliveryAddress */


/* _UIB-CODE-BLOCK-END */
&ANALYZE-RESUME

&ENDIF

&IF DEFINED(EXCLUDE-uFillDeliveryScheduleDatesSection) = 0 &THEN

&ANALYZE-SUSPEND _UIB-CODE-BLOCK _PROCEDURE uFillDeliveryScheduleDatesSection Method-Library
procedure uFillDeliveryScheduleDatesSection :
/* Description ---------------------------------------------------------------*/
/*                                                                            */
/* Fill Delivery Plan Date (ULP) in case of U_CA usage                        */
/*                                                                            */
/*----------------------------------------------------------------------------*/

&IF LOOKUP("U_CA":U,"{&PA-OPTIONEN}":U) > 0 &THEN

define variable duQtyDelevered       like V_BelegPos.gelieferte_Menge    no-undo.
define variable duQtyOrdered         like V_BelegPos.beauftragte_Menge   no-undo.
define variable duRestQtyDelevered   like V_BelegPos.gelieferte_Menge    no-undo.
define variable duRestQtyOrdered     like V_BelegPos.beauftragte_Menge   no-undo.
define variable duQtyToBeOrdered     like V_BelegPos.beauftragte_Menge   no-undo.
define variable cuUnitDescription    like S_MengeneinheitSpr.KurzBez     no-undo.

define buffer bUVT_VersionsBOPosition       for UVT_VersionsBOPosition.
define buffer bUVT_DatesOfVersionsBOPos     for UVT_DatesOfVersionsBOPos.
define buffer bttUVT_DatesOfVersionsBOPos-P for temp-table ttUVT_DatesOfVersionsBOPos-P.

  if branche.vert.cls.UVCIndependentRequirementPlannungSvc:prpoInstance:cModificationInUse
       (ttV_BelegPos-P.V_BelegPos_Obj) <> 'U_CA':U then
    return.

  find bUVT_VersionsBOPosition
    where bUVT_VersionsBOPosition.V_BelegPos_Obj = ttV_BelegPos-P.V_BelegPos_Obj
      and bUVT_VersionsBOPosition.Version        = 1
    no-lock.  

  assign
    duRestQtyDelevered = ttV_BelegPos-P.gelieferte_Menge
    duRestQtyOrdered   = ttV_BelegPos-P.beauftragte_Menge
    cuUnitDescription  = {fnarg
                           pa_cQUnitShortDescLng
                           "ttV_BelegPos-P.Mengeneinheit,
                            1,
                            gcContentLanguage"}
    .

  for each bUVT_DatesOfVersionsBOPos
    where bUVT_DatesOfVersionsBOPos.UVT_VersionsBOPosition_Obj = bUVT_VersionsBOPosition.UVT_VersionsBOPosition_Obj
    no-lock:

    if duRestQtyDelevered = 0 then
      duQtyDelevered = 0.
    else
      if bUVT_DatesOfVersionsBOPos.Quantity >= duRestQtyDelevered then
        assign
          duQtyDelevered     = duRestQtyDelevered
          duRestQtyDelevered = 0
          .
      else
        assign
          duQtyDelevered     = bUVT_DatesOfVersionsBOPos.Quantity
          duRestQtyDelevered =   duRestQtyDelevered
                               - bUVT_DatesOfVersionsBOPos.Quantity
          .

    duQtyToBeOrdered =   bUVT_DatesOfVersionsBOPos.Quantity
                       - duQtyDelevered.

    if duRestQtyOrdered = 0 then
      duQtyOrdered = 0.
    else
      if duQtyToBeOrdered >= duRestQtyOrdered then
        assign
          duQtyOrdered     = duRestQtyOrdered
          duRestQtyOrdered = 0
          .
      else
        assign
          duQtyOrdered      = duQtyToBeOrdered
          duRestQtyOrdered  =   duRestQtyOrdered
                              - duQtyToBeOrdered
          .

    create bttUVT_DatesOfVersionsBOPos-P.
    {buffer-copy
       bUVT_DatesOfVersionsBOPos
       to bttUVT_DatesOfVersionsBOPos-P
       assign
         "bttUVT_DatesOfVersionsBOPos-P.OrderedQty    =   duQtyDelevered
                                                        / ttV_BelegPos-P.VME_Faktor
          bttUVT_DatesOfVersionsBOPos-P.DeliveredQty  =   duQtyOrdered
                                                        / ttV_BelegPos-P.VME_Faktor
          bttUVT_DatesOfVersionsBOPos-P.OpenQty       = (  bUVT_DatesOfVersionsBOPos.Quantity
                                                         - duQtyDelevered
                                                         - duQtyOrdered)
                                                        / ttV_BelegPos-P.VME_Faktor
          bttUVT_DatesOfVersionsBOPos-P.ShippingDate  =   bUVT_DatesOfVersionsBOPos.Date
                                                        + dynamic-function('pa_iCalendTransportTime':U in target-procedure, ttV_Belegpos-P.Firma, ttV_BelegKopf-P.Lagergruppe, ttV_BelegPos-P.Lagerort, ttV_Belegpos-P.uci_kommzeit, ttV_Belegpos-P.uci_kommzeiteinheit, bUVT_DatesOfVersionsBOPos.Date, yes)
          bttUVT_DatesOfVersionsBOPos-P.DeliveryDate  =   bttUVT_DatesOfVersionsBOPos-P.ShippingDate
                                                        + dynamic-function('pa_iCalendTransportTime':U in target-procedure, ttV_BelegPos-P.Firma, ttV_BelegKopf-P.Lagergruppe, ttV_BelegPos-P.Lagerort, ttV_BelegPos-P.transportzeit, ttV_BelegPos-P.zeiteinheit, bttUVT_DatesOfVersionsBOPos-P.ShippingDate, yes)
          bttUVT_DatesOfVersionsBOPos-P.CompletelyDel = (if duQtyDelevered = bUVT_DatesOfVersionsBOPos.Quantity then
                                                           yes
                                                         else
                                                           no)
          bttUVT_DatesOfVersionsBOPos-P.UnitDesc      = cuUnitDescription
          bttUVT_DatesOfVersionsBOPos-P.Owning_Obj    = ttV_Belegpos-P.V_Belegpos_Obj"}

  end. /* for each UVT_DatesOfVersionsBOPos */           

&ENDIF 

end procedure. /* uFillDeliveryScheduleDatesSection */

/* _UIB-CODE-BLOCK-END */
&ANALYZE-RESUME

&ENDIF

&IF DEFINED(EXCLUDE-uFillReservedOrdersSection) = 0 &THEN

&ANALYZE-SUSPEND _UIB-CODE-BLOCK _PROCEDURE uFillReservedOrdersSection Method-Library
procedure uFillReservedOrdersSection :
/* Description ---------------------------------------------------------------*/
/*                                                                            */
/* Fills Blanket Order: Ordered Orders (UBA)                                  */
/*                                                                            */
/*----------------------------------------------------------------------------*/

&IF LOOKUP("U_CA":U,"{&PA-OPTIONEN}":U) > 0 &THEN
define buffer buV_BelegKopf-U            for V_BelegKopf.
define buffer buV_Belegpos-U             for V_Belegpos.
define buffer bS_MengenEinheit           for S_MengenEinheit.
define buffer bttV_BelegPos-PBlankOrder  for temp-table ttV_BelegPos-P8.
define buffer bttV_BelegKopf-PBlankOrder for temp-table ttV_BelegKopf-P9.
define buffer bttS_MengenEinheit-PBOrder for temp-table ttS_MengenEinheit-PBOrder.

  for each buV_Belegpos-U
    where buV_Belegpos-U.Firma            = {firma/vbelegko.fir gcFirma}
      and buV_Belegpos-U.BelegArt         = 'U':U
      and buV_Belegpos-U.Herk_BelegArt    = ttV_Belegpos-P.BelegArt
      and buV_Belegpos-U.Herk_ReferenzNr  = ttV_Belegpos-P.ReferenzNr
      and buV_Belegpos-U.Herk_PositionsNr = ttV_Belegpos-P.PositionsNr
      and buV_Belegpos-U.offen            = yes
    no-lock:
  
    create bttV_BelegPos-PBlankOrder.
    {buffer-copy
       buV_Belegpos-U
       to bttV_BelegPos-PBlankOrder
       assign
         "bttV_BelegPos-PBlankOrder.Firma = gcFirma"}
  
    if not can-find (bttV_BelegKopf-PBlankOrder 
                       where bttV_BelegKopf-PBlankOrder.Firma      = gcFirma 
                         and bttV_BelegKopf-PBlankOrder.Belegart   = buV_Belegpos-U.BelegArt
                         and bttV_BelegKopf-PBlankOrder.ReferenzNr = buV_Belegpos-U.ReferenzNr) then   
    do:
  
      find buV_BelegKopf-U
        where buV_BelegKopf-U.Firma      = {firma/vbelegko.fir gcFirma}
          and buV_BelegKopf-U.BelegArt   = buV_Belegpos-U.BelegArt
          and buV_BelegKopf-U.ReferenzNr = buV_Belegpos-U.ReferenzNr
        no-lock.
  
      create bttV_BelegKopf-PBlankOrder.
      {buffer-copy
         buV_BelegKopf-U
         to bttV_BelegKopf-PBlankOrder
         assign
           "bttV_BelegKopf-PBlankOrder.Firma      = gcFirma
            bttV_BelegKopf-PBlankOrder.Empfaenger = VBCContactPersonSvc:prpoInstance:cGetContactPersonName
                                                      (buV_BelegKopf-U.V_BelegKopf_Obj,
                                                       integer(SBCContactTypeEnu:Customer))"}
  
    end. /* if not can-find (bttV_BelegPos-PBlankOrder */ 
  
    if not can-find(bttS_MengenEinheit-PBOrder
                      where bttS_MengenEinheit-PBOrder.Firma         = gcFirma
                        and bttS_MengenEinheit-PBOrder.MengenEinheit = buV_Belegpos-U.Mengeneinheit) then
    do:
  
      find bS_MengenEinheit
        where bS_MengenEinheit.Firma         = {firma/smngeinh.fir gcFirma}
          and bS_MengenEinheit.MengenEinheit = buV_Belegpos-U.Mengeneinheit
        no-lock no-error.
  
      if available bS_MengenEinheit then
      do:
  
        create bttS_MengenEinheit-PBOrder.
        {buffer-copy
           bS_MengenEinheit
           to bttS_MengenEinheit-PBOrder
           assign
             "bttS_MengenEinheit-PBOrder.Firma = gcFirma"}
  
      end. /* if available bS_MengenEinheit then */
  
    end. /* if not can-find(bttS_MengenEinheit-PBOrder */  
  
  end. /* for each buV_Belegpos-U */
&ENDIF 

end procedure. /* uFillReservedOrdersSection */


/* _UIB-CODE-BLOCK-END */
&ANALYZE-RESUME

&ENDIF

&ANALYZE-SUSPEND _UIB-CODE-BLOCK _PROCEDURE uFillUnloadingPoints Method-Library
procedure uFillUnloadingPoints :
/* Description ---------------------------------------------------------------*/
/*                                                                            */
/* Fill list of unloading points of a shipping document, proforma document or */
/* an invoice                                                                 */
/*                                                                            */
/*----------------------------------------------------------------------------*/

&IF LOOKUP("U_CA":U,"{&PA-OPTIONEN}":U) > 0 &THEN

  define variable cuHerk_Abruf         as character                     no-undo.
  define variable cuUnloadingPoint     as character                     no-undo.

  define buffer buV_BelegPos           for V_BelegPos.
  define buffer buVU_RA_Abruf          for VU_RA_Abruf.
  define buffer buV_BelegPos-Abr       for V_BelegPos.

  if can-do('L,R,VFP':U,ttV_BelegKopf-P.Belegart) then

    for each buV_BelegPos
      where buV_BelegPos.Firma        = {firma/vbelegko.fir gcFirma}
        and buV_BelegPos.BelegArt     = ttV_BelegKopf-P.BelegArt
        and buV_BelegPos.ReferenzNr   = ttV_BelegKopf-P.ReferenzNr
        and buV_BelegPos.Herk_Abruf  >= '':U
      no-lock
      on error undo, throw:

      cuHerk_Abruf = buV_BelegPos.Herk_Abruf.

      /* Abrufauftragsposition und Abruf laden */

      find buVU_RA_Abruf
        where buVU_RA_Abruf.Firma       = {firma/vbelegko.fir gcFirma}
          and buVU_RA_Abruf.Belegart    = entry(1,cuHerk_Abruf,{&PA-DELIMITER3})
          and buVU_RA_Abruf.ReferenzNr  = integer(entry(2,cuHerk_Abruf,{&PA-DELIMITER3}))
          and buVU_RA_Abruf.PositionsNr = integer(entry(3,cuHerk_Abruf,{&PA-DELIMITER3})) / 10
          and buVU_RA_Abruf.AbrufArt    = entry(4,cuHerk_Abruf,{&PA-DELIMITER3})
          and buVU_RA_Abruf.AbrufNr     = integer(entry(5,cuHerk_Abruf,{&PA-DELIMITER3}))
        no-lock no-error.

      if available buVU_RA_Abruf then
      do:

        find buV_BelegPos-Abr
          where buV_BelegPos-Abr.Firma        = ttV_BelegKopf-P.Firma
            and buV_BelegPos-Abr.BelegArt     = buVU_RA_Abruf.BelegArt
            and buV_BelegPos-Abr.ReferenzNr   = buVU_RA_Abruf.ReferenzNr
            and buV_BelegPos-Abr.LfdNr_SR     = 0
            and buV_BelegPos-Abr.PositionsNr  = buVU_RA_Abruf.PositionsNr
          no-lock.

        cuUnloadingPoint = cuUnloadingPoint
                             + (if cuUnloadingPoint > '':U then
                                  ',':U
                                else
                                  '':U)
                             + (if buVU_RA_Abruf.Lieferadresse = ? then
                                  buV_BelegPos-Abr.Abladestelle
                                else
                                  buVU_RA_Abruf.Abladestelle).

      end. /* if available buVU_RA_Abruf */

    end. /* for each buV_BelegPos */

    find {&pa_DR_DataProviderVariablesTT}
      where {&pa_DR_DataProviderVariablesTT}.VariableName = 'UnloadingPoint':U
      no-error.

    if available {&pa_DR_DataProviderVariablesTT} then
      {&pa_DR_DataProviderVariablesTT}.CharacterValue = cuUnloadingPoint.

&ENDIF /* U_CA */

end procedure. /* uFillUnloadingPoints */


/* _UIB-CODE-BLOCK-END */
&ANALYZE-RESUME


/* ************************  Function Implementations ***************** */

&IF DEFINED(EXCLUDE-lDocumentHasDifferentTaxKeys) = 0 &THEN

&ANALYZE-SUSPEND _UIB-CODE-BLOCK _FUNCTION lDocumentHasDifferentTaxKeys Method-Library
function lDocumentHasDifferentTaxKeys returns logical
  ( pdGesamt_Steuersatz like V_BelegKopf.Steuersatz,
    piH_TaxCode         like S_Steuer.Steuer extent 11,
    plP_TaxExtentUsed   as   logical         extent 11,
    pcI_P_S_Steuer_Obj  as   character       extent 11 ):
/* Description ---------------------------------------------------------------*/
/*                                                                            */
/* Check if different tax rates are available in the current document.        */
/* Because giSteuerSlot in v_belpow.p gives that because Zuschlag_Extent is   */
/* initialized with 1 if there is a Zuschlag or not, the default tax key is   */
/* written in Gesamt_Steuersatz[2]. Depending on if the tax key is changed and*/
/* to which tax key, Gesamt_Steuersatz[2] is used or not                      */
/* e.g. Italy, 1 pos with 0% -> Gesamt_Steuersatz[1] is used,                 */
/*                              Gesamt_Steuersatz[2] = 22, but not used       */
/* e.g. Italy, 1 pos with 22% -> Gesamt_Steuersatz[1] is not used,            */
/*                               Gesamt_Steuersatz[2] = 22, used              */
/* e.g. Italy, 2 pos with diff. 0% -> Gesamt_Steuersatz[1] = 0, used,         */
/*                                    Gesamt_Steuersatz[2] = 0, used          */
/* e.g. Italy, Pos 1 22%, Pos. 2 0% -> Gesamt_Steuersatz[1] = 0, used,        */
/*                                    Gesamt_Steuersatz[2] = 22, used         */
/* e.g. Pos 1 22%, Pos. 2 10% -> Gesamt_Steuersatz[1] = 10, used, of Pos. 2   */
/*                               Gesamt_Steuersatz[2] = 22, used, of Pos. 1   */
/* e.g. Pos 1 22%, Pos. 2 22% -> Gesamt_Steuersatz[1] = 10, not used,         */
/*                               Gesamt_Steuersatz[2] = 22, used, of Pos. 1+2 */
/* So it must be checked how many and which tax keys (0, non-0) are really used */
/*                                                                            */
/* Parameters ----------------------------------------------------------------*/
/*                                                                            */
/* pdGesamt_Steuersatz  member of temp-table defined in v__bel00.tdf          */
/* piH_TaxCode          member of temp-table defined in v__bel00.tdf          */
/* plP_TaxExtentUsed    member of temp-table defined in v__bel00.tdf          */
/* pcI_P_S_Steuer_Obj   member of temp-table defined in v__bel00.tdf          */
/*                                                                            */
/*----------------------------------------------------------------------------*/
define variable iTaxRatesCounter  as integer no-undo.
define variable iCounter          as integer no-undo.

/* only change for localization Italy (and later Poland/Hungary), 
   because for other contries the zero tax key topic is easy,
   because tax key is identical to tax rate  */
  if not can-do('I,P,H':U,pACConnectionSvc:prpcLocalization) then
  do:

    do iTaxRatesCounter = 2 to extent(pdGesamt_Steuersatz):
  
      /* in some countries several 0% tax keys can exist. the tax rate is 0 but the
         tax key has to be regarded separately  */
      if pdGesamt_Steuersatz[1] <> pdGesamt_Steuersatz[iTaxRatesCounter] then
        return yes.
          
    end. /* do iTaxRatesCounter = 1 to extent(pdGesamt_Steuersatz): */

    return no.
    
  end. /* if not can-do */  

  /* here can-do('I,P,H':U,pACConnectionSvc:prpcLocalization) */
  
  /* now check if there is a further tax key in the vector starting 3rd element */
  do iTaxRatesCounter = 1 to extent(pdGesamt_Steuersatz):

    if pdGesamt_Steuersatz[iTaxRatesCounter] > 0 then 

      iCounter = iCounter + 1.

    else
    do:

      if   lTaxKeyIsZeroTaxKey(pdGesamt_Steuersatz[iTaxRatesCounter],
                               piH_TaxCode[iTaxRatesCounter],
                               plP_TaxExtentUsed[iTaxRatesCounter],
                               pcI_P_S_Steuer_Obj[iTaxRatesCounter])
       /* this following condition does not work for Hungary ! */                               
       and can-find( first ttV_BelegPos-P
                       where ttV_BelegPos-P.SteuerSatz   = pdGesamt_Steuersatz[iTaxRatesCounter]
                         and ttV_BelegPos-P.S_Steuer_Obj = pcI_P_S_Steuer_Obj[iTaxRatesCounter]) then

       iCounter = iCounter + 1.

    end. /* else */

    if iCounter >= 2 then 
      return yes.
   
  end. /* do iTaxRatesCounter = 1 to extent(pdGesamt_Steuersatz): */
   
  return no.
  
end function.

/* _UIB-CODE-BLOCK-END */
&ANALYZE-RESUME

&ENDIF


&IF DEFINED(EXCLUDE-lIsI_P_HZeroTaxKey) = 0 &THEN

&ANALYZE-SUSPEND _UIB-CODE-BLOCK _FUNCTION lIsI_P_HZeroTaxKey Method-Library
function lIsI_P_HZeroTaxKey returns logical 
  ( piH_TaxCode        like S_Steuer.Steuer,
    plP_TaxExtentUsed  as   logical,
    pcI_P_S_Steuer_Obj as   character ):
/* Description ---------------------------------------------------------------*/
/*                                                                            */
/* returns yes if the tax key for the given piTaxIndex is a used tax key with 0% */
/*                                                                            */
/*----------------------------------------------------------------------------*/

  return    (    pACConnectionSvc:prpcLocalization = 'H':U
             and piH_TaxCode <> ?)
         or (    pACConnectionSvc:prpcLocalization  = 'P':U
             and plP_TaxExtentUsed  = yes)
         or (    pACConnectionSvc:prpcLocalization  = 'I':U
             and pcI_P_S_Steuer_Obj > '':U).

end function.

/* _UIB-CODE-BLOCK-END */
&ANALYZE-RESUME

&ENDIF


&IF DEFINED(EXCLUDE-lTaxKeyIsZeroTaxKey) = 0 &THEN

&ANALYZE-SUSPEND _UIB-CODE-BLOCK _FUNCTION lTaxKeyIsZeroTaxKey Method-Library
function lTaxKeyIsZeroTaxKey returns logical 
  ( pdGesamt_Steuersatz as   decimal,
    piH_TaxCode         like S_Steuer.Steuer,
    plP_TaxExtentUsed   as   logical,
    pcI_P_S_Steuer_Obj  as   character ):
/* Description ---------------------------------------------------------------*/
/*                                                                            */
/* returns yes if the tax key for the given piTaxIndex is a tax key with 0%   */
/* (and not only not used)                                                    */
/*                                                                            */
/*----------------------------------------------------------------------------*/

  return    pdGesamt_Steuersatz = 0
        and lIsI_P_HZeroTaxKey(piH_TaxCode, plP_TaxExtentUsed, pcI_P_S_Steuer_Obj).
    
end function.

/* _UIB-CODE-BLOCK-END */
&ANALYZE-RESUME

&ENDIF
