&ANALYZE-SUSPEND _VERSION-NUMBER UIB_v8r2 GUI
&ANALYZE-RESUME

&ANALYZE-SUSPEND _UIB-CODE-BLOCK _CUSTOM _DECLARATIONS V-table-Win 

/* _UIB-CODE-BLOCK-END */
&ANALYZE-RESUME


&ANALYZE-SUSPEND _UIB-CODE-BLOCK _XFTR "Update Information" Procedure _INLINE
/* Actions: ? ? ? ? adm/support/proc/ds_pa_01.w */

/* _UIB-CODE-BLOCK-END */
&ANALYZE-RESUME

&ANALYZE-SUSPEND _UIB-CODE-BLOCK _CUSTOM _DEFINITIONS Procedure
/******************************************************************************/
/* @COPYRIGHT@                                                                */
/* Project: Proalpha                                                          */
/*                                                                            */
/* Name   : fojopi00.p                                                        */
/* Product: FIBU - Finanzwesen                                                */
/* Module : OP - OP-Verwaltung                                                */
/*                                                                            */
/* Created: 6.2d01 as of 12.01.2017/Peter Demmerle                            */
/* Current: @PAVERSION@ as of @PADATE@/@PALASTAUTHOR@                         */
/*                                                                            */
/*----------------------------------------------------------------------------*/
/* DESCRIPTION                                                                */
/*----------------------------------------------------------------------------*/
/*                                                                            */
/* Print Open Items (FOOPLN) (Data Access Object)                             */
/*                                                                            */
/*----------------------------------------------------------------------------*/
/* PARAMETERS                                                                 */
/*----------------------------------------------------------------------------*/
/* Name                      Description                                      */
/*----------------------------------------------------------------------------*/
/*                                                                            */
/*----------------------------------------------------------------------------*/
/* HISTORY                                                                    */
/*----------------------------------------------------------------------------*/
/* @FILEHISTORY@                                                              */
/******************************************************************************/

/* Procedure Information -----------------------------------------------------*/

&GLOBAL-DEFINE pa-Autor             Peter Demmerle
&GLOBAL-DEFINE pa-Version           @PAVERSION@
&GLOBAL-DEFINE pa-Datum             @PADATE@
&GLOBAL-DEFINE pa-Letzter           @PALASTAUTHOR@

&GLOBAL-DEFINE pa-GenVersion       OEA
&GLOBAL-DEFINE pa-ProgrammTyp      DataAccessObject
&GLOBAL-DEFINE pa-Template         padataaccessobject.pjet
&GLOBAL-DEFINE pa-TemplateVersion  3.00
&GLOBAL-DEFINE pa-XBasisName       fojopi00_p
&GLOBAL-DEFINE pa-NameSpace        2.00

/*----------------------------------------------------------------------------*/
/* Definitions                                                                */
/*----------------------------------------------------------------------------*/

/* Parameters ----------------------------------------------------------------*/

/* Globals -------------------------------------------------------------------*/

{adm/template/incl/dt_dao00.df}

{fibu/base/incl/fm_fac00.tdf &ippNoReferenceOnlySwitch = "YES"}  /* ttFMM_Factor */

&GLOBAL-DEFINE S_KontenArt_alle         'alle Konten,Debitoren,Kreditoren,Sachkonten,Personenkonten':U
&GLOBAL-DEFINE S_KontenArt_alle_keys    'A,D,K,S,P':U

/* SCOPEDs -------------------------------------------------------------------*/

/* Datasets ------------------------------------------------------------------*/

/* must be in front of variables because of buffer definitions                */

{fibu/op/incl/fo_opi00.pds} /* dsFO_OpenItems-P */

/* Variables -----------------------------------------------------------------*/
/*                                                                            */
/*----------------------------------------------------------------------------*/

{fibu/op/incl/fonoic00.df}

/* Buffers -------------------------------------------------------------------*/


/* _UIB-CODE-BLOCK-END */
&ANALYZE-RESUME


&ANALYZE-SUSPEND _UIB-PREPROCESSOR-BLOCK

/* ********************  Preprocessor Definitions  ******************** */

&Scoped-define PROCEDURE-TYPE Procedure
&Scoped-define DB-AWARE no



/* _UIB-PREPROCESSOR-BLOCK-END */
&ANALYZE-RESUME

/* ************************  Function Prototypes ********************** */
/* *********************** Procedure Settings ************************ */

&ANALYZE-SUSPEND _PROCEDURE-SETTINGS
/* Settings for THIS-PROCEDURE
   Type: Procedure
   Allow:
   Frames: 0
   Add Fields to: Neither
   Other Settings: CODE-ONLY
 */
&ANALYZE-RESUME _END-PROCEDURE-SETTINGS

/* *************************  Create Window  ************************** */

&ANALYZE-SUSPEND _CREATE-WINDOW
/* DESIGN Window definition (used by the UIB)
  CREATE WINDOW Procedure ASSIGN
         HEIGHT             = 6.95
         WIDTH              = 50.4.
/* END WINDOW DEFINITION */
                                                                        */
&ANALYZE-RESUME

&ANALYZE-SUSPEND _UIB-CODE-BLOCK _CUSTOM _INCLUDED-LIB Procedure
/* ************************* Included-Libraries *********************** */

{adm/method/incl/dm_dao00.lib}
{fibu/buch/incl/fbdribi0.lib}
{fibu/op/incl/fonoic00.lib}

/* _UIB-CODE-BLOCK-END */
&ANALYZE-RESUME




&ANALYZE-SUSPEND _UIB-CODE-BLOCK _CUSTOM _MAIN-BLOCK Procedure


/* ***************************  Main Block  *************************** */

/*----------------------------------------------------------------------------*/
/* Processing                                                                 */
/*----------------------------------------------------------------------------*/

/* _UIB-CODE-BLOCK-END */
&ANALYZE-RESUME




/* **********************  Internal Procedures  *********************** */

&IF DEFINED(EXCLUDE-fillDataset) = 0 &THEN

&ANALYZE-SUSPEND _UIB-CODE-BLOCK _PROCEDURE fillDataset Method-Library 
procedure fillDataset :
/* Description ---------------------------------------------------------------*/
/*                                                                            */
/* Fill dataset                                                               */
/*                                                                            */
/* Notes ---------------------------------------------------------------------*/
/*                                                                            */
/*                                                                            */
/*                                                                            */
/* Parameters ----------------------------------------------------------------*/
/*                                                                            */
/* dsFO_OpenItems-P     dataset                                               */
/*                                                                            */
/* Examples ------------------------------------------------------------------*/
/*                                                                            */
/*                                                                            */
/*                                                                            */
/*----------------------------------------------------------------------------*/

define input-output parameter dataset for dsFO_OpenItems-P.

/* Variables -----------------------------------------------------------------*/
/* cContentLanguage     content language                                      */
/* cPKS                 parameter string                                      */
/* cCompany             company                                               */
/* iCounterOI           counter active AND inactive open items                */
/* iCounterValuation    counter for find FO_OP_Bewert                         */
/* iCounterOPAdr        counter for synthetic open item address-numbers;      */
/*                      counting backwards (negative) to avoid a collision    */
/*                      with real S_Adress.AdressNr!                          */
/*----------------------------------------------------------------------------*/

define variable cContentLanguage  as character                          no-undo.
define variable cPKS              as character                          no-undo.
define variable cCompany          as character                          no-undo.

/* Buffers -------------------------------------------------------------------*/

/* --> MO#SCHW-ALZ-0061 thongdi.p 14/07/2026 List&Label OP-Liste Auftragsart Kostentr�ger */
define buffer bV_BelegKopf          for V_BelegKopf.
define buffer bFB_Buchung           for FB_Buchung.
define buffer bS_AuftragsArtSpr     for S_AuftragsArtSpr.
define buffer bS_KoTraeger          for S_KoTraeger.
define buffer bDBM_ShortDescription for DBM_ShortDescription.
/* <-- MO#SCHW-ALZ-0061 thongdi.p 14/07/2026 List&Label OP-Liste Auftragsart Kostentr�ger */

/*----------------------------------------------------------------------------*/
/* Processing                                                                 */
/*----------------------------------------------------------------------------*/

/* create default data records when starting the List & Label designer        */

{&{&pa-XBasisName}_C_FillDatasetStart}
{&{&pa-XBasisName}_U_FillDatasetStart}
{&{&pa-XBasisName}_Q_FillDatasetStart}
{&{&pa-XBasisName}_FillDatasetStart}
{&{&pa-XBasisName}_Y_FillDatasetStart}

if adm.method.cls.DMCSessionSvc:cGetObjectProperty
     (dataset dsFO_OpenItems-P:handle,
      'FillMode':U) = 'LLConfig':U then

  adm.repos.cls.DRCDataProviderSvc:prpoInstance:generateDummyRecords
    (dataset dsFO_OpenItems-P:get-top-buffer(1)).

else
do:

  assign
    cContentLanguage         = adm.method.cls.DMCSessionSvc:cGetObjectProperty
                                 (dataset dsFO_OpenItems-P:handle,
                                  'ContentLanguage':U)
    cPKS                     = adm.method.cls.DMCSessionSvc:cGetObjectPropertyPKS
                                 (dataset dsFO_OpenItems-P:handle,
                                  'Context':U)
    cCompany                 = pACConnectionSvc:prpcCompany
    .

  run ReadParameterValues in target-procedure (cPKS).

  /* fill variables                                                           */

  find {&pa_DR_DataProviderVariablesTT}
    where {&pa_DR_DataProviderVariablesTT}.VariableName = 'AccountCategory':U.

  {&pa_DR_DataProviderVariablesTT}.CharacterValue
    = adm.base.cls.DBCTranslateSvc:prpoInstance:cTryTranslateTerm
        (entry(lookup(gcAccountCategory,{&S_KontenArt_alle_keys}),{&S_KontenArt_alle}),
         'D':U,
         cContentLanguage,
         20).

  find {&pa_DR_DataProviderVariablesTT}
    where {&pa_DR_DataProviderVariablesTT}.VariableName = 'PaymentHold':U.

  {&pa_DR_DataProviderVariablesTT}.CharacterValue = adm.base.cls.DBCTranslateSvc:prpoInstance:cTryTranslateTerm
                                                      (gcPaymentHold, /* ja, nein, alle */
                                                       'D':U,
                                                       cContentLanguage,
                                                       8).

  find {&pa_DR_DataProviderVariablesTT}
    where {&pa_DR_DataProviderVariablesTT}.VariableName = 'Exempt':U.

  {&pa_DR_DataProviderVariablesTT}.CharacterValue = adm.base.cls.DBCTranslateSvc:prpoInstance:cTryTranslateTerm
                                                      (gcExempt, /* ja, nein, alle */
                                                       'D':U,
                                                       cContentLanguage,
                                                       8).

  find {&pa_DR_DataProviderVariablesTT}
    where {&pa_DR_DataProviderVariablesTT}.VariableName = 'DueDate1':U.

  {&pa_DR_DataProviderVariablesTT}.DateValue = gtDueDate1.

  find {&pa_DR_DataProviderVariablesTT}
    where {&pa_DR_DataProviderVariablesTT}.VariableName = 'DueDate2':U.

  {&pa_DR_DataProviderVariablesTT}.DateValue = gtDueDate2.

  find {&pa_DR_DataProviderVariablesTT}
    where {&pa_DR_DataProviderVariablesTT}.VariableName = 'DueDate3':U.

  {&pa_DR_DataProviderVariablesTT}.DateValue = gtDueDate3.

  find {&pa_DR_DataProviderVariablesTT}
    where {&pa_DR_DataProviderVariablesTT}.VariableName = 'DueDate4':U.

  {&pa_DR_DataProviderVariablesTT}.DateValue = gtDueDate4.

  find {&pa_DR_DataProviderVariablesTT}
    where {&pa_DR_DataProviderVariablesTT}.VariableName = 'DueDate5':U.

  {&pa_DR_DataProviderVariablesTT}.DateValue = gtDueDate5.

  find {&pa_DR_DataProviderVariablesTT}
    where {&pa_DR_DataProviderVariablesTT}.VariableName = 'DueDate6':U.

  {&pa_DR_DataProviderVariablesTT}.DateValue = gtDueDate6.

  find {&pa_DR_DataProviderVariablesTT}
    where {&pa_DR_DataProviderVariablesTT}.VariableName = 'DueDate7':U.

  {&pa_DR_DataProviderVariablesTT}.DateValue = gtDueDate7.

  find {&pa_DR_DataProviderVariablesTT}
    where {&pa_DR_DataProviderVariablesTT}.VariableName = 'BusinessPartnerOI':U.

  {&pa_DR_DataProviderVariablesTT}.LogicalValue = glBusinessPartnerOI.

  find {&pa_DR_DataProviderVariablesTT}
    where {&pa_DR_DataProviderVariablesTT}.VariableName = 'DebCrdtrCredDbtr':U.

  {&pa_DR_DataProviderVariablesTT}.LogicalValue = glDebCrdtrCredDbtr.

  find {&pa_DR_DataProviderVariablesTT}
    where {&pa_DR_DataProviderVariablesTT}.VariableName = 'WithHistory':U.

  {&pa_DR_DataProviderVariablesTT}.LogicalValue = glWithHistory.

  find {&pa_DR_DataProviderVariablesTT}
    where {&pa_DR_DataProviderVariablesTT}.VariableName = 'ByAssociation':U.

  {&pa_DR_DataProviderVariablesTT}.LogicalValue = glByAssociation.

  find {&pa_DR_DataProviderVariablesTT}
    where {&pa_DR_DataProviderVariablesTT}.VariableName = 'WithoutAssociation':U.

  {&pa_DR_DataProviderVariablesTT}.LogicalValue = glWithoutAssociation.

  find {&pa_DR_DataProviderVariablesTT}
    where {&pa_DR_DataProviderVariablesTT}.VariableName = 'ImplementationReport':U.

  {&pa_DR_DataProviderVariablesTT}.LogicalValue = glImplementationReport.

  find {&pa_DR_DataProviderVariablesTT}
    where {&pa_DR_DataProviderVariablesTT}.VariableName = 'AsOfDate':U.

  {&pa_DR_DataProviderVariablesTT}.DateValue = gtAsOfDate.

  find {&pa_DR_DataProviderVariablesTT}
    where {&pa_DR_DataProviderVariablesTT}.VariableName = 'VariableAgingStructure':U.

  {&pa_DR_DataProviderVariablesTT}.LogicalValue = glVariableAgingStructure.

  find {&pa_DR_DataProviderVariablesTT}
    where {&pa_DR_DataProviderVariablesTT}.VariableName = 'Association':U.

  {&pa_DR_DataProviderVariablesTT}.IntegerValue = giAssociation.

  find {&pa_DR_DataProviderVariablesTT}
    where {&pa_DR_DataProviderVariablesTT}.VariableName = 'ForAsOfDate':U.

  {&pa_DR_DataProviderVariablesTT}.LogicalValue = glForAsOfDate.

  find {&pa_DR_DataProviderVariablesTT}
    where {&pa_DR_DataProviderVariablesTT}.VariableName = 'FiscalYear':U.

  {&pa_DR_DataProviderVariablesTT}.DecimalValue = gdFiscalYear.

  find {&pa_DR_DataProviderVariablesTT}
    where {&pa_DR_DataProviderVariablesTT}.VariableName = 'ForPeriod':U.

  {&pa_DR_DataProviderVariablesTT}.LogicalValue = glForPeriod.

  find {&pa_DR_DataProviderVariablesTT}
    where {&pa_DR_DataProviderVariablesTT}.VariableName = 'PostingPeriod':U.

  {&pa_DR_DataProviderVariablesTT}.IntegerValue = giPostingPeriod.

  find {&pa_DR_DataProviderVariablesTT}
    where {&pa_DR_DataProviderVariablesTT}.VariableName = 'PartPmtInvoice':U.

  {&pa_DR_DataProviderVariablesTT}.LogicalValue = glPartPmtInvoice.

  find {&pa_DR_DataProviderVariablesTT}
    where {&pa_DR_DataProviderVariablesTT}.VariableName = 'WithoutPartPmtInvoice':U.

  {&pa_DR_DataProviderVariablesTT}.LogicalValue = glWithoutPartPmtInvoice.

  find {&pa_DR_DataProviderVariablesTT}
    where {&pa_DR_DataProviderVariablesTT}.VariableName = 'PostingsFilter':U.

  {&pa_DR_DataProviderVariablesTT}.LogicalValue = glPostingsFilter.

  find {&pa_DR_DataProviderVariablesTT}
    where {&pa_DR_DataProviderVariablesTT}.VariableName = 'CustSuppFilter':U.

  {&pa_DR_DataProviderVariablesTT}.LogicalValue = glCustSuppFilter.

  find {&pa_DR_DataProviderVariablesTT}
    where {&pa_DR_DataProviderVariablesTT}.VariableName = 'AddressFilter':U.

  {&pa_DR_DataProviderVariablesTT}.LogicalValue = glAddressFilter.

  find {&pa_DR_DataProviderVariablesTT}
    where {&pa_DR_DataProviderVariablesTT}.VariableName = 'OpenItemsFilter':U.

  {&pa_DR_DataProviderVariablesTT}.LogicalValue = glOpenItemsFilter.
  
  if pACConnectionSvc:prpcLocalization = 'H':U then
  do:

    find {&pa_DR_DataProviderVariablesTT}
      where {&pa_DR_DataProviderVariablesTT}.VariableName = 'H_CashFlowPrinciple':U.

    {&pa_DR_DataProviderVariablesTT}.LogicalValue = glHCashFlowPrinciple.

  end. /* if pACConnectionSvc:prpcLocalization = 'H':U then */

  /* collect data                                                             */

  run FIllDatasetOIData in target-procedure (cContentLanguage).
  
  /* --> MO#SCHW-ALZ-0061 thongdi.p 14/07/2026 List&Label OP-Liste Auftragsart Kostentr�ger */
  for each ttFO_OP-P 
    exclusive-lock:
  
    find bFB_Buchung
      where bFB_Buchung.FB_Buchung_Obj = ttFO_OP-P.FB_Buchung_Obj
      no-lock no-error.
      
    if available bFB_Buchung then
    do:
      find bV_BelegKopf
        where bV_BelegKopf.Firma      = {firma/vbelegko.fir pACConnectionSvc:prpcCompany}
          and bV_BelegKopf.BelegArt   = bFB_Buchung.Herk_BelegArt
          and bV_BelegKopf.ReferenzNr = bFB_Buchung.Herk_ReferenzNr
        no-lock no-error.
      
      if available bV_BelegKopf then
      do:       
        assign 
          ttFO_OP-P.xAuftragsart = bV_BelegKopf.Auftragsart
          .
        
        find bS_AuftragsArtSpr 
          where bS_AuftragsArtSpr.Firma       = {firma/saufart.fir pACConnectionSvc:prpcCompany}
            and bS_AuftragsArtSpr.Auftragsart = bV_BelegKopf.Auftragsart
          no-lock no-error.
            
        if available bS_AuftragsArtSpr then
        do:
          assign 
            ttFO_OP-P.xAuftragsartBez = bS_AuftragsArtSpr.Bezeichnung
            .

          find bS_KoTraeger 
            where bS_KoTraeger.S_KoTraeger_Obj = bV_BelegKopf.Driver_Obj
            no-lock no-error.
            
          if available bS_KoTraeger then
          do:
            assign 
              ttFO_OP-P.xKostentraeger = bS_KoTraeger.KostenTraeger
              .
              
            find bDBM_ShortDescription 
              where bDBM_ShortDescription.Owning_Obj = bS_KoTraeger.S_KoTraeger_Obj

              no-lock no-error.
              
            if available bDBM_ShortDescription then
              assign 
                ttFO_OP-P.xKostentraegerBez = bDBM_ShortDescription.ShortDesc1
                .
          end. /* if available bS_KoTraeger */
        end. /* if available bS_AuftragsArtSpr */
      end. /* if available bV_BelegKopf */      
    end. /* if available bFB_Buchung */  
  end. /* for each ttFO_OP-P */
  
  /* <-- MO#SCHW-ALZ-0061 thongdi.p 14/07/2026 List&Label OP-Liste Auftragsart Kostentr�ger */
  
  if pACConnectionSvc:prpcLocalization = 'I':U then
  do:

    find {&pa_DR_DataProviderVariablesTT}
      where {&pa_DR_DataProviderVariablesTT}.VariableName = 'I_GrandTotalRIBAAmount':U.

    {&pa_DR_DataProviderVariablesTT}.DecimalValue = gdIGrandTotalRIBAAmount.

  end. /* if pACConnectionSvc:prpcLocalization = 'I':U then */

end. /* else (if adm.method.cls.DMCSessionSvc:cGetObjectProperty) */

{&{&pa-XBasisName}_C_FillDatasetEnd}
{&{&pa-XBasisName}_U_FillDatasetEnd}
{&{&pa-XBasisName}_Q_FillDatasetEnd}
{&{&pa-XBasisName}_FillDatasetEnd}
{&{&pa-XBasisName}_Y_FillDatasetEnd}

end procedure. /* fillDataset */


/* _UIB-CODE-BLOCK-END */
&ANALYZE-RESUME

&ENDIF


/* ************************  Function Implementations ***************** */

