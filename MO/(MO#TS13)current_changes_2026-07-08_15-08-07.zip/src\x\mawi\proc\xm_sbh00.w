&ANALYZE-SUSPEND _VERSION-NUMBER UIB_v8r12 GUI
&ANALYZE-RESUME
&Scoped-define WINDOW-NAME CURRENT-WINDOW
&Scoped-define FRAME-NAME Dialog-Frame

&ANALYZE-SUSPEND _UIB-CODE-BLOCK _CUSTOM _DECLARATIONS Dialog-Frame 

/* _UIB-CODE-BLOCK-END */
&ANALYZE-RESUME


&ANALYZE-SUSPEND _UIB-CODE-BLOCK _XFTR "Update Information" Dialog-Frame _INLINE
/* Actions: ? ? ? ? adm/support/proc/ds_pa_01.w */

/* _UIB-CODE-BLOCK-END */
&ANALYZE-RESUME

&ANALYZE-SUSPEND _UIB-CODE-BLOCK _CUSTOM _DEFINITIONS Dialog-Frame 
/******************************************************************************/
/* @COPYRIGHT@                                                                */
/* Project: Proalpha                                                          */
/*                                                                            */
/* Name   : xm_sbh00.w                                                        */
/* Product: X            - Individualanpassungen extern                       */
/* Module : MAWI         - Materialwirtschaft                                 */
/*                                                                            */
/* Created: 9.5 as of 06.07.2026/thongdi_p                                    */
/* Current: @PAVERSION@ as of @PADATE@/@PALASTAUTHOR@                         */
/*                                                                            */
/*----------------------------------------------------------------------------*/
/* DESCRIPTION                                                                */
/*----------------------------------------------------------------------------*/
/*                                                                            */
/* Dialog for Meterial (Vorlauf)                                              */
/*                                                                            */
/*----------------------------------------------------------------------------*/
/* PARAMETERS                                                                 */
/*----------------------------------------------------------------------------*/
/* Name                      Description                                      */
/*----------------------------------------------------------------------------*/
/*                                                                            */
/*----------------------------------------------------------------------------*/
/* HISTORY                                                                    */
/*----------------------------------------------------------------------------*/
/* @FILEHISTORY@                                                              */
/******************************************************************************/

create widget-pool.

/* Procedure Information -----------------------------------------------------*/

&GLOBAL-DEFINE pa-Autor            thongdi_p
&GLOBAL-DEFINE pa-Version          @PAVERSION@
&GLOBAL-DEFINE pa-Datum            @PADATE@
&GLOBAL-DEFINE pa-Letzter          @PALASTAUTHOR@

&GLOBAL-DEFINE pa-GenVersion       UIB
&GLOBAL-DEFINE pa-ProgrammTyp      PrintDialog
&GLOBAL-DEFINE pa-Template         adm/template/dt_dlg02.w
&GLOBAL-DEFINE pa-TemplateVersion  3.01
&GLOBAL-DEFINE pa-XBasisName       xm_sbh00_w
&GLOBAL-DEFINE pa-NameSpace        2.10
&GLOBAL-DEFINE pa-ZielProgramm 'bjvjob02.p#XMCStockCalculateJob':U

/* Parameters ----------------------------------------------------------------*/

/* Globals -------------------------------------------------------------------*/

{adm/template/incl/dt_dlg01.df}

/* SCOPEDs -------------------------------------------------------------------*/

&GLOBAL-DEFINE pa-WflArea
&GLOBAL-DEFINE pa-WflCompany

/* Variables -----------------------------------------------------------------*/
/*----------------------------------------------------------------------------*/

/* Buffers -------------------------------------------------------------------*/

/* _UIB-CODE-BLOCK-END */
&ANALYZE-RESUME


&ANALYZE-SUSPEND _UIB-PREPROCESSOR-BLOCK 

/* ********************  Preprocessor Definitions  ******************** */

&Scoped-define PROCEDURE-TYPE DIALOG-BOX
&Scoped-define DB-AWARE no

/* Name of designated FRAME-NAME and/or first browse and/or first query */
&Scoped-define FRAME-NAME Dialog-Frame

/* Standard List Definitions                                            */
&Scoped-Define ENABLED-OBJECTS Artikel_min Artikel_max ArtikelArt_min ~
ArtikelArt_max ArtikelGruppe_min ArtikelGruppe_max DispoGruppe_min ~
DispoGruppe_max Lagergruppe_min Lagergruppe_max RADIO-SET-1 Btn_Start ~
Btn_Cancel 
&Scoped-Define DISPLAYED-OBJECTS Artikel_min Artikel_max ArtikelArt_min ~
ArtikelArt_max ArtikelGruppe_min ArtikelGruppe_max DispoGruppe_min ~
DispoGruppe_max Lagergruppe_min Lagergruppe_max RADIO-SET-1 c_von c_bis 

/* Custom List Definitions                                              */
/* pa-YearFields,pa-ResetFields,List-3,List-4,List-5,List-6             */

/* _UIB-PREPROCESSOR-BLOCK-END */
&ANALYZE-RESUME


&ANALYZE-SUSPEND _UIB-CODE-BLOCK _XFTR "InfoFields" Dialog-Frame _INLINE
/* Actions: ? ? ? ? adm/support/proc/ds_inf01.p */
/* STRUCTURED-DATA
<Build-Information>
1.02
</Build-Information>
<Constants></Constants>
<InfoFields></InfoFields> */
/* _UIB-CODE-BLOCK-END */
&ANALYZE-RESUME

&ANALYZE-SUSPEND _UIB-CODE-BLOCK _XFTR "Dynamic InfoFields" Dialog-Frame _INLINE
/* Actions: ? ? ? ? adm/support/proc/ds_viw09.p */
/* _UIB-CODE-BLOCK-END */
&ANALYZE-RESUME

&ANALYZE-SUSPEND _UIB-CODE-BLOCK _XFTR "FieldDefinitions" Dialog-Frame _INLINE
/* Actions: ? ? ? ? adm/support/proc/ds_dlg01.p */
/* STRUCTURED-DATA
<DATA></DATA>
<FRAME>
****/
define frame f_dummy
with side-labels width 255 stream-io.
/****
</FRAME> */
/* _UIB-CODE-BLOCK-END */
&ANALYZE-RESUME

&ANALYZE-SUSPEND _UIB-CODE-BLOCK _XFTR "Skin Client Support" Dialog-Frame _INLINE
/* Actions: ? ? ? ? adm/support/proc/ds_skc00.p */
/* _UIB-CODE-BLOCK-END */
&ANALYZE-RESUME


/* ***********************  Control Definitions  ********************** */

/* Define a dialog box                                                  */

/* Definitions of the field level widgets                               */
DEFINE BUTTON Btn_Cancel AUTO-END-KEY 
     LABEL "Abbruch":T8 
     SIZE 12 BY 1.

DEFINE BUTTON Btn_Start AUTO-GO 
     LABEL "OK":T8 
     SIZE 12 BY 1.

DEFINE VARIABLE Artikel_max AS CHARACTER FORMAT "x(20)":U 
     VIEW-AS FILL-IN 
     SIZE 24 BY 1 NO-UNDO.

DEFINE VARIABLE Artikel_min AS CHARACTER FORMAT "x(20)":U 
     LABEL "Teil":R18 
     VIEW-AS FILL-IN 
     SIZE 24 BY 1 NO-UNDO.

DEFINE VARIABLE ArtikelArt_max AS INTEGER FORMAT "z9":U INITIAL 0 
     VIEW-AS FILL-IN 
     SIZE 5 BY 1 NO-UNDO.

DEFINE VARIABLE ArtikelArt_min AS INTEGER FORMAT "z9":U INITIAL 0 
     LABEL "Teileart":R18 
     VIEW-AS FILL-IN 
     SIZE 5 BY 1 NO-UNDO.

DEFINE VARIABLE ArtikelGruppe_max AS CHARACTER FORMAT "x(6)":U 
     VIEW-AS FILL-IN 
     SIZE 12 BY 1 NO-UNDO.

DEFINE VARIABLE ArtikelGruppe_min AS CHARACTER FORMAT "x(6)":U 
     LABEL "Teilegruppe":R18 
     VIEW-AS FILL-IN 
     SIZE 12 BY 1 NO-UNDO.

DEFINE VARIABLE c_bis AS CHARACTER FORMAT "X(256)":U 
      VIEW-AS TEXT 
     SIZE 14 BY .63 NO-UNDO.

DEFINE VARIABLE c_von AS CHARACTER FORMAT "X(256)":U 
      VIEW-AS TEXT 
     SIZE 14 BY .63 NO-UNDO.

DEFINE VARIABLE DispoGruppe_max AS CHARACTER FORMAT "x(6)":U 
     VIEW-AS FILL-IN 
     SIZE 12 BY 1 NO-UNDO.

DEFINE VARIABLE DispoGruppe_min AS CHARACTER FORMAT "x(6)":U 
     LABEL "Dispositionsgruppe":R18 
     VIEW-AS FILL-IN 
     SIZE 12 BY 1 NO-UNDO.

DEFINE VARIABLE Lagergruppe_max AS INTEGER FORMAT "zzzzzzz9":U INITIAL 0 
     VIEW-AS FILL-IN 
     SIZE 12 BY 1 NO-UNDO.

DEFINE VARIABLE Lagergruppe_min AS INTEGER FORMAT "zzzzzzz9":U INITIAL 0 
     LABEL "Dispobereich":R18 
     VIEW-AS FILL-IN 
     SIZE 12 BY 1 NO-UNDO.

DEFINE VARIABLE RADIO-SET-1 AS INTEGER 
     VIEW-AS RADIO-SET VERTICAL
     RADIO-BUTTONS 
          "alle", 1,
"nur mit autom Sicherheitsbestandsubernahme", 2,
"nur ohne autom Sicherheitsbestandsubernahme", 3
     SIZE 49 BY 3 NO-UNDO.


/* ************************  Frame Definitions  *********************** */

DEFINE FRAME Dialog-Frame
     Artikel_min AT ROW 2.5 COL 21 COLON-ALIGNED
     Artikel_max AT ROW 2.5 COL 59 COLON-ALIGNED NO-LABEL
     ArtikelArt_min AT ROW 3.5 COL 21 COLON-ALIGNED
     ArtikelArt_max AT ROW 3.5 COL 59 COLON-ALIGNED NO-LABEL
     ArtikelGruppe_min AT ROW 4.5 COL 21 COLON-ALIGNED
     ArtikelGruppe_max AT ROW 4.5 COL 59 COLON-ALIGNED NO-LABEL
     DispoGruppe_min AT ROW 5.5 COL 21 COLON-ALIGNED
     DispoGruppe_max AT ROW 5.5 COL 59 COLON-ALIGNED NO-LABEL
     Lagergruppe_min AT ROW 6.5 COL 21 COLON-ALIGNED
     Lagergruppe_max AT ROW 6.5 COL 59 COLON-ALIGNED NO-LABEL
     RADIO-SET-1 AT ROW 7.5 COL 23.5 NO-LABEL
     Btn_Start AT ROW 11 COL 3
     Btn_Cancel AT ROW 11 COL 16
     c_von AT ROW 1.5 COL 21 COLON-ALIGNED NO-LABEL
     c_bis AT ROW 1.5 COL 59 COLON-ALIGNED NO-LABEL
     SPACE(17.16) SKIP(10.24)
    WITH VIEW-AS DIALOG-BOX KEEP-TAB-ORDER 
         SIDE-LABELS NO-UNDERLINE THREE-D  SCROLLABLE 
         TITLE "Sicherheitsbestande berechnen":T60
         DEFAULT-BUTTON Btn_Start CANCEL-BUTTON Btn_Cancel.


/* *********************** Procedure Settings ************************ */

&ANALYZE-SUSPEND _PROCEDURE-SETTINGS
/* Settings for THIS-PROCEDURE
   Type: DIALOG-BOX
   Allow: Basic,DB-Fields
 */
&ANALYZE-RESUME _END-PROCEDURE-SETTINGS

&ANALYZE-SUSPEND _UIB-CODE-BLOCK _CUSTOM _INCLUDED-LIB Dialog-Frame 
/* ************************* Included-Libraries *********************** */

{adm/method/incl/dm_dlg00.lib}

/* _UIB-CODE-BLOCK-END */
&ANALYZE-RESUME




/* ***********  Runtime Attributes and AppBuilder Settings  *********** */

&ANALYZE-SUSPEND _RUN-TIME-ATTRIBUTES
/* SETTINGS FOR DIALOG-BOX Dialog-Frame
   FRAME-NAME L-To-R                                                    */
ASSIGN 
       FRAME Dialog-Frame:SCROLLABLE       = FALSE
       FRAME Dialog-Frame:HIDDEN           = TRUE.

/* SETTINGS FOR FILL-IN c_bis IN FRAME Dialog-Frame
   NO-ENABLE                                                            */
/* SETTINGS FOR FILL-IN c_von IN FRAME Dialog-Frame
   NO-ENABLE                                                            */
/* _RUN-TIME-ATTRIBUTES-END */
&ANALYZE-RESUME

 



/* ************************  Control Triggers  ************************ */

&Scoped-define SELF-NAME Dialog-Frame
&ANALYZE-SUSPEND _UIB-CODE-BLOCK _CONTROL Dialog-Frame Dialog-Frame
ON WINDOW-CLOSE OF FRAME Dialog-Frame /* Sicherheitsbestande berechnen */
DO:
  {adm/template/incl/dt_uit00.if
     &UserExitName = "ON_WINDOW-CLOSE_OF_FRAME"}

  {adm/template/incl/dt_dlg09.if}

  {adm/template/incl/dt_uit01.if
     &UserExitName = "ON_WINDOW-CLOSE_OF_FRAME"}
END.

/* _UIB-CODE-BLOCK-END */
&ANALYZE-RESUME


&Scoped-define SELF-NAME Artikel_min
&ANALYZE-SUSPEND _UIB-CODE-BLOCK _CONTROL Artikel_min Dialog-Frame
ON leave OF Artikel_min IN FRAME Dialog-Frame /* Teil */
DO:
  {adm/template/incl/dt_uit00.if
     &UserExitName = "ON_LEAVE_OF_Artikel_min"}

  {adm/template/incl/dt_dlg00.if &MAX-FELD = "Artikel_max"}

  {adm/template/incl/dt_uit01.if
     &UserExitName = "ON_LEAVE_OF_Artikel_min"}
END.

/* _UIB-CODE-BLOCK-END */
&ANALYZE-RESUME


&Scoped-define SELF-NAME ArtikelArt_min
&ANALYZE-SUSPEND _UIB-CODE-BLOCK _CONTROL ArtikelArt_min Dialog-Frame
ON leave OF ArtikelArt_min IN FRAME Dialog-Frame /* Teileart */
DO:
  {adm/template/incl/dt_uit00.if
     &UserExitName = "ON_LEAVE_OF_ArtikelArt_min"}

  {adm/template/incl/dt_dlg00.if &MAX-FELD = "ArtikelArt_max"}

  {adm/template/incl/dt_uit01.if
     &UserExitName = "ON_LEAVE_OF_ArtikelArt_min"}
END.

/* _UIB-CODE-BLOCK-END */
&ANALYZE-RESUME


&Scoped-define SELF-NAME ArtikelGruppe_min
&ANALYZE-SUSPEND _UIB-CODE-BLOCK _CONTROL ArtikelGruppe_min Dialog-Frame
ON leave OF ArtikelGruppe_min IN FRAME Dialog-Frame /* Teilegruppe */
DO:
  {adm/template/incl/dt_uit00.if
     &UserExitName = "ON_LEAVE_OF_ArtikelGruppe_min"}

  {adm/template/incl/dt_dlg00.if &MAX-FELD = "ArtikelGruppe_max"}

  {adm/template/incl/dt_uit01.if
     &UserExitName = "ON_LEAVE_OF_ArtikelGruppe_min"}
END.

/* _UIB-CODE-BLOCK-END */
&ANALYZE-RESUME


&Scoped-define SELF-NAME Btn_Start
&ANALYZE-SUSPEND _UIB-CODE-BLOCK _CONTROL Btn_Start Dialog-Frame
ON CHOOSE OF Btn_Start IN FRAME Dialog-Frame /* OK */
DO:
  {adm/template/incl/dt_uit00.if
     &UserExitName = "ON_CHOOSE_OF_Btn_Start"}

  {adm/template/incl/dt_btn01.if}

  {adm/template/incl/dt_uit01.if
     &UserExitName = "ON_CHOOSE_OF_Btn_Start"}
END.

/* _UIB-CODE-BLOCK-END */
&ANALYZE-RESUME


&Scoped-define SELF-NAME DispoGruppe_min
&ANALYZE-SUSPEND _UIB-CODE-BLOCK _CONTROL DispoGruppe_min Dialog-Frame
ON LEAVE OF DispoGruppe_min IN FRAME Dialog-Frame /* Dispositionsgruppe */
do:
  {adm/template/incl/dt_uit00.if
     &UserExitName = "ON_LEAVE_OF_DispoGruppe_min"}

  {adm/template/incl/dt_dlg00.if &MAX-FELD = "DispoGruppe_max"}

  {adm/template/incl/dt_uit01.if
     &UserExitName = "ON_LEAVE_OF_DispoGruppe_min"}
end.

/* _UIB-CODE-BLOCK-END */
&ANALYZE-RESUME


&Scoped-define SELF-NAME Lagergruppe_min
&ANALYZE-SUSPEND _UIB-CODE-BLOCK _CONTROL Lagergruppe_min Dialog-Frame
ON leave OF Lagergruppe_min IN FRAME Dialog-Frame /* Dispobereich */
DO:
  {adm/template/incl/dt_uit00.if
     &UserExitName = "ON_LEAVE_OF_Lagergruppe_min"}

  {adm/template/incl/dt_dlg00.if &MAX-FELD = "Lagergruppe_max"}

  {adm/template/incl/dt_uit01.if
     &UserExitName = "ON_LEAVE_OF_Lagergruppe_min"}
END.

/* _UIB-CODE-BLOCK-END */
&ANALYZE-RESUME


&UNDEFINE SELF-NAME

&ANALYZE-SUSPEND _UIB-CODE-BLOCK _CUSTOM _MAIN-BLOCK Dialog-Frame 


/* ***************************  Main Block  *************************** */

{adm/template/incl/dt_dlg00.i}

run initialize in this-procedure.

/* Now enable the interface and wait for the exit condition.            */
/* (NOTE: handle ERROR and END-KEY so cleanup code will always fire.    */
MAIN-BLOCK:
DO ON ERROR   UNDO MAIN-BLOCK, LEAVE MAIN-BLOCK
   ON END-KEY UNDO MAIN-BLOCK, LEAVE MAIN-BLOCK:
  RUN enable_UI.

  /* Wait-for go of frame                                                     */

  {adm/template/incl/dt_dlg11.if}

END.
RUN disable_UI.


{adm/template/incl/dt_dlg08.if}

/* _UIB-CODE-BLOCK-END */
&ANALYZE-RESUME


/* **********************  Internal Procedures  *********************** */

&ANALYZE-SUSPEND _UIB-CODE-BLOCK _PROCEDURE assignData Dialog-Frame  adm/support/proc/ds_dlg10.p
PROCEDURE assignData :
/* Description ---------------------------------------------------------------*/
/*                                                                            */
/* Assign screen values to parameter string                                   */
/*                                                                            */
/* Parameters ----------------------------------------------------------------*/
/*                                                                            */
/* pcParamListe  List with data in Proalpha String format                     */
/*                                                                            */
/*----------------------------------------------------------------------------*/

define       output parameter pcParamListe as character     no-undo.

/* Variables -----------------------------------------------------------------*/
/*----------------------------------------------------------------------------*/

/* Buffers -------------------------------------------------------------------*/

/*----------------------------------------------------------------------------*/
/* Processing                                                                 */
/*----------------------------------------------------------------------------*/

/* Assign Screen Buffer                                                       */

{adm/template/incl/dt_dlg12.if}

/* Assign Default Values                                                      */

/* --> MO#KBer-MG2-0108 thongdi_p 07/07/2026 PA-63 Sicherheitsbest�nde - automatische Berechnung */

pcParamListe = adm.method.cls.DMCParameterStringSvc:cWriteValue
                 ( /* pcPString */ pcParamListe,
                   /* pcKey     */ 'Artikel_min':U,
                   /* pcValue   */ Artikel_min ).
                   
pcParamListe = adm.method.cls.DMCParameterStringSvc:cWriteValue
                 ( /* pcPString */ pcParamListe,
                   /* pcKey     */ 'Artikel_max':U,
                   /* pcValue   */ Artikel_max ). 
                   
pcParamListe = adm.method.cls.DMCParameterStringSvc:cWriteValue
                 ( /* pcPString */ pcParamListe,
                   /* pcKey     */ 'ArtikelArt_min':U,
                   /* pcValue   */ ArtikelArt_min ).
                   
pcParamListe = adm.method.cls.DMCParameterStringSvc:cWriteValue
                 ( /* pcPString */ pcParamListe,
                   /* pcKey     */ 'ArtikelArt_max':U,
                   /* pcValue   */ ArtikelArt_max ).
                   
pcParamListe = adm.method.cls.DMCParameterStringSvc:cWriteValue
                 ( /* pcPString */ pcParamListe,
                   /* pcKey     */ 'ArtikelGruppe_min':U,
                   /* pcValue   */ ArtikelGruppe_min ).
                   
pcParamListe = adm.method.cls.DMCParameterStringSvc:cWriteValue
                 ( /* pcPString */ pcParamListe,
                   /* pcKey     */ 'ArtikelGruppe_max':U,
                   /* pcValue   */ ArtikelGruppe_max ). 
                   
pcParamListe = adm.method.cls.DMCParameterStringSvc:cWriteValue
                 ( /* pcPString */ pcParamListe,
                   /* pcKey     */ 'DispoGruppe_min':U,
                   /* pcValue   */ DispoGruppe_min ).
                   
pcParamListe = adm.method.cls.DMCParameterStringSvc:cWriteValue
                 ( /* pcPString */ pcParamListe,
                   /* pcKey     */ 'DispoGruppe_max':U,
                   /* pcValue   */ DispoGruppe_max ).                   
                   
pcParamListe = adm.method.cls.DMCParameterStringSvc:cWriteValue
                 ( /* pcPString */ pcParamListe,
                   /* pcKey     */ 'Lagergruppe_min':U,
                   /* pcValue   */ Lagergruppe_min ). 
                   
pcParamListe = adm.method.cls.DMCParameterStringSvc:cWriteValue
                 ( /* pcPString */ pcParamListe,
                   /* pcKey     */ 'Lagergruppe_max':U,
                   /* pcValue   */ Lagergruppe_max ).                    
                                                                                            
pcParamListe = adm.method.cls.DMCParameterStringSvc:cWriteValue
                 ( /* pcPString */ pcParamListe,
                   /* pcKey     */ 'SichBestUebernahme':U,
                   /* pcValue   */ string(RADIO-SET-1) ).
                            
/* <-- MO#KBer-MG2-0108 thongdi_p 07/07/2026 PA-63 Sicherheitsbest�nde - automatische Berechnung */


/* Default Code                                                               */

{adm/template/incl/dt_dlg07.if}

return.

end procedure. /* assignData */

/* _UIB-CODE-BLOCK-END */
&ANALYZE-RESUME

&ANALYZE-SUSPEND _UIB-CODE-BLOCK _PROCEDURE disable_UI Dialog-Frame 
PROCEDURE disable_UI :
/* Description ---------------------------------------------------------------*/
/*                                                                            */
/* DISABLE the User Interface                                                 */
/*                                                                            */
/* Notes ---------------------------------------------------------------------*/
/*                                                                            */
/* Here we clean-up the user-interface by deleting dynamic widgets we have    */
/* created and/or hide frames.  This procedure is usually called when we are  */
/* ready to "clean-up" after running                                          */
/*                                                                            */
/* Parameters ----------------------------------------------------------------*/
/*                                                                            */
/* <none>                                                                     */
/*                                                                            */
/*----------------------------------------------------------------------------*/

/* Variables -----------------------------------------------------------------*/
/*----------------------------------------------------------------------------*/

/* Buffers -------------------------------------------------------------------*/

/*----------------------------------------------------------------------------*/
/* Processing                                                                 */
/*----------------------------------------------------------------------------*/

{adm/template/incl/dt_dlg06.if}

end procedure. /* disable_UI */

/* _UIB-CODE-BLOCK-END */
&ANALYZE-RESUME

&ANALYZE-SUSPEND _UIB-CODE-BLOCK _PROCEDURE enable_UI Dialog-Frame 
PROCEDURE enable_UI :
/* Description ---------------------------------------------------------------*/
/*                                                                            */
/* ENABLE the User Interface                                                  */
/*                                                                            */
/* Notes ---------------------------------------------------------------------*/
/*                                                                            */
/* Here we display/view/enable the widgets in the user-interface.             */
/* In addition, OPEN all queries associated with each FRAME and BROWSE.       */
/* These statements here are based on the "Other Settings" section of the     */
/* widget Property Sheets.                                                    */
/*                                                                            */
/* Parameters ----------------------------------------------------------------*/
/*                                                                            */
/* <none>                                                                     */
/*                                                                            */
/*----------------------------------------------------------------------------*/

/* Variables -----------------------------------------------------------------*/
/*----------------------------------------------------------------------------*/

/* Buffers -------------------------------------------------------------------*/

/*----------------------------------------------------------------------------*/
/* Processing                                                                 */
/*----------------------------------------------------------------------------*/

{adm/template/incl/dt_dlg03.if}

end procedure. /* enable_UI */

/* _UIB-CODE-BLOCK-END */
&ANALYZE-RESUME

&ANALYZE-SUSPEND _UIB-CODE-BLOCK _PROCEDURE initialize Dialog-Frame  adm/support/proc/ds_dlg02.p
PROCEDURE initialize :
/* Description ---------------------------------------------------------------*/
/*                                                                            */
/* Initialization                                                             */
/*                                                                            */
/* Notes ---------------------------------------------------------------------*/
/*                                                                            */
/* - Initialization of variables                                              */
/* - Assign format                                                            */
/*                                                                            */
/* Parameters ----------------------------------------------------------------*/
/*                                                                            */
/* <none>                                                                     */
/*                                                                            */
/*----------------------------------------------------------------------------*/

/* Variables -----------------------------------------------------------------*/
/* lExternalValueAvailable     Flag                                           */
/*----------------------------------------------------------------------------*/

define variable lExternalValueAvailable as logical       no-undo.

/*----------------------------------------------------------------------------*/
/* Processing                                                                 */
/*----------------------------------------------------------------------------*/

/* Initialize maximum values (use external data, if available)                */

/* --> MO#KBer-MG2-0108 thongdi_p 07/07/2026 PA-63 Sicherheitsbest�nde - automatische Berechnung */

/* Artikel */
{adm/incl/d__par01.if
  &ParameterListe = "pc_Options"
  &Parameter      = "Artikel"
  &Variable1      = "Artikel_min"
  &Variable2      = "Artikel_max"
  &Flag           = "lExternalValueAvailable"
}

if not lExternalValueAvailable then
do:
  {adm/template/incl/dt_dlg04.if
    &Variable = "Artikel_min"
  }
  find last S_Artikel
    where S_Artikel.Firma = {firma/sartikel.fir pa-Firma}
    use-index Main
    no-lock no-error.
  if available S_Artikel then
    Artikel_max = S_Artikel.Artikel.
end. /* not lExternalValueAvailable */

/* ArtikelArt */
{adm/incl/d__par01.if
  &ParameterListe = "pc_Options"
  &Parameter      = "ArtikelArt"
  &Variable1      = "ArtikelArt_min"
  &Variable2      = "ArtikelArt_max"
  &Datentyp       = "integer"
  &Flag           = "lExternalValueAvailable"
}

if not lExternalValueAvailable then
do:
  {adm/template/incl/dt_dlg04.if
    &Variable = "ArtikelArt_min"
    &Datentyp = "integer"
  }
  find last S_ArtikelArt
    use-index Main
    no-lock no-error.
  if available S_ArtikelArt then
    ArtikelArt_max = S_ArtikelArt.ArtikelArt.
end. /* not lExternalValueAvailable */

/* ArtikelGruppe */
{adm/incl/d__par01.if
  &ParameterListe = "pc_Options"
  &Parameter      = "ArtikelGruppe"
  &Variable1      = "ArtikelGruppe_min"
  &Variable2      = "ArtikelGruppe_max"
  &Flag           = "lExternalValueAvailable"
}

if not lExternalValueAvailable then
do:
  {adm/template/incl/dt_dlg04.if
    &Variable = "ArtikelGruppe_min"
  }
  find last S_ArtGruppe
    where S_ArtGruppe.Firma = {firma/sartgrp.fir pa-Firma}
    use-index Main
    no-lock no-error.
  if available S_ArtGruppe then
    ArtikelGruppe_max = S_ArtGruppe.ArtikelGruppe.
end. /* not lExternalValueAvailable */

/* Lagergruppe */
{adm/incl/d__par01.if
  &ParameterListe = "pc_Options"
  &Parameter      = "Lagergruppe"
  &Variable1      = "Lagergruppe_min"
  &Variable2      = "Lagergruppe_max"
  &Datentyp       = "integer"
  &Flag           = "lExternalValueAvailable"
}

if not lExternalValueAvailable then
do:
  {adm/template/incl/dt_dlg04.if
    &Variable = "Lagergruppe_min"
    &Datentyp = "integer"
  }
  find last ML_Lagergruppe
    where ML_Lagergruppe.Firma = {firma/mlort.fir pa-Firma}
    use-index Main
    no-lock no-error.
  if available ML_Lagergruppe then 
    Lagergruppe_max = ML_Lagergruppe.Lagergruppe.
end. /* not lExternalValueAvailable */

/* DispoGruppe */
{adm/incl/d__par01.if
  &ParameterListe = "pc_Options"
  &Parameter      = "DispoGruppe"
  &Variable1      = "DispoGruppe_min"
  &Variable2      = "DispoGruppe_max"
  &Flag           = "lExternalValueAvailable"
}

if not lExternalValueAvailable then
do:
  {adm/template/incl/dt_dlg04.if
    &Variable = "DispoGruppe_min"
  }
  find last S_DispoGruppe
    where S_DispoGruppe.Firma = {firma/sdispogr.fir pa-Firma}
    use-index Main
    no-lock no-error.
  if available S_DispoGruppe then 
    DispoGruppe_max = S_DispoGruppe.DispoGruppe.
end. /* not lExternalValueAvailable */

/* <-- MO#KBer-MG2-0108 thongdi_p 07/07/2026 PA-63 Sicherheitsbest�nde - automatische Berechnung */

/* Copy setup from dummy frame                                                */



/* Default Code                                                               */

{adm/template/incl/dt_dlg01.if}

end procedure. /* initialize */

/* _UIB-CODE-BLOCK-END */
&ANALYZE-RESUME

&ANALYZE-SUSPEND _UIB-CODE-BLOCK _PROCEDURE process-data Dialog-Frame  adm/support/proc/ds_dlg04.p
PROCEDURE process-data :
/* Description ---------------------------------------------------------------*/
/*                                                                            */
/* Save data into parameter string and start processing                       */
/*                                                                            */
/* Parameters ----------------------------------------------------------------*/
/*                                                                            */
/* <none>                                                                     */
/*                                                                            */
/*----------------------------------------------------------------------------*/

/* Variables -----------------------------------------------------------------*/
/* c_ParamListe        Parameter string                                       */
/* c_Options           Options of target program                              */
/* c_ZielProgramm      Target Program                                         */
/*----------------------------------------------------------------------------*/

define variable c_ParamListe   as character     no-undo.
define variable c_Options      as character     no-undo.
define variable c_ZielProgramm as character     no-undo.

/*----------------------------------------------------------------------------*/
/* Processing                                                                 */
/*----------------------------------------------------------------------------*/

run assignData in this-procedure (output c_ParamListe).

{adm/template/incl/dt_dlg02.if}

end procedure. /* process-data */

/* _UIB-CODE-BLOCK-END */
&ANALYZE-RESUME

