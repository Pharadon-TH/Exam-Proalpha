&ANALYZE-SUSPEND _VERSION-NUMBER UIB_v8r12 GUI
&ANALYZE-RESUME
/* Connected Databases
          basis            PROGRESS
*/
&Scoped-define WINDOW-NAME CURRENT-WINDOW

&ANALYZE-SUSPEND _UIB-CODE-BLOCK _CUSTOM _DECLARATIONS B-table-Win 

/* _UIB-CODE-BLOCK-END */
&ANALYZE-RESUME


&ANALYZE-SUSPEND _UIB-CODE-BLOCK _XFTR "Update Information" B-table-Win _INLINE
/* Actions: ? ? ? ? adm/support/proc/ds_pa_01.w */

/* _UIB-CODE-BLOCK-END */
&ANALYZE-RESUME

&ANALYZE-SUSPEND _UIB-CODE-BLOCK _CUSTOM _DEFINITIONS B-table-Win 
/*****************************************************************************/
/* @COPYRIGHT@                                                               */
/*                                                                           */
/*  Projekt....: Proalpha                                                    */
/*                                                                           */
/*  Name.......: ivbang40.w                                                  */
/*  Bereich....: INFO/VERT                                                   */
/*                                                                           */
/*  erstellt am: 06.11.1997                                                  */
/*  Autor......: Werner Ernst                                                */
/*                                                                           */
/*  Version....: @PAVERSION@ vom @PADATE@/@PALASTAUTHOR@                     */
/*                                                                           */
/*---------------------------------------------------------------------------*/
/*  AUFGABE                                                                  */
/*---------------------------------------------------------------------------*/
/*                                                                           */
/*  Browser �ber die Angebote zu einem Artikel                               */
/*                                                                           */
/*---------------------------------------------------------------------------*/
/*  ARGUMENTE/PARAMETER                                                      */
/*---------------------------------------------------------------------------*/
/*                                                                           */
/*  Name                Art Funktion/Inhalt                                  */
/*  ------------------- --- ------------------------------------------------ */
/*---------------------------------------------------------------------------*/
/*  �NDERUNGSPROTOKOLL                                                       */
/*---------------------------------------------------------------------------*/
/* @FILEHISTORY@                                                             */
/*****************************************************************************/

/*----------------------------------------------------------------------     */
/*          This .W file was created with the Progress UIB.                  */
/*----------------------------------------------------------------------     */

/* Create an unnamed pool to store all the widgets created
     by this procedure. This is a good default which assures
     that this procedure's triggers and internal procedures
     will execute in this procedure's storage, and that proper
     cleanup will occur on deletion of the procedure. */

CREATE WIDGET-POOL.

/*---------------------------------------------------------------------------*/
/* Definitionen                                                              */
/*---------------------------------------------------------------------------*/

/* KONSTANTEN ---------------------------------------------------------------*/
/* Systemkonstanten **********************************************************/

&GLOBAL-DEFINE pa-Autor             Werner Ernst
&GLOBAL-DEFINE pa-Version           @PAVERSION@
&GLOBAL-DEFINE pa-Datum             @PADATE@
&GLOBAL-DEFINE pa-Letzter           @PALASTAUTHOR@

&GLOBAL-DEFINE pa-GenVersion       UIB
&GLOBAL-DEFINE pa-ProgrammTyp      SmartBrowser
&GLOBAL-DEFINE pa-Template         adm/template/proc/dt_brw01.w
&GLOBAL-DEFINE pa-TemplateVersion  1.03

&GLOBAL-DEFINE pa-XBasisName       ivbang40_w

/* lokale Konstanten *********************************************************/


/* EXTERNE DEFINITIONEN -----------------------------------------------------*/

{adm/template/incl/dt_brw00.df}

&IF LOOKUP('U_CI':U,'{&PA-OPTIONEN}':U) > 0 &THEN
  &Scoped-define K_V_BelegPos_uAngebot V_BelegPos.uAngebot
  &Scoped-define K_V_BelegPos_uAngebotsversion V_BelegPos.uAngebotsversion
&ENDIF

&IF lookup('VC':U,'{&PA-MODULE}':U) > 0 &THEN
  &Scoped-define K_V_BelegKopf_Interessent V_BelegKopf.Interessent
&ENDIF

&IF '{&pa_S_Varianten}':U = '1':U &THEN
  &Scoped-define K_V_BelegPos_ArtVar V_BelegPos.ArtVar
&ENDIF

&IF LOOKUP('S_ProfCenter','{&PA-OPTIONEN}') > 0 &THEN
  &Scoped-define K_V_BelegKopf_SBM_ProfitCenter_ID V_BelegKopf.SBM_ProfitCenter_ID
  &Scoped-define K_gcProfitCenterDesc gcProfitCenterDesc
  &Scoped-define pa-SetConditionalColumnLabels gcProfitCenterDesc:label in browse br_table = dynamic-function('pa_cUISvcSetWidgetAttribute':U in target-procedure, gcProfitCenterDesc:handle, 'label':U, 'Bezeichnung Profitcenter':L30).
&ENDIF


/* LOKALE OBJEKTE -----------------------------------------------------------*/
/* Variable ******************************************************************/
/*   Name               Funktion                                             */
/*   ------------------ ---------------------------------------------------- */
/*****************************************************************************/

define variable iRueckmeldeNr      as integer                           no-undo.

&IF LOOKUP("S_ProfCenter","{&PA-OPTIONEN}") > 0 &THEN
define variable gcProfitCenterDesc like DBM_ShortDescription.ShortDesc1 format 'x(30)':U no-undo.
&ENDIF

{info/vert/incl/iv_pos00.df}

&IF LOOKUP("U_CI":U,"{&PA-OPTIONEN}":U) > 0 &THEN
define variable gluQuoteVersioning  as logical     no-undo.
&ENDIF

{vert/incl/v__bel10.lib}
{vert/incl/v__bel11.lib}

/* Buffer ********************************************************************/

/* Work-/Temp-Tables *********************************************************/

/* _UIB-CODE-BLOCK-END */
&ANALYZE-RESUME


&ANALYZE-SUSPEND _UIB-PREPROCESSOR-BLOCK

/* ********************  Preprocessor Definitions  ******************** */

&Scoped-define PROCEDURE-TYPE Proalpha-SmartBrowser
&Scoped-define DB-AWARE no

&Scoped-define ADM-SUPPORTED-LINKS Record-Source,Record-Target,Navigation-Target

/* Name of designated FRAME-NAME and/or first browse and/or first query */
&Scoped-define FRAME-NAME F-Main
&Scoped-define BROWSE-NAME br_table

/* Internal Tables (found by Frame, Query & Browse Queries)             */
&Scoped-define INTERNAL-TABLES V_BelegPos

/* Define KEY-PHRASE in case it is used by any query. */
&Scoped-define KEY-PHRASE TRUE

/* Definitions for BROWSE br_table                                      */
&Scoped-define FIELDS-IN-QUERY-br_table find-additional-records() @ V_BelegPos.BelegNummer {&K_V_BelegPos_uAngebot} {&K_V_BelegPos_uAngebotsversion} V_BelegKopf.BelegDatum V_BelegKopf.Auftragsart V_BelegPos.Wertposition V_BelegPos.PositionsNr V_BelegKopf.Kunde {&K_V_BelegKopf_Interessent} cName1 dMenge cME1 dGesamtnetto dGesamtbrutto gcKurzBez V_BelegKopf.gueltig_bis V_BelegPos.Wunschtermin V_BelegPos.Lieferzeit V_BelegPos.Artikel {&K_V_BelegPos_ArtVar} gcBezeichnung1 gcBezeichnung2 gcBezeichnung3 gcBezeichnung4 V_BelegPos.Lagerort V_BelegPos.Gewicht V_BelegPos.AnlageBenutzer V_BelegPos.AnlageDatum V_BelegPos.AenderungDatum V_BelegPos.AenderungBenutzer V_BelegPos.MMM_CusRefOrder_ID dEinzelpreis dZuschlagW1 dZuschlagW2 dZuschlagP1 dZuschlagP2 dZuschlagP3 {&K_V_BelegKopf_SBM_ProfitCenter_ID} {&K_gcProfitCenterDesc} V_BelegKopf.BelegInfo {&{&PA-XBASISName}_C_BROWSEDISPLAY} {&{&PA-XBASISName}_U_BROWSEDISPLAY} {&{&PA-XBASISName}_Q_BROWSEDISPLAY} {&{&PA-XBASISNAME}_BROWSEDISPLAY} {&{&PA-XBASISName}_Y_BROWSEDISPLAY}
&Scoped-define ENABLED-FIELDS-IN-QUERY-br_table V_BelegPos.MMM_CusRefOrder_ID
&Scoped-define ENABLED-TABLES-IN-QUERY-br_table V_BelegPos
&Scoped-define FIRST-ENABLED-TABLE-IN-QUERY-br_table V_BelegPos
&Scoped-define SELF-NAME br_table
&Scoped-define QUERY-STRING-br_table ~{&PA-VIRTUAL-INDEX-PHRASE} EACH V_BelegPos WHERE ~{&KEY-PHRASE} AND V_BelegPos.Firma = ~{firma/vbelegko.fir pa-firma} AND V_BelegPos.BelegArt = 'A':U AND V_BelegPos.offen = l_offen AND V_BelegPos.Satzart = 'A':U NO-LOCK ~{&SORTBY-PHRASE}
&Scoped-define OPEN-QUERY-br_table OPEN QUERY {&SELF-NAME} ~{&PA-VIRTUAL-INDEX-PHRASE} EACH V_BelegPos WHERE ~{&KEY-PHRASE} AND V_BelegPos.Firma = ~{firma/vbelegko.fir pa-firma} AND V_BelegPos.BelegArt = 'A':U AND V_BelegPos.offen = l_offen AND V_BelegPos.Satzart = 'A':U NO-LOCK ~{&SORTBY-PHRASE}.
&Scoped-define TABLES-IN-QUERY-br_table V_BelegPos
&Scoped-define FIRST-TABLE-IN-QUERY-br_table V_BelegPos


/* Definitions for FRAME F-Main                                         */

/* Standard List Definitions                                            */
&Scoped-Define ENABLED-OBJECTS l_offen br_table
&Scoped-Define DISPLAYED-OBJECTS l_offen

/* Custom List Definitions                                              */
/* List-1,List-2,List-3,List-4,List-5,List-6                            */

/* _UIB-PREPROCESSOR-BLOCK-END */
&ANALYZE-RESUME


&ANALYZE-SUSPEND _UIB-CODE-BLOCK _XFTR "Foreign Keys" B-table-Win _INLINE
/* Actions: ? adm/support/proc/keyedit.w ? ? ? */
/* STRUCTURED-DATA
<KEY-OBJECT>
&BROWSE-NAME
</KEY-OBJECT>
<FOREIGN-KEYS>
BelegArt||y|mawi.V_BelegPos.BelegArt||||||
ReferenzNr||y|mawi.V_BelegPos.ReferenzNr||||||
LfdNr_SR||y|mawi.V_BelegPos.LfdNr_SR||||||
PositionsNr||y|mawi.V_BelegPos.PositionsNr||||||
Artikel|y||mawi.V_BelegPos.Artikel||||||
Kunde||y|mawi.V_BelegKopf.Kunde||||||
$KEY||y|mawi.V_BelegPos|vert/incl/v_belpo.sl|||||
RueckMeldeNr||y|iRueckMeldeNr||||||
V_BelegPos_Obj||y|V_BelegPos.V_BelegPos_Obj||||||
Origin_Obj||y|V_BelegPos.Origin_Obj||||||
V_BelegKopf_Obj||y|basis.V_BelegKopf.V_BelegKopf_Obj||||||
MMM_CusRefOrder_Obj||y|basis.V_BelegPos.MMM_CusRefOrder_Obj||||||
S_Steuer_Obj||y|basis.V_BelegPos.S_Steuer_Obj||||||
Driver_Obj||y|basis.V_BelegPos.Driver_Obj||||||
SBM_BusinessCategory_Obj||y|basis.V_BelegPos.SBM_BusinessCategory_Obj||||||
SBM_CustomsTariffNo_Obj||y|basis.V_BelegPos.SBM_CustomsTariffNo_Obj||||||
Sys_S_Steuer_Obj||y|basis.V_BelegPos.Sys_S_Steuer_Obj||||||
Owning_Obj||y|basis.V_BelegPos.V_BelegPos_Obj||||||
</FOREIGN-KEYS> 
<EXECUTING-CODE>
**************************
* Set attributes related to FOREIGN KEYS
*/
run set-attribute-list (
    'Keys-Accepted = "Artikel",
     Keys-External = ,
     Keys-Supplied = "BelegArt,ReferenzNr,LfdNr_SR,PositionsNr,Kunde,$KEY,RueckMeldeNr,V_BelegPos_Obj,Origin_Obj,V_BelegKopf_Obj,MMM_CusRefOrder_Obj,S_Steuer_Obj,Driver_Obj,SBM_BusinessCategory_Obj,SBM_CustomsTariffNo_Obj,Sys_S_Steuer_Obj,Owning_Obj"':U).

/* Tell the ADM to use the OPEN-QUERY-CASES. */
&Scoped-define OPEN-QUERY-CASES run dispatch ('open-query-cases':U).
/**************************
</EXECUTING-CODE> */
/* _UIB-CODE-BLOCK-END */
&ANALYZE-RESUME

&ANALYZE-SUSPEND _UIB-CODE-BLOCK _XFTR "Advanced Query Options" B-table-Win _INLINE
/* Actions: ? adm/support/proc/advqedit.w ? ? ? */
/* STRUCTURED-DATA
<KEY-OBJECT>
&BROWSE-NAME
</KEY-OBJECT>
<SORTBY-OPTIONS>
BelegNummer|y||mawi.V_BelegPos.BelegNummer|no
uAngebot|||V_BelegPos.uAngebot|no
</SORTBY-OPTIONS>
<SORTBY-RUN-CODE>
************************
* Set attributes related to SORTBY-OPTIONS */
run set-attribute-list (
    'SortBy-Options = "BelegNummer,uAngebot",
     SortBy-Case = BelegNummer':U).

/* Tell the ADM to use the OPEN-QUERY-CASES. */
&Scoped-define OPEN-QUERY-CASES run dispatch ('open-query-cases':U).

/* set up order-direction */
&Scoped-define PA-DESCENDING-SORT YES
run set-attribute-list ('pa-SortDirectionChangeEnabled=yes':U).
/************************
</SORTBY-RUN-CODE>
<FILTER-ATTRIBUTES>
</FILTER-ATTRIBUTES> */

/* _UIB-CODE-BLOCK-END */
&ANALYZE-RESUME

&ANALYZE-SUSPEND _UIB-CODE-BLOCK _XFTR "Find Builder" B-table-Win _INLINE
/* Actions: ? adm/support/proc/ds_sma00.w ? ? adm/support/proc/ds_fin00.p */
/* STRUCTURED-DATA
<ADDITIONAL-INFORMATION EDITABLE></ADDITIONAL-INFORMATION EDITABLE>

/* --> MO#END-ADU-0003 Thongdi.P 10/07/2026 2025: Spalte Kunde such- und sortierbar in Auftr�gen, Angeboten und Rechnungen zu Teilen */
/* Add when 'Kunde':U then ~ */

<GET-OFFSET-INFO>
V_BelegPos.BelegNummer,string(V_BelegPos.BelegNummer)|Nummer
V_BelegPos.uAngebot,string(V_BelegPos.uAngebot)|uAngebot
</GET-OFFSET-INFO>
<FIND-STATEMENT>
********/
&GLOBAL-DEFINE FIND-STATEMENT ~
case pa-sortby-case: ~
  when 'BelegNummer':U then ~
    find ~{&FIND-OPTION} V_BelegPos ~
      where V_BelegPos.Firma = ~{firma/vbelegko.fir pa-firma} ~
      &IF DEFINED(OFFSET-VALUE) > 0 &THEN ~
        and V_BelegPos.BelegNummer ~{&OFFSET-COMPARE} integer(~{&OFFSET-VALUE}) ~
      &ENDIF ~
   and V_BelegPos.BelegArt = 'A':U ~
   and V_BelegPos.offen = l_offen ~
   and V_BelegPos.Satzart = 'A':U ~
   and V_BelegPos.Artikel = pa-key-Artikel ~
      use-index Nummer ~
      no-lock no-error. ~
  when 'uAngebot':U then ~
    find ~{&FIND-OPTION} V_BelegPos ~
      where V_BelegPos.Firma = ~{firma/vbelegko.fir pa-firma} ~
      &IF DEFINED(OFFSET-VALUE) > 0 &THEN ~
        and V_BelegPos.uAngebot ~{&OFFSET-COMPARE} integer(~{&OFFSET-VALUE}) ~
      &ENDIF ~
   and V_BelegPos.BelegArt = 'A':U ~
   and V_BelegPos.offen = l_offen ~
   and V_BelegPos.Satzart = 'A':U ~
   and V_BelegPos.Artikel = pa-key-Artikel ~
      use-index uAngebot ~
      no-lock no-error. ~
  when 'Kunde':U then ~
    find ~{&FIND-OPTION} V_BelegPos ~
      where V_BelegPos.Firma = ~{firma/vbelegko.fir pa-firma} ~
      &IF DEFINED(OFFSET-VALUE) > 0 &THEN ~
        and V_BelegPos.Kunde ~{&OFFSET-COMPARE} integer(~{&OFFSET-VALUE}) ~
      &ENDIF ~
   and V_BelegPos.BelegArt = 'A':U ~
   and V_BelegPos.offen = l_offen ~
   and V_BelegPos.Satzart = 'A':U ~
   and V_BelegPos.Artikel = pa-key-Artikel ~
      use-index Kunde ~
      no-lock no-error. ~
  {&{&PA-XBASISNAME}_C_FindStatement} ~
  {&{&PA-XBASISNAME}_U_FindStatement} ~
  {&{&PA-XBASISNAME}_Q_FindStatement} ~
  {&{&PA-XBASISNAME}_FindStatement} ~
  {&{&PA-XBASISNAME}_Y_FindStatement} ~
  ~{adm/template/incl/dt_vbs13.if &ippSortCaseName = "pa-sortby-case"}~
  end case.

define variable pa-key-Artikel like V_BelegPos.Artikel no-undo init ?.
/********
</FIND-STATEMENT>  */
/* --> MO#END-ADU-0003 Thongdi.P 10/07/2026 2025: Spalte Kunde such- und sortierbar in Auftr�gen, Angeboten und Rechnungen zu Teilen */
/* _UIB-CODE-BLOCK-END */
&ANALYZE-RESUME

&ANALYZE-SUSPEND _UIB-CODE-BLOCK _XFTR "Find-Trigger" B-table-Win _INLINE
/* Actions: ? adm/support/proc/ds_sma00.w ? ? ? */

FUNCTION find-additional-records RETURNS INTEGER ( ) :

assign
  iRueckmeldeNr  = 0
  dMenge         = 0
  dOffen         = 0
  dGesamtnetto   = 0
  dGesamtbrutto  = 0
  dEinzelpreis   = 0
  dZuschlagW1    = 0
  dZuschlagW2    = 0
  dZuschlagP1    = 0
  dZuschlagP2    = 0
  dZuschlagP3    = 0
  gcBezeichnung1 = '':U
  gcBezeichnung2 = '':U
  gcBezeichnung3 = '':U
  gcBezeichnung4 = '':U
  cName1         = '':U
  cME1           = '':U
  cME2           = '':U
  cME3           = '':U
  &IF LOOKUP("S_ProfCenter","{&PA-OPTIONEN}") > 0 &THEN
    gcProfitCenterDesc = '':U
  &ENDIF
  .

if available V_BelegPos then do:

  {info/vert/incl/iv_pos00.if}

  &IF LOOKUP("S_ProfCenter","{&PA-OPTIONEN}") > 0 &THEN

    if    available V_BelegKopf
      and V_BelegKopf.SBM_ProfitCenter_Obj > '':U then

      gcProfitCenterDesc = stamm.base.cls.SBCProfitCenterSvc:prpoInstance:cProfitCenterDesc
                             (V_BelegKopf.SBM_ProfitCenter_Obj).

  &ENDIF

  {&{&PA-XBASISName}_C_FIND-TRIGGER_FIND}
  {&{&PA-XBASISName}_U_FIND-TRIGGER_FIND}
  {&{&PA-XBASISName}_Q_FIND-TRIGGER_FIND}
  {&{&PA-XBASISNAME}_FIND-TRIGGER_FIND}
  {&{&PA-XBASISName}_Y_FIND-TRIGGER_FIND}

  return V_BelegPos.BelegNummer.

end.

else do:

  {&{&PA-XBASISName}_C_FIND-TRIGGER_RELEASE}
  {&{&PA-XBASISName}_U_FIND-TRIGGER_RELEASE}
  {&{&PA-XBASISName}_Q_FIND-TRIGGER_RELEASE}
  {&{&PA-XBASISNAME}_FIND-TRIGGER_RELEASE}
  {&{&PA-XBASISName}_Y_FIND-TRIGGER_RELEASE}

  return ?.
end.

END FUNCTION.

&SCOP PA-FIND-DUMMY define variable pa-find-dummy as integer no-undo.

/* _UIB-CODE-BLOCK-END */
&ANALYZE-RESUME

&ANALYZE-SUSPEND _UIB-CODE-BLOCK _XFTR "Window Title" B-table-Win _INLINE
/* Actions: ? adm/support/proc/ds_sma00.w ? ? adm/support/proc/ds_ttl00.p */
/* STRUCTURED-DATA
<TITLE-CODE EDITABLE>
(if pa-key-artikel <> ? then
   trim(pa-key-artikel)
  else
    '':U)
+ (' ':U)
+ (if l_offen = no then
    '(Archiv)':L18
   else
     '':U)
</TITLE-CODE EDITABLE>
<CONSTANTS>
**/
&SCOP PA-TITLE-CODE ~
(if pa-key-artikel <> ? then ~
   trim(pa-key-artikel) ~
  else ~
    '':U) ~
+ (' ':U) ~
+ (if l_offen = no then ~
    '(Archiv)':L18 ~
   else ~
     '':U)
/**
</CONSTANTS>  */
/* _UIB-CODE-BLOCK-END */
&ANALYZE-RESUME

&ANALYZE-SUSPEND _UIB-CODE-BLOCK _XFTR "Skin Client Support" B-table-Win _INLINE
/* Actions: ? ? ? ? adm/support/proc/ds_skc00.p */
/* _UIB-CODE-BLOCK-END */
&ANALYZE-RESUME


/* ***********************  Control Definitions  ********************** */


/* Definitions of the field level widgets                               */
DEFINE VARIABLE l_offen AS LOGICAL INITIAL yes 
     LABEL "offene Belege":L20 
     VIEW-AS TOGGLE-BOX
     SIZE 28 BY 1 NO-UNDO.

/* Query definitions                                                    */
&ANALYZE-SUSPEND
DEFINE QUERY br_table FOR
      &IF defined(PA-CHECK-BROWSE-CONFIGURATION-SUPPORT) &THEN
        &IF {&PA-CHECK-BROWSE-CONFIGURATION-SUPPORT} &THEN
        DBT_VirtualIndex,
        &ENDIF
      &ENDIF
      V_BelegPos SCROLLING.
&ANALYZE-RESUME

/* Browse definitions                                                   */
DEFINE BROWSE br_table
&ANALYZE-SUSPEND _UIB-CODE-BLOCK _DISPLAY-FIELDS br_table B-table-Win _FREEFORM
  QUERY br_table NO-LOCK DISPLAY
      find-additional-records() @ V_BelegPos.BelegNummer
      {&K_V_BelegPos_uAngebot}
      {&K_V_BelegPos_uAngebotsversion}
      V_BelegKopf.BelegDatum
      V_BelegKopf.Auftragsart
      V_BelegPos.Wertposition
      V_BelegPos.PositionsNr
      V_BelegKopf.Kunde
      {&K_V_BelegKopf_Interessent}
      cName1              column-label 'Name':L30
      dMenge              column-label 'Menge':R16
      cME1                column-label 'ME':R4
      dGesamtnetto        column-label 'Gesamtnetto':R15
      dGesamtbrutto       column-label 'Gesamtbrutto':R15
      gcKurzBez
      V_BelegKopf.gueltig_bis
      V_BelegPos.Wunschtermin
      V_BelegPos.Lieferzeit
      V_BelegPos.Artikel
      {&K_V_BelegPos_ArtVar}
      gcBezeichnung1      column-label 'Bezeichnung 1':L30
      gcBezeichnung2      column-label 'Bezeichnung 2':L30
      gcBezeichnung3      column-label 'Bezeichnung 3':L30
      gcBezeichnung4      column-label 'Bezeichnung 4':L30
      V_BelegPos.Lagerort
      V_BelegPos.Gewicht
      V_BelegPos.AnlageBenutzer
      V_BelegPos.AnlageDatum
      V_BelegPos.AenderungDatum
      V_BelegPos.AenderungBenutzer
      V_BelegPos.MMM_CusRefOrder_ID
      dEinzelpreis
      dZuschlagW1
      dZuschlagW2
      dZuschlagP1
      dZuschlagP2
      dZuschlagP3
      {&K_V_BelegKopf_SBM_ProfitCenter_ID}
      {&K_gcProfitCenterDesc}
      V_BelegKopf.BelegInfo
      {&{&PA-XBASISName}_C_BROWSEDISPLAY}
      {&{&PA-XBASISName}_U_BROWSEDISPLAY}
      {&{&PA-XBASISName}_Q_BROWSEDISPLAY}
      {&{&PA-XBASISNAME}_BROWSEDISPLAY}
      {&{&PA-XBASISName}_Y_BROWSEDISPLAY}
  ENABLE
      V_BelegPos.MMM_CusRefOrder_ID
/* _UIB-CODE-BLOCK-END */
&ANALYZE-RESUME
    WITH NO-ASSIGN SEPARATORS SIZE 146 BY 13.79.


/* ************************  Frame Definitions  *********************** */

DEFINE FRAME F-Main
     l_offen AT ROW 1 COL 4
     br_table AT ROW 2.04 COL 1
    WITH 1 DOWN NO-BOX KEEP-TAB-ORDER OVERLAY
         SIDE-LABELS NO-UNDERLINE THREE-D
         AT COL 1 ROW 1 SCROLLABLE.


/* *********************** Procedure Settings ************************ */

&ANALYZE-SUSPEND _PROCEDURE-SETTINGS
/* Settings for THIS-PROCEDURE
   Type: Proalpha-SmartBrowser
   Allow: Basic,Browse
   Frames: 1
   Add Fields to: External-Tables
   Other Settings: PERSISTENT-ONLY
 */

/* This procedure should always be RUN PERSISTENT.  Report the error,  */
/* then cleanup and return.                                            */
IF NOT THIS-PROCEDURE:PERSISTENT THEN DO:
  MESSAGE "{&FILE-NAME} should only be RUN PERSISTENT.":U
          VIEW-AS ALERT-BOX ERROR BUTTONS OK.
  RETURN.
END.

&ANALYZE-RESUME _END-PROCEDURE-SETTINGS

/* *************************  Create Window  ************************** */

&ANALYZE-SUSPEND _CREATE-WINDOW
/* DESIGN Window definition (used by the UIB)
  CREATE WINDOW B-table-Win ASSIGN
         HEIGHT             = 15.21
         WIDTH              = 146.33.
/* END WINDOW DEFINITION */
                                                                        */
&ANALYZE-RESUME

&ANALYZE-SUSPEND _UIB-CODE-BLOCK _CUSTOM _INCLUDED-LIB B-table-Win 
/* ************************* Included-Libraries *********************** */

{adm/method/incl/dm_brw01.lib}

/* _UIB-CODE-BLOCK-END */
&ANALYZE-RESUME




/* ***********  Runtime Attributes and AppBuilder Settings  *********** */

&ANALYZE-SUSPEND _RUN-TIME-ATTRIBUTES
/* SETTINGS FOR WINDOW B-table-Win
  NOT-VISIBLE,,RUN-PERSISTENT                                           */
/* SETTINGS FOR FRAME F-Main
   NOT-VISIBLE FRAME-NAME Size-to-Fit                                   */
/* BROWSE-TAB br_table l_offen F-Main */
ASSIGN
       FRAME F-Main:SCROLLABLE       = FALSE
       FRAME F-Main:HIDDEN           = TRUE.

/* _RUN-TIME-ATTRIBUTES-END */
&ANALYZE-RESUME


/* Setting information for Queries and Browse Widgets fields            */

&ANALYZE-SUSPEND _QUERY-BLOCK BROWSE br_table
/* Query rebuild information for BROWSE br_table
     _START_FREEFORM
OPEN QUERY {&SELF-NAME} FOR EACH V_BelegPos WHERE ~{&KEY-PHRASE}
  AND V_BelegPos.Firma    = ~{firma/vbelegko.fir pa-firma}
  AND V_BelegPos.BelegArt = 'A':U
  AND V_BelegPos.offen    = l_offen
  AND V_BelegPos.Satzart  = 'A':U
  NO-LOCK ~{&SORTBY-PHRASE}.
     _END_FREEFORM
     _Options          = "NO-LOCK KEY-PHRASE SORTBY-PHRASE"
     _Query            is NOT OPENED
*/  /* BROWSE br_table */
&ANALYZE-RESUME

&ANALYZE-SUSPEND _QUERY-BLOCK FRAME F-Main
/* Query rebuild information for FRAME F-Main
     _Options          = "NO-LOCK"
     _Query            is NOT OPENED
*/  /* FRAME F-Main */
&ANALYZE-RESUME





/* ************************  Control Triggers  ************************ */

&Scoped-define BROWSE-NAME br_table
&Scoped-define SELF-NAME br_table
&ANALYZE-SUSPEND _UIB-CODE-BLOCK _CONTROL br_table B-table-Win
ON ROW-DISPLAY OF br_table IN FRAME F-Main
DO:
  {adm/template/incl/dt_uit00.if
     &UserExitName = "ON_ROW-DISPLAY_OF_br_table"}

  find V_BelegKopf
    where V_BelegKopf.Firma      = V_BelegPos.Firma
      and V_BelegKopf.Belegart   = V_BelegPos.Belegart
      and V_BelegKopf.ReferenzNr = V_BelegPos.ReferenzNr
    no-lock.

  assign
    {adm/incl/d__bcf00.if
       &BrowseCellColumn = "dGesamtnetto"
       &ToFormat         = "entry(V_BelegKopf.WaehrungNK + 1, {&pa_MengenAnzeigeFormat_Browse},':':U)"
       &WithFrame        = "in browse {&browse-name}"}
    {adm/incl/d__bcf00.if
       &BrowseCellColumn = "dGesamtbrutto"
       &ToFormat         = "entry(V_BelegKopf.WaehrungNK + 1, {&pa_MengenAnzeigeFormat_Browse},':':U)"
       &WithFrame        = "in browse {&browse-name}"}
    {adm/incl/d__bcf00.if
       &BrowseCellColumn = "dMenge"
       &ToFormat         = "entry(V_BelegPos.Nachkomma + 1, {&pa_MengenAnzeigeFormat_Browse},':':U)"
       &WithFrame        = "in browse {&browse-name}"}
    {adm/incl/d__bcf00.if
       &BrowseCellColumn = "dEinzelpreis"
       &ToFormat         = "entry(V_BelegKopf.WaehrungNK + 1, {&pa_MengenAnzeigeFormat_Browse},':':U)"
       &WithFrame        = "in browse {&browse-name}"}
    {adm/incl/d__bcf00.if
       &BrowseCellColumn = "dZuschlagW1"
       &ToFormat         = "entry(V_BelegKopf.WaehrungNK + 1, {&pa_MengenAnzeigeFormat_Browse},':':U)"
       &WithFrame        = "in browse {&browse-name}"}
    {adm/incl/d__bcf00.if
       &BrowseCellColumn = "dZuschlagW2"
       &ToFormat         = "entry(V_BelegKopf.WaehrungNK + 1, {&pa_MengenAnzeigeFormat_Browse},':':U)"
       &WithFrame        = "in browse {&browse-name}"}
    .

  {adm/template/incl/dt_uit01.if
     &UserExitName = "ON_ROW-DISPLAY_OF_br_table"}
END.

/* _UIB-CODE-BLOCK-END */
&ANALYZE-RESUME


&Scoped-define SELF-NAME l_offen
&ANALYZE-SUSPEND _UIB-CODE-BLOCK _CONTROL l_offen B-table-Win
ON VALUE-CHANGED OF l_offen IN FRAME F-Main /* offene Belege */
DO:
  {adm/template/incl/dt_uit00.if
     &UserExitName = "ON_VALUE-CHANGED_OF_l_offen"}

  assign
    l_offen.

  run dispatch in this-procedure ( 'open-query':U ).

  run request in adm-broker-hdl (this-procedure,
                                 'container-source':U,
                                 'set-window-title':U).

  {adm/template/incl/dt_uit01.if
     &UserExitName = "ON_VALUE-CHANGED_OF_l_offen"}
END.

/* _UIB-CODE-BLOCK-END */
&ANALYZE-RESUME


&UNDEFINE SELF-NAME

&ANALYZE-SUSPEND _UIB-CODE-BLOCK _CUSTOM _MAIN-BLOCK B-table-Win 


/* ***************************  Main Block  *************************** */

{adm/template/incl/dt_brw00.i}

/* _UIB-CODE-BLOCK-END */
&ANALYZE-RESUME


/* **********************  Internal Procedures  *********************** */

&ANALYZE-SUSPEND _UIB-CODE-BLOCK _PROCEDURE adm-open-query-cases B-table-Win  adm/support/proc/ds_opn00.p
PROCEDURE adm-open-query-cases :
/* Description ---------------------------------------------------------------*/
/*                                                                            */
/* Opens different cases of the query based on attributes such as the         */
/* 'Key-Name', or 'SortBy-Case'                                               */
/*                                                                            */
/* Parameters ----------------------------------------------------------------*/
/*                                                                            */
/* <none>                                                                     */
/*                                                                            */
/*----------------------------------------------------------------------------*/

/*----------------------------------------------------------------------------*/
/* Processing                                                                 */
/*----------------------------------------------------------------------------*/

/* Initialize                                                                 */

{adm/template/incl/dt_opn00.if}

/* PREPROCS to support accepted keys                                          */

&SCOP KEY-PHRASE V_BelegPos.Artikel = pa-key-Artikel
&SCOP ORIGINAL-KEY-PHRASE V_BelegPos.Artikel = pa-key-Artikel

/* Open Query                                                                 */

case pa-sortby-case:
  when 'BelegNummer':U then
    if pa-DescendingSortOrder then
      &IF "{&PA-USE-INDEX-IN-QUERY}":U = "1":U &THEN
        &SCOP SORTBY-PHRASE use-index Nummer ~{&PA-VIRTUAL-INDEX-DUMMY-SORTBY-PHRASE-DESC} BY V_BelegPos.Firma DESCENDING BY V_BelegPos.BelegArt DESCENDING BY V_BelegPos.offen DESCENDING BY V_BelegPos.Artikel DESCENDING BY V_BelegPos.BelegNummer DESCENDING BY V_BelegPos.PositionsNr DESCENDING BY V_BelegPos.ArtVar DESCENDING
      &ELSE
        &SCOP SORTBY-PHRASE ~{&PA-VIRTUAL-INDEX-DUMMY-SORTBY-PHRASE-DESC} BY V_BelegPos.Firma DESCENDING BY V_BelegPos.BelegArt DESCENDING BY V_BelegPos.offen DESCENDING BY V_BelegPos.Artikel DESCENDING BY V_BelegPos.BelegNummer DESCENDING BY V_BelegPos.PositionsNr DESCENDING BY V_BelegPos.ArtVar DESCENDING
      &ENDIF
    &SCOP KEY-PHRASE {&KEY-PHRASE} {&PA-FILTER-PHRASE} and V_BelegPos.BelegNummer {&PA-OFFSET-COMPARE-GE-DESC} integer(c_offset-value) {&PA-FILTER-PHRASE}
    if c_offset-value <> ? then
      {&OPEN-QUERY-{&BROWSE-NAME}}
    &SCOP KEY-PHRASE {&ORIGINAL-KEY-PHRASE} {&PA-FILTER-PHRASE}
      else
        {&OPEN-QUERY-{&BROWSE-NAME}}

    else
      &IF "{&PA-USE-INDEX-IN-QUERY}":U = "1":U &THEN
        &SCOP SORTBY-PHRASE use-index Nummer ~{&PA-VIRTUAL-INDEX-DUMMY-SORTBY-PHRASE} BY V_BelegPos.Firma BY V_BelegPos.BelegArt BY V_BelegPos.offen BY V_BelegPos.Artikel BY V_BelegPos.BelegNummer BY V_BelegPos.PositionsNr BY V_BelegPos.ArtVar
      &ELSE
        &SCOP SORTBY-PHRASE ~{&PA-VIRTUAL-INDEX-DUMMY-SORTBY-PHRASE} BY V_BelegPos.Firma BY V_BelegPos.BelegArt BY V_BelegPos.offen BY V_BelegPos.Artikel BY V_BelegPos.BelegNummer BY V_BelegPos.PositionsNr BY V_BelegPos.ArtVar
      &ENDIF
      &SCOP KEY-PHRASE {&KEY-PHRASE} {&PA-FILTER-PHRASE} and V_BelegPos.BelegNummer {&PA-OFFSET-COMPARE-GE-ASC} integer(c_offset-value) {&PA-FILTER-PHRASE}
      if c_offset-value <> ? then
        {&OPEN-QUERY-{&BROWSE-NAME}}
      &SCOP KEY-PHRASE {&ORIGINAL-KEY-PHRASE} {&PA-FILTER-PHRASE}
      else
        {&OPEN-QUERY-{&BROWSE-NAME}}

  when 'uAngebot':U then
    if pa-DescendingSortOrder then
      &IF "{&PA-USE-INDEX-IN-QUERY}":U = "1":U &THEN
        &SCOP SORTBY-PHRASE use-index uAngebot ~{&PA-VIRTUAL-INDEX-DUMMY-SORTBY-PHRASE-DESC} BY V_BelegPos.Firma DESCENDING BY V_BelegPos.BelegArt DESCENDING BY V_BelegPos.offen DESCENDING BY V_BelegPos.uAngebot DESCENDING BY V_BelegPos.uAngebot_LfdNr DESCENDING BY V_BelegPos.uAngebotsversion DESCENDING
      &ELSE
        &SCOP SORTBY-PHRASE ~{&PA-VIRTUAL-INDEX-DUMMY-SORTBY-PHRASE-DESC} BY V_BelegPos.Firma DESCENDING BY V_BelegPos.BelegArt DESCENDING BY V_BelegPos.offen DESCENDING BY V_BelegPos.uAngebot DESCENDING BY V_BelegPos.uAngebot_LfdNr DESCENDING BY V_BelegPos.uAngebotsversion DESCENDING
      &ENDIF
    &SCOP KEY-PHRASE {&KEY-PHRASE} {&PA-FILTER-PHRASE} and V_BelegPos.uAngebot {&PA-OFFSET-COMPARE-GE-DESC} integer(c_offset-value) {&PA-FILTER-PHRASE}
    if c_offset-value <> ? then
      {&OPEN-QUERY-{&BROWSE-NAME}}
    &SCOP KEY-PHRASE {&ORIGINAL-KEY-PHRASE} {&PA-FILTER-PHRASE}
      else
        {&OPEN-QUERY-{&BROWSE-NAME}}

    else
      &IF "{&PA-USE-INDEX-IN-QUERY}":U = "1":U &THEN
        &SCOP SORTBY-PHRASE use-index uAngebot ~{&PA-VIRTUAL-INDEX-DUMMY-SORTBY-PHRASE} BY V_BelegPos.Firma BY V_BelegPos.BelegArt BY V_BelegPos.offen BY V_BelegPos.uAngebot BY V_BelegPos.uAngebot_LfdNr BY V_BelegPos.uAngebotsversion
      &ELSE
        &SCOP SORTBY-PHRASE ~{&PA-VIRTUAL-INDEX-DUMMY-SORTBY-PHRASE} BY V_BelegPos.Firma BY V_BelegPos.BelegArt BY V_BelegPos.offen BY V_BelegPos.uAngebot BY V_BelegPos.uAngebot_LfdNr BY V_BelegPos.uAngebotsversion
      &ENDIF
      &SCOP KEY-PHRASE {&KEY-PHRASE} {&PA-FILTER-PHRASE} and V_BelegPos.uAngebot {&PA-OFFSET-COMPARE-GE-ASC} integer(c_offset-value) {&PA-FILTER-PHRASE}
      if c_offset-value <> ? then
        {&OPEN-QUERY-{&BROWSE-NAME}}
      &SCOP KEY-PHRASE {&ORIGINAL-KEY-PHRASE} {&PA-FILTER-PHRASE}
      else
        {&OPEN-QUERY-{&BROWSE-NAME}}

  {&{&PA-XBASISNAME}_C_OpenQueryCases}
  {&{&PA-XBASISNAME}_U_OpenQueryCases}
  {&{&PA-XBASISNAME}_Q_OpenQueryCases}
  {&{&PA-XBASISNAME}_OpenQueryCases}
  {&{&PA-XBASISNAME}_Y_OpenQueryCases}

  {&{&PA-XBASISNAME}_C_OpenQueryCases_Sort}
  {&{&PA-XBASISNAME}_U_OpenQueryCases_Sort}
  {&{&PA-XBASISNAME}_Q_OpenQueryCases_Sort}
  {&{&PA-XBASISNAME}_OpenQueryCases_Sort}
  {&{&PA-XBASISNAME}_Y_OpenQueryCases_Sort}

  otherwise
    {adm/template/incl/dt_vbs10.if
      &ippSortCaseName = "pa-sortby-case"
      &ippOffsetValue  = "c_offset-value"
    }

end case.

return.

end procedure. /* adm-open-query-cases */

/* _UIB-CODE-BLOCK-END */
&ANALYZE-RESUME

&ANALYZE-SUSPEND _UIB-CODE-BLOCK _PROCEDURE adm-row-available B-table-Win  adm/support/proc/ds_rec00.p
PROCEDURE adm-row-available :
/* Description ---------------------------------------------------------------*/
/*                                                                            */
/* Dispatched to this procedure when the Record-Source has a new row          */
/* available.  This procedure tries to get the new row (or foreign keys)      */
/* from the  Record-Source and process it.                                    */
/*                                                                            */
/* Parameters ----------------------------------------------------------------*/
/*                                                                            */
/* <none>                                                                     */
/*                                                                            */
/*----------------------------------------------------------------------------*/

/*----------------------------------------------------------------------------*/
/* Processing                                                                 */
/*----------------------------------------------------------------------------*/

/* Define variables needed by this internal procedure.                        */

{adm/template/incl/row-head.i}

/* load the accepted/external keys                                            */

{adm/template/incl/dt_key00.if "Artikel" "character" "accepted"}

/* Process the newly available records (i.e. display fields, open queries,    */
/* and/or pass records on to any RECORD-TARGETS).                             */

{adm/template/incl/row-end.i}

end procedure. /* adm-row-available */

/* _UIB-CODE-BLOCK-END */
&ANALYZE-RESUME

&ANALYZE-SUSPEND _UIB-CODE-BLOCK _PROCEDURE getQueryAttribute B-table-Win  adm/support/proc/ds_qat00.p
procedure getQueryAttribute :
/* Description ---------------------------------------------------------------*/
/*                                                                            */
/* return query attribute as requested by parameter                           */
/*                                                                            */
/* Notes ---------------------------------------------------------------------*/
/*                                                                            */
/* This procedure is generated by the app builder.                            */
/*                                                                            */
/* Parameters ----------------------------------------------------------------*/
/*                                                                            */
/* pcAttribute          name of requested attribute                           */
/*                                                                            */
/*----------------------------------------------------------------------------*/

define input  parameter pcAttribute as character no-undo.

/* Variables -----------------------------------------------------------------*/
/*----------------------------------------------------------------------------*/

/* Buffers -------------------------------------------------------------------*/

/*----------------------------------------------------------------------------*/
/* Processing                                                                 */
/*----------------------------------------------------------------------------*/

case pcAttribute:

  when 'l_offen':U then
    return string(l_offen).

  when 'pa-key-Artikel':U then
    return string(pa-key-Artikel).

  otherwise
    undo, throw new adm.method.cls.DMCNotExistingErr
      ('Get browse query attribute':U,'Query attribute':U,pcAttribute).

end case.

end procedure. /* getQueryAttribute */

/* _UIB-CODE-BLOCK-END */
&ANALYZE-RESUME

&ANALYZE-SUSPEND _UIB-CODE-BLOCK _PROCEDURE init-external-keys B-table-Win  adm/support/proc/ds_brw02.p
PROCEDURE init-external-keys :
/* Description ---------------------------------------------------------------*/
/*                                                                            */
/* Reads the external keys from the containers PKS. Needed if the browse is   */
/* used in 'external'-mode to support CTRL-A                                  */
/*                                                                            */
/* Parameters ----------------------------------------------------------------*/
/*                                                                            */
/* c_PKS containers original PKS                                              */
/*                                                                            */
/*----------------------------------------------------------------------------*/

define input parameter c_PKS as char no-undo.

/* Variables -----------------------------------------------------------------*/
/* cTmp   needed internally in dt_brw07.if                                    */
/*----------------------------------------------------------------------------*/

define variable cTmp as char no-undo.

/*----------------------------------------------------------------------------*/
/* Processing                                                                 */
/*----------------------------------------------------------------------------*/

/* load the external keys */

{adm/template/incl/dt_brw07.if "Artikel" "character"}

return.

end procedure. /* init-external-keys */

/* _UIB-CODE-BLOCK-END */
&ANALYZE-RESUME

&ANALYZE-SUSPEND _UIB-CODE-BLOCK _PROCEDURE local-initialize B-table-Win 
PROCEDURE local-initialize :
/* Description ---------------------------------------------------------------*/
/*                                                                            */
/* Super Override                                                             */
/*                                                                            */
/* Notes ---------------------------------------------------------------------*/
/*                                                                            */
/*                                                                            */
/*                                                                            */
/* Parameters ----------------------------------------------------------------*/
/*                                                                            */
/* <none>                                                                     */
/*                                                                            */
/* Examples ------------------------------------------------------------------*/
/*                                                                            */
/*                                                                            */
/*                                                                            */
/*----------------------------------------------------------------------------*/

/* Variables -----------------------------------------------------------------*/
/*----------------------------------------------------------------------------*/

/* Buffers -------------------------------------------------------------------*/

/*----------------------------------------------------------------------------*/
/* Processing                                                                 */
/*----------------------------------------------------------------------------*/

/* Code placed here will execute PRIOR to standard behavior ------------------*/
&IF LOOKUP("U_CI":U,"{&PA-OPTIONEN}":U) > 0 &THEN
gluQuoteVersioning = adm.config.cls.DCCAppConfigSvc:prpoInstance:lParameterValue('UCI_QuoteVersioning':U).
&ENDIF

/* Execute standard behavior -------------------------------------------------*/

run dispatch('initialize':U).

/* Code placed here will execute AFTER standard behavior ---------------------*/

if return-value <> 'ADM-ERROR':U then
do:

  &IF LOOKUP("U_CI":U,"{&PA-OPTIONEN}":U) > 0 &THEN
  assign
    {setwidgetattr
       "V_BelegPos.uAngebot"
       "visible"
       "gluQuoteVersioning"
       "in browse {&BROWSE-NAME}"}
    {setwidgetattr
       "V_BelegPos.uAngebotsversion"
       "visible"
       "gluQuoteVersioning"
       "in browse {&BROWSE-NAME}"}
    .
  &ENDIF

  {info/vert/incl/iv_pos01.if}

end.

end procedure. /* local-initialize */

/* _UIB-CODE-BLOCK-END */
&ANALYZE-RESUME

&ANALYZE-SUSPEND _UIB-CODE-BLOCK _PROCEDURE read-current-offset B-table-Win  adm/support/proc/ds_fin02.p
PROCEDURE read-current-offset :
/* Description ---------------------------------------------------------------*/
/*                                                                            */
/* Get back current key-value                                                 */
/*                                                                            */
/* Parameters ----------------------------------------------------------------*/
/*                                                                            */
/* pcField: name of requested field                                           */
/*                                                                            */
/*----------------------------------------------------------------------------*/

define input parameter pcField as char no-undo.

/*----------------------------------------------------------------------------*/
/* Processing                                                                 */
/*----------------------------------------------------------------------------*/

if available V_BelegPos then

  case pcField:

    when 'BelegNummer':U then
      return string(V_BelegPos.BelegNummer).

    when 'uAngebot':U then
      return string(V_BelegPos.uAngebot).

    {&{&PA-XBASISNAME}_C_CurrentOffset}
    {&{&PA-XBASISNAME}_U_CurrentOffset}
    {&{&PA-XBASISNAME}_Q_CurrentOffset}
    {&{&PA-XBASISNAME}_CurrentOffset}
    {&{&PA-XBASISNAME}_Y_CurrentOffset}

    otherwise
      {adm/template/incl/dt_vbs12.if &ippSortCaseName = "pcField"}

  end case.

return ?.
end procedure. /* read-current-offset */

/* _UIB-CODE-BLOCK-END */
&ANALYZE-RESUME

&ANALYZE-SUSPEND _UIB-CODE-BLOCK _PROCEDURE send-key B-table-Win  adm/support/proc/_key-snd.p
PROCEDURE send-key :
/* Description ---------------------------------------------------------------*/
/*                                                                            */
/* Sends a requested KEY value back to the calling SmartObject                */
/*                                                                            */
/* Parameters ----------------------------------------------------------------*/
/*                                                                            */
/* see adm/template/sndkytop.i                                                */
/*                                                                            */
/*----------------------------------------------------------------------------*/

/*----------------------------------------------------------------------------*/
/* Processing                                                                 */
/*----------------------------------------------------------------------------*/

/* Define variables needed by this internal procedure.                        */

{adm/template/incl/sndkytop.i}

/* Return the key value associated with each key case.                        */

{adm/template/incl/sndkycas.i "BelegArt" "V_BelegPos" "BelegArt" " "}
{adm/template/incl/sndkycas.i "ReferenzNr" "V_BelegPos" "ReferenzNr" " "}
{adm/template/incl/sndkycas.i "LfdNr_SR" "V_BelegPos" "LfdNr_SR" " "}
{adm/template/incl/sndkycas.i "PositionsNr" "V_BelegPos" "PositionsNr" " "}
{adm/template/incl/sndkycas.i "Kunde" "V_BelegKopf" "Kunde" " "}
{adm/template/incl/sndkycas.i "$KEY" "V_BelegPos" " " "vert/incl/v_belpo.sl "}
{adm/template/incl/sndkycas.i "RueckMeldeNr" " " "iRueckMeldeNr" " "}
{adm/template/incl/sndkycas.i "V_BelegPos_Obj" "V_BelegPos" "V_BelegPos_Obj" " "}
{adm/template/incl/sndkycas.i "Origin_Obj" "V_BelegPos" "Origin_Obj" " "}
{adm/template/incl/sndkycas.i "V_BelegKopf_Obj" "V_BelegKopf" "V_BelegKopf_Obj" " "}
{adm/template/incl/sndkycas.i "MMM_CusRefOrder_Obj" "V_BelegPos" "MMM_CusRefOrder_Obj" " "}
{adm/template/incl/sndkycas.i "S_Steuer_Obj" "V_BelegPos" "S_Steuer_Obj" " "}
{adm/template/incl/sndkycas.i "Driver_Obj" "V_BelegPos" "Driver_Obj" " "}
{adm/template/incl/sndkycas.i "SBM_BusinessCategory_Obj" "V_BelegPos" "SBM_BusinessCategory_Obj" " "}
{adm/template/incl/sndkycas.i "SBM_CustomsTariffNo_Obj" "V_BelegPos" "SBM_CustomsTariffNo_Obj" " "}
{adm/template/incl/sndkycas.i "Sys_S_Steuer_Obj" "V_BelegPos" "Sys_S_Steuer_Obj" " "}
{adm/template/incl/sndkycas.i "Owning_Obj" "V_BelegPos" "V_BelegPos_Obj" " "}

/* Close the CASE statement and end the procedure.                            */

{adm/template/incl/sndkyend.i}

end procedure. /* send-key */

/* _UIB-CODE-BLOCK-END */
&ANALYZE-RESUME

&ANALYZE-SUSPEND _UIB-CODE-BLOCK _PROCEDURE send-records B-table-Win  adm/support/proc/ds_rec01.p
PROCEDURE send-records :
/* Description ---------------------------------------------------------------*/
/*                                                                            */
/* Send record ROWID's for all tables used by this file.                      */
/*                                                                            */
/* Parameters ----------------------------------------------------------------*/
/*                                                                            */
/* see template/incl/snd-head.i                                               */
/*                                                                            */
/*----------------------------------------------------------------------------*/

/*----------------------------------------------------------------------------*/
/* Processing                                                                 */
/*----------------------------------------------------------------------------*/

/* Define variables needed by this internal procedure.                        */

{adm/template/incl/snd-head.i}

/* For each requested table, put it's ROWID in the output list.               */

{adm/template/incl/snd-list.i "V_BelegPos"}

/* Deal with any unexpected table requests before closing.                    */

{adm/template/incl/snd-end.i}

end procedure. /* send-records */

/* _UIB-CODE-BLOCK-END */
&ANALYZE-RESUME

&ANALYZE-SUSPEND _UIB-CODE-BLOCK _PROCEDURE state-changed B-table-Win 
PROCEDURE state-changed :
/* Description ---------------------------------------------------------------*/
/*                                                                            */
/* Handle state-changed messages                                              */
/*                                                                            */
/* Notes ---------------------------------------------------------------------*/
/*                                                                            */
/*                                                                            */
/*                                                                            */
/* Parameters ----------------------------------------------------------------*/
/*                                                                            */
/* p-issuer-hdl   Handle of calling object                                    */
/* p-state        new state                                                   */
/*                                                                            */
/* Examples ------------------------------------------------------------------*/
/*                                                                            */
/*                                                                            */
/*                                                                            */
/*----------------------------------------------------------------------------*/

define input        parameter p-issuer-hdl as handle        no-undo.
define input        parameter p-state      as character     no-undo.

/* Variables -----------------------------------------------------------------*/
/*----------------------------------------------------------------------------*/

/* Buffers -------------------------------------------------------------------*/

/*----------------------------------------------------------------------------*/
/* Processing                                                                 */
/*----------------------------------------------------------------------------*/

  CASE p-state:
      /* Object instance CASEs can go here to replace standard behavior
         or add new cases. */
    {adm/template/incl/dt_brw00.if}
  END CASE.
end procedure.

/* _UIB-CODE-BLOCK-END */
&ANALYZE-RESUME

