&ANALYZE-SUSPEND _VERSION-NUMBER UIB_v8r12 GUI
&ANALYZE-RESUME
/* Connected Databases 
          temp-db          PROGRESS
*/
&Scoped-define WINDOW-NAME CURRENT-WINDOW

&ANALYZE-SUSPEND _UIB-CODE-BLOCK _CUSTOM _DECLARATIONS B-table-Win 

/* _UIB-CODE-BLOCK-END */
&ANALYZE-RESUME


&ANALYZE-SUSPEND _UIB-CODE-BLOCK _XFTR "Update Information" B-table-Win _INLINE
/* Actions: ? ? ? ? adm/support/proc/ds_pa_01.w */

/* _UIB-CODE-BLOCK-END */
&ANALYZE-RESUME



/* Temp-Table and Buffer definitions                                    */
DEFINE TEMP-TABLE TT_E_BelegPos NO-UNDO LIKE TD_E_BelegPos.


&ANALYZE-SUSPEND _UIB-CODE-BLOCK _CUSTOM _DEFINITIONS B-table-Win 
/*****************************************************************************/
/* @COPYRIGHT@                                                               */
/*                                                                           */
/*  Projekt....: Proalpha                                                    */
/*                                                                           */
/*  Name.......: e_bab_11.w                                                  */
/*  Bereich....: EINK/KERN                                                   */
/*                                                                           */
/*  erstellt am: 13.10.1997                                                  */
/*  Autor......: Ingrid Gr�nder                                              */
/*                                                                           */
/*  Version....: @PAVERSION@ vom @PADATE@/@PALASTAUTHOR@                     */
/*                                                                           */
/*---------------------------------------------------------------------------*/
/*  AUFGABE                                                                  */
/*---------------------------------------------------------------------------*/
/*                                                                           */
/*  Browser der Bestellpositionen f�r �bernahme in AB                        */
/*                                                                           */
/*---------------------------------------------------------------------------*/
/*  ARGUMENTE/PARAMETER                                                      */
/*---------------------------------------------------------------------------*/
/*                                                                           */
/*  Name                Art Funktion/Inhalt                                  */
/*  ------------------- --- ------------------------------------------------ */
/*---------------------------------------------------------------------------*/
/*  �NDERUNGSPROTOKOLL                                                       */
/*---------------------------------------------------------------------------*/
/* @FILEHISTORY@                                                             */
/*****************************************************************************/

/*----------------------------------------------------------------------     */
/*          This .W file was created with the Progress UIB.                  */
/*----------------------------------------------------------------------     */

/* Create an unnamed pool to store all the widgets created
     by this procedure. This is a good default which assures
     that this procedure's triggers and internal procedures
     will execute in this procedure's storage, and that proper
     cleanup will occur on deletion of the procedure. */

create widget-pool.

/*---------------------------------------------------------------------------*/
/* Definitionen                                                              */
/*---------------------------------------------------------------------------*/

/* KONSTANTEN ---------------------------------------------------------------*/
/* Systemkonstanten **********************************************************/

&GLOBAL-DEFINE pa-Autor             Ingrid Gr�nder
&GLOBAL-DEFINE pa-Version           @PAVERSION@
&GLOBAL-DEFINE pa-Datum             @PADATE@
&GLOBAL-DEFINE pa-Letzter           @PALASTAUTHOR@

&GLOBAL-DEFINE pa-GenVersion       UIB
&GLOBAL-DEFINE pa-ProgrammTyp      SmartBrowser
&GLOBAL-DEFINE pa-Template         adm/template/proc/dt_brw00.w
&GLOBAL-DEFINE pa-TemplateVersion  1.04

&GLOBAL-DEFINE pa-XBasisName       e_bab_11_w


/* lokale Konstanten *********************************************************/

&GLOBAL-DEFINE exclude-adm-copy-source        yes
&GLOBAL-DEFINE exclude-adm-select-copy-source yes


&Scoped-define pa-hlp-fieldnames Lagerort BestellNr
&Scoped-define pa-hlp-keynames Storagearea 


/* EXTERNE DEFINITIONEN -----------------------------------------------------*/

{adm/template/incl/dt_brw00.df}

&IF LOOKUP("U_CI":U,"{&PA-OPTIONEN}":U) > 0 &THEN
  &Scoped-define K_TT_E_BelegPos_uCI_ReqDeliveryDate TT_E_BelegPos.uCI_ReqDeliveryDate
&ENDIF


/* LOKALE OBJEKTE -----------------------------------------------------------*/
/* Variable ******************************************************************/
/*   Name                 Funktion                                           */
/*   -------------------  -------------------------------------------------- */
/*                                                                           */
/*   gcTargetObj          transferred ObjectId of EBT_Delivery               */
/*   gcSourceDocType      either those of E_BelegKopf (EB,EAB,ERL) or ECO    */
/*   gcTargetDocType      either 'EBB' or 'EDA'                              */
/*   ... gdproz_RZ_3        E_BelegPos and EBT_DeliveryPos                   */
/*   gdQtySuggested   Quantity which is sugggested, when the browser is      */
/*                    opened (temporarily used as work around for Progress   */
/*                    bug up to Progress Version 10.1B01 (call 51137).       */
/*   glStorAreaValid      The storage area is not valid, if it does not      */
/*                        belong to the given warehouse.                     */
/*   gcDocNoFormat    is needed, because it can not be queried in            */
/*                    row-display trigger                                    */
/*                                                                           */
/*****************************************************************************/

define variable giReferenzNr        like E_AB_Kopf.ReferenzNr          no-undo.
define variable gcTargetObj         like EBT_Delivery.EBT_Delivery_Obj no-undo.
define variable gcSourceDocType     like E_BelegKopf.Belegart          no-undo.
define variable gcTargetDocType     like E_BelegKopf.BelegArt          no-undo.
define variable gcSource_Obj        like E_BelegKopf.E_BelegKopf_Obj   no-undo.
define variable gcEntryField        as   character                     no-undo.
define variable glAbfrage           as   logical                       no-undo.
define variable glFehler            as   logical                       no-undo.
define variable glCancelRecord      as   logical                       no-undo.
define variable glCancelAdoption    as   logical                       no-undo.
define variable glStorAreaValid     as   logical                       no-undo init yes.
define variable glWrongInput        as   logical                       no-undo.
define variable gdPositionsNrAlt    like E_BelegPos.PositionsNr        no-undo init ?.
define variable gdLastABPos         like E_BelegPos.PositionsNr        no-undo init ?.
define variable gdEinzelpreis       like E_BelegPos.Einzelpreis        no-undo.
define variable gdLABFZGes          like EBL_Progress.GesFZ            no-undo column-label 'LAB-FZ (ges)':R12.
define variable gdWert_RZ_1         like E_BelegPos.Wert_RZ_1          no-undo.
define variable gdWert_RZ_2         like E_BelegPos.Wert_RZ_2          no-undo.
define variable gdproz_RZ_1         like E_BelegPos.proz_RZ_1          no-undo.
define variable gdproz_RZ_2         like E_BelegPos.proz_RZ_2          no-undo.
define variable gdproz_RZ_3         like E_BelegPos.proz_RZ_3          no-undo.
define variable gdQtySuggested      like E_BelegPos.Menge              no-undo.
define variable gdQuantity          like E_BelegPos.Menge              no-undo.
define variable giTargetFunction    as   integer                       no-undo.
define variable gcKommissionsnummer like E_BelegPos.MMM_CusRefOrder_ID no-undo.
define variable glUpdateComplete    as   logical                       no-undo.
define variable glDateSplit         as   logical                       no-undo.
define variable glProtocol          as   logical                       no-undo init ?.
define variable gcDocNoFormat       as   character                     no-undo. 

/* Buffer ********************************************************************/

define buffer EBL_Progress for EBL_Progress.
define buffer gbS_Artikel  for S_Artikel.

/* Work-/Temp-Tables *********************************************************/

&IF lookup("EB_DESADV":U,"{&PA-OPTIONEN}":U) > 0 &THEN
  {eink/incl/e__bel10.lib}
&ENDIF

/* ttMM_MRPLinkAPI                                                           */
{mawi/base/incl/mm_mrp11.tdf
  &ippNoReferenceOnlySwitch = "yes"
}

/* _UIB-CODE-BLOCK-END */
&ANALYZE-RESUME


&ANALYZE-SUSPEND _UIB-PREPROCESSOR-BLOCK 

/* ********************  Preprocessor Definitions  ******************** */

&Scoped-define PROCEDURE-TYPE Proalpha-SmartBrowser
&Scoped-define DB-AWARE no

&Scoped-define ADM-SUPPORTED-LINKS Record-Source,Record-Target,TableIO-Target,Navigation-Target

/* Name of designated FRAME-NAME and/or first browse and/or first query */
&Scoped-define FRAME-NAME F-Main
&Scoped-define BROWSE-NAME br_table

/* Internal Tables (found by Frame, Query & Browse Queries)             */
&Scoped-define INTERNAL-TABLES TT_E_BelegPos

/* Define KEY-PHRASE in case it is used by any query. */
&Scoped-define KEY-PHRASE TRUE

/* Definitions for BROWSE br_table                                      */
/* --> MO#ABT-IVC-0049 thongdi_p 15.07.2026 Erfassung und Auswahl Teile-LieferantenNr Auftragsbest�tigung */
/* add TT_E_BelegPos.BestellNr ~ */
&Scoped-define FIELDS-IN-QUERY-br_table find-additional-records() @ TT_E_BelegPos.PositionsNr TT_E_BelegPos.Belegnummer TT_E_BelegPos.Artikel TT_E_BelegPos.Bezeichnung TT_E_BelegPos.BestellNr TT_E_BelegPos.AB_PositionsNr TT_E_BelegPos.LieferantenCharge TT_E_BelegPos.LagerOrt gcKommissionsnummer TT_E_BelegPos.Menge TT_E_BelegPos.MEBez gdLABFZGes TT_E_BelegPos.Bestellmenge TT_E_BelegPos.gelieferte_Menge TT_E_BelegPos.TransitQty TT_E_BelegPos.Wunschtermin TT_E_BelegPos.Liefertermin gdEinzelpreis gdWert_RZ_1 gdWert_RZ_2 gdproz_RZ_1 gdproz_RZ_2 gdproz_RZ_3 TT_E_BelegPos.Warenwert_offen TT_E_BelegPos.WaeBez TT_E_BelegPos.SperreArtikel {&K_TT_E_BelegPos_uCI_ReqDeliveryDate} {&{&PA-XBASISName}_C_BROWSEDISPLAY} {&{&PA-XBASISName}_U_BROWSEDISPLAY} {&{&PA-XBASISName}_Q_BROWSEDISPLAY} {&{&PA-XBASISNAME}_BROWSEDISPLAY} {&{&PA-XBASISName}_Y_BROWSEDISPLAY}   
&Scoped-define ENABLED-FIELDS-IN-QUERY-br_table TT_E_BelegPos.Lagerort ~
TT_E_BelegPos.LieferantenCharge ~
TT_E_BelegPos.AB_PositionsNr ~
TT_E_BelegPos.Menge ~
TT_E_BelegPos.BestellNr ~
TT_E_BelegPos.Liefertermin   
&Scoped-define ENABLED-TABLES-IN-QUERY-br_table TT_E_BelegPos
&Scoped-define FIRST-ENABLED-TABLE-IN-QUERY-br_table TT_E_BelegPos
&Scoped-define SELF-NAME br_table
&Scoped-define QUERY-STRING-br_table ~{&PA-VIRTUAL-INDEX-PHRASE} EACH TT_E_BelegPos WHERE ~{&KEY-PHRASE} NO-LOCK ~{&SORTBY-PHRASE}
&Scoped-define OPEN-QUERY-br_table OPEN QUERY {&SELF-NAME} ~{&PA-VIRTUAL-INDEX-PHRASE} EACH TT_E_BelegPos WHERE ~{&KEY-PHRASE} NO-LOCK ~{&SORTBY-PHRASE}.
&Scoped-define TABLES-IN-QUERY-br_table TT_E_BelegPos
&Scoped-define FIRST-TABLE-IN-QUERY-br_table TT_E_BelegPos
/* <-- MO#ABT-IVC-0049 thongdi_p 15.07.2026 Erfassung und Auswahl Teile-LieferantenNr Auftragsbest�tigung */

/* Definitions for FRAME F-Main                                         */

/* Standard List Definitions                                            */
&Scoped-Define ENABLED-OBJECTS br_table BtnPackage Btn_Abrufe Btn_Termin 

/* Custom List Definitions                                              */
/* List-1,List-2,List-3,List-4,List-5,List-6                            */

/* _UIB-PREPROCESSOR-BLOCK-END */
&ANALYZE-RESUME


&ANALYZE-SUSPEND _UIB-CODE-BLOCK _XFTR "Foreign Keys" B-table-Win _INLINE
/* Actions: ? adm/support/proc/keyedit.w ? ? ? */
/* STRUCTURED-DATA
<KEY-OBJECT>
&BROWSE-NAME
</KEY-OBJECT>
<FOREIGN-KEYS>
Belegart||y|TT_E_BelegPos.Belegart||||||
ReferenzNr||y|TT_E_BelegPos.ReferenzNr||||||
PositionsNr||y|TT_E_BelegPos.PositionsNr||||||
Source_Obj||y|TT_E_BelegPos.Source_Obj||||||
$KEY||y|temp-db.TT_E_BelegPos|eink/incl/e_belpo.sl|||||
E_BelegPos_Obj||y|TT_E_BelegPos.E_BelegPos_Obj||||||
</FOREIGN-KEYS>
<EXECUTING-CODE>
**************************
* Set attributes related to FOREIGN KEYS
*/
/* --> MO#ABT-IVC-0049 thongdi_p 16.07.2026 Erfassung und Auswahl Teile-LieferantenNr Auftragsbest�tigung */
/* add Keys-Supplied Lieferant */
run set-attribute-list (
    'Keys-Accepted = ,
     Keys-External = ,
     Keys-Supplied = "Lieferant,Belegart,ReferenzNr,PositionsNr,Source_Obj,$KEY,E_BelegPos_Obj"':U).
/* <-- MO#ABT-IVC-0049 thongdi_p 16.07.2026 Erfassung und Auswahl Teile-LieferantenNr Auftragsbest�tigung */


/* Tell the ADM to use the OPEN-QUERY-CASES. */
&Scoped-define OPEN-QUERY-CASES run dispatch ('open-query-cases':U).
/**************************
</EXECUTING-CODE> */
/* _UIB-CODE-BLOCK-END */
&ANALYZE-RESUME

&ANALYZE-SUSPEND _UIB-CODE-BLOCK _XFTR "Advanced Query Options" B-table-Win _INLINE
/* Actions: ? adm/support/proc/advqedit.w ? ? ? */
/* STRUCTURED-DATA
<KEY-OBJECT>
&BROWSE-NAME
</KEY-OBJECT>
<SORTBY-OPTIONS>
PositionsNr|y||Temp-Tables.TT_E_BelegPos.PositionsNr|yes
BestellNr|||Temp-DB.TT_E_BelegPos.BestellNr|yes
LagerOrt|||Temp-DB.TT_E_BelegPos.LagerOrt|yes
</SORTBY-OPTIONS>
<SORTBY-RUN-CODE>
************************
* Set attributes related to SORTBY-OPTIONS */
run set-attribute-list (
    'SortBy-Options = "PositionsNr,BestellNr,LagerOrt",
     SortBy-Case = PositionsNr':U).

/* Tell the ADM to use the OPEN-QUERY-CASES. */
&Scoped-define OPEN-QUERY-CASES run dispatch ('open-query-cases':U).

/* set up order-direction */
&Scoped-define PA-DESCENDING-SORT NO
run set-attribute-list ('pa-SortDirectionChangeEnabled=yes':U).

/* This SmartObject is a valid SortBy-Target. */
&IF '{&USER-SUPPORTED-LINKS}':U NE '':U &THEN
  &SCOPED-DEFINE user-supported-links {&USER-SUPPORTED-LINKS},SortBy-Target
&ELSE
  &SCOPED-DEFINE user-supported-links SortBy-Target
&ENDIF

/************************
</SORTBY-RUN-CODE>
<FILTER-ATTRIBUTES>
</FILTER-ATTRIBUTES> */

/* _UIB-CODE-BLOCK-END */
&ANALYZE-RESUME

&ANALYZE-SUSPEND _UIB-CODE-BLOCK _XFTR "Find Builder" B-table-Win _INLINE
/* Actions: ? adm/support/proc/ds_sma00.w ? ? adm/support/proc/ds_fin00.p */
/* STRUCTURED-DATA
<ADDITIONAL-INFORMATION EDITABLE></ADDITIONAL-INFORMATION EDITABLE>

<GET-OFFSET-INFO>
TT_E_BelegPos.PositionsNr,string(TT_E_BelegPos.PositionsNr)|Main
TT_E_BelegPos.BestellNr,TT_E_BelegPos.BestellNr|BestellNr
TT_E_BelegPos.LagerOrt,string(TT_E_BelegPos.LagerOrt)|LagerOrt
</GET-OFFSET-INFO>
<FIND-STATEMENT>
********/
&GLOBAL-DEFINE FIND-STATEMENT ~
case pa-sortby-case: ~
  when 'PositionsNr':U then ~
    find ~{&FIND-OPTION} TT_E_BelegPos ~
      where yes  ~
      &IF DEFINED(OFFSET-VALUE) > 0 &THEN ~
        and TT_E_BelegPos.PositionsNr ~{&OFFSET-COMPARE} decimal(~{&OFFSET-VALUE}) ~
      &ENDIF ~
      use-index Main ~
      no-lock no-error. ~
  when 'BestellNr':U then ~
    find ~{&FIND-OPTION} TT_E_BelegPos ~
      where yes  ~
      &IF DEFINED(OFFSET-VALUE) > 0 &THEN ~
        and TT_E_BelegPos.BestellNr ~{&OFFSET-COMPARE} ~{&OFFSET-VALUE} ~
      &ENDIF ~
      use-index BestellNr ~
      no-lock no-error. ~
  when 'LagerOrt':U then ~
    find ~{&FIND-OPTION} TT_E_BelegPos ~
      where yes  ~
      &IF DEFINED(OFFSET-VALUE) > 0 &THEN ~
        and TT_E_BelegPos.LagerOrt ~{&OFFSET-COMPARE} integer(~{&OFFSET-VALUE}) ~
      &ENDIF ~
      use-index LagerOrt ~
      no-lock no-error. ~
  {&{&PA-XBASISNAME}_C_FindStatement} ~
  {&{&PA-XBASISNAME}_U_FindStatement} ~
  {&{&PA-XBASISNAME}_Q_FindStatement} ~
  {&{&PA-XBASISNAME}_FindStatement} ~
  {&{&PA-XBASISNAME}_Y_FindStatement} ~
  ~{adm/template/incl/dt_vbs13.if &ippSortCaseName = "pa-sortby-case"}~
  end case.
&SCOP INTERNAL-TABLES {&INTERNAL-TABLES} E_BelegPos EBL_Progress
/********
</FIND-STATEMENT>  */
/* _UIB-CODE-BLOCK-END */
&ANALYZE-RESUME

&ANALYZE-SUSPEND _UIB-CODE-BLOCK _XFTR "Find-Trigger" B-table-Win _INLINE
/* Actions: ? adm/support/proc/ds_sma00.w ? ? ? */

function find-additional-records returns decimal ( ) :

define variable tDate like EBL_Progress.Datum no-undo.

if available TT_E_BelegPos then
do:

  if gcSourceDocType <> 'ECO':U then
  do:

    find E_BelegPos
      where rowid (E_BelegPos) = to-rowid (TT_E_BelegPos.RowidString)
      no-lock.

    assign
      gdEinzelpreis       = E_BelegPos.Einzelpreis
      gdWert_RZ_1         = E_BelegPos.Wert_RZ_1
      gdWert_RZ_2         = E_BelegPos.Wert_RZ_2
      gdproz_RZ_1         = E_BelegPos.proz_RZ_1
      gdproz_RZ_2         = E_BelegPos.proz_RZ_2
      gdproz_RZ_3         = E_BelegPos.proz_RZ_3   
      gcKommissionsnummer = E_BelegPos.MMM_CusRefOrder_ID    
      .
    
  end. /* else do: */

  /* Find the whole release progress */

  if    gcTargetDocType = 'EDA':U
    and available EBT_CallOrder then
  do:

    gcKommissionsnummer = EBT_CallOrder.MMM_CusRefOrder_ID.

    find last EBL_Progress
      where EBL_Progress.EBT_CallOrder_Obj = EBT_CallOrder.EBT_CallOrder_Obj
        and EBL_Progress.Art               = '1':U
      no-lock no-error.

    if available EBL_Progress then
    do:

      /* If several records to a date exist, then the record with the         */
      /* greatest counter (LfdNr) is read.                                    */

      tDate = EBL_Progress.Datum.

      find last EBL_Progress
        where EBL_Progress.EBT_CallOrder_Obj = EBT_CallOrder.EBT_CallOrder_Obj
          and EBL_Progress.Datum             = tDate
          and EBL_Progress.Art               = '1':U
        use-index Main
        no-lock.

      gdLABFZGes = EBL_Progress.FZ.

    end. /* if available EBL_Progress */

  end. /* if    gcTargetDocType = 'EDA':U */

  {&{&PA-XBASISName}_C_FIND-TRIGGER_FIND}
  {&{&PA-XBASISName}_U_FIND-TRIGGER_FIND}
  {&{&PA-XBASISName}_Q_FIND-TRIGGER_FIND}
  {&{&PA-XBASISNAME}_FIND-TRIGGER_FIND}
  {&{&PA-XBASISName}_Y_FIND-TRIGGER_FIND}

  return TT_E_BelegPos.PositionsNr.

end. /* if available TT_E_BelegPos */

else
do:

  release E_BelegPos.
  release EBL_Progress.

  {&{&PA-XBASISName}_C_FIND-TRIGGER_RELEASE}
  {&{&PA-XBASISName}_U_FIND-TRIGGER_RELEASE}
  {&{&PA-XBASISName}_Q_FIND-TRIGGER_RELEASE}
  {&{&PA-XBASISNAME}_FIND-TRIGGER_RELEASE}
  {&{&PA-XBASISName}_Y_FIND-TRIGGER_RELEASE}
  return ?.
end.

end function.

&SCOP PA-FIND-DUMMY define variable pa-find-dummy as decimal no-undo.


/* _UIB-CODE-BLOCK-END */
&ANALYZE-RESUME

&ANALYZE-SUSPEND _UIB-CODE-BLOCK _XFTR "Window Title" B-table-Win _INLINE
/* Actions: ? adm/support/proc/ds_sma00.w ? ? adm/support/proc/ds_ttl00.p */
/* STRUCTURED-DATA
<TITLE-CODE EDITABLE>
(if available E_BelegKopf then
   string(E_BelegKopf.Belegnummer)
 else if available EBT_CallOrder then
   string(EBT_CallOrder.Belegnummer)
 else
   '':U)
</TITLE-CODE EDITABLE>
<CONSTANTS>
**/
&SCOP PA-TITLE-CODE ~
(if available E_BelegKopf then ~
   string(E_BelegKopf.Belegnummer) ~
 else if available EBT_CallOrder then ~
   string(EBT_CallOrder.Belegnummer) ~
 else ~
   '':U)
/**
</CONSTANTS>  */
/* _UIB-CODE-BLOCK-END */
&ANALYZE-RESUME

&ANALYZE-SUSPEND _UIB-CODE-BLOCK _XFTR "Skin Client Support" B-table-Win _INLINE
/* Actions: ? ? ? ? adm/support/proc/ds_skc00.p */
/* _UIB-CODE-BLOCK-END */
&ANALYZE-RESUME

/* ************************  Function Prototypes ********************** */

&ANALYZE-SUSPEND _UIB-CODE-BLOCK _FUNCTION-FORWARD cAktuellePositionsnummern B-table-Win 
FUNCTION cAktuellePositionsnummern returns character
  ( )  FORWARD.

/* _UIB-CODE-BLOCK-END */
&ANALYZE-RESUME

&ANALYZE-SUSPEND _UIB-CODE-BLOCK _FUNCTION-FORWARD dBestaetigteMenge B-table-Win 
FUNCTION dBestaetigteMenge returns decimal
  ( pcRowidString as character)  FORWARD.

/* _UIB-CODE-BLOCK-END */
&ANALYZE-RESUME

&ANALYZE-SUSPEND _UIB-CODE-BLOCK _FUNCTION-FORWARD lCheckStorageAreaOK B-table-Win 
FUNCTION lCheckStorageAreaOK returns logical
  ( plSaveButtonPressed   as logical,
    piStorageArea         as integer,
    pcPart                as character,
    prRowID_TT_E_BelegPos as rowid )  FORWARD.

/* _UIB-CODE-BLOCK-END */
&ANALYZE-RESUME


/* ***********************  Control Definitions  ********************** */


/* Definitions of the field level widgets                               */
DEFINE BUTTON Btn_Abrufe 
     LABEL "Lieferplante&rmine":T18 
     SIZE 20 BY 1.

DEFINE BUTTON Btn_Termin 
     LABEL "Termin&zuordnung":C20 
     SIZE 26 BY 1.

DEFINE BUTTON BtnPackage 
     LABEL "Packmittel":T18 
     SIZE 20 BY 1.

/* Query definitions                                                    */
&ANALYZE-SUSPEND
DEFINE QUERY br_table FOR 
      &IF defined(PA-CHECK-BROWSE-CONFIGURATION-SUPPORT) &THEN
        &IF {&PA-CHECK-BROWSE-CONFIGURATION-SUPPORT} &THEN
        DBT_VirtualIndex,
        &ENDIF
      &ENDIF
      TT_E_BelegPos SCROLLING.
&ANALYZE-RESUME

/* Browse definitions                                                   */
DEFINE BROWSE br_table
&ANALYZE-SUSPEND _UIB-CODE-BLOCK _DISPLAY-FIELDS br_table B-table-Win _FREEFORM
  QUERY br_table NO-LOCK DISPLAY
      find-additional-records() @ TT_E_BelegPos.PositionsNr
      TT_E_BelegPos.Belegnummer
      TT_E_BelegPos.Artikel      
      TT_E_BelegPos.Bezeichnung
      TT_E_BelegPos.BestellNr
      TT_E_BelegPos.AB_PositionsNr
      TT_E_BelegPos.LieferantenCharge
      TT_E_BelegPos.LagerOrt      
      gcKommissionsnummer
      TT_E_BelegPos.Menge
      TT_E_BelegPos.MEBez
      gdLABFZGes
      TT_E_BelegPos.Bestellmenge
      TT_E_BelegPos.gelieferte_Menge
      TT_E_BelegPos.TransitQty   column-label 'Transitmenge':T12
      TT_E_BelegPos.Wunschtermin
      TT_E_BelegPos.Liefertermin
      gdEinzelpreis      
      gdWert_RZ_1
      gdWert_RZ_2
      gdproz_RZ_1
      gdproz_RZ_2
      gdproz_RZ_3      
      TT_E_BelegPos.Warenwert_offen
      TT_E_BelegPos.WaeBez
      TT_E_BelegPos.SperreArtikel
      
      {&K_TT_E_BelegPos_uCI_ReqDeliveryDate}
      {&{&PA-XBASISName}_C_BROWSEDISPLAY}
      {&{&PA-XBASISName}_U_BROWSEDISPLAY}
      {&{&PA-XBASISName}_Q_BROWSEDISPLAY}
      {&{&PA-XBASISNAME}_BROWSEDISPLAY}
      {&{&PA-XBASISName}_Y_BROWSEDISPLAY}
  ENABLE
      TT_E_BelegPos.Lagerort
      TT_E_BelegPos.LieferantenCharge
      TT_E_BelegPos.AB_PositionsNr
      TT_E_BelegPos.Menge
      /* --> MO#ABT-IVC-0049 thongdi_p 15.07.2026 Erfassung und Auswahl Teile-LieferantenNr Auftragsbest�tigung */
      TT_E_BelegPos.BestellNr
      /* <-- MO#ABT-IVC-0049 thongdi_p 15.07.2026 Erfassung und Auswahl Teile-LieferantenNr Auftragsbest�tigung */      
      TT_E_BelegPos.Liefertermin
/* _UIB-CODE-BLOCK-END */
&ANALYZE-RESUME
    WITH NO-ASSIGN SEPARATORS SIZE 128 BY 8.38.


/* ************************  Frame Definitions  *********************** */

DEFINE FRAME F-Main
     br_table AT ROW 1 COL 1
     BtnPackage AT ROW 9.88 COL 52.5
     Btn_Abrufe AT ROW 9.92 COL 3
     Btn_Termin AT ROW 9.92 COL 25
    WITH 1 DOWN NO-BOX KEEP-TAB-ORDER OVERLAY 
         SIDE-LABELS NO-UNDERLINE THREE-D 
         AT COL 1 ROW 1 SCROLLABLE .


/* *********************** Procedure Settings ************************ */

&ANALYZE-SUSPEND _PROCEDURE-SETTINGS
/* Settings for THIS-PROCEDURE
   Type: Proalpha-SmartBrowser
   Allow: Basic,Browse
   Frames: 1
   Add Fields to: External-Tables
   Other Settings: PERSISTENT-ONLY
   Temp-Tables and Buffers:
      TABLE: TT_E_BelegPos T "?" NO-UNDO temp-db TD_E_BelegPos
   END-TABLES.
 */

/* This procedure should always be RUN PERSISTENT.  Report the error,  */
/* then cleanup and return.                                            */
IF NOT THIS-PROCEDURE:PERSISTENT THEN DO:
  MESSAGE "{&FILE-NAME} should only be RUN PERSISTENT.":U
          VIEW-AS ALERT-BOX ERROR BUTTONS OK.
  RETURN.
END.

&ANALYZE-RESUME _END-PROCEDURE-SETTINGS

/* *************************  Create Window  ************************** */

&ANALYZE-SUSPEND _CREATE-WINDOW
/* DESIGN Window definition (used by the UIB) 
  CREATE WINDOW B-table-Win ASSIGN
         HEIGHT             = 10
         WIDTH              = 128.17.
/* END WINDOW DEFINITION */
                                                                        */
&ANALYZE-RESUME

&ANALYZE-SUSPEND _UIB-CODE-BLOCK _CUSTOM _INCLUDED-LIB B-table-Win 
/* ************************* Included-Libraries *********************** */

{adm/method/incl/dm_brw01.lib}

/* _UIB-CODE-BLOCK-END */
&ANALYZE-RESUME




/* ***********  Runtime Attributes and AppBuilder Settings  *********** */

&ANALYZE-SUSPEND _RUN-TIME-ATTRIBUTES
/* SETTINGS FOR WINDOW B-table-Win
  NOT-VISIBLE,,RUN-PERSISTENT                                           */
/* SETTINGS FOR FRAME F-Main
   NOT-VISIBLE FRAME-NAME Size-to-Fit                                   */
/* BROWSE-TAB br_table 1 F-Main */
ASSIGN 
       FRAME F-Main:SCROLLABLE       = FALSE
       FRAME F-Main:HIDDEN           = TRUE.

/* _RUN-TIME-ATTRIBUTES-END */
&ANALYZE-RESUME


/* Setting information for Queries and Browse Widgets fields            */

&ANALYZE-SUSPEND _QUERY-BLOCK BROWSE br_table
/* Query rebuild information for BROWSE br_table
     _START_FREEFORM
OPEN QUERY {&SELF-NAME} FOR EACH TT_E_BelegPos WHERE ~{&KEY-PHRASE} NO-LOCK
    ~{&SORTBY-PHRASE}.
     _END_FREEFORM
     _Options          = "NO-LOCK KEY-PHRASE SORTBY-PHRASE"
     _Query            is NOT OPENED
*/  /* BROWSE br_table */
&ANALYZE-RESUME

&ANALYZE-SUSPEND _QUERY-BLOCK FRAME F-Main
/* Query rebuild information for FRAME F-Main
     _Options          = "NO-LOCK"
     _Query            is NOT OPENED
*/  /* FRAME F-Main */
&ANALYZE-RESUME





/* ************************  Control Triggers  ************************ */

&Scoped-define BROWSE-NAME br_table
&Scoped-define SELF-NAME br_table
&ANALYZE-SUSPEND _UIB-CODE-BLOCK _CONTROL br_table B-table-Win
ON row-display OF br_table IN FRAME F-Main
do:

  {adm/template/incl/dt_uit00.if
     &UserExitName = "ON_ROW-DISPLAY_OF_br_table"}

  if    available E_BelegKopf
    and available TT_E_BelegPos then

    assign
      {adm/incl/d__bcf00.if
         &BrowseCellColumn = "gdEinzelpreis"
         &ToFormat         = "entry(E_BelegKopf.WaehrungNK + 1,{&pa_WERTGESAMTFORMAT},{&PA-DELIMITER4})"
         &WithFrame        = "in browse {&browse-name}"}
      {adm/incl/d__bcf00.if
         &BrowseCellColumn = "gdWert_RZ_1"
         &ToFormat         = "entry(E_BelegKopf.WaehrungNK + 1,{&pa_WERTGESAMTFORMAT},{&PA-DELIMITER4})"
         &WithFrame        = "in browse {&browse-name}"}
      {adm/incl/d__bcf00.if
         &BrowseCellColumn = "gdWert_RZ_2"
         &ToFormat         = "entry(E_BelegKopf.WaehrungNK + 1,{&pa_WERTGESAMTFORMAT},{&PA-DELIMITER4})"
         &WithFrame        = "in browse {&browse-name}"}
      {adm/incl/d__bcf00.if
         &BrowseCellTable  = "TT_E_BelegPos"
         &BrowseCellColumn = "Warenwert_offen"
         &ToFormat         = "entry(E_BelegKopf.WaehrungNK + 1,{&pa_WERTGESAMTFORMAT},{&PA-DELIMITER4})"
         &WithFrame        = "in browse {&browse-name}"}
      .

  if   (   available E_BelegKopf
        or available EBT_CallOrder)
    and available TT_E_BelegPos then

    assign
      TT_E_BelegPos.Belegnummer = (if available E_BelegKopf then
                                     E_BelegKopf.Belegnummer
                                   else
                                     EBT_CallOrder.Belegnummer)
      {adm/incl/d__bcf00.if
         &BrowseCellTable  = "TT_E_BelegPos"
         &BrowseCellColumn = "Belegnummer"
         &ToFormat         = "gcDocNoFormat"
         &WithFrame        = "in browse {&browse-name}"}                                     
      {adm/incl/d__bcf00.if
         &BrowseCellTable  = "TT_E_BelegPos"
         &BrowseCellColumn = "Menge"
         &ToFormat         = "entry(TT_E_BelegPos.NachKomma + 1,{&PA_MENGENEINGABEFORMAT},{&PA-DELIMITER4})"
         &WithFrame        = "in browse {&browse-name}"}
      {adm/incl/d__bcf00.if
         &BrowseCellTable  = "TT_E_BelegPos"
         &BrowseCellColumn = "Bestellmenge"
         &ToFormat         = "entry(TT_E_BelegPos.NachKomma + 1,{&PA_MENGENEINGABEFORMAT},{&PA-DELIMITER4})"
         &WithFrame        = "in browse {&browse-name}"}
      {adm/incl/d__bcf00.if
         &BrowseCellColumn = "gdLABFZGes"
         &ToFormat         = "entry(TT_E_BelegPos.NachKomma + 1,{&PA_MENGENEINGABEFORMAT},{&PA-DELIMITER4})"
         &WithFrame        = "in browse {&browse-name}"}
      {adm/incl/d__bcf00.if
         &BrowseCellTable  = "TT_E_BelegPos"
         &BrowseCellColumn = "TransitQty"
         &ToFormat         = "entry(TT_E_BelegPos.NachKomma + 1,{&PA_MENGENEINGABEFORMAT},{&PA-DELIMITER4})"
         &WithFrame        = "in browse {&browse-name}"}
      {adm/incl/d__bcf00.if
         &BrowseCellTable  = "TT_E_BelegPos"
         &BrowseCellColumn = "gelieferte_Menge"
         &ToFormat         = "entry(TT_E_BelegPos.NachKomma + 1,{&PA_MENGENEINGABEFORMAT},{&PA-DELIMITER4})"
         &WithFrame        = "in browse {&browse-name}"}
      .


  {adm/template/incl/dt_uit01.if
     &UserExitName = "ON_ROW-DISPLAY_OF_br_table"}
end.

/* _UIB-CODE-BLOCK-END */
&ANALYZE-RESUME


&ANALYZE-SUSPEND _UIB-CODE-BLOCK _CONTROL br_table B-table-Win
ON row-entry OF br_table IN FRAME F-Main
do:
  
  /* This code displays initial values for newly added or copied rows. */

  {adm/template/incl/dt_uit00.if
     &UserExitName = "ON_ROW-ENTRY_OF_br_table"}

  {adm/template/incl/dt_brw02.if}

  define variable dAB_PositionsNr as decimal no-undo.

  define buffer bE_AB_Pos           for E_AB_Pos.
  define buffer bEBT_DeliveryPos    for EBT_DeliveryPos.
  define buffer bTT_E_BelegPos      for temp-table TT_E_BelegPos.
  define buffer bTT_E_BelegPos-Last for temp-table TT_E_BelegPos.

  define variable i as integer no-undo.

  if available TT_E_BelegPos then
  do:

    /* In case of a special constellation in classic UI, there is a           */
    /* possibility to double the last row in the browser. Given the           */
    /* constellation, that not all available rows are displayed and menu      */
    /* button for "Date Assignment" has been selected for updating all        */
    /* browser rows with delivery dates, the query of the last row can not    */
    /* handle a value change of an editable field (e.g. "AB-Pos.") combined   */
    /* with leaving this field (and row). The error does not appear, if the   */
    /* next entry is searched on the last row by using the toolbar or the     */
    /* down arrow key, before the field value has changed. This workaround    */
    /* (searching the next row on the last row) is applied here in a          */
    /* programmed manner. The error only occurs on ascending sort order.      */
    
    if    not adm.method.cls.DMCSkinClientSvc:prplIsSkinClient
      and not pa-DescendingSortOrder then
    do:

      find last bTT_E_BelegPos-Last
        no-lock.

      if bTT_E_BelegPos-Last.PositionsNr = TT_E_BelegPos.PositionsNr then

        run dispatch('get-next':U).
        
      else if {getwidgetattr {&BROWSE-NAME} focused-row integer} >= {getwidgetattr {&BROWSE-NAME} down integer} then
      do:

        run dispatch('get-next':U).
        run dispatch('get-prev':U).

      end.
      
    end.

    find gbS_Artikel
      where gbS_Artikel.Firma   = {firma/sartikel.fir pa-Firma}
        and gbS_Artikel.Artikel = TT_E_BelegPos.Artikel
      no-lock.

    if gcTargetDocType = 'EBB':U then
    do:

      run ChangeFieldStatus(   TT_E_BelegPos.BelegArt     <> 'EAB':U
                            or TT_E_BelegPos.Wertposition  = yes).

      {fnarg
        pa_lUISvcSetWidgetSensitiveState
        "Btn_Abrufe:handle in frame {&frame-name},
             TT_E_BelegPos.BelegArt     = 'EAB':U
         and TT_E_BelegPos.Wertposition = no"}.

      {fnarg
        pa_lUISvcSetWidgetSensitiveState
        "Btn_Termin:handle in frame {&frame-name},
            TT_E_BelegPos.BelegArt    <> 'EAB':U
         or TT_E_BelegPos.Wertposition = yes"}.

    end. /* if gcTargetDocType = 'EBB':U */
    else

      if TT_E_BelegPos.Lagerort = ? then

        {fnarg
          pa_lUISvcDisableBrowseColumn
          "TT_E_BelegPos.Lagerort:handle in browse {&browse-name}"}.

      else

        {fnarg
          pa_lUISvcEnableBrowseColumn
          "TT_E_BelegPos.Lagerort:handle in browse {&browse-name}"}.

    /* Purchase orders with delivery plan are adopted to the despatch advice  */
    /* from the line and to the order confirmation from the delivery plan     */
    /* date.                                                                  */
    /* Do not fill the temp-table if the user scrolled with the mouse in the  */
    /* browser. (SCROLL-NOTIFY if no cursor in an open field; OFF-HOME if the */
    /* cursor is placed in an open field.                                     */

    if    TT_E_BelegPos.AB_PositionsNr    = ?
      and (       gcTargetDocType         = 'EBB':U
              and TT_E_BelegPos.Belegart <> 'EAB':U
           or     gcTargetDocType         = 'EDA':U)
      and not can-do('SCROLL-NOTIFY,OFF-HOME':U,{getwidgetattr last-event function string}) then
    do:

      /* If the part has a warning then do not show it several times. */

      if glCancelRecord then

        {returnnoapply}.

      if gcTargetDocType = 'EBB':U then
      do:

        if not available E_AB_Kopf then

          find E_AB_Kopf
            where E_AB_Kopf.Firma      = {firma/ebelkop.fir pa-firma}
              and E_AB_Kopf.ReferenzNr = giReferenzNr
            no-lock.

        find last bE_AB_Pos
          where bE_AB_Pos.Firma      = E_AB_Kopf.Firma
            and bE_AB_Pos.ReferenzNr = E_AB_Kopf.ReferenzNr
          use-index Main
          no-lock no-error.

        find last bTT_E_BelegPos
          where bTT_E_BelegPos.AB_PositionsNr <> ?
          use-index AB
          no-lock no-error.

        i = max ((if available bE_AB_Pos then
                    truncate(bE_AB_Pos.PositionsNr + 1,0)
                  else
                    1),
                 (if available bTT_E_BelegPos
                    and bTT_E_BelegPos.AB_PositionsNr <> ? then
                    truncate(bTT_E_BelegPos.AB_PositionsNr + 1,0)
                  else
                    1)).

        assign
          {adm/incl/d__bcs00.if
             &BrowseCell  = "TT_E_BelegPos.AB_PositionsNr"
             &ScreenValue = "string(i,'zz9.9':U)"
             &WithFrame   = "in browse {&browse-name}"}
          TT_E_BelegPos.AB_PositionsNr  = decimal(string(i,'zz9.9':U))

          &IF LOOKUP("U_CI":U,"{&PA-OPTIONEN}":U) > 0 &THEN
          {adm/incl/d__bcs00.if
             &BrowseCell  = "TT_E_BelegPos.Liefertermin"
             &ScreenValue = "string(TT_E_BelegPos.uci_ReqDeliveryDate,'{&PA_DATEFORMAT}':U)"
             &WithFrame   = "in browse {&browse-name}"}
          &ELSE /* original */
          {adm/incl/d__bcs00.if
             &BrowseCell  = "TT_E_BelegPos.Liefertermin"
             &ScreenValue = "string(TT_E_BelegPos.Wunschtermin,'{&PA_DATEFORMAT}':U)"
             &WithFrame   = "in browse {&browse-name}"}
          &ENDIF

          {adm/incl/d__bcs00.if
             &BrowseCell  = "TT_E_BelegPos.Menge"
             &ScreenValue = "string(TT_E_BelegPos.Restmenge, entry(TT_E_BelegPos.NachKomma + 1,{&PA_MENGENEINGABEFORMAT},{&PA-DELIMITER4}))"
             &WithFrame   = "in browse {&browse-name}"}
          TT_E_BelegPos.Liefertermin 
            = date({getwidgetattr TT_E_BelegPos.Liefertermin screen-value string "in browse {&BROWSE-NAME}"})
          .

        /* Sperrgrund Pr�fungen Beleg */

        basis.buro.cls.BBCWorkflowSvc:prpoInstance:showLockStatus
          (E_AB_Kopf.E_AB_Kopf_Obj,
           'E_BB':U) no-error.

          if error-status:error then
            {returnnoapply}.

      end. /* TT_E_BelegPos.AB_PositionsNr = ? */

      else if gcTargetDocType = 'EDA':U then
      do:

        if not available EBT_Delivery then

          find EBT_Delivery
            where EBT_Delivery.EBT_Delivery_Obj = gcTargetObj
            no-lock.

        if not available EBT_DesAdv then

          find EBT_DesAdv
            where EBT_DesAdv.EBT_DesAdv_Obj = EBT_Delivery.EBT_DesAdv_Obj
            no-lock.

        find last bEBT_DeliveryPos
          where bEBT_DeliveryPos.EBT_Delivery_Obj = EBT_Delivery.EBT_Delivery_Obj
          use-index Main
          no-lock no-error.

        /* Some fields are misused for the document type 'EDA' as the program   */
        /* logic corresponds strongly to that of 'EBB':                         */
        /* TT_E_BelegPos.AB_PositionsNr -> Shipping Document Line No            */
        /* TT_E_BelegPos.Liefertermin -> Target Arrival Date of Despatch Advice */

        find last bTT_E_BelegPos
          where bTT_E_BelegPos.AB_PositionsNr <> ?
          use-index AB
          no-lock no-error.

        i = max ((if available bEBT_DeliveryPos then
                    truncate(bEBT_DeliveryPos.PositionsNr + 1,0)
                  else
                    1),
                 (if available bTT_E_BelegPos
                    and bTT_E_BelegPos.AB_PositionsNr <> ? then
                    truncate(bTT_E_BelegPos.AB_PositionsNr + 1,0)
                  else
                    1)).

        {adm/incl/d__bcs00.if
           &BrowseCell  = "TT_E_BelegPos.AB_PositionsNr"
           &ScreenValue = "string(i,'zz9.9':U)"
           &WithFrame   = "in browse {&browse-name}"}.

        if TT_E_BelegPos.Belegart <> 'ECO':U then

          {adm/incl/d__bcs00.if
             &BrowseCell  = "TT_E_BelegPos.Menge"
             &ScreenValue = "string(TT_E_BelegPos.Restmenge, entry(TT_E_BelegPos.NachKomma + 1,{&PA_MENGENEINGABEFORMAT},{&PA-DELIMITER4}))"
             &WithFrame   = "in browse {&browse-name}"}.

        &IF lookup ("M_PACK":U,"{&PA-OPTIONEN}":U) > 0 &THEN

          dAB_PositionsNr = {getwidgetattr TT_E_BelegPos.AB_PositionsNr input-value decimal "in browse {&BROWSE-NAME}"}.

          {fnarg
            pa_lUISvcSetWidgetSensitiveState
            "BtnPackage:handle in frame {&frame-name},
                 dAB_PositionsNr         <> ? 
             and dAB_PositionsNr          > 0 
             and available gbS_Artikel
             and lookup(string(gbS_Artikel.ArtikelArt),{&pa_M_PTList_StorageArea}) > 0"}.

        &ENDIF /* &IF lookup ("M_PACK":U,"{&PA-OPTIONEN}":U) > 0 &THEN */

        /* Sperrgrund Pr�fungen Beleg */

        basis.buro.cls.BBCWorkflowSvc:prpoInstance:showLockStatus
          (EBT_DesAdv.EBT_DesAdv_Obj,
           'EB_EDA':U) no-error.
        if error-status:error then
          {returnnoapply}.

      end. /* if gcTargetDocType = 'EDA':U */

    end. /* if TT_E_BelegPos.AB_PositionsNr = ? */

    &IF   lookup ("EB_DESADV":U,"{&PA-OPTIONEN}":U) > 0
      and lookup ("M_PACK":U,"{&PA-OPTIONEN}":U)    > 0 &THEN

      else if gcTargetDocType                                                   = 'EDA':U
        and   available gbS_Artikel
        and   lookup(string(gbS_Artikel.ArtikelArt),{&pa_M_PTList_StorageArea}) > 0 then

        {fnarg
          pa_lUISvcEnableWidget
          "BtnPackage:handle in frame {&FRAME-NAME}"}.

    &ENDIF /* &IF   lookup ("EB_DESADV":U,"{&PA-OPTIONEN}":U) > 0*/

    assign
      gdQtySuggested   = TT_E_BelegPos.Menge
      glAbfrage        = (TT_E_BelegPos.AB_PositionsNr <> gdPositionsNrAlt)
                          or (TT_E_BelegPos.AB_PositionsNr = ?)
                          or (gdQuantity <> {getwidgetattr TT_E_BelegPos.Menge input-value decimal "in browse {&BROWSE-NAME}"})
      gdPositionsNrAlt = TT_E_BelegPos.AB_PositionsNr
      glProtocol       = ?
      .

  end. /* if available TT_E_BelegPos */


  {adm/template/incl/dt_uit01.if
     &UserExitName = "ON_ROW-ENTRY_OF_br_table"}
end.

/* _UIB-CODE-BLOCK-END */
&ANALYZE-RESUME


&ANALYZE-SUSPEND _UIB-CODE-BLOCK _CONTROL br_table B-table-Win
ON row-leave OF br_table IN FRAME F-Main
do: 
  define variable i                  as integer                                 no-undo.
  define variable cListe             as character                               no-undo.
  define variable cPositionsnummern  as character                               no-undo.
  define variable cTemp              as character                               no-undo.
  define variable cWert1             as character                               no-undo.
  define variable cWert2             as character                               no-undo.
  define variable cWert3             as character                               no-undo.
  define variable tDatum             as date                                    no-undo.
  define variable lRueckgabe         as logical                                 no-undo.
  define variable lErhoehung         as logical                                 no-undo init no.
  define variable rZeile             as rowid                                   no-undo.

  &IF lookup("EB_DESADV":U,"{&PA-OPTIONEN}":U) > 0 &THEN
    define variable dSumQtyAdvised   as decimal                                 no-undo.
    define variable dSumQtyDelivered like E_WE_Pos.Liefermenge                  no-undo.
    define variable dSumQtyLacking   like E_WE_Pos.Fehlmenge                    no-undo.
  &ENDIF

  define buffer bTT_E_BelegPos    for temp-table TT_E_BelegPos.
  define buffer bE_WE_Pos         for E_WE_Pos.
  define buffer bE_BelegPos       for E_BelegPos.
  &IF lookup("EB_DESADV":U,"{&PA-OPTIONEN}":U) > 0 &THEN
    define buffer EBT_DeliveryPos for EBT_DeliveryPos.
    define buffer EBT_Delivery    for EBT_Delivery.
    define buffer EBT_DesAdv      for EBT_DesAdv.
  &ENDIF

  {adm/template/incl/dt_uit00.if
     &UserExitName = "ON_ROW-LEAVE_OF_br_table"}

  /* Zuweisung erfolgt, damit nach Eingabe des Datums z.B. '23.5.' ohne */
  /* anschliessendem Tab, keine Fehlermeldung erscheint und das Datum   */
  /* korrekt zur�ckgeschrieben wird.                                    */
  assign
    tDatum        = {getwidgetattr TT_E_BelegPos.Liefertermin input-value date "in browse {&BROWSE-NAME}"}
    {adm/incl/d__bcs00.if
       &BrowseCell  = "TT_E_BelegPos.Liefertermin"
       &ScreenValue = "string(tDatum,'{&pa_DateFormat}':U)"
       &WithFrame   = "in browse {&browse-name}"
       &NoError     = "yes"}
    glFehler      = no
    glDateSplit   = no
    no-error.
    
    // Sperrgrund Pr�fungen Teil
    if basis.buro.cls.BBCWorkflowSvc:prpoInstance:lHasLockStatusWarningOrLock
         (gbS_Artikel.S_Artikel_Obj,
          TT_E_BelegPos.Bereich) then
    do:

      basis.buro.cls.BBCWorkflowSvc:prpoInstance:showLockStatus
        (gbS_Artikel.S_Artikel_Obj,
         TT_E_BelegPos.Bereich) no-error.                   

      // Prevent, that the warning appears several times.
      if error-status:error then
      do:

        assign
          TT_E_BelegPos.AB_PositionsNr                                       = ?
          {adm/incl/d__bcs00.if
             &BrowseCell  = "TT_E_BelegPos.AB_PositionsNr"
             &ScreenValue = "'?':U"
             &WithFrame   = "in browse {&browse-name}"}
          TT_E_BelegPos.Menge                                                = ?
          {adm/incl/d__bcs00.if
             &BrowseCell  = "TT_E_BelegPos.Menge"
             &ScreenValue = "'?':U"
             &WithFrame   = "in browse {&browse-name}"}
          glCancelRecord                                                     = yes
          .

        if adm.method.cls.DMCSkinClientSvc:prplIsSkinClient then
        do:

          {fnarg
             pa_lUISvcDisableBrowseColumn
             "TT_E_BelegPos.AB_PositionsNr:handle in browse {&browse-name}"}.
          {fnarg
             pa_lUISvcDisableBrowseColumn
             "TT_E_BelegPos.Menge:handle in browse {&browse-name}"}.
          {fnarg
             pa_lUISvcDisableBrowseColumn
             "TT_E_BelegPos.Liefertermin:handle in browse {&browse-name}"}.

        end. /* if adm.method.cls.DMCSkinClientSvc:prplIsSkinClient */

      end. /* if error-status:error */
      
    end.  /* if basis.buro.cls.BBCWorkflowSvc:prpoInstance:lHasLockStatusWarningOrLock */
        
  // If a not existing date was entered and then the mouse was clicked to the
  // Appbuilder, then a progress error occurred. Run check before dt_brw03.if

  run CheckDeliveryDate. 

  TT_E_BelegPos.Liefertermin = {getwidgetattr TT_E_BelegPos.Liefertermin input-value date "in browse {&BROWSE-NAME}"}.

  /* Do not disable this code or no updates will take place except
     by pressing the Save button on an Update SmartPanel. */

  {adm/template/incl/dt_brw03.if}

  if    available TT_E_BelegPos
    and pa-hlp-function = '':U
    and not glCancelRecord then
  do:

    assign
      TT_E_BelegPos.AB_PositionsNr = {getwidgetattr TT_E_BelegPos.AB_PositionsNr input-value decimal "in browse {&BROWSE-NAME}"}
      TT_E_BelegPos.Menge          = {getwidgetattr TT_E_BelegPos.Menge input-value decimal "in browse {&BROWSE-NAME}"}
      .

    /* Quantities of source documents may be modified via order confirmations */
    /* but not via despatch advices.                                          */

    if gcTargetDocType = 'EBB':U then
    do:

      find bE_BelegPos
        where rowid (bE_BelegPos) = to-rowid (TT_E_BelegPos.RowidString)
        no-lock.

      if    TT_E_BelegPos.AB_PositionsNr = ?
        and TT_E_BelegPos.Liefertermin  <> ? then
      do:

        assign
          gcEntryField = 'AB_PositionsNr':U
          glFehler     = yes
          .

        adm.method.cls.DMCMessageSvc:prpoInstance:showError
          ('e_ab_00007':U).

      end.

      /* Quantity '?' would result in a runtime error. */

      if    TT_E_BelegPos.Menge           = ?
        and TT_E_BelegPos.AB_PositionsNr <> ? then
      do:

        assign
          gcEntryField = 'Menge':U
          glFehler     = yes
          .

        adm.method.cls.DMCMessageSvc:prpoInstance:showError
          ('e_ab_00017':U).

      end. /* if TT_E_BelegPos.Menge = ? */

      &IF lookup("EB_DESADV":U,"{&PA-OPTIONEN}":U) > 0 &THEN

        dSumQtyAdvised = pa_dPurDesTotalUpSumQtyAdv(TT_E_BelegPos.Source_Obj).

        if    dSumQtyAdvised > 0
          and adm.method.cls.DMCMessageSvc:prpoInstance:lShowMessage
                ('ebdea00053':U,
                 string(dSumQtyAdvised,
                        entry(bE_BelegPos.NachKomma + 1,
                              {&PA_MENGENEINGABEFORMAT},
                              {&PA-DELIMITER4})),
                 TT_E_BelegPos.MEBez) = no then
        do:

          glFehler = yes.
          {returnnoapply}.

        end. /* if dSumQtyAdvised > 0 */

      &ENDIF

      /* For purchase orders the quantity of the document line may be changed */
      /* here,  for purchase orders with delivery plan it may be changed      */
      /* in the browser of delivery plan dates (e_bab_12.w).                  */

      if    TT_E_BelegPos.BelegArt                       = 'EB':U
        and dBestaetigteMenge(TT_E_BelegPos.RowidString) > TT_E_BelegPos.Bestellmenge
        and glAbfrage
        and not can-find(first bTT_E_BelegPos
                  where bTT_E_BelegPos.PositionsNr    = TT_E_BelegPos.PositionsNr
                    and bTT_E_BelegPos.AB_PositionsNr > TT_E_BelegPos.AB_PositionsNr) then

        lErhoehung = adm.method.cls.DMCMessageSvc:prpoInstance:lShowMessage
                       ('e_ab_00023':U).

      if   lErhoehung
        or (    dBestaetigteMenge(TT_E_BelegPos.RowidString) < TT_E_BelegPos.Bestellmenge
            and glAbfrage
            and not can-find(first bTT_E_BelegPos
              where bTT_E_BelegPos.PositionsNr    = TT_E_BelegPos.PositionsNr
                and bTT_E_BelegPos.AB_PositionsNr > TT_E_BelegPos.AB_PositionsNr)) then
      do:

        /* Reduzierung der Positionsmenge nur bei Bestellung m�glich */

        if    not lErhoehung
          and TT_E_BelegPos.BelegArt = 'EB':U then
        do:

          &IF lookup("EB_DESADV":U,"{&PA-OPTIONEN}":U) > 0 &THEN

            find first EBT_DeliveryPos
              where EBT_DeliveryPos.Source_Obj = bE_BelegPos.E_BelegPos_Obj
                and EBT_DeliveryPos.offen      = yes
              no-lock no-error.

            if available EBT_DeliveryPos then
            do:

              find EBT_Delivery
                where EBT_Delivery.EBT_Delivery_Obj = EBT_DeliveryPos.EBT_Delivery_Obj
                no-lock.

              find EBT_DesAdv
                where EBT_DesAdv.EBT_DesAdv_Obj = EBT_Delivery.EBT_DesAdv_Obj
                no-lock.

            end. /* if available EBT_DeliveryPos */

          &ENDIF

          if bE_BelegPos.gelieferte_Menge + bE_BelegPos.Fehlmenge < dBestaetigteMenge(TT_E_BelegPos.RowidString) then

            &IF lookup("EB_DESADV":U,"{&PA-OPTIONEN}":U) > 0 &THEN

              /* If there is still an open delivery line present, then a      */
              /* reduction of the quantity to the ordered quantity does not   */
              /* automatically archive the line.                              */

              if available EBT_DeliveryPos then

                lRueckgabe = adm.method.cls.DMCMessageSvc:prpoInstance:lShowMessage
                               ('ebdea00055':U,
                                string(bE_BelegPos.PositionsNr),
                                string(EBT_DesAdv.BelegNummer) + '/':U + EBT_Delivery.LieferscheinNr,
                                string(EBT_DeliveryPos.PositionsNr)).

              else

            &ENDIF

                lRueckgabe = adm.method.cls.DMCMessageSvc:prpoInstance:lShowMessage
                               ('e_ab_00003':U).

          else if bE_BelegPos.gelieferte_Menge + bE_BelegPos.Fehlmenge = dBestaetigteMenge(TT_E_BelegPos.RowidString) then
          do:

            &IF lookup("EB_DESADV":U,"{&PA-OPTIONEN}":U) > 0 &THEN

              /* If there is still an open delivery line present, then the    */
              /* source document line may not be archived.                    */

              if available EBT_DeliveryPos then
              do:

                lRueckgabe = adm.method.cls.DMCMessageSvc:prpoInstance:lShowMessage
                               ('ebdea00054':U,
                                string(bE_BelegPos.PositionsNr),
                                string(EBT_DesAdv.BelegNummer) + '/':U + EBT_Delivery.LieferscheinNr,
                                string(EBT_DeliveryPos.PositionsNr)).

                if not lRueckgabe then
                  {returnnoapply}.

              end. /* if available EBT_DeliveryPos */

              else

            &ENDIF

                lRueckgabe = adm.method.cls.DMCMessageSvc:prpoInstance:lShowMessage
                               ('e_ab_00029':U).

          end. /* else if bE_BelegPos.gelieferte_Menge + bE_BelegPos.Fehlmenge = dBestaetigteMenge(TT_E_BelegPos.RowidString) */

        end. /* if not lErhoehung */
        else
          lRueckgabe = lErhoehung.

        if lRueckgabe then
        do:

          if bE_BelegPos.gelieferte_Menge
            + bE_BelegPos.Fehlmenge > dBestaetigteMenge(TT_E_BelegPos.RowidString) then

            adm.method.cls.DMCMessageSvc:prpoInstance:showError
              ('e_ab_00022':U).

          else
          do:

            rZeile = rowid(TT_E_BelegPos).

            TT_E_BelegPos.Bestellmenge = dBestaetigteMenge(TT_E_BelegPos.RowidString).

            /* Synchronisiere die Bestellmenge in allen teilbest�tigten Positionen */
            /* der aktuellen Belegposition                                         */

            for each bTT_E_BelegPos
              where bTT_E_BelegPos.PositionsNr     = TT_E_BelegPos.PositionsNr
                and bTT_E_BelegPos.ReferenzNr      = TT_E_BelegPos.ReferenzNr
                and bTT_E_BelegPos.BelegArt        = TT_E_BelegPos.BelegArt
                and bTT_E_BelegPos.AB_PositionsNr <> TT_E_BelegPos.AB_PositionsNr
              on error undo, throw:

              bTT_E_BelegPos.Bestellmenge = TT_E_BelegPos.Bestellmenge.

            end. /* for each bTT_E_BelegPos */

            run dispatch ('open-query':U).

            if return-value <> 'ADM-ERROR':U then
              run RepositionBrowse(rZeile) no-error.

          end. /* else do: */

        end. /* if lRueckgabe */

        else if can-do('EB,ERL':U,TT_E_BelegPos.BelegArt) then

          if adm.method.cls.DMCMessageSvc:prpoInstance:lShowMessage
               ('e_ab_00015':U,
                string(dBestaetigteMenge(TT_E_BelegPos.RowidString),
                       entry(TT_E_BelegPos.NachKomma + 1,
                             {&PA_MENGENEINGABEFORMAT},
                             {&PA-DELIMITER4})),
                string(TT_E_BelegPos.Bestellmenge,
                       entry(TT_E_BelegPos.NachKomma + 1,
                             {&PA_MENGENEINGABEFORMAT},
                             {&PA-DELIMITER4})),
                TT_E_BelegPos.MEBez,
                string(today + {&pa_S_Liefertermin_Zukunft},
                       '{&PA_DATEFORMAT}':U)) = yes then
          do:

            cPositionsnummern = cAktuellePositionsnummern().

            run eink/proc/e_pab_05.w (input-output cTemp,
                                      TT_E_BelegPos.Bestellmenge - dBestaetigteMenge(TT_E_BelegPos.RowidString),
                                      TT_E_BelegPos.Nachkomma,
                                      TT_E_BelegPos.MEBez,
                                      cPositionsnummern,
                                      TT_E_BelegPos.BelegArt,
                                      input-output cListe) no-error.

            if    not error-status:error
              and cListe <> ? then
            do:

              assign
                rZeile      = rowid(TT_E_BelegPos)
                glDateSplit = yes
                .

              i = 0.

              do while cWert1 <> ?:

                assign
                  i      = i + 1
                  cWert1 = adm.method.cls.DMCParameterStringSvc:cReadValue(cListe, 'abpos':U, i)
                  cWert2 = adm.method.cls.DMCParameterStringSvc:cReadValue(cListe, 'mng':U, i)
                  cWert3 = adm.method.cls.DMCParameterStringSvc:cReadValue(cListe, 'dat':U, i)
                  .

                if cWert1 <> ? then
                do:

                  create bTT_E_BelegPos.

                  {buffer-copy
                     TT_E_BelegPos
                     to bTT_E_BelegPos
                     assign
                       "bTT_E_BelegPos.AB_PositionsNr = decimal(cWert1)
                        bTT_E_BelegPos.Menge          = decimal(cWert2)
                        bTT_E_BelegPos.Liefertermin   = date(01,01,0001) + (integer(cWert3) - 1)"}

                  validate bTT_E_BelegPos.

                  rZeile = rowid(bTT_E_BelegPos).

                end. /* if cWert1 <> ? */

                else
                  i = i - 1.

              end. /* do while */

              run dispatch ('open-query':U).

              if return-value <> 'ADM-ERROR':U then
                run RepositionBrowse(rZeile) no-error.

            end. /* if not error-status:error */

          end. /* if lRueckgabe */

      end. /* if TT_E_BelegPos.Menge < TT_E_BelegPos.Bestellmenge */

      /* Create workflow for event 35 in the origin purchase order if delivery*/ 
      /* date is different from requested date                                */

      eink.base.cls.EBCPurchaseOrderDocSvc:prpoInstance:CreateOrCancelWorkflowEvent35
        (buffer E_BelegKopf,
         buffer bE_BelegPos,
         date({getwidgetattr TT_E_BelegPos.Liefertermin input-value date "in browse {&BROWSE-NAME}"}),
         '':U).

    end. /* if gcTargetDocType = 'EBB':U */

    /* For despatch advices, inform that document lines with delivery         */
    /* quantities equal to jet delivered quantities will be archived and      */
    /* inform about differences between entered quantity and the quantity of  */
    /* the document line in the source document.                              */

    &IF lookup("EB_DESADV":U,"{&PA-OPTIONEN}":U) > 0 &THEN

      else if glAbfrage
        and   not can-find(first bTT_E_BelegPos
                    where bTT_E_BelegPos.PositionsNr    = TT_E_BelegPos.PositionsNr
                      and bTT_E_BelegPos.AB_PositionsNr > TT_E_BelegPos.AB_PositionsNr) then
      do:

        /* The delivery quantity may not be zero. */

        if    TT_E_BelegPos.AB_PositionsNr <> ?
          and (   TT_E_BelegPos.Menge       = 0
               or TT_E_BelegPos.Menge       = ?) then
        do:

          assign
            gcEntryField = 'Menge':U
            glFehler     = yes
            .

          adm.method.cls.DMCMessageSvc:prpoInstance:showError
            ('ebdea00036':U).

        end. /* if TT_E_BelegPos.AB_PositionsNr <> ? */

        assign
          dSumQtyDelivered = 0
          dSumQtyLacking   = 0
          .

        if can-do('EB,ERL,EAB':U,TT_E_BelegPos.BelegArt) then
        do:

          find bE_BelegPos
            where rowid (bE_BelegPos) = to-rowid (TT_E_BelegPos.RowidString)
            no-lock.

          /* Several stock receipts may exist with the same Company, Supplier,  */
          /* Delivery Date and Delivery Number.                                 */

          for each bE_WE_Pos
            where bE_WE_Pos.Firma            = bE_BelegPos.Firma
              and bE_WE_Pos.Herk_BelegArt    = bE_BelegPos.BelegArt
              and bE_WE_Pos.Herk_ReferenzNr  = bE_BelegPos.ReferenzNr
              and bE_WE_Pos.Herk_PositionsNr = bE_BelegPos.PositionsNr
              and bE_WE_Pos.berechnet        = no
              and can-find (E_WE_Kopf
                    where E_WE_Kopf.Firma             = bE_WE_Pos.Firma
                      and E_WE_Kopf.ReferenzNr        = bE_WE_Pos.ReferenzNr
                      and E_WE_Kopf.Lieferant         = EBT_Delivery.Lieferant
                      and E_WE_Kopf.LieferscheinNr    = EBT_Delivery.LieferscheinNr
                      and E_WE_Kopf.LieferscheinDatum = EBT_Delivery.LieferscheinDatum)
            no-lock
            on error undo, throw:

            assign
              dSumQtyDelivered = dSumQtyDelivered + bE_WE_Pos.Liefermenge
              dSumQtyLacking   = dSumQtyLacking   + bE_WE_Pos.Fehlmenge
              .

          end. /* for each bE_WE_Pos */

        end. /* if can-do('EB,ERL,EAB':U,TT_E_BelegPos.BelegArt) */
        else if TT_E_BelegPos.BelegArt = 'ECO':U then

          for each bE_WE_Pos
            where bE_WE_Pos.Source_Obj = TT_E_BelegPos.Source_Obj /* code checked by jf 05.05.2010 */
              and bE_WE_Pos.berechnet  = no
              and can-find (E_WE_Kopf
                    where E_WE_Kopf.Firma             = bE_WE_Pos.Firma
                      and E_WE_Kopf.ReferenzNr        = bE_WE_Pos.ReferenzNr
                      and E_WE_Kopf.Lieferant         = EBT_Delivery.Lieferant
                      and E_WE_Kopf.LieferscheinNr    = EBT_Delivery.LieferscheinNr
                      and E_WE_Kopf.LieferscheinDatum = EBT_Delivery.LieferscheinDatum)
            no-lock
            on error undo, throw:

            assign
              dSumQtyDelivered = dSumQtyDelivered + bE_WE_Pos.Liefermenge
              dSumQtyLacking   = dSumQtyLacking   + bE_WE_Pos.Fehlmenge
              .

          end. /* for each bE_WE_Pos */

        if   dSumQtyDelivered > 0
          or dSumQtyLacking   > 0 then
        do:

          if dSumQtyDelivered + dSumQtyLacking > TT_E_BelegPos.Menge then
          do:

            assign
              gcEntryField = 'Menge':U
              glFehler     = yes
              .

            adm.method.cls.DMCMessageSvc:prpoInstance:showError
              ('ebdea00021':U,
               string(EBT_DesAdv.BelegNummer) + ' ':U + 'Lieferschein':T20 + ' ':U + EBT_Delivery.LieferscheinNr,
               string(TT_E_BelegPos.PositionsNr)).

          end. /* dSumQtyDelivered + dSumQtyLacking > TT_E_BelegPos.Menge */
          else if dSumQtyDelivered = TT_E_BelegPos.Menge then

            adm.method.cls.DMCMessageSvc:prpoInstance:lShowMessage
              ('ebdea00022':U,
               string(TT_E_BelegPos.PositionsNr)).

          else if dSumQtyDelivered + dSumQtyLacking < TT_E_BelegPos.Menge then

            adm.method.cls.DMCMessageSvc:prpoInstance:lShowMessage
              ('ebdea00029':U,
               string(TT_E_BelegPos.PositionsNr)).

        end. /* if   dSumQtyDelivered > 0 */
        else if can-do('EB,ERL,EAB':U,TT_E_BelegPos.BelegArt) then
        do:

          if  TT_E_BelegPos.Bestellmenge - TT_E_BelegPos.gelieferte_Menge
            < dBestaetigteMenge(TT_E_BelegPos.RowidString) then
          do:

            if adm.method.cls.DMCMessageSvc:prpoInstance:lShowMessage
                 ('ebdea00010':U,
                  string(TT_E_BelegPos.Bestellmenge - TT_E_BelegPos.gelieferte_Menge,
                         entry(bE_BelegPos.NachKomma + 1,
                               {&PA_MENGENEINGABEFORMAT},
                               {&PA-DELIMITER4})),
                  string(dBestaetigteMenge(TT_E_BelegPos.RowidString),
                         entry(bE_BelegPos.NachKomma + 1,
                               {&PA_MENGENEINGABEFORMAT},
                               {&PA-DELIMITER4})),
                  TT_E_BelegPos.MEBez) = no then
            do:

              {fnarg
                pa_lUISvcEnableBrowseColumn
                "TT_E_BelegPos.Menge:handle in browse {&browse-name}"}.

              run new-state ('toolbar-update,tableio-source':U).

              /* Assign gdPositionsNrAlt in order to repeat message if several  */
              /* times the entered quantity was to high.                        */

              assign
                gcEntryField     = 'Menge':U
                glFehler         = yes
                gdPositionsNrAlt = ?
                .

              {returnnoapply}.

            end. /* if not lRueckgabe */

          end. /* if dBestaetigteMenge(TT_E_BelegPos.RowidString) > TT_E_BelegPos.Bestellmenge */
          else if TT_E_BelegPos.Bestellmenge - TT_E_BelegPos.gelieferte_Menge
                  > dBestaetigteMenge(TT_E_BelegPos.RowidString) then

            adm.method.cls.DMCMessageSvc:prpoInstance:lShowMessage
              ('ebdea00009':U,
               string(TT_E_BelegPos.Bestellmenge - TT_E_BelegPos.gelieferte_Menge,
                      entry(bE_BelegPos.NachKomma + 1,
                            {&PA_MENGENEINGABEFORMAT},
                            {&PA-DELIMITER4})),
               string(dBestaetigteMenge(TT_E_BelegPos.RowidString),
                      entry(bE_BelegPos.NachKomma + 1,
                            {&PA_MENGENEINGABEFORMAT},
                            {&PA-DELIMITER4})),
               TT_E_BelegPos.MEBez).

        end. /* else if can-do('EB,ERL,EAB':U,TT_E_BelegPos.BelegArt) */

        /* Packaging is reviewed, whether all parameters are consistent.      */
        /* If not, then new packaging records are created.                    */

        &IF lookup ("M_Pack":U,"{&PA-OPTIONEN}":U) > 0 &THEN

          run ConfirmPackage no-error.

          if error-status:error then

            {returnnoapply}.

        &ENDIF

      end. /* else if glAbfrage */

    &ENDIF /* &IF lookup("EB_DESADV":U,"{&PA-OPTIONEN}":U) > 0 */

    assign
      glAbfrage        = no
      gdPositionsNrAlt = TT_E_BelegPos.AB_PositionsNr
      .

  end. /* available TT_E_BelegPos */

  {adm/template/incl/dt_uit01.if
     &UserExitName = "ON_ROW-LEAVE_OF_br_table"
     &ErrorFct     = "run onError_row-leave_br_table. ~{returnnoapply~}."}

end.

/* _UIB-CODE-BLOCK-END */
&ANALYZE-RESUME


&ANALYZE-SUSPEND _UIB-CODE-BLOCK _CONTROL br_table B-table-Win
ON VALUE-CHANGED OF br_table IN FRAME F-Main
DO:

  /* Here we enable the browse columns so that the row-entry trigger also to  */
  /* purchase orders with delivery plan can fire. This will be needed when a  */
  /* value line should be adopted!                                            */

  {adm/template/incl/dt_uit00.if
     &UserExitName = "ON_VALUE-CHANGED_OF_br_table"}

  if gcTargetDocType = 'EBB':U then

    run ChangeFieldStatus(yes).

  /* This ADM trigger code must be preserved in order to notify other
     objects when the browser's current row changes. */
  {adm/template/incl/dt_brw04.if}


  {adm/template/incl/dt_uit01.if
     &UserExitName = "ON_VALUE-CHANGED_OF_br_table"}
END.

/* _UIB-CODE-BLOCK-END */
&ANALYZE-RESUME


&Scoped-define SELF-NAME Btn_Abrufe
&ANALYZE-SUSPEND _UIB-CODE-BLOCK _CONTROL Btn_Abrufe B-table-Win
ON choose OF Btn_Abrufe IN FRAME F-Main /* Lieferplantermine */
do:
  {adm/template/incl/dt_uit00.if
     &UserExitName = "ON_CHOOSE_OF_Btn_Abrufe"}

  run AbrufEingabe no-error.

  if error-status:error then
    {returnnoapply}.


  {adm/template/incl/dt_uit01.if
     &UserExitName = "ON_CHOOSE_OF_Btn_Abrufe"}
end.

/* _UIB-CODE-BLOCK-END */
&ANALYZE-RESUME


&Scoped-define SELF-NAME Btn_Termin
&ANALYZE-SUSPEND _UIB-CODE-BLOCK _CONTROL Btn_Termin B-table-Win
ON choose OF Btn_Termin IN FRAME F-Main /* Terminzuordnung */
do:
  {adm/template/incl/dt_uit00.if
     &UserExitName = "ON_CHOOSE_OF_Btn_Termin"}

  run Zuordnen-Termin.

  {adm/template/incl/dt_uit01.if
     &UserExitName = "ON_CHOOSE_OF_Btn_Termin"}
end.

/* _UIB-CODE-BLOCK-END */
&ANALYZE-RESUME


&Scoped-define SELF-NAME BtnPackage
&ANALYZE-SUSPEND _UIB-CODE-BLOCK _CONTROL BtnPackage B-table-Win
ON choose OF BtnPackage IN FRAME F-Main /* Packmittel */
do:

  {adm/template/incl/dt_uit00.if
     &UserExitName = "ON_CHOOSE_OF_BtnPackage"}

  run Package.


  {adm/template/incl/dt_uit01.if
     &UserExitName = "ON_CHOOSE_OF_BtnPackage"}
end.

/* _UIB-CODE-BLOCK-END */
&ANALYZE-RESUME


&UNDEFINE SELF-NAME

&ANALYZE-SUSPEND _UIB-CODE-BLOCK _CUSTOM _MAIN-BLOCK B-table-Win 


/* ***************************  Main Block  *************************** */

on {&pa_EntryEvent} of TT_E_BelegPos.Menge in browse {&browse-name}
do:
  {adm/template/incl/dt_uit00.if
     &UserExitName = "ON_PA_ENTRYEVENT_OF_TT_E_BelegPos_Menge"}

  gdQuantity = {getwidgetattr TT_E_BelegPos.Menge input-value decimal "in browse {&BROWSE-NAME}"}.

  {adm/template/incl/dt_uit01.if
     &UserExitName = "ON_PA_ENTRYEVENT_OF_TT_E_BelegPos_Menge"}
end.

on {&pa_EntryEvent} of TT_E_BelegPos.Liefertermin in browse {&browse-name}
do:

  /* TT_E_BelegPos.AB_PositionsNr hier bzw. im ON LEAVE OF TT_E_BelegPos.AB_PositionsNr    */
  /* zuweisen, weil sonst weitergesprungen wird, ohne da? die Abfrage, ob die Bestellmenge */
  /* reduziert werden soll kommt.                                                          */

  define variable cLiefertermin  as character     no-undo.

  {adm/template/incl/dt_uit00.if
     &UserExitName = "ON_PA_ENTRYEVENT_OF_TT_E_BelegPos_Liefertermin"}

  if available TT_E_BelegPos then
  do:

    assign
      TT_E_BelegPos.AB_PositionsNr = {getwidgetattr TT_E_BelegPos.AB_PositionsNr input-value decimal "in browse {&BROWSE-NAME}"}
      .

    /* Zuweisung wurde eingef�gt, damit die erste Stelle des Datums */
    /* nicht verschwindet.                                          */

    if not glWrongInput then
      assign
        cLiefertermin = {getwidgetattr TT_E_BelegPos.Liefertermin screen-value string }
        {adm/incl/d__bcs00.if      
          &BrowseCell  = "TT_E_BelegPos.Liefertermin"
          &ScreenValue = "cLiefertermin"
          &WithFrame   = "in browse {&browse-name}"}
        .

  end. /* if available TT_E_BelegPos then */

  {adm/template/incl/dt_uit01.if
     &UserExitName = "ON_PA_ENTRYEVENT_OF_TT_E_BelegPos_Liefertermin"}
end.

on leave of TT_E_BelegPos.Liefertermin in browse {&browse-name}
do:
  {adm/template/incl/dt_uit00.if
     &UserExitName = "ON_LEAVE_OF_TT_E_BelegPos_Liefertermin"}

  do
    on error undo, throw:

    run CheckDeliveryDate.

    TT_E_BelegPos.Liefertermin 
      = date({getwidgetattr TT_E_BelegPos.Liefertermin screen-value string "in browse {&BROWSE-NAME}"}).

  end.

  {adm/template/incl/dt_uit01.if
     &UserExitName = "ON_LEAVE_OF_TT_E_BelegPos_Liefertermin"
     &ErrorFct     = "~{returnnoapply~}."}
end.

on leave of TT_E_BelegPos.AB_PositionsNr in browse {&browse-name}
do:

  /* If the adoption browser is opened the first time automatically, then the */
  /* focus was passed through all fields until it was kept on the button      */
  /* 'date assignment'. As in this situation the last-event:function is       */
  /* 'window-resized' it was used here to stop the programming flow.          */

  {adm/template/incl/dt_uit00.if
     &UserExitName = "ON_LEAVE_OF_TT_E_BelegPos_AB_PositionsNr"}

  if {getwidgetattr last-event function string} = 'window-resized':U then

    {returnnoapply}.

  define buffer bTT_E_BelegPos for temp-table TT_E_BelegPos.

  &IF   lookup ("EB_DESADV":U,"{&PA-OPTIONEN}":U) > 0
    and lookup ("M_PACK":U,"{&PA-OPTIONEN}":U)    > 0 &THEN
    define variable cPMKeyAdopt3   like M_LTPos.Herk_Schluessel3     no-undo.
  &ENDIF
    define variable dABPositionsNr as decimal no-undo.

  glWrongInput = no.

  if available TT_E_BelegPos then
  do:

    dABPositionsNr = {getwidgetattr TT_E_BelegPos.AB_PositionsNr input-value decimal "in browse {&BROWSE-NAME}"}.

    if {getwidgetattr TT_E_BelegPos.AB_PositionsNr screen-value string "in browse {&BROWSE-NAME}"} = '?':U then

      assign
        TT_E_BelegPos.Liefertermin                                       = ?
        {adm/incl/d__bcs00.if
           &BrowseCell  = "TT_E_BelegPos.Liefertermin"
           &ScreenValue = "string(?)"
           &WithFrame   = "in browse {&browse-name}"}
        .

    else

      if    TT_E_BelegPos.AB_PositionsNr         <> {getwidgetattr TT_E_BelegPos.AB_PositionsNr input-value decimal "in browse {&BROWSE-NAME}"}
        and can-find(bTT_E_BelegPos
              where bTT_E_BelegPos.PositionsNr    = TT_E_BelegPos.PositionsNr
                and bTT_E_BelegPos.ReferenzNr     = TT_E_BelegPos.ReferenzNr
                and bTT_E_BelegPos.Belegart       = TT_E_BelegPos.Belegart
                and bTT_E_BelegPos.AB_PositionsNr = dABPositionsNr) then

        adm.method.cls.DMCMessageSvc:prpoInstance:showError('mspro000003':U).

    assign
      {adm/incl/d__agn01.if "TT_E_BelegPos.AB_PositionsNr" "decimal"}
      .

    &IF   lookup ("EB_DESADV":U,"{&PA-OPTIONEN}":U) > 0
      and lookup ("M_PACK":U,"{&PA-OPTIONEN}":U)    > 0 &THEN

      if    gcTargetDocType                                                   = 'EDA':U
        and {getwidgetattr TT_E_BelegPos.AB_PositionsNr input-value decimal "in browse {&BROWSE-NAME}"}         <> ?
        and {getwidgetattr TT_E_BelegPos.AB_PositionsNr input-value decimal "in browse {&BROWSE-NAME}"}          > 0
        and available gbS_Artikel
        and lookup(string(gbS_Artikel.ArtikelArt),{&pa_M_PTList_StorageArea}) > 0 then

        {fnarg
          pa_lUISvcEnableWidget
          "BtnPackage:handle in frame {&FRAME-NAME}"}.

      else
      do:

        {fnarg
          pa_lUISvcDisableWidget
          "BtnPackage:handle in frame {&FRAME-NAME}"}.

        cPMKeyAdopt3 = mawi.base.cls.MMCPackagingSvc:prpoInstance:cCheckPMKeyAdopt3
                         (TT_E_BelegPos.BelegArt,
                          {&pa_MM_PackagingInformational},    /* Function Code 9*/
                          gcSource_Obj,
                          TT_E_BelegPos.Source_Obj).

        if cPMKeyAdopt3 > '':U then

          run mawi/proc/m_vpmi04.p (pACConnectionSvc:prpcCompany,
                                    {&pa_ML_PackagingArea_Purchasing},
                                    {&pa_MM_PackagingInformational},   /* Function Code 9 */
                                    '':U,
                                    '':U,
                                    TT_E_BelegPos.BelegArt,
                                    gcSource_Obj,
                                    TT_E_BelegPos.BelegArt,
                                    cPMKeyAdopt3,
                                    yes).

      end. /* else do: */

    &ENDIF /* &IF   lookup ("EB_DESADV":U,"{&PA-OPTIONEN}":U) > 0 */

  end. /* if available TT_E_BelegPos then */

  {adm/template/incl/dt_uit01.if
     &UserExitName = "ON_LEAVE_OF_TT_E_BelegPos_AB_PositionsNr"
     &ErrorFct     = "glWrongInput = yes.
                      ~{returnnoapply~}."}

end.

on leave of TT_E_BelegPos.Menge in browse {&browse-name}
do:
  {adm/template/incl/dt_uit00.if
     &UserExitName = "ON_LEAVE_OF_TT_E_BelegPos_Menge"}

  if gdQuantity <> {getwidgetattr TT_E_BelegPos.Menge input-value decimal "in browse {&BROWSE-NAME}"} then
    glAbfrage = yes.

  {adm/template/incl/dt_uit01.if
     &UserExitName = "ON_LEAVE_OF_TT_E_BelegPos_Menge"}
end.

/* --> MO#ABT-IVC-0049 thongdi_p 16.07.2026 Erfassung und Auswahl Teile-LieferantenNr Auftragsbest�tigung */
on leave of TT_E_BelegPos.BestellNr in browse {&browse-name}
do:
  {adm/template/incl/dt_uit00.if
     &UserExitName = "ON_LEAVE_OF_TT_E_BelegPos_BestellNr"}
     
  TT_E_BelegPos.BestellNr = {getwidgetattr TT_E_BelegPos.BestellNr screen-value string "in browse {&BROWSE-NAME}"}.
       
  {adm/template/incl/dt_uit01.if
     &UserExitName = "ON_LEAVE_OF_TT_E_BelegPos_BestellNr"}
end.
/* <-- MO#ABT-IVC-0049 thongdi_p 16.07.2026 Erfassung und Auswahl Teile-LieferantenNr Auftragsbest�tigung */

on leave of TT_E_BelegPos.Lagerort in browse {&browse-name}
do:
  {adm/template/incl/dt_uit00.if
     &UserExitName = "ON_LEAVE_OF_TT_E_BelegPos_Lagerort"}

  if not lCheckStorageAreaOK(no,  /* plSaveButtonPressed */
                             {getwidgetattr TT_E_BelegPos.Lagerort input-value integer "in browse {&BROWSE-NAME}"},
                             TT_E_BelegPos.Artikel,
                             rowid(TT_E_BelegPos)) then
  do:

    run pa_UISvcApplyEventToWidgetByHandle
          ('entry':U,
           TT_E_BelegPos.Lagerort:handle in browse {&browse-name}).

    /* If the Button 'Save' is pressed in the toolbar, then set glFehler to   */
    /* yes in order to throw an ADM-ERROR in local-update-records. In this    */
    /* case 'return no-apply' does not stop the program.                      */

    glStorAreaValid = no.
    {returnnoapply}.

  end. /* if not lCheckStorageAreaOK(no, ... */
  else

    glStorAreaValid = yes.

  TT_E_BelegPos.Lagerort = {getwidgetattr TT_E_BelegPos.Lagerort input-value integer "in browse {&BROWSE-NAME}"}.

  {adm/template/incl/dt_uit01.if
     &UserExitName = "ON_LEAVE_OF_TT_E_BelegPos_Lagerort"}
end. /* ON LEAVE OF TT_E_BelegPos.Lagerort IN BROWSE {&browse-name} DO: */

ON RETURN OF browse {&browse-name} anywhere
do:

  {adm/template/incl/dt_uit00.if
     &UserExitName = "ON_RETURN_OF_browse"}

  run new-state('Toolbar-Save,TableIO-source':U).

  {adm/template/incl/dt_uit01.if
     &UserExitName  = "ON_RETURN_OF_browse"
     &returnnoapply = "yes"}

end. /* ON RETURN OF browse {&browse-name} anywhere */

{adm/template/incl/dt_brw00.i}

/* _UIB-CODE-BLOCK-END */
&ANALYZE-RESUME


/* **********************  Internal Procedures  *********************** */

&ANALYZE-SUSPEND _UIB-CODE-BLOCK _PROCEDURE AbrufEingabe B-table-Win 
PROCEDURE AbrufEingabe :
/*------------------------------------------------------------------------------
  Purpose:     Eingabe der Auftragsbest�tigungen der Abruftermine
  Parameters:  <none>
  Notes:
------------------------------------------------------------------------------*/

  define variable cTmp   as character          no-undo.
  define variable dMenge as decimal decimals 3 no-undo init 0.

  define buffer E_AB_PosTermin for E_AB_PosTermin.
  define buffer bS_Artikel     for S_Artikel.

  if available TT_E_BelegPos then
  do:

    /* Zeige alle Sperrgr�nde an */

    find bS_Artikel
      where bS_Artikel.Firma   = {firma/sartikel.fir pACConnectionSvc:prpcCompany}
        and bS_Artikel.Artikel = TT_E_BelegPos.Artikel
      no-lock.

    if basis.buro.cls.BBCWorkflowSvc:prpoInstance:lHasLockStatusWarningOrLock
      (bS_Artikel.S_Artikel_Obj,
       TT_E_BelegPos.Bereich) then
    do:

      basis.buro.cls.BBCWorkflowSvc:prpoInstance:showLockStatus
        (bS_Artikel.S_Artikel_Obj,
         TT_E_BelegPos.Bereich)
        no-error.

      if error-status:error then
      do:

        glFehler = yes.
        return.

      end.

      /* Dieser Befehl wurde eingef�gt, damit nach erscheinen der Zust�nde */
      /* nicht der Initialwert des Liefertermins erscheint.                */
      /* Der Effekt war nur zu sehen, wenn der Liefertermin durch ein      */
      /* anderes Objekt verdeckt worden war.                               */

      run RepositionBrowse(rowid(TT_E_BelegPos)) no-error.

    end. /* if TT_E_BelegPos.Funktion >= 1 */

    if gcTargetDocType = 'EBB':U then
    do:

      run eink/proc/e_uab_12.w (TT_E_BelegPos.BelegArt,
                                TT_E_BelegPos.ReferenzNr,
                                TT_E_BelegPos.PositionsNr,
                                E_AB_Kopf.ReferenzNr,
                                TT_E_BelegPos.AB_PositionsNr,
                                gdLastABPos,
                                input-output cTmp).

      for each E_AB_PosTermin
        where E_AB_PosTermin.Firma            = {firma/ebelkop.fir pa-Firma}
          and E_AB_PosTermin.Herk_BelegArt    = TT_E_BelegPos.BelegArt
          and E_AB_PosTermin.Herk_ReferenzNr  = TT_E_BelegPos.ReferenzNr
          and E_AB_PosTermin.Herk_PositionsNr = TT_E_BelegPos.PositionsNr
          and E_AB_PosTermin.Wunschtermin     > 01/01/1900
          and E_AB_PosTermin.Liefertermin     > 01/01/1900
          and E_AB_PosTermin.ReferenzNr       = E_AB_Kopf.ReferenzNr
        no-lock
        on error undo, throw:

        dMenge = dMenge + E_AB_PosTermin.Menge.

      end. /* for each E_AB_PosTermin */

    end. /* if gcTargetDocType = 'EBB':U */

    assign
      TT_E_BelegPos.Menge
        = dMenge
      {adm/incl/d__bcs00.if
         &BrowseCell  = "TT_E_BelegPos.Menge"
         &ScreenValue = "string(TT_E_BelegPos.Menge, entry(TT_E_BelegPos.NachKomma + 1, {&PA_MENGENEINGABEFORMAT}, {&PA-DELIMITER4}))"
         &WithFrame   = "in browse {&browse-name}"}
      .

  end. /* if available TT_E_BelegPos */

end procedure.

/* _UIB-CODE-BLOCK-END */
&ANALYZE-RESUME

&ANALYZE-SUSPEND _UIB-CODE-BLOCK _PROCEDURE adm-open-query-cases B-table-Win  adm/support/proc/ds_opn00.p
PROCEDURE adm-open-query-cases :
/* Description ---------------------------------------------------------------*/
/*                                                                            */
/* Opens different cases of the query based on attributes such as the         */
/* 'Key-Name', or 'SortBy-Case'                                               */
/*                                                                            */
/* Parameters ----------------------------------------------------------------*/
/*                                                                            */
/* <none>                                                                     */
/*                                                                            */
/*----------------------------------------------------------------------------*/

/*----------------------------------------------------------------------------*/
/* Processing                                                                 */
/*----------------------------------------------------------------------------*/

/* Initialize                                                                 */

{adm/template/incl/dt_opn00.if}

/* no "keys-accepted" supported by this procedure                             */

/* Open Query                                                                 */

case pa-sortby-case:
  when 'PositionsNr':U then
    if pa-DescendingSortOrder then
      &IF "{&PA-USE-INDEX-IN-QUERY}":U = "1":U &THEN
        &SCOP SORTBY-PHRASE use-index Main ~{&PA-VIRTUAL-INDEX-DUMMY-SORTBY-PHRASE-DESC} BY TT_E_BelegPos.PositionsNr DESCENDING BY TT_E_BelegPos.ReferenzNr DESCENDING BY TT_E_BelegPos.Belegart DESCENDING BY TT_E_BelegPos.AB_PositionsNr DESCENDING BY TT_E_BelegPos.Source_Obj DESCENDING
      &ELSE
        &SCOP SORTBY-PHRASE ~{&PA-VIRTUAL-INDEX-DUMMY-SORTBY-PHRASE-DESC} BY TT_E_BelegPos.PositionsNr DESCENDING BY TT_E_BelegPos.ReferenzNr DESCENDING BY TT_E_BelegPos.Belegart DESCENDING BY TT_E_BelegPos.AB_PositionsNr DESCENDING BY TT_E_BelegPos.Source_Obj DESCENDING
      &ENDIF
    &SCOP KEY-PHRASE TT_E_BelegPos.PositionsNr {&PA-OFFSET-COMPARE-GE-DESC} decimal(c_offset-value) {&PA-FILTER-PHRASE}
    if c_offset-value <> ? then
      {&OPEN-QUERY-{&BROWSE-NAME}}
    &SCOP KEY-PHRASE true {&PA-FILTER-PHRASE}
      else
        {&OPEN-QUERY-{&BROWSE-NAME}}

    else
      &IF "{&PA-USE-INDEX-IN-QUERY}":U = "1":U &THEN
        &SCOP SORTBY-PHRASE use-index Main ~{&PA-VIRTUAL-INDEX-DUMMY-SORTBY-PHRASE} BY TT_E_BelegPos.PositionsNr BY TT_E_BelegPos.ReferenzNr BY TT_E_BelegPos.Belegart BY TT_E_BelegPos.AB_PositionsNr BY TT_E_BelegPos.Source_Obj
      &ELSE
        &SCOP SORTBY-PHRASE ~{&PA-VIRTUAL-INDEX-DUMMY-SORTBY-PHRASE} BY TT_E_BelegPos.PositionsNr BY TT_E_BelegPos.ReferenzNr BY TT_E_BelegPos.Belegart BY TT_E_BelegPos.AB_PositionsNr BY TT_E_BelegPos.Source_Obj
      &ENDIF
      &SCOP KEY-PHRASE TT_E_BelegPos.PositionsNr {&PA-OFFSET-COMPARE-GE-ASC} decimal(c_offset-value) {&PA-FILTER-PHRASE}
      if c_offset-value <> ? then
        {&OPEN-QUERY-{&BROWSE-NAME}}
      &SCOP KEY-PHRASE true {&PA-FILTER-PHRASE}
      else
        {&OPEN-QUERY-{&BROWSE-NAME}}

  when 'BestellNr':U then
    if pa-DescendingSortOrder then
      &IF "{&PA-USE-INDEX-IN-QUERY}":U = "1":U &THEN
        &SCOP SORTBY-PHRASE use-index BestellNr ~{&PA-VIRTUAL-INDEX-DUMMY-SORTBY-PHRASE-DESC} BY TT_E_BelegPos.BestellNr DESCENDING
      &ELSE
        &SCOP SORTBY-PHRASE ~{&PA-VIRTUAL-INDEX-DUMMY-SORTBY-PHRASE-DESC} BY TT_E_BelegPos.BestellNr DESCENDING
      &ENDIF
    &SCOP KEY-PHRASE TT_E_BelegPos.BestellNr {&PA-OFFSET-COMPARE-GE-DESC} c_offset-value {&PA-FILTER-PHRASE}
    if c_offset-value <> ? then
      {&OPEN-QUERY-{&BROWSE-NAME}}
    &SCOP KEY-PHRASE true {&PA-FILTER-PHRASE}
      else
        {&OPEN-QUERY-{&BROWSE-NAME}}

    else
      &IF "{&PA-USE-INDEX-IN-QUERY}":U = "1":U &THEN
        &SCOP SORTBY-PHRASE use-index BestellNr ~{&PA-VIRTUAL-INDEX-DUMMY-SORTBY-PHRASE} BY TT_E_BelegPos.BestellNr
      &ELSE
        &SCOP SORTBY-PHRASE ~{&PA-VIRTUAL-INDEX-DUMMY-SORTBY-PHRASE} BY TT_E_BelegPos.BestellNr
      &ENDIF
      &SCOP KEY-PHRASE TT_E_BelegPos.BestellNr {&PA-OFFSET-COMPARE-GE-ASC} c_offset-value {&PA-FILTER-PHRASE}
      if c_offset-value <> ? then
        {&OPEN-QUERY-{&BROWSE-NAME}}
      &SCOP KEY-PHRASE true {&PA-FILTER-PHRASE}
      else
        {&OPEN-QUERY-{&BROWSE-NAME}}

  when 'LagerOrt':U then
    if pa-DescendingSortOrder then
      &IF "{&PA-USE-INDEX-IN-QUERY}":U = "1":U &THEN
        &SCOP SORTBY-PHRASE use-index LagerOrt ~{&PA-VIRTUAL-INDEX-DUMMY-SORTBY-PHRASE-DESC} BY TT_E_BelegPos.LagerOrt DESCENDING BY TT_E_BelegPos.Abruf DESCENDING
      &ELSE
        &SCOP SORTBY-PHRASE ~{&PA-VIRTUAL-INDEX-DUMMY-SORTBY-PHRASE-DESC} BY TT_E_BelegPos.LagerOrt DESCENDING BY TT_E_BelegPos.Abruf DESCENDING
      &ENDIF
    &SCOP KEY-PHRASE TT_E_BelegPos.LagerOrt {&PA-OFFSET-COMPARE-GE-DESC} integer(c_offset-value) {&PA-FILTER-PHRASE}
    if c_offset-value <> ? then
      {&OPEN-QUERY-{&BROWSE-NAME}}
    &SCOP KEY-PHRASE true {&PA-FILTER-PHRASE}
      else
        {&OPEN-QUERY-{&BROWSE-NAME}}

    else
      &IF "{&PA-USE-INDEX-IN-QUERY}":U = "1":U &THEN
        &SCOP SORTBY-PHRASE use-index LagerOrt ~{&PA-VIRTUAL-INDEX-DUMMY-SORTBY-PHRASE} BY TT_E_BelegPos.LagerOrt BY TT_E_BelegPos.Abruf
      &ELSE
        &SCOP SORTBY-PHRASE ~{&PA-VIRTUAL-INDEX-DUMMY-SORTBY-PHRASE} BY TT_E_BelegPos.LagerOrt BY TT_E_BelegPos.Abruf
      &ENDIF
      &SCOP KEY-PHRASE TT_E_BelegPos.LagerOrt {&PA-OFFSET-COMPARE-GE-ASC} integer(c_offset-value) {&PA-FILTER-PHRASE}
      if c_offset-value <> ? then
        {&OPEN-QUERY-{&BROWSE-NAME}}
      &SCOP KEY-PHRASE true {&PA-FILTER-PHRASE}
      else
        {&OPEN-QUERY-{&BROWSE-NAME}}

  {&{&PA-XBASISNAME}_C_OpenQueryCases}
  {&{&PA-XBASISNAME}_U_OpenQueryCases}
  {&{&PA-XBASISNAME}_Q_OpenQueryCases}
  {&{&PA-XBASISNAME}_OpenQueryCases}
  {&{&PA-XBASISNAME}_Y_OpenQueryCases}

  {&{&PA-XBASISNAME}_C_OpenQueryCases_Sort}
  {&{&PA-XBASISNAME}_U_OpenQueryCases_Sort}
  {&{&PA-XBASISNAME}_Q_OpenQueryCases_Sort}
  {&{&PA-XBASISNAME}_OpenQueryCases_Sort}
  {&{&PA-XBASISNAME}_Y_OpenQueryCases_Sort}

  otherwise
    {adm/template/incl/dt_vbs10.if
      &ippSortCaseName = "pa-sortby-case"
      &ippOffsetValue  = "c_offset-value"
    }

end case.

return.

end procedure. /* adm-open-query-cases */

/* _UIB-CODE-BLOCK-END */
&ANALYZE-RESUME

&ANALYZE-SUSPEND _UIB-CODE-BLOCK _PROCEDURE adm-row-available B-table-Win  adm/support/proc/ds_rec00.p
PROCEDURE adm-row-available :
/* Description ---------------------------------------------------------------*/
/*                                                                            */
/* Dispatched to this procedure when the Record-Source has a new row          */
/* available.  This procedure tries to get the new row (or foreign keys)      */
/* from the  Record-Source and process it.                                    */
/*                                                                            */
/* Parameters ----------------------------------------------------------------*/
/*                                                                            */
/* <none>                                                                     */
/*                                                                            */
/*----------------------------------------------------------------------------*/

/*----------------------------------------------------------------------------*/
/* Processing                                                                 */
/*----------------------------------------------------------------------------*/

/* Define variables needed by this internal procedure.                        */

{adm/template/incl/row-head.i}


/* Process the newly available records (i.e. display fields, open queries,    */
/* and/or pass records on to any RECORD-TARGETS).                             */

{adm/template/incl/row-end.i}

end procedure. /* adm-row-available */

/* _UIB-CODE-BLOCK-END */
&ANALYZE-RESUME

&ANALYZE-SUSPEND _UIB-CODE-BLOCK _PROCEDURE ChangeFieldStatus B-table-Win 
PROCEDURE ChangeFieldStatus :
/* Description ---------------------------------------------------------------*/
/*                                                                            */
/* Set the browse columns depending the input parameter to writeable or read  */
/* only.                                                                      */
/*                                                                            */
/* Parameters ----------------------------------------------------------------*/
/*                                                                            */
/* plEnable       i   Sign to enable or disable the browse fields             */
/*                                                                            */
/*----------------------------------------------------------------------------*/

define input parameter plEnable as logical no-undo.

if    plEnable
  and pa-fields-enabled then
do:

  {fnarg
    pa_lUISvcEnableBrowseColumn
    "TT_E_BelegPos.AB_PositionsNr:handle in browse {&browse-name}"}.

  {fnarg
    pa_lUISvcEnableBrowseColumn
    "TT_E_BelegPos.Liefertermin:handle in browse {&browse-name}"}.

  {fnarg
    pa_lUISvcEnableBrowseColumn
    "TT_E_BelegPos.Menge:handle in browse {&browse-name}"}.
     
end. /* if plEnable */
else
do:

  {fnarg
    pa_lUISvcDisableBrowseColumn
    "TT_E_BelegPos.AB_PositionsNr:handle in browse {&browse-name}"}.

  {fnarg
    pa_lUISvcDisableBrowseColumn
    "TT_E_BelegPos.Liefertermin:handle in browse {&browse-name}"}.

  {fnarg
    pa_lUISvcDisableBrowseColumn
    "TT_E_BelegPos.Menge:handle in browse {&browse-name}"}.
   
end. /* else: if plEnable */

return.

end procedure.

/* _UIB-CODE-BLOCK-END */
&ANALYZE-RESUME

&ANALYZE-SUSPEND _UIB-CODE-BLOCK _PROCEDURE CheckDeliveryDate B-table-Win
procedure CheckDeliveryDate :
/* Description ---------------------------------------------------------------*/
/*                                                                            */
/* Check delivery date                                                        */
/*                                                                            */
/*----------------------------------------------------------------------------*/

define variable tDate as date no-undo.

if available TT_E_BelegPos then
do on error undo, throw:

  glWrongInput = no.

  tDate = date({getwidgetattr TT_E_BelegPos.Liefertermin screen-value string "in browse {&BROWSE-NAME}"}) no-error.

  if   error-status:error
    or tDate < today - {&pa_S_Liefertermin_Vergangenheit}
    or tDate > today + {&pa_S_Liefertermin_Zukunft} then
  do:

    assign
      gcEntryField = 'Liefertermin':U
      glWrongInput = yes
      glFehler     = yes
      .

    adm.method.cls.DMCMessageSvc:prpoInstance:showError
      ('e_ab_00008':U).

  end. /* if   error-status:error */

  catch oError as Progress.Lang.Error:

    run pa_UISvcApplyEventToWidgetByHandle
          ('entry':U,
           TT_E_BelegPos.Liefertermin:handle).

    {adm/incl/d__bcs00.if
       &BrowseCell  = "TT_E_BelegPos.Liefertermin"
       &ScreenValue = "string(?)"
       &WithFrame   = "in browse {&browse-name}"}.

    undo, throw oError.

  end catch. /* oError */

end. /* if available TT_E_BelegPos */

end procedure. /* CheckDeliveryDate */

/* _UIB-CODE-BLOCK-END */
&ANALYZE-RESUME

&ANALYZE-SUSPEND _UIB-CODE-BLOCK _PROCEDURE CheckPackage B-table-Win 
PROCEDURE CheckPackage :
/* Description ---------------------------------------------------------------*/
/*                                                                            */
/* Check the Packaging.                                                       */
/*                                                                            */
/* Notes ---------------------------------------------------------------------*/
/*                                                                            */
/*                                                                            */
/*                                                                            */
/* Parameters ----------------------------------------------------------------*/
/*                                                                            */
/* <none>                                                                     */
/*                                                                            */
/*----------------------------------------------------------------------------*/

&IF   lookup ("EB_DESADV":U,"{&PA-OPTIONEN}":U) > 0
  and lookup ("M_PACK":U,"{&PA-OPTIONEN}":U)    > 0 &THEN

  /* Variables ---------------------------------------------------------------*/
  /* cPMKeyAdopt3 Call orders are adopted to the despatch advice using the    */
  /*              ObjectID of the header (EBT_CallOrder_Obj). Besides this,   */
  /*              packaging may reference to the valid purchase release       */
  /*              (EBT_PurchRelease_Obj). cPMKeyAdopt3 gets the presently     */
  /*              valid key for adopting packaging from call orders and other */
  /*              documet types.                                              */
  /*--------------------------------------------------------------------------*/

  define variable cPMKeyAdopt3 like EBT_PurchRelease.EBT_PurchRelease_Obj no-undo.

  /* Buffers -----------------------------------------------------------------*/

  /*--------------------------------------------------------------------------*/
  /* Processing                                                               */
  /*--------------------------------------------------------------------------*/

  if available TT_E_BelegPos then
  do:

    cPMKeyAdopt3 = mawi.base.cls.MMCPackagingSvc:prpoInstance:cCheckPMKeyAdopt3
                     (TT_E_BelegPos.BelegArt,
                      {&pa_MM_PackagingInformational},             /* Function Code 9 */
                      gcSource_Obj,
                      TT_E_BelegPos.Source_Obj).

    if cPMKeyAdopt3 > '':U then

      run mawi/proc/m_vpmi01.p (pACConnectionSvc:prpcCompany,
                                {&pa_ML_PackagingArea_Purchasing},
                                {&pa_MM_PackagingInformational},  /* Function Code 9 */
                                TT_E_BelegPos.BelegArt,
                                gcSource_Obj,
                                TT_E_BelegPos.BelegArt,
                                cPMKeyAdopt3,
                                TT_E_BelegPos.Artikel,
                                decimal({getwidgetattr TT_E_BelegPos.Menge screen-value string "in browse {&BROWSE-NAME}"}),
                                TT_E_BelegPos.MengenEinheit,
                                pACConnectionSvc:prpcLanguage).

  end. /* if available TT_E_BelegPos then */

&ENDIF /* &IF lookup ("M_PACK":U,"{&PA-OPTIONEN}":U) > 0 &THEN */

end procedure. /* CheckPackage */

/* _UIB-CODE-BLOCK-END */
&ANALYZE-RESUME

&ANALYZE-SUSPEND _UIB-CODE-BLOCK _PROCEDURE ConfirmPackage B-table-Win 
PROCEDURE ConfirmPackage :
/* Description ---------------------------------------------------------------*/
/*                                                                            */
/* This procedure is called in the row-leave trigger in order to keep it      */
/* smaller. Packaging is reviewed, whether all parameters are consistent.     */
/* If not, then new packaging records are created.                            */
/*                                                                            */
/* Notes ---------------------------------------------------------------------*/
/*                                                                            */
/*                                                                            */
/*                                                                            */
/* Parameters ----------------------------------------------------------------*/
/*                                                                            */
/* <none>                                                                     */
/*                                                                            */
/*----------------------------------------------------------------------------*/

&IF   lookup("EB_DESADV":U,"{&PA-OPTIONEN}":U) > 0
  and lookup ("M_Pack":U,"{&PA-OPTIONEN}":U) > 0 &THEN

/* Variables -----------------------------------------------------------------*/
/* lNewPackage  Flag, whether new package should be created                   */
/* cPMKeyAdopt3 Call orders are adopted to the stock receipt using the        */
/*              ObjectID of the header (EBT_CallOrder_Obj). Besides this,     */
/*              packaging may reference to the valid purchase release         */
/*              (EBT_PurchRelease_Obj). cPMKeyAdopt3 gets the presently       */
/*              valid key for adopting packaging from call orders and other   */
/*              documet types.                                                */
/*----------------------------------------------------------------------------*/

  define variable cPMKeyAdopt3 like M_LTPos.Herk_Schluessel3  no-undo.
  define variable lNewPackage  as logical init yes            no-undo.

  /* Buffers -----------------------------------------------------------------*/

  define buffer bE_BelegPos     for E_BelegPos.
  define buffer bEBT_CallOrder  for EBT_CallOrder.

  /*--------------------------------------------------------------------------*/
  /* Processing                                                               */
  /*--------------------------------------------------------------------------*/

  if TT_E_BelegPos.Wertposition = no then
  do:

    if mawi.base.cls.MMCPackagingSvc:prpoInstance:cCheckPMKeyAdopt3
        (TT_E_BelegPos.BelegArt,
         {&pa_MM_PackagingInformational},   /* Function Code 9 */
         gcSource_Obj,
         TT_E_BelegPos.Source_Obj) > '':U then
    do:

      run CheckPackage no-error.

      if error-status:error then
      do:

        /* If there extists packaging for the present line, either    */
        /* delete it after confirmation or create a new one.          */

        /* Message: M�chten Sie die Menge von &1 &2 neu verpacken? ---- */

        cPMKeyAdopt3 = mawi.base.cls.MMCPackagingSvc:prpoInstance:cCheckPMKeyAdopt3
                         (TT_E_BelegPos.BelegArt,
                          (if TT_E_BelegPos.BelegArt = 'ERL':U then
                             {&pa_MM_PackagingDelivery}         /* Function Code 4 */
                           else
                             {&pa_MM_PackagingInstruction}),    /* Function Code 1 */
                          gcSource_Obj,
                          TT_E_BelegPos.Source_Obj).

        if    cPMKeyAdopt3            > '':U
          and adm.method.cls.DMCMessageSvc:prpoInstance:lShowMessage
                ('v_bel20002':U,
                 string(TT_E_BelegPos.Menge),
                 TT_E_BelegPos.MEBez) = yes then

          run mawi/proc/m_vpmi04.p (pACConnectionSvc:prpcCompany,
                                    {&pa_ML_PackagingArea_Purchasing},
                                    {&pa_MM_PackagingInformational},  /* Function Code 9 */
                                    '':U,
                                    '':U,
                                    TT_E_BelegPos.BelegArt,
                                    gcSource_Obj,
                                    TT_E_BelegPos.BelegArt,
                                    cPMKeyAdopt3,
                                    yes).

        else
        do:

          run pa_UISvcApplyEventToWidgetByHandle
                ('entry':U,
                 TT_E_BelegPos.Menge:handle in browse {&browse-name}).

          return.

        end. /* else do: */

      end. /* if error-status:error then */
      else

        lNewPackage = no.

    end. /* if mawi.base.cls.MMCPackagingSvc:prpoInstance:cCheckPMKeyAdopt3 */

    /* Create the packaging for the part */

    cPMKeyAdopt3 = mawi.base.cls.MMCPackagingSvc:prpoInstance:cCheckPMKeyAdopt3
                     (TT_E_BelegPos.BelegArt,
                      (if TT_E_BelegPos.BelegArt = 'ERL':U then
                         {&pa_MM_PackagingDelivery}         /* Function Code 4 */
                       else
                         {&pa_MM_PackagingInstruction}),    /* Function Code 1 */
                      gcSource_Obj,
                      TT_E_BelegPos.Source_Obj).

    if    lNewPackage
      and cPMKeyAdopt3                                              > '':U
      and {getwidgetattr TT_E_BelegPos.AB_PositionsNr input-value decimal "in browse {&BROWSE-NAME}"} <> ? then
    do:

      /* Check whether an existing packaging regulation should be     */
      /* used.                                                        */

      if adm.method.cls.DMCMessageSvc:prpoInstance:lShowMessage
           ('m_pac00134':U,
            TT_E_BelegPos.Artikel) = yes then
      do:

        if can-do ('EB,EAB,ERL':U,TT_E_BelegPos.BelegArt) then

          find bE_BelegPos
            where rowid (bE_BelegPos) = to-rowid (TT_E_BelegPos.RowidString)
            no-lock.

        else

          find bEBT_CallOrder
            where bEBT_CallOrder.EBT_CallOrder_Obj = TT_E_BelegPos.Source_Obj
            no-lock.

        run mawi/proc/m_vpmi11.p (pACConnectionSvc:prpcCompany,
                                  {&pa_ML_PackagingArea_Purchasing},
                                  (if TT_E_BelegPos.BelegArt = 'ERL':U then
                                     {&pa_MM_PackagingDelivery}      /* Function Code 4 */
                                   else
                                     {&pa_MM_PackagingInstruction}), /* Function Code 1 */
                                  TT_E_BelegPos.BelegArt,
                                  gcSource_Obj,
                                  TT_E_BelegPos.BelegArt,
                                  cPMKeyAdopt3,
                                  'E':U,
                                  {&pa_MM_PackagingInformational},   /* Function Code 9 */
                                  TT_E_BelegPos.BelegArt,
                                  gcSource_Obj,
                                  TT_E_BelegPos.BelegArt,
                                  cPMKeyAdopt3,
                                  {&pa_MM_PackagingInformational},   /* Function Code 9 */
                                  TT_E_BelegPos.Artikel,
                                  TT_E_BelegPos.ArtVar,
                                  (if can-do ('EB,EAB,ERL':U,TT_E_BelegPos.BelegArt) then
                                     bE_BelegPos.Gewicht
                                   else
                                     bEBT_CallOrder.Gewicht),
                                  0,
                                  decimal({getwidgetattr TT_E_BelegPos.Menge screen-value string "in browse {&BROWSE-NAME}"}),
                                  TT_E_BelegPos.MengenEinheit,
                                  no).                               /* Set */

      end. /* if adm.method.cls.DMCMessageSvc:prpoInstance:lShowMessage */

    end. /* if    lNewPackage */

  end. /* if TT_E_BelegPos.Wertposition = no then */

&ENDIF /* &IF   lookup("EB_DESADV":U,"{&PA-OPTIONEN}":U) > 0 */

end procedure. /* ConfirmPackage */

/* _UIB-CODE-BLOCK-END */
&ANALYZE-RESUME

&ANALYZE-SUSPEND _UIB-CODE-BLOCK _PROCEDURE CreateShippingDocLines B-table-Win 
PROCEDURE CreateShippingDocLines :
/* Description ---------------------------------------------------------------*/
/*                                                                            */
/*   Create Shipping Document Lines                                           */
/*                                                                            */
/* Notes ---------------------------------------------------------------------*/
/*                                                                            */
/*                                                                            */
/*                                                                            */
/* Parameters ----------------------------------------------------------------*/
/*                                                                            */
/* <none>                                                                     */
/*                                                                            */
/* Examples ------------------------------------------------------------------*/
/*                                                                            */
/*                                                                            */
/*                                                                            */
/*----------------------------------------------------------------------------*/

/* Variables -----------------------------------------------------------------*/
/*                                                                            */
/*   dOldDeliveryQty     Delivery quantity of yet existing delivery lines     */
/*   dQtyDelivered       Quantity which has yet been delivered for a delivery */
/*                       line                                                 */
/*                                                                            */
/*----------------------------------------------------------------------------*/

define variable dOldDeliveryQty  like EBT_DeliveryPos.Liefermenge             no-undo init 0.
define variable dQtyDelivered    like E_WE_Pos.Liefermenge                    no-undo init 0.
define variable oMaterialPosting as class mawi.base.cls.MMCMaterialPostingSvo no-undo.

&IF lookup ("M_Pack":U,"{&PA-OPTIONEN}":U) > 0 &THEN
  define variable cPMKeyAdopt3   like M_LTPos.Herk_Schluessel3                no-undo.
&ENDIF

/* Buffers -------------------------------------------------------------------*/

define buffer bE_BelegKopf        for E_BelegKopf.
define buffer bE_BelegPos         for E_BelegPos.
define buffer bE_BelegPosTermin   for E_BelegPosTermin.
define buffer EBT_DeliveryPos     for EBT_DeliveryPos.
define buffer bEBT_CallOrder      for EBT_CallOrder.
define buffer bEBT_PurchRelease   for EBT_PurchRelease.
define buffer bEBT_DeliveryPos    for EBT_DeliveryPos.
define buffer bS_Artikel          for S_Artikel.
define buffer bS_ArtVar           for S_ArtVar.
define buffer MMM_CusRefOrder     for MMM_CusRefOrder.
define buffer bS_Mengeneinheit    for S_MengenEinheit.
define buffer E_WE_Pos            for E_WE_Pos.
define buffer E_WE_Kopf           for E_WE_Kopf.
&IF LOOKUP("MC":U,"{&PA-MODULE}":U) > 0 &THEN
  define buffer bMCL_LotReference for MCL_LotReference.
&ENDIF
&IF lookup ("S_ProfCenter":U,"{&PA-OPTIONEN}":U) > 0 &THEN
  define buffer bEBT_DesAdv-excl  for EBT_DesAdv.
  define buffer bEBT_Delivery     for EBT_Delivery.
&ENDIF

/*----------------------------------------------------------------------------*/
/* Processing                                                                 */
/*----------------------------------------------------------------------------*/

Main: do transaction
  on error undo, throw:

  /* 'assign-record' in order to prevent problems which may arise if          */
  /* modifying the present record and using the OK-button via Return.         */

  run dispatch ('assign-record':U).

  if return-value <> 'ADM-ERROR':U then
  do:

    if    valid-handle ({focus})
      and gdQtySuggested
            <> decimal({getwidgetattr TT_E_BelegPos.Menge screen-value string "in browse {&BROWSE-NAME}"}) then

      apply 'leave':U to TT_E_BelegPos.Menge in browse {&BROWSE-NAME}.

    apply 'row-leave':U to {&browse-name} in frame {&frame-name}.

    if glFehler then

      adm.method.cls.DMCMessageSvc:prpoInstance:showError('s_bel00002':U).

    if can-do ('EB,EAB,ERL':U,TT_E_BelegPos.BelegArt) then
    do:

      find bE_BelegKopf
        where bE_BelegKopf.E_BelegKopf_Obj = gcSource_Obj
        exclusive-lock no-wait no-error.

      if not available bE_BelegKopf then
      do:

        find bE_BelegKopf
          where bE_BelegKopf.E_BelegKopf_Obj = gcSource_Obj
          no-lock.

        adm.method.cls.DMCMessageSvc:prpoInstance:showError
          ('m_bel00007':U,
           string(bE_BelegKopf.BelegNummer)).

      end. /* if not available bE_BelegKopf */

    end. /* if lookup(TT_E_BelegPos.BelegArt,'EB,EAB,ERL':U) */
    else
    do:

      find bEBT_CallOrder
        where bEBT_CallOrder.EBT_CallOrder_Obj = gcSource_Obj
        exclusive-lock no-wait no-error.

      if not available bEBT_CallOrder then
      do:

        find bEBT_CallOrder
          where bEBT_CallOrder.EBT_CallOrder_Obj = gcSource_Obj
          no-lock.

        adm.method.cls.DMCMessageSvc:prpoInstance:showError
          ('m_bel00007':U,
           string(bEBT_CallOrder.BelegNummer)).

      end. /* if not available bEBT_CallOrder */

    end. /* else do: */

    &IF lookup ("S_ProfCenter":U,"{&PA-OPTIONEN}":U) > 0 &THEN

      /* If the profitcenter is required and the source document does not   */
      /* have one, then maintain the present profit center whithout asking. */
      /* If a source profit center is given, then decide which one will be  */
      /* used.                                                              */

      if    not can-find (first bEBT_Delivery
                  where bEBT_Delivery.EBT_DesAdv_Obj = EBT_DesAdv.EBT_DesAdv_Obj
                    and can-find (first bEBT_DeliveryPos
                          where bEBT_DeliveryPos.EBT_Delivery_Obj = bEBT_Delivery.EBT_Delivery_Obj))
        and stamm.base.cls.SBCProfitCenterSvc:prpoInstance:lIsProfitCenterRequiredOrOptional('EDA':U)
        and EBT_DesAdv.SBM_ProfitCenter_ID <> (if can-do ('EB,EAB,ERL':U,TT_E_BelegPos.BelegArt) then
                                                 bE_BelegKopf.SBM_ProfitCenter_ID
                                               else
                                                 bEBT_CallOrder.SBM_ProfitCenter_ID)
        and (if can-do ('EB,EAB,ERL':U,TT_E_BelegPos.BelegArt) then
               bE_BelegKopf.SBM_ProfitCenter_ID > '':U
             else
               bEBT_CallOrder.SBM_ProfitCenter_ID > '':U)
        and not adm.method.cls.DMCMessageSvc:prpoInstance:lShowMessage
                  ('ebpro00001':U,
                    EBT_DesAdv.SBM_ProfitCenter_ID,
                    (if can-do ('EB,EAB,ERL':U,TT_E_BelegPos.BelegArt) then
                       bE_BelegKopf.SBM_ProfitCenter_ID
                     else
                       bEBT_CallOrder.SBM_ProfitCenter_ID)) then
      do:

        find bEBT_DesAdv-excl
          where bEBT_DesAdv-excl.EBT_DesAdv_Obj = EBT_DesAdv.EBT_DesAdv_Obj
          exclusive-lock.

        stamm.base.cls.SBCProfitCenterSvc:prpoInstance:ChooseProfitCenterDocAdopt
          (             (if can-do ('EB,EAB,ERL':U,TT_E_BelegPos.BelegArt) then
                           bE_BelegKopf.SBM_ProfitCenter_Obj
                         else
                           bEBT_CallOrder.SBM_ProfitCenter_Obj),
                        (if can-do ('EB,EAB,ERL':U,TT_E_BelegPos.BelegArt) then
                           bE_BelegKopf.SBM_ProfitCenter_ID
                         else
                           bEBT_CallOrder.SBM_ProfitCenter_ID),
                        '':U,
                        'EDA':U,
           input-output bEBT_DesAdv-excl.SBM_ProfitCenter_Obj,
           input-output bEBT_DesAdv-excl.SBM_ProfitCenter_ID).

        validate bEBT_DesAdv-excl.

        run new-state ('ProfitCenterAdopted,record-source':U).

      end. /* if    stamm.base.cls.SBCProfitCenterSvc:prpoInstance:lIsProfitCenterRequiredOrOptional('EDA':U) */

    &ENDIF /* &IF lookup ("S_ProfCenter":U,"{&PA-OPTIONEN}":U) > 0 &THEN */

    /* Delete Shipping Document Lines */

    for each TT_E_BelegPos
      where (TT_E_BelegPos.AB_PositionsNr     = ?
             or TT_E_BelegPos.AB_PositionsNr <> TT_E_BelegPos.AB_PositionsNr_vor)
        and TT_E_BelegPos.LieferantenCharge   = '':U
        on error undo, throw:

      find EBT_DeliveryPos
        where EBT_DeliveryPos.EBT_Delivery_Obj = EBT_Delivery.EBT_Delivery_Obj
          and EBT_DeliveryPos.PositionsNr      = TT_E_BelegPos.AB_PositionsNr_vor
        exclusive-lock no-error.

      /* Check whether line is still appropriate */

      if    available EBT_DeliveryPos
        and EBT_DeliveryPos.Source_Obj = TT_E_BelegPos.Source_Obj then

        delete EBT_DeliveryPos.

    end. /* for each TT_E_BelegPos */

    /* Insert AB_PositionsNr */

    for each TT_E_BelegPos
      where TT_E_BelegPos.AB_PositionsNr <> ?
      break by TT_E_BelegPos.PositionsNr
      on error undo, throw:

      if can-do ('EB,EAB,ERL':U,TT_E_BelegPos.BelegArt) then

        find bE_BelegPos
          where rowid (bE_BelegPos) = to-rowid (TT_E_BelegPos.RowidString)
          no-lock.

      /* L�sche die best�tigten Positionen zu dieser Bestellposition, bei     */
      /* erster best�tigter Position zur Bestellposition.                     */

      /* Delete the confirmed lines to this purchase order line */

      if first-of(TT_E_BelegPos.PositionsNr) then
      do:

        /* memorise links to rebuild them */

        mawi.base.cls.MMCMRPLinkSvc:prpoInstance:GetMRPLink
          (       (if can-do ('EB,EAB,ERL':U,TT_E_BelegPos.BelegArt) then
                     bE_BelegPos.E_BelegPos_Obj
                   else
                     bEBT_CallOrder.EBT_CallOrder_Obj),
           output table ttMM_MRPLinkAPI by-reference).

        for each EBT_DeliveryPos
          where EBT_DeliveryPos.Source_Obj        = (if can-do ('EB,EAB,ERL':U,TT_E_BelegPos.BelegArt) then
                                                       bE_BelegPos.E_BelegPos_Obj
                                                     else
                                                       bEBT_CallOrder.EBT_CallOrder_Obj)
            and EBT_DeliveryPos.EBT_Delivery_Obj  = EBT_Delivery.EBT_Delivery_Obj
            and can-find (EBT_DesAdv
                            where EBT_DesAdv.EBT_DesAdv_Obj = EBT_Delivery.EBT_DesAdv_Obj)
          exclusive-lock
          on error undo, throw:

          &IF LOOKUP("MC":U,"{&PA-MODULE}":U) > 0 &THEN

            if not can-find (first MCL_LotReference
                     where MCL_LotReference.Owning_Obj   = EBT_DeliveryPos.EBT_DeliveryPos_Obj
                       and MCL_LotReference.LotSupplier <> TT_E_BelegPos.LieferantenCharge) then

          &ENDIF

              delete EBT_DeliveryPos.

        end. /* for each EBT_DeliveryPos */

      end. /* if first-of(TT_E_BelegPos.PositionsNr) */

      /* Check, whether the line number has yet been allocated. */

      if can-find (bEBT_DeliveryPos
           where bEBT_DeliveryPos.EBT_Delivery_Obj = EBT_Delivery.EBT_Delivery_Obj
             and bEBT_DeliveryPos.PositionsNr      = TT_E_BelegPos.AB_PositionsNr) then
      do:

        run pa_UISvcBrowseSelectRow(browse {&browse-name}:handle, 1).

        gcEntryField = 'AB_PositionsNr':U.

        adm.method.cls.DMCMessageSvc:prpoInstance:showError
          ('e_ab_00006':U,
           string(TT_E_BelegPos.AB_PositionsNr)).

      end. /* if can-find(bEBT_DeliveryPos */

      else
      do:

        find bS_Artikel
          where bS_Artikel.Firma   = {firma/sartikel.fir pa-Firma}
            and bS_Artikel.Artikel = (if can-do ('EB,EAB,ERL':U,TT_E_BelegPos.BelegArt) then
                                        bE_BelegPos.Artikel
                                      else
                                        bEBT_CallOrder.Artikel)
          no-lock.

        find bS_ArtVar
          where bS_ArtVar.ArtVarTyp = bS_Artikel.ArtVarTyp
            and bS_ArtVar.ArtVar    = (if can-do ('EB,EAB,ERL':U,TT_E_BelegPos.BelegArt) then
                                         bE_BelegPos.ArtVar
                                       else
                                         bEBT_CallOrder.ArtVar)
          no-lock no-error.

        find MMM_CusRefOrder
          where MMM_CusRefOrder.Company            = {firma/mkommis.fir pa-Firma}
            and MMM_CusRefOrder.MMM_CusRefOrder_ID = (if can-do ('EB,EAB,ERL':U,TT_E_BelegPos.BelegArt) then
                                                        bE_BelegPos.MMM_CusRefOrder_ID
                                                      else
                                                        bEBT_CallOrder.MMM_CusRefOrder_ID)
          no-lock no-error.

        if can-do ('EB,EAB,ERL':U,TT_E_BelegPos.BelegArt) then

          find bS_Mengeneinheit
            where bS_Mengeneinheit.Firma         = {firma/smngeinh.fir pa-Firma}
              and bS_Mengeneinheit.Mengeneinheit = bE_BelegPos.Mengeneinheit
            no-lock.

        else

          find bS_Mengeneinheit
            where bS_Mengeneinheit.S_Mengeneinheit_Obj = bEBT_CallOrder.S_Mengeneinheit_Obj
            no-lock.

        find ML_Ort
          where ML_Ort.Firma   = {firma/mlort.fir pa-Firma}
           and ML_Ort.LagerOrt = TT_E_BelegPos.Lagerort
          no-lock no-error.

        /* If up to now no shipping document item exists to the source        */
        /* document item, then create one, otherwise correct the just         */
        /* existing document item.                                            */

        if not can-find (first EBT_DeliveryPos
          where EBT_DeliveryPos.EBT_Delivery_Obj  = EBT_Delivery.EBT_Delivery_Obj
            and EBT_DeliveryPos.Source_Obj        = (if can-do ('EB,EAB,ERL':U,TT_E_BelegPos.BelegArt) then
                                                       bE_BelegPos.E_BelegPos_Obj
                                                     else
                                                       bEBT_CallOrder.EBT_CallOrder_Obj)
            &IF LOOKUP("MC":U,"{&PA-MODULE}":U) > 0 &THEN
              and can-find (first MCL_LotReference     /* code checked by Fichter 23.11.2011 */
                    where MCL_LotReference.Owning_Obj  = EBT_DeliveryPos.EBT_DeliveryPos_Obj
                      and MCL_LotReference.LotSupplier = TT_E_BelegPos.LieferantenCharge)
            &ENDIF
                        ) then
        do:

          /* If there exists yet a stock receipt line with reference to the   */
          /* source document, then respect it for initializing the delivered  */
          /* quantity.                                                        */

          dQtyDelivered = 0.

          for each E_WE_Kopf
            where E_WE_Kopf.Firma             = {firma/ebelkop.fir pa-Firma}
              and E_WE_Kopf.Lieferant         = EBT_Delivery.Lieferant
              and E_WE_Kopf.LieferscheinNr    = EBT_Delivery.LieferscheinNr
              and E_WE_Kopf.LieferscheinDatum = EBT_Delivery.LieferscheinDatum
            no-lock,
            each E_WE_Pos
              where E_WE_Pos.Firma      = E_WE_Kopf.Firma
                and E_WE_Pos.ReferenzNr = E_WE_Kopf.ReferenzNr
                and E_WE_Pos.Source_Obj = TT_E_BelegPos.Source_Obj
              no-lock
            on error undo, throw:

            dQtyDelivered = dQtyDelivered + E_WE_Pos.Liefermenge.

          end. /*  for each E_WE_Kopf */

          create EBT_DeliveryPos.

          assign
            EBT_DeliveryPos.Firma               = (if can-do ('EB,EAB,ERL':U,TT_E_BelegPos.BelegArt) then
                                                     bE_BelegPos.Firma
                                                   else
                                                     bEBT_CallOrder.Firma)
            EBT_DeliveryPos.EBT_Delivery_Obj    = EBT_Delivery.EBT_Delivery_Obj
            EBT_DeliveryPos.Source_Obj          = TT_E_BelegPos.Source_Obj
            EBT_DeliveryPos.Herk_BelegArt       = TT_E_BelegPos.BelegArt
            EBT_DeliveryPos.PositionsNr         = TT_E_BelegPos.AB_PositionsNr
            EBT_DeliveryPos.ML_Ort_Obj          = (if available ML_Ort then
                                                     ML_Ort.ML_Ort_Obj
                                                   else
                                                     '':U)
            EBT_DeliveryPos.Artikel             = bS_Artikel.Artikel
            EBT_DeliveryPos.S_Artikel_Obj       = bS_Artikel.S_Artikel_Obj
            EBT_DeliveryPos.ArtVar              = (if available bS_ArtVar then
                                                     bS_ArtVar.ArtVar
                                                   else
                                                     '':U)
            EBT_DeliveryPos.S_ArtVar_Obj        = (if available bS_ArtVar then
                                                     bS_ArtVar.S_ArtVar_Obj
                                                   else
                                                     '':U)
            EBT_DeliveryPos.MMM_CusRefOrder_ID  = (if can-do ('EB,EAB,ERL':U,TT_E_BelegPos.BelegArt) then
                                                     bE_BelegPos.MMM_CusRefOrder_ID
                                                   else
                                                     bEBT_CallOrder.MMM_CusRefOrder_ID)
            EBT_DeliveryPos.MMM_CusRefOrder_Obj = (if available MMM_CusRefOrder then
                                                     MMM_CusRefOrder.MMM_CusRefOrder_Obj
                                                   else
                                                     '':U)
            EBT_DeliveryPos.S_Mengeneinheit_Obj = bS_Mengeneinheit.S_MengenEinheit_Obj
            EBT_DeliveryPos.Nachkomma           = bS_Mengeneinheit.Nachkomma
            EBT_DeliveryPos.Mengenfaktor        = (if can-do ('EB,EAB,ERL':U,TT_E_BelegPos.BelegArt) then
                                                     bE_BelegPos.Mengenfaktor
                                                   else
                                                     bEBT_CallOrder.Mengenfaktor)
            EBT_DeliveryPos.LieferMenge         = TT_E_BelegPos.Menge
            EBT_DeliveryPos.gelieferte_Menge    = dQtyDelivered
            EBT_DeliveryPos.stornierteMenge     = (if    dQtyDelivered       > 0
                                                     and TT_E_BelegPos.Menge > dQtyDelivered then
                                                     TT_E_BelegPos.Menge - dQtyDelivered
                                                   else
                                                     0)
            EBT_DeliveryPos.Gewicht             = (if can-do ('EB,EAB,ERL':U,TT_E_BelegPos.BelegArt) then
                                                     bE_BelegPos.Gewicht
                                                   else
                                                     bEBT_CallOrder.Gewicht)
            EBT_DeliveryPos.offen               = (dQtyDelivered = 0)
            .

          validate EBT_DeliveryPos.

          /* If it is about a lot, then store the supplier lot if precised    */
          /* in a MCL_LotReference record, which may be modified afterwards.  */
          /* Several suplier lots may be entered later in the delivery line.  */

          &IF LOOKUP("MC":U,"{&PA-MODULE}":U) > 0 &THEN

            if     bS_Artikel.ChargenArt           > '':U
               and TT_E_BelegPos.LieferantenCharge > '':U then
            do:

              create bMCL_LotReference.

              assign
                bMCL_LotReference.Owning_Obj          = EBT_DeliveryPos.EBT_DeliveryPos_Obj
                bMCL_LotReference.Lot                 = '':U
                bMCL_LotReference.LotSupplier         = TT_E_BelegPos.LieferantenCharge
                bMCL_LotReference.LotCustomer         = '':U
                bMCL_LotReference.Quantity            = EBT_DeliveryPos.LieferMenge
                bMCL_LotReference.NoDecimals          = TT_E_BelegPos.NachKomma
                bMCL_LotReference.QtyUnit             = integer(adm.method.cls.DMCSessionSvc:cFieldValuesFromObj(EBT_DeliveryPos.S_MengenEinheit_Obj, 'Mengeneinheit':U))
                bMCL_LotReference.OriginCountry       = '':U
                bMCL_LotReference.Weight              = EBT_DeliveryPos.Gewicht
                bMCL_LotReference.PostedQty           = EBT_DeliveryPos.gelieferte_Menge
                bMCL_LotReference.ExpiryDate          = ?
                bMCL_LotReference.CertificationReport = '':U
                .

              validate bMCL_LotReference.

            end. /* if TT_E_BelegPos.LieferantenCharge > '':U */

          &ENDIF /* &IF LOOKUP("MC":U,"{&PA-MODULE}":U) > 0 */

        end. /* if not can-find (EBT_DeliveryPos */
        else
        do:

          find first EBT_DeliveryPos
            where EBT_DeliveryPos.Source_Obj        = (if can-do ('EB,EAB,ERL':U,TT_E_BelegPos.BelegArt) then
                                                         bE_BelegPos.E_BelegPos_Obj
                                                       else
                                                         bEBT_CallOrder.EBT_CallOrder_Obj)
              and EBT_DeliveryPos.EBT_Delivery_Obj  = EBT_Delivery.EBT_Delivery_Obj
            exclusive-lock.

          assign
            EBT_DeliveryPos.LieferMenge      = EBT_DeliveryPos.LieferMenge
                                               + TT_E_BelegPos.Menge
            EBT_DeliveryPos.gelieferte_Menge = dQtyDelivered
            EBT_DeliveryPos.stornierteMenge  = (if    dQtyDelivered       > 0
                                                  and TT_E_BelegPos.Menge > dQtyDelivered then
                                                  TT_E_BelegPos.Menge - dQtyDelivered
                                                else
                                                  0)
            EBT_DeliveryPos.offen            = (dQtyDelivered = 0)
            .

          validate EBT_DeliveryPos.

          /* Correct also MCL_LotReference if present. */

          &IF LOOKUP("MC":U,"{&PA-MODULE}":U) > 0 &THEN

            find first bMCL_LotReference
              where bMCL_LotReference.Owning_Obj = EBT_DeliveryPos.EBT_DeliveryPos_Obj
              exclusive-lock no-error.

            if available bMCL_LotReference then
            do:

              assign
                bMCL_LotReference.LotSupplier = TT_E_BelegPos.LieferantenCharge
                bMCL_LotReference.Quantity    = EBT_DeliveryPos.LieferMenge
                bMCL_LotReference.Weight      = EBT_DeliveryPos.Gewicht
                bMCL_LotReference.NoDecimals  = TT_E_BelegPos.NachKomma
                bMCL_LotReference.QtyUnit     = integer(adm.method.cls.DMCSessionSvc:cFieldValuesFromObj(EBT_DeliveryPos.S_MengenEinheit_Obj, 'Mengeneinheit':U))
                bMCL_LotReference.Weight      = EBT_DeliveryPos.Gewicht
                bMCL_LotReference.PostedQty   = EBT_DeliveryPos.gelieferte_Menge
                .

              validate bMCL_LotReference.

            end. /* if available bMCL_LotReference */

          &ENDIF /* &IF LOOKUP("MC":U,"{&PA-MODULE}":U) > 0 &THEN */

        end. /* else do: */

        /* If supplier, shipping document number and date correspond          */
        /* to those of an indepentetly created stock receipt line, then adopt */
        /* the delivery line as predecessor of the stock receipt line.        */

        for each E_WE_Kopf
          where E_WE_Kopf.Firma             = {firma/ebelkop.fir pa-Firma}
            and E_WE_Kopf.Lieferant         = EBT_Delivery.Lieferant
            and E_WE_Kopf.LieferscheinNr    = EBT_Delivery.LieferscheinNr
            and E_WE_Kopf.LieferscheinDatum = EBT_Delivery.LieferscheinDatum
          no-lock,
          each E_WE_Pos
            where E_WE_Pos.Firma      = E_WE_Kopf.Firma
              and E_WE_Pos.ReferenzNr = E_WE_Kopf.ReferenzNr
              and E_WE_Pos.Source_Obj = TT_E_BelegPos.Source_Obj
            exclusive-lock
          on error undo, throw:

          assign
            E_WE_Pos.Source_Obj
              = EBT_DeliveryPos.EBT_DeliveryPos_Obj
            E_WE_Pos.Herk_BelegArt
              = (if EBT_DeliveryPos.Herk_BelegArt = 'ECO':U then
                   'EDC':U
                 else
                   'EDA':U)
            E_WE_Pos.Herk_ReferenzNr
              = ?
            E_WE_Pos.Herk_PositionsNr
              = ?
            .

          validate E_WE_Pos.

        end. /*  for each E_WE_Kopf */

        /* Adoption Code 'T' can not be distinguished here from 'U'.        */
        /* If 'U' should be used, then modify this manually.                */

        if can-do ('EB,EAB,ERL':U,TT_E_BelegPos.BelegArt) then
        do:

          for each bEBT_DeliveryPos /* code checked by jf 26.06.2007 */
            where bEBT_DeliveryPos.Source_Obj        = bE_BelegPos.E_BelegPos_Obj
              and bEBT_DeliveryPos.EBT_Delivery_Obj <> EBT_Delivery.EBT_Delivery_Obj
              and bEBT_DeliveryPos.offen             = yes
            no-lock
            on error undo, throw:

            dOldDeliveryQty = dOldDeliveryQty + bEBT_DeliveryPos.Liefermenge.

          end. /*  for each bEBT_DeliveryPos */

          assign
            EBT_DeliveryPos.Lieferkennzeichen
              = (if    EBT_DeliveryPos.LieferMenge = TT_E_BelegPos.BestellMenge
                   and dOldDeliveryQty             = 0 then
                   'K':U
                 else if EBT_DeliveryPos.LieferMenge + dOldDeliveryQty > TT_E_BelegPos.BestellMenge - TT_E_BelegPos.gelieferte_Menge then
                   'M':U
                 else if EBT_DeliveryPos.Liefermenge + dOldDeliveryQty = TT_E_BelegPos.BestellMenge - TT_E_BelegPos.gelieferte_Menge then
                   'R':U
                 else
                   'T':U)
            dOldDeliveryQty
              = 0
            .

        end. /* if can-do ('EB,EAB,ERL':U,TT_E_BelegPos.BelegArt) */
        else

          EBT_DeliveryPos.Lieferkennzeichen = 'A':U.

        validate EBT_DeliveryPos.

        &IF lookup ("M_PACK":U,"{&PA-OPTIONEN}":U) > 0 &THEN

          /* Adopt Packaging of predecessor document */

          if can-do('EB,EAB,ERL,ECO':U,TT_E_BelegPos.BelegArt) then
          do:

            assign
              cPMKeyAdopt3 = mawi.base.cls.MMCPackagingSvc:prpoInstance:cCheckPMKeyAdopt3
                               (TT_E_BelegPos.BelegArt,
                                (if TT_E_BelegPos.BelegArt = 'ERL':U then
                                   {&pa_MM_PackagingDelivery}         /* Function Code 4 */
                                 else
                                   {&pa_MM_PackagingInstruction}),    /* Function Code 1 */
                                gcSource_Obj,
                                TT_E_BelegPos.Source_Obj)
              cPMKeyAdopt3 = (if cPMKeyAdopt3 > '':U then

                                cPMKeyAdopt3

                              /* If packaging was created during the adoption using the  */
                              /* button BtnPackage.                                      */

                              else

                                mawi.base.cls.MMCPackagingSvc:prpoInstance:cCheckPMKeyAdopt3
                                 (TT_E_BelegPos.BelegArt,
                                  {&pa_MM_PackagingInformational},       /* Function Code 9 */
                                  gcSource_Obj,
                                  TT_E_BelegPos.Source_Obj))
              .

            run mawi/proc/m_vpmi07.p (pACConnectionSvc:prpcCompany,
                                      {&pa_ML_PackagingArea_Purchasing},
                                      {&pa_MM_PackagingInformational},   /* Function Code 9 */
                                      TT_E_BelegPos.BelegArt,
                                      gcSource_Obj,
                                      TT_E_BelegPos.BelegArt,
                                      cPMKeyAdopt3,
                                      'E':U,
                                      {&pa_MM_PackagingInformational},   /* Function Code 9 */
                                      'EDA':U,
                                      EBT_Delivery.EBT_Delivery_Obj,
                                      'EDA':U,
                                      EBT_DeliveryPos.EBT_DeliveryPos_Obj).

          end. /* if can-do('EB,EAB,ERL,ECO':U,TT_E_BelegPos.BelegArt) then */

        &ENDIF /* M_PACK */

      end. /* not can-find(bEBT_DeliveryPos */

      /* Rebuild coverage of adopted line */

      if gcSourceDocType = 'EAB':U then
      do:

        /* Several MRP records may be replaced by the adoption to           */
        /* the despatch advice. Delete them all.                            */

        oMaterialPosting = mawi.base.cls.MMCMaterialPostingSvo:create().

        for each bE_BelegPosTermin
          where bE_BelegPosTermin.Firma       = bE_BelegPos.Firma
            and bE_BelegPosTermin.BelegArt    = bE_BelegPos.BelegArt
            and bE_BelegPosTermin.ReferenzNr  = bE_BelegPos.ReferenzNr
            and bE_BelegPosTermin.PositionsNr = bE_BelegPos.PositionsNr
          no-lock
          on error undo, throw:

          oMaterialPosting:deleteMRPAccount('EAB':U,
                                            bE_BelegPosTermin.E_BelegPosTermin_Obj).

        end. /* for each bE_BelegPosTermin */

        oMaterialPosting:saveMaterialPosting().

        eink.base.cls.EBCPODeliveryPlanSvc:prpoInstance:RebuildCoverage
          (      bE_BelegPos.E_BelegPos_Obj,
           table ttMM_MRPLinkAPI by-reference).

      end. /* if gcSourceDocType = 'EAB':U */
      else if can-do('EB,ERL':U,gcSourceDocType) then
        eink.base.cls.EBCPurchaseDocSvc:prpoInstance:RebuildCoverage
          (      bE_BelegPos.E_BelegPos_Obj,
           table ttMM_MRPLinkAPI by-reference).

      else if gcSourceDocType = 'ECO':U then
      do:

        /* Several MRP records may be replaced by the adoption to           */
        /* the despatch advice. Delete them all.                            */

        oMaterialPosting = mawi.base.cls.MMCMaterialPostingSvo:create().

        for each bEBT_PurchRelease
          where bEBT_PurchRelease.EBT_CallOrder_Obj = gcSource_Obj
          no-lock,
          each EBT_RelSchedules
            where EBT_RelSchedules.EBT_PurchRelease_Obj = bEBT_PurchRelease.EBT_PurchRelease_Obj
          no-lock
          on error undo, throw:

          oMaterialPosting:deleteMRPAccount('ECO':U,
                                            EBT_RelSchedules.EBT_RelSchedules_Obj).

        end. /* for each bEBT_PurchRelease */

        oMaterialPosting:saveMaterialPosting().

        /* Rebuild coverage of the call order */

        eink.base.cls.EBCCallOrderSvc:prpoInstance:RebuildCoverage(gcSource_Obj).

      end. /* else if gcSourceDocType = 'ECO':U */

    end. /* for each TT_E_BelegPos */

  end. /* if return-value <> 'ADM-ERROR':U */

  catch goProgressError as Progress.Lang.Error:

    (new adm.method.cls.DMCErrorMessageErr(goProgressError)):displayProgressErrorsOnly().

    if gcEntryField = '':U then

      gcEntryField = 'Menge':U.

    glFehler = yes.

  end catch.

end. /* Main */

end procedure. /* CreateShippingDocLines */

/* _UIB-CODE-BLOCK-END */
&ANALYZE-RESUME

&ANALYZE-SUSPEND _UIB-CODE-BLOCK _PROCEDURE Erzeuge-ABPositionen B-table-Win 
PROCEDURE Erzeuge-ABPositionen :
/*------------------------------------------------------------------------------
  Purpose:     Generiere die Auftragsbest�tigungspositionen
  Parameters:  <none>
  Notes:
------------------------------------------------------------------------------*/

define variable lAutoArchived         as logical       no-undo init no.
define variable tLieferterminMoeglich as date          no-undo.

define buffer E_BelegKopf  for E_BelegKopf.
define buffer E_BelegPos   for E_BelegPos.
define buffer E_AB_Pos     for E_AB_Pos.

define buffer bE_AB_Pos for E_AB_Pos.

define buffer bTT_E_BelegPos for temp-table TT_E_BelegPos.

Main: do transaction
  on error undo, throw:

  /* sicherheitshalber auf aktuellem Satz ein assign-record, damit TT-Satz    */
  /* zugewiesen, sonst gibt es Probleme bei �nderung von aktuellem Satz und   */
  /* und Verwendung von OK-Button �ber Return-Taste                           */

  run dispatch ('assign-record':U).

  if return-value <> 'ADM-ERROR':U then
  do:

    if    valid-handle ({focus})
      and gdQtySuggested
            <> decimal({getwidgetattr TT_E_BelegPos.Menge screen-value string "in browse {&BROWSE-NAME}"}) then

      apply 'leave':U to TT_E_BelegPos.Menge in browse {&BROWSE-NAME}.

    apply 'row-leave':U to {&browse-name} in frame {&frame-name}.

    if glFehler then

      adm.method.cls.DMCMessageSvc:prpoInstance:showError('s_bel00002':U).

    find E_BelegKopf
      where E_BelegKopf.E_BelegKopf_Obj = gcSource_Obj
      exclusive-lock no-wait no-error.

    if not available E_BelegKopf then
    do:

      find E_BelegKopf
        where E_BelegKopf.E_BelegKopf_Obj = gcSource_Obj
        no-lock.

      adm.method.cls.DMCMessageSvc:prpoInstance:showError
        ('m_bel00007':U,
         string(E_BelegKopf.BelegNummer)).

    end.

    if not can-find(first bE_AB_Pos
             where bE_AB_Pos.Firma      = {firma/ebelkop.fir pa-Firma}
               and bE_AB_Pos.ReferenzNr = E_AB_Kopf.ReferenzNr) then
    do:

      &IF lookup ("S_ProfCenter":U,"{&PA-OPTIONEN}":U) > 0 &THEN

        /* If the profitcenter is required and the source document does not   */
        /* have one, then maintain the present profit center whithout asking. */
        /* If a source profit center is given, then decide which one will be  */
        /* used.                                                              */

        if    stamm.base.cls.SBCProfitCenterSvc:prpoInstance:lIsProfitCenterRequiredOrOptional('EBB':U)
          and E_AB_Kopf.SBM_ProfitCenter_ID   <> E_BelegKopf.SBM_ProfitCenter_ID
          and E_BelegKopf.SBM_ProfitCenter_ID  > '':U
          and not adm.method.cls.DMCMessageSvc:prpoInstance:lShowMessage
                    ('ebpro00001':U,
                      E_AB_Kopf.SBM_ProfitCenter_ID,
                      E_BelegKopf.SBM_ProfitCenter_ID) then
        do:

          stamm.base.cls.SBCProfitCenterSvc:prpoInstance:ChooseProfitCenterDocAdopt
            (             E_BelegKopf.SBM_ProfitCenter_Obj,
                          E_BelegKopf.SBM_ProfitCenter_ID,
                          '':U,
                          'EBB':U,
             input-output E_AB_Kopf.SBM_ProfitCenter_Obj,
             input-output E_AB_Kopf.SBM_ProfitCenter_ID).

          validate E_AB_Kopf.

          run new-state ('ProfitCenterAdopted,record-source':U).

        end. /* if    stamm.base.cls.SBCProfitCenterSvc:prpoInstance:lIsProfitCenterRequiredOrOptional('EBB */

      &ENDIF /* &IF lookup ("S_ProfCenter":U,"{&PA-OPTIONEN}":U) > 0 &THEN */

      /* initialisiere die Adresse f�r Diverse */

      {eink/incl/e_kbel04.if
        &UrTabelle   = "E_BelegKopf"
        &ZielTabelle = "E_AB_Kopf"
      }

    end.

    /* l�sche die AB-Position */

    for each bTT_E_BelegPos
      where bTT_E_BelegPos.AB_PositionsNr  = ?
        or  bTT_E_BelegPos.AB_PositionsNr <> bTT_E_BelegPos.AB_PositionsNr_vor
      break by bTT_E_BelegPos.PositionsNr
      on error undo, throw:

      if first-of(bTT_E_BelegPos.PositionsNr) then

        find E_BelegPos
          where rowid (E_BelegPos) = to-rowid (bTT_E_BelegPos.RowidString)
          no-lock.

      /* delete E_AB_Pos */

      find E_AB_Pos
        where E_AB_Pos.Firma       = E_AB_Kopf.Firma
          and E_AB_Pos.ReferenzNr  = E_AB_Kopf.ReferenzNr
          and E_AB_Pos.PositionsNr = bTT_E_BelegPos.AB_PositionsNr_vor
        exclusive-lock no-error.

      /* pr�fe sicherheitshalber �ber Belegart/ReferenzNr/PositionsNr, ob Position */
      /* mit Rowid noch die richtige ist                                           */

      if    available E_AB_Pos
        and E_AB_Pos.Herk_BelegArt    = bTT_E_BelegPos.Belegart
        and E_AB_Pos.Herk_ReferenzNr  = bTT_E_BelegPos.ReferenzNr
        and E_AB_Pos.Herk_PositionsNr = bTT_E_BelegPos.PositionsNr then

        delete E_AB_Pos.

    end. /* for each bTT_E_BelegPos */

    /* Trage AB_PositionsNr ein */

    for each bTT_E_BelegPos
      where bTT_E_BelegPos.AB_PositionsNr <> ?
      break by bTT_E_BelegPos.PositionsNr
            by bTT_E_BelegPos.Liefertermin descending
      on error undo, throw:

      find E_BelegPos
        where rowid (E_BelegPos) = to-rowid (bTT_E_BelegPos.RowidString)
        no-lock.

      /*-------------------------------------------------------------------*/
      /* Wochentage fix und Feiertage im eigenen Kalender ausgrenzen       */
      /*-------------------------------------------------------------------*/

      tLieferterminMoeglich = bTT_E_BelegPos.Liefertermin.

      {stamm/incl/s_vzei00.if
        &ippFirma       = "E_AB_Kopf.Firma"
        &ippDatum       = "tLieferterminMoeglich"
        &ippVor         = "yes"
        &ippLagergruppe = "E_BelegKopf.Lagergruppe"
      }

      if  (    bTT_E_BelegPos.Liefertermin < tLieferterminMoeglich
           and adm.method.cls.DMCMessageSvc:prpoInstance:lShowMessage
                 ('e_ab_00025':U,
                  string(bTT_E_BelegPos.AB_PositionsNr),
                  string (E_BelegKopf.Lagergruppe),
                  string(tLieferterminMoeglich,'{&PA_DATEFORMAT}':U),
                  string(bTT_E_BelegPos.Liefertermin,'{&PA_DATEFORMAT}':U)) = yes)
        or bTT_E_BelegPos.Liefertermin <> bTT_E_BelegPos.Wunschtermin then
      do:

         if glProtocol = ? then
          do:

            {adm/incl/d__msg00.if
              &Meldung   = "'e_ab_00036':U"
              &Rueckgabe = "glProtocol"
              &FehlerFkt = "gcEntryField = 'Liefertermin':U.
                            run pa_UISvcApplyEventToWidgetByHandle
                                  ('entry':U,
                                   TT_E_BelegPos.Liefertermin:handle in browse {&BROWSE-NAME})."
            }

          end. /* if glProtocol = ? */

        if    glProtocol
          and eink.base.cls.EBCOrderConfirmationSvc:prpoInstance:lCreateProtocolRecord
                (bTT_E_BelegPos.E_BelegPos_Obj,
                 tLieferterminMoeglich,
                 bTT_E_BelegPos.Wunschtermin,
                 bTT_E_BelegPos.Bestellmenge,
                 bTT_E_BelegPos.Menge) = no then
        do:

          glFehler = yes.

          adm.method.cls.DMCMessageSvc:prpoInstance:showError('e_ab_00037':U).

        end. /* if eink.base.cls.EBCOrderConfirmationSvc:prpoInstance:lCreateProtocolRecord.. */

        assign
          gcEntryField               = 'Liefertermin':U
          bTT_E_BelegPos.Liefertermin = tLieferterminMoeglich
          .

      end. /* bTT_E_BelegPos.Liefertermin < tLieferterminMoeglich... */

      /* Soll die Menge der Belegposition ver�ndert werden ? */

      if eink.base.cls.EBCPurchaseOrderDocSvc:prpoInstance:lIsPurchaseOrderQtyDifferentFromConfirmationQty
           (E_BelegPos.Menge,
            bTT_E_BelegPos.Bestellmenge) then
      do:

        find E_BelegPos
          where rowid(E_BelegPos) = to-rowid(bTT_E_BelegPos.RowidString)
          exclusive-lock no-wait no-error.

        if   locked E_BelegPos
          or not available E_BelegPos then

          adm.method.cls.DMCMessageSvc:prpoInstance:showError
            ('m_bel00007':U,
             string(E_BelegKopf.Belegnummer)).

        else
        do:

          if    adm.method.cls.DMCMessageSvc:prpoInstance:lShowMessage
                  ('e_ab_00038':U) = yes
            and eink.base.cls.EBCOrderConfirmationSvc:prpoInstance:lCreateProtocolRecord
                  (E_BelegPos.E_BelegPos_Obj,
                   bTT_E_BelegPos.Liefertermin,
                   ?,
                   bTT_E_BelegPos.Bestellmenge,
                   E_BelegPos.Menge) = no then
            adm.method.cls.DMCMessageSvc:prpoInstance:showError
              ('e_ab_00037':U).

          if E_BelegKopf.VerteilerGruppe > '':U then

            basis.buro.cls.BBCWorkflowSvc:prpoInstance:createWorkflow
              (E_BelegKopf.E_BelegKopf_Obj,
               E_BelegPos.E_BelegPos_Obj,
               E_BelegKopf.Firma,
               'E_EB':U,
               34,
               E_BelegKopf.VerteilerGruppe,
               ?,
               ?,
               E_BelegKopf.AuftragsArt,
               pACConnectionSvc:cTranslatedString('OrderConfirmation':U,'1':U)
               + ' ':U + quoter(E_BelegPos.Menge)
               + ' -> ':U + quoter(bTT_E_BelegPos.Bestellmenge)
               + ' (':U + 'Position':T30 + ' ':U + quoter(E_BelegPos.PositionsNr) + ')':U,
               '':U).

          /* validate zwingend erforderlich ? */

          E_BelegPos.Menge = bTT_E_BelegPos.Bestellmenge.

          if    E_BelegPos.gelieferte_Menge + E_BelegPos.Fehlmenge >= dBestaetigteMenge(bTT_E_BelegPos.RowidString)
            and bTT_E_BelegPos.TransitQty                           = 0 then

            assign
              E_BelegPos.offen = no
              lAutoArchived    = yes
              .

          validate E_BelegPos.

        end. /* else do: */

      end. /* if E_BelegPos.Menge <> bTT_E_BelegPos.Bestellmenge */

      find E_BelegPos
        where rowid (E_BelegPos) = to-rowid (bTT_E_BelegPos.RowidString)
        no-lock.

      if    E_BelegPos.offen = no
        and lAutoArchived    = no then
      do:

        find current E_BelegKopf
          no-lock.

        adm.method.cls.DMCMessageSvc:prpoInstance:showError
          ('e_bel00003':U,
           string(E_BelegPos.PositionsNr)).

      end.

      if   E_BelegPos.BelegArt    <> 'EAB':U
        or E_BelegPos.WertPosition = yes then
      do:

        /* L�sche die best�tigten Positionen zu dieser Bestellposition, bei erster */
        /* best�tigter Position zur Bestellposition.                               */

        if first-of(bTT_E_BelegPos.PositionsNr) then
        do:

          /* memorise links to rebuild them */

          if     can-do('EB,ERL':U,gcSourceDocType)
             and  E_BelegPos.WertPosition <> yes then

            mawi.base.cls.MMCMRPLinkSvc:prpoInstance:GetMRPLink
              (       E_BelegPos.E_BelegPos_Obj,
               output table ttMM_MRPLinkAPI by-reference).

          /* delete confirmed lines (referenced to purchase order)            */

          for each E_AB_Pos
            where E_AB_Pos.Firma            = E_BelegPos.Firma
              and E_AB_Pos.Herk_BelegArt    = E_BelegPos.BelegArt
              and E_AB_Pos.Herk_ReferenzNr  = E_BelegPos.ReferenzNr
              and E_AB_Pos.Herk_PositionsNr = E_BelegPos.PositionsNr
              and E_AB_Pos.Liefertermin     > 01/01/1900
              and E_AB_Pos.ReferenzNr       = E_AB_Kopf.ReferenzNr
            exclusive-lock
            on error undo, throw:

            delete E_AB_Pos.

          end. /* for each E_AB_Pos */

        end. /* if first-of(bTT_E_BelegPos.PositionsNr) */

        /* pr�fe, ob die Positionsnummer noch nicht vergeben wurde. */

        if can-find(bE_AB_Pos
             where bE_AB_Pos.Firma       = {firma/ebelkop.fir pa-firma}
               and bE_AB_Pos.ReferenzNr  = E_AB_Kopf.ReferenzNr
               and bE_AB_Pos.PositionsNr = bTT_E_BelegPos.AB_PositionsNr) then
        do:

          run pa_UISvcBrowseSelectRow(browse {&browse-name}:handle, 1).

          gcEntryField = 'AB_PositionsNr':U.

          adm.method.cls.DMCMessageSvc:prpoInstance:showError
            (TT_E_BelegPos.AB_PositionsNr:handle in browse {&BROWSE-NAME},
             'e_ab_00006':U,
             string(bTT_E_BelegPos.AB_PositionsNr)).

        end. /* if can-find(bE_AB_Pos */

        else
        do:

          create E_AB_Pos.

          assign
            E_AB_Pos.Firma       = E_AB_Kopf.Firma
            E_AB_Pos.ReferenzNr  = E_AB_Kopf.ReferenzNr
            E_AB_Pos.PositionsNr = bTT_E_BelegPos.AB_PositionsNr
            .

          validate E_AB_Pos.

          assign
            E_AB_Pos.Menge            = bTT_E_BelegPos.Menge
            E_AB_Pos.Liefertermin     = bTT_E_BelegPos.Liefertermin
            E_AB_Pos.Herk_BelegArt    = bTT_E_BelegPos.BelegArt
            E_AB_Pos.Herk_ReferenzNr  = bTT_E_BelegPos.ReferenzNr
            E_AB_Pos.Herk_PositionsNr = bTT_E_BelegPos.PositionsNr
            .
                    
        end. /* else do: */

      end. /* if E_BelegPos.BelegArt <> 'EAB':U */

      /* Create workflow for event 35 in the origin purchase order if delivery*/
      /* date is different from requested date                                */

      if bTT_E_BelegPos.Liefertermin <> bTT_E_BelegPos.Wunschtermin then
        eink.base.cls.EBCPurchaseOrderDocSvc:prpoInstance:CreateOrCancelWorkflowEvent35
          (buffer E_BelegKopf,
           buffer E_BelegPos,
           bTT_E_BelegPos.Liefertermin,
           '':U).

      /* Rebuild coverage of adopted line (once for every purchase order line)*/

      if    can-do('EB,ERL':U,gcSourceDocType)
        and last-of(bTT_E_BelegPos.PositionsNr) then
        eink.base.cls.EBCPurchaseDocSvc:prpoInstance:RebuildCoverage
          (      E_BelegPos.E_BelegPos_Obj,
           table ttMM_MRPLinkAPI by-reference).
      
      /* --> MO#ABT-IVC-0049 thongdi_p 16.07.2026 Erfassung und Auswahl Teile-LieferantenNr Auftragsbest�tigung */ 
      basis.base.cls.BMCAddDataSvc:setValue
        ( /* pcOwning_Obj */          bTT_E_BelegPos.E_BelegPos_Obj,
          /* pcDRC_VirtualField_ID */ 'xVF_LieferTeileNr':U,
          /* pcFieldValue */          bTT_E_BelegPos.BestellNr ).
      /* <-- MO#ABT-IVC-0049 thongdi_p 16.07.2026 Erfassung und Auswahl Teile-LieferantenNr Auftragsbest�tigung */
      
    end. /* for each bTT_E_BelegPos */

  end. /* if return-value <> 'ADM-ERROR':U */

end. /* Main */

/* when the question 'e_-ab_-00025' has been answered with "CANCEL" then the  */
/* user have to change the delivery date.                                     */

catch goProgressError as Progress.Lang.Error:

  (new adm.method.cls.DMCErrorMessageErr(goProgressError)):displayProgressErrorsOnly().

  if gcEntryField = '':U then

    gcEntryField = 'Liefertermin':U.

  glFehler = yes.

end catch.

end procedure.

/* _UIB-CODE-BLOCK-END */
&ANALYZE-RESUME

&ANALYZE-SUSPEND _UIB-CODE-BLOCK _PROCEDURE getQueryAttribute B-table-Win  adm/support/proc/ds_qat00.p
procedure getQueryAttribute :
/* Description ---------------------------------------------------------------*/
/*                                                                            */
/* return query attribute as requested by parameter                           */
/*                                                                            */
/* Notes ---------------------------------------------------------------------*/
/*                                                                            */
/* This procedure is generated by the app builder.                            */
/*                                                                            */
/* Parameters ----------------------------------------------------------------*/
/*                                                                            */
/* pcAttribute          name of requested attribute                           */
/*                                                                            */
/*----------------------------------------------------------------------------*/

define input  parameter pcAttribute as character no-undo.

/* Variables -----------------------------------------------------------------*/
/*----------------------------------------------------------------------------*/

/* Buffers -------------------------------------------------------------------*/

/*----------------------------------------------------------------------------*/
/* Processing                                                                 */
/*----------------------------------------------------------------------------*/

case pcAttribute:

  otherwise
    undo, throw new adm.method.cls.DMCNotExistingErr
      ('Get browse query attribute':U,'Query attribute':U,pcAttribute).

end case.

end procedure. /* getQueryAttribute */

/* _UIB-CODE-BLOCK-END */
&ANALYZE-RESUME

&ANALYZE-SUSPEND _UIB-CODE-BLOCK _PROCEDURE init-TT B-table-Win 
PROCEDURE init-TT :
/*------------------------------------------------------------------------------
  Purpose:     Erzeuge die Temp-Table (Positionen) zum aktuellen Beleg
  Parameters:  <none>
  Notes:
------------------------------------------------------------------------------*/

  empty temp-table TT_E_BelegPos.

  gcDocNoFormat = TT_E_BelegPos.Belegnummer:format in browse {&browse-name}.

  if gcTargetDocType = 'EBB':U then
  do:

    eink.base.cls.EBCPurchaseDocSvc:prpoInstance:createTTAdoptLinesToEBB(       gcSource_Obj,
                                                                   rowid(E_AB_Kopf),
                                                            output table TT_E_BelegPos by-reference).

    if    available E_BelegKopf
      and E_BelegKopf.Belegart = 'EAB':U then
    do:

      find last TT_E_BelegPos
        where TT_E_BelegPos.AB_PositionsNr <> ?
        no-lock no-error.

      gdLastABPos = (if available TT_E_BelegPos then
                       TT_E_BelegPos.AB_PositionsNr
                     else
                       ?).

    end. /* if    available E_BelegKopf */

  end. /* if gcTargetDocType = 'EBB':U */

  &IF lookup ("EB_DESADV":U,"{&PA-OPTIONEN}":U) > 0 &THEN

    else if gcTargetDocType = 'EDA':U then
    do:

      eink.base.cls.EBCPurchaseDocSvc:prpoInstance:createTTAdoptLinesToEDA(       gcSource_Obj,
                                                                     rowid(EBT_Delivery),
                                                                     gcSourceDocType,
                                                              output table TT_E_BelegPos by-reference).

      &IF lookup ("M_PACK":U,"{&PA-OPTIONEN}":U) > 0 &THEN

        giTargetFunction = mawi.base.cls.MMCPackagingSvc:prpoInstance:iFunctionCode
                             (gcTargetDocType,
                              gcSourceDocType).

      &ENDIF

    end. /* else if gcTargetDocType = 'EDA':U then */

  &ENDIF /* &IF lookup ("EB_DESADV":U,"{&PA-OPTIONEN}":U) > 0 &THEN */

  run dispatch in this-procedure ('open-query':U).

end procedure.

/* _UIB-CODE-BLOCK-END */
&ANALYZE-RESUME

&ANALYZE-SUSPEND _UIB-CODE-BLOCK _PROCEDURE LiefereRowid B-table-Win 
PROCEDURE LiefereRowid :
/*------------------------------------------------------------------------------
  Purpose:     Gebe den RowIdString des aktuellen Datensatzes zur�ck
  Parameters:  <none>
  Notes:
------------------------------------------------------------------------------*/

  define output parameter pcRowid as char no-undo.

  if available TT_E_BelegPos then
    pcRowid = TT_E_BelegPos.RowidString.

end procedure.

/* _UIB-CODE-BLOCK-END */
&ANALYZE-RESUME

&ANALYZE-SUSPEND _UIB-CODE-BLOCK _PROCEDURE local-apply-entry B-table-Win 
PROCEDURE local-apply-entry :
/* Description ---------------------------------------------------------------*/
/*                                                                            */
/* Super Override                                                             */
/*                                                                            */
/* Notes ---------------------------------------------------------------------*/
/*                                                                            */
/*                                                                            */
/*                                                                            */
/* Parameters ----------------------------------------------------------------*/
/*                                                                            */
/* <none>                                                                     */
/*                                                                            */
/* Examples ------------------------------------------------------------------*/
/*                                                                            */
/*                                                                            */
/*                                                                            */
/*----------------------------------------------------------------------------*/

/* Variables -----------------------------------------------------------------*/
/*----------------------------------------------------------------------------*/

/* Buffers -------------------------------------------------------------------*/

/*----------------------------------------------------------------------------*/
/* Processing                                                                 */
/*----------------------------------------------------------------------------*/

/* Code placed here will execute PRIOR to standard behavior ------------------*/

/* Execute standard behavior -------------------------------------------------*/

run dispatch('apply-entry':U).

/* Code placed here will execute AFTER standard behavior ---------------------*/

if return-value <> 'ADM-ERROR':U then
do:

  if    gcEntryField        > '':U
    and adm-updating-record = no
    and glCancelRecord      = no then
  do:

    case gcEntryField:

      when 'Menge':U then
        run pa_UISvcApplyEventToWidgetByHandle
              ('entry':U,
               TT_E_BelegPos.Menge:handle in browse {&Browse-Name}).

      when 'Liefertermin':U then
        run pa_UISvcApplyEventToWidgetByHandle
              ('entry':U,
               TT_E_BelegPos.Liefertermin:handle in browse {&Browse-Name}).

      when 'AB_PositionsNr':U then
        run pa_UISvcApplyEventToWidgetByHandle
              ('entry':U,
               TT_E_BelegPos.AB_PositionsNr:handle in browse {&Browse-Name}).
      
      /* --> MO#ABT-IVC-0049 thongdi_p 15.07.2026 Erfassung und Auswahl Teile-LieferantenNr Auftragsbest�tigung */
      when 'BestellNr':U then
        run pa_UISvcApplyEventToWidgetByHandle
              ('entry':U,
               TT_E_BelegPos.BestellNr:handle in browse {&Browse-Name}).
      /* <-- MO#ABT-IVC-0049 thongdi_p 15.07.2026 Erfassung und Auswahl Teile-LieferantenNr Auftragsbest�tigung */      
      
    end case.

    gcEntryField = '':U.

  end. /* if    return-value       <> 'ADM-ERROR':U */

  /* assign necessary in order to prevent initialization with blank, if the */
  /* two columns are ordered in front of the line number.                   */

  if    available TT_E_BelegPos
    and glCancelRecord = no then

    assign
      TT_E_BelegPos.Liefertermin = {getwidgetattr TT_E_BelegPos.Liefertermin input-value date "in browse {&BROWSE-NAME}"}
      TT_E_BelegPos.Menge        = {getwidgetattr TT_E_BelegPos.Menge input-value decimal "in browse {&BROWSE-NAME}"}
      .

end. /* if return-value <> 'ADM-ERROR':U */

end procedure. /* local-apply-entry */

/* _UIB-CODE-BLOCK-END */
&ANALYZE-RESUME

&ANALYZE-SUSPEND _UIB-CODE-BLOCK _PROCEDURE local-assign-statement B-table-Win 
PROCEDURE local-assign-statement :
/* Description ---------------------------------------------------------------*/
/*                                                                            */
/* Super Override                                                             */
/*                                                                            */
/* Notes ---------------------------------------------------------------------*/
/*                                                                            */
/*                                                                            */
/*                                                                            */
/* Parameters ----------------------------------------------------------------*/
/*                                                                            */
/* <none>                                                                     */
/*                                                                            */
/* Examples ------------------------------------------------------------------*/
/*                                                                            */
/*                                                                            */
/*                                                                            */
/*----------------------------------------------------------------------------*/

/* Variables -----------------------------------------------------------------*/
/*----------------------------------------------------------------------------*/

/* Buffers -------------------------------------------------------------------*/

/*----------------------------------------------------------------------------*/
/* Processing                                                                 */
/*----------------------------------------------------------------------------*/

/* Code placed here will execute PRIOR to standard behavior ------------------*/

/* If storing without having left the line, checks are done here. */

if glAbfrage = no then
do:

  /* If a wrong delivery date was entered then stop. */

  /* Check whether the present record may be adopted. */

  apply 'row-leave':U to {&browse-name} in frame {&frame-name}.

  if   glWrongInput
    or glFehler then
  do:

    case gcEntryField:

      when 'Menge':U then
        run pa_UISvcApplyEventToWidgetByHandle
              ('entry':U,
               TT_E_BelegPos.Menge:handle in browse {&BROWSE-NAME}).

      when 'Liefertermin':U then
        run pa_UISvcApplyEventToWidgetByHandle
              ('entry':U,
               TT_E_BelegPos.Liefertermin:handle in browse {&BROWSE-NAME}).

      when 'AB_PositionsNr':U then
        run pa_UISvcApplyEventToWidgetByHandle
              ('entry':U,
               TT_E_BelegPos.AB_PositionsNr:handle in browse {&BROWSE-NAME}).

      otherwise

        run pa_UISvcApplyEventToWidgetByHandle
              ('entry':U,
               TT_E_BelegPos.Menge:handle in browse {&BROWSE-NAME}).

    end case. /* case gcEntryField: */

    return 'ADM-ERROR':U.

  end. /* if   glWrongInput */

end. /* if glAbfrage = yes then */

/* Execute standard behavior -------------------------------------------------*/

run dispatch('assign-statement':U).

/* Code placed here will execute AFTER standard behavior ---------------------*/

end procedure. /* local-assign-statement */

/* _UIB-CODE-BLOCK-END */
&ANALYZE-RESUME

&ANALYZE-SUSPEND _UIB-CODE-BLOCK _PROCEDURE local-cancel-record B-table-Win 
PROCEDURE local-cancel-record :
/* Description ---------------------------------------------------------------*/
/*                                                                            */
/* Super Override                                                             */
/*                                                                            */
/* Notes ---------------------------------------------------------------------*/
/*                                                                            */
/*                                                                            */
/*                                                                            */
/* Parameters ----------------------------------------------------------------*/
/*                                                                            */
/* <none>                                                                     */
/*                                                                            */
/* Examples ------------------------------------------------------------------*/
/*                                                                            */
/*                                                                            */
/*                                                                            */
/*----------------------------------------------------------------------------*/

/* Variables -----------------------------------------------------------------*/
/*----------------------------------------------------------------------------*/

/* Buffers -------------------------------------------------------------------*/

&IF   lookup("EB_DESADV":U,"{&PA-OPTIONEN}":U) > 0
  and lookup ("M_PACK":U,"{&PA-OPTIONEN}":U)   > 0 &THEN
  define buffer bTT_E_BelegPos   for temp-table TT_E_BelegPos.
&ENDIF
/*----------------------------------------------------------------------------*/
/* Processing                                                                 */
/*----------------------------------------------------------------------------*/

/* Code placed here will execute PRIOR to standard behavior ------------------*/

assign
  glCancelRecord   = yes
  glCancelAdoption = yes
  glWrongInput     = yes
  .

/* Execute standard behavior -------------------------------------------------*/

run dispatch('cancel-record':U).

/* Code placed here will execute AFTER standard behavior ---------------------*/

&IF   lookup("EB_DESADV":U,"{&PA-OPTIONEN}":U) > 0
  and lookup ("M_PACK":U,"{&PA-OPTIONEN}":U)   > 0 &THEN

  if return-value <> 'ADM-ERROR':U then
  do:

    /* Delete Packaging, if the adoption was canceled */

    if gcTargetDocType = 'EDA':U then

      for each bTT_E_BelegPos
        where bTT_E_BelegPos.AB_PositionsNr <> ?
        on error undo, throw:

        if mawi.base.cls.MMCPackagingSvc:prpoInstance:cCheckPMKeyAdopt3
            (bTT_E_BelegPos.BelegArt,
             {&pa_MM_PackagingInformational},    /* Function Code 9 */
             gcSource_Obj,
             bTT_E_BelegPos.Source_Obj) > '':U then

          run mawi/proc/m_vpmi04.p (pACConnectionSvc:prpcCompany,
                                    {&pa_ML_PackagingArea_Purchasing},
                                    {&pa_MM_PackagingInformational},  /* Function Code 9 */
                                    '':U,
                                    '':U,
                                    bTT_E_BelegPos.BelegArt,
                                    gcSource_Obj,
                                    bTT_E_BelegPos.BelegArt,
                                    bTT_E_BelegPos.Source_Obj,
                                    yes).

      end. /* for each bTT_E_BelegPos */

  end. /* if return-value <> 'ADM-ERROR':U then */

&ENDIF /* &IF   lookup("EB_DESADV":U,"{&PA-OPTIONEN}":U) > 0 */

end procedure. /* local-cancel-record */

/* _UIB-CODE-BLOCK-END */
&ANALYZE-RESUME

&ANALYZE-SUSPEND _UIB-CODE-BLOCK _PROCEDURE local-delete-record B-table-Win 
PROCEDURE local-delete-record :
/* Description ---------------------------------------------------------------*/
/*                                                                            */
/* Super Override                                                             */
/*                                                                            */
/* Notes ---------------------------------------------------------------------*/
/*                                                                            */
/*                                                                            */
/*                                                                            */
/* Parameters ----------------------------------------------------------------*/
/*                                                                            */
/* <none>                                                                     */
/*                                                                            */
/* Examples ------------------------------------------------------------------*/
/*                                                                            */
/*                                                                            */
/*                                                                            */
/*----------------------------------------------------------------------------*/

/* Variables -----------------------------------------------------------------*/
/*----------------------------------------------------------------------------*/

/* Buffers -------------------------------------------------------------------*/

/*----------------------------------------------------------------------------*/
/* Processing                                                                 */
/*----------------------------------------------------------------------------*/

/* Code placed here will execute PRIOR to standard behavior. */

/* Sperrgrund Pr�fungen Beleg */

if gcTargetDocType = 'EBB':U then

  basis.buro.cls.BBCWorkflowSvc:prpoInstance:showLockStatus
    (E_AB_Kopf.E_AB_Kopf_Obj,
     'E_BB':U).

else if gcTargetDocType = 'EDA':U then

  basis.buro.cls.BBCWorkflowSvc:prpoInstance:showLockStatus
    (EBT_DesAdv.EBT_DesAdv_Obj,
     'EB_EDA':U).

/* Dispatch standard ADM method.                             */
run dispatch in this-procedure ( 'delete-record':U ) .

/* Code placed here will execute AFTER standard behavior.    */

end procedure.

/* _UIB-CODE-BLOCK-END */
&ANALYZE-RESUME

&ANALYZE-SUSPEND _UIB-CODE-BLOCK _PROCEDURE local-destroy B-table-Win 
PROCEDURE local-destroy :
/* Description ---------------------------------------------------------------*/
/*                                                                            */
/* Super Override                                                             */
/*                                                                            */
/* Notes ---------------------------------------------------------------------*/
/*                                                                            */
/*                                                                            */
/*                                                                            */
/* Parameters ----------------------------------------------------------------*/
/*                                                                            */
/* <none>                                                                     */
/*                                                                            */
/* Examples ------------------------------------------------------------------*/
/*                                                                            */
/*                                                                            */
/*                                                                            */
/*----------------------------------------------------------------------------*/

/* Variables -----------------------------------------------------------------*/
/*----------------------------------------------------------------------------*/

/* Buffers -------------------------------------------------------------------*/

/*----------------------------------------------------------------------------*/
/* Processing                                                                 */
/*----------------------------------------------------------------------------*/

/* Code placed here will execute PRIOR to standard behavior ------------------*/

/* Do not show an error, if a not existing date was entered to the delivery   */
/* date.                                                                      */

glWrongInput = yes.

/* Execute standard behavior -------------------------------------------------*/

run dispatch('destroy':U).

/* Code placed here will execute AFTER standard behavior ---------------------*/

end procedure. /* local-destroy */

/* _UIB-CODE-BLOCK-END */
&ANALYZE-RESUME

&ANALYZE-SUSPEND _UIB-CODE-BLOCK _PROCEDURE local-disable-fields B-table-Win 
PROCEDURE local-disable-fields :
/* Description ---------------------------------------------------------------*/
/*                                                                            */
/* Super Override                                                             */
/*                                                                            */
/* Notes ---------------------------------------------------------------------*/
/*                                                                            */
/*                                                                            */
/*                                                                            */
/* Parameters ----------------------------------------------------------------*/
/*                                                                            */
/* <none>                                                                     */
/*                                                                            */
/* Examples ------------------------------------------------------------------*/
/*                                                                            */
/*                                                                            */
/*                                                                            */
/*----------------------------------------------------------------------------*/

/* Variables -----------------------------------------------------------------*/
/*----------------------------------------------------------------------------*/

/* Buffers -------------------------------------------------------------------*/

/*----------------------------------------------------------------------------*/
/* Processing                                                                 */
/*----------------------------------------------------------------------------*/

/* Code placed here will execute PRIOR to standard behavior ------------------*/

/* Execute standard behavior -------------------------------------------------*/

run dispatch('disable-fields':U).

/* Code placed here will execute AFTER standard behavior ---------------------*/

/* Assignment necessary, because when modifying the quantity and closing the  */
/* browser via F3, the modified screen-value would not be respected for the   */
/* message ebdea00010.                                                        */

if    return-value <> 'ADM-ERROR':U
  and available TT_E_BelegPos then

  {adm/incl/d__bcs00.if
     &BrowseCell  = "TT_E_BelegPos.Menge"
     &ScreenValue = "string(TT_E_BelegPos.Menge)"
     &WithFrame   = "in browse {&browse-name}"}.

end procedure. /* local-disable-fields */

/* _UIB-CODE-BLOCK-END */
&ANALYZE-RESUME

&ANALYZE-SUSPEND _UIB-CODE-BLOCK _PROCEDURE local-enable-fields B-table-Win 
PROCEDURE local-enable-fields :
/* Description ---------------------------------------------------------------*/
/*                                                                            */
/* Super Override                                                             */
/*                                                                            */
/* Notes ---------------------------------------------------------------------*/
/*                                                                            */
/*                                                                            */
/*                                                                            */
/* Parameters ----------------------------------------------------------------*/
/*                                                                            */
/* <none>                                                                     */
/*                                                                            */
/* Examples ------------------------------------------------------------------*/
/*                                                                            */
/*                                                                            */
/*                                                                            */
/*----------------------------------------------------------------------------*/

/* Variables -----------------------------------------------------------------*/
/*----------------------------------------------------------------------------*/

/* Buffers -------------------------------------------------------------------*/

/*----------------------------------------------------------------------------*/
/* Processing                                                                 */
/*----------------------------------------------------------------------------*/

/* Code placed here will execute PRIOR to standard behavior ------------------*/

/* Execute standard behavior -------------------------------------------------*/

run dispatch('enable-fields':U).

/* Code placed here will execute AFTER standard behavior ---------------------*/

if    return-value <> 'ADM-ERROR':U
  and available TT_E_BelegPos then
do:

  if gcTargetDocType = 'EDA':U then
  do:

    {fnarg
      pa_lUISvcDisableBrowseColumn
      "TT_E_BelegPos.Liefertermin:handle in browse {&browse-name}"}.

    {fnarg
      pa_lUISvcSetWidgetSensitiveState
      "Btn_Abrufe:handle in frame {&frame-name}, no"}.

    if not can-find (S_Artikel
                       where S_Artikel.Firma      = {firma/sartikel.fir pa-Firma}
                         and S_Artikel.Artikel    = TT_E_BelegPos.Artikel
                         and S_Artikel.Chargenart > '':U) then

      {fnarg
        pa_lUISvcDisableBrowseColumn
        "TT_E_BelegPos.LieferantenCharge:handle in browse {&browse-name}"}.

    &IF LOOKUP("MC":U,"{&PA-MODULE}":U) = 0 &THEN

      {setwidgetattr
         "TT_E_BelegPos.LieferantenCharge"
         "visible"
         "no"
         "in browse {&browse-name}"}.

    &ENDIF

    {fnarg
      pa_lUISvcSetWidgetHiddenState
      "Btn_Termin:handle in frame {&FRAME-NAME}, yes"}.

  end. /* if gcTargetDocType = 'EDA':U */

  else
  do:

    {fnarg
      pa_lUISvcDisableBrowseColumn
      "TT_E_BelegPos.Lagerort:handle in browse {&browse-name}"}.

    /* For order confirmations prevent that the cursor starts in field the    */
    /* 'supplier lot' if the program was started.                             */

    {fnarg
      pa_lUISvcDisableBrowseColumn
      "TT_E_BelegPos.LieferantenCharge:handle in browse {&browse-name}"}.

    {setwidgetattr
       "TT_E_BelegPos.LieferantenCharge"
       "visible"
       "no"
       "in browse {&browse-name}"}.

  end. /* else do:*/

  run pa_UISvcApplyEventToWidgetByHandle
        ('entry':U,
         TT_E_BelegPos.AB_PositionsNr:handle in browse {&browse-name}).

end. /* if return-value <> 'ADM-ERROR':U */

end procedure. /* local-enable-fields */

/* _UIB-CODE-BLOCK-END */
&ANALYZE-RESUME

&ANALYZE-SUSPEND _UIB-CODE-BLOCK _PROCEDURE local-end-update B-table-Win 
PROCEDURE local-end-update :
/* Description ---------------------------------------------------------------*/
/*                                                                            */
/* Super Override                                                             */
/*                                                                            */
/* Notes ---------------------------------------------------------------------*/
/*                                                                            */
/*                                                                            */
/*                                                                            */
/* Parameters ----------------------------------------------------------------*/
/*                                                                            */
/* <none>                                                                     */
/*                                                                            */
/* Examples ------------------------------------------------------------------*/
/*                                                                            */
/*                                                                            */
/*                                                                            */
/*----------------------------------------------------------------------------*/

/* Variables -----------------------------------------------------------------*/
/*----------------------------------------------------------------------------*/

/* Buffers -------------------------------------------------------------------*/

/*----------------------------------------------------------------------------*/
/* Processing                                                                 */
/*----------------------------------------------------------------------------*/

/* Code placed here will execute PRIOR to standard behavior ------------------*/

/* Execute standard behavior -------------------------------------------------*/

run dispatch('end-update':U).

/* Code placed here will execute AFTER standard behavior ---------------------*/

/* Without checking glUpdateComplete -> Error 3135                            */

if return-value <> 'ADM-ERROR':U 
  and glUpdateComplete then

  /* Now we can close the adoption program. */

  run dispatch('exit':U).


end procedure. /* local-end-update */

/* _UIB-CODE-BLOCK-END */
&ANALYZE-RESUME

&ANALYZE-SUSPEND _UIB-CODE-BLOCK _PROCEDURE local-help-begin B-table-Win 
PROCEDURE local-help-begin :
/* Description ---------------------------------------------------------------*/
/*                                                                            */
/* Super Override                                                             */
/*                                                                            */
/* Notes ---------------------------------------------------------------------*/
/*                                                                            */
/*                                                                            */
/*                                                                            */
/* Parameters ----------------------------------------------------------------*/
/*                                                                            */
/* <none>                                                                     */
/*                                                                            */
/* Examples ------------------------------------------------------------------*/
/*                                                                            */
/*                                                                            */
/*                                                                            */
/*----------------------------------------------------------------------------*/

/* Variables -----------------------------------------------------------------*/
/*----------------------------------------------------------------------------*/

/* Buffers -------------------------------------------------------------------*/

/*----------------------------------------------------------------------------*/
/* Processing                                                                 */
/*----------------------------------------------------------------------------*/

/* Code placed here will execute PRIOR to standard behavior ------------------*/

pa-hlp-string = adm.method.cls.DMCParameterStringSvc:cWriteValue(pa-hlp-string, 'Artikel':U, trim(TT_E_BelegPos.Artikel)).

/* Strg-A for field Lagerort needs 'Storagearea' as key-name  */
/* but Strg-Y must get 'Lagerort' as key-name                 */

if    can-do(pa-hlp-function,'E':U)
  and can-do(pa-hlp-function,'LagerOrt':U) then

  pa-hlp-string = adm.method.cls.DMCParameterStringSvc:cWriteValue
                    (pa-hlp-string,
                     'key-name':U,
                     'Lagerort':U).

/* --> MO#ABT-IVC-0049 thongdi_p 15.07.2026 Erfassung und Auswahl Teile-LieferantenNr Auftragsbest�tigung */
  pa-hlp-string = adm.method.cls.DMCParameterStringSvc:cWriteValue
                    (pa-hlp-string,
                     'Lieferant':U,
                     string(TT_E_BelegPos.Lieferant)).
  
  pa-hlp-string = adm.method.cls.DMCParameterStringSvc:cWriteValue
                    (pa-hlp-string,
                     'key-name':U,
                     'BestellNr':U).
/* <-- MO#ABT-IVC-0049 thongdi_p 15.07.2026 Erfassung und Auswahl Teile-LieferantenNr Auftragsbest�tigung */ 
 
/* Execute standard behavior -------------------------------------------------*/

run dispatch('help-begin':U).

/* Code placed here will execute AFTER standard behavior ---------------------*/

end procedure. /* local-help-begin */

/* _UIB-CODE-BLOCK-END */
&ANALYZE-RESUME

&ANALYZE-SUSPEND _UIB-CODE-BLOCK _PROCEDURE local-initialize B-table-Win 
PROCEDURE local-initialize :
/* Description ---------------------------------------------------------------*/
/*                                                                            */
/* Super Override                                                             */
/*                                                                            */
/* Notes ---------------------------------------------------------------------*/
/*                                                                            */
/*                                                                            */
/*                                                                            */
/* Parameters ----------------------------------------------------------------*/
/*                                                                            */
/* <none>                                                                     */
/*                                                                            */
/* Examples ------------------------------------------------------------------*/
/*                                                                            */
/*                                                                            */
/*                                                                            */
/*----------------------------------------------------------------------------*/

/* Variables -----------------------------------------------------------------*/
/*----------------------------------------------------------------------------*/

define variable cReferenzNr as character     no-undo.

/* Code placed here will execute PRIOR to standard behavior. */

{adm/template/incl/dt_row00.if
  &KeyName1 = "TargetDocType"
  &KeyVar1  = "gcTargetDocType"
  &KeyName2 = "HerkBelegart"
  &KeyVar2  = "gcSourceDocType"
  &KeyName3 = "Source_Obj"
  &KeyVar3  = "gcSource_Obj"
  &NoAction = "yes"
  &NoError  = "yes"
}

if gcTargetDocType = 'EBB':U then
do:

  {adm/template/incl/dt_row00.if
    &KeyName1 = "TargetDocRefNo"
    &KeyVar1  = "cReferenzNr"
    &NoAction = "yes"
    &NoError  = "yes"
  }

  giReferenzNr = integer(cReferenzNr).

end. /* if gcTargetDocType = 'EBB':U */
else
do:

  {adm/template/incl/dt_row00.if
    &KeyName1 = "TargetObjectID"
    &KeyVar1  = "gcTargetObj"
    &NoAction = "yes"
    &NoError  = "yes"
  }

end.

/* Dispatch standard ADM method.                             */
run dispatch in this-procedure ( 'initialize':U ) .

/* Code placed here will execute AFTER standard behavior.    */

if return-value <> 'ADM-ERROR':U then
do:

  assign
    {setwidgetattr
       "gdWert_RZ_1"
       "label"
       "string(adm.config.cls.DCCAppConfigSvc:prpoInstance:cParameterValue ('EB_DiscountSurchargeValueColumnLabel1':U))"
       "in browse {&browse-name}"}
    {setwidgetattr
       "gdWert_RZ_2"
       "label"
       "string(adm.config.cls.DCCAppConfigSvc:prpoInstance:cParameterValue ('EB_DiscountSurchargeValueColumnLabel2':U))"
       "in browse {&browse-name}"}
    {setwidgetattr
       "gdproz_RZ_1"
       "label"
       "string(adm.config.cls.DCCAppConfigSvc:prpoInstance:cParameterValue ('EB_DiscountSurchargePercColumnLabel1':U))"
       "in browse {&browse-name}"}
    {setwidgetattr
       "gdproz_RZ_2"
       "label"
       "string(adm.config.cls.DCCAppConfigSvc:prpoInstance:cParameterValue ('EB_DiscountSurchargePercColumnLabel2':U))"
       "in browse {&browse-name}"}
    {setwidgetattr
       "gdproz_RZ_3"
       "label"
       "string(adm.config.cls.DCCAppConfigSvc:prpoInstance:cParameterValue ('EB_DiscountSurchargePercColumnLabel3':U))"
       "in browse {&browse-name}"}
    .

  if not {fn pa_lUISvcIsInDesignMode} then
  do:

    if gcTargetDocType = 'EBB':U then
    do:

      if not available E_AB_Kopf then

        find E_AB_Kopf
          where E_AB_Kopf.Firma      = {firma/ebelkop.fir pa-Firma}
            and E_AB_Kopf.ReferenzNr = giReferenzNr
          exclusive-lock.

      {setwidgetattr
         "gdLABFZGes"
         "visible"
         "no"
         "in browse {&browse-name}"}.

      {fnarg
        pa_lUISvcSetWidgetHiddenState
        "BtnPackage:handle in frame {&FRAME-NAME}, yes"}.

    end. /* if gcTargetDocType = 'EBB':U */

    else if gcTargetDocType = 'EDA':U then
    do:

      if not available EBT_Delivery then

        find EBT_Delivery
          where EBT_Delivery.EBT_Delivery_Obj = gcTargetObj
          exclusive-lock.

      if not available EBT_DesAdv then

        find EBT_DesAdv
          where EBT_DesAdv.EBT_DesAdv_Obj = EBT_Delivery.EBT_DesAdv_Obj
          no-lock.

      assign
        {setwidgetattr
           "gdEinzelpreis"
           "visible"
           "no"
           "in browse {&browse-name}"}
        {setwidgetattr
           "gdWert_RZ_1"
           "visible"
           "no"
           "in browse {&browse-name}"}
        {setwidgetattr
           "gdWert_RZ_2"
           "visible"
           "no"
           "in browse {&browse-name}"}
        {setwidgetattr
           "gdproz_RZ_1"
           "visible"
           "no"
           "in browse {&browse-name}"}
        {setwidgetattr
           "gdproz_RZ_2"
           "visible"
           "no"
           "in browse {&browse-name}"}
        {setwidgetattr
           "gdproz_RZ_3"
           "visible"
           "no"
           "in browse {&browse-name}"}
        {setwidgetattr
           "TT_E_BelegPos.Warenwert_offen"
           "visible"
           "no"
           "in browse {&browse-name}"}
        {setwidgetattr
           "TT_E_BelegPos.WaeBez"
           "visible"
           "no"
           "in browse {&browse-name}"}
        {setwidgetattr
           "gdLABFZGes"
           "visible"
           "(gcSourceDocType = 'ECO':U)"
           "in browse {&browse-name}"}
        {setwidgetattr
           "TT_E_BelegPos.AB_PositionsNr"
           "label"
           "'LSPos':T6"
           "in browse {&browse-name}"}
        {setwidgetattr
           "TT_E_BelegPos.Liefertermin"
           "label"
           "'EinDatS':T10"
           "in browse {&browse-name}"}
        {setwidgetattr
           "TT_E_BelegPos.Menge"
           "label"
           "'Liefermenge':T12"
           "in browse {&browse-name}"}
        .

      if gcSourceDocType = 'ECO':U then

        assign
          {setwidgetattr
             "TT_E_BelegPos.Bestellmenge"
             "label"
             "'LAB-FZ':T15"
             "in browse {&browse-name}"}
          {setwidgetattr
             "TT_E_BelegPos.gelieferte_Menge"
             "label"
             "'EingangsFZ':T15"
             "in browse {&browse-name}"}
          {setwidgetattr
             "TT_E_BelegPos.Wunschtermin"
             "visible"
             "no"
             "in browse {&browse-name}"}
          .

    end. /* else if gcTargetDocType = 'EDA':U */

    if can-do('EB,EAB,ERL':U,gcSourceDocType) then

      find E_BelegKopf
        where E_BelegKopf.E_BelegKopf_Obj = gcSource_Obj
        no-lock no-error.

    else if gcSourceDocType = 'ECO':U then

      find EBT_CallOrder
        where EBT_CallOrder.EBT_CallOrder_Obj = gcSource_Obj
        no-lock no-error.

   /* Only lines from documents with the same term of delivery and the same */
   /* place of destination as the present despatch advice may be adopted.   */

    if gcTargetDocType = 'EDA':U then

      if gcSourceDocType = 'ECO':U then
      do:

        {eink/incl/e_bab_01.if
          &ippSourceTable = "EBT_CallOrder"
        }

      end.

      else
      do:

        {eink/incl/e_bab_01.if
          &ippSourceTable = "E_BelegKopf"
        }

      end.

    /* Bei R�cklieferungen keine Rabatt- und Zuschlagsinformationen anzeigen */

    if    available E_BelegKopf
      and E_BelegKopf.BelegArt = 'ERL':U then

      assign
        {setwidgetattr
           "gdEinzelpreis"
           "visible"
           "no"
           "in browse {&browse-name}"}
        {setwidgetattr
           "gdWert_RZ_1"
           "visible"
           "no"
           "in browse {&browse-name}"}
        {setwidgetattr
           "gdWert_RZ_2"
           "visible"
           "no"
           "in browse {&browse-name}"}
        {setwidgetattr
           "gdproz_RZ_1"
           "visible"
           "no"
           "in browse {&browse-name}"}
        {setwidgetattr
           "gdproz_RZ_2"
           "visible"
           "no"
           "in browse {&browse-name}"}
        {setwidgetattr
           "gdproz_RZ_3"
           "visible"
           "no"
           "in browse {&browse-name}"}
        &IF lookup("EB_DESADV":U,"{&PA-OPTIONEN}":U) = 0 &THEN
          {setwidgetattr
             "TT_E_BelegPos.TransitQty"
             "visible"
             "no"
             "in browse {&browse-name}"}
        &ENDIF
       .

    run request in adm-broker-hdl (this-procedure,
                                   'container-source':U,
                                   'set-window-title':U).

    run init-TT.

  end. /* if not {fn pa_lUISvcIsInDesignMode} */

end. /* if return-value <> 'ADM-ERROR':U then */

end procedure.

/* _UIB-CODE-BLOCK-END */
&ANALYZE-RESUME

&ANALYZE-SUSPEND _UIB-CODE-BLOCK _PROCEDURE local-row-available B-table-Win 
PROCEDURE local-row-available :
/* Description ---------------------------------------------------------------*/
/*                                                                            */
/* Super Override                                                             */
/*                                                                            */
/* Notes ---------------------------------------------------------------------*/
/*                                                                            */
/*                                                                            */
/*                                                                            */
/* Parameters ----------------------------------------------------------------*/
/*                                                                            */
/* <none>                                                                     */
/*                                                                            */
/* Examples ------------------------------------------------------------------*/
/*                                                                            */
/*                                                                            */
/*                                                                            */
/*----------------------------------------------------------------------------*/

/* Variables -----------------------------------------------------------------*/
/*----------------------------------------------------------------------------*/

/* Buffers -------------------------------------------------------------------*/

/*----------------------------------------------------------------------------*/
/* Processing                                                                 */
/*----------------------------------------------------------------------------*/

/* Code placed here will execute PRIOR to standard behavior ------------------*/

/* Execute standard behavior -------------------------------------------------*/

run dispatch('row-available':U).

/* Code placed here will execute AFTER standard behavior ---------------------*/

if return-value <> 'ADM-ERROR':U then

  /* We must call the trigger code because otherwise the fields for the line  */
  /* and the quantity will not be initialized.                                */

  apply 'row-entry':U to browse {&BROWSE-NAME}.

end procedure. /* local-row-available */

/* _UIB-CODE-BLOCK-END */
&ANALYZE-RESUME

&ANALYZE-SUSPEND _UIB-CODE-BLOCK _PROCEDURE local-update-record B-table-Win 
PROCEDURE local-update-record :
/* Description ---------------------------------------------------------------*/
/*                                                                            */
/* Super Override                                                             */
/*                                                                            */
/* Notes ---------------------------------------------------------------------*/
/*                                                                            */
/*                                                                            */
/*                                                                            */
/* Parameters ----------------------------------------------------------------*/
/*                                                                            */
/* <none>                                                                     */
/*                                                                            */
/* Examples ------------------------------------------------------------------*/
/*                                                                            */
/*                                                                            */
/*                                                                            */
/*----------------------------------------------------------------------------*/

/* Variables -----------------------------------------------------------------*/
/*----------------------------------------------------------------------------*/

/* Buffers -------------------------------------------------------------------*/

define buffer bTT_E_BelegPos for temp-table TT_E_BelegPos.

/*----------------------------------------------------------------------------*/
/* Processing                                                                 */
/*----------------------------------------------------------------------------*/

/* Code placed here will execute PRIOR to standard behavior ------------------*/

/* Assignment here, because F3 would not respect the present screen-value. */

/* If the Button 'Save' was pressed in the toolbar and the storage area was   */
/* not valid, then glStorAreaValid was set to no in the leave trigger of the  */
/* field storage area in order to return ADM-ERROR here.                      */
/* In the case of saving 'return no-apply' in the leave trigger does not      */
/* stop the program.                                                          */

if gcTargetDocType = 'EDA':U then

  if not glStorAreaValid then

    return 'ADM-ERROR':U.

  else

    for each bTT_E_BelegPos
      where bTT_E_BelegPos.AB_PositionsNr <> ?
      on error undo, throw:

      if not lCheckStorageAreaOK(no,  /* plSaveButtonPressed */
                                 bTT_E_BelegPos.Lagerort,
                                 bTT_E_BelegPos.Artikel,
                                 rowid(bTT_E_BelegPos)) then
      do:

        glStorAreaValid = no.
        return 'ADM-ERROR':U.

      end. /* if not lCheckStorageAreaOK(no, ... */

    end. /* for each TT_E_BelegPos */

  else

    /* Check whether all lines to adopt show a delivery date. If a return was */
    /* made it may have been removed by the toolbar (save) if it was          */
    /* not valid.                                                             */

    for each bTT_E_BelegPos
      where bTT_E_BelegPos.AB_PositionsNr <> ?
        and bTT_E_BelegPos.Liefertermin    = ?
      on error undo, throw:

      adm.method.cls.DMCMessageSvc:prpoInstance:showError
        ('e_ab_00008':U).

    end. /* for each TT_E_BelegPos */     

/* If the line number has been changed to an already existing line number     */
/* or if an invalid delivery date was entered, and the save button has been   */
/* pressed then we stop the saving now.                                       */

if glWrongInput then
  return 'ADM-ERROR':U.

/* Dispatch standard ADM method.                             */

run dispatch ('update-record':U).

/* Code placed here will execute AFTER standard behavior ---------------------*/

end procedure. /* update-record */

/* _UIB-CODE-BLOCK-END */
&ANALYZE-RESUME

&IF DEFINED(EXCLUDE-onError_row-leave_br_table) = 0 &THEN

&ANALYZE-SUSPEND _UIB-CODE-BLOCK _PROCEDURE onError_row-leave_br_table Method-Library
procedure onError_row-leave_br_table :
/* Description ---------------------------------------------------------------*/
/*                                                                            */
/* Code executed on error from ui-trigger row-leave of br_table.              */
/*                                                                            */
/* Parameters ----------------------------------------------------------------*/
/*                                                                            */
/* <none>                                                                     */
/*                                                                            */
/*----------------------------------------------------------------------------*/
assign
  gdPositionsNrAlt = ?
  glFehler         = yes
  .

/* Choose entry field with respect to the last message or use the field   */
/* quantity as default.                                                   */

case gcEntryField:

  when 'Menge':U then
    run pa_UISvcApplyEventToWidgetByHandle
          ('entry':U,
           TT_E_BelegPos.Menge:handle in browse {&BROWSE-NAME}).

  when 'Liefertermin':U then
    run pa_UISvcApplyEventToWidgetByHandle
          ('entry':U,
           TT_E_BelegPos.Liefertermin:handle in browse {&BROWSE-NAME}).

  when 'AB_PositionsNr':U then
    run pa_UISvcApplyEventToWidgetByHandle
          ('entry':U,
           TT_E_BelegPos.AB_PositionsNr:handle in browse {&BROWSE-NAME}).

  otherwise
  do:

    gcEntryField = 'Menge':U.
    run pa_UISvcApplyEventToWidgetByHandle
          ('entry':U,
           TT_E_BelegPos.Menge:handle).

  end.

end case. /* case gcEntryField: */

end procedure.


/* _UIB-CODE-BLOCK-END */
&ANALYZE-RESUME

&ENDIF


&ANALYZE-SUSPEND _UIB-CODE-BLOCK _PROCEDURE Package B-table-Win 
PROCEDURE Package :
/* Description ---------------------------------------------------------------*/
/*                                                                            */
/* Aufruf des Verpackungsprogramms �ber den Button Packmittel                 */
/*                                                                            */
/* Notes ---------------------------------------------------------------------*/
/*                                                                            */
/*                                                                            */
/*                                                                            */
/* Parameters ----------------------------------------------------------------*/
/*                                                                            */
/* <none>                                                                     */
/*                                                                            */
/* Examples ------------------------------------------------------------------*/
/*                                                                            */
/*                                                                            */
/*                                                                            */
/*----------------------------------------------------------------------------*/

&IF   lookup ("EB_DESADV":U,"{&PA-OPTIONEN}":U) > 0
  and lookup ("M_PACK":U,"{&PA-OPTIONEN}":U)    > 0 &THEN

  /* Variables ---------------------------------------------------------------*/
  /* cPackaging   Packaging                                                   */
  /* cPMKeyAdopt3 Call orders are adopted to the despatch advice using the    */
  /*              ObjectID of the header (EBT_CallOrder_Obj). Besides this,   */
  /*              packaging may reference to the valid purchase release       */
  /*              (EBT_PurchRelease_Obj). cPMKeyAdopt3 gets the presently     */
  /*              valid key for adopting packaging from call orders and other */
  /*              documet types.                                              */
  /*--------------------------------------------------------------------------*/

  define variable cPackaging   like M_LTPos.Packmittel                    no-undo.
  define variable cPMKeyAdopt3 like M_LTPos.Herk_Schluessel3              no-undo.

  /* Buffers -----------------------------------------------------------------*/

  /*--------------------------------------------------------------------------*/
  /* Processing                                                               */
  /*--------------------------------------------------------------------------*/

  if available TT_E_BelegPos then
  do:

    cPMKeyAdopt3 = mawi.base.cls.MMCPackagingSvc:prpoInstance:cCheckPMKeyAdopt3
                     (TT_E_BelegPos.BelegArt,
                      {&pa_MM_PackagingInformational}, /* Function Code 9 */
                      gcSource_Obj,
                      TT_E_BelegPos.Source_Obj).

    run mawi/proc/m_ppmi30.w (input-output cPackaging,
                                           'E':U,
                                           {&pa_MM_PackagingInformational},     /* Function Code 9 */
                                           '':U,                                /* DocType 1       */
                                           '':U,                                /* Key 1           */
                                           TT_E_BelegPos.Belegart,              /* DocType 2       */
                                           gcSource_Obj,                        /* Key 2           */
                                           TT_E_BelegPos.Belegart,
                                           cPMKeyAdopt3,                        /* Key 3           */
                                           TT_E_BelegPos.Lagerort,
                                           ?,
                                           TT_E_BelegPos.Menge,
                                           TT_E_BelegPos.MengenEinheit,
                                           gbS_Artikel.Gewicht,
                                           0,
                                           (if available E_BelegKopf then
                                              E_BelegKopf.Lieferant
                                            else
                                              EBT_CallOrder.Lieferant),
                                           ?,
                                           no).

    if can-do('{&pa_MM_PackagingInformational},{&pa_MM_PackagingDelivery}':U,
              string(giTargetFunction)) then   /* Function Code 9,4 */

      run CheckPackage.

  end. /* if available TT_E_BelegPos then */

&ENDIF /* &IF   lookup ("EB_DESADV":U,"{&PA-OPTIONEN}":U) > 0 */

end procedure. /* Package */

/* _UIB-CODE-BLOCK-END */
&ANALYZE-RESUME

&ANALYZE-SUSPEND _UIB-CODE-BLOCK _PROCEDURE read-current-offset B-table-Win  adm/support/proc/ds_fin02.p
PROCEDURE read-current-offset :
/* Description ---------------------------------------------------------------*/
/*                                                                            */
/* Get back current key-value                                                 */
/*                                                                            */
/* Parameters ----------------------------------------------------------------*/
/*                                                                            */
/* pcField: name of requested field                                           */
/*                                                                            */
/*----------------------------------------------------------------------------*/

define input parameter pcField as char no-undo.

/*----------------------------------------------------------------------------*/
/* Processing                                                                 */
/*----------------------------------------------------------------------------*/

if available TT_E_BelegPos then

  case pcField:

    when 'PositionsNr':U then
      return string(TT_E_BelegPos.PositionsNr).

    when 'BestellNr':U then
      return TT_E_BelegPos.BestellNr.

    when 'LagerOrt':U then
      return string(TT_E_BelegPos.LagerOrt).

    {&{&PA-XBASISNAME}_C_CurrentOffset}
    {&{&PA-XBASISNAME}_U_CurrentOffset}
    {&{&PA-XBASISNAME}_Q_CurrentOffset}
    {&{&PA-XBASISNAME}_CurrentOffset}
    {&{&PA-XBASISNAME}_Y_CurrentOffset}

    otherwise
      {adm/template/incl/dt_vbs12.if &ippSortCaseName = "pcField"}

  end case.

return ?.
end procedure. /* read-current-offset */

/* _UIB-CODE-BLOCK-END */
&ANALYZE-RESUME

&ANALYZE-SUSPEND _UIB-CODE-BLOCK _PROCEDURE send-key B-table-Win  adm/support/proc/_key-snd.p
PROCEDURE send-key :
/* Description ---------------------------------------------------------------*/
/*                                                                            */
/* Sends a requested KEY value back to the calling SmartObject                */
/*                                                                            */
/* Parameters ----------------------------------------------------------------*/
/*                                                                            */
/* see adm/template/sndkytop.i                                                */
/*                                                                            */
/*----------------------------------------------------------------------------*/

/*----------------------------------------------------------------------------*/
/* Processing                                                                 */
/*----------------------------------------------------------------------------*/

/* Define variables needed by this internal procedure.                        */

{adm/template/incl/sndkytop.i}

/* Return the key value associated with each key case.                        */

{adm/template/incl/sndkycas.i "Belegart" "TT_E_BelegPos" "Belegart" " "}
{adm/template/incl/sndkycas.i "ReferenzNr" "TT_E_BelegPos" "ReferenzNr" " "}
{adm/template/incl/sndkycas.i "PositionsNr" "TT_E_BelegPos" "PositionsNr" " "}
{adm/template/incl/sndkycas.i "Source_Obj" "TT_E_BelegPos" "Source_Obj" " "}
{adm/template/incl/sndkycas.i "$KEY" "TT_E_BelegPos" " " "eink/incl/e_belpo.sl "}
{adm/template/incl/sndkycas.i "E_BelegPos_Obj" "TT_E_BelegPos" "E_BelegPos_Obj" " "}

/* Close the CASE statement and end the procedure.                            */

{adm/template/incl/sndkyend.i}

end procedure. /* send-key */

/* _UIB-CODE-BLOCK-END */
&ANALYZE-RESUME

&ANALYZE-SUSPEND _UIB-CODE-BLOCK _PROCEDURE send-records B-table-Win  adm/support/proc/ds_rec01.p
PROCEDURE send-records :
/* Description ---------------------------------------------------------------*/
/*                                                                            */
/* Send record ROWID's for all tables used by this file.                      */
/*                                                                            */
/* Parameters ----------------------------------------------------------------*/
/*                                                                            */
/* see template/incl/snd-head.i                                               */
/*                                                                            */
/*----------------------------------------------------------------------------*/

/*----------------------------------------------------------------------------*/
/* Processing                                                                 */
/*----------------------------------------------------------------------------*/

/* Define variables needed by this internal procedure.                        */

{adm/template/incl/snd-head.i}

/* For each requested table, put it's ROWID in the output list.               */

{adm/template/incl/snd-list.i "E_BelegPos"}
{adm/template/incl/snd-list.i "EBL_Progress"}

/* Deal with any unexpected table requests before closing.                    */

{adm/template/incl/snd-end.i}

end procedure. /* send-records */

/* _UIB-CODE-BLOCK-END */
&ANALYZE-RESUME

&ANALYZE-SUSPEND _UIB-CODE-BLOCK _PROCEDURE state-changed B-table-Win 
PROCEDURE state-changed :
/* -----------------------------------------------------------
  Purpose:
  Parameters:  <none>
  Notes:
-------------------------------------------------------------*/
  define input parameter p-issuer-hdl as handle    no-undo.
  define input parameter p-state      as character no-undo.

  define buffer bTT_E_BelegPos for temp-table TT_E_BelegPos.

  if (   p-state = 'first-record':U
      or p-state = 'not-first-or-last':U) then

    glCancelRecord = no.

  case p-state:
      /* Object instance CASEs can go here to replace standard behavior
         or add new cases. */
    {adm/template/incl/dt_brw00.if}

    when 'SaveButtonPressed':U then
    do:

      if    gcTargetDocType = 'EDA':U
        and glCancelRecord  = no then
      do:

        for each bTT_E_BelegPos
          where bTT_E_BelegPos.AB_PositionsNr <> ?
          on error undo, throw:

          if not lCheckStorageAreaOK(yes,  /* plSaveButtonPressed */
                                     bTT_E_BelegPos.Lagerort,
                                     bTT_E_BelegPos.Artikel,
                                     rowid(bTT_E_BelegPos)) then
          do:

            glFehler = yes.

            adm.method.cls.DMCMessageSvc:prpoInstance:showError('s_bel00002':U).

          end. /* if not lCheckStorageAreaOK(yes, ... */

        end. /* for each bTT_E_BelegPos */

      end. /* if gcTargetDocType = 'EDA':U */

      if not glCancelAdoption then
      do
        on error undo, throw:

        if gcTargetDocType = 'EBB':U then

          run Erzeuge-ABPositionen.

        else

          run CreateShippingDocLines.

        /* If an error was shown from the trigger when storing the record,    */
        /* then open the record and stop.                                     */

        if   glFehler    = yes
          or glDateSplit = yes then
        do:

          run new-state('toolbar-update,tableio-source':U).

          return.

        end. /* if glFehler = yes then */

        /* If no more adoptable lines exist for the current document          */
        /* then delete the Temp-Table record in the Document-Browser.         */
        /* For purchase orders containing lot parts do not clear the record   */
        /* in the browser.                                                    */

        if       gcTargetDocType                      = 'EDA':U
             and (not can-find (S_Artikel
                           where S_Artikel.Firma      = {firma/sartikel.fir pa-Firma}
                             and S_Artikel.Artikel    = TT_E_BelegPos.Artikel
                             and S_Artikel.Chargenart > '':U))
          or not can-find(first TT_E_BelegPos
                    where TT_E_BelegPos.AB_PositionsNr = ?) then

          run new-state ('NoMoreAdoptablePosition,record-source':U).

        catch goProgressError as Progress.Lang.Error:

          (new adm.method.cls.DMCErrorMessageErr(oError)):displayProgressErrorsOnly().

          if gcEntryField = '':U then

            gcEntryField = 'Liefertermin':U.

          run new-state('toolbar-update,tableio-source':U).

          return.

        end catch.

      end. /* if not glCancelAdoption */

      /* Send this state to show the line window that the creation has been   */
      /* done.                                                                */

      run new-state ('update-complete,record-source':U).

      glUpdateComplete = yes.

    end. /* when 'SaveButtonPressed':U */

  end case.

  /* Enable or disable the field 'Supplier lot' also if navigation buttons    */
  /* are used.                                                                */

  if    gcTargetDocType = 'EDA':U
    and (   p-state = 'first-record':U
         or p-state = 'not-first-or-last':U) then

    if not can-find (S_Artikel
                       where S_Artikel.Firma      = {firma/sartikel.fir pa-Firma}
                         and S_Artikel.Artikel    = TT_E_BelegPos.Artikel
                         and S_Artikel.Chargenart > '':U) then

      {fnarg
        pa_lUISvcDisableBrowseColumn
        "TT_E_BelegPos.LieferantenCharge:handle in browse {&browse-name}"}.

    else

      {fnarg
        pa_lUISvcEnableBrowseColumn
        "TT_E_BelegPos.LieferantenCharge:handle in browse {&browse-name}"}.

end procedure.

/* _UIB-CODE-BLOCK-END */
&ANALYZE-RESUME

&ANALYZE-SUSPEND _UIB-CODE-BLOCK _PROCEDURE Zuordnen-Termin B-table-Win 
PROCEDURE Zuordnen-Termin :
/*------------------------------------------------------------------------------
  Purpose:     Ordne alle noch nicht belegten bzw. initialisierten Terminen
               den einzugebenden Termin zu
  Parameters:  <none>
  Notes:
------------------------------------------------------------------------------*/

  define buffer bE_AB_Pos      for E_AB_Pos.
  define buffer bTT_E_BelegPos for temp-table TT_E_BelegPos.

  define variable tTermin as date      no-undo.
  define variable i       as integer   no-undo.

  if can-find (first bTT_E_BelegPos
    where bTT_E_BelegPos.AB_PositionsNr = ?) then

    run eink/proc/e_pab_12.w (output tTermin).

  else

    adm.method.cls.DMCMessageSvc:prpoInstance:showError
      ('e_ab_00011':U).

  if tTermin <> ? then
  do:

    find last bE_AB_Pos
      where bE_AB_Pos.Firma      = E_AB_Kopf.Firma
        and bE_AB_Pos.ReferenzNr = E_AB_Kopf.ReferenzNr
      no-lock no-error.

    find last bTT_E_BelegPos
      where bTT_E_BelegPos.AB_PositionsNr < ?
      use-index AB
      no-lock no-error.

    i = max((if available bE_AB_Pos then
               truncate(bE_AB_Pos.PositionsNr + 1,0)
             else
               1),
            (if available bTT_E_BelegPos then
               truncate(bTT_E_BelegPos.AB_PositionsNr + 1,0)
             else
               1)).

    /* alle noch nicht belegten bzw. lediglich initialisierten Liefertermine */
    /* jetzt mit dem vorgegebenen Termin belegen.                            */

    for each bTT_E_BelegPos
      where bTT_E_BelegPos.AB_PositionsNr   = ?
        or (bTT_E_BelegPos.AB_PositionsNr   = i - 1
          and (bTT_E_BelegPos.Menge         = ?
            or bTT_E_BelegPos.Menge         = bTT_E_BelegPos.Bestellmenge))
      by bTT_E_BelegPos.PositionsNr
      on error undo, throw:

      assign
        bTT_E_BelegPos.AB_PositionsNr = (if bTT_E_BelegPos.AB_PositionsNr = ? then
                                           i
                                         else
                                           bTT_E_BelegPos.AB_PositionsNr)
        bTT_E_BelegPos.AB_ReferenzNr  = E_AB_Kopf.ReferenzNr
        bTT_E_BelegPos.Liefertermin   = tTermin
        bTT_E_BelegPos.Menge          = bTT_E_BelegPos.Restmenge
        i                                = (if bTT_E_BelegPos.AB_PositionsNr = i then
                                              i + 1
                                            else
                                              i)
        .

    end. /* for each bTT_E_BelegPos */

    run dispatch ('open-query':U).

  end. /* if tTermin <> ? */

  return.

end procedure.

/* _UIB-CODE-BLOCK-END */
&ANALYZE-RESUME

/* ************************  Function Implementations ***************** */

&ANALYZE-SUSPEND _UIB-CODE-BLOCK _FUNCTION cAktuellePositionsnummern B-table-Win 
FUNCTION cAktuellePositionsnummern returns character
  ( ) :
/*------------------------------------------------------------------------------
  Purpose:  Die bereits vergebenen AB-Positionsnummern werden als kommasepa-
            rierte Liste zur�ckgegeben.
    Notes:
------------------------------------------------------------------------------*/

  define variable cPosNummern as character no-undo init '':U.

  define buffer TT_E_BelegPos for temp-table TT_E_BelegPos.

  for each TT_E_BelegPos
    where TT_E_BelegPos.AB_PositionsNr <> ?
    on error undo, throw:

    cPosNummern = cPosNummern
                  + (if cPosNummern <> '':U then
                       ',':U
                     else
                       '':U)
                  + string(TT_E_BelegPos.AB_PositionsNr * 10).

  end. /* for each TT_E_BelegPos */

  return cPosNummern.   /* Function return value. */

end function.

/* _UIB-CODE-BLOCK-END */
&ANALYZE-RESUME

&ANALYZE-SUSPEND _UIB-CODE-BLOCK _FUNCTION dBestaetigteMenge B-table-Win 
FUNCTION dBestaetigteMenge returns decimal
  ( pcRowidString as character) :
/*------------------------------------------------------------------------------
  Purpose:  Die bereits best�tigte Menge zur aktuellen Belegposition wird er-
            mittelt und zur�ckgegeben.
    Notes:  Source Document Types 'EAB' and 'ECO' are treated in e_bab_12.w
------------------------------------------------------------------------------*/

  define variable dMenge as decimal decimals 3 no-undo init 0.

  define buffer bTT_E_BelegPos   for temp-table TT_E_BelegPos.
  define buffer bE_AB_Pos        for E_AB_Pos.
  define buffer bEBT_DeliveryPos for EBT_DeliveryPos.
  define buffer bE_BelegPos          for E_BelegPos.

  if gcSourceDocType <> 'ECO':U then
  do:

    find bE_BelegPos
      where rowid (bE_BelegPos) = to-rowid (pcRowidString)
      no-lock no-error.

    if available bE_BelegPos then
    do:

      /* Accumulate confirmed quantities of the current document with respect */
      /* to the requested date.                                               */

      for each bTT_E_BelegPos
        where bTT_E_BelegPos.PositionsNr = bE_BelegPos.PositionsNr
        on error undo, throw:

        dMenge = dMenge + bTT_E_BelegPos.Menge.

      end. /* for each bTT_E_BelegPos */

      /* Accumulate the confirmed quantities of other order confirmations or  */
      /* shipping documents respectively.                                     */

      if gcTargetDocType = 'EBB':U then

        for each bE_AB_Pos
          where bE_AB_Pos.Firma            = bE_BelegPos.Firma
            and bE_AB_Pos.Herk_BelegArt    = bE_BelegPos.BelegArt
            and bE_AB_Pos.Herk_ReferenzNr  = bE_BelegPos.ReferenzNr
            and bE_AB_Pos.Herk_PositionsNr = bE_BelegPos.PositionsNr
            and bE_AB_Pos.ReferenzNr      <> E_AB_Kopf.ReferenzNr
          no-lock
          on error undo, throw:

          dMenge = dMenge + bE_AB_Pos.Menge.

        end. /* for each bE_AB_Pos */

      else if gcTargetDocType = 'EDA':U then

        for each bEBT_DeliveryPos  /* code checked by jf 12.02.2009 */
          where bEBT_DeliveryPos.Source_Obj = bE_BelegPos.E_BelegPos_Obj
            and bEBT_DeliveryPos.offen      = yes
          no-lock
          on error undo, throw:

          dMenge = dMenge + bEBT_DeliveryPos.LieferMenge.

        end. /* for each bEBT_DeliveryPos */

    end. /* if available bE_BelegPos */

  end. /* if gcSourceDocType <> 'ECO':U */

  return dMenge. /* Function return value. */

end function.

/* _UIB-CODE-BLOCK-END */
&ANALYZE-RESUME

&ANALYZE-SUSPEND _UIB-CODE-BLOCK _FUNCTION lCheckStorageAreaOK B-table-Win 
FUNCTION lCheckStorageAreaOK returns logical
  ( plSaveButtonPressed   as logical,
    piStorageArea         as integer,
    pcPart                as character,
    prRowID_TT_E_BelegPos as rowid ) :
/* Description ---------------------------------------------------------------*/
/*                                                                            */
/* Check whether the storage area of the indicatred record is valid.          */
/*                                                                            */
/* Notes ---------------------------------------------------------------------*/
/*                                                                            */
/*                                                                            */
/*                                                                            */
/* Parameters ----------------------------------------------------------------*/
/*                                                                            */
/* plSaveButtonPressed    function was called when the save button was pressed*/
/*                          (question m_bel00001 appears only once.)          */
/* piStorageArea          Storage area                                        */
/* pcPart                 Part                                                */
/* prRowID_TT_E_BelegPos  RowId of presently processed TT_E_BelegPos          */
/*                                                                            */
/* Examples ------------------------------------------------------------------*/
/*                                                                            */
/*                                                                            */
/*                                                                            */
/*----------------------------------------------------------------------------*/

/* Variables -----------------------------------------------------------------*/
/*                                                                            */
/* iMRPArea         MRP-Unit of the current storage area                      */
/* iDelMRPArea      MRP-Unit of the storage areas of the delivery lines       */
/* iMRPAreaSrc      MRP-Unit of storage area in source document line          */
/* iStorageAreaSrc  Storage area of source document line                      */
/* cRecInfo         Identification of the line number in the message          */
/*                                                                            */
/*----------------------------------------------------------------------------*/

define variable iMRPArea          like ML_Lagergruppe.Lagergruppe no-undo.
&IF "{&pa_MD_LGrp_Wechsel}" = "0" &THEN
  define variable iDelMRPArea     like ML_Lagergruppe.Lagergruppe no-undo.
&ENDIF
&IF lookup("EB_DESADV":U,"{&PA-OPTIONEN}":U) > 0 &THEN
  define variable iStorageAreaSrc like ML_Ort.LagerOrt        no-undo.
  define variable iMRPAreaSrc     like ML_Lagergruppe.Lagergruppe no-undo.
&ENDIF
define variable cRecInfo          as character                    no-undo.

/* Buffers -------------------------------------------------------------------*/

define buffer bTT_E_BelegPos   for temp-table TT_E_BelegPos.
define buffer bML_Ort          for ML_Ort.
define buffer bML_Ort-Src      for ML_Ort.
define buffer bS_Artikel       for S_Artikel.
&IF lookup("EB_DESADV":U,"{&PA-OPTIONEN}":U) > 0 &THEN
  define buffer bE_BelegPos    for E_BelegPos.
  define buffer bEBT_CallOrder for EBT_CallOrder.
&ENDIF

/*----------------------------------------------------------------------------*/
/* Processing                                                                 */
/*----------------------------------------------------------------------------*/

find bTT_E_BelegPos
  where rowid (bTT_E_BelegPos) = prRowID_TT_E_BelegPos
  no-lock.

cRecInfo = string(EBT_DesAdv.Belegnummer)
           + ' ':U
           + 'Lieferschein':T18
           + ' ':U
           + EBT_Delivery.LieferscheinNr
           + ' ':U
           + 'Position':T10
           + ' ':U
           + string(bTT_E_BelegPos.PositionsNr).

if piStorageArea <> ? then
do:

  find bML_Ort
    where bML_Ort.Firma    = {firma/mlort.fir pa-Firma}
      and bML_Ort.Lagerort = piStorageArea
    no-lock no-error.

  if not available bML_Ort then

    adm.method.cls.DMCMessageSvc:prpoInstance:showError
      ('s_trg00060':U,
       string(piStorageArea)).

end. /* if piStorageArea <> ? */

find bS_Artikel
  where bS_Artikel.Firma   = {firma/sartikel.fir pa-Firma}
    and bS_Artikel.Artikel = pcPart
  no-lock.

if    piStorageArea <> ?
  and not can-do({&pa_S_PTList_OnceOnlyPartTypes}, string(bS_Artikel.ArtikelArt)) then
do:

  /* The storage area must be available  */

  if mawi.lager.cls.MLCPartStAreaSvc:prpoInstance:lIsPartAvailableInStArea(pcPart,
                                                              piStorageArea) = no then

    adm.method.cls.DMCMessageSvc:prpoInstance:showError('e_trg00061':U,
                                                         cRecInfo,
                                                         pcPart,
                                                         string(bML_Ort.Lagerort)).

  /* Storage Areas of delivery lines have to belong to the present warehouse. */

  iMRPArea = mawi.dispo.cls.MDCMRPAreaSvc:prpoInstance:iGetMRPAreaPart(pcPart,
                                                                       piStorageArea).

  &IF "{&pa_MD_LGrp_Wechsel}" = "0" &THEN

    iDelMRPArea = integer(adm.method.cls.DMCSessionSvc:cFieldValuesFromObj(EBT_Delivery.ML_Lagergruppe_Obj, 'Lagergruppe':U)).

    if iDelMRPArea <> iMRPArea then

      adm.method.cls.DMCMessageSvc:prpoInstance:showError('ebdea00050':U,
                                                          cRecInfo,
                                                          string(iDelMRPArea)).

  &ENDIF /* &IF "{&pa_MD_LGrp_Wechsel}" = "0" */

  /* If pa_MD_LGrp_Wechsel = 0 then storage areas of delivery lines have to   */
  /* belong to the warehouse of the storage area used in the source document. */

  &IF lookup("EB_DESADV":U,"{&PA-OPTIONEN}":U) > 0 &THEN

    if gcTargetDocType = 'EDA':U then
    do:

      /* MRP area belonging to the present storage area has to correspond to  */
      /* that of the source document line.                                    */

      if can-do('EB,EAB,ERL':U,gcSourceDocType) then

        find bE_BelegPos
          where rowid (bE_BelegPos) = to-rowid (bTT_E_BelegPos.RowidString)
          no-lock.

      else

        find bEBT_CallOrder
          where bEBT_CallOrder.EBT_CallOrder_Obj = gcSource_Obj
          no-lock.

      assign
        iStorageAreaSrc = (if can-do('EB,EAB,ERL':U,gcSourceDocType) then
                             bE_BelegPos.Lagerort
                           else
                             integer(adm.method.cls.DMCSessionSvc:cFieldValuesFromObj(bEBT_CallOrder.ML_Ort_Obj, 'Lagerort':U)))
        iMRPAreaSrc = mawi.dispo.cls.MDCMRPAreaSvc:prpoInstance:iGetMRPAreaPart(bTT_E_BelegPos.Artikel,
                                                                                iStorageAreaSrc)
        .

      /* Storage Areas of delivery lines have to belong to the present        */
      /* warehouse, always if 'pa_MD_LGrp_Wechsel' is not active              */
      /* or if 'pa_MD_LGrp_Wechsel' is activ and the source document type     */
      /* is a call order.                                                     */

      if      iMRPAreaSrc     <> iMRPArea
        &IF "{&pa_MD_LGrp_Wechsel}" = "1" &THEN
          and gcSourceDocType  = 'ECO':U
        &ENDIF then

        adm.method.cls.DMCMessageSvc:prpoInstance:showError ('ebdea00064':U,
                                                             cRecInfo,
                                                             string(iMRPAreaSrc)).

      &IF "{&pa_MD_LGrp_Wechsel}" = "1" &THEN

        find bML_Ort-Src
          where bML_Ort-Src.Firma    = {firma/mlort.fir pa-Firma}
            and bML_Ort-Src.LagerOrt = iStorageAreaSrc
          no-lock.

        if bML_Ort-Src.ML_Ort_Obj <> bML_Ort.ML_Ort_Obj then
        do:

          /* New storage area valid for part */

          if mawi.lager.cls.MLCPartStAreaSvc:prpoInstance:lIsPartAvailableInStArea
              (bTT_E_BelegPos.Artikel,
               bML_Ort.Lagerort) = no then

            adm.method.cls.DMCMessageSvc:prpoInstance:showError
              ('mltrg00023':U,
               string(bML_Ort.Lagerort),
               bTT_E_BelegPos.Artikel).

          /* Ask whether the two storage areas may not belong to the same     */
          /* MRP Area.                                                        */

          if    plSaveButtonPressed  = yes
            and iMRPArea            <> iMRPAreaSrc
            and adm.method.cls.DMCMessageSvc:prpoInstance:lShowMessage
                 ('m_bel00001':U,
                  string(bTT_E_BelegPos.PositionsNr),
                  string(bML_Ort.Lagerort),
                  string(iMRPArea),
                  string(iMRPAreaSrc)) = no then

            return no.

        end. /* if bML_Ort-Old.ML_Ort_Obj <> bML_Ort.ML_Ort_Obj then */

      &ENDIF

    end. /* if gcTargetDocType = 'EDA':U then */

  &ENDIF

end. /* if    piStorageArea <> ? */

return yes.

/* When an error message occured, then do not continue. */

catch goProgressError as Progress.Lang.Error:

  (new adm.method.cls.DMCErrorMessageErr(goProgressError)):displayProgressErrorsOnly().

  return no.

end catch.

end function. /* lCheckStorageAreaOK */

/* _UIB-CODE-BLOCK-END */
&ANALYZE-RESUME

